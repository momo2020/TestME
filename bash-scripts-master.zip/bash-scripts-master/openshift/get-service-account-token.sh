#!/bin/sh

SA_NAME=$1
PROJECT=$2

SECRET_NAME=$(oc get sa $SA_NAME -o yaml -n $PROJECT | grep  "^- name: $SA_NAME-token.*" | sed 's/- name: //')
oc get secret $SECRET_NAME -o go-template --template='{{.data.token}}' -n $PROJECT | base64 -d