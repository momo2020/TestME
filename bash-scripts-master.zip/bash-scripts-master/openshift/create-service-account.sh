#!/bin/sh

SCRIPT_PATH="`dirname \"$0\"`"

SA_NAME=$1
PROJECT=$2

oc create sa $SA_NAME -n $PROJECT
oc policy add-role-to-user edit $SA_NAME -n $PROJECT

$SCRIPT_PATH/get-service-account-token.sh $SA_NAME $PROJECT