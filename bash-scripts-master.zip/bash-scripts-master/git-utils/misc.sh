#!/usr/bin/env bash

SCRIPT_PATH="`dirname \"$0\"`"
PATH=${SCRIPT_PATH}/bin:$PATH
OAUTH_HEADER="Authorization: token $OAUTH_TOKEN"

function echoing() {
    msg = $1
    echo ${msg}

}
# Display user
#curl -kl -H "Authorization: token $OAUTH_TOKEN" https://githubifc.iad.ca.inet/api/v3/user/repos
curl -kl -H "$OAUTH_HEADER" https://githubifc.iad.ca.inet/api/v3/user/repos

# Create hello-world
#curl -kl -H "$OAUTH_HEADER" -X POST -d @${SCRIPT_PATH}/repo-template.json https://githubifc.iad.ca.inet/api/v3/user/repos

# Fork
curl -kl -H "$OAUTH_HEADER" -X POST https://githubifc.iad.ca.inet/api/v3/repos/Sandbox/ocp-simple-app/forks