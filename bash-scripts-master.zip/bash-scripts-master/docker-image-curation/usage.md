# Curation Usage

1. Ensure that with your docker client, you are logged to the following docker registries:
    * `docker-group.iad.ca.inet:8503`
    * `docker-immutable.iad.ca.inet:8513`
2. If not already done execute:
    * `git clone git@githubifc.iad.ca.inet:DevTools/bash-scripts.git`  
    * `cd docker-image-curation`
3. Create a file that contains the list of the images you want to import. You could reuse images.txt in the local folder.
4. Execute `./batch-curate.sh <path-to-image-list-file>` 
