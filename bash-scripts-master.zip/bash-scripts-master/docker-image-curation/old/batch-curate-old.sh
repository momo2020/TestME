#/bin/sh
# IMAGE_LIST_FILE=$1
# DIR=`dirname ${0}`
# echo "IMAGE_LIST_FILE=${IMAGE_LIST_FILE}"
# echo "DIR=${DIR}"
# while read image; do
#   echo hello
# done <${IMAGE_LIST_FILE}
while read line
do
  echo "$line"
done < "${1:-/dev/stdin}"