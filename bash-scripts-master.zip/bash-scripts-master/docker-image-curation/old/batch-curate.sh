#/bin/sh
IMAGE_LIST_FILE=$1
DIR=`dirname ${0}`
while read IMAGE; do
  ${DIR}/curate.sh $IMAGE
done < $IMAGE_LIST_FILE