#/bin/sh
CURATION_GROUP=docker-group.iad.ca.inet:8503
CURATED=docker-immutable.iad.ca.inet:8513
IMAGE=$1
PULL_CMD="docker pull ${CURATION_GROUP}/${IMAGE}"
TAG_CMD="docker tag ${CURATION_GROUP}/${IMAGE}${CURATED}/${IMAGE}"
PUSH_CMD="docker push ${CURATED}/${IMAGE}"

# echo $PULL_CMD
echo "${IMAGE} XXX"
# echo $PUSH_CMD
