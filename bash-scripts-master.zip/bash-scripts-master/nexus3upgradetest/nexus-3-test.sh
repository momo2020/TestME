#!/bin/bash
echo off
echo Prepare tests

#export DOCKER_MUTABLE="docker-mutable.iad.ca.inet:8463"
#export DOCKER_GROUP="docker-group.iad.ca.inet:8473"
#export DOCKER_IMMUTABLE="docker-immutable.iad.ca.inet:8453"

export DOCKER_MUTABLE="prep-docker-mutable.iad.ca.inet:8463"
export DOCKER_GROUP="prep-docker-group.iad.ca.inet:8473"
export DOCKER_IMMUTABLE="prep-docker-immutable.iad.ca.inet:8453"

source ~/secrets/nexus-upgrade-tester-pass.sh

TEST_DIR=/tmp/nexus-3-upgrade-tests
IMAGE_01_DIR=${TEST_DIR}/01
IMAGE_02_DIR=${TEST_DIR}/02
mkdir -p ${IMAGE_01_DIR}
mkdir -p ${IMAGE_02_DIR}

function createDockerfile {
    echo `date` > ${1}/somefile.txt
    cat > ${1}/Dockerfile <<EOF
FROM ${DOCKER_GROUP}/library/hello-world
ADD somefile.txt .
EOF
    cat ${1}/Dockerfile
}
echo Starting Nexus 3 upgrade tests

echo -e "\n TEST CASE 1 - LOGIN"
echo Login as nexus-upgrade-tester to mutable
docker login -u nexus-upgrade-tester -p ${PASS} ${DOCKER_MUTABLE}

echo Login as nexus-upgrade-tester to group
docker login -u nexus-upgrade-tester -p ${PASS} ${DOCKER_GROUP}

echo Login as nexus-upgrade-tester to immutable
docker login -u nexus-upgrade-tester -p ${PASS} ${DOCKER_IMMUTABLE}

echo -e "\n TEST CASE 2 - PULL FROM REDHAT"
echo Pulling from RedHat openshift3/jenkins-slave-base-rhel7:1.0-18
docker pull ${DOCKER_GROUP}/openshift3/jenkins-slave-base-rhel7:1.0-18

echo -e "\n TEST CASE 3 - BUILD AND TAG IMAGE FROM DOCKERFILE"
echo Build test test-nexus-upgrade-1:01-SNAPSHOT
createDockerfile ${IMAGE_01_DIR}
docker build -t ${DOCKER_MUTABLE}/intact/test-nexus-upgrade-1:01-SNAPSHOT ${IMAGE_01_DIR}

echo -e "\n TEST CASE 4 - PUSH EXISTING IMAGE TO MUTABLE AND THEN DELETE FROM LOCAL REGISTRY"
echo Pushing ${DOCKER_MUTABLE}/intact/test-nexus-upgrade-1:01-SNAPSHOT
docker push ${DOCKER_MUTABLE}/intact/test-nexus-upgrade-1:01-SNAPSHOT
docker rmi ${DOCKER_MUTABLE}/intact/test-nexus-upgrade-1:01-SNAPSHOT

echo -e "\n TEST CASE 5 - BUILD AND TAG IMAGE AND PUSH TO IMMUTABLE"
echo Build test test-nexus-upgrade-2:01-RELEASE
createDockerfile ${IMAGE_02_DIR}
docker build -t ${DOCKER_IMMUTABLE}/intact/test-nexus-upgrade-2:01-RELEASE ${IMAGE_02_DIR}
echo Pushing ${DOCKER_IMMUTABLE}/intact/test-nexus-upgrade-2:01-RELEASE
docker push ${DOCKER_IMMUTABLE}/intact/test-nexus-upgrade-2:01-RELEASE

echo -e "\n TEST CASE 6 - PULL IMAGE FROM GROUP, ADD TAG AND PUSH TO MUTABLE"
echo Pulling ${DOCKER_GROUP}/intact/test-nexus-upgrade-1:01-SNAPSHOT
docker pull ${DOCKER_GROUP}/intact/test-nexus-upgrade-1:01-SNAPSHOT
echo Pushing ${DOCKER_MUTABLE}/intact/test-nexus-upgrade-bis-1:01-SNAPSHOT
echo Same content and id as test-nexus-upgrade-1:01-SNAPSHOT but different tag
docker tag ${DOCKER_GROUP}/intact/test-nexus-upgrade-1:01-SNAPSHOT ${DOCKER_MUTABLE}/intact/test-nexus-upgrade-bis-1:01-SNAPSHOT
docker push ${DOCKER_MUTABLE}/intact/test-nexus-upgrade-bis-1:01-SNAPSHOT
#docker rmi ${DOCKER_MUTABLE}/intact/test-nexus-upgrade-bis-1:01-SNAPSHOT

echo -e "\n TEST CASE 7 - BUILD, TAG AND PUSH TO MUTABLE WITH DIFFERENT CONTENT"
echo Pushing again, with different content and id, ${DOCKER_MUTABLE}/intact/test-nexus-upgrade-1:01-SNAPSHOT
createDockerfile ${IMAGE_01_DIR}
docker build -t ${DOCKER_MUTABLE}/intact/test-nexus-upgrade-1:01-SNAPSHOT ${IMAGE_01_DIR}
docker push ${DOCKER_MUTABLE}/intact/test-nexus-upgrade-1:01-SNAPSHOT

echo -e "\n TEST CASE 8 - PUSH IMAGE TO IMMUTABLE"
echo Pulling ${DOCKER_GROUP}/intact/test-nexus-upgrade-1:01-SNAPSHOT
echo Tag and push in IMMUTABLE
docker pull ${DOCKER_GROUP}/intact/test-nexus-upgrade-1:01-SNAPSHOT
docker tag ${DOCKER_GROUP}/intact/test-nexus-upgrade-1:01-SNAPSHOT ${DOCKER_IMMUTABLE}/intact/test-nexus-upgrade-1:01-RELEASE
docker push ${DOCKER_IMMUTABLE}/intact/test-nexus-upgrade-1:01-RELEASE

echo -e "\n TEST CASE 9 - PUSH EXISTING TAG WITH DIFFERENT IMAGE CONTENT TO IMMUTABLE"
echo Pulling ${DOCKER_GROUP}/intact/test-nexus-upgrade-1:01-SNAPSHOT
docker pull ${DOCKER_GROUP}/intact/test-nexus-upgrade-1:01-SNAPSHOT
echo Create a new image with an existing tag
createDockerfile ${IMAGE_01_DIR}
docker build -t ${DOCKER_GROUP}/intact/test-nexus-upgrade-1:01-SNAPSHOT ${IMAGE_01_DIR}
docker tag ${DOCKER_GROUP}/intact/test-nexus-upgrade-1:01-SNAPSHOT ${DOCKER_IMMUTABLE}/intact/test-nexus-upgrade-1:01-RELEASE
echo Push to IMMUTABLE
docker push ${DOCKER_IMMUTABLE}/intact/test-nexus-upgrade-1:01-RELEASE

echo -e "\n\n Cleanup..."
echo Tests done

rm -rf ${TEST_DIR}
