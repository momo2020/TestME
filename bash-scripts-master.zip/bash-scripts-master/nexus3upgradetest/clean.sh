#!/bin/bash
# CAUTION : USE ON LAB SERVERS ONLY
# Deletes all docker images from the registry. No parameters.
docker images | grep -v IMAGE | awk '{print $3}' | uniq | awk '{print "docker rmi --force "$1}' > cleanimages.sh
chmod +x cleanimages.sh
source cleanimages.sh
rm cleanimages.sh

