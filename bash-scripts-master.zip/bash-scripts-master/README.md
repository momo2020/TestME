# bash-scripts

## nexus2upgradetest

Test suite to execute before and after an upgrade of Nexus Repository Manager 2.

## nexus3upgradetest

Test suite to execute before and after an upgrade of Nexus Repository Manager 3.
