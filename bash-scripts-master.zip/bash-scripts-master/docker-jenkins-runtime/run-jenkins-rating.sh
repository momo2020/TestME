#!/bin/sh
source /tools/jenkins/scripts/version-rating.sh
export JAVA_GC_OPTS="-server -Xms2g -Xmx4g -XX:+UseParallelGC -XX:MaxPermSize=256m -XX:MinHeapFreeRatio=20 -XX:MaxHeapFreeRatio=40 -XX:GCTimeRatio=4 -XX:AdaptiveSizePolicyWeight=90"
docker run -d -p 9443:8443 -l app=jenkins-rating -v /opt/tools/docker/jenkins-rhel-rating:/var/lib/jenkins -v /opt/tools/docker/jenkins-rhel-builds-rating:/var/lib/jenkins-builds -e JAVA_GC_OPTS="${JAVA_GC_OPTS}" -e HTTPS_KEY_STORE_PASSWORD=******* docker-group.iad.ca.inet:8473/intact/jenkins-rhel-base:${JENKINS_IMAGE_VERSION}
