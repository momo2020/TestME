#!/bin/sh
docker rm -vf $(docker ps -f label=app=jenkins-gc -qa)
