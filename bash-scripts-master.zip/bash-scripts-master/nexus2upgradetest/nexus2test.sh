#!/usr/bin/env bash

USERNAME=$1
PASSWORD=$2

if [ -z ${USERNAME} ] || [ -z ${PASSWORD} ]
then
  echo -e "\n USAGE : nexus2test.sh username password"
  echo "         The username and password is for access to Nexus RM 2 and is mandatory"
  exit
fi

# RESULT FILE
WORKDIR=`pwd`
RESULTFILE="${WORKDIR}\resultfile.log"
echo -e "\n OVERALL TEST RESULTS\n ====================\n" > ${RESULTFILE}

# NXRM2 PROD
NXRM2HOSTNAME=prod-nexus-b2eapp.iad.ca.inet ; echo -e "\n THE TEST IS RUN IN NXRM2 PRODUCTION"
NXRM2ENV="_prod"
MVNSETTING=
# NXRM2 PREP
#NXRM2HOSTNAME=stha28a04.iad.ca.inet ; echo -e "\n THE TEST IS RUN IN NXRM2 NON-PROD"
#NXRM2ENV="_prep"
#MVNSETTING="-s ${WORKDIR}/src/resources/settings-prep.xml"

echo -e "\n CLEAN UP MAVEN REPO BEFORE TEST"
ls -al ~/.m2/repository/intact/devtools/intact-parent-pom-git
rm -fr ~/.m2/repository/intact/devtools/intact-parent-pom-git
ls -al ~/.m2/repository/intact/swept/test
rm -fr ~/.m2/repository/intact/swept/test
echo -e "\n DELETE SNAPSHOT ARTIFACT IN NEXUS"
curl -k --request DELETE --user "${USERNAME}:${PASSWORD}" "https://${NXRM2HOSTNAME}:8443/nexus/service/local/repositories/snapshots/content/intact/swept/test/nexus2upgradetestsnapshot"
echo -e "\n DELETE RELEASE ARTIFACT IN NEXUS"
curl -k --request DELETE --user "${USERNAME}:${PASSWORD}" "https://${NXRM2HOSTNAME}:8443/nexus/service/local/repositories/releases/content/intact/swept/test/nexus2upgradetestrelease/0.0.0.0"

echo -e "\n TEST CASE 1 - DOWNLOAD PARENT POM SNAPSHOT"
cd nexus2upgradetestsnapshot
mvn -U clean ${MVNSETTING}
ls -al ~/.m2/repository/intact/devtools/intact-parent-pom-git/1.3.32-SNAPSHOT
if [ $? -eq 0 ]
then
  echo -e "\n TEST CASE 1 - PASS" >> ${RESULTFILE}
else
  echo -e "\n TEST CASE 1 - DOWNLOAD OF SNAPSHOT PARENT POM FAILED!!!" >> ${RESULTFILE}
fi

echo -e "\n TEST CASE 2 - UPLOAD SNAPSHOT "
mvn clean deploy ${MVNSETTING}
curl -k --request GET --user "${USERNAME}:${PASSWORD}" "https://${NXRM2HOSTNAME}:8443/nexus/service/local/artifact/maven/resolve?r=snapshots&g=intact.swept.test&a=nexus2upgradetestsnapshot&v=0.0.0.0-SNAPSHOT&c=&e=pom&isLocal=true" -o target/output.xml
VERSION=`grep version target/output.xml | sed 's/<\/\?version>//g' | sed -e 's/^[ \t]*//'`
BASEVERSION=`grep baseVersion target/output.xml | sed 's/<\/\?baseVersion>//g' | sed -e 's/^[ \t]*//'`
if [ ${VERSION} != ${BASEVERSION} ]
then
  echo -e "\n TEST CASE 2 - PASS" >> ${RESULTFILE}
else
  echo -e "\n TEST CASE 2 - UPLOAD OF ARTIFACT intact.swept.test:nexus2upgradetestsnapshot:0.0.0.0-SNAPSHOT FAILED!!!" >> ${RESULTFILE}
fi

echo -e "\n TEST CASE 3 - DOWNLOAD A RELEASE PARENT POM"
cd ../nexus2upgradetestrelease
mvn clean ${MVNSETTING}
ls -al ~/.m2/repository/intact/devtools/intact-parent-pom-git/1.3.34
if [ $? -eq 0 ]
then
  echo -e "\n TEST CASE 3 - PASS" >> ${RESULTFILE}
else
  echo -e "\n TEST CASE 3 - DOWNLOAD OF RELEASE PARENT POM FAILED!!!" >> ${RESULTFILE}
fi

echo -e "\n TEST CASE 4 - UPLOAD A RELEASE THAT DOESNT EXIST IN NEXUS"
mvn deploy ${MVNSETTING}
curl -k --request GET --user "${USERNAME}:${PASSWORD}" "https://${NXRM2HOSTNAME}:8443/nexus/service/local/repositories/releases/content/intact/swept/test/nexus2upgradetestrelease/0.0.0.0/nexus2upgradetestrelease-0.0.0.0.jar?describe=info&isLocal=true&" -o target/output.xml
PRESENTLOCALLY=`grep presentLocally target/output.xml | sed 's/<\/\?presentLocally>//g' | sed -e 's/^[ \t]*//'`
if [ ${PRESENTLOCALLY} == "true" ]
then
  echo -e "\n TEST CASE 4 - PASS" >> ${RESULTFILE}
else
  echo -e "\n TEST CASE 4 - UPLOAD OF ARTIFACT intact.swept.test:nexus2upgradetestrelease:0.0.0.0 FAILED!!!" >> ${RESULTFILE}
fi

echo -e "\n TEST CASE 5 - UPLOAD A RELEASE THAT EXISTS (NEXUS RETURNS CODE 400 - BAD REQUEST)"
mvn deploy ${MVNSETTING} 1>target/output.log 2>&1
grep "Return code is: 400" target/output.log
if [ $? -eq 0 ]
then
  echo -e "\n TEST CASE 5 - PASS" >> ${RESULTFILE}
else
  echo -e "\n TEST CASE 5 - UPLOAD OF ALREADY EXISANT RELEASE DIDN'T GIVE A RETURN CODE OF 400!!!" >> ${RESULTFILE}
fi

echo -e "\n TEST CASE 6 - PROCUREMENT PLUGIN"
cd ../nexus2upgradetestprocure
curl -k --request DELETE --user "${USERNAME}:${PASSWORD}" "https://${NXRM2HOSTNAME}:8443/nexus/service/local/repositories/central/content/com/sun/jersey/samples/helloworld/1.2/helloworld-1.2.jar"
ls -al ~/.m2/repository/com/sun/jersey/samples/helloworld/
rm -fr ~/.m2/repository/com/sun/jersey/samples/helloworld/
curl -k --request GET --user "${USERNAME}:${PASSWORD}" "https://${NXRM2HOSTNAME}:8443/nexus/service/local/repositories/central/content/com/sun/jersey/samples/helloworld/1.2/helloworld-1.2.jar?describe=info&isLocal=true" -o target/tc6beforeresult.xml
ls  target/tc6beforeresult.xml
TC6RESULTBEFORE=$?
mvn clean ${MVNSETTING}
echo "y" | mvn procurement:procure -s settings_for_dep${NXRM2ENV}.xml
mvn dependency:copy-dependencies ${MVNSETTING}
curl -k --request GET --user "${USERNAME}:${PASSWORD}" "https://${NXRM2HOSTNAME}:8443/nexus/service/local/repositories/central/content/com/sun/jersey/samples/helloworld/1.2/helloworld-1.2.jar?describe=info&isLocal=true" -o target/tc6afterresult.xml
PRESENTLOCALLY=`grep presentLocally target/tc6afterresult.xml | sed 's/<\/\?presentLocally>//g' | sed -e 's/^[ \t]*//'`
if [ ${TC6RESULTBEFORE} -eq 2 ] || [ ${PRESENTLOCALLY} == "true" ]
then
  echo -e "\n TEST CASE 6 - PASS" >> ${RESULTFILE}
else
  echo -e "\n TEST CASE 6 - PROCUREMENT PLUGIN FAILED!!!" >> ${RESULTFILE}
fi

echo -e "\n TEST CASE 7 - PROCUREMENT THROUGH CURL COMMAND"
curl -k --request DELETE --user "${USERNAME}:${PASSWORD}" "https://${NXRM2HOSTNAME}:8443/nexus/service/local/repositories/central/content/com/sun/jersey/samples/helloworld/1.2/helloworld-1.3.jar"
ls -al ~/.m2/repository/com/sun/jersey/samples/helloworld/
rm -fr ~/.m2/repository/com/sun/jersey/samples/helloworld/
curl -k --request GET --user "${USERNAME}:${PASSWORD}" "https://${NXRM2HOSTNAME}:8443/nexus/service/local/repositories/central/content/com/sun/jersey/samples/helloworld/1.2/helloworld-1.2.jar?describe=info&isLocal=true" -o target/tc7beforeresult.xml
ls  target/tc7beforeresult.xml
TC7RESULTBEFORE=$?
mvn dependency:copy-dependencies ${MVNSETTING}
curl -k --request GET --user "${USERNAME}:${PASSWORD}" "https://${NXRM2HOSTNAME}:8443/nexus/service/local/repositories/central/content/com/sun/jersey/samples/helloworld/1.2/helloworld-1.2.jar?describe=info&isLocal=true" -o target/tc7afterresult.xml
PRESENTLOCALLY=`grep presentLocally target/tc7afterresult.xml | sed 's/<\/\?presentLocally>//g' | sed -e 's/^[ \t]*//'`
if [ ${TC7RESULTBEFORE} -eq 2 ] || [ ${PRESENTLOCALLY} == "true" ]
then
  echo -e "\n TEST CASE 7 - PASS" >> ${RESULTFILE}
else
  echo -e "\n TEST CASE 7 - PROCUREMENT THROUGH CURL COMMAND FAILED!!!" >> ${RESULTFILE}
fi

cat ${RESULTFILE}
