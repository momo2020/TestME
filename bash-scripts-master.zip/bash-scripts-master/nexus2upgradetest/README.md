# Nexus Repository Manager 2 upgrade test

This project is used for testing during the Nexus Repository Manager 2 upgrades. There are seven tests cases and a report is sent to standard output at the end.

## Requirements

1. Maven 3.3.9
2. Bash (GitBash or Linux based)

## Test-cases

1. Download artifact from snapshot repository
2. Upload artifact to snapshot repository
3. Download artifact from release repository
4. Upload a new artifact to release repository
5. Upload an existing artifact to release repository
6. Get an artifact from Maven Central using the Maven procurement plugin
7. Get an artifact from Maven Central using NXRM2 REST API

## Steps

### Clone this repository
```$xslt
git clone https://githubifc.iad.ca.inet/DevTools/bash-scripts.git
```

### Comment/Uncomment section for PREP/PROD
In file nexus2test.sh, comment/uncomment the section corresponding to NXRM2 PREP or PROD.
```
# NXRM2 PROD
...
# NXRM2 PREP
...
```

### Launch tests
Launch the following command. The username and password is mandatory. 
```$xslt
cd nexus2upgradetest
./nexus2tests.sh username password
```
 
### Check report
A report is sent to standard output. If a test fails, the test case number and it's purpose appears.
