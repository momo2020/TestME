package intact.swept;

public class App
{
    public static void main( String[] args )
    {
        System.out.println( "Nexus 2 upgrade test suite." );
    }
}
