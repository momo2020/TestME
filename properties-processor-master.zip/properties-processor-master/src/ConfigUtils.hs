module ConfigUtils where

import Control.Monad
import System.Directory
import System.FilePath
import Data.List
import Data.Maybe

getPaths :: FilePath -> IO [FilePath]
getPaths src = do
  names <- getDirectoryContents src
  let properNames = filter (`notElem` [".", ".."]) names
  paths <- forM properNames $ \name -> do
    let path = src </> name
    isDirectory <- doesDirectoryExist path
    if isDirectory
      then do
           paths <- getPaths path
           return $ path:paths
      else return [path]
  return $ concat paths

filePaths :: FilePath -> IO [FilePath]
filePaths src = do
  paths <- getPaths src
  filterM doesFileExist paths

copyDir :: FilePath -> FilePath -> IO ()
copyDir src dest = do
  getPaths src
  >>= mapM_ (\path -> copy path src dest)

copy :: FilePath -> [Char] -> FilePath -> IO ()
copy path src dest = do
  let relPath = tail $ fromJust $ stripPrefix src path
      target = dest </> relPath
  isDirectory <- doesDirectoryExist path
  if isDirectory
    then createDirectoryIfMissing True target
    else copyFile path target


