module Main where

import Control.Monad
import System.FilePath
import System.Directory
import qualified System.Environment as E (lookupEnv)
import Data.List
import qualified Data.Map as M
import qualified Data.Maybe as B (fromMaybe)
import Text.Regex.Posix
import qualified Data.Text as T

import ConfigUtils

-- Utility function to build the paths we need
configDir r = r </> "etc" </> "config"
defaultPropertiesDir r = configDir r </> "default" </> "properties"
defaultPropertiesMultiDir r = defaultPropertiesDir r  </> "multi"
defaultSinglePropertiesFile r = defaultPropertiesDir r </> "single.properties"
overridePropertiesDir r = configDir r </> "override" </> "properties"
overridePropertiesMultiDir r = overridePropertiesDir r  </> "multi"
overrideSinglePropertiesFile r = overridePropertiesDir r </> "single.properties"
overrideSecretsDir r = configDir r </> "override" </> "secrets"
templates r = configDir r </> "templates" 
processed r = configDir r </> "processed" 

type Key = String
type Value = String
type Content = String

data Property = Property {
  key :: Key,
  value :: Value
  } deriving (Show, Eq, Ord)

toProperty cs = Property key value
  where key   = takeWhile (\c -> c /= '=') cs
        value = tail $ dropWhile (\c -> c /= '=') cs 

toProperties = sort . map toProperty . lines 

readPropertiesFile path = do
  content <- readFile path 
  return $ toProperties content

readPropertiesDir dir = do
  withCurrentDirectory dir f
  where f = do
          keys <- listDirectory dir
          mapM g keys
        g key = do
          value <- readFile key
          return $ Property key value

fromProperties = M.fromList . map (\p -> (key p, value p))

mergePropertyMap = M.unions . map fromProperties

keysFromTemplate content =
  sort $ concat $
  map tail $ ((content :: Content) =~ "\\$\\{([^\\{}]+)\\}" :: [[String]])

process dir mprops = do
  paths <- filePaths dir
  forM_ paths $ \path -> do
    content <- readFile path
    let keys = keysFromTemplate content
    -- print keys
    props <- forM keys $ \key -> do
      let value = mprops M.! key
      return $ Property key value
    let replaced = replaceAll content props
    writeFile path replaced
    
replaceAll cs props = foldr replace cs props
  where replace prop cs =
          let tcs = T.pack cs
              tk  = T.pack $ "${" ++ key prop ++ "}"
              tv  = T.pack $ value prop
          in T.unpack $ T.replace tk tv tcs

main = do
  b <- E.lookupEnv "BASEDIR"
  let r = B.fromMaybe "/home/opicasso/oc-deployment-configs" b 
      pr = processed r
  copyDir (templates r) pr
  ds <- readPropertiesFile $ defaultSinglePropertiesFile r
  dm <- readPropertiesDir $ defaultPropertiesMultiDir r
  os <- readPropertiesFile $ overrideSinglePropertiesFile r
  om <- readPropertiesDir $ overridePropertiesMultiDir r
  ot <- readPropertiesDir $ overrideSecretsDir r
  let mprops = mergePropertyMap [ot, os, om, ds, dm]
  process pr mprops
  copyDir pr r
  