# properties-processor
Process properties for use in Docker container
