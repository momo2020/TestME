/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance
* Copyright (c) 2015, Intact Insurance, All rights reserved.<br>
*/
package com.intact.raa.domain.authentication;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.intact.raa.annotation.CaseSensitive;

/**
 * The Class ClientRegistrationEvent.
 *
 */
@Entity
@Table(name = "CLIENT_REG_EVENTS", schema="RAAADMIN")
@NamedQueries({
	@NamedQuery(name = "ClientRegistrationEvent.findResetPasswordAttempts" , 
		query = "select cre from ClientRegistrationEvent cre where cre.authentication = :authentication" +
			" and cre.eventDateTime > :startDate and cre.deleteDateTime is null" +
			" and cre.eventType = 'RESET_PWD'") ,
	@NamedQuery(name = "ClientRegistrationEvent.findRegisterAttempts" , 
		query = "select cre from ClientRegistrationEvent cre where cre.cliClient = :cliClient" +
			" and cre.eventDateTime > :startDate and cre.deleteDateTime is null" +
			" and cre.eventType in ('FAIL_FIND_BY_POL', 'FAIL_POL_VERIF', 'FAIL_DRIV_LIC_VERIF', 'FAIL_SMS_VERIF')") ,
	@NamedQuery(name = "ClientRegistrationEvent.findAlive" , 
		query = "select cre from ClientRegistrationEvent cre where (cre.cliClient = :cliClient" +
			" or cre.authentication = :authentication) and (cre.deleteDateTime is null" +
			" or cre.deleteDateTime > CURRENT_DATE)") ,
	@NamedQuery(name = "ClientRegistrationEvent.findByAuthentication" , 
		query = "select cre from ClientRegistrationEvent cre where cre.authentication = :authentication") ,
	@NamedQuery(name = "ClientRegistrationEvent.findByCliClient" , 
		query = "select cre from ClientRegistrationEvent cre where cre.cliClient = :cliClient") 
})
public class ClientRegistrationEvent {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="CLI_REG_EVENTS_SEQ")
    @SequenceGenerator(name="CLI_REG_EVENTS_SEQ", sequenceName="CLIENT_REG_EVENTS_SEQ", allocationSize=1,initialValue=1)
	@Column(name = "CLIENT_REG_EVENT_ID")
	private Long clientRegEventId;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "EVENT_TYPE")
	private EventType eventType;
	
	@Column(name = "EVENT_DATE_TIME")
	private Date eventDateTime;
	
	@Column(name = "DELETE_DATE_TIME")
	private Date deleteDateTime;
	
	@CaseSensitive
	@Column(name = "ANONYMOUS_TOKEN")
	private String anonymousToken;
	
	@Column(name = "CLI_CLIENT")
	private Long cliClient;
	
	@ManyToOne
	@JoinColumn(name = "AUTHENTICATION_ID")
	private Authentication authentication;

	/**
	 * Gets the client reg event id.
	 *
	 * @return the client reg event id
	 */
	public Long getClientRegEventId() {
		return clientRegEventId;
	}

	/**
	 * Sets the client reg event id.
	 *
	 * @param clientRegEventId the new client reg event id
	 */
	public void setClientRegEventId(Long clientRegEventId) {
		this.clientRegEventId = clientRegEventId;
	}

	/**
	 * Gets the event type.
	 *
	 * @return the event type
	 */
	public EventType getEventType() {
		return eventType;
	}

	/**
	 * Sets the event type.
	 *
	 * @param eventType the new event type
	 */
	public void setEventType(EventType eventType) {
		this.eventType = eventType;
	}

	/**
	 * Gets the event date time.
	 *
	 * @return the event date time
	 */
	public Date getEventDateTime() {
		return eventDateTime;
	}

	/**
	 * Sets the event date time.
	 *
	 * @param eventDateTime the new event date time
	 */
	public void setEventDateTime(Date eventDateTime) {
		this.eventDateTime = eventDateTime;
	}

	/**
	 * Gets the delete date time.
	 *
	 * @return the delete date time
	 */
	public Date getDeleteDateTime() {
		return deleteDateTime;
	}

	/**
	 * Sets the delete date time.
	 *
	 * @param deleteDateTime the new delete date time
	 */
	public void setDeleteDateTime(Date deleteDateTime) {
		this.deleteDateTime = deleteDateTime;
	}

	/**
	 * Gets the anonymous token.
	 *
	 * @return the anonymous token
	 */
	public String getAnonymousToken() {
		return anonymousToken;
	}

	/**
	 * Sets the anonymous token.
	 *
	 * @param anonymousToken the new anonymous token
	 */
	public void setAnonymousToken(String anonymousToken) {
		this.anonymousToken = anonymousToken;
	}

	/**
	 * Gets the cli client.
	 *
	 * @return the cli client
	 */
	public Long getCliClient() {
		return cliClient;
	}

	/**
	 * Sets the cli client.
	 *
	 * @param cliClient the new cli client
	 */
	public void setCliClient(Long cliClient) {
		this.cliClient = cliClient;
	}

	/**
	 * Gets the authentication.
	 *
	 * @return the authentication
	 */
	public Authentication getAuthentication() {
		return authentication;
	}

	/**
	 * Sets the authentication.
	 *
	 * @param authentication the new authentication
	 */
	public void setAuthentication(Authentication authentication) {
		this.authentication = authentication;
	}
	
	/**
	 * The Enum EventType.
	 *
	 */
	public static enum EventType {
		RESET_PWD,
		FAIL_FIND_BY_POL,
		FAIL_POL_VERIF,
		FAIL_DRIV_LIC_VERIF,
		FAIL_SMS_VERIF;
	}
	
}
