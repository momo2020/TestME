/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance
* Copyright (c) 2015, Intact Insurance, All rights reserved.<br>
*/
package com.intact.raa.domain.authentication;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.intact.raa.annotation.CaseSensitive;


/**
 * The Class AuthenticationCookie.
 *
 */
@Entity
@Table(name = "AUTHENTICATION_COOKIES", schema="RAAADMIN")
@NamedQueries({
	@NamedQuery(name = "AuthenticationCookie.findByAuthenticationCookieUuId" , query = "select ac from AuthenticationCookie ac where ac.authenticationCookieUuId = :authenticationCookieUuId and ac.endDate > CURRENT_DATE") ,
	@NamedQuery(name = "AuthenticationCookie.findByAuthentication" , query = "select ac from AuthenticationCookie ac where ac.authentication = :authentication") 
})
public class AuthenticationCookie {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="AUTH_COOKIE_SEQ")
    @SequenceGenerator(name="AUTH_COOKIE_SEQ", sequenceName="AUTHENTICATION_COOKIES_SEQ", allocationSize=1,initialValue=1)
	@Column(name = "AUTHENTICATION_COOKIE_ID")
	private Long authenticationCookieId;
	
	@Column(name = "CREATION_DATE_TIME")
	private Date creationDateTime;
	
	@CaseSensitive
	@Column(name = "AUTHENTICATION_COOKIE_UU_ID")
	private String authenticationCookieUuId;
	
	@Column(name = "AUTHENTICATION_TYPE")
	private String authenticationType;
	
	@CaseSensitive
	@Column(name = "LAST_NAME")
	private String lastName;
	
	@CaseSensitive
	@Column(name = "FIRST_NAME")
	private String firstName;
	
	@CaseSensitive
	@Column(name = "ORGANIZATION_NAME")
	private String organizationName;
	
	@Column(name = "BIRTH_DATE")
	private Date birthDate;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "MAIL_TYPE_CODE")
	private MailTypeCode mailTypeCode;
	
	@Column(name = "MAIL_CODE")
	private String mailCode;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "AGREEMENT_TYPE")
	private AggrementType agreementType;
	
	@Column(name = "AGREEMENT_NUMBER")
	private String agreementNumber;
	
	@Column(name = "END_DATE")
	private Date endDate;
	
	@ManyToOne
	@JoinColumn(name = "AUTHENTICATION_ID")
	private Authentication authentication;

	/**
	 * Gets the authentication cookie id.
	 *
	 * @return the authentication cookie id
	 */
	public Long getAuthenticationCookieId() {
		return authenticationCookieId;
	}

	/**
	 * Sets the authentication cookie id.
	 *
	 * @param authenticationCookieId the new authentication cookie id
	 */
	public void setAuthenticationCookieId(Long authenticationCookieId) {
		this.authenticationCookieId = authenticationCookieId;
	}

	/**
	 * Gets the creation date time.
	 *
	 * @return the creation date time
	 */
	public Date getCreationDateTime() {
		return creationDateTime;
	}

	/**
	 * Sets the creation date time.
	 *
	 * @param creationDateTime the new creation date time
	 */
	public void setCreationDateTime(Date creationDateTime) {
		this.creationDateTime = creationDateTime;
	}

	/**
	 * Gets the authentication cookie uu id.
	 *
	 * @return the authentication cookie uu id
	 */
	public String getAuthenticationCookieUuId() {
		return authenticationCookieUuId;
	}

	/**
	 * Sets the authentication cookie uu id.
	 *
	 * @param authenticationCookieUuId the new authentication cookie uu id
	 */
	public void setAuthenticationCookieUuId(String authenticationCookieUuId) {
		this.authenticationCookieUuId = authenticationCookieUuId;
	}

	/**
	 * Gets the authentication type.
	 *
	 * @return the authentication type
	 */
	public AuthenticationType getAuthenticationType() {
		return AuthenticationType.fromCode(this.authenticationType);
	}

	/**
	 * Sets the authentication type.
	 *
	 * @param authenticationType the new authentication type
	 */
	public void setAuthenticationType(AuthenticationType authenticationType) {
		this.authenticationType = authenticationType.toCode();
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets the organization name.
	 *
	 * @return the organization name
	 */
	public String getOrganizationName() {
		return organizationName;
	}

	/**
	 * Sets the organization name.
	 *
	 * @param organizationName the new organization name
	 */
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	/**
	 * Gets the birth date.
	 *
	 * @return the birth date
	 */
	public Date getBirthDate() {
		return birthDate;
	}

	/**
	 * Sets the birth date.
	 *
	 * @param birthDate the new birth date
	 */
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * Gets the mail type code.
	 *
	 * @return the mail type code
	 */
	public MailTypeCode getMailTypeCode() {
		return mailTypeCode;
	}

	/**
	 * Sets the mail type code.
	 *
	 * @param mailTypeCode the new mail type code
	 */
	public void setMailTypeCode(MailTypeCode mailTypeCode) {
		this.mailTypeCode = mailTypeCode;
	}

	/**
	 * Gets the mail code.
	 *
	 * @return the mail code
	 */
	public String getMailCode() {
		return mailCode;
	}

	/**
	 * Sets the mail code.
	 *
	 * @param mailCode the new mail code
	 */
	public void setMailCode(String mailCode) {
		this.mailCode = mailCode;
	}

	/**
	 * Gets the agreement type.
	 *
	 * @return the agreement type
	 */
	public AggrementType getAgreementType() {
		return agreementType;
	}

	/**
	 * Sets the agreement type.
	 *
	 * @param agreementType the new agreement type
	 */
	public void setAgreementType(AggrementType agreementType) {
		this.agreementType = agreementType;
	}

	/**
	 * Gets the agreement number.
	 *
	 * @return the agreement number
	 */
	public String getAgreementNumber() {
		return agreementNumber;
	}

	/**
	 * Sets the agreement number.
	 *
	 * @param agreementNumber the new agreement number
	 */
	public void setAgreementNumber(String agreementNumber) {
		this.agreementNumber = agreementNumber;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * Sets the end date.
	 *
	 * @param endDate the new end date
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * Gets the authentication.
	 *
	 * @return the authentication
	 */
	public Authentication getAuthentication() {
		return authentication;
	}

	/**
	 * Sets the authentication.
	 *
	 * @param authentication the new authentication
	 */
	public void setAuthentication(Authentication authentication) {
		this.authentication = authentication;
	}
	
	/**
	 * The Enum AuthenticationType.
	 *
	 * @author vmathieu
	 */
	public static enum AuthenticationType {

		EMAIL("EMAIL"),
		PERSONAL_INFO("PERS"),
		POLICY_NUMBER("POLNB");
		
		String code;
		
		/**
		 * Instantiates a new authentication type.
		 *
		 * @param code the code
		 */
		AuthenticationType(String code){
			this.code= code;
		}
		
		/**
		 * From code.
		 *
		 * @param code the code
		 * @return the authentication type
		 */
		public static AuthenticationType fromCode(String code){
			for(AuthenticationType e : AuthenticationType.values()) {
				if (e.code.equals(code)) {
					return e;
				}
			}
			throw new RuntimeException("Can not found corresponding EnumType for code [" + code + "]");
		}
		
		/**
		 * To code.
		 *
		 * @return the string
		 */
		public String toCode() {  
			   return this.code;  
			 }
	}
	
	/**
	 * The Enum MailTypeCode.
	 *
	 */
	public static enum MailTypeCode {
		PO,
		ZI,
		OT;
	}
	
	/**
	 * The Enum AggrementType.
	 *
	 */
	public static enum AggrementType {
		CON, 
		QUO, 
		CER, 
		PUR, 
		REL, 
		UPL;
	}
	
}
