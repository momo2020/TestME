/**
 *
 * Copyright � Intact Financial Corporation.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Intact Financial Corporation. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Intact Financial Corporation.
 */

package com.intact.soa.utility.sas.repository.retrieveprofile.controller;

import java.util.List;

import com.intact.bod.bco.party.ISystemAccessor;
import com.intact.soa.utility.sas.repository.exception.SasException;

/**
 * Definition of all the available service methods for the Retrieve System
 * Accessor.
 * 
 */
public interface IRetrieveProfileController {

	ISystemAccessor retrieveSystemAccessorByEmail(String userEmail) throws SasException;

	ISystemAccessor retrieveSystemAccessorByEmailAndUsageType(String userEmail, String usageType) throws SasException;
	
	ISystemAccessor retrieveSystemAccessorByClientId(Long clientId) throws SasException;
	
	List<Long> retrieveClientIdsByAuthenticationId(Long authenticationId);

}