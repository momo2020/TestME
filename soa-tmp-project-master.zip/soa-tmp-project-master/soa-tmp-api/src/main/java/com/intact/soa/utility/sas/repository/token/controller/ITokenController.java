package com.intact.soa.utility.sas.repository.token.controller;

public interface ITokenController {

	String generateSystemAccessorResetToken(Long authenticationId);

	String generateSystemAccessorCreationToken(Long cifId);
	
	String generateSystemAccessorCreationToken(Long cifId, String emailTokenType);
}
