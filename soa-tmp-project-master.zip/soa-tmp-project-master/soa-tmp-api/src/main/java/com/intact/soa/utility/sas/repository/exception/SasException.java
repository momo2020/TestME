package com.intact.soa.utility.sas.repository.exception;

public class SasException extends Exception {
	
	/***/
	private static final long serialVersionUID = -7329234186880959871L;

	public SasException(String pMessage) {
		super(pMessage);
	}

	public SasException(Throwable pCause) {
		super(pCause);
	}

	public SasException(String pMessage, Throwable pCause) {
		super(pMessage, pCause);
	}

}
