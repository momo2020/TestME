/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance
* Copyright (c) 2015, Intact Insurance, All rights reserved.<br>
*/
package com.intact.raa.domain.authentication;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.intact.raa.annotation.CaseSensitive;

/**
 * The Class ClientRegistrationRestriction.
 *
 */
@Entity
@Table(name = "CLIENT_REG_RESTRICTIONS", schema="RAAADMIN")
@NamedQueries({
	@NamedQuery(name = "ClientRegistrationRestriction.findResetPasswordBlock" , 
		query = "select crr from ClientRegistrationRestriction crr where crr.authentication = :authentication and crr.endDate > CURRENT_DATE" +
			" and crr.restrictionType = 'EMAIL_BLOCKED'") ,
	@NamedQuery(name = "ClientRegistrationRestriction.findRegisterBlock" , 
		query = "select crr from ClientRegistrationRestriction crr where crr.cliClient = :cliClient and crr.endDate > CURRENT_DATE" +
			" and crr.restrictionType = 'REG_BLOCKED'") ,
	@NamedQuery(name = "ClientRegistrationRestriction.findAlive" , 
		query = "select crr from ClientRegistrationRestriction crr where (crr.cliClient = :cliClient" +
			" or crr.authentication = :authentication) and (crr.endDate is null or crr.endDate > CURRENT_DATE)") ,
	@NamedQuery(name = "ClientRegistrationRestriction.findByAuthentication" , 
		query = "select crr from ClientRegistrationRestriction crr where crr.authentication = :authentication") ,
	@NamedQuery(name = "ClientRegistrationRestriction.findByCliClient" , 
		query = "select crr from ClientRegistrationRestriction crr where crr.cliClient = :cliClient") 
})
public class ClientRegistrationRestriction {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="CLI_REG_RESTRICTIONS_SEQ")
    @SequenceGenerator(name="CLI_REG_RESTRICTIONS_SEQ", sequenceName="CLIENT_REG_RESTRICTIONS_SEQ", allocationSize=1,initialValue=1)
	@Column(name = "CLIENT_REG_RESTRICTION_ID")
	private Long clientRegRestrictionId;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "RESTRICTION_TYPE")
	private RestrictionType restrictionType;
	
	@Column(name = "START_DATE_TIME")
	private Date startDate;
	
	@Column(name = "END_DATE_TIME")
	private Date endDate;
	
	@CaseSensitive
	@Column(name = "ANONYMOUS_TOKEN")
	private String anonymousToken;
	
	@Column(name = "CLI_CLIENT")
	private Long cliClient;

	@ManyToOne
	@JoinColumn(name = "AUTHENTICATION_ID")
	private Authentication authentication;

	/**
	 * Gets the client reg restriction id.
	 *
	 * @return the client reg restriction id
	 */
	public Long getClientRegRestrictionId() {
		return clientRegRestrictionId;
	}

	/**
	 * Sets the client reg restriction id.
	 *
	 * @param clientRegRestrictionId the new client reg restriction id
	 */
	public void setClientRegRestrictionId(Long clientRegRestrictionId) {
		this.clientRegRestrictionId = clientRegRestrictionId;
	}

	/**
	 * Gets the restriction type.
	 *
	 * @return the restriction type
	 */
	public RestrictionType getRestrictionType() {
		return restrictionType;
	}

	/**
	 * Sets the restriction type.
	 *
	 * @param restrictionType the new restriction type
	 */
	public void setRestrictionType(RestrictionType restrictionType) {
		this.restrictionType = restrictionType;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * Sets the start date.
	 *
	 * @param startDate the new start date
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * Sets the end date.
	 *
	 * @param endDate the new end date
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * Gets the anonymous token.
	 *
	 * @return the anonymous token
	 */
	public String getAnonymousToken() {
		return anonymousToken;
	}

	/**
	 * Sets the anonymous token.
	 *
	 * @param anonymousToken the new anonymous token
	 */
	public void setAnonymousToken(String anonymousToken) {
		this.anonymousToken = anonymousToken;
	}

	/**
	 * Gets the cli client.
	 *
	 * @return the cli client
	 */
	public Long getCliClient() {
		return cliClient;
	}

	/**
	 * Sets the cli client.
	 *
	 * @param cliClient the new cli client
	 */
	public void setCliClient(Long cliClient) {
		this.cliClient = cliClient;
	}
	
	/**
	 * Gets the authentication.
	 *
	 * @return the authentication
	 */
	public Authentication getAuthentication() {
		return authentication;
	}

	/**
	 * Sets the authentication.
	 *
	 * @param authentication the new authentication
	 */
	public void setAuthentication(Authentication authentication) {
		this.authentication = authentication;
	}
	
	/**
	 * The Enum RestrictionType.
	 *
	 */
	public static enum RestrictionType {
		REG_BLOCKED,
		EMAIL_BLOCKED;
	}

}
