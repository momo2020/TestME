/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance
* Copyright (c) 2015, Intact Insurance, All rights reserved.<br>
*/
package com.intact.raa.domain.authentication;

import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.intact.raa.annotation.CaseSensitive;

/**
 * The Class EmailToken.
 *
 */
@Entity
@Table(name = "EMAIL_TOKENS",schema="CIFADMIN")
@NamedQueries({
	@NamedQuery(name = "EmailToken.findValidEmailToken", query = "select et from EmailToken et where et.token = :token and et.eventTriggerCode = :eventTriggerCode"),
	@NamedQuery(name = "EmailToken.findEmailTokens", query = "select et from EmailToken et where et.token = :token and et.eventTriggerCode in :eventTriggerCodes"),
	@NamedQuery(name = "EmailToken.findByAuthenticationAndEventTriggerCode", query = "select et from EmailToken et where et.authentication = :authentication and et.eventTriggerCode = :eventTriggerCode and et.endDateTime > CURRENT_DATE"),
	@NamedQuery(name = "EmailToken.findByAuthentication", query = "select et from EmailToken et where et.authentication = :authentication"),
	@NamedQuery(name = "EmailToken.findByClientId", query = "select et from EmailToken et where et.cliClient = :clientId and et.eventTriggerCode = :eventTriggerCode and et.endDateTime > CURRENT_DATE")
})
public class EmailToken {
	
	public enum EventTriggerCode{
		SUSP_OFFER, SUSP_BIND, RESET_PWD, WELC_EMAIL, EDOC_POL_CAN, EDOC_POL_CHG, EDOC_POL_RNW, EDOC_REPRINT
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="EMAILTOKEN_SEQ")
    @SequenceGenerator(name="EMAILTOKEN_SEQ", sequenceName="CIFADMIN.EMAIL_TOKEN_SEQ", allocationSize=1,initialValue=1)
	@Column(name = "EMAIL_TOKEN")
	private Long emailToken;
	
	@Column(name = "CREATION_DATE_TIME")
	private Date creationDateTime;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "EVENT_TRIGGER_CODE")
	private EventTriggerCode eventTriggerCode;
	
	@CaseSensitive
	@Column(name = "TOKEN")
	private String token;
	
	@ManyToOne
	@JoinColumn(name = "AUTHENTICATION_ID")
	private Authentication authentication;
	
	@Column(name = "START_DATE_TIME")
	private Date startDateTime;

	@Column(name = "END_DATE_TIME")
	private Date endDateTime;

	@Column(name = "CLI_CLIENT")
	private Long cliClient;

	/**
	 * Gets the cli client.
	 *
	 * @return the cli client
	 */
	public Long getCliClient() {
		return cliClient;
	}

	/**
	 * Sets the cli client.
	 *
	 * @param cliClient the new cli client
	 */
	public void setCliClient(Long cliClient) {
		this.cliClient = cliClient;
	}

	/**
	 * Sets the email token.
	 *
	 * @param emailToken the new email token
	 */
	public void setEmailToken(Long emailToken) {
		this.emailToken = emailToken;
	}

	/**
	 * Gets the email token.
	 *
	 * @return the email token
	 */
	public Long getEmailToken() {
		return emailToken;
	}

	/**
	 * Sets the email token.
	 *
	 * @param emailToken the new email token
	 */
	public void setEmailToken(long emailToken) {
		this.emailToken = emailToken;
	}

	/**
	 * Gets the creation date time.
	 *
	 * @return the creation date time
	 */
	public Date getCreationDateTime() {
		return creationDateTime;
	}

	/**
	 * Sets the creation date time.
	 *
	 * @param creationDateTime the new creation date time
	 */
	public void setCreationDateTime(Date creationDateTime) {
		this.creationDateTime = creationDateTime;
	}


	/**
	 * Gets the event trigger code.
	 *
	 * @return the event trigger code
	 */
	public EventTriggerCode getEventTriggerCode() {
		return eventTriggerCode;
	}

	/**
	 * Sets the event trigger code.
	 *
	 * @param eventTriggerCode the new event trigger code
	 */
	public void setEventTriggerCode(EventTriggerCode eventTriggerCode) {
		this.eventTriggerCode = eventTriggerCode;
	}

	/**
	 * Gets the token.
	 *
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * Sets the token.
	 *
	 * @param token the new token
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * Gets the authentication.
	 *
	 * @return the authentication
	 */
	public Authentication getAuthentication() {
		return authentication;
	}

	/**
	 * Sets the authentication.
	 *
	 * @param authentication the new authentication
	 */
	public void setAuthentication(Authentication authentication) {
		this.authentication = authentication;
	}

	/**
	 * Gets the start date time.
	 *
	 * @return the start date time
	 */
	public Date getStartDateTime() {
		return startDateTime;
	}

	/**
	 * Sets the start date time.
	 *
	 * @param startDateTime the new start date time
	 */
	public void setStartDateTime(Date startDateTime) {
		this.startDateTime = startDateTime;
	}

	/**
	 * Gets the end date time.
	 *
	 * @return the end date time
	 */
	public Date getEndDateTime() {
		return endDateTime;
	}

	/**
	 * Sets the end date time.
	 *
	 * @param endDateTime the new end date time
	 */
	public void setEndDateTime(Date endDateTime) {
		this.endDateTime = endDateTime;
	}

	
	public Boolean isExpired() {
		Calendar now = Calendar.getInstance();
		Calendar expiry = Calendar.getInstance();
		expiry.setTime(this.endDateTime);
	
		return now.after(expiry);
	}
	
}
