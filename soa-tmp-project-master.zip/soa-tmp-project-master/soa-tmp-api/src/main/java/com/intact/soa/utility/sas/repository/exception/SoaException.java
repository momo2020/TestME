package com.intact.soa.utility.sas.repository.exception;

public class SoaException extends RuntimeException {
	
	/***/
	private static final long serialVersionUID = -7329234186880959871L;

	public SoaException(String pMessage) {
		super(pMessage);
	}

	public SoaException(Throwable pCause) {
		super(pCause);
	}

	public SoaException(String pMessage, Throwable pCause) {
		super(pMessage, pCause);
	}

}
