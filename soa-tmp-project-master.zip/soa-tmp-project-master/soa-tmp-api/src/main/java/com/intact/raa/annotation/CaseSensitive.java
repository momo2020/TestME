package com.intact.raa.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation to be applied to any RAA field that is case sensitive. All other fields will be transformed to upper-case
 * before save or update by the UppercaseStringInterceptor.
 * 
 * @author Simon Legault
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface CaseSensitive {
	// Nothing to implements
}
