/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance
* Copyright (c) 2015, Intact Insurance, All rights reserved.<br>
*/
package com.intact.raa.domain.authentication;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The Class AuthenticationClientRel.
 *
 */
@Entity
@Table(name = "AUTHENTICATION_CLIENT_REL", schema="RAAADMIN")
@NamedQueries({
	@NamedQuery(name = "AuthenticationClientRel.findByAuthenticationId" , query = "select acr from AuthenticationClientRel acr where acr.authentication.authenticationId = :authenticationId and ( acr.endDate is null or acr.endDate > CURRENT_DATE)") 
})
public class AuthenticationClientRel {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="AUTH_CLIENT_REL_SEQ")
    @SequenceGenerator(name="AUTH_CLIENT_REL_SEQ", sequenceName="AUTHENTICATION_CLIENT_REL_SEQ", allocationSize=1,initialValue=1)
	@Column(name = "AUTHENTICATION_CLIENT_REL_ID")
	private Long authenticationClientRelId;
	
	@Column(name = "CREATION_DATE_TIME")
	private Date creationDateTime = new Date();
	
	@Enumerated(EnumType.STRING)
	@Column(name = "RELATION_MATCH_CRITERIA_TYPE")
	private RelationMatchCriteriaType relationMatchCriteriaType;
	
	@Column(name = "LAST_NAME_CRITERIA")
	private String lastNameCriteria;
	
	@Column(name = "FIRST_NAME_CRITERIA")
	private String firstNameCriteria;
	
	@Column(name = "ORGANIZATION_NAME_CRITERIA")
	private String organizationNameCriteria;
	
	@Column(name = "BIRTH_DATE_CRITERIA")
	private Date birthDateCriteria;
	
	@Column(name = "DRIVER_LICENSE_NBR_CRITERIA")
	private String driverLicenseNbrCriteria;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "MAIL_TYPE_CODE_CRITERIA")
	private MailTypeCodeCriteria mailTypeCodeCriteria;
	
	@Column(name = "MAIL_CODE_CRITERIA")
	private String mailCodeCriteria;
	
	@Column(name = "CIVIC_NO")
	private String civicNo;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "AGREEMENT_TYPE_CRITERIA")
	private AggrementTypeCriteria agreementTypeCriteria;
	
	@Column(name = "AGREEMENT_NUMBER_CRITERIA")
	private String agreementNumberCriteria;
	
	@Column(name = "START_DATE")
	private Date StartDate = new Date();
	
	@Column(name = "END_DATE")
	private Date endDate;
	
	@ManyToOne
	@JoinColumn(name = "AUTHENTICATION_ID")
	private Authentication authentication;
	
	@Column(name = "CLI_CLIENT")
	private Long cliClient;

	/**
	 * Gets the authentication client rel id.
	 *
	 * @return the authentication client rel id
	 */
	public Long getAuthenticationClientRelId() {
		return authenticationClientRelId;
	}

	/**
	 * Sets the authentication client rel id.
	 *
	 * @param authenticationClientRelId the new authentication client rel id
	 */
	public void setAuthenticationClientRelId(Long authenticationClientRelId) {
		this.authenticationClientRelId = authenticationClientRelId;
	}

	/**
	 * Gets the creation date time.
	 *
	 * @return the creation date time
	 */
	public Date getCreationDateTime() {
		return creationDateTime;
	}

	/**
	 * Sets the creation date time.
	 *
	 * @param creationDateTime the new creation date time
	 */
	public void setCreationDateTime(Date creationDateTime) {
		this.creationDateTime = creationDateTime;
	}

	/**
	 * Gets the relation match criteria type.
	 *
	 * @return the relation match criteria type
	 */
	public RelationMatchCriteriaType getRelationMatchCriteriaType() {
		return relationMatchCriteriaType;
	}

	/**
	 * Sets the relation match criteria type.
	 *
	 * @param relationMatchCriteriaType the new relation match criteria type
	 */
	public void setRelationMatchCriteriaType(RelationMatchCriteriaType relationMatchCriteriaType) {
		this.relationMatchCriteriaType = relationMatchCriteriaType;
	}

	/**
	 * Gets the last name criteria.
	 *
	 * @return the last name criteria
	 */
	public String getLastNameCriteria() {
		return lastNameCriteria;
	}

	/**
	 * Sets the last name criteria.
	 *
	 * @param lastNameCriteria the new last name criteria
	 */
	public void setLastNameCriteria(String lastNameCriteria) {
		this.lastNameCriteria = lastNameCriteria;
	}

	/**
	 * Gets the first name criteria.
	 *
	 * @return the first name criteria
	 */
	public String getFirstNameCriteria() {
		return firstNameCriteria;
	}

	/**
	 * Sets the first name criteria.
	 *
	 * @param firstNameCriteria the new first name criteria
	 */
	public void setFirstNameCriteria(String firstNameCriteria) {
		this.firstNameCriteria = firstNameCriteria;
	}

	/**
	 * Gets the organization name criteria.
	 *
	 * @return the organization name criteria
	 */
	public String getOrganizationNameCriteria() {
		return organizationNameCriteria;
	}

	/**
	 * Sets the organization name criteria.
	 *
	 * @param organizationNameCriteria the new organization name criteria
	 */
	public void setOrganizationNameCriteria(String organizationNameCriteria) {
		this.organizationNameCriteria = organizationNameCriteria;
	}

	/**
	 * Gets the birth date criteria.
	 *
	 * @return the birth date criteria
	 */
	public Date getBirthDateCriteria() {
		return birthDateCriteria;
	}

	/**
	 * Sets the birth date criteria.
	 *
	 * @param birthDateCriteria the new birth date criteria
	 */
	public void setBirthDateCriteria(Date birthDateCriteria) {
		this.birthDateCriteria = birthDateCriteria;
	}

	/**
	 * Gets the driver license nbr criteria.
	 *
	 * @return the driver license nbr criteria
	 */
	public String getDriverLicenseNbrCriteria() {
		return driverLicenseNbrCriteria;
	}

	/**
	 * Sets the driver license nbr criteria.
	 *
	 * @param driverLicenseNbrCriteria the new driver license nbr criteria
	 */
	public void setDriverLicenseNbrCriteria(String driverLicenseNbrCriteria) {
		this.driverLicenseNbrCriteria = driverLicenseNbrCriteria;
	}

	/**
	 * Gets the mail type code criteria.
	 *
	 * @return the mail type code criteria
	 */
	public MailTypeCodeCriteria getMailTypeCodeCriteria() {
		return mailTypeCodeCriteria;
	}

	/**
	 * Sets the mail type code criteria.
	 *
	 * @param mailTypeCodeCriteria the new mail type code criteria
	 */
	public void setMailTypeCodeCriteria(MailTypeCodeCriteria mailTypeCodeCriteria) {
		this.mailTypeCodeCriteria = mailTypeCodeCriteria;
	}

	/**
	 * Gets the mail code criteria.
	 *
	 * @return the mail code criteria
	 */
	public String getMailCodeCriteria() {
		return mailCodeCriteria;
	}

	/**
	 * Sets the mail code criteria.
	 *
	 * @param mailCodeCriteria the new mail code criteria
	 */
	public void setMailCodeCriteria(String mailCodeCriteria) {
		this.mailCodeCriteria = mailCodeCriteria;
	}

	/**
	 * Gets the civic no.
	 *
	 * @return the civic no
	 */
	public String getCivicNo() {
		return civicNo;
	}

	/**
	 * Sets the civic no.
	 *
	 * @param civicNo the new civic no
	 */
	public void setCivicNo(String civicNo) {
		this.civicNo = civicNo;
	}

	/**
	 * Gets the agreement type criteria.
	 *
	 * @return the agreement type criteria
	 */
	public AggrementTypeCriteria getAgreementTypeCriteria() {
		return agreementTypeCriteria;
	}

	/**
	 * Sets the agreement type criteria.
	 *
	 * @param agreementTypeCriteria the new agreement type criteria
	 */
	public void setAgreementTypeCriteria(AggrementTypeCriteria agreementTypeCriteria) {
		this.agreementTypeCriteria = agreementTypeCriteria;
	}

	/**
	 * Gets the agreement number criteria.
	 *
	 * @return the agreement number criteria
	 */
	public String getAgreementNumberCriteria() {
		return agreementNumberCriteria;
	}

	/**
	 * Sets the agreement number criteria.
	 *
	 * @param agreementNumberCriteria the new agreement number criteria
	 */
	public void setAgreementNumberCriteria(String agreementNumberCriteria) {
		this.agreementNumberCriteria = agreementNumberCriteria;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public Date getStartDate() {
		return StartDate;
	}

	/**
	 * Sets the start date.
	 *
	 * @param startDate the new start date
	 */
	public void setStartDate(Date startDate) {
		StartDate = startDate;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * Sets the end date.
	 *
	 * @param endDate the new end date
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * Gets the authentication.
	 *
	 * @return the authentication
	 */
	public Authentication getAuthentication() {
		return authentication;
	}

	/**
	 * Sets the authentication.
	 *
	 * @param authentication the new authentication
	 */
	public void setAuthentication(Authentication authentication) {
		this.authentication = authentication;
	}

	/**
	 * Gets the cli client.
	 *
	 * @return the cli client
	 */
	public Long getCliClient() {
		return cliClient;
	}

	/**
	 * Sets the cli client.
	 *
	 * @param cliClient the new cli client
	 */
	public void setCliClient(Long cliClient) {
		this.cliClient = cliClient;
	}
	
	/**
	 * The Enum MailTypeCodeCriteria.
	 *
	 */
	public static enum MailTypeCodeCriteria {
		PO,
		ZI,
		OT;
	}
	
	/**
	 * The Enum AggrementTypeCriteria.
	 *
	 */
	public static enum AggrementTypeCriteria {
		CON, 
		QUO, 
		CER, 
		PUR, 
		REL, 
		UPL;
	}

	/**
	 * The Enum RelationMatchCriteriaType.
	 *
	 */
	public static enum RelationMatchCriteriaType {
		EMAIL_POL, 
		EMAIL_DL, 
		PERS_POL, 
		PERS_DL, 
		POL_DOB_POST_CV, 
		POL_DOB_DL,
		CLIENT_ID;
	}
	
	
}
