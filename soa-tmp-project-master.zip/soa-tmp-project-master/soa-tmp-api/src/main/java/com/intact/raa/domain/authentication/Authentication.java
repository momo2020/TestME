/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance
* Copyright (c) 2015, Intact Insurance, All rights reserved.<br>
*/
package com.intact.raa.domain.authentication;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;


/**
 * The Class Authentication.
 *
 */
@Entity
@Table(name = "AUTHENTICATIONS", schema="RAAADMIN")
@NamedQueries({
	@NamedQuery(name = "Authentication.findByEmailAddressIgnoreCase", query = "select au from Authentication au where upper(au.emailAddress) = upper(:emailAddress) and (au.endDate is null or au.endDate > CURRENT_DATE)"),
	@NamedQuery(name = "Authentication.findByEmailAddressAndUsageTypeIgnoreCase", query = "select au from Authentication au where upper(au.emailAddress) = upper(:emailAddress) and upper(au.usageType) = upper(:usageType) and (au.endDate is null or au.endDate > CURRENT_DATE)"),
	@NamedQuery(name = "Authentication.findByClientId", query = "select acr.authentication from AuthenticationClientRel acr where acr.cliClient = :cliClient and (acr.endDate is null or acr.endDate > CURRENT_DATE) and (acr.authentication.endDate is null or acr.authentication.endDate > CURRENT_DATE)"),
	@NamedQuery(name = "Authentication.findOne" , query="select au from Authentication au where au.authenticationId = :id and ( au.endDate is null or au.endDate > CURRENT_DATE)")
})
public class Authentication {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="AUTH_SEQ")
    @SequenceGenerator(name="AUTH_SEQ", sequenceName="AUTHENTICATIONS_SEQ", allocationSize=1,initialValue=1)
	@Column(name = "AUTHENTICATION_ID")
	private Long authenticationId;
	
	@Column(name = "CREATION_DATE_TIME")
	private Date creationDateTime = new Date();
	
	@Column(name = "USAGE_TYPE")
	private String usageType;
	
	@Column(name = "EMAIL_ADDRESS")
	private String emailAddress;
	
	@Column(name = "START_DATE")
	private Date startDate = new Date();
	
	@Column(name = "END_DATE")
	private Date endDate;

	
	/**
	 * Gets the authentication id.
	 *
	 * @return the authentication id
	 */
	public Long getAuthenticationId() {
		return authenticationId;
	}

	/**
	 * Sets the authentication id.
	 *
	 * @param authenticationId the new authentication id
	 */
	public void setAuthenticationId(Long authenticationId) {
		this.authenticationId = authenticationId;
	}

	/**
	 * Gets the creation date time.
	 *
	 * @return the creation date time
	 */
	public Date getCreationDateTime() {
		return creationDateTime;
	}

	/**
	 * Sets the creation date time.
	 *
	 * @param creationDateTime the new creation date time
	 */
	public void setCreationDateTime(Date creationDateTime) {
		this.creationDateTime = creationDateTime;
	}

	/**
	 * Gets the usage type.
	 *
	 * @return the usage type
	 */
	/*
	 * the corresponding mapping in data base is USAGE_TYPE witch is a String, in JPA2.0 there is no support for @Converter. so W deal with fromCode toCode. don't remove @Transient.
	 * 
	 */
	@Transient
	public UsageType getUsageType() {
		return UsageType.fromCode(this.usageType);
	}

	/**
	 * Sets the usage type.
	 *
	 * @param usageType the new usage type
	 */
	public void setUsageType(UsageType usageType) {
		this.usageType = usageType.toCode();
	}
		
	/**
	 * Gets the email address.
	 *
	 * @return the email address
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * Sets the email address.
	 *
	 * @param emailAddress the new email address
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * Sets the start date.
	 *
	 * @param startDate the new start date
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * Sets the end date.
	 *
	 * @param endDate the new end date
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	
	/**
	 * The Enum UsageType.
	 *
	 * @author vmathieu
	 */
	public static enum UsageType {
		BELAIR("DTCD"),
		INTACT("BRKDIST"),
		BANQUE_NATIONALE_ASSURANCES("DTCDBNA");
		
		private String code;
		
		/**
		 * Instantiates a new usage type.
		 *
		 * @param code the code
		 */
		UsageType(String code) {
			this.code = code;
		}

		/**
		 * Gets the code.
		 *
		 * @return the code
		 */
		public String getCode() {
			return code;
		}

		/**
		 * Sets the code.
		 *
		 * @param code the new code
		 */
		public void setCode(String code) {
			this.code = code;
		}
		
		/**
		 * From code.
		 *
		 * @param code the code
		 * @return the usage type
		 */
		public static UsageType fromCode(String code){
			for(UsageType e : UsageType.values()) {
				if (e.code.equals(code)) {
					return e;
				}
			}
			throw new RuntimeException("Can not found corresponding EnumType for code [" + code + "]");
		}
		
		/**
		 * To code.
		 *
		 * @return the string
		 */
		public String toCode() {  
			   return this.code;  
			 }
		
		
	}

}
