# soa-tmp-project
SOA-TMP project - a permanent temporary SOA project

TODO document README.md

## Built With

 * https://prod-jenkins-2020.iad.ca.inet/job/Digital/job/common_libs/job/BUILD_DAY_commons.service.soatmp.soatmp-project_MASTER_DEF/
 * https://prod-jenkins-2020.iad.ca.inet/job/Intact/job/soa-tmp-project/
