package com.intact.soa.raa.authentication.service;

import static org.junit.Assert.assertEquals;

import com.ing.canada.singleid.accessmanager.domain.User;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.ing.canada.singleid.accessmanager.domain.SecureDomain;
import com.ing.canada.singleid.accessmanager.exception.AccessManagerException;
import com.ing.canada.singleid.accessmanager.service.IUserAccountService;
import com.intact.bod.bco.party.impl.SystemAccessor;
import com.intact.soa.raa.authentication.service.impl.AccessManagerBean;
import com.intact.soa.raa.authentication.service.impl.ModifySystemAccessorServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class ModifySystemAccessorServiceImplTest {

	public static final String USERNAME = "test@test.com";

	public static final String PASSWORD = "password";

	@InjectMocks
	private ModifySystemAccessorServiceImpl modifySystemAccessorServiceImpl;
	
	@Mock
	private SystemAccessor systemAccessor;
	@Mock
	private MockAccessManagerBean mockAccessManagerBean;
	@Mock
	private IUserAccountService userAccountService;
	@Mock
	private IAuthenticationService authenticationService;
	@Mock
	private IAuthenticationClientRelService authenticationClientRelService;
	
	@Before
	public void setUp() {
		mockAccessManagerBean = new MockAccessManagerBean();
		mockAccessManagerBean.setUserAccountService(userAccountService);
		modifySystemAccessorServiceImpl = new ModifySystemAccessorServiceImpl(authenticationService, authenticationClientRelService, SecureDomain.DEFAULT , mockAccessManagerBean);
	}

	@Test
	public void testValidateCurrentPassword_WhenTrue() throws Exception {
		Mockito.when(userAccountService.authenticate(Mockito.any(SecureDomain.class), Mockito.anyString(), Mockito.anyString())).thenReturn(IUserAccountService.AUTH_SUCCESS);
		int result = modifySystemAccessorServiceImpl.validateCurrentPassword(systemAccessor, PASSWORD);
		assertEquals(result,IUserAccountService.AUTH_SUCCESS);
	}

	@Test(expected = AccessManagerException.class)
	public void testValidateCurrentPassword_WhenAccessManagerException() throws Exception {
		Mockito.when(userAccountService.authenticate(Mockito.any(SecureDomain.class), Mockito.anyString(), Mockito.anyString())).thenThrow(new AccessManagerException());
		modifySystemAccessorServiceImpl.validateCurrentPassword(systemAccessor, PASSWORD);
	}

	@Test
	public void testValidateCurrentPassword_WhenAccountLocked() throws Exception {
		Mockito.when(userAccountService.authenticate(Mockito.any(SecureDomain.class), Mockito.anyString(), Mockito.anyString())).thenReturn(IUserAccountService.AUTH_LOCKED);
		int result = modifySystemAccessorServiceImpl.validateCurrentPassword(systemAccessor, PASSWORD);
		assertEquals(result, IUserAccountService.AUTH_LOCKED);
	}

	@Test
	public void testValidateCurrentPassword_WhenAccountLockedAfterMaxAttempts() throws Exception {
		Mockito.when(userAccountService.authenticate(Mockito.any(SecureDomain.class), Mockito.anyString(), Mockito.anyString())).thenReturn(IUserAccountService.AUTH_FAILED);
		User user = new User();
		user.setValidationAttempNb(2);
		Mockito.when(userAccountService.getUser(Mockito.any(SecureDomain.class), Mockito.anyString())).thenReturn(user);
		int result = modifySystemAccessorServiceImpl.validateCurrentPassword(systemAccessor, PASSWORD);
		assertEquals(user.getValidationAttempNb(), 0);
		assertEquals(result, IUserAccountService.AUTH_LOCKED);
	}

	@Test
	public void testValidateCurrentPassword_WhenAuthenticationFailed() throws Exception {
		Mockito.when(userAccountService.authenticate(Mockito.any(SecureDomain.class), Mockito.anyString(), Mockito.anyString())).thenReturn(IUserAccountService.AUTH_FAILED);
		User user = new User();
		user.setValidationAttempNb(1);
		Mockito.when(userAccountService.getUser(Mockito.any(SecureDomain.class), Mockito.anyString())).thenReturn(user);
		int result = modifySystemAccessorServiceImpl.validateCurrentPassword(systemAccessor, PASSWORD);
		assertEquals(result,IUserAccountService.AUTH_FAILED);
	}
	public class MockAccessManagerBean extends AccessManagerBean {

		
		private IUserAccountService userAccountService;

		public void setUserAccountService(IUserAccountService userAccountService) {
			this.userAccountService = userAccountService;
		}
		
		@Override
		public IUserAccountService getUserAccountService() {
			return userAccountService;
		}
		
		
	}
}
