package com.intact.soa.utility.sas.repository.modifysystemaccessor.controller;

import com.ing.canada.singleid.accessmanager.domain.SecureDomain;
import com.ing.canada.singleid.accessmanager.exception.AccessManagerException;
import com.intact.bod.bco.party.ISystemAccessor;

public interface IModifySystemAccessorController {

	public boolean deleteSystemAccessor(ISystemAccessor systemAccessor);
	
	public boolean deleteSystemAccessor(ISystemAccessor systemAccessor, SecureDomain secureDomain);
	
	boolean updateSystemAccessor(ISystemAccessor systemAccessor, String newEmail, String usageType);

	boolean updateSystemAccessor(SecureDomain secureDomain, ISystemAccessor systemAccessor, String newEmail, String usageType);

	boolean updateSystemAccessor(ISystemAccessor systemAccessor, String newEmail);
	
	public void updatePassword(ISystemAccessor systemAccessor, String password) throws AccessManagerException;
	
	ISystemAccessor getPersonalUserAccess(Long authenticationId);

	public int validateCurrentPassword(ISystemAccessor systemAccessor, String currentPassword)  throws AccessManagerException ;

	
}
