/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance
* Copyright (c) 2015, Intact Insurance, All rights reserved.<br>
*/
package com.intact.soa.raa.authentication.service;

import com.intact.raa.domain.authentication.Authentication;

/**
 * Authentication Service.
 *
 */
public interface IAuthenticationService {
	
	/**
	 * Find by email address and usage type (company) both ignore case,
	 * the user. 
	 * 
	 * @param email the meail 
	 * @param usageType the company 
	 * @return the authentication
	 */
	//@Query("select au from Authentication au where upper(au.emailAddress) = upper(?1) and upper(au.usageType) = upper(?2) and (au.endDate is null or au.endDate > CURRENT_DATE)")
	public Authentication findByEmailAddressAndUsageTypeIgnoreCase(String email, String usageType); 
	
	/**
	 * Find by email address ignore case.
	 *
	 * @param email the email
	 * @return the authentication
	 */
	//@Query("select au from Authentication au where upper(au.emailAddress) = upper(?1) and (au.endDate is null or au.endDate > CURRENT_DATE)")
	public Authentication findByEmailAddressIgnoreCase(String email); 
	
	/**
	 * Find by client id.
	 *
	 * @param clientId the client id
	 * @return the authentication
	 */
	//@Query("select acr.authentication from AuthenticationClientRel acr where acr.cliClient = ?1 and (acr.authentication.endDate is null or acr.authentication.endDate > CURRENT_DATE)")
	public Authentication findByClientId(long clientId); 
	
	
	//@Override
	/**
	 * Find one.
	 *
	 * @param id the id
	 * @return the authentication
	 */
	//@Query("select au from Authentication au where au.authenticationId = ?1 and ( au.endDate is null or au.endDate > CURRENT_DATE)")
	public Authentication findOne(Long id);
	
	/**
	 * Delete by setting end date.
	 *
	 * @param authenticationObject the authentication object
	 */
	public void delete(Authentication authenticationObject);
	
	/**
	 * Update.
	 *
	 * @param authentication the authentication
	 * @return true, if successful
	 */
	public boolean update(Authentication authentication);
	
	/**
	 * Save.
	 *
	 * @param authentication the authentication
	 * @return the authentication
	 */
	public Authentication save(Authentication authentication);

	/**
	 * delete row in database
	 *
	 * @param authentication the authentication
	 */
	public void fullDelete(Authentication authentication);

}
