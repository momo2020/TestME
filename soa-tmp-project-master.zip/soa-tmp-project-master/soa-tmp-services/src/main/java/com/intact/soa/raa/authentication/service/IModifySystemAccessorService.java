package com.intact.soa.raa.authentication.service;

import com.ing.canada.singleid.accessmanager.domain.SecureDomain;
import com.ing.canada.singleid.accessmanager.exception.AccessManagerException;
import com.intact.bod.bco.party.ISystemAccessor;


public interface IModifySystemAccessorService {

	public boolean deletePersonalUserAccess(Long authenticationId);
	
	public boolean deletePersonalUserAccess(Long authenticationId, SecureDomain secureDomain);
	
	boolean updatePersonalUserAccessEmail(ISystemAccessor systemAccessor, String newEmail, String usageType);
	
	boolean updatePersonalUserAccessEmail(SecureDomain secureDomain, ISystemAccessor systemAccessor, String newEmail, String usageType);

	boolean updatePersonalUserAccessEmail(ISystemAccessor systemAccessor, String newEmail);
	
	public void updatePersonalUserAccessPassword(ISystemAccessor systemAccessor,
			String password) throws AccessManagerException;
	
	ISystemAccessor getPersonalUserAccess(Long authenticationId);

	public int validateCurrentPassword(ISystemAccessor systemAccessor, String currentPassword)  throws AccessManagerException ;
}
