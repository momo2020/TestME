package com.intact.soa.raa.authentication.dao;

import java.util.List;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.EmailToken;
import com.intact.raa.domain.authentication.EmailToken.EventTriggerCode;

/**
 * The Interface IEmailTokenDAO.
 */
public interface IEmailTokenDAO {

	/**
	 * Find by authentication.
	 *
	 * @param authentication the authentication
	 * @param code the code
	 * @return the list
	 */
	List<EmailToken> findByAuthentication(Authentication authentication, EventTriggerCode code);

	/**
	 * Persist.
	 *
	 * @param emailToken the email token
	 * @return the email token
	 */
	EmailToken persist(EmailToken emailToken);

	/**
	 * delete row in database
	 *
	 * @param emailToken the email token
	 */
	void fullDelete(EmailToken emailToken);

	/**
	 * Find by authentication.
	 *
	 * @param authentication the authentication
	 * @return the list
	 */
	List<EmailToken> findByAuthentication(Authentication authentication);

	/**
	 * Find by client id.
	 *
	 * @param clientId the client id
	 * @param code the code
	 * @return the list
	 */
	List<EmailToken> findByClientId(Long clientId, EventTriggerCode code);

	/**
	 * Find valid email token.
	 *
	 * @param token the token
	 * @param code the code
	 * @return the email token
	 */
	EmailToken findValidEmailToken(String token, EventTriggerCode code);

	/**
	 * Find email token.
	 *
	 * @param token the token
	 * @param code list for codes
	 * @return the email tokens
	 */
	List<EmailToken> findEmailTokens(String token, List<EventTriggerCode> codes);
	/**
	 * Flush.
	 */
	void flush();

}
