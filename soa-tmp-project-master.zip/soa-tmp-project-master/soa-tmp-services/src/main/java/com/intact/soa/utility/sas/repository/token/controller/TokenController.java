/**
 * 
 */
package com.intact.soa.utility.sas.repository.token.controller;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.time.DateUtils;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.intact.common.security.SecurityUtility;
import com.intact.common.security.exception.SecurityUtilityException;
import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.ClientRegistrationEvent;
import com.intact.raa.domain.authentication.ClientRegistrationEvent.EventType;
import com.intact.raa.domain.authentication.EmailToken;
import com.intact.raa.domain.authentication.EmailToken.EventTriggerCode;
import com.intact.soa.raa.authentication.service.IAuthenticationService;
import com.intact.soa.raa.authentication.service.IClientRegistrationEventService;
import com.intact.soa.raa.authentication.service.IEmailTokenService;
import com.intact.soa.utility.sas.repository.exception.SoaException;

@Component("tokenController")
public class TokenController implements ITokenController {

	private static final Logger log = ESAPI.getLogger(TokenController.class);

	@Value("${token.welcomeEmail.validity:172800}")
	private int welcomeEmailTokenValiditySec;

	@Value("${token.resetPasswordEmail.validity:7200}")
	private int resetPasswordEmailTokenValiditySec;

	@Autowired
	private IAuthenticationService authenticationService;
	
	@Autowired
	private IClientRegistrationEventService clientRegistrationEventService;
	
	@Autowired
	private IEmailTokenService emailTokenService;
	
	/* (non-Javadoc)
	 * @see com.intact.soa.utility.sas.repository.token.controller.ITokenController#generateSystemAccessorResetToken(java.lang.Long)
	 */
	@Override
	public String generateSystemAccessorResetToken(Long cifClientId) {
		String token = null;
		try {
			token = SecurityUtility.getInstance().getRandomizeToolbox().randomString().substring(0, 39);
			Authentication authentication = null;
			authentication = authenticationService.findByClientId(cifClientId);

			// log the request into ClientRegistrationEvent (RESET_PWD type)
			ClientRegistrationEvent clientRegistrationEvent = new ClientRegistrationEvent();
			clientRegistrationEvent.setEventType(EventType.RESET_PWD);
			clientRegistrationEvent.setEventDateTime(new Date());
			clientRegistrationEvent.setAuthentication(authentication);
			ClientRegistrationEvent registrationEvent = clientRegistrationEventService.persist(clientRegistrationEvent);
			if (log.isDebugEnabled()) {
				log.debug(Logger.EVENT_SUCCESS,"Created a new ClientRegistrationEvent in RAA database result :" + registrationEvent);
			}
			
			// invalidate last token if exist
			invalidateLastEmailToken(authentication);

			// save token
			saveToken(token, authentication);
		} catch (SecurityUtilityException e) {
			throw new SoaException(e);
		}
		return token;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.utility.sas.repository.token.controller.ITokenController#generateSystemAccessorCreationToken(java.lang.Long)
	 */
	@Override
	public String generateSystemAccessorCreationToken(Long cliClient) {
		return generateSystemAccessorCreationToken(cliClient, null);
	}
	
	/* (non-Javadoc)
	 * @see com.intact.soa.utility.sas.repository.token.controller.ITokenController#generateSystemAccessorCreationToken(java.lang.Long)
	 */
	@Override
	public String generateSystemAccessorCreationToken(Long cliClient, String emailTokenType) {

		String token = null;
		try {
			token = SecurityUtility.getInstance().getRandomizeToolbox().randomString().substring(0, 39);
			// save token
			saveTokenCreate(token, cliClient, emailTokenType);
		} catch (SecurityUtilityException e) {
			throw new SoaException(e);
		}
		return token;
	
	}
	
	/**
	 * Invalidate last email token.
	 * 
	 * @param authentication the authentication
	 */
	private void invalidateLastEmailToken(Authentication authentication){
		List<EmailToken> lastEmailTokens = emailTokenService.findByAuthentication(authentication,EventTriggerCode.RESET_PWD);
		for (EmailToken lastEmailToken : lastEmailTokens)
			if (lastEmailToken != null) {
				invalidateLastEmailToken(lastEmailToken);
			}
	}

	/**
	 * Invalidate last email token.
	 * 
	 * @param emailToken the email token
	 */
	private void invalidateLastEmailToken(EmailToken emailToken) {
		emailToken.setEndDateTime(new Date());
		emailTokenService.save(emailToken);
	}
	
	/**
	 * Store the token in db.
	 * 
	 * @param email the email
	 * @param token the token
	 * @param authentication the authentication
	 */
	private void saveToken(String token, Authentication authentication) {

		// create new email token
		EmailToken emailToken = new EmailToken();
		emailToken.setAuthentication(authentication);
		emailToken.setCreationDateTime(new Date());
		emailToken.setEndDateTime(DateUtils.addSeconds(new Date(), resetPasswordEmailTokenValiditySec));
		emailToken.setEventTriggerCode(EventTriggerCode.RESET_PWD);
		emailToken.setStartDateTime(new Date());
		emailToken.setToken(hashToken(token));
		// save it
		emailTokenService.save(emailToken);
	}
	
	/**
	 * Store the token in db.
	 * 
	 * @param email the email
	 * @param token the token
	 * @param cliClient the cliClient
	 */
	private void saveTokenCreate(String token, Long cliClient, String emailTokenType) {
		EventTriggerCode eventTriggerCode;
		if ("modification".equals(emailTokenType)) {
			eventTriggerCode = EventTriggerCode.EDOC_POL_CHG;
		} else if ("renewal".equals(emailTokenType)) {
			eventTriggerCode = EventTriggerCode.EDOC_POL_RNW;
		} else if ("cancellation".equals(emailTokenType)) {
			eventTriggerCode = EventTriggerCode.EDOC_POL_CAN;
		} else if ("reprint".equals(emailTokenType)) {
			eventTriggerCode = EventTriggerCode.EDOC_REPRINT;
		} else {
			//welcome email is the else case since it was the only type possible before adding modification, renewal and cancellation
			eventTriggerCode = EventTriggerCode.WELC_EMAIL;
		}
	
		// create new email token
		EmailToken emailToken = new EmailToken();
		emailToken.setCreationDateTime(new Date());
		emailToken.setEndDateTime(DateUtils.addSeconds(new Date(), welcomeEmailTokenValiditySec));
		emailToken.setEventTriggerCode(eventTriggerCode);
		emailToken.setStartDateTime(new Date());
		emailToken.setToken(hashToken(token));
		emailToken.setCliClient(cliClient);
		// save it
		emailTokenService.save(emailToken);
	}
	
	private String hashToken(String token){
		try {
			return SecurityUtility.getInstance().getHasherToolbox().hash(token);
		} catch (SecurityUtilityException e) {
			throw new SoaException(e);
		}
	}
}
