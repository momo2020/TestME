package com.intact.soa.raa.authentication.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.EmailToken;
import com.intact.raa.domain.authentication.EmailToken.EventTriggerCode;
import com.intact.soa.raa.authentication.dao.IEmailTokenDAO;
import com.intact.soa.raa.authentication.service.IEmailTokenService;

@Service
@Transactional
public class EmailTokenServiceImpl implements IEmailTokenService {

	@Autowired
	private IEmailTokenDAO emailTokenDAO;

	@Override
	public EmailToken findValidEmailToken(String token, EventTriggerCode code) {
		return emailTokenDAO.findValidEmailToken(token, code);
	}
	
	@Override
	public List<EmailToken> findEmailTokens(String token, List<EventTriggerCode> codes) {
		return emailTokenDAO.findEmailTokens(token, codes);
	}

	@Override
	public List<EmailToken> findByAuthentication(Authentication authentication, EventTriggerCode code) {
		List<EmailToken> emailTokens = emailTokenDAO.findByAuthentication(authentication, code);
		return emailTokens;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public EmailToken save(EmailToken emailToken) {
		EmailToken newEmailToken = emailTokenDAO.persist (emailToken);
		return newEmailToken;
	}

	@Override
	public List<EmailToken> findByAuthentication(Authentication authentication) {
		return emailTokenDAO.findByAuthentication(authentication);
	}

	@Override
	public void fullDelete(List<EmailToken> emailTokens) {
		for (EmailToken emailToken : emailTokens){
			emailTokenDAO.fullDelete(emailToken);
		}
		
	}

	@Override
	public List<EmailToken> findByClientId(Long clientId, EventTriggerCode code) {
		return emailTokenDAO.findByClientId(clientId, code);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public EmailToken saveAndFlush(EmailToken emailToken) {
		EmailToken newEmailToken = emailTokenDAO.persist (emailToken);
		emailTokenDAO.flush();
		return newEmailToken;
	}
}
