package com.intact.soa.raa.authentication.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.AuthenticationCookie;
import com.intact.soa.raa.authentication.dao.IAuthenticationCookieDAO;
import com.intact.soa.raa.authentication.service.IAuthenticationCookieService;

@Service
@Transactional
public class AuthenticationCookieServiceImpl implements IAuthenticationCookieService {
	
	@Autowired
	private IAuthenticationCookieDAO authenticationCookieDAO;

	@Override
	public AuthenticationCookie findByAuthenticationCookieUuId(String cookieId) {
		return authenticationCookieDAO.findByAuthenticationCookieUuId(cookieId);
	}

	@Override
	public List<AuthenticationCookie> findByAuthentication(Authentication authentication){
		return authenticationCookieDAO.findByAuthentication(authentication);
	}

	@Override
	public void fullDelete(List<AuthenticationCookie> authenticationCookies) {
		for (AuthenticationCookie authenticationCookie: authenticationCookies){
			authenticationCookieDAO.fullDelete(authenticationCookie);
		}
		
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public AuthenticationCookie save(AuthenticationCookie authenticationCookie) {
		return authenticationCookieDAO.persist(authenticationCookie);
	}

}
