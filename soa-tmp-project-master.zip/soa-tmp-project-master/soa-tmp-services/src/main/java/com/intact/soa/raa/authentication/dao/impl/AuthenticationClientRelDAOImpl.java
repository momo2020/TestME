package com.intact.soa.raa.authentication.dao.impl;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.owasp.esapi.ESAPI;
import org.owasp.esapi.Logger;
import org.springframework.stereotype.Repository;

import com.intact.raa.domain.authentication.AuthenticationClientRel;
import com.intact.soa.raa.authentication.dao.IAuthenticationClientRelDAO;

/**
 * The Class AuthenticationClientRelDAOImpl.
 */
@Repository
public class AuthenticationClientRelDAOImpl implements IAuthenticationClientRelDAO {

	/** The log. */
	private final Logger log = ESAPI.getLogger(AuthenticationClientRelDAOImpl.class);
	
	
	/** The entity manager. */
	@PersistenceContext(unitName="soaraa_persistence_unit")
	protected EntityManager entityManager;
	
	
	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IAuthenticationClientRelDAO#findByAuthenticationId(long)
	 */
	@Override
	public List<AuthenticationClientRel> findByAuthenticationId(
			long authenticationId) {
		
		Query query = entityManager.createNamedQuery("AuthenticationClientRel.findByAuthenticationId");
		query.setParameter("authenticationId", authenticationId);
		
		@SuppressWarnings("unchecked")
		List<AuthenticationClientRel> listeAuthClientRel = query.getResultList();
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"findByAuthenticationId query returned " + listeAuthClientRel.size() + " AuthenticationClientRel objects");
		}
		return listeAuthClientRel;
	}
	
	/**
	 * We perform a soft delete which simply consist of setting the EndDate field in the Database
	 *  
	 *
	 * @param authenthicationId the authenthication id
	 */
	public void deleteByAuthenticationId( long authenthicationId){
			
		List<AuthenticationClientRel> listeAuthenticationClientRel = findByAuthenticationId(authenthicationId);
		
		for(AuthenticationClientRel authClientRel : listeAuthenticationClientRel){
			authClientRel.setEndDate(new Date());
			//update DB with changes
			entityManager.merge(authClientRel);
			if(log.isDebugEnabled()){
				log.debug(Logger.EVENT_SUCCESS,"update DB with AuthenticationClientRel object id:"+authClientRel.getAuthenticationClientRelId()+"");
			}
		}
		
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IAuthenticationClientRelDAO#fullDelete(com.intact.raa.domain.authentication.AuthenticationClientRel)
	 */
	@Override
	public void fullDelete(AuthenticationClientRel authenticationClientRel) {
		entityManager.remove(authenticationClientRel);
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IAuthenticationClientRelDAO#persist(com.intact.raa.domain.authentication.AuthenticationClientRel)
	 */
	@Override
	public AuthenticationClientRel persist(
			AuthenticationClientRel authenticationClientRel) {
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_UNSPECIFIED,"about to persist a entity: " + authenticationClientRel);
		}
		
		if (authenticationClientRel.getAuthenticationClientRelId() != null && !this.entityManager.contains(authenticationClientRel) ) {
			this.entityManager.merge(authenticationClientRel);
		} else {
			this.entityManager.persist(authenticationClientRel);
		}
		
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"merged/persisted a " + authenticationClientRel + " instance");
		}
		return authenticationClientRel;
	}

}
