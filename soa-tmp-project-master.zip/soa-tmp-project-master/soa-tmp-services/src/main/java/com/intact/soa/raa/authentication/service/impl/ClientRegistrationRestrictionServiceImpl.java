package com.intact.soa.raa.authentication.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.ClientRegistrationRestriction;
import com.intact.soa.raa.authentication.dao.IClientRegistrationRestrictionDAO;
import com.intact.soa.raa.authentication.service.IClientRegistrationRestrictionService;

@Service
@Transactional
public class ClientRegistrationRestrictionServiceImpl implements IClientRegistrationRestrictionService {

	@Autowired
	private IClientRegistrationRestrictionDAO clientRegistrationRestrictionDAO;

	@Override
	public List<ClientRegistrationRestriction> findResetPasswordBlock(Authentication authentication) {
		return clientRegistrationRestrictionDAO.findResetPasswordBlock(authentication);
	}

	@Override
	public List<ClientRegistrationRestriction> findRegisterBlock(Long cliClient) {
		return clientRegistrationRestrictionDAO.findRegisterBlock(cliClient);
	}

	@Override
	public List<ClientRegistrationRestriction> findAlive(Long cliClient, Authentication authentication) {
		return clientRegistrationRestrictionDAO.findAlive(cliClient, authentication);
	}

	@Override
	public List<ClientRegistrationRestriction> findByAuthentication(
			Authentication authentication) {
		return clientRegistrationRestrictionDAO.findByAuthentication(authentication);
	}

	@Override
	public List<ClientRegistrationRestriction> findByCliClient(Long clientId) {
		return clientRegistrationRestrictionDAO.findByCliClient(clientId);
	}

	@Override
	public void fullDelete(
			List<ClientRegistrationRestriction> clientRegistrationRestrictions) {
		for (ClientRegistrationRestriction clientRegistrationRestriction : clientRegistrationRestrictions){
			clientRegistrationRestrictionDAO.fullDelete(clientRegistrationRestriction);
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public ClientRegistrationRestriction save(
			ClientRegistrationRestriction clientRegistrationRestriction) {
		return clientRegistrationRestrictionDAO.persist(clientRegistrationRestriction);
	}

}
