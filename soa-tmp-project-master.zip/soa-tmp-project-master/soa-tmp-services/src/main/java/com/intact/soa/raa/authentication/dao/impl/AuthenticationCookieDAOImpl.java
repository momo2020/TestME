/**
 * 
 */
package com.intact.soa.raa.authentication.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.collections.CollectionUtils;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.Logger;
import org.springframework.stereotype.Repository;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.AuthenticationCookie;
import com.intact.soa.raa.authentication.dao.IAuthenticationCookieDAO;

/**
 * The Class AuthenticationCookieDAOImpl.
 *
 * @author vmathieu
 */
@Repository
public class AuthenticationCookieDAOImpl implements IAuthenticationCookieDAO {
	
	/** The log. */
	private final Logger log= ESAPI.getLogger(AuthenticationCookieDAOImpl.class);
	
	
	/** The entity manager. */
	@PersistenceContext(unitName="soaraa_persistence_unit")
	protected EntityManager entityManager;


	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IAuthenticationCookieDAO#fullDelete(com.intact.raa.domain.authentication.AuthenticationCookie)
	 */
	@Override
	public void fullDelete(AuthenticationCookie authenticationCookie) {
		entityManager.remove(authenticationCookie);
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IAuthenticationCookieDAO#findByAuthenticationCookieUuId(java.lang.String)
	 */
	@Override
	public AuthenticationCookie findByAuthenticationCookieUuId(String cookieId) {
		AuthenticationCookie authenticationCookie = null;
		Query query = entityManager.createNamedQuery("AuthenticationCookie.findByAuthenticationCookieUuId");
		query.setParameter("authenticationCookieUuId", cookieId);
		
		@SuppressWarnings("unchecked")
		List<AuthenticationCookie> authenticationCookies = query.getResultList();
		if (CollectionUtils.isNotEmpty(authenticationCookies)) {
			authenticationCookie = authenticationCookies.get(0);
			if (log.isDebugEnabled()) {
				log.debug(Logger.EVENT_SUCCESS,"findByAuthenticationCookieUuId query returned " + authenticationCookies.size() + " AuthenticationCookie objects");
			}
		}
		return authenticationCookie;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IAuthenticationCookieDAO#findByAuthentication(com.intact.raa.domain.authentication.Authentication)
	 */
	@Override
	public List<AuthenticationCookie> findByAuthentication(Authentication authentication) {
		Query query = entityManager.createNamedQuery("AuthenticationCookie.findByAuthentication");
		query.setParameter("authentication", authentication);
		
		@SuppressWarnings("unchecked")
		List<AuthenticationCookie> authenticationCookies = query.getResultList();
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"findByAuthentication query returned " + authenticationCookies.size() + " AuthenticationCookie objects");
		}
		return authenticationCookies;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IAuthenticationCookieDAO#persist(com.intact.raa.domain.authentication.AuthenticationCookie)
	 */
	@Override
	public AuthenticationCookie persist(
			AuthenticationCookie authenticationCookie) {
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_UNSPECIFIED,"about to persist a entity: " + authenticationCookie);
		}
		
		if (authenticationCookie.getAuthenticationCookieId() != null && !this.entityManager.contains(authenticationCookie) ) {
			this.entityManager.merge(authenticationCookie);
		} else {
			this.entityManager.persist(authenticationCookie);
		}
		
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"merged/persisted a " + authenticationCookie + " instance");
		}
		return authenticationCookie;
	}
	

}
