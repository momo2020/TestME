package com.intact.soa.raa.authentication.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.collections.CollectionUtils;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.Logger;
import org.springframework.stereotype.Repository;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.EmailToken;
import com.intact.raa.domain.authentication.EmailToken.EventTriggerCode;
import com.intact.soa.raa.authentication.dao.IEmailTokenDAO;

/**
 * The Class EmailTokenDAOImpl.
 */
@Repository
public class EmailTokenDAOImpl implements IEmailTokenDAO {

	/** The log. */
	private final Logger log = ESAPI.getLogger(EmailTokenDAOImpl.class);

	/** The entity manager. */
	@PersistenceContext(unitName="soaraa_persistence_unit")
	protected EntityManager entityManager;
	
	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IEmailTokenDAO#findByAuthentication(com.intact.raa.domain.authentication.Authentication, com.intact.raa.domain.authentication.EmailToken.EventTriggerCode)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<EmailToken> findByAuthentication(Authentication authentication, EventTriggerCode code) {
		
		List<EmailToken> emailTokens = null;
		Query query = this.entityManager.createNamedQuery("EmailToken.findByAuthenticationAndEventTriggerCode");
		query.setParameter("authentication", authentication);
		query.setParameter("eventTriggerCode", code);
		
		emailTokens = query.getResultList();
		
		if (log.isDebugEnabled()) {
			if (CollectionUtils.isNotEmpty(emailTokens)) {
				log.debug(Logger.EVENT_SUCCESS,"findByAuthenticationAndEventTriggerCode query returned " + emailTokens.size() + " EmailToken objects");
			}
		}
		
		return emailTokens;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IEmailTokenDAO#persist(com.intact.raa.domain.authentication.EmailToken)
	 */
	@Override
	public EmailToken persist(EmailToken emailToken) {
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_UNSPECIFIED,"about to persist a entity: " + emailToken);
		}
		
		if (emailToken.getEmailToken() != null && !this.entityManager.contains(emailToken) ) {
			this.entityManager.merge(emailToken);
		} else {
			this.entityManager.persist(emailToken);
		}
		
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"merged/persisted a " + emailToken + " instance");
		}
		return emailToken;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IEmailTokenDAO#fullDelete(com.intact.raa.domain.authentication.EmailToken)
	 */
	@Override
	public void fullDelete(EmailToken emailToken) {
		entityManager.remove(emailToken);
		
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IEmailTokenDAO#findByAuthentication(com.intact.raa.domain.authentication.Authentication)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<EmailToken> findByAuthentication(Authentication authentication) {
		List<EmailToken> emailTokens = null;
		Query query = this.entityManager.createNamedQuery("EmailToken.findByAuthentication");
		query.setParameter("authentication", authentication);
		
		emailTokens = query.getResultList();
		
		if (log.isDebugEnabled()) {
			if (CollectionUtils.isNotEmpty(emailTokens)) {
				log.debug(Logger.EVENT_SUCCESS,"findByAuthentication query returned " + emailTokens.size() + " EmailToken objects");
			}
		}
		
		return emailTokens;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IEmailTokenDAO#findByClientId(java.lang.Long, com.intact.raa.domain.authentication.EmailToken.EventTriggerCode)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<EmailToken> findByClientId(Long clientId, EventTriggerCode code) {
		List<EmailToken> emailTokens = null;
		Query query = this.entityManager.createNamedQuery("EmailToken.findByClientId");
		query.setParameter("clientId", clientId);
		query.setParameter("eventTriggerCode", code);
		
		emailTokens = query.getResultList();
		
		if (log.isDebugEnabled()) {
			if (CollectionUtils.isNotEmpty(emailTokens)) {
				log.debug(Logger.EVENT_SUCCESS,"findByClientId query returned " + emailTokens.size() + " EmailToken objects");
			}
		}
		
		return emailTokens;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IEmailTokenDAO#findValidEmailToken(java.lang.String, com.intact.raa.domain.authentication.EmailToken.EventTriggerCode)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public EmailToken findValidEmailToken(String token, EventTriggerCode code) {
		List<EmailToken> emailTokens = null;
		EmailToken emailToken = null;
		Query query = this.entityManager.createNamedQuery("EmailToken.findValidEmailToken");
		query.setParameter("token", token);
		query.setParameter("eventTriggerCode", code);
		
		emailTokens = query.getResultList();
		
		if (CollectionUtils.isNotEmpty(emailTokens)) {
			emailToken = emailTokens.get(0);
			if (log.isDebugEnabled()) {
				log.debug(Logger.EVENT_SUCCESS,"findValidEmailToken query returned " + emailTokens.size() + " EmailToken objects");
			}
		}
		
		return emailToken;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IEmailTokenDAO#findEmailToken(java.lang.String, List<com.intact.raa.domain.authentication.EmailToken.EventTriggerCode>)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<EmailToken> findEmailTokens(String token, List<EventTriggerCode> codes) {
		Query query = this.entityManager.createNamedQuery("EmailToken.findEmailTokens");
		query.setParameter("token", token);
		query.setParameter("eventTriggerCodes", codes);
		
		return query.getResultList();
	}
	
	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IEmailTokenDAO#flush()
	 */
	@Override
	public void flush() {
		entityManager.flush();
	}


}
