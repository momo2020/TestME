package com.intact.soa.raa.authentication.service.impl;

import org.springframework.stereotype.Component;

import com.ing.canada.singleid.accessmanager.service.IUserAccountService;
import com.ing.canada.singleid.accessmanager.service.factory.AccessManagerServiceFactory;

@Component
public class AccessManagerBean {

	public IUserAccountService getUserAccountService() {
		return AccessManagerServiceFactory.getInstance().getUserAccountService();
	}
}
