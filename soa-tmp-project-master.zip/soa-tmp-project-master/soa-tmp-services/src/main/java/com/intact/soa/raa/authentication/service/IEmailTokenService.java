/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance
* Copyright (c) 2015, Intact Insurance, All rights reserved.<br>
*/
package com.intact.soa.raa.authentication.service;

import java.util.List;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.EmailToken;
import com.intact.raa.domain.authentication.EmailToken.EventTriggerCode;

/**
 * Email Token Service.
 *
 */
public interface IEmailTokenService {

	/**
	 * Find valid email token.
	 *
	 * @param token the token
	 * @param code the code
	 * @return the email token
	 */
	//@Query("select et from EmailToken et where et.token = ?1 and et.eventTriggerCode = ?2")
	EmailToken findValidEmailToken(String token, EventTriggerCode code);
	
	/**
	 * Find valid email token.
	 *
	 * @param token the token
	 * @param code list of EventTriggerCode
	 * @return the email tokens
	 */
	//@Query("select et from EmailToken et where et.token = ?1 and et.eventTriggerCode in ?2")
	List<EmailToken> findEmailTokens(String token, List<EventTriggerCode> codes);
	
	/**
	 * Find by authentication.
	 *
	 * @param authentication the authentication
	 * @param code the code
	 * @return the email token
	 */
	//@Query("select et from EmailToken et where et.authentication = ?1 and et.eventTriggerCode = ?2 and et.endDateTime > CURRENT_DATE")
	List<EmailToken> findByAuthentication(Authentication authentication, EventTriggerCode code);

	/**
	 * Saves a new instance of <code></code> to RAA database.
	 *
	 * @param emailToken the email token
	 * @return the email token
	 */
	EmailToken save(EmailToken emailToken);
	
	/**
	 * Find by authentication.
	 *
	 * @param authentication the authentication
	 * @return the list
	 */
	//@Query("select et from EmailToken et where et.authentication = ?1")
	List<EmailToken> findByAuthentication(Authentication authentication);

	/**
	 * delete row in database
	 *
	 * @param emailTokens the email tokens
	 */
	void fullDelete(List<EmailToken> emailTokens);
	
	/**
	 * Find by client id.
	 *
	 * @param clientId the client id
	 * @param code the code
	 * @return the list
	 */
	//@Query("select et from EmailToken et where et.cliClient = ?1 and et.eventTriggerCode = ?2 and et.endDateTime > CURRENT_DATE")
	List<EmailToken> findByClientId(Long clientId, EventTriggerCode code);

	/**
	 * Save and flush.
	 *
	 * @param emailToken the email token
	 * @return the email token
	 */
	EmailToken saveAndFlush(EmailToken emailToken);

	

}
