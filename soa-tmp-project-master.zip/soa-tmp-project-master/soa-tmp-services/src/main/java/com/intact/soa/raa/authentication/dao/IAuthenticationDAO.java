package com.intact.soa.raa.authentication.dao;

import com.intact.raa.domain.authentication.Authentication;

/**
 * The Interface IAuthenticationDAO.
 */
public interface IAuthenticationDAO {

	/**
	 * Find by email address ignore case.
	 *
	 * @param email the email
	 * @return the authentication
	 */
	Authentication findByEmailAddressIgnoreCase(String email);
	
	/**
	 * Find by email address and usage type ignore case.
	 *
	 * @param email the email
	 * @param usageType the usage type
	 * @return the authentication
	 */
	Authentication findByEmailAddressAndUsageTypeIgnoreCase(String email, String usageType);
	
	/**
	 * Find by client id.
	 *
	 * @param clientId the client id
	 * @return the authentication
	 */
	Authentication findByClientId(long clientId);
	
	/**
	 * Delete by setting end date.
	 *
	 * @param authenticationObject the authentication object
	 */
	public void delete(Authentication authenticationObject);
	
	/**
	 * Update.
	 *
	 * @param authentication the authentication
	 * @return the authentication
	 */
	public Authentication update(Authentication authentication);
	
	/**
	 * Find one.
	 *
	 * @param id the id
	 * @return the authentication
	 */
	public Authentication findOne(Long id);

	/**
	 * delete row in database
	 *
	 * @param authentication the authentication
	 */
	void fullDelete(Authentication authentication);

	/**
	 * Persist.
	 *
	 * @param authentication the authentication
	 * @return the authentication
	 */
	Authentication persist(Authentication authentication);
}
