package com.intact.soa.raa.authentication.dao.impl;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.owasp.esapi.ESAPI;
import org.owasp.esapi.Logger;
import org.springframework.stereotype.Repository;
import org.apache.commons.collections.CollectionUtils;
import com.intact.raa.domain.authentication.Authentication;
import com.intact.soa.raa.authentication.dao.IAuthenticationDAO;

/**
 * The Class AuthenticationDAOImpl.
 */
@Repository
public class AuthenticationDAOImpl implements IAuthenticationDAO {

	/** The logger. */
	private final Logger log = ESAPI.getLogger(AuthenticationDAOImpl.class);

	/** The entity manager. */
	@PersistenceContext(unitName = "soaraa_persistence_unit")
	protected EntityManager entityManager;

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IAuthenticationDAO#findByEmailAddressIgnoreCase(java.lang.String)
	 */
	@Override
	public Authentication findByEmailAddressIgnoreCase(String email) {

		Authentication authentication = null;
		Query query = this.entityManager.createNamedQuery("Authentication.findByEmailAddressIgnoreCase");
		query.setParameter("emailAddress", email);

		@SuppressWarnings("unchecked")
		List<Authentication> authentications = query.getResultList();

		if (CollectionUtils.isNotEmpty(authentications)) {
			authentication = authentications.get(0);
			if (log.isDebugEnabled()) {
				log.debug(Logger.EVENT_SUCCESS,"findByEmailAddressIgnoreCase query returned " + authentications.size() + " Authentication objects");
			}
		}
		return authentication;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IAuthenticationDAO#findByEmailAddressAndUsageTypeIgnoreCase(java.lang.String, java.lang.String)
	 */
	@Override
	public Authentication findByEmailAddressAndUsageTypeIgnoreCase(String email, String usageType) {
		
		Authentication authentication = null;
		Query query = this.entityManager.createNamedQuery("Authentication.findByEmailAddressAndUsageTypeIgnoreCase");
		query.setParameter("emailAddress", email);
		query.setParameter("usageType", usageType);

		@SuppressWarnings("unchecked")
		List<Authentication> authentications = query.getResultList();

		if (CollectionUtils.isNotEmpty(authentications)) {
			authentication = authentications.get(0);
			if (log.isDebugEnabled()) {
				log.debug(Logger.EVENT_SUCCESS,"findByEmailAddressAndUsageTypeIgnoreCase query returned " + authentications.size() + " Authentication objects");
			}
		}
		return authentication;
	}
	
	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IAuthenticationDAO#findByClientId(long)
	 */
	@Override
	public Authentication findByClientId(long clientId) {
		
		Authentication authentication = null;
		Query query = this.entityManager.createNamedQuery("Authentication.findByClientId");
		query.setParameter("cliClient", clientId);

		try {
			authentication = (Authentication) query.getSingleResult();			
		} catch (NoResultException e) {
			log.debug(Logger.EVENT_UNSPECIFIED,"No record returnd by the query, no result exception is handled gracefully!");
		}
		
		return authentication;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IAuthenticationDAO#delete(com.intact.raa.domain.authentication.Authentication)
	 */
	@Override
	public void delete(Authentication authenticationObject) {
		authenticationObject.setEndDate(new Date());
		entityManager.merge(authenticationObject);
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IAuthenticationDAO#update(com.intact.raa.domain.authentication.Authentication)
	 */
	@Override
	public Authentication update(Authentication authentication) {
		return entityManager.merge(authentication);
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IAuthenticationDAO#findOne(java.lang.Long)
	 */
	@Override
	public Authentication findOne(Long id) {
		Authentication authentication = null;
		Query query = this.entityManager.createNamedQuery("Authentication.findOne");
		query.setParameter("id", id);
		try {
			authentication = (Authentication) query.getSingleResult();			
		} catch (NoResultException e) {
			log.debug(Logger.EVENT_UNSPECIFIED,"No record returnd by the query, no result exception is handled gracefully!");
		}
		
		return authentication;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IAuthenticationDAO#fullDelete(com.intact.raa.domain.authentication.Authentication)
	 */
	@Override
	public void fullDelete(Authentication authentication) {
		entityManager.remove(authentication);
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IAuthenticationDAO#persist(com.intact.raa.domain.authentication.Authentication)
	 */
	@Override
	public Authentication persist(Authentication authentication) {
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_UNSPECIFIED,"about to persist a entity: " + authentication);
		}
		
		if (authentication.getAuthenticationId() != null && !this.entityManager.contains(authentication) ) {
			this.entityManager.merge(authentication);
		} else {
			this.entityManager.persist(authentication);
		}
		
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"merged/persisted a " + authentication + " instance");
		}
		return authentication;
	}
}
