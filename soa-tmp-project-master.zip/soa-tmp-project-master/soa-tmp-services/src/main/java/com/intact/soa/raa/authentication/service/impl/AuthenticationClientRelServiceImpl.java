package com.intact.soa.raa.authentication.service.impl;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.AuthenticationClientRel;
import com.intact.soa.raa.authentication.dao.IAuthenticationClientRelDAO;
import com.intact.soa.raa.authentication.service.IAuthenticationClientRelService;

@Service
@Transactional
public class AuthenticationClientRelServiceImpl implements IAuthenticationClientRelService {

	@Autowired
	private IAuthenticationClientRelDAO authenticationClientRelDAO;
	
	@Override
	public List<AuthenticationClientRel> findByAuthentication(Authentication authentication) {
		return authenticationClientRelDAO.findByAuthenticationId(authentication.getAuthenticationId());
	}

	@Override
	public List<AuthenticationClientRel> findByAuthenticationId(
			long authenticationId) {
		
		return authenticationClientRelDAO.findByAuthenticationId(authenticationId);
	}

	@Override
	public void deleteByAuthenticationId(long authenticationId) {

		authenticationClientRelDAO.deleteByAuthenticationId(authenticationId);
	}

/*	@Override
	public void deleteByAuthenticationClientRel(
			AuthenticationClientRel authenticationClientRel) {
		authenticationClientRelDAO.deleteByAuthenticationClientRel(authenticationClientRel);
		
	}*/

	@Override
	public void fullDelete(List<AuthenticationClientRel> authenticationClientRels) {
		for (AuthenticationClientRel authenticationClientRel : authenticationClientRels){
			authenticationClientRelDAO.fullDelete(authenticationClientRel);
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public AuthenticationClientRel save(
			AuthenticationClientRel authenticationClientRel) {
		return authenticationClientRelDAO.persist(authenticationClientRel);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void save(
			Collection<AuthenticationClientRel> authenticationClientRels) {
		for (AuthenticationClientRel authenticationClientRel : authenticationClientRels){
			authenticationClientRelDAO.persist(authenticationClientRel);
		}
	}

}
