package com.intact.soa.utility.communicationservice.controller;

import java.util.Locale;
import java.util.Map;

import com.intact.bod.bco.party.impl.UnderwritingCompany;
import com.intact.bod.bco.place.impl.Province;
import com.intact.soa.utility.communicationservice.model.EmailCommunicationEnum;

public interface ICommunicationServiceMailerController {

	public void sendEmail(Locale locale, Province province, UnderwritingCompany company, EmailCommunicationEnum emailEnum, Map<String, String> emailInfo);
	
}
