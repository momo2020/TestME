/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance
* Copyright (c) 2015, Intact Insurance, All rights reserved.<br>
*/
package com.intact.soa.raa.authentication.service;

import java.util.Date;
import java.util.List;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.ClientRegistrationEvent;

/**
 * The Interface IClientRegistrationEventService.
 *
 */
public interface IClientRegistrationEventService {

	/**
	 * Find reset password attempts.
	 *
	 * @param authentication the authentication
	 * @param startDate retrieve attempts after this date
	 * @return the list
	 */
	/*@Query("select cre from ClientRegistrationEvent cre where cre.authentication = ?1" +
			" and cre.eventDateTime > ?2 and cre.deleteDateTime is null" +
			" and cre.eventType = 'RESET_PWD'")
	*/
	public List<ClientRegistrationEvent> findResetPasswordAttempts(Authentication authentication, Date startDate);
	
	/**
	 * Find register attempts.
	 *
	 * @param cliClient the cli client
	 * @param startDate the start date
	 * @return the list
	 */
	/*@Query("select cre from ClientRegistrationEvent cre where cre.cliClient = ?1" +
			" and cre.eventDateTime > ?2 and cre.deleteDateTime is null" +
			" and cre.eventType in ('FAIL_FIND_BY_POL', 'FAIL_POL_VERIF', 'FAIL_DRIV_LIC_VERIF', 'FAIL_SMS_VERIF')")
			*/
	public List<ClientRegistrationEvent> findRegisterAttempts(Long cliClient, Date startDate);
	
	/**
	 * Find client registration events for which deleteDateTime is null or in the future.
	 *
	 * @param cliClient the cli client
	 * @param authentication the authentication
	 * @return the list
	 */
	/*@Query("select cre from ClientRegistrationEvent cre where (cre.cliClient = ?1" +
			" or cre.authentication = ?2) and (cre.deleteDateTime is null" +
			" or cre.deleteDateTime > CURRENT_DATE)")
			*/
	public List<ClientRegistrationEvent> findAlive(Long cliClient, Authentication authentication);
	
	/**
	 * Saves ClientRegistrationEvent to RAA Database.
	 *
	 * @param newClientRegistrationEvent the new client registration event
	 * @return the client registration event
	 */
	public ClientRegistrationEvent persist(ClientRegistrationEvent newClientRegistrationEvent);
	
	/**
	 * Find by authentication.
	 *
	 * @param authentication the authentication
	 * @return the list
	 */
	public List<ClientRegistrationEvent> findByAuthentication(Authentication authentication);

	/**
	 * Find by cli client.
	 *
	 * @param clientId the client id
	 * @return the list
	 */
	public List<ClientRegistrationEvent> findByCliClient(Long clientId);

	/**
	 * delete row in database
	 *
	 * @param clientRegistrationEvents the client registration events
	 */
	public void fullDelete(List<ClientRegistrationEvent> clientRegistrationEvents);
	
	/**
	 * Save.
	 *
	 * @param clientRegistrationEvent the client registration event
	 * @return the client registration event
	 */
	public ClientRegistrationEvent save(ClientRegistrationEvent clientRegistrationEvent);
}
