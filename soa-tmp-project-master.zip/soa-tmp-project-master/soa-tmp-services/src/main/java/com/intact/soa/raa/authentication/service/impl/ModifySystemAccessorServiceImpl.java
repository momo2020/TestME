package com.intact.soa.raa.authentication.service.impl;

import org.apache.commons.lang.StringUtils;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ing.canada.singleid.accessmanager.domain.SecureDomain;
import com.ing.canada.singleid.accessmanager.domain.User;
import com.ing.canada.singleid.accessmanager.exception.AccessManagerException;
import com.ing.canada.singleid.accessmanager.service.IUserAccountService;
import com.intact.bod.bco.party.ISystemAccessor;
import com.intact.bod.bco.party.impl.PersonalUserAccess;
import com.intact.raa.domain.authentication.Authentication;
import com.intact.soa.raa.authentication.service.IAuthenticationClientRelService;
import com.intact.soa.raa.authentication.service.IAuthenticationService;
import com.intact.soa.raa.authentication.service.IModifySystemAccessorService;
import com.intact.soa.utility.sas.repository.exception.SoaException;

@Service
@Transactional
public class ModifySystemAccessorServiceImpl implements
		IModifySystemAccessorService {

	private static final Logger LOG = ESAPI.getLogger(ModifySystemAccessorServiceImpl.class);
	
	private IAuthenticationService  authenticationService;
	private IAuthenticationClientRelService authenticationClientRelService;
	private SecureDomain secureDomain;
	private AccessManagerBean accessManagerBean;

	@Autowired(required = false)
	public ModifySystemAccessorServiceImpl( IAuthenticationService authenticationService, IAuthenticationClientRelService authenticationClientRelService, AccessManagerBean accessManagerBean) {
		this.authenticationService = authenticationService;
		this.authenticationClientRelService = authenticationClientRelService;
		this.secureDomain = SecureDomain.DEFAULT;
		this.accessManagerBean = accessManagerBean;
	}

	@Autowired(required = false) // The required=false is necessary for the fallback to the simpler constructor if the SecureDomain parameter doesn't exist in the context
	public ModifySystemAccessorServiceImpl( IAuthenticationService authenticationService, IAuthenticationClientRelService authenticationClientRelService, SecureDomain secureDomain, AccessManagerBean accessManagerBean ) {
		this.authenticationService = authenticationService;
		this.authenticationClientRelService = authenticationClientRelService;
		this.secureDomain = secureDomain;
		this.accessManagerBean = accessManagerBean;
	}


	/**
	 * Delete userAccount from Raa Database
	 * 
	 * @param {@link Authentication} authentication
	 * @return
	 */
	private boolean deleteRaaPersonalUserAccess(Authentication authentication) {

		if (authentication != null) {
			authenticationClientRelService.deleteByAuthenticationId(authentication.getAuthenticationId());
			authenticationService.delete(authentication);
			return true;
		}
        return false;
	}
	
	/**
	 * Performs deletion of userAccount from TAM 
	 * 
	 * @param authentication
	 * @return
	 */
	@Deprecated
	private boolean deleteTamPersonalUserAccess(Authentication authentication) {
		return deleteTamPersonalUserAccess(authentication,SecureDomain.DEFAULT);
	}
	
	
	
	/**
	 * Performs deletion of userAccount from TAM 
	 * 
	 * @param authentication
	 * @return
	 */
	private boolean deleteTamPersonalUserAccess(Authentication authentication ,SecureDomain secureDomain) {
		if (authentication != null) {
			try {  	
					//Check if the account exist before delete
					if(accessManagerBean.getUserAccountService().getAccountState(secureDomain,authentication.getEmailAddress()) != User.STATE_USERACCOUNT_VALID) {
						return false;
					}else {
						//Delete account
						accessManagerBean.getUserAccountService().deleteAccount(secureDomain, authentication.getEmailAddress());
						return true;
					}
			} catch (AccessManagerException e) {
				LOG.error(Logger.EVENT_FAILURE, "Could not delete TAM account with userId" + authentication.getEmailAddress(), e);
				throw new SoaException("could not delete user from TAM", e);
			}
		}
		return false;
	}

	/***
	 * 
	 * Helper method for performing user email update on Raa account
	 * 
	 * @param newEmail
	 * @param authentication
	 * @return
	 */
	private boolean updateRaaPersonalUserAccessEmail(String newEmail, Authentication authentication) {

		Authentication foundAuth = null;
		if (StringUtils.isBlank(newEmail) || authentication == null) {
			return false;
		}
		//Check if Email exist
		foundAuth = authenticationService.findByEmailAddressIgnoreCase(newEmail);
		if(foundAuth != null){
			return false;
		}
		authentication.setEmailAddress(StringUtils.upperCase(newEmail));
		return authenticationService.update(authentication);
	}
	
	/***
	 * 
	 * Helper method for performing user email update on Raa account
	 * 
	 * @param newEmail
	 * @param authentication
	 * @return
	 */
	private boolean updateRaaPersonalUserAccessEmail(String newEmail, String usageType, Authentication authentication) {

		Authentication foundAuth = null;
		if (StringUtils.isBlank(newEmail) || authentication == null) {
			return false;
		}
		//Check if Email exist
		foundAuth = authenticationService.findByEmailAddressAndUsageTypeIgnoreCase(newEmail, usageType);
		if(foundAuth != null){
			return false;
		}
		authentication.setEmailAddress(StringUtils.upperCase(newEmail));
		return authenticationService.update(authentication);
	}

	
	/**
	 * Helper method for performing user email update on TAM account
	 * 
	 * @param newEmail
	 * @return
	 */
	private boolean updateTamPersonalUserAccessEmail(String oldEmail, String newEmail) {
		//FIXME should add more validations on emails
		if (StringUtils.isNotEmpty(newEmail)) {
			try {
				accessManagerBean.getUserAccountService().updateUserID(this.secureDomain, oldEmail, newEmail);
				return true;
			} catch (AccessManagerException e) {
				//FIXME:Veracode vulnarability fix. we should likely have a uniform method using ESAPI
				//library sanitaze data input
				//LOG.error("Could not update TAM account with userId: " + oldEmail, e);
				LOG.error(Logger.EVENT_FAILURE,"Could not update TAM ", e);
				return false;
			}
		}
		return false;
	}
	
	/**
	 * Helper method for performing user email update on TAM account
	 * 
	 * @param newEmail
	 * @return
	 */
	private boolean updateTamPersonalUserAccessEmail(SecureDomain secureDomain, String oldEmail, String newEmail) {
		
		if (StringUtils.isNotEmpty(newEmail)) {
			try {
				accessManagerBean.getUserAccountService().updateUserID(secureDomain, oldEmail, newEmail);
				return true;
			} catch (AccessManagerException e) {
				LOG.error(Logger.EVENT_FAILURE,"Could not update TAM ", e);
				return false;
			}
		}
		return false;
	}

	
	/**
	 * Delete user account from Raa Database and  from Tam repository
	 * The calling order of sub methods are important
	 * 
	 * @return boolean
	 */
	@Deprecated
	@Override
	public boolean deletePersonalUserAccess(Long authenticationId) {
		return deletePersonalUserAccess(authenticationId,SecureDomain.DEFAULT);
		
	}
	

	@Override
	public boolean deletePersonalUserAccess(Long authenticationId, SecureDomain secureDomain) {
		Authentication authentication = authenticationService.findOne(authenticationId);
		return (deleteRaaPersonalUserAccess(authentication) && deleteTamPersonalUserAccess(authentication,secureDomain));
	}

	/**
	 * Performs an update of user Email on both TAM and Raa repository 
	 * 
	 * @param newEmail
	 * @return boolean
	 */
	@Override
	public boolean updatePersonalUserAccessEmail(ISystemAccessor systemAccessor, String newEmail) {
		Authentication authentication = authenticationService.findOne(systemAccessor.getSystemAccessorId());
		if (authentication != null) {
			boolean updateRaaPersonalUserAccessEmail = updateRaaPersonalUserAccessEmail(newEmail, authentication);
			String oldEmail = systemAccessor.getUserId();
			boolean updateTamPersonalUserAccessEmail = updateTamPersonalUserAccessEmail(oldEmail, newEmail);
			return (updateRaaPersonalUserAccessEmail && updateTamPersonalUserAccessEmail);
		}
		return false;
	}
	
	@Override
	public boolean updatePersonalUserAccessEmail(SecureDomain secureDomain, ISystemAccessor systemAccessor,
			String newEmail, String usageType) {
		Authentication authentication = authenticationService.findOne(systemAccessor.getSystemAccessorId());
		if (authentication != null) {
			return (updateRaaPersonalUserAccessEmail(newEmail, authentication) && updateTamPersonalUserAccessEmail(secureDomain,systemAccessor.getUserId(), newEmail));
		}
		return false;
	}

	
	/**
	 * Performs an update of user Email on both TAM and Raa repository 
	 * 
	 * @param newEmail
	 * @return boolean
	 */
	@Override
	public boolean updatePersonalUserAccessEmail(ISystemAccessor systemAccessor, String newEmail, String usageType) {
		Authentication authentication = authenticationService.findOne(systemAccessor.getSystemAccessorId());
		if (authentication != null) {
			boolean updateRaaPersonalUserAccessEmail = updateRaaPersonalUserAccessEmail(newEmail, usageType, authentication);
			String oldEmail = systemAccessor.getUserId();
			boolean updateTamPersonalUserAccessEmail = updateTamPersonalUserAccessEmail(oldEmail, newEmail);
			return (updateRaaPersonalUserAccessEmail && updateTamPersonalUserAccessEmail);
		}
		return false;
	}

	@Override
	public void updatePersonalUserAccessPassword(ISystemAccessor systemAccessor,String password) throws AccessManagerException {
		User user = accessManagerBean.getUserAccountService().getUser(this.secureDomain, systemAccessor.getUserId());

		if (user.getValidationAttempNb() > 0) {
			user.setValidationAttempNb(0);
			accessManagerBean.getUserAccountService().updateUser(this.secureDomain, user);
		}
		accessManagerBean.getUserAccountService().changePassword(this.secureDomain, systemAccessor.getUserId(), password);
	}

	@Override
	public ISystemAccessor getPersonalUserAccess(Long authenticationId) {
		Authentication authentication = authenticationService.findOne(authenticationId);
		ISystemAccessor systemAccessor = null;
		if(authentication != null){
			systemAccessor = new PersonalUserAccess();
			systemAccessor.setUserId(authentication.getEmailAddress());
			systemAccessor.setSystemAccessorId(authentication.getAuthenticationId());
		}
		
		return systemAccessor;
	}

	@Override
	public int validateCurrentPassword(ISystemAccessor systemAccessor, String currentPassword) throws AccessManagerException {
		int result = accessManagerBean.getUserAccountService().authenticate(this.secureDomain, systemAccessor.getUserId(), currentPassword);
		if (result == IUserAccountService.AUTH_SUCCESS || result == IUserAccountService.AUTH_LOCKED ) {
			return result;
		} else {
			User user = accessManagerBean.getUserAccountService().getUser(this.secureDomain, systemAccessor.getUserId());
			if (user.getValidationAttempNb() >= 2) {
				accessManagerBean.getUserAccountService().lockAccount(this.secureDomain, systemAccessor.getUserId());
				// put attempt to 0 after locking account to allow reset with temporary password
				user.setValidationAttempNb(0);
				accessManagerBean.getUserAccountService().updateUser(this.secureDomain, user);
				return IUserAccountService.AUTH_LOCKED;
			} else {
				user.setValidationAttempNb(user.getValidationAttempNb() + 1);
				accessManagerBean.getUserAccountService().updateUser(this.secureDomain, user);
				return IUserAccountService.AUTH_FAILED;
			}
		}
	}
}

