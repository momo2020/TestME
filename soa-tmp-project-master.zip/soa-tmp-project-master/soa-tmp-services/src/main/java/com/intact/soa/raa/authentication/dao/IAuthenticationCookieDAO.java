/**
 * 
 */
package com.intact.soa.raa.authentication.dao;

import java.util.List;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.AuthenticationCookie;

/**
 * The Interface IAuthenticationCookieDAO.
 *
 * @author vmathieu
 */
public interface IAuthenticationCookieDAO {

	/**
	 * delete row in database.
	 *
	 * @param authenticationCookie the authentication cookie
	 */
	void fullDelete(AuthenticationCookie authenticationCookie);


	/**
	 * Find by authentication cookie uu id.
	 *
	 * @param cookieId the cookie id
	 * @return the authentication cookie
	 */
	AuthenticationCookie findByAuthenticationCookieUuId(String cookieId);


	/**
	 * Find by authentication.
	 *
	 * @param authentication the authentication
	 * @return the list
	 */
	List<AuthenticationCookie> findByAuthentication(
			Authentication authentication);


	/**
	 * Persist.
	 *
	 * @param authenticationCookie the authentication cookie
	 * @return the authentication cookie
	 */
	AuthenticationCookie persist(AuthenticationCookie authenticationCookie);

}
