/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance
* Copyright (c) 2015, Intact Insurance, All rights reserved.<br>
*/
package com.intact.soa.utility.sas.repository.modifysystemaccessor.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ing.canada.singleid.accessmanager.domain.SecureDomain;
import com.ing.canada.singleid.accessmanager.exception.AccessManagerException;
import com.intact.bod.bco.party.ISystemAccessor;
import com.intact.soa.raa.authentication.service.IModifySystemAccessorService;


@Component
public class ModifySystemAccessorController implements
		IModifySystemAccessorController {
	
	@Autowired
	private IModifySystemAccessorService   modifySystemAccessService;
	
	/* (non-Javadoc)
	 * @see com.intact.soa.utility.sas.repository.modifysystemaccessor.controller.IModifySystemAccessorController#deleteSystemAccessor(com.intact.bod.bco.party.ISystemAccessor)
	 */
	@Deprecated
	@Override
	public boolean deleteSystemAccessor(ISystemAccessor systemAccessor) {
		return deleteSystemAccessor(systemAccessor, SecureDomain.DEFAULT);
	}
	

	@Override
	public boolean deleteSystemAccessor(ISystemAccessor systemAccessor, SecureDomain secureDomain) {
		  return modifySystemAccessService.deletePersonalUserAccess(systemAccessor.getSystemAccessorId(),secureDomain);

	}

	/* (non-Javadoc)
	 * @see com.intact.soa.utility.sas.repository.modifysystemaccessor.controller.IModifySystemAccessorController#updateSystemAccessor(com.intact.bod.bco.party.ISystemAccessor)
	 * 
	 * 
	 */
	@Override
	public boolean updateSystemAccessor(ISystemAccessor systemAccessor, String newEmail, String usageType) {
		return modifySystemAccessService.updatePersonalUserAccessEmail(systemAccessor, newEmail, usageType);
	}
	

	@Override
	public boolean updateSystemAccessor(SecureDomain secureDomain, ISystemAccessor systemAccessor, String newEmail,
			String usageType) {
		return modifySystemAccessService.updatePersonalUserAccessEmail(secureDomain,systemAccessor, newEmail, usageType);

	}

	/**
	 * 
	 * @see com.intact.soa.utility.sas.repository.modifysystemaccessor.controller.IModifySystemAccessorController#updateSystemAccessor(com.intact.bod.bco.party.ISystemAccessor, java.lang.String)
	 */
	@Override
	public boolean updateSystemAccessor(ISystemAccessor systemAccessor, String newEmail) {
		return modifySystemAccessService.updatePersonalUserAccessEmail(systemAccessor, newEmail);
	}
	
	@Override
	public void updatePassword(ISystemAccessor systemAccessor, String password) throws AccessManagerException {
		modifySystemAccessService.updatePersonalUserAccessPassword(systemAccessor, password);
	}

	@Override
	public ISystemAccessor getPersonalUserAccess(Long authenticationId) {
		return modifySystemAccessService.getPersonalUserAccess(authenticationId);
	}

	@Override
	public int validateCurrentPassword(ISystemAccessor systemAccessor, String currentPassword) throws AccessManagerException {
		return modifySystemAccessService.validateCurrentPassword(systemAccessor,currentPassword);
	}


}
