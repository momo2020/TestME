package com.intact.soa.raa.authentication.dao;



import java.util.List;

import com.intact.raa.domain.authentication.AuthenticationClientRel;



/**
 * The Interface IAuthenticationClientRelDAO.
 */
public interface IAuthenticationClientRelDAO {
	
	/**
	 * Find by authentication id.
	 *
	 * @param authenticationId the authentication id
	 * @return the list
	 */
	public List<AuthenticationClientRel>  findByAuthenticationId(long authenticationId);
	
	/**
	 * Delete by authentication id.
	 *
	 * @param authenthicationId the authenthication id
	 */
	public void deleteByAuthenticationId( long authenthicationId);

	/**
	 * Delete row in database.
	 *
	 * @param authenticationClientRel the authentication client rel
	 */
	public void fullDelete(AuthenticationClientRel authenticationClientRel);

	/**
	 * Persist.
	 *
	 * @param authenticationClientRel the authentication client rel
	 * @return the authentication client rel
	 */
	public AuthenticationClientRel persist(
			AuthenticationClientRel authenticationClientRel);

}
