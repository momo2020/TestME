/**
 * 
 */
package com.intact.soa.raa.authentication.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.owasp.esapi.ESAPI;
import org.owasp.esapi.Logger;
import org.springframework.stereotype.Repository;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.ClientRegistrationRestriction;
import com.intact.soa.raa.authentication.dao.IClientRegistrationRestrictionDAO;

/**
 * The Class ClientRegistrationRestrictionDAOImpl.
 *
 * @author vmathieu
 */
@Repository
public class ClientRegistrationRestrictionDAOImpl implements
		IClientRegistrationRestrictionDAO {

	/** The log. */
	protected final Logger log = ESAPI.getLogger(ClientRegistrationRestrictionDAOImpl.class);
	
	/** The entity manager. */
	@PersistenceContext(unitName="soaraa_persistence_unit")
	protected EntityManager entityManager;

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IClientRegistrationRestrictionDAO#fullDelete(com.intact.raa.domain.authentication.ClientRegistrationRestriction)
	 */
	@Override
	public void fullDelete(
			ClientRegistrationRestriction clientRegistrationRestriction) {
		entityManager.remove(clientRegistrationRestriction);
		
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IClientRegistrationRestrictionDAO#findResetPasswordBlock(com.intact.raa.domain.authentication.Authentication)
	 */
	@Override
	public List<ClientRegistrationRestriction> findResetPasswordBlock(
			Authentication authentication) {
		Query query = entityManager.createNamedQuery("ClientRegistrationRestriction.findResetPasswordBlock");
		query.setParameter("authentication", authentication);
		
		@SuppressWarnings("unchecked")
		List<ClientRegistrationRestriction> clientRegistrationRestrictions = query.getResultList();
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"findResetPasswordBlock query returned " + clientRegistrationRestrictions.size() + " ClientRegistrationRestriction objects");
		}
		return clientRegistrationRestrictions;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IClientRegistrationRestrictionDAO#findRegisterBlock(java.lang.Long)
	 */
	@Override
	public List<ClientRegistrationRestriction> findRegisterBlock(Long cliClient) {
		Query query = entityManager.createNamedQuery("ClientRegistrationRestriction.findRegisterBlock");
		query.setParameter("cliClient", cliClient);
		
		@SuppressWarnings("unchecked")
		List<ClientRegistrationRestriction> clientRegistrationRestrictions = query.getResultList();
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"findRegisterBlock query returned " + clientRegistrationRestrictions.size() + " ClientRegistrationRestriction objects");
		}
		return clientRegistrationRestrictions;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IClientRegistrationRestrictionDAO#findAlive(java.lang.Long, com.intact.raa.domain.authentication.Authentication)
	 */
	@Override
	public List<ClientRegistrationRestriction> findAlive(Long cliClient,
			Authentication authentication) {
		Query query = entityManager.createNamedQuery("ClientRegistrationRestriction.findAlive");
		query.setParameter("cliClient", cliClient);
		
		@SuppressWarnings("unchecked")
		List<ClientRegistrationRestriction> clientRegistrationRestrictions = query.getResultList();
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"findAlive query returned " + clientRegistrationRestrictions.size() + " ClientRegistrationRestriction objects");
		}
		return clientRegistrationRestrictions;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IClientRegistrationRestrictionDAO#findByAuthentication(com.intact.raa.domain.authentication.Authentication)
	 */
	@Override
	public List<ClientRegistrationRestriction> findByAuthentication(
			Authentication authentication) {
		Query query = entityManager.createNamedQuery("ClientRegistrationRestriction.findByAuthentication");
		query.setParameter("authentication", authentication);
		
		@SuppressWarnings("unchecked")
		List<ClientRegistrationRestriction> clientRegistrationRestrictions = query.getResultList();
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"findByAuthentication query returned " + clientRegistrationRestrictions.size() + " ClientRegistrationRestriction objects");
		}
		return clientRegistrationRestrictions;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IClientRegistrationRestrictionDAO#findByCliClient(java.lang.Long)
	 */
	@Override
	public List<ClientRegistrationRestriction> findByCliClient(Long clientId) {
		Query query = entityManager.createNamedQuery("ClientRegistrationRestriction.findByCliClient");
		query.setParameter("cliClient", clientId);
		
		@SuppressWarnings("unchecked")
		List<ClientRegistrationRestriction> clientRegistrationRestrictions = query.getResultList();
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"findByCliClient query returned " + clientRegistrationRestrictions.size() + " ClientRegistrationRestriction objects");
		}
		return clientRegistrationRestrictions;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IClientRegistrationRestrictionDAO#persist(com.intact.raa.domain.authentication.ClientRegistrationRestriction)
	 */
	@Override
	public ClientRegistrationRestriction persist(
			ClientRegistrationRestriction clientRegistrationRestriction) {
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_UNSPECIFIED,"about to persist a entity: " + clientRegistrationRestriction);
		}
		
		if (clientRegistrationRestriction.getClientRegRestrictionId() != null && !this.entityManager.contains(clientRegistrationRestriction) ) {
			this.entityManager.merge(clientRegistrationRestriction);
		} else {
			this.entityManager.persist(clientRegistrationRestriction);
		}
		
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"merged/persisted a " + clientRegistrationRestriction + " instance");
		}
		return clientRegistrationRestriction;
	}
	
}
