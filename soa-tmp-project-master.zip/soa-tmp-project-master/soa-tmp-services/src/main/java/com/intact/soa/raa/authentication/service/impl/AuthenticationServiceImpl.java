package com.intact.soa.raa.authentication.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.soa.raa.authentication.dao.IAuthenticationDAO;
import com.intact.soa.raa.authentication.service.IAuthenticationService;

@Service
@Transactional
public class AuthenticationServiceImpl implements IAuthenticationService {

	@Autowired
	private IAuthenticationDAO authenticationDAO;

	@Override
	public Authentication findByEmailAddressIgnoreCase(String email) {
		return this.authenticationDAO.findByEmailAddressIgnoreCase(email);
	}

	@Override
	public Authentication findByEmailAddressAndUsageTypeIgnoreCase(String email, String usageType) {
		return this.authenticationDAO.findByEmailAddressAndUsageTypeIgnoreCase(email, usageType);
	}
	
	@Override
	public Authentication findByClientId(long clientId) {
		return this.authenticationDAO.findByClientId(clientId);
	}

	@Override
	public Authentication findOne(Long id) {
		return authenticationDAO.findOne(id);
	}

	@Override
	public void delete(Authentication authenticationObject) {
		authenticationDAO.delete(authenticationObject);
	}

	@Override
	public boolean update(Authentication authentication) {
		Authentication updatedAuthObject = authenticationDAO.update(authentication);
		return updatedAuthObject.getEmailAddress().equalsIgnoreCase(authentication.getEmailAddress());
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public Authentication save(Authentication authentication) {
		return authenticationDAO.persist(authentication);
	}

	@Override
	public void fullDelete(Authentication authentication) {
		authenticationDAO.fullDelete(authentication);
	}

}
