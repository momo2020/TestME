package com.intact.soa.utility.communicationservice.model;

public enum EmailCommunicationEnum {

	RESET_PASSWORD,
	WELCOME_EMAIL
	
}

