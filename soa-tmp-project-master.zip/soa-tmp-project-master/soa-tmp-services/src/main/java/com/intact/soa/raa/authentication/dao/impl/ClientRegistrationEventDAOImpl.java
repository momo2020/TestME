package com.intact.soa.raa.authentication.dao.impl;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.owasp.esapi.ESAPI;
import org.owasp.esapi.Logger;
import org.springframework.stereotype.Repository;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.ClientRegistrationEvent;
import com.intact.soa.raa.authentication.dao.IClientRegistrationEventDAO;

/**
 * The Class ClientRegistrationEventDAOImpl.
 */
@Repository
public class ClientRegistrationEventDAOImpl implements IClientRegistrationEventDAO {

	/** The log. */
	protected final Logger log = ESAPI.getLogger(ClientRegistrationEventDAOImpl.class);
	
	/** The entity manager. */
	@PersistenceContext(unitName="soaraa_persistence_unit")
	protected EntityManager entityManager;
	
	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IClientRegistrationEventDAO#persist(com.intact.raa.domain.authentication.ClientRegistrationEvent)
	 */
	@Override
	public ClientRegistrationEvent persist(ClientRegistrationEvent clientRegistrationEvent) {
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_UNSPECIFIED,"about to persist a entity: " + clientRegistrationEvent);
		}

		if (clientRegistrationEvent.getClientRegEventId() != null && !this.entityManager.contains(clientRegistrationEvent) ) {
			this.entityManager.merge(clientRegistrationEvent);
		} else {
			this.entityManager.persist(clientRegistrationEvent);
		}
		
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"persisted a " + clientRegistrationEvent + " instance");
		}
		return clientRegistrationEvent;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IClientRegistrationEventDAO#fullDelete(com.intact.raa.domain.authentication.ClientRegistrationEvent)
	 */
	@Override
	public void fullDelete(ClientRegistrationEvent clientRegistrationEvent) {
		entityManager.remove(clientRegistrationEvent);		
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IClientRegistrationEventDAO#findResetPasswordAttempts(com.intact.raa.domain.authentication.Authentication, java.util.Date)
	 */
	@Override
	public List<ClientRegistrationEvent> findResetPasswordAttempts(
			Authentication authentication, Date startDate) {
		Query query = entityManager.createNamedQuery("ClientRegistrationEvent.findResetPasswordAttempts");
		query.setParameter("authentication", authentication);
		query.setParameter("startDate", startDate);
		
		@SuppressWarnings("unchecked")
		List<ClientRegistrationEvent> clientRegistrationEvents = query.getResultList();
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"findResetPasswordAttempts query returned " + clientRegistrationEvents.size() + " ClientRegistrationEvent objects");
		}
		return clientRegistrationEvents;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IClientRegistrationEventDAO#findRegisterAttempts(java.lang.Long, java.util.Date)
	 */
	@Override
	public List<ClientRegistrationEvent> findRegisterAttempts(Long cliClient,
			Date startDate) {
		Query query = entityManager.createNamedQuery("ClientRegistrationEvent.findRegisterAttempts");
		query.setParameter("cliClient", cliClient);
		query.setParameter("startDate", startDate);
		
		@SuppressWarnings("unchecked")
		List<ClientRegistrationEvent> clientRegistrationEvents = query.getResultList();
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"findRegisterAttempts query returned " + clientRegistrationEvents.size() + " ClientRegistrationEvent objects");
		}
		return clientRegistrationEvents;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IClientRegistrationEventDAO#findAlive(java.lang.Long, com.intact.raa.domain.authentication.Authentication)
	 */
	@Override
	public List<ClientRegistrationEvent> findAlive(Long cliClient,
			Authentication authentication) {
		Query query = entityManager.createNamedQuery("ClientRegistrationEvent.findAlive");
		query.setParameter("cliClient", cliClient);
		query.setParameter("authentication", authentication);
		
		@SuppressWarnings("unchecked")
		List<ClientRegistrationEvent> clientRegistrationEvents = query.getResultList();
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"findAlive query returned " + clientRegistrationEvents.size() + " ClientRegistrationEvent objects");
		}
		return clientRegistrationEvents;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IClientRegistrationEventDAO#findByAuthentication(com.intact.raa.domain.authentication.Authentication)
	 */
	@Override
	public List<ClientRegistrationEvent> findByAuthentication(
			Authentication authentication) {
		Query query = entityManager.createNamedQuery("ClientRegistrationEvent.findByAuthentication");
		query.setParameter("authentication", authentication);
		
		@SuppressWarnings("unchecked")
		List<ClientRegistrationEvent> clientRegistrationEvents = query.getResultList();
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"findByAuthentication query returned " + clientRegistrationEvents.size() + " ClientRegistrationEvent objects");
		}
		return clientRegistrationEvents;
	}

	/* (non-Javadoc)
	 * @see com.intact.soa.raa.authentication.dao.IClientRegistrationEventDAO#findByCliClient(java.lang.Long)
	 */
	@Override
	public List<ClientRegistrationEvent> findByCliClient(Long cliClient) {
		Query query = entityManager.createNamedQuery("ClientRegistrationEvent.findByCliClient");
		query.setParameter("cliClient", cliClient);
		
		@SuppressWarnings("unchecked")
		List<ClientRegistrationEvent> clientRegistrationEvents = query.getResultList();
		if (log.isDebugEnabled()) {
			log.debug(Logger.EVENT_SUCCESS,"findByCliClient query returned " + clientRegistrationEvents.size() + " ClientRegistrationEvent objects");
		}
		return clientRegistrationEvents;
	}
}
