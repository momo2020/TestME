/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.intact.soa.raa.stereotype;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * @author mblouin
 * 
 */
public class ApplicationContextHolder implements ApplicationContextAware {
	@SuppressWarnings("unused")

	/** Contexte Spring injected directly */
	private static ApplicationContext context = null;

	/**
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 */
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		ApplicationContextHolder.context = applicationContext;

	}

	/**
	 * @return the context
	 */
	public static ApplicationContext getApplicationContext() {
		return context;
	}

	/**
	 * Gets the bean.
	 * 
	 * @param beanName the bean name
	 * 
	 * @return the bean
	 */
	public static Object getBean(String beanName) {
		return context.getBean(beanName);

	}
}
