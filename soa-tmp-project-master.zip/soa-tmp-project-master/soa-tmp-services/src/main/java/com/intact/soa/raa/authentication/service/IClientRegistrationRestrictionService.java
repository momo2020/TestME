/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance
* Copyright (c) 2015, Intact Insurance, All rights reserved.<br>
*/
package com.intact.soa.raa.authentication.service;

import java.util.List;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.ClientRegistrationRestriction;

/**
 * The Interface IClientRegistrationRestrictionService.
 *
 */
public interface IClientRegistrationRestrictionService {
	
	/**
	 * Find reset password block.
	 *
	 * @param authentication the authentication
	 * @return the list
	 */
	/*@Query("select crr from ClientRegistrationRestriction crr where crr.authentication = ?1 and crr.endDate > CURRENT_DATE" +
			" and crr.restrictionType = 'EMAIL_BLOCKED'")
			*/
	public List<ClientRegistrationRestriction> findResetPasswordBlock(Authentication authentication);

	/**
	 * Find register block.
	 *
	 * @param cliClient the cli client
	 * @return the list
	 */
	/*@Query("select crr from ClientRegistrationRestriction crr where crr.cliClient = ?1 and crr.endDate > CURRENT_DATE" +
			" and crr.restrictionType = 'REG_BLOCKED'")
			*/
	public List<ClientRegistrationRestriction> findRegisterBlock(Long cliClient);
	
	/**
	 * Find client registration restrictions for which the endDate is null or in the future.
	 *
	 * @param cliClient the cli client
	 * @param authentication the authentication
	 * @return the list
	 */
	/*@Query("select crr from ClientRegistrationRestriction crr where (crr.cliClient = ?1" +
			" or crr.authentication = ?2) and (crr.endDate is null or crr.endDate > CURRENT_DATE)")
			*/
	public List<ClientRegistrationRestriction> findAlive(Long cliClient, Authentication authentication);
	
	/**
	 * Find by authentication.
	 *
	 * @param authentication the authentication
	 * @return the list
	 */
	public List<ClientRegistrationRestriction> findByAuthentication(Authentication authentication);

	/**
	 * Find by cli client.
	 *
	 * @param clientId the client id
	 * @return the list
	 */
	public List<ClientRegistrationRestriction> findByCliClient(Long clientId);
	
	/**
	 * delete row in database
	 *
	 * @param clientRegistrationRestrictions the client registration restrictions
	 */
	public void fullDelete(List<ClientRegistrationRestriction> clientRegistrationRestrictions);

	/**
	 * Save.
	 *
	 * @param clientRegistrationRestriction the client registration restriction
	 * @return the client registration restriction
	 */
	public ClientRegistrationRestriction save(ClientRegistrationRestriction clientRegistrationRestriction);
}
