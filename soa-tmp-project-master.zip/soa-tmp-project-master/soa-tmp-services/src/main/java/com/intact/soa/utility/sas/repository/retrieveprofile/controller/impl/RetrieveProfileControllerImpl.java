package com.intact.soa.utility.sas.repository.retrieveprofile.controller.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.intact.bod.bco.party.ISystemAccessor;
import com.intact.bod.bco.party.impl.PersonalUserAccess;
import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.AuthenticationClientRel;
import com.intact.soa.raa.authentication.service.IAuthenticationClientRelService;
import com.intact.soa.raa.authentication.service.IAuthenticationService;
import com.intact.soa.utility.sas.repository.exception.SasException;
import com.intact.soa.utility.sas.repository.retrieveprofile.controller.IRetrieveProfileController;

@Component
public class RetrieveProfileControllerImpl implements IRetrieveProfileController {

	@Autowired
	private IAuthenticationService authenticationService;
	
	@Autowired
	private IAuthenticationClientRelService authenClientRelService;
	
	@Override
	public ISystemAccessor retrieveSystemAccessorByEmail(String userEmail) throws SasException {
		
		ISystemAccessor systemAccessor = null;
		Authentication authentication = authenticationService.findByEmailAddressIgnoreCase(userEmail);
		if (authentication!=null) {
			systemAccessor = new PersonalUserAccess();
			systemAccessor.setSystemAccessorId(authentication.getAuthenticationId());
		}
		return systemAccessor;
	}
	
	@Override
	public ISystemAccessor retrieveSystemAccessorByEmailAndUsageType(String userEmail, String usageType) throws SasException {
		
		ISystemAccessor systemAccessor = null;
		Authentication authentication = authenticationService.findByEmailAddressAndUsageTypeIgnoreCase(userEmail, usageType);
		if (authentication!=null) {
			systemAccessor = new PersonalUserAccess();
			systemAccessor.setSystemAccessorId(authentication.getAuthenticationId());
		}
		return systemAccessor;
	}
	
	@Override
	public ISystemAccessor retrieveSystemAccessorByClientId(Long clientId) throws SasException {
		
		ISystemAccessor systemAccessor = null;
		Authentication authentication = authenticationService.findByClientId(clientId);
		if (authentication!=null) {
			systemAccessor = new PersonalUserAccess();
			systemAccessor.setSystemAccessorId(authentication.getAuthenticationId());
			systemAccessor.setUserId(authentication.getEmailAddress());
		}
		return systemAccessor;
	}

	@Override
	public List<Long> retrieveClientIdsByAuthenticationId(Long authenticationId) {		
		 List<Long> clientIds = new ArrayList<Long>();		 
		List<AuthenticationClientRel> clientsRel = authenClientRelService.findByAuthenticationId(authenticationId);
		
		if (clientsRel != null){
			for (AuthenticationClientRel authenticationClientRel : clientsRel){
				clientIds.add(authenticationClientRel.getCliClient());
			}
		}
		
		return clientIds;
	}
}
