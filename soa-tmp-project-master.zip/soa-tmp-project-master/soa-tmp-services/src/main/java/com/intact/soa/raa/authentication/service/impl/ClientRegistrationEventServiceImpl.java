package com.intact.soa.raa.authentication.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.ClientRegistrationEvent;
import com.intact.soa.raa.authentication.dao.IClientRegistrationEventDAO;
import com.intact.soa.raa.authentication.service.IClientRegistrationEventService;

@Service
@Transactional
public class ClientRegistrationEventServiceImpl implements IClientRegistrationEventService {

	@Autowired
	private IClientRegistrationEventDAO clientRegistrationEventDAO;

	@Override
	public List<ClientRegistrationEvent> findResetPasswordAttempts(Authentication authentication, Date startDate) {
		return clientRegistrationEventDAO.findResetPasswordAttempts(authentication, startDate);
	}

	@Override
	public List<ClientRegistrationEvent> findRegisterAttempts(Long cliClient, Date startDate) {
		return clientRegistrationEventDAO.findRegisterAttempts(cliClient, startDate);
	}

	@Override
	public List<ClientRegistrationEvent> findAlive(Long cliClient, Authentication authentication) {
		return clientRegistrationEventDAO.findAlive(cliClient, authentication);
	}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public ClientRegistrationEvent persist(ClientRegistrationEvent clientRegistrationEvent) {
		ClientRegistrationEvent registrationEvent = clientRegistrationEventDAO.persist(clientRegistrationEvent);
		return registrationEvent;
	}

	@Override
	public List<ClientRegistrationEvent> findByAuthentication(
			Authentication authentication) {
		return clientRegistrationEventDAO.findByAuthentication(authentication);
	}

	@Override
	public List<ClientRegistrationEvent> findByCliClient(Long cliClient) {
		return clientRegistrationEventDAO.findByCliClient(cliClient);
	}

	@Override
	public void fullDelete(List<ClientRegistrationEvent> clientRegistrationEvents) {
		for (ClientRegistrationEvent clientRegistrationEvent : clientRegistrationEvents){
			clientRegistrationEventDAO.fullDelete(clientRegistrationEvent);
		}
		
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public ClientRegistrationEvent save(
			ClientRegistrationEvent clientRegistrationEvent) {
		return clientRegistrationEventDAO.persist(clientRegistrationEvent);
	}

}
