/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance
* Copyright (c) 2015, Intact Insurance, All rights reserved.<br>
*/
package com.intact.soa.raa.authentication.service;

import java.util.Collection;
import java.util.List;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.AuthenticationClientRel;

/**
 * Authentication Client Relation Service.
 *
 * @author vmathieu
 */
public interface IAuthenticationClientRelService {

	/**
	 * Find by authentication.
	 *
	 * @param authentication the authentication
	 * @return the list
	 */
	//@Query("select acr from AuthenticationClientRel acr where acr.authentication = ?1 and (acr.endDate is null or acr.endDate > CURRENT_DATE)")
	List<AuthenticationClientRel> findByAuthentication(Authentication authentication);
	
	/**
	 * Find by authentication id.
	 *
	 * @param authenticationId the authentication id
	 * @return the list
	 */
	public List<AuthenticationClientRel> findByAuthenticationId(long authenticationId);
	
	/**
	 * Delete by authentication id.
	 *
	 * @param authenticationId the authentication id
	 */
	public void deleteByAuthenticationId( long authenticationId);
	
	/**
	 * delete row in database
	 *
	 * @param authenticationClientRels the authentication client rels
	 */
	public void fullDelete(List<AuthenticationClientRel> authenticationClientRels);
	
	/**
	 * Save.
	 *
	 * @param authenticationClientRel the authentication client rel
	 * @return the authentication client rel
	 */
	public AuthenticationClientRel save(AuthenticationClientRel authenticationClientRel);
	
	/**
	 * Save.
	 *
	 * @param authenticationClientRels the authentication client rels
	 */
	public void save(Collection<AuthenticationClientRel> authenticationClientRels);
}
