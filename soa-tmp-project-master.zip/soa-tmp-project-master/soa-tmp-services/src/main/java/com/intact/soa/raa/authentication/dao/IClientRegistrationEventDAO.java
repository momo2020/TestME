package com.intact.soa.raa.authentication.dao;

import java.util.Date;
import java.util.List;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.ClientRegistrationEvent;

/**
 * The Interface IClientRegistrationEventDAO.
 */
public interface IClientRegistrationEventDAO {

	/**
	 * Persist.
	 *
	 * @param clientRegistrationEvent the client registration event
	 * @return the client registration event
	 */
	ClientRegistrationEvent persist (ClientRegistrationEvent  clientRegistrationEvent);

	/**
	 * delete row in database
	 *
	 * @param clientRegistrationEvent the client registration event
	 */
	void fullDelete(ClientRegistrationEvent clientRegistrationEvent);

	/**
	 * Find reset password attempts.
	 *
	 * @param authentication the authentication
	 * @param startDate the start date
	 * @return the list
	 */
	List<ClientRegistrationEvent> findResetPasswordAttempts(
			Authentication authentication, Date startDate);

	/**
	 * Find register attempts.
	 *
	 * @param cliClient the cli client
	 * @param startDate the start date
	 * @return the list
	 */
	List<ClientRegistrationEvent> findRegisterAttempts(Long cliClient,
			Date startDate);

	/**
	 * Find not expired events.
	 *
	 * @param cliClient the cli client
	 * @param authentication the authentication
	 * @return the list
	 */
	List<ClientRegistrationEvent> findAlive(Long cliClient,
			Authentication authentication);

	/**
	 * Find by authentication.
	 *
	 * @param authentication the authentication
	 * @return the list
	 */
	List<ClientRegistrationEvent> findByAuthentication(
			Authentication authentication);

	/**
	 * Find by cli client.
	 *
	 * @param cliClient the cli client
	 * @return the list
	 */
	List<ClientRegistrationEvent> findByCliClient(Long cliClient);
}
