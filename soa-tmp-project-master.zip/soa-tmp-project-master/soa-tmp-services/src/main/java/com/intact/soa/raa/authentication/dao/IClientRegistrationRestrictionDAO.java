/**
 * 
 */
package com.intact.soa.raa.authentication.dao;

import java.util.List;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.ClientRegistrationRestriction;

/**
 * The Interface IClientRegistrationRestrictionDAO.
 *
 * @author vmathieu
 */
public interface IClientRegistrationRestrictionDAO {

	/**
	 * delete row in database
	 *
	 * @param clientRegistrationRestriction the client registration restriction
	 */
	void fullDelete(ClientRegistrationRestriction clientRegistrationRestriction);

	/**
	 * Find reset password block.
	 *
	 * @param authentication the authentication
	 * @return the list
	 */
	List<ClientRegistrationRestriction> findResetPasswordBlock(
			Authentication authentication);

	/**
	 * Find register block.
	 *
	 * @param cliClient the cli client
	 * @return the list
	 */
	List<ClientRegistrationRestriction> findRegisterBlock(Long cliClient);

	/**
	 * Find not expired restrictions.
	 *
	 * @param cliClient the cli client
	 * @param authentication the authentication
	 * @return the list
	 */
	List<ClientRegistrationRestriction> findAlive(Long cliClient,
			Authentication authentication);

	/**
	 * Find by authentication.
	 *
	 * @param authentication the authentication
	 * @return the list
	 */
	List<ClientRegistrationRestriction> findByAuthentication(
			Authentication authentication);

	/**
	 * Find by cli client.
	 *
	 * @param clientId the client id
	 * @return the list
	 */
	List<ClientRegistrationRestriction> findByCliClient(Long clientId);

	/**
	 * Persist.
	 *
	 * @param clientRegistrationRestriction the client registration restriction
	 * @return the client registration restriction
	 */
	ClientRegistrationRestriction persist(
			ClientRegistrationRestriction clientRegistrationRestriction);

}
