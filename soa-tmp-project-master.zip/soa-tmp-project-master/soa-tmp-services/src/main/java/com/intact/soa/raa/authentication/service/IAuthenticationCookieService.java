/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance
* Copyright (c) 2015, Intact Insurance, All rights reserved.<br>
*/
package com.intact.soa.raa.authentication.service;

import java.util.List;

import com.intact.raa.domain.authentication.Authentication;
import com.intact.raa.domain.authentication.AuthenticationCookie;

/**
 * Authentication Cookie Service.
 *
 */
public interface IAuthenticationCookieService {

	/**
	 * Find not expired cookies by authentication cookie uu id.
	 *
	 * @param cookieId the cookie id
	 * @return the authentication cookie
	 */
	//@Query("select ac from AuthenticationCookie ac where ac.authenticationCookieUuId = ?1 and ac.endDate > CURRENT_DATE")
	public AuthenticationCookie findByAuthenticationCookieUuId(String cookieId);
	
	/**
	 * Find by authentication.
	 *
	 * @param authentication the authentication
	 * @return the list
	 */
	//@Query("select ac from AuthenticationCookie ac where ac.authentication = ?1 ")
	public List<AuthenticationCookie> findByAuthentication(Authentication authentication);

	/**
	 * delete row in database
	 *
	 * @param authenticationCookies the authentication cookies
	 */
	public void fullDelete(List<AuthenticationCookie> authenticationCookies); 
	
	/**
	 * Save.
	 *
	 * @param authenticationCookie the authentication cookie
	 * @return the authentication cookie
	 */
	public AuthenticationCookie save(AuthenticationCookie authenticationCookie);
}
