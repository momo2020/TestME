# Openshift Templates

Here are [some details](docs/details.md)
