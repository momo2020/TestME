# intact-kit-starter
Kit de démarrage de projet INTACT

## Installation
* Télécharger les sources depuis RTC ;
* Aller dans le dossier de travail (au niveau du fichier package.json) ;
* Vérifier l'installation de NodeJs :
```javascript
node -v
> v10.x.x //Mac
> v4.x.x //PC
```
* Vérifier l'installation de npm :
```javascript
npm list
> --- (empty)
```
* Désactiver la restriction de certificat SSL pour l'url du repo. NPM :
```javascript
npm config set registry https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/content/repositories/npm-public/ 
```
* Installer les outils grunt et karma :
```javascript
npm install -g grunt
npm install -g grunt-cli
npm install -g karma-cli
```
* Modifier la variable d'environnement PATH :
* Aller dans Panneau de config. > Système et sécurité > Système > Param. système avancés ;
* Cliquer sur le bouton variable d'environnement ;
* Dans les variables utilisateurs ajouter/modifier la variable PATH ;
```javascript
;%USERPROFILE%\AppData\Roaming\npm;
```
* Relancer l'invite de commande (idéalement en mode administrateur) ;
* Se rendre au root du projet (Dossier contenant le Gruntfile == Gruntfile.js) ;
* Si un dossier node_modules existe le supprimer complètement ;
* Executer les commandes suivantes (depuis cmd.exe ou PowerShell) :
```javascript
npm install
// Pour démarrer le projet
grunt belair-dev
```
* Ouvrir votre navigateur à l'adresse du projet :[http://localhost:${port}](http://localhost:3001)
<br /><i>(attention l'adresse exacte est spécifiée dans l'output de l'invite de commande)</i>

### Problèmes possibles
le front end peut utiliser des mocks (serveur http local retournant des fichiers json statiques). Pour changer/vérifier l'adresse du serveur d'API utilisé :
* Aller dans le dossier > grunt-tasks > replace.js
* Vérifier la valeur du match API_REST_URL (si elle est de http://localhost:<%= globalConfig.applicationPort => alors le projet est en mock)
* Changer si nécessaire la valeur du port pour celle des environnement backend 

##### Impossible de compléter l'installation des modules via NPM
Vous devez redémarrer votre invite de commande (idéalement en tant qu'administrateur). Supprimez le dossier node_modules puis executer la commande suivante :
```javascript
npm cache clear
npm install
```
##### Grunt n'est pas reconnu comme commande
Vous devez vérifier que le PATH rentré pointe vers le dossier d'installation de NPM.

##### Grunt ne s'execute pas (pas de fichier gruntfile)
Vous devez vérifier que vous exécutez la commande grunt dans le dossier contenant le fichier Gruntfile.

### Tâches supplémentaires disponibles
* Génération de la documentation :<br/>Vous pouvez générer la documentation AngularJs du projet en lançant la commande :
```javascript
grunt ng-doc
> http://localhost:4001
```
* Optimisation du code javascript : <br />Vous pouvez lancer l'analyse du code javascript par la commande :
```javascript
grunt optimize
```

## En local via la jonction
* Demander la configuration de jonctions au HelpDesk (Martin Caron), suivant le modèle de votre copain (marfourn, par exemple)
* Vérifier la configuration: https://signature-dsso.iad.ca.inet/sil/jvminfo/junctions.php
* Backend REST: https://intg-intactinsurance-sso.iad.ca.inet/cc-mywinuser
* Frontend JS: https://intg-intactinsurance-sso.iad.ca.inet/cc-web-mywinuser
* "spoe.mode=false" dans /clientcentre-intact-external-config/src/main/filters/dev-default.properties
* Dans la tache grunt replace mettre dans la section DEV 'API_REST_URL' à 'https://intg-intactinsurance-sso.iad.ca.inet/cc-mywinuser'" et * "hostname: '*'" dans /clientcentre-project/clientcentre-appstatic-web/grunt-tasks/express.js
* Configurer votre serveur ClientCenter pour INTG

## Tests

### Tests Unitaires
Les tests unitaires sont fait avec Karma et Jasmine

Attention : Le Package Karma n'est présentement pas disponible sous Nexus !
* Un update Nexus est prévu en janvier 2016 pour régler la situation et permettre l'exécution des tests lors du processus de build sous Jenkins.

Les dépendances suivantes ont été ajouté sous 'optionalDependencies' dans le package.json :
```javascript
"grunt-karma": "^0.12.1",
"jasmine-core": "^2.3.4",
"karma": "^0.13.11",
"karma-chrome-launcher": "^0.2.1",
"karma-html-reporter": "^0.2.7",
"karma-jasmine": "^0.3.6",
"karma-junit-reporter": "^0.3.8",
"karma-coverage": "~0.5.0",
"karma-ng-html2js-preprocessor": "^0.2.0"
```
Les rapports générés par ces tests se retrouveront dans 'target/unit-tests'.
* Pour ajouter des tests dans d'autres browser que 'Chrome' présentement installé il faut en ajouter dans le fichier karma.conf.js et installer les plugins correspondants.
* Plusieurs types de rapports sont générés:
    - Des rapports de tests unitaires en format 'junit' consommable par Sonar dans 'target/unit-tests/report-summary-for-sonar/* browser name */test-results.xml'
    - Des rapports de tests unitaires en format 'html' pour Ãªtre visualisé dans un browser dans 'target/unit-tests/report-summary-html/index.html'
    - Des rapports de couverture de test en format 'lcov' consommable par Sonar dans 'target/unit-tests/coverage/* browser name */lcov.info'
    - Des rapports de couverture de test en format 'html' pour Ãªtre visualisé dans un browser dans 'target/unit-tests/coverage/* browser name */lcov-report/index.html'

Vous pouvez lancer les tests par la commande en local :
```javascript
grunt unit-tests
```
Une fois la tâche exécutée, analyser le rapport et corriger les erreurs/warning jusqu'à ce que la tâche s'exécute sans erreurs.

### Tests End-to-End
#### À venir
Vous pouvez lancer les tests par la commande en local :
```javascript
grunt e2e-tests
```

### Tests Accessibilité WCAG
Attention : Le Package html-snapshot n'est présentement pas disponible sous Nexus !
* Un update Nexus est prévu en janvier 2016 pour régler la situation et permettre l'exécution des tests lors du processus de build sous Jenkins.

Les dépendances suivantes ont été ajouté sous 'optionalDependencies' dans le package.json :
```javascript
"grunt-html-snapshot": "~0.6.1",
"grunt-accessibility": "3.5.1"
```
Les résultats des tests WCAG automatique doivent Ãªtre pris avec un grain de sel.
* Ils ne valide pas tout les paramÃªtres nécessaires pour Ãªtre valide WCAG.
* Ces tests sont des tests de base pour les éléments testables au niveau du code.
* Ces tests ne valide pas par exemples les contraste de couleurs de manière très fiable.
* La norme utilisée pour rouler les tests présentement est le WCAG A.
* Il conviendra de vérifier les lois en vigueur dans chacune des provinces canadiennes pour déterminer les normes légales nécessaires dans chacune de celle-ci et d'adapter les tests en conséquences.
* IL sera nécessaires de faire des tests manuelles pour vérifier de manière fiable le respect de chacune de ces normes.

Les rapports générés par ces tests se retrouveront dans 'target/wcag' en format json.

Vous pouvez lancer les tests par la commande en local :
```javascript
grunt wcag
```

## Déploiement du code (BUILD)
* Se placer au root du dossier clientcentre-appstatic-web ;
* Supprimer le dossier node_modules s'il existe ;
* NPM doit pointer vers le repository NEXUS de la compagnie :
```javascript
npm config set registry https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/content/repositories/npm-public/ 
npm config set strict-ssl=true
npm config set cafile={chemin vers le fichier dans la solution statique nexus-chain.pem}
```
* Exécuter les commandes suivantes :
```javascript
npm cache clean
npm install --production
grunt belair-build ou grunt intact-build
```
* Prendre le dossier généré dans le dossier /target ;
* Déployer ce dossier (intact ou belair) ;

## Documentation
La documentation frontend est gérée via le module grun-ng-doc disponible sur npm (cf. package.json).
Des changements mineurs ont été apportés au plugin pour fonctionner complètement notamment pour la navigation.
Pour avoir accès à ces changements, vous devez "mettre à jour" le module en écrasant les fichiers suivants dans le node module package :
* /src/ngdoc.js ;
* /src/templates/index.tmpl ;
* /tasks/grunt-ngdocs.js ;

* Se rendre sur https://github.com/fginioux/grunt-ngdocs;
* Télécharger les sources du module ;
* Faire les updates de fichiers.

Une fois mis à  jour ces fichiers, relancer la tache grunt :
```javascript
grunt ng-doc
```

### Pour en savoir plus :
* [https://nodejs.org/en/](https://nodejs.org/en/)
* [https://www.npmjs.com/](https://www.npmjs.com/)
* [http://gruntjs.com](http://gruntjs.com)
* [http://jshint.com](http://jshint.com)
* [https://github.com/angular/angular.js/wiki/Writing-AngularJS-Documentation](https://github.com/angular/angular.js/wiki/Writing-AngularJS-Documentation)
