
// Karma configuration
// Generated on Mon Oct 19 2015 17:07:40 GMT-0400 (EDT)
module.exports = function(config) {
  config.set({

    // base path that will be used to resolve all patterns (eg. files, exclude)
    basePath: '',

    // frameworks to use
    // available frameworks: https://npmjs.org/browse/keyword/karma-adapter
    frameworks: ['jasmine'],


    // list of files / patterns to load in the browser
    files: [
      'node_modules/jquery/dist/jquery.js',
      'node_modules/match-media/matchMedia.js',
      'node_modules/angular/angular.js',
      'node_modules/angular-i18n/angular-locale_fr-ca.js',
      'node_modules/angular-i18n/angular-locale_en-ca.js',
      'node_modules/angular-animate/angular-animate.js',
      'node_modules/angular-aria/angular-aria.js',
      'node_modules/angular-breadcrumb/dist/angular-breadcrumb.js',
      'node_modules/angular-cache/dist/angular-cache.js',
      'node_modules/angular-cookies/angular-cookies.js',
      'node_modules/angular-dynamic-locale/dist/tmhDynamicLocale.js',
      'node_modules/angular-filter/dist/angular-filter.js',
      'node_modules/angular-masonry/dist/angular-masonry.js',
      'node_modules/angular-mocks/angular-mocks.js',
      'node_modules/angular-modal-service/src/angular-modal-service.js',
      'node_modules/angular-pretty-xml/dist/angular-pretty-xml.js',
      'node_modules/angular-route/angular-route.js',
      'node_modules/angular-sanitize/angular-sanitize.js',
      'node_modules/angular-touch/angular-touch.js',
      'node_modules/angular-translate/dist/angular-translate.js', 
      'node_modules/angular-ui-router/release/angular-ui-router.js',
      'node_modules/matchmedia-ng/matchmedia-ng.js',
      'node_modules/clientcentre-calendar/dist/index.js',
      'node_modules/clientcentre-core-http/dist/index.js',
      'node_modules/clientcentre-core/dist/index.js',
      'node_modules/clientcentre-analytics/dist/index.js',
      'node_modules/clientcentre-configs-extractor/dist/index.js',
      'node_modules/clientcentre-cookies/dist/index.js',
      'node_modules/clientcentre-policies/dist/index.js',
      'node_modules/clientcentre-distributors/dist/index.js',
      'node_modules/clientcentre-helptext/dist/index.js',
      'node_modules/clientcentre-interceptors/dist/index.js',
      'node_modules/clientcentre-page-transition/dist/index.js',
      'node_modules/clientcentre-single-request/dist/index.js',
      'node_modules/clientcentre-error-404/dist/index.js',
      'node_modules/clientcentre-modal/dist/index.js',
      'node_modules/clientcentre-bootstrap/dist/index.js',
      'node_modules/clientcentre-error-page/dist/index.js',
      'node_modules/ng-mask/dist/ngMask.js',
	  'node_modules/underscore/underscore-min.js',
      'node_modules/intact-address/dist/index.js',
      'src/main/webapp/application/*.js',
      'src/main/webapp/application/providers/provider.configuration.js',
      'src/main/webapp/application/providers/provider.policy-change-configuration.js',
      'src/main/webapp/application/providers/provider.urls.js',
      'src/main/webapp/application/providers/provider.routes.js',
      'src/main/webapp/application/providers/provider.application-calendar.js',
      'src/main/webapp/application/providers/provider.validation.js',
      'src/main/webapp/application/providers/provider.policychange.js',
	  'src/main/webapp/application/services/*.js',
      'src/main/webapp/application/models/*.js',
      'src/main/webapp/application/factories/*.js',
      'src/main/webapp/application/directives/*.js',
      'src/main/webapp/application/filters/*.js',
      'src/main/webapp/application/controllers/*.js',
      'src/main/webapp/components/car-page/car-antitheft/car-antitheft-types/*.js',
	  'src/main/webapp/components/car-page/car-antitheft/car-antitheft-brands/*.js',
      'src/main/webapp/components/car-page/car-page-model/*.js',
      'src/main/webapp/components/car-page/car-page-condition/*.js',
      'src/main/webapp/components/car-page/car-page-leased/*.js',
      'src/main/webapp/components/car-page/car-modifications/car-modifications-performance/*.js',
      'src/main/webapp/components/car-page/car-winter-tires/*.js',
      'src/main/webapp/components/car-page/car-disclaimer/*.js',
      'src/main/webapp/components/car-page/car-postalcode-overriden/*.js',
	  'src/main/webapp/components/car-page/car-principal-driver/*/*.js',
	  'src/main/webapp/components/car-page/car-registered-owner/*.js',
	  'src/main/webapp/components/car-page/car-commercial-use/car-commercial-use-delivery/*.js',
	  'src/main/webapp/components/car-page/car-commercial-use/car-commercial-use-ind/*.js',
	  'src/main/webapp/components/car-page/car-commercial-use/car-commercial-use-businesskm/*.js',
	  'src/main/webapp/components/car-page/car-parking/car-parking-location/*.js',
	  'src/main/webapp/components/car-page/car-parking/car-parking-detail/*.js',
	  'src/main/webapp/components/car-page/car-outside-province/car-outside-province-usage/*.js',
	  'src/main/webapp/components/car-page/car-outside-province/car-outside-province-km/*.js',
      'src/main/webapp/components/driver-page/driver-date-of-birth/*.js',
      'src/main/webapp/components/driver-page/driver-gender/*.js',
      'src/main/webapp/components/driver-page/driver-marital-status/*.js',
      'src/main/webapp/components/driver-page/driver-name/*.js',
      'src/main/webapp/components/driver-page/driver-relationship/*.js',
      'src/main/webapp/components/driver-page/driver-infraction-group/*/*.js',
      'src/main/webapp/components/driver-page/driver-claims-group/*/*.js',
	  'src/main/webapp/components/driver-page/driver-record-group-qc/*/*.js',
	  'src/main/webapp/components/driver-page/driver-occupation-group/*/*.js',
	  'src/main/webapp/components/driver-page/driver-criminal-record/*.js',
	  'src/main/webapp/components/schedule-call/*.js',
	  'src/main/webapp/components/review-accept/extended-term/*.js',
	  'src/main/webapp/modules/debug/*.js',
      'src/main/webapp/modules/debug/services/*.js',
      'src/main/webapp/modules/debug/directives/*.js',
      'src/main/webapp/modules/debug/controllers/*.js',
      'tests/unit-tests-specs/application/app.js',
      'tests/unit-tests-specs/application/models/*.js',
      'tests/unit-tests-specs/application/services/service.coverages.js',
      'tests/unit-tests-specs/application/services/service.state-manager.js',
      'tests/unit-tests-specs/application/services/service.analytics.js',
      'tests/unit-tests-specs/application/services/service.initialization.js',
      'tests/unit-tests-specs/application/services/service.policy-change.js',
      'tests/unit-tests-specs/application/services/service.inline.validation.js',
      'tests/unit-tests-specs/application/services/service.core-pch.js',
      'tests/unit-tests-specs/application/services/service.car.js',
	  'tests/unit-tests-specs/application/services/service.mapper.js',
      'tests/unit-tests-specs/application/services/service.toaster.js',
	  'tests/unit-tests-specs/application/services/service.schedule-call.js',
	  'tests/unit-tests-specs/application/providers/provider.routes.js',
	  'tests/unit-tests-specs/application/providers/provider.validation.js',
      'tests/unit-tests-specs/application/filters/*.js',
      'tests/unit-tests-specs/application/controllers/*.js',
      'tests/unit-tests-specs/application/directives/*.js',
      'tests/unit-tests-specs/application/directives/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-antitheft/car-antitheft-types/*.js',
	  'tests/unit-tests-specs/application/components/car-page/car-antitheft/car-antitheft-brands/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-page-model/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-page-condition/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-page-leased/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-modifications/car-modifications-performance/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-winter-tires/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-disclaimer/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-postalcode-overriden/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-principal-driver/*/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-registered-owner/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-commercial-use/car-commercial-use-delivery/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-commercial-use/car-commercial-use-ind/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-commercial-use/car-commercial-use-businesskm/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-parking/car-parking-location/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-parking/car-parking-detail/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-outside-province/car-outside-province-usage/*.js',
      'tests/unit-tests-specs/application/components/car-page/car-outside-province/car-outside-province-km/*.js',
      'tests/unit-tests-specs/application/components/driver-page/driver-date-of-birth/*.js',
      'tests/unit-tests-specs/application/components/driver-page/driver-gender/*.js',
      'tests/unit-tests-specs/application/components/driver-page/driver-marital-status/*.js',
      'tests/unit-tests-specs/application/components/driver-page/driver-name/*.js',
      'tests/unit-tests-specs/application/components/driver-page/driver-relationship/*.js',
      'tests/unit-tests-specs/application/components/driver-page/driver-infraction-group/*/*.js',
      'tests/unit-tests-specs/application/components/driver-page/driver-claims-group/*/*.js',
	  'tests/unit-tests-specs/application/components/driver-page/driver-record-group-qc/*/*.js',
	  'tests/unit-tests-specs/application/components/driver-page/driver-occupation-group/*/*.js',
	  'tests/unit-tests-specs/application/components/driver-page/driver-criminal-record/*.js',
	  'tests/unit-tests-specs/application/components/schedule-call/*.js',
	  'tests/unit-tests-specs/application/components/review-accept/extended-term/*.js',
      'tests/dependancies/*.js',
      //template for directives
      'tests/mocks/*.json',
      'src/main/webapp/application/views/directives/*.html',
      'src/main/webapp/application/views/partials/*.html',
      'src/main/webapp/components/car-page/car-*/*.html',
      'src/main/webapp/components/car-page/car-*-group/*/*.html',
      'src/main/webapp/components/driver-page/driver-*/*.html',
      'src/main/webapp/components/driver-page/driver-*-group/*/*.html',
	  'src/main/webapp/components/schedule-call/*.html',
      'node_modules/clientcentre-helptext/views/*.html',
      'node_modules/clientcentre-page-transition/dist/views/*.html',
      'node_modules/clientcentre-error-404/dist/views/*.html',
      'node_modules/clientcentre-error-404/dist/views/**/*.html'
    ],

    proxies: {
      '/application/': '/base/node_modules/'
    },

    // list of files to exclude
    exclude: [
      //'src/main/webapp/modules/bootstrap/*.js'
    ],
    preprocessors: {
      // source files, that you wanna generate coverage for
      // do not include tests or libraries
      // (these files will be instrumented by Istanbul)
	    'src/main/webapp/application/*.js': ['coverage'],
      'src/main/webapp/application/providers/*.js': ['coverage'],
      'src/main/webapp/application/services/*.js': ['coverage'],
      'src/main/webapp/application/filters/*.js': ['coverage'],
      'src/main/webapp/application/factories/*.js': ['coverage'],
      'src/main/webapp/application/directives/directive.!(menu-header|mobile-menu).js': ['coverage'],
      'src/main/webapp/application/models/*.js': ['coverage'],
      'src/main/webapp/application/controllers/*.js': ['coverage'],
      'src/main/webapp/components/car-page/car-*/*.controller.js' : ['coverage'],
      'src/main/webapp/components/car-page/car-*-group/*/*.controller.js' : ['coverage'],
      'src/main/webapp/components/driver-page/driver-*-group/*/*.controller.js' : ['coverage'],
      'src/main/webapp/components/driver-page/driver-*/*.controller.js' : ['coverage'],
	  'src/main/webapp/components/schedule-call/*.controller.js' : ['coverage'],
      //template for directives and components
      'src/main/webapp/application/views/**/*.html':['ng-html2js'],
      'src/main/webapp/components/car-page/car-*-group/*/*.html':['ng-html2js'],
      'src/main/webapp/components/car-page/car-*/*.html':['ng-html2js'],
      'src/main/webapp/components/driver-page/driver-*-group/*/*.html':['ng-html2js'],
      'src/main/webapp/components/driver-page/driver-*/*.html':['ng-html2js'],
	  'src/main/webapp/components/schedule-call/*.html':['ng-html2js'],
      'node_modules/clientcentre-page-transition/dist/views/*.html':['ng-html2js'],
      'tests/mocks/*.json': ['ng-html2js']
    },

    // test results reporter to use
    // possible values: 'dots', 'progress'
    // available reporters: https://npmjs.org/browse/keyword/karma-reporter
    reporters: ['progress', 'junit', 'html', 'coverage'],

    htmlReporter: {
      outputDir: 'target/unit-tests/',
      templatePath:  'tests/template/jasmine_template.html',
      reportName: 'report-summary-html'
    },

    junitReporter : {
      outputDir: 'target/unit-tests/report-summary-for-sonar',
      // will be resolved to basePath (in the same way as files/exclude patterns)
      outputFile: 'test-results.xml',
	    suite: ''
    },

    coverageReporter: {
      type : 'lcov',
      dir : 'target/unit-tests/coverage/',
      watermarks: {
        statements: [ 50, 75 ],
        functions: [ 50, 75 ],
        branches: [ 50, 75 ],
        lines: [ 50, 75 ]
      }
    },

    ngHtml2JsPreprocessor:{
      stripPrefix: 'src/main/webapp',
      moduleName: 'policyChange.templates'
    },
    plugins: [

      'karma-html-reporter',
      'karma-junit-reporter',
      'karma-jasmine',
      'karma-chrome-launcher',
      'karma-ie-launcher',
      'karma-coverage',
      'karma-ng-html2js-preprocessor',
      'karma-phantomjs-launcher'
    ],



    // web server port
    port: 9876,


    // enable / disable colors in the output (reporters and logs)
    colors: true,


    // level of logging
    // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
    logLevel: config.LOG_ERROR,


    // enable / disable watching file and executing tests whenever any file changes
    autoWatch: false,


    // start these browsers
    // available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
    browsers: ['PhantomJS'],
    //browsers: ['Chrome'],

    // Continuous Integration mode
    // if true, Karma captures browsers, runs the tests and exits
    singleRun: true,
	//singleRun: false,

    browserDisconnectTimeout:5000,
    browserDisconnectTolerance:5,
    browserNoActivityTimeout:3000,
    client: {
      //captureConsole: true
    }
  })
};
