# Guideline frontend pour projet AngularJS

## Nomenclature des fichiers du projet :
* Le nom du fichier doit informer sur le composant AngularJS correspondant ;
* Un composant AngularJS par fichier ;
* Mettre les noms en minuscule avec le "-" comme séparateur pour les noms complexes ;
* Mettre le fichier dans le dossiers composant AngularJS correspondant. 

### Exemples de nomenclature 

#### Provider

> ${Module}{ProviderName} ==> module/providers/provider.provider-name.js

```javascript
Nom -> $AppConfiguration, $AppConfigurationProvider
Emplacement -> modules > app > providers > provider.configuration.js
```

#### Service

> ${Module}{ServiceName}Service ==> module/services/service.service-name.js

```javascript
Nom -> $ClientPromotionsService
Emplacement -> modules > client > services > service.promotions.js
```

#### Factory

> ${Module}{FactoryName}Factory ==> module/factories/factory.factory-name.js

```javascript
Nom -> $ClientAccesFactory
Emplacement -> modules > client > factories > factory.access.js
```

#### Model

> {Module}{ModelName}Model ==> module/models/model.model-name.js

```javascript
Nom -> ClientInformationModel
Emplacement -> modules > client > models > model.information.js
```

#### Controller

> {Module}{ControllerName}Controller ==> module/controllers/controller.controller-name.js

```javascript
Nom -> AppMainController
Emplacement -> modules > app > controllers > controller.main.js
```

#### Directive

> {prefix}{Module}{DirectiveName} ==> module/directives/directive.directive-name.js

```javascript
Nom -> ccAppBrokerBlock data-attribute : data-cc-app-broker-block=""
Emplacement -> modules > app > directives > directive.broker-block.js
```
