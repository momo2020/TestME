(function(angular){
	'use strict';
	var configuration = null; 
	angular.module('INTACT.PolicyChange', [
		'INTACT.Core',
		'INTACT.Address',
		'INTACT.Analytics',
		'INTACT.ErrorPage',
		'INTACT.PageTransition',
		'INTACT.Cookies',
		'INTACT.Helptext',
		'INTACT.Policies',
		'INTACT.Distributors',
		'INTACT.Error404',
		'INTACT.Modal',
		'INTACT.Debug',
		'ADM-dateTimePicker',
		'prettyXml',
		'ngMask'
	]);

	angular.module('INTACT.PolicyChange').config(function(
		$AddressConfigurationProvider,
		$HelpTextProvider,
		$logProvider,
		$PCRouteStatesProvider,
		$locationProvider,
		$PCAppConfigurationProvider,
		$CoreLocaleProvider,
		LOCALES,
		BROKER_ID,
		$InterceptorsConfigurationProvider,
		$PageTransitionProvider,
		$CookiesProvider,
		$PoliciesProvider,
		$PolicyChangeConfigurationProvider,
		$DistributorsProvider,
		$Error404Provider,
		$IntactModalProvider,
		$ErrorPageProvider,
		$PcCalendarProvider
		){

		// Config. app.
		configuration = $PCAppConfigurationProvider.$get();

		$AddressConfigurationProvider.configurations({
			webserviceBaseUrl: configuration.addressRestBasePath,
			apiKey: configuration.addressRestApiKey,
			province : configuration.province,
			language : configuration.language,
			rdblckPhoneNumber : configuration.rdblckPhoneNumber,
			fieldsRequirement : {
				autocompleteField : false,
				apartmentField : false,
				cityField : false,
				streetField : false,
				streetNumberField : false,
				postalCodeField :false
			}, 
			streetNameFormat : {
        		showStreetType: false
      		},
      		applicationConfiguration : configuration
		});

		// Config. modal module
		$IntactModalProvider.defaults = angular.extend($IntactModalProvider.defaults, {
			'viewsPath': configuration.viewsPath,
			'$windowService': '$CoreWindowService'
		});

		// Error Page provider
		$ErrorPageProvider.setDefaults({
			language: configuration.preferredLanguage,
			province: configuration.province,
			appname: configuration.companyName === 'belairdirect' ? 'belair' : configuration.companyName,
			rootPath: configuration.rootPath
		}).setStates();

		// Enabled logs
		$logProvider.debugEnabled(configuration.verbose);

		// Provide locales
		$CoreLocaleProvider.$get().setLocales(LOCALES, {
			sanitizeStrategy: null,
			preferredLanguage: configuration.preferredLanguage
		});
		
		// Providing routes states
		$PCRouteStatesProvider.stateOtherwise().provideStates();

		// Page transition
		$PageTransitionProvider.defaults.basePath = configuration.rootPath;

		// Cookies configuration
		$CookiesProvider.setDefaults({
			province: configuration.province,
			cacheFactory: '$CoreCacheFactory'
		});


		// DONT THINK IT'S NEEDED FOR PCH - SGIGNAC
		// $PoliciesProvider.setDefaults({
		// 	restService: '$CoreRestApiService',
		// 	cookieService: '$CookiesService',
		// 	preferredLanguage: configuration.preferredLanguage,
		// 	brokerId: BROKER_ID
		// });

		//Configure the policy change module
		$PolicyChangeConfigurationProvider.setDefaults({
			restService: '$CoreRestApiService'
		});

	    $HelpTextProvider.defaults = angular.extend($HelpTextProvider.defaults, {
	    	rootPath: configuration.rootPath,
	    	assetsPath: configuration.assetsPath,
	    	province: configuration.province.toUpperCase(),
	    	preferredLanguage: configuration.preferredLanguage.toUpperCase()
	    });

	    // Distributors
	    $DistributorsProvider.defaults = angular.extend($DistributorsProvider.defaults, {
	    	httpService: '$CoreRestApiService',
	    	preferredLanguage: configuration.preferredLanguage
	    });

	    // Error 404
	    $Error404Provider.defaults = angular.extend($Error404Provider.defaults, {
	    	urlProvider: '$PCUrls',
	    	websiteUrl: configuration.websiteUrl,
	    	analyticsService: '$PCAnalyticsService'
	    });

	    //Datepicker
	    $PcCalendarProvider.initCalendar();

	}).run(function( $CoreWindowService, 
					$rootScope, 
					$state, 
					$location, 
					$timeout, 
					tmhDynamicLocale){
		
		var locales = {
			en : 'en-ca',
			fr : 'fr-ca'
		};

		tmhDynamicLocale.set(locales[configuration.preferredLanguage]);

		/* RootScope Helpers */
		$rootScope.helpers = $rootScope.helpers || {
			state: {
				currentPage: 'PC_START'
			}
		};

		// Reload page behaviour
		$rootScope.$on('$locationChangeStart', function(){
			$CoreWindowService.scrollTop(1);
		});

		$rootScope.$on('$stateChangeStart', function(event, toState){
			if(toState.redirectTo) { // implements a redirect if configured in route
				var redirectState = $state.get(toState.redirectTo);
				if(redirectState && redirectState.url){
					var $t = $timeout(function(){
						// Clean timeout
						if($t){
							$timeout.cancel($t);
						}
						// Redirect without impact history back button
						$location.path(redirectState.url).replace();
					}, 0);
				}
			} else {
				// Registers UI state
				$rootScope.helpers.state.currentPage = toState;
				// Scroll top
	        	$CoreWindowService.scrollTop(100);

	        	//$PCStateManagerService.showLoader();
			}
        });
	});
})(angular);
