(function(angular){
	'use strict';

	angular.module('INTACT.PolicyChange').provider('$PcCalendar', provider);
	
	function provider(LOCALES, ADMdtpProvider, $PCAppConfigurationProvider) {
		var lang = $PCAppConfigurationProvider.configuration.preferredLanguage.toLowerCase(), 
			labels = servicePcCalendar();

		this.initCalendar = function(){
		    ADMdtpProvider.setOptions({
				calType 	: "gregorian",
				dtpType		: 'date',
				format		: (lang === 'en') ? 'YYYY-MM-DD' : 'DD-MM-YYYY',
				labels		: labels,
				autoClose 	: true
		    });			
		};

		this.$get = servicePcCalendar;

		function validateDate(_date) {
            if(!angular.isDefined(_date) || _date == null || _date === ''){
            	return false;
            }
            var date = isFrenchFormat(_date) ? reverse(_date) : _date;
            var regEx = '^[0-9]{4}-[0-1][0-9]-[0-3][0-9]$';
            var matchPattern = date.match(regEx);
            return matchPattern ? true: false;
        }

        function isFrenchFormat(date) {
        	return (date.indexOf('-') !== 4) ? true : false;
        }
        
        function reverse(date) {
            return date.split('-').reverse().join('-');
        }

        function getDateFormat() {
            return { 
                mask: lang.toUpperCase() === 'EN' ? '9999-19-39' : '39-19-9999',
                format : lang.toUpperCase() === 'EN' ? 'yyyy-MM-dd' : 'dd-MM-yyyy',
                isFrenchFormat : isFrenchFormat,
                reverse :reverse
            };
        }

		/***/
		function propsToArrayLocalized(value){
			var myArray = [];

			if(angular.isObject(LOCALES[lang])) {
				var props = LOCALES[lang]['DP_' + value];

				if(angular.isString(props)){
					myArray = props.split(',');
				}				
			}
			
			return myArray;
		}

		function servicePcCalendar(){
			return {
				validateDate : validateDate,
				getDateFormat :getDateFormat,
				monthsNames : propsToArrayLocalized('MONTHS'),
				daysNames : propsToArrayLocalized('DAYS')
			};
		}	
	}
})(angular);