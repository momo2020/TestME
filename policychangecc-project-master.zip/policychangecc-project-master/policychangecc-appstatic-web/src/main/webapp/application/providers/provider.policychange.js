// **********************************************************
// NOTE: PART OF CODE REFACTORING.
// NOTE: DO NOT DELETE OF ALTER THE CODE IN THIS FILE
// NOTE: SGIGNAC
// **********************************************************

(function(angular){
 'use strict';

 /**
    * @ngdoc service
    * @name INTACT.PolicyChange.$PolicyChange
    *
    * @example
    * <pre>
    *
    * </pre>
    *
    * @description
    * Provide the policy change data
    * Updated by the policy change service
    **/
 angular.module('INTACT.PolicyChange').provider('$PolicyChange', provider);

 function provider() {
    var policyChange = null;
    var policyChangeCache = null;
    var ETagTimeStamp = null;
    var pageNameCurrentTag = null;

   /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChange#update
   * @methodOf INTACT.PolicyChange.$PolicyChange
   * @description
   * Update the Policy Change
   * @params {Object} pc Policy Change object from the server
   * @returns {Function} $PolicyChangeProvider
   */
  this.update = function(pc){
    updatePolicyChangeData(pc);
    return this;
  };


  /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChange#updateTimeStamp
   * @methodOf INTACT.PolicyChange.$PolicyChange
   * @description
   * Update the Policy Change TimeStamp to use in PUT
   * @params {String} Time Stamp from the GET service
   * @returns {Function} $PolicyChangeProvider
   */
  this.updateTimeStamp = function(ts){
    ETagTimeStamp = ts;
    return this;
  };

  /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChange#getTimeStamp
   * @methodOf INTACT.PolicyChange.$PolicyChange
   * @description
   * Return the Policy Change TimeStamp to use in PUT
   * @returns {String} TimeStamp
   */
  this.getTimeStamp = function(){
    return ETagTimeStamp;
  };


  /**
  * @ngdoc method
  * @name INTACT.PolicyChange.$PolicyChange#policyChange
  * @methodOf INTACT.PolicyChange.$PolicyChange
  * @description
  * get the policy change response data
  * @returns {Object} Policy Change Response Data
  */
  this.policyChange = function(){
    return policyChange || null;
  };

  /**
  * @ngdoc method
  * @name INTACT.PolicyChange.$PolicyChange#$get
  * @methodOf INTACT.PolicyChange.$PolicyChange
  * @description
  * Return the $PolicyChangeProvider provider
  * @returns {Object} $$PolicyChangeProvider
  */
  this.$get = function(){
    return this;
  };

  /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChange#updatePageNameTag
   * @methodOf INTACT.PolicyChange.$PolicyChange
   * @description
   * Update the s_pageName Omniture current tag in order to be used in othe containers (SideBar)
   * @params {String} s_pageName to be saved
   * @returns {Function} $PolicyChangeProvider
   */
  this.updatePageNameTag = function(tag){
    pageNameCurrentTag = tag;
    return this;
  };

  /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChange#getPageNameTag
   * @methodOf INTACT.PolicyChange.$PolicyChange
   * @description
   * Return the current s_pageName tag
   * @returns {String} TimeStamp
   */
  this.getPageNameTag = function(){
    return pageNameCurrentTag;
  };

  /*
  * Update the data and prepare some feature
  */
  function updatePolicyChangeData(data){
    policyChange = data || null;

    // Prepare a copy of the data in order to process the possible cancels
    if(data){
      policyChangeCache = angular.copy(data);
    }
    else{
      policyChangeCache = null;
    }
  }


 }
})(angular);
