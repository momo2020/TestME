// **********************************************************
// NOTE: PART OF CODE REFACTORING.
// NOTE: DO NOT DELETE OF ALTER THE CODE IN THIS FILE
// NOTE: SGIGNAC
// **********************************************************

(function(angular){
 'use strict';

 /**
    * @ngdoc service
    * @name INTACT.PolicyChange.$PolicyChangeState
    *
    * @example
    * <pre>
    *
    * </pre>
    *
    * @description
    * Provide the policy change data
    * Updated by the policy change service
    **/
 angular.module('INTACT.PolicyChange').provider('$PolicyChangeState', provider);

 function provider() {

    // The raw policy change state object
    var policyChangeState = null;


   /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeState#update
   * @methodOf INTACT.PolicyChange.$PolicyChangeState
   * @description
   * Update the Policy Change
   * @params {Object} state Policy Change State object from the server
   * @returns {Function} $PolicyChangeStateProvider
   */
   this.update = function(state){
     if(state){
       policyChangeState = state;
     }
     else{
       //No pc passed. Clean up.
       policyChangeState = null;
     }
     return this;
   };

  /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeState#get
   * @methodOf INTACT.PolicyChange.$PolicyChangeState
   * @description
   * Returns state
   * @returns {Object} State
   */
   this.state = function() {
      return policyChangeState ? policyChangeState : null; 
   };


   /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeState#$get
   * @methodOf INTACT.PolicyChange.$PolicyChangeState
   * @description
   * Return the $PolicyChangeProvider provider
   * @returns {Object} $PolicyChangeStateProvider
   */
   this.$get = function(){
     return this;
   };
  

 }
})(angular);
