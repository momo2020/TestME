 (function(angular){
	'use strict';

	/**
     * @ngdoc service
     * @name INTACT.PolicyChange.$PCRouteStates
     * @requires http://angular-ui.github.io/ui-router/site/#/api/ui.router.state.$stateProvider
     *
     * @example
     * <pre>
     * // In config.
     * MyModule.config(function($AppRouteStatesProvider){
     *
     * });
     * </pre>
     *
     * @description
     * Provide access to application urls (in context language)
     **/
	angular.module('INTACT.PolicyChange').provider('$PCRouteStates', provider);

	function provider($urlRouterProvider, $stateProvider, $PCUrlsProvider, $PCAppConfigurationProvider, $provide, $windowProvider, $Error404Provider) {
		var urlProvider = $PCUrlsProvider.$get(),
			configuration = $PCAppConfigurationProvider.$get();

		// Main views Path + Partials views path
		var VIEWS_PATH = configuration.viewsPath,
			PARTIALS_VIEWS_PATH = configuration.partialsViewsPath,
			MODULE_VIEW_PATH = configuration.rootPath + '/modules';

		// App states
		var states = {
			'app': {
				abstract: true,
				views: {
					'header@': {
						templateUrl: PARTIALS_VIEWS_PATH + '/header.html',
		            	controller: 'PCHeaderController',
						controllerAs : 'header',
						resolve: /*@ngInject*/ {
		      				DistributorData: function($PCDistributorService){
		      					return $PCDistributorService.get();
				            }
				        }
		        	},
		        	'help@': {
	          			templateUrl: PARTIALS_VIEWS_PATH + '/need-help.html',
	          			controller: 'PCFooterController',
	          			controllerAs: 'footer',
	          			resolve: /*@ngInject*/ {
	          				DistributorData: function($PCDistributorService){
	          					return $PCDistributorService.get();
				            }
	          			}
	        		},
		        	'footer@': {
	          			templateUrl: PARTIALS_VIEWS_PATH + '/footer.html',
	          			controller: 'PCFooterController',
	          			controllerAs: 'footer',
	          			resolve: /*@ngInject*/ {
	          				DistributorData: function($PCDistributorService){
	          					return $PCDistributorService.get();
				            }
	          			}
	        		}
				}
			},
			'app.summary': {
				url: urlProvider.getUrl('summary'),
				redirectTo: 'app.policychange.select',
				views: {
		            'container@': {
		            	template: '<span></span>',
		            	controller: 'MainController',
		            	controllerAs: 'Main'
		        	}
		        },
				data: {
					ID: 'dashboard'
				}
			},
			'app.policychange': {
				abstract: true,
				views: {
					'right@': {
	        			templateUrl: PARTIALS_VIEWS_PATH + '/right.html',
	        			controller: 'PCSidebarController',
	          			controllerAs: 'sidebar',
	          			resolve: /*@ngInject*/ {
	          				DistributorData: function($PCDistributorService){
	          					return $PCDistributorService.get();
				            }
	          			}
	        		}
				}
			},
			'app.policychange.select': {
				url: urlProvider.getUrl('policychange'),
				views: {
		            'container@': {
		            	templateUrl: VIEWS_PATH + '/policy-change-select.html',
		            	controller: 'PolicyChangeSelectController',
		            	controllerAs: 'SelectCtrl',
		            	resolve: /*@ngInject*/ {
		            		PolicyChangeData: function( $PolicyChangeService, 
		            									$InitializationService, 
		            									$PCStateManagerService, 
		            									$q, 
		            									$state){
		            			var defered = $q.defer();
		            			$PolicyChangeService.get('PC_START').then(function(data){

	            					$PCStateManagerService.validStateOrRedirect(data.state);
									$InitializationService.get($PCAppConfigurationProvider.configuration.policyNumber).then(function(init){
			            				defered.resolve({
			            					PolicyChangeData : data,
			            					PolicyChangeInitState : init
			            				});
		            				});

		            			});
		            			
		            			return defered.promise;
		            		}
		            	}
		        	},
		        	'statusbar@': /*@ngInject*/ {
	        			template: '<cc-status-bar />'
					},
		        	'buttons@': {
		        		template: '<cc-navigation-buttons />'
		        	}
		        },
		        data: {
		        	ID: 'pc-select',
		        	page: 'PC_START'
		        }
			},
			'app.policychange.address': {
				url: urlProvider.getUrl('policychangeaddress'),
				views: {
		            'container@': {
		            	templateUrl: VIEWS_PATH + '/policy-change-address.html',
		            	controller: 'PolicyChangeAddressController',
		            	controllerAs: 'addressCtrl',
		            	resolve: /*@ngInject*/ {
		            		PolicyChangeData: function($PolicyChangeService, 
		            									$PCStateManagerService, 
		            									$q, 
		            									$state){
		            			var deferred = $q.defer();
		            			$PolicyChangeService.get('PC_ADDRESS').then(function(data){
		            				$PCStateManagerService.validStateOrRedirect(data.state);
		            				deferred.resolve(data);
		            			});
		            			return deferred.promise;
		            		}
		            	}
		            },
	            	'statusbar@': /*@ngInject*/ {
	            		template: '<cc-status-bar />'
					},
		        	'buttons@': {
		        		template: '<cc-navigation-buttons />'
		        	}
		        },
		        data: {
		        	ID: 'pc-address',
		        	page: 'PC_ADDRESS'
		        }
			},
			'app.policychange.policyReset': {
				url: urlProvider.getUrl('policychangeresetpolicy'),
				views: {
		            'container@': { /*@ngInject*/
	            		controller: function( $CoreRestApiService, $state, $stateParams, $log) {
			        	var policyNumber = $stateParams.policyNo;

			        	function configure() {
			        		var options = {
			        			 params: {
			        				language : $stateParams.language,
			        				province : $stateParams.province
			        			}
			        		};
			        		return $CoreRestApiService.get("/configurations", options);
			        	}

			        	function getPolicy() {
			        		return $CoreRestApiService.get("/policy/"+policyNumber);
			        	}

			        	function cancelPolicy() {
			        		return $CoreRestApiService.delete("/policy/"+policyNumber+"/policychange");
			        	}

			            configure()
			            	.then(cancelPolicy)
			            	.then(getPolicy)
			                .then( function(data) {
			                	var data = data.data ? data.data : data;
			                	if(data.validation !== null && data.validation !== undefined){
			                		if(data.validation.resultType === "HARD_ROADBLOCKS"){
										$state.go('app.hardRoadBlock', {errors: data.validation.roadBlocks});
			                		}
				                	else{
				                    	$state.go('app.policychange.select');
				                	}

			                	}
			                	else{
			                    	$state.go('app.policychange.select');
			                	}
			                		
			                })
			                .catch( function(e) {
			                	$log.warn(e.status +': '+ e.statusText);
			                	// TODO: check what it needs to do when police delete fails when already deleted 
			                	$state.go('app.policychange.select');
			                });
				    	}
		        	}
		        },
		        data: {
		        	ID: 'reset-car',
		        	page: ''
		        }
			},
			'app.policychange.car': {
				url: urlProvider.getUrl('policychangecar'),
				views: {
		            'container@': {
		            	templateUrl: VIEWS_PATH + '/policy-change-car.html',
		            	controller: 'PolicyChangeCarController',
		            	controllerAs: 'pcCarCtrl',
		            	resolve: /*@ngInject*/ {
		            		PolicyChangeData: function($PolicyChangeService, 
		            									$PCStateManagerService, 
		            									$q, 
		            									$state){
		            			var deferred = $q.defer();
		            			$PolicyChangeService.get('PC_CARS').then(function(data){
		            				$PCStateManagerService.validStateOrRedirect(data.state);
		            				deferred.resolve(data);
		            			});
		            			
		            			return deferred.promise;
		            		}
		            	}
		        	},
	            	'statusbar@': /*@ngInject*/ {
	            		template: '<cc-status-bar />'
	     			},
		        	'buttons@': {
		            	template: '<cc-navigation-buttons />'
		        	}
		        },
		        data: {
		        	ID: 'pc-car',
		        	page: 'PC_CARS'
		        }
			},
			'app.policychange.driver': {
				url: urlProvider.getUrl('policychangedriver'),
				views: {
		            'container@': {
		            	templateUrl: VIEWS_PATH + '/policy-change-driver.html',
		            	controller: 'PolicyChangeDriverController',
		            	controllerAs: 'pcDriverCtrl',
		            	resolve: /*@ngInject*/ {
		            		PolicyChangeContext: function($PolicyChangeService, 
		            									$PCStateManagerService, 
		            									//$AffinityGroupsService,
		            									$q, 
		            									$state){
		            			var deferred = $q.defer();
		            			$PolicyChangeService.get('PC_DRIVERS').then(function(data){
		            				$PCStateManagerService.validStateOrRedirect(data.state);
		            				var pcEffectiveDate = data.policyChange.effectiveDate;

		            				//$AffinityGroupsService.get(pcEffectiveDate).then(function(affinityGroupsData){
		            				deferred.resolve({
		            					PolicyChangeData : data,
		            					// AffinityGroupsData : affinityGroupsData
		            				});
			            			//});

	            				});
	            				return deferred.promise;
		            		}
		            	}
		        	},
	            	'statusbar@': /*@ngInject*/ {
	            		template: '<cc-status-bar />'
					},
		        	'buttons@': {
		        		template: '<cc-navigation-buttons />'
		        	}
		        },
		        data: {
		        	ID: 'pc-driver',
		        	page: 'PC_DRIVERS'
		        }
			},
			'app.policychange.usage': {
				url: urlProvider.getUrl('policychangeusage'),
				views: {
		            'container@': {
		            	templateUrl: VIEWS_PATH + '/policy-change-usage.html',
		            	controller: 'PolicyChangeUsageController',
		            	controllerAs: 'UsageCtrl',
		            	resolve: /*@ngInject*/ {
		            		PolicyChangeData: function($PolicyChangeService, 
		            									$PCStateManagerService, 
		            									$q, 
		            									$state){
		            			var deferred = $q.defer();
		            			$PolicyChangeService.get('PC_VEH_USAGE').then(function(data){
		            				$PCStateManagerService.validStateOrRedirect(data.state);
		            				deferred.resolve(data);
		            			});
		            			return deferred.promise;
		            		}
		            	}
		        	},
	            	'statusbar@': /*@ngInject*/ {
	            		template: '<cc-status-bar />'
					},
		        	'buttons@': {
		        		template: '<cc-navigation-buttons />'
		        	}
		        },
		        data: {
		        	ID: 'pc-usage',
		        	page: 'PC_VEH_USAGE'
		        }
			},
			'app.policychange.coverage': {
				url: urlProvider.getUrl('policychangecoverage'),
				views: {
		            'container@': {
		            	templateUrl: VIEWS_PATH + '/policy-change-coverage.html',
		            	controller: 'PolicyChangeCoverageController',
		            	controllerAs: 'CoverageCtrl',
		            	resolve: /*@ngInject*/ {
		            		PolicyChangeData: function($PolicyChangeService, 
		            									$PCStateManagerService, 
		            									$q, 
		            									$state){
		            			var deferred = $q.defer();
		            			$PolicyChangeService.get('PC_COV').then(function(data){
		            				$PCStateManagerService.validStateOrRedirect(data.state);
		            				deferred.resolve(data);
		            			});
		            			return deferred.promise;
		            		}
		            	}
		        	},
	            	'statusbar@': /*@ngInject*/ {
	            		template: '<cc-status-bar />'
					},
		        	'buttons@': {
		        		template: '<cc-navigation-buttons />'
		        	}
		        },
		        data: {
		        	ID: 'pc-coverage',
		        	page: 'PC_COV'
		        }
			},
			'app.policychange.premium': {
				url: urlProvider.getUrl('policychangepremium'),
				views: {
		            'container@': {
		            	templateUrl: VIEWS_PATH + '/policy-change-premium.html',
		            	controller: 'PolicyChangePremiumController',
		            	controllerAs: 'PremiumCtrl',
		            	resolve: /*@ngInject*/ {
		            		PolicyChangeData: function($PolicyChangeService, 
		            									$PCStateManagerService, 
		            									$q, 
		            									$state){
		            			var deferred = $q.defer();
		            			$PolicyChangeService.get('PC_PRM').then(function(data){
		            				$PCStateManagerService.validStateOrRedirect(data.state);
		            				deferred.resolve(data);
		            			});
		            			return deferred.promise;
		            		}
		            	}
		        	},
	            	'statusbar@': /*@ngInject*/ {
	            		template: '<cc-status-bar />'
					},
		        	'buttons@': {
		        		template: '<cc-navigation-buttons />'
		        	}
		        },
		        data: {
		        	ID: 'pc-premium',
		        	page: 'PC_PRM'
		        }
			},
			'app.policychange.review': {
				url: urlProvider.getUrl('policychangereview'),
				views: {
		            'container@': {
		            	templateUrl: VIEWS_PATH + '/policy-change-review.html',
		            	controller: 'PolicyChangeReviewController',
		            	controllerAs: 'ReviewCtrl',
		            	resolve: /*@ngInject*/ {
		            		PolicyChangeData: function($PolicyChangeService, $PCStateManagerService, $PolicyModificationsService, $q, $state){ 
		            			var deferred = $q.defer();
		            			$PolicyChangeService.get('PC_REVW').then(function(data){
		            				var x = $PolicyModificationsService.get().then(function(data2){
		            					$PCStateManagerService.validStateOrRedirect(data.state);	
		            					deferred.resolve(data);
		            				});
		            			});
		            			return deferred.promise;
		            		}
		            	}
		        	},
	            	'statusbar@': /*@ngInject*/ {
	            		template: '<cc-status-bar />'
					},
		        	'buttons@': {
		        		template: '<cc-navigation-buttons />'
		        	}
		        },
		        data: {
		        	ID: 'pc-review',
		        	page: 'PC_REVW'
		        }
			},
			'app.policychange.confirm': {
				url: urlProvider.getUrl('policychangeconfirm'), 
				views: {
					'container@': {},
					'help@': {},
					'right@': {},
		        	'buttons@': {
		        		template: '<cc-navigation-buttons />'
		        	},
		            'fullWidthView@': {
		            	templateUrl: VIEWS_PATH + '/policy-change-confirm.html',
		            	controller: 'PolicyChangeConfirmController',
		            	controllerAs: '$ctrl',
		            	resolve: /*@ngInject*/ {
		            		PolicyChangeData: function($PolicyChangeService, 
		            									$PCStateManagerService, 
		            									$q, 
		            									$state){
		            			var deferred = $q.defer();
		            			$PolicyChangeService.get('PC_CONFIRM').then(function(data){
		            				$PCStateManagerService.validStateOrRedirect(data.state);
		            				deferred.resolve(data);
		            			});
		            			return deferred.promise;
		            		}
		            	}
		        	}
		        },
		        data: {
		        	ID: 'pc-trx-confrm',
		        	page: 'PC_TRX_CONFRM'
		        }
			},
			'app.hardRoadBlock': {
				url: urlProvider.getUrl('policychangehardroadblock'),
				views: {
					'container@': {},
					'help@': {},
					'fullWidthView@': {
						controller: 'HardRoadBlockController',
						controllerAs: 'hardRoadBlockCtrl',
		             	templateUrl: VIEWS_PATH + '/hard-road-block.html' 
		        	}
		        },
		        params:{
             		errors: null
             	},
				data: {
					ID: 'hard-road-block'
				}
			}
		};

		var errorStates = $Error404Provider.$get().getStates(MODULE_VIEW_PATH + '/error-404/views');

		if(errorStates.hasOwnProperty('404') && errorStates.hasOwnProperty('404.content')){
			states = angular.extend(states, errorStates);
		}

		/**
		* @ngdoc method
		* @name INTACT.PolicyChange.$PCRouteStates#stateOtherwise
		* @methodOf INTACT.PolicyChange.$PCRouteStates
		* @description
		* Otherwise routing
		* @params {Object} overwise Overwise routing management
		* @returns {Function} $AppRouteStatesProvider
		*/
		this.stateOtherwise = function(){
			// 404 Page without change url
			$urlRouterProvider.otherwise(function($injector, $location){
				var state = $injector.get('$state');
				state.go('404.content');
				return $location.path();
			});

			return this;
		};

		/**
		* @ngdoc method
		* @name INTACT.PolicyChange.$PCRouteStates#provideStates
		* @methodOf INTACT.PolicyChange.$PCRouteStates
		* @description
		* Provide availables states
		* @returns {Function} $AppRouteStatesProvider
		*/
		this.provideStates = function(){
			/* Provide all states */
			for(var name in states){
				$stateProvider.state(name, states[name]);
			}

			return this;
		};

		/**
		* @ngdoc method
		* @name INTACT.PolicyChange.$PCRouteStates#$get
		* @methodOf INTACT.PolicyChange.$PCRouteStates
		* @description
		* $AppRouteStatesProvider
		* @returns {Object} $AppRouteStatesProvider
		*/
		this.$get = function(){
			return this;
		};
	}
})(angular);
