// **********************************************************
// NOTE: PART OF CODE REFACTORING.
// NOTE: DO NOT DELETE OR ALTER THE CODE IN THIS FILE
// NOTE: SGIGNAC
// **********************************************************

(function(angular){
 'use strict';

 /**
    * @ngdoc service
    * @name INTACT.PolicyChange.$PolicyChangeValidation
    *
    * @example
    * <pre>
    *
    * </pre>
    *
    * @description
    * Provide the policy change inline validation data
    * Updated by the policy change service
    **/
 angular.module('INTACT.PolicyChange').provider('$PolicyChangeValidation', provider);

 function provider() {

    // The raw policy change inline validation object
    var inlineValidationData = null;
    
   /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeValidation#update
   * @methodOf INTACT.PolicyChange.$PolicyChangeValidation
   * @description
   * Update the Policy Change
   * @params {Object} state Policy Change State object from the server
   * @returns {Function} $PolicyChangeValidationProvider
   */
   this.update = function(inlineData, rs){
      if(inlineData){
       inlineValidationData = inlineData;

       // This loops through all errors and add a property for the name
       // elementName + index 
       // (ie: field=DE0029 + elementIndex=1 -> indexedName=DE00291)
       prepareIndexedName(inlineData);
       rs.$broadcast('ValidationDataUpdated', inlineData);
      }
      else{
       //No pc passed. Clean up.
       inlineValidationData = null;
      }

      return this;
   };

    /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeValidation#get
   * @methodOf INTACT.PolicyChange.$PolicyChangeValidation
   * @description
   * returns validation object
   * @returns {Object}
   */

   this.get = function() {
     return inlineValidationData;
   };

 /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeValidation#getResultType
   * @methodOf INTACT.PolicyChange.$PolicyChangeValidation
   * @description
   * returns validation resultType
   * @returns {String}
   */
   this.getResultType = function() {
     return inlineValidationData ? inlineValidationData.resultType : 'invalid resultType';
   };

  /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeValidation#getValidationByType
   * @methodOf INTACT.PolicyChange.$PolicyChangeValidation
   * @description
   * returns passed validation object by type
   * @returns {Object}
   */
   this.getValidationByType = function(validationType) {
      return inlineValidationData && inlineValidationData[validationType] ? inlineValidationData[validationType] : null;
   };

   /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeValidation#hasErrors
   * @methodOf INTACT.PolicyChange.$PolicyChangeValidation
   * @description
   * return true if there is errors in the object
   * @returns {boolean}
   */
   this.hasErrors = function(){
      return angular.isObject(inlineValidationData.errors);
   };

   /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeValidation#hasRoadblocks
   * @methodOf INTACT.PolicyChange.$PolicyChangeValidation
   * @description
   * return true if there is roadblocks in the object
   * @returns {boolean}
   */
   this.hasRoadblocks = function(){
      return angular.isObject(inlineValidationData.roadBlocks);
   };

  /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeValidation#getRoadBlocksMessages
   * @methodOf INTACT.PolicyChange.$PolicyChangeValidation
   * @description
   * returns a list of roadblocks messages
   * @returns {Array}
   */
   this.getRoadBlocksMessages = function() {
      var roadBlocksMessages = [];
      
      angular.forEach(inlineValidationData.roadBlocks, function(roadBlock) {
        if (roadBlock.message) {
          roadBlocksMessages.push(roadBlock.message);
        }
      });

      return roadBlocksMessages;
   };

   /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeValidation#getRoadBlocks
   * @methodOf INTACT.PolicyChange.$PolicyChangeValidation
   * @description
   * returns a list of roadblocks objects
   * @returns {Array}
   */
   this.getRoadBlocks = function() {
      return inlineValidationData.roadBlocks;
   };


   /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeValidation#hasWarnings
   * @methodOf INTACT.PolicyChange.$PolicyChangeValidation
   * @description
   * return true if there is warnings in the object
   * @returns {boolean}
   */
   this.hasWarnings = function(){
      return angular.isObject(inlineValidationData.warnings);
   };

   /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeValidation#hasErrorByRisk
   * @methodOf INTACT.PolicyChange.$PolicyChangeValidation
   * @description
   * return true if risk has error
   * @returns {boolean}
   */
   this.hasErrorByRisk = function(risk){
    var hasError = false;
    if(angular.isObject(inlineValidationData)){
      if(angular.isObject(inlineValidationData.errors)){
        for(var i = 0, ll = inlineValidationData.errors.length ; i < ll ; i++){
          if(inlineValidationData.errors[i]){
            if(inlineValidationData.errors[i].elementIndex === risk){
              hasError = true;
              continue;
            }
          }
        }
      }
    }

    return hasError;
   };

   this.removeErrorForRisk = function(risk) {
    var toDelete = [];
    if(angular.isObject(inlineValidationData.errors)){
      for(var i = 0, ll = inlineValidationData.errors.length ; i < ll ; i++){
        if(inlineValidationData.errors[i].elementIndex === risk){
          toDelete.push(i);
        }
      }

      for(var i = 0, ll = toDelete.length ; i < ll ; i++){
        delete inlineValidationData.errors[toDelete[i]];
      }
    }
   };

   /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeValidation#$get
   * @methodOf INTACT.PolicyChange.$PolicyChangeValidation
   * @description
   * Return the $PolicyChangeValidationProvider provider
   * @returns {Object} $PolicyChangeValidationProvider
   */
   this.$get = function(){
      return this;
   };


   // Prepare the indexedName properties
   var prepareIndexedName = function(inlineData){
    if(inlineData.errors){
      if(angular.isArray(inlineData.errors)){
        angular.forEach(inlineData.errors, function(error){
          if(error.elementIndex){
            error.indexedName = error.field + error.elementIndex;
          }
          else{
            error.indexedName = error.field;
          }
        });
      }
    }
   };


 }
})(angular);
