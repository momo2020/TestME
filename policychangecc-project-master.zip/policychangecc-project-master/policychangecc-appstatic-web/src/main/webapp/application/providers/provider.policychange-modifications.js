(function(angular){
 'use strict';

 /**
    * @ngdoc service
    * @name INTACT.PolicyChange.$PolicyChangeModifications
    *
    * @example
    * <pre>
    *
    * </pre>
    *
    * @description
    * Provide the policy change data
    * Updated by the policy change service
    **/
 angular.module('INTACT.PolicyChange').provider('$PolicyChangeModifications', provider);

 function provider() {

    // The raw policy change modifications object
    var policyChangeModifications = null;


   /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeModifications#getModifications
   * @methodOf INTACT.PolicyChange.$PolicyChangeModifications
   * @description
   * Get the modifications data
   * @returns {Object} policyChangeModifications
   */
   this.getModifications = function(){
     return policyChangeModifications || null;
   };


   /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeModifications#update
   * @methodOf INTACT.PolicyChange.$PolicyChangeModifications
   * @description
   * Update the Policy Change
   * @params {Object} state Policy Change Modification object from the server
   * @returns {Function} $PolicyChangeModificationsProvider
   */
   this.update = function(data){
     policyChangeModifications = data || null;
     return this;
   };


   /**
   * @ngdoc method
   * @name INTACT.PolicyChange.$PolicyChangeModifications#$get
   * @methodOf INTACT.PolicyChange.$PolicyChangeModifications
   * @description
   * Return the $PolicyChangeModificationsProvider provider
   * @returns {Object} $PolicyChangeModificationsProvider
   */
   this.$get = function(){
     return this;
   };
 }
})(angular);
