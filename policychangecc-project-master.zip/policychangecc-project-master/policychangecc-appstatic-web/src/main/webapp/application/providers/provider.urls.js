(function(angular){
	'use strict';

	/**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:$PCUrlsProvider
     * @requires $INTACT.PolicyChange.service:$PCAppConfigurationProvider
     * 
     * @example
     * <pre>
     * // In config.
     * MyModule.config(function($AppUrlsProvider){
     * 	var urlProvider = $AppUrlsProvider.$get();
     * 	// Access to an url
     * 	var url = urlProvider.getUrl('summary');
     * 	// url ==> '/'
     * });
     *
     * // In run phase
     * MyModule.run(function($AppUrls){
     * 	var url = $AppUrls.getUrl('summary');
     * 	// url ==> '/'
     * });
     * </pre>
     * 
     * @description
     * Provide access to application urls (in context language)
     **/
	angular.module('INTACT.PolicyChange').provider('$PCUrls', provider);
	
	function provider($PCAppConfigurationProvider, $windowProvider) {
		var configs = $PCAppConfigurationProvider.$get(),
			preferredLanguage = configs.preferredLanguage,
			policyNumber = configs.policyNumber,
			province = configs.province,
			location = $windowProvider.$get().location,
			params = [];

		/**/
		var pathname = location.pathname;
		if(pathname.length){
			if(pathname.indexOf('/' + policyNumber) !== -1){
				params.push(policyNumber);
			}

			if(pathname.indexOf('/' + province) !== -1){
				params.push(province);
			} else if(pathname.indexOf('/' + province.toLowerCase()) !== -1) {
				params.push(province.toLowerCase());
			}
			
			if(pathname.indexOf('/' + preferredLanguage) !== -1){
				params.push(preferredLanguage);
			} else if(pathname.indexOf('/' + preferredLanguage.toUpperCase()) !== -1) {
				params.push(preferredLanguage.toUpperCase());
			}
		}

		var rootPath = configs.rootPath,
			summaryPath = '';

		if(params.length){
			rootPath += '/' + params.join('/');
		} else {
			summaryPath += '/';
		}
		
		var route404 = rootPath + '/404';
		var route500 = rootPath + '/500';
		var urls = {
			
			en: {
				'summary': rootPath + summaryPath,
				'policychange': rootPath + '/change',
				'policychangecar': rootPath + '/change/car',
				'policychangeresetpolicy': configs.rootPath + '/:policyNo/:province/:language/reset/policy',
				'policychangecoverage': rootPath + '/change/coverage',
				'policychangepremium': rootPath + '/change/premium',
				'policychangereview': rootPath + '/change/review',	
				'policychangeconfirm': rootPath + '/change/confirm',								
				'policychangeaddress': rootPath + '/change/address',	
				'policychangeusage': rootPath + '/change/usage',								
				'policychangedriver': rootPath + '/change/driver',
				'policychangehardroadblock': rootPath + '/hardRoadBlock',
				'404': route404,
				'500': route500
			},
			fr: {
				'summary': rootPath + summaryPath,
				'policychange': rootPath + '/modifier',
				'policychangecar': rootPath + '/modifier/voiture',
				'policychangeresetpolicy': configs.rootPath + '/:policyNo/:province/:language/reset/policy',
				'policychangecoverage': rootPath + '/modifier/couverture',	
				'policychangepremium': rootPath + '/modifier/prime',		
				'policychangereview': rootPath + '/modifier/revision',										
				'policychangeconfirm': rootPath + '/modifier/confirmation',								
				'policychangeaddress': rootPath + '/modifier/adresse',
				'policychangeusage': rootPath + '/modifier/utilisation',								
				'policychangedriver': rootPath + '/modifier/conducteur',
				'policychangehardroadblock': rootPath + '/hardRoadBlock',
				'404': route404,
				'500': route500
			}
		};

		/**
		* @ngdoc method
		* @name $PCUrlsProvider#$get
		* @methodOf INTACT.PolicyChange.service:$PCUrlsProvider
		* @description
		* Return $PCUrlsProvider
		* @returns {Object} $PCUrlsProvider
		*/
		this.$get = function(){
			return {
				getUrl: function(urlKey){
					return urls[preferredLanguage][urlKey];
				}	
			};
		};
	}
})(angular);