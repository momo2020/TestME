(function(angular){
	'use strict';

	/**
	 * @ngdoc service
	 * @name INTACT.PolicyChange.service:$PolicyChangeConfigurationProvider
	 * @description
	 * Provide configuration for policy change module.<br />
	 * Configurations are :<br />
	 *  - todo
	 *  - todo
	 * @example
	 * <pre>
	 * var myModule = angular.module('MyModule');
	 * myModule.config(function($PolicyChangeConfigurationProvider){
	 * 	$PolicyChangeConfigurationProvider.setDefaults({
	 * 		restService: '$CoreRestApiService',
	 * 		cookieService: '$CookiesService'
	 * 	});
	 * }).run(function(){
	 * 		//
	 * });
	 * </pre>
	 */
	angular.module('INTACT.PolicyChange').provider('$PolicyChangeConfiguration', function(){
		
		/**
		 * @ngdoc property
		 * @name $PolicyChangeConfigurationProvider#defaults
		 * @propertyOf INTACT.PolicyChange.service:$PolicyChangeConfigurationProvider
		 * @description
		 * Default set-up configuration
		 * @returns {Object} Set of configurations
		 */
		var defaults = this.defaults = {
			appConfiguration: null,
			restService: null
		};

		/**
		 * @ngdoc method
		 * @name $PolicyChangeConfigurationProvider#$get
		 * @methodOf INTACT.PolicyChange.service:$PolicyChangeConfigurationProvider
		 * @description
		 * Return the set of configuration
		 * @return {Object} Return the current set of configuration
		 */
		this.$get = function(){
			return defaults;
		};

		/**
		 * @ngdoc method
		 * @name $PolicyChangeConfigurationProvider#setDefaults
		 * @methodOf INTACT.PolicyChange.service:$PolicyChangeConfigurationProvider
		 * @description
		 * Push new value in default set of configurations
		 * @return {Object} Return the current PolicyChange provider instance for chaining
		 */
		this.setDefaults = function(properties){
			
			var keys = Object.keys(properties);
			for(var i = 0, l = keys.length; i < l; i++) {
				var key = keys[i];
				if(defaults.hasOwnProperty(key)){
					defaults[key] = properties[key];
				}
			}
			return this;
		};
	});
})(angular);