(function(angular){
	'use strict';

	/**
     * @ngdoc service
     * @name INTACT.PolicyChange.$PCAppConfigurationProvider
     * @requires INTACT.Core.$CoreConfigurationProvider
	 * @requires CONFIGURATION
     *
     * @example
     * <pre>
     * var MyModule = angular.module('MyModule', ['INTACT.Core']);
     *
     * MyModule.config(function($AppConfigurationProvider){
     * 	var configs = $AppConfigurationProvider.$get();
     * });
     *
     * // In service
     * MyModule.service('MyService', function($AppConfigurationProvider){
     * 	var partialsViewsPath = $AppConfigurationProvider.partialsViewsPath;
     * });
     * </pre>
     *
     * @description
     * Provide configuration variables and expose values :
     * <pre>
     * {
     * 	viewsPath: 'path/views'
     * 	moduleViewsPath: '/path/module/views/folder',
     * 	verbose: (true|false),
     * 	cache: (true|false),
     * 	defaultLanguage: 'fr'
     * }
     * </pre>
     **/
	angular.module('INTACT.PolicyChange').provider('$PCAppConfiguration', provider);

	// Service implementation
	function provider($CoreConfigurationProvider, CONFIGURATION) {
		// Core configs
        var coreConfigs = $CoreConfigurationProvider.$get(),
 			language = CONFIGURATION.language || coreConfigs.preferredLanguage;
	
		// Module specifics configs
		var configs = {
               partialsViewsPath: coreConfigs.viewsPath + '/partials',
               directivesViewsPath: coreConfigs.viewsPath + '/directives',
               componentsViewsPath: coreConfigs.viewsPath + '/components',
               preferredLanguage: language.toLowerCase(),
               appName: CONFIGURATION.companyName || '',
               addressRestApiKey : CONFIGURATION.addressRestApiKey || '',
               addressRestBasePath : CONFIGURATION.addressRestBasePath || '', 
               logoutUrl: '/pkmslogout',
               websiteUrl: CONFIGURATION.homepage || '',
               contactUsURL: CONFIGURATION.contactUsURL || '',
               privacyURL: CONFIGURATION.privacyURL || '',
               clientCentreUrl: CONFIGURATION.clientCentreUrl || '',
               useTermsURL: CONFIGURATION.useTermsURL || '',
               securityURL: CONFIGURATION.securityURL || '',
               entrustURL: CONFIGURATION.entrustURL || '',
               entrustClientUrl: CONFIGURATION.entrustProfile || '',
               copyright: CONFIGURATION.copyRight || '',
               companyName: CONFIGURATION.companyName || '',
               province: CONFIGURATION.province,
               agent: CONFIGURATION.agent,
               policyNumber: CONFIGURATION.policyNo,
               cacheDisabled: true,
               viewsPath : coreConfigs.viewsPath,
               rdblckPhoneNumber: CONFIGURATION.rdblckPhoneNumber || '',
               pchPhoneNumber: CONFIGURATION.pchPhoneNumber || '',
               chat: CONFIGURATION.chat || '',
               chatAvailable: CONFIGURATION.chatAvailable === 'true' ? true : false,
               chatPostId: CONFIGURATION.chatPostid || '',
               chatQuestId: CONFIGURATION.chatQuestid || '',
               chatUrl: CONFIGURATION.chatUrl || '',
               openingHourMondayToFriday : CONFIGURATION.openingHourMondayToFriday || '',
               openingHourSaturday : CONFIGURATION.openingHourSaturday || '',
               closingHourMondayToFriday : CONFIGURATION.closingHourMondayToFriday || '',
               closingHourSaturday : CONFIGURATION.closingHourSaturday || '',
               claimsPhoneNumber : CONFIGURATION.claimsPhoneNumber || ''
		};

          if(CONFIGURATION.webserviceBasePath){
               configs.webserviceBasePath = CONFIGURATION.webserviceBasePath;
          }

          if(CONFIGURATION.webserviceBaseUrl){
               configs.webserviceBaseUrl = CONFIGURATION.webserviceBaseUrl;
          }

          /**
           * Synchronize Core configs with App configs
           */
		$CoreConfigurationProvider.setConfigurations(configs);

          /**
		* @ngdoc property
		* @name INTACT.PolicyChange.$PCAppConfigurationProvider#configuration
		* @propertyOf INTACT.PolicyChange.$PCAppConfigurationProvider
		* @description
		* Current Configurations
		* @returns {Object} Current Configurations
		*/
		this.configuration = angular.extend({}, coreConfigs, configs);

		/**
		* @ngdoc service
		* @name INTACT.PolicyChange.$PCAppConfiguration
		* @description
		* Service return Policy Change App configuration
          *
          * @example
          * <pre>
          * angular.module('PolicyChange').service('MyService', service);
          *
          * function service($PCAppConfiguration){
          *
          *    return {
          *         getChatConfig: function(){
          *              return $PCAppConfiguration.chat;
          *         }
          *    }
          * }
          * </pre>
		*/
		this.$get = function(){
               return this.configuration;
		};
	}
})(angular);
