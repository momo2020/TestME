(function(angular){
	'use strict';

	/*
	* @ngdoc service
	* @name INTACT.PolicyChange.service:VehicleModel
	* @description
	* Data mapping service for vehicle DTO Object
	* 
	* @requires
	* 
	* @example
	* <pre>
	* // Data from API REST vehicle object
	* var data = {};
	* 
	* // Model
	* var vehicleModel = new VehicleModel(data.vehicles[x]);
	* // Vehicle
	* {
	*	sequenceNumber :  0,
	*	sequence :  0,
	*	purchaseDate :  '',
	*	model : vehicleMakeModel,
	*	serialNumber : '',
	*	drivers :  [],
	*	conditionWhenBought :  null,
	*	leased :  null,
	*	modified :  null,
	*	modifiedForPerformance : null,
	*	modificationWorth : null,
	*	winterTire :  null,
	*	parkedAtPolicyHolderlocation :  null,
	*	newPostalCode : '',
	*	annualKmForBusiness : 0,
	*	annualKm : null,
	*	antiTheftDeviceIndicator : null,
	*	postalCodeOverriden : null,
	*	annualKm : '',
	*	usedForBusiness : null,
	*	usedToTransportGoods : null,
	*	workOrSchoolKm : 0,
	*	usedOutsideProvinceOrCountry : null,
	*	registerOwner : "",
	*	principalDriver : ""
	* }
	* </pre>
	*/
	angular.module('INTACT.PolicyChange').factory('VehicleModel', Factory);

	function Factory($filter, 
					$log, 
					VehicleMakeModel,
	 				$PolicyChangeValidation,
	 				AntitheftModel){

		function Vehicle(data){
			var _data = angular.copy(data || {}),
				vehicleMakeModel = new VehicleMakeModel(),
				antitheftDevices = [];

			if( _data.hasOwnProperty('model') ){
				vehicleMakeModel = new VehicleMakeModel(_data.model);
			}

			if(_data.hasOwnProperty('antiTheftDevices') && _data.antiTheftDevices.length > 0){
				angular.forEach(_data.antiTheftDevices, function(anditheftDevice){
					antitheftDevices.push(new AntitheftModel(anditheftDevice));
				});
			}

			var resetAboutThisCar = function (car){
				car.usageModified = true;
                car.conditionWhenBought = '';
                car.leased = null;
                car.modified = null;
                car.modificationWorth = null;
                car.winterTire = null;
                car.antiTheftDevice = null;
                car.antiTheftDevices = [];

                return car;
			};

			var isVehicleYearInList = function (year, bottomTreshold, topTreshold){
				return year <= topTreshold && year >= bottomTreshold;
			};

			var hasError = function(){

				var hasError = false;
				if( this.vehicle.usageModified && (this.vehicle.annualKm === null  || this.vehicle.workOrSchoolKm === null || (this.vehicle.usedForBusiness === true && this.vehicle.usedToTransportGoods === false && this.vehicle.businessAnnualKm === null)) ){
					hasError = true;
				}
				if($PolicyChangeValidation.hasErrorByRisk(this.vehicle.riskIndex)){
					hasError = true;
				}

				return hasError;
			};

			var resetBusinessAnnualKm = function(car){
				if(car.vehicle.usedToTransportGoods){
				    car.vehicle.businessAnnualKm = null;
				}
			};

			var vehicle = {
				addressChanged 					: _data.addressChanged || false,
				annualKm 						: _data.annualKm ? _data.annualKm.toString() : null,
				annualPremium 					: _data.annualPremium,
				showUnrepairedDamage 			: typeof _data.showUnrepairedDamage === 'boolean' ? _data.showUnrepairedDamage : false,
				unrepairedDamage 				: typeof _data.unrepairedDamage === 'boolean' ? _data.unrepairedDamage : null,
				antiTheftDevice 				: typeof _data.antiTheftDevice === 'boolean' ? _data.antiTheftDevice : null,
				antiTheftDevices 				: antitheftDevices,
				businessAnnualKm 				: _data.businessAnnualKm || null,
				annualKmModified				: _data.annualKmModified || false,
				workKmModified					: _data.workKmModified || false,
				conditionWhenBought 			: _data.conditionWhenBought || null,
				coverageModified 				: _data.coverageModified || false,
				coverages 						: _data.coverages ||  [],				
				goodDriverDate					: _data.goodDriverDate || null,
				leased 							: typeof _data.leased === 'boolean' ? _data.leased : null,
				model 							: _data.model || vehicleMakeModel,
				modificationCode 				: _data.modificationCode || null,
				modificationWorth 				: _data.modificationWorth ? _data.modificationWorth.toString() : 0,
				modified 						: typeof _data.modified === 'boolean' ? _data.modified : null,
				modifiedForPerformance 			: typeof _data.modifiedForPerformance === 'boolean' ? _data.modifiedForPerformance : false,
				outsideProvinceOrCountryKm		: _data.outsideProvinceOrCountryKm != null ? _data.outsideProvinceOrCountryKm.toString() : null,
				postalCodeOverriden 			: typeof _data.postalCodeOverriden === 'boolean' ? _data.postalCodeOverriden : null,
				principalDriver 				: _data.principalDriver || null,
				principalDriverSince 			: _data.principalDriverSince || null,
				purchaseDate 					: _data.purchaseDate || '',
				registerOwner 					: _data.registerOwner || null,
				riskIndex 						: _data.riskIndex || 0,
				sequenceNumber 					: _data.sequenceNumber || 0,
				serialNumber 					: _data.serialNumber || '',
				usageModified 					: _data.usageModified || false,
				usedForBusiness 				: typeof _data.usedForBusiness === 'boolean' ? _data.usedForBusiness : null,
				usedOutsideProvinceOrCountry	: typeof _data.usedOutsideProvinceOrCountry === 'boolean' ? _data.usedOutsideProvinceOrCountry : null,
				usedToTransportGoods 			: typeof _data.usedToTransportGoods === 'boolean' ? _data.usedToTransportGoods : null,
				winterTire 						: typeof _data.winterTire === 'boolean' ? _data.winterTire : null,
				workOrSchoolKm 					: _data.workOrSchoolKm,
				parkingIndoor					: typeof _data.parkingIndoor === 'boolean' ? _data.parkingIndoor : null,
				parkingType						: _data.parkingType || null
			};
			
			return {
				vehicle 				: vehicle,
				resetAboutThisCar 		: resetAboutThisCar,
				hasError 				: hasError,
				resetBusinessAnnualKm	: resetBusinessAnnualKm,
				isVehicleYearInList 	: isVehicleYearInList
			};
		}


		return Vehicle;
	}
})(angular);