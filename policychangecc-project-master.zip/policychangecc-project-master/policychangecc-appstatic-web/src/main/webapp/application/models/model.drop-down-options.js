(function(angular){
	'use strict';

	/*
	* @ngdoc service
	* @name INTACT.PolicyChange.service:DropDownOptionsModel
	* @description
	* Persist the drop down options for each vehicle
	* 
	* @requires
	* 
	* @example
	* <pre>
	*	{
	*		riskIndex : {Integer},
	*		yearOptions : [],
	*		modelOptions : [],
	*		makeOptions : [],
	*		yearOptionsOriginal : [],
	*		modelOptionsOriginal : [],
	*		makeOptionsOriginal	: [],
	*		vehiclesYearMax : '',
	*		vehiclesYearMin : ''
	*	}
	* </pre>
	*/
	angular.module('INTACT.PolicyChange').factory('DropDownOptionsModel', Factory);

	function Factory(){

		function DropDownOptions(options){
			var _options = angular.copy(options || {});
			
			return {
				riskIndex 			: _options.riskIndex || 0,
				yearOptions 		: _options.yearOptions || [],
				modelOptions 		: _options.modelOptions || [],
				makeOptions			: _options.makeOptions || [],
				yearOptionsOriginal	: _options.yearOptionsOriginal,
				modelOptionsOriginal: _options.modelOptionsOriginal,
				makeOptionsOriginal : _options.makeOptionsOriginal,
				vehiclesYearMax		: _options.vehiclesYearMax || '',
				vehiclesYearMin		: _options.vehiclesYearMin || ''
			};
		}

		return DropDownOptions;
	}
})(angular);