(function(angular){
	'use strict';

	/**
	 * @ngdoc service
	 * @name INTACT.PolicyChange.service:CoverageValueModel
	 * @description 
	 * Data mapping service for coverage value DTO Object
	 * @example
	 * <pre>
	 * var data = {
	 * 	"amount":0.0,
	 * 	"sequence":0
	 * },
	 * coverageValue = new CoverageValueModel(data);
	 * // Coverage Value 
	 * {
	 * 	selected: false,
	 * 	amount: {Number|null},
	 * 	label: 'String amount formatted'
	 * }
	 * </pre>
	 */
	angular.module('INTACT.PolicyChange').factory('CoverageValueModel', Factory);

	function Factory($filter){
		var $currency = $filter('currency'),
			notCoveredLabel = $filter('translate')('policychange.coverage.not.covered');

		function CoverageValue(data){
			var _data = angular.copy(data),
				amount = (_data.hasOwnProperty('amount') && _data.amount !== null)? _data.amount : null,
				label = (amount === null)? notCoveredLabel : $currency(amount, '$', 0);

			return {
				selected: false,
				amount: amount,
				label: label
			};
		}

		return CoverageValue;
	}
})(angular);