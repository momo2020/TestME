 (function(angular){
    'use strict';


    angular.module('INTACT.PolicyChange').factory('ValidationModel', Factory);

    function Factory(){

        function validationMessage(message){
            var _data = angular.copy(message || { message : [] }),            
                errorMessage = (_data.message.length > 0) ? _data.message[0] : "";
            
            return {
                message: errorMessage
            };
        }

        return validationMessage;
    }
})(angular); 