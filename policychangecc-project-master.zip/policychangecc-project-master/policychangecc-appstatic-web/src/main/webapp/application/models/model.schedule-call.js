(function(angular){
	'use strict';

	/*
	* @ngdoc service
	* @name INTACT.PolicyChange.service:ScheduleCallModel
	* @description
	* Data mapping service for schedule a call DTO Object
	*
	* @requires
	*/

	angular.module('INTACT.PolicyChange').factory('ScheduleCallModel', Factory);

	function Factory(){

		return function(data){
			
			return {
				descriptionPrefix		: "",
				description				: "",
				areaCode				: null,
				phoneNumber				: null,
				extension				: null,
				preferedTime			: null,
				phoneExchange			: null,
				otherPhoneNumber		: false
			};

		};
	}
})(angular);
