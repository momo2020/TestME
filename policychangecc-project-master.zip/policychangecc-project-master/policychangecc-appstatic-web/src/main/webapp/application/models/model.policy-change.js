(function(angular){
    'use strict';

    /**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:PolicyChangeModel
     * @description 
     * Data object for mapping DTO Object from REST API (split current policy && policy change )
     * 
     * @example
     * <pre>
     * // Data get by Api Rest /policy call (cf. $PolicyChangeService)
     * var PolicyData = {},
     * // Policy change Model
     * var pcModel = new PolicyChangeModel(CurrentRisk, PolicyChangeRisk);
     * </pre>
     */
    angular.module('INTACT.PolicyChange').factory('PolicyChangeModel', factory);

    function factory (){
        function PolicyChange(data){
            var _data = angular.copy(data || {});

            // Split the current policy vs policy change
            var _currentPolicy = {},
                _policyChange = {},
                _state = {},
                _validation = {},
                _minEffectiveDate = "",
                _maxEffectiveDate = "",
                _retiredAgeThreshold = 50,
                _studentAgeThreshold = 25,
                _canAddVehicle       = false,
                _canAddDriver        = false,
                _driverAgeThreshold  = 99;

            if(_data.response){
                // Current policy 
                _currentPolicy = angular.copy(data.response);

                if(_currentPolicy.hasOwnProperty('policyChange')) {
                    // Policy Change
                    _policyChange = angular.copy(_currentPolicy.policyChange);
                    // Remove property in current policy
                    delete _currentPolicy.policyChange;
                }
            }

            if(_data.state){
                _state = _data.state;
                _minEffectiveDate             = _state.effectiveDateMin;
                _maxEffectiveDate             = _state.effectiveDateMax;
                _retiredAgeThreshold          = _state.retiredAgeThreshold || _retiredAgeThreshold;
                _studentAgeThreshold          = _state.studentAgeThreshold || _studentAgeThreshold;
                _state._canAddVehicle         = _state.canAddVehicle       || _canAddVehicle;
                _state._canAddDriver          = _state.canAddDriver        || _canAddDriver;
                _state.driverAgeThreshold     = _state.driverAgeThreshold  || _driverAgeThreshold;
            }
            _validation = _data.validation || null;

            return {
                data                : _data,
                currentPolicy       : _currentPolicy,
                policyChange        : _policyChange,
                state               : _state,
                validation          : _validation,
                minEffectiveDate    : _minEffectiveDate,
                maxEffectiveDate    : _maxEffectiveDate,
                studentAgeThreshold : _studentAgeThreshold,
                retiredAgeThreshold : _retiredAgeThreshold,
                driverAgeThreshold  : _driverAgeThreshold
            };
        }

        return PolicyChange;
    }

})(angular);
