(function(angular){
    'use strict';

    /**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:InitializationModel
     * @description 
     * Data object for mapping DTO Object from REST API (split current policy && policy change )
     * 
     * @example
     * <pre>
     * // Data get by Api Rest /policy call (cf. $InitializationService)
     * var PolicyData = {},
     * // Policy change Model
     * var pcModel = new InitializationModel(init);
     * </pre>
     */

    angular.module('INTACT.PolicyChange').factory('InitializationModel', factory);

    function factory (){
        function InitializationState(init){

            var _init = angular.copy(init.initialization || {}),
                _state = angular.copy(init.state);


            var _transactionInitialized     = _state.transactionInitialized || false,
                _taskschanged               = _state.taskschanged || false,
                _previousPage               = _state.previousPage || 'PC_START',
                _currentPage                = _state.currentPage || 'PC_START',
                _nextPage                   = _state.nextPage || 'PC_START',
                _pages                      = _state.pages || [],
                _tasks                      = _state.tasks || [],
                _effectiveDateMin           = _state.effectiveDateMin || "",
                _effectiveDateMax           = _state.effectiveDateMax || "",
                _vehiclesYearMin            = _state.vehiclesYearMin,  
                _vehiclesYearMax            = _state.vehiclesYearMax,
                _transactionEffectiveDate   = _init.transactionEffectiveDate || "",
                _selectedTasks              = _init.selectedTasks || [],
                _canAddVehicle              = _state.canAddVehicle || false,
                _canAddDriver               = _state.canAddDriver || false;
            
            return {
                    initialization : {
                        transactionEffectiveDate   : _transactionEffectiveDate,
                        selectedTasks              : _selectedTasks       
                    },
                    state : {
                        taskschanged               : _taskschanged,
                        previousPage               : _previousPage,
                        currentPage                : _currentPage,
                        nextPage                   : _nextPage,
                        pages                      : _pages,
                        tasks                      : _tasks,
                        effectiveDateMin           : _effectiveDateMin,
                        effectiveDateMax           : _effectiveDateMax,
                        transactionInitialized     : _transactionInitialized,
                        vehiclesYearMin            : _vehiclesYearMin,  
                        vehiclesYearMax            : _vehiclesYearMax,
                        canAddVehicle              : _canAddVehicle,
                        canAddDriver               : _canAddDriver
                    }
            };
        }

        return InitializationState;
    }

})(angular);
