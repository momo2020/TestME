(function(angular){
	'use strict';

	/*
	* @ngdoc service
	* @name INTACT.PolicyChange.service:VehicleMakeModel
	* @description
	* Data mapping service for vehicle model object
	* 
	* @requires
	* 
	* @example
	* <pre>
	* // Data from API REST vehicle object
	* var data = {};
	* 
	* // Model
	* var vehicleMakeModel = new VehicleMakeModel(vehicleData.model);
	* // Model
	* {
	* 	make : '',
	* 	model : '',
	* 	year : 0,
	* 	code : ''
	* }
	* </pre>
	*/
	angular.module('INTACT.PolicyChange').factory('VehicleMakeModel', Factory);

	function Factory(){

		function VehicleModel(data){
			var _data = angular.copy(data || {});

			return {
				make : _data.make || '',
				model: _data.model || '',
				year : (_data.year) ? String(_data.year) : '',
				code : _data.code || '' 
				
			}; 
		}

		return VehicleModel;
	}
})(angular);