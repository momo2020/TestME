(function(angular){
	'use strict';

	/*
	 * @ngdoc service
	 * @name INTACT.PolicyChange.service:DriverModel
	 * @description
	 * Data mapping service for driver DTO Object
	 *
	 * @requires
	 *
	 * @example
	 * <pre>
	 * // Data from API REST driver object
	 * var data = {};
	 *
	 * // Model
	 * var driverModel = new VehicleModel(data.drivers[x]);
	 * // driverModel
	 *	driverModel = {
	 *			driver 						: driver,
	 *			getDateOfBirth				: getDateOfBirth,
	 *			buildDob 					: buildDob,
	 *			showIsRetired				: showIsRetired,
	 *			showIsStudent 				: showIsStudent,
	 *			showPermanentAddressInd 	: showPermanentAddressInd,
	 *			show100KmInd 				: show100KmInd,
	 *			getDriverLicenceYears 		: getDriverLicenceYears,
	 *			licenceObtained5YearsOrLess : licenceObtained5YearsOrLess,
	 *			updateDriverDate 			: updateDriverDate, 
	 *			clearDriverInformations		: clearDriverInformations,
	 *			getAge						: getAge
	 *		};
	 * </pre>
	 */

	angular.module('INTACT.PolicyChange').factory('DriverModel', Factory);

	function Factory(ConvictionsModel, 
					ClaimsModel, 
					PolicyChangeModel,
					$filter,
					$InlineValidationService,
					$WorkSectorService,
					$rootScope,
					$log){

		function Driver(data) {

			var _data = angular.copy(data || {}),
				_convictions = [],
				_claims = [],
				hasClaims = false,
				$validDate = $filter('validateDate'),
				$translate = $filter('translate'),
				$orderBy = $filter('orderBy');

			if (_data.driver) {
				_data = _data.driver;
			}

			hasClaims = (_data.claims && _data.claims !== null) ? _data.claims.length > 0 : false;

			if (_data.convictionsCount > 0) {
				for (var i = 0, ll = _data.convictions.length; i < ll; i++) {
					_convictions.push(new ConvictionsModel(_data.convictions[i]));
				}
			}
			if (hasClaims) {
				for (var j = 0, jj = _data.claims.length; j < jj; j++) {
					var claim = new ClaimsModel(_data.claims[j]);
					_claims.push(claim);
				}
			}

			/**
			 * @ngdoc method
			 * @name DriverModel#updateDriverDate
			 * @methodOf INTACT.PolicyChange.model:DriverModel
			 * @description
			 * Update the a date for a 2 with an object
			 * @param  {String} prop     driver's porperty to update
			 * @param  {Object} dateObj	 object containing year and month values
			 */
			var updateDriverDate = function(prop, dateObj) {
				if (dateObj) {
					if (((dateObj.year !== "")) && ((dateObj.month !== ""))) {
						this.driver[prop] = dateObj.year + "-" + dateObj.month + "-01";
					}
				} else {
					this.driver[prop] = "";
				}
			};

			var getAgesList = function(){
				var list = [],
					age = getAge(this.driver.dateOfBirth);

				for(i = 16, ll = age ; i < ll ; i++){
					list.push({key : parseInt(i), value : i});
				}
	 			list.unshift({key : null, value : $filter('translate')('LBLXXXX.car.select') });

				return list;
			};

			/**
			 * @ngdoc method
			 * @name DriverModel#getDriverLicenceYears
			 * @methodOf INTACT.PolicyChange.model:DriverModel
			 * @description
			 * Calculate the list of years for licence
			 */
			var getDriverLicenceYears = function() {
				//var dobYear = this.driver.dateOfBirth || "";
				var years = [];
				if (this.driver.dateOfBirth) {
					var minyear = parseInt(this.driver.dateOfBirth.split('-')[0]) + 16;
					var currentYear = new Date().getFullYear();
					years.push({
						key : '',
						value : $translate('policychange.placeholder.year')
					});
					var y = minyear;
					for (y ; y <= currentYear; y++) {
						years.push({
							key: y.toString(),
							value: y.toString()
						});
					}
				}
				return years;
			};

			/**
			 * @ngdoc method
			 * @name DriverModel#licenceObtained5YearsOrLess
			 * @methodOf INTACT.PolicyChange.model:DriverModel
			 * @description
			 * Calculates if the licence has been obtained in 5 years or less
			 */
			var licenceObtained5YearsOrLess = function() {
				if (this.driver.licenceObtentionDate) {
					if (this.driver.licenceObtentionDate !== "") {
						var yr = this.driver.licenceObtentionDate.split('-')[0],
							mn = this.driver.licenceObtentionDate.split('-')[1],
							licenceDate = new Date(parseInt(yr), parseInt(mn) - 1, 1, 0, 0, 0, 0);
						var today = new Date();
						var months = (today.getFullYear() - licenceDate.getFullYear()) * 12;
						months -= licenceDate.getMonth() + 1;
						months += today.getMonth() + 1;
						return (months <= 0 ? 0 : months) <= 60;
					}
				}
				return null;
			};

			/**
			 * @ngdoc method
			 * @name DriverModel#getDateOfBirth
			 * @methodOf INTACT.PolicyChange.model:DriverModel
			 * @description
			 * returns the year / month/ day of the date of birth
			 * @param {String} temp 	'year', 'month' or 'day'
			 * @param {String} dob 		'1970-01-01' formated dob
			 */
			var getDateOfBirth = function(temp, dob) {
				var dateArray = dob ? dob.split('-') : ['', '', ''],
					wantedInd = 0;
				switch (temp) {
					case 'day':
						wantedInd = 2;
						break;
					case 'month':
						wantedInd = 1;
						break;
					case 'year':
						wantedInd = 0;
						break;
				}

				return dateArray[wantedInd];
			};

			var driversDobObject = function() {
				return {
					year: getDateOfBirth('year', driver.dateOfBirth),
					month: getDateOfBirth('month', driver.dateOfBirth),
					day: getDateOfBirth('day', driver.dateOfBirth)
				};
			};

			var buildDob = function(dateObj, elementIndex) {
				var date = dateObj.year + '-' + dateObj.month + '-' + dateObj.day;
				if (!$validDate(date)) {
					var validation = [{
						elementIndex: elementIndex,
						elementSubIndex: null,
						field: 'DE0049',
						message: $translate('MSG05844.error.invalidformat'),
						sequence: null
					}];
					$InlineValidationService.triggerValidation(validation);
					date = null;
				}
				return date;
			};

			var showIsStudent = function(dob, treshold) {
				var driverAge = dob !== null ? getAge(dob) : 99;
				return driverAge < treshold;
			};

			var showIsRetired = function(dob, treshold) {
				var driverAge = dob !== null ? getAge(dob) : 0;
				return driverAge >= treshold;
			};

			var showPermanentAddressInd = function(driver) {
				var isShow = isFullTimeStudent(driver);
				if (!isShow) {
					driver.permanentAddress = null;
				}
				return isShow;
			};

			var show100KmInd = function(driver) {
				var isShow = isFullTimeStudent(driver) && livesWithParents(driver);
				if (!isShow) {
					driver.school100KmFromParent = null;
				}
				return isShow;
			};

			var isFullTimeStudent = function(driver) {
				return driver.fullTimeStudent === true ? true : false;
			};

			var livesWithParents = function(driver) {
				return driver.permanentAddress === true ? true : false;
			};

			var getAge = function(stringDateOfBirth) {
				// stringDateOfBirth format = 'YYYY-MM-DD'
				stringDateOfBirth = angular.isDefined(stringDateOfBirth) && stringDateOfBirth !== null ? stringDateOfBirth : "";
				var today = new Date();
				var birthDate = new Date(stringDateOfBirth.replace(/(-)/g, '/'));
				var age = today.getFullYear() - birthDate.getFullYear();
				var m = today.getMonth() - birthDate.getMonth();
				if (m < 0 || (m === 0 && today.getDate() > birthDate.getDate())) {
					age--;
				}
				return age;
			};

			var getFullName = function() {
				return driver.firstName+'&nbsp;'+driver.lastName;
			};

			// Clear driver after update
			function clearDriverInformations() {
				for (var props in this.driver) {
					var okToClear = ((props !== "firstName") && (props !== "lastName") && (props !== "dateOfBirth") && (props !== "driverIndex") && (props !== "sequence") && (props !== "modificationCode"));
					if (okToClear && this.driver[props] !== null) {
						if (Array.isArray(this.driver[props])) {
							this.driver[props] = [];
						} else {
							switch (typeof this.driver[props]) {
								case "number":
									this.driver[props] = 0;
									break;
								case "string":
									this.driver[props] = "";
									break;
								case "object":
									this.driver[props] = {};
									break;
								default:
									this.driver[props] = null;
							}
						}
					}
				}
			}

			var driver = {
				ageGotLicence				: _data.ageGotLicence || null,
				cancelledPolicyReason		: _data.cancelledPolicyReason || "",
				claims 						: _claims,
				convictions 				: _convictions,
				convictionsCount 			: _data.convictionsCount || "",
				criminalRecord				: typeof _data.criminalRecord === 'boolean' ? _data.criminalRecord : null,
				dateOfBirth 				: _data.dateOfBirth || "",
				driverIndex					: _data.driverIndex || 0,
				driverLicenceClass 			: typeof _data.driverLicenceClass === 'boolean' ? _data.driverLicenceClass : null,
				driverLicenceType 			: _data.driverLicenceType || "",
				driverTrainingCourse 		: typeof _data.driverTrainingCourse === 'boolean' ? _data.driverTrainingCourse : null,
				firstName 					: _data.firstName || "",
				fullTimeStudent 			: typeof _data.fullTimeStudent === 'boolean' ? _data.fullTimeStudent : null,
				g2LicenceDate 				: typeof _data.g2LicenceDate === 'boolean' ? _data.g2LicenceDate : null,
				gender 						: _data.gender || "",
				infractionsPast3Years 		: typeof _data.infractionsPast3Years === 'boolean' ? _data.infractionsPast3Years : null,
				lastName 					: _data.lastName || "",
				licenceNumber 				: _data.licenceNumber || "",
				licenceObtentionDate 		: _data.licenceObtentionDate || "",
				licenseRevoked 				: typeof _data.licenseRevoked === 'boolean' ? _data.licenseRevoked : null,
				lossesYears 				: typeof _data.lossesYears === 'boolean' ? _data.lossesYears : null,
				majorInfraction 			: typeof _data.majorInfraction === 'boolean' ? _data.majorInfraction : null,
				majorInfractionCount 		: _data.majorInfractionCount || "",
				maritalStatus 				: _data.maritalStatus || "",
				minorInfractionCount 		: _data.minorInfractionCount || 0,
				modificationCode 			: _data.modificationCode || null,
				monthNotLivingParent		: _data.monthNotLivingParent || null,
				obtainedG2OrG 				: typeof _data.obtainedG2OrG === 'boolean' ? _data.obtainedG2OrG : null,
				occupation 					: _data.occupation || null,
				penaltyPointsAmount 		: _data.penaltyPointsAmount || null,
				permanentAddress 			: typeof _data.permanentAddress === 'boolean' ? _data.permanentAddress : null,
				policyHolder 				: _data.policyHolder || false,
				principalDriverSince 		: _data.principalDriverSince || null,
				priorCarrier 				: typeof _data.priorCarrier === 'boolean' ? _data.priorCarrier : null,
				priorCarrierCancelled 		: typeof _data.priorCarrierCancelled === 'boolean' ? _data.priorCarrierCancelled : null,
				priorCarrierPolicyNumber 	: _data.priorCarrierPolicyNumber || '',
				relationshipToPolicyHolder 	: _data.relationshipToPolicyHolder || null,
				retired 					: typeof _data.retired === 'boolean' ? _data.retired : null,
				school100KmFromParent 		: typeof _data.school100KmFromParent === 'boolean' ? _data.school100KmFromParent : null,
				sequence 					: _data.sequence || 0,
				severeInfractionCount 		: _data.severeInfractionCount || "",
				universityDiploma 			: typeof _data.universityDiploma === 'boolean' ? _data.universityDiploma : null,
				workSector					: _data.workSector || ""
			};

			return {
				driver: driver,
				getDateOfBirth: getDateOfBirth,
				buildDob: buildDob,
				showIsRetired: showIsRetired,
				showIsStudent: showIsStudent,
				showPermanentAddressInd: showPermanentAddressInd,
				show100KmInd: show100KmInd,
				getDriverLicenceYears: getDriverLicenceYears,
				licenceObtained5YearsOrLess: licenceObtained5YearsOrLess,
				updateDriverDate: updateDriverDate,
				clearDriverInformations: clearDriverInformations,
				getAge: getAge,
				getFullName : getFullName,
				driversDobObject : driversDobObject,
				getAgesList : getAgesList
			};
		}

		return Driver;
	}
})(angular);