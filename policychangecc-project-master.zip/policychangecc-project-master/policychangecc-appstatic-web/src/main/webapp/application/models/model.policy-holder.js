(function(angular){
	'use strict';

	/*
	* @ngdoc service
	* @name INTACT.PolicyChange.service:PolicyHolderModel
	* @description
	* Data mapping service for vehicle DTO Object
	* 
	* @requires
	* 
	* @example
	* <pre>
	* // Data from API REST vehicle object
	* var data = {};
	* 
	* // Model
	* var PolicyHolderModel = new PolicyHolderModel(data.vehicles[x]);
	* // PolicyHolder
	* {
	*	partyId 		: Integer,
	*	address 		: Object,
	*	dateOfBirth		: String,
	*	driverLicence 	: String,
	*	emailAddress 	: String,
	*	firstName 		: String,
	*	gender			: String,
	*	lastName		: String,
	*	martialStatus	: String,
	*	phoneExtension 	: String,
	*	phoneNumber 	: String,
	*	type			: String
	* }
	* </pre>
	*/
	angular.module('INTACT.PolicyChange').factory('PolicyHolderModel', Factory);

	function Factory(){

		function PolicyHolder(data){
			var _data = angular.copy(data || {});
			
			return {
				partyId 				: _data.partyId || 0,
				address 				: _data.address || {},
				businessPhoneExtension 	: _data.businessPhoneExtension || '',
				businessPhoneNumber 	: _data.businessPhoneNumber || '',
				dateOfBirth				: _data.dateOfBirth || '',
				driverLicence 			: _data.driverLicence || '',
				emailAddress 			: _data.emailAddress || '',
				firstName 				: _data.firstName || '',
				gender					: _data.gender || '',
				homePhoneExtension 		: _data.homePhoneExtension || '',
				homePhoneNumber 		: _data.homePhoneNumber || '',
				lastName				: _data.lastName || '',
				martialStatus			: _data.martialStatus || '',
				type					: _data.type || ''
			};
		}

		return PolicyHolder;
	}
})(angular);