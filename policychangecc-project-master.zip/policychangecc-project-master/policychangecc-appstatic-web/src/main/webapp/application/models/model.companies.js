(function(angular){
    'use strict';

    /**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:CompaniesModel
     * @description
     * Data from the companies service
     *
     * @example
     * <pre>
     * 
     * </pre>
     */
    angular.module('INTACT.PolicyChange').factory('CompaniesModel', factory);

    function factory (){
        function CompaniesModel(data){

            var _data = angular.copy(data || {});

            var kvData = [];
            // Prepare the Key-Value array object
            for(var propt in _data){
                kvData.push({key: propt, value: _data[propt]});
            }
            
            return {
                data : kvData
            };
        }
       
        return CompaniesModel;
    }

})(angular);
