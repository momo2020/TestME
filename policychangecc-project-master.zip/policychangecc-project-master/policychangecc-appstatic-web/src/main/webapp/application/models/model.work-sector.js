(function(angular){
    'use strict';

    /**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:WorkSectorModel
     * @description
     * Data from the work sectors 
     *
     * @example
     * <pre>
     * 
     * </pre>
     */
    angular.module('INTACT.PolicyChange').factory('WorkSectorModel', factory);

    function factory (){
        function WorkSectorModel(data){

            var _data = angular.copy(data || {});

            var kvData = [];
            // Prepare the Key-Value array object
            for(var propt in _data){
                kvData.push({key: propt, value: _data[propt]});
            }
            
            return {
                data : kvData
            };
        }
       
        return WorkSectorModel;
    }

})(angular);
