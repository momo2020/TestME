(function(angular){
	'use strict';

	/**
	*
	*/
	angular.module('INTACT.PolicyChange').factory('AntitheftModel', Factory);

	function Factory($log){
		function AntitheftDevice(data){
			var _data = angular.copy(data || {});

			return {
				type : _data.type || null,
				modificationCode : _data.modificationCode || null,
				brand : _data.brand || null
			};
		}

		return AntitheftDevice;
	}

})(angular);