(function(angular){
	'use strict';

	/**
	 * @ngdoc service
	 * @name INTACT.PolicyChange.service:CoveragesListModel
	 * @description 
	 * Data object for display coverages list in coverages change page.
	 * - code : coverage code ;
	 * - sequence : sequence order to display ;
	 * - description : coverage description ; 
	 * - section : coverage section (displayed group by section) ;
	 * - current : label for the current policy value ;
	 * - displayModify : indicates if the modify button should be displayed or not;
	 * - displayType : indicates if we display a Label, a Select box or a Radio Button in the change to column
	 * - values : object with list of values availables for policy change (to render a select component). 
	 *
	 * @requires INTACT.PolicyChange.service:CoverageModel
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 * 
	 * @example
	 * <pre>
	 * // Data get by Api Rest /policy call (cf. $PolicyChangeService)
	 * var PolicyData = {},
	 * 	CurrentRisk = PolicyData.currentPolicy.vehicules[0],
	 * 	PolicyChangeRisk = PolicyData.policyChange.vehicules[0];
	 * // Merge formatted coverages current and policy change 
	 * var coveragesInSection = new CoveragesListModel(CurrentRisk, PolicyChangeRisk);
	 * </pre>
	 */
	angular.module('INTACT.PolicyChange').factory('CoveragesListModel', factory);

	function factory($filter, CoverageModel){
		var $translate = $filter('translate'),
			notCoveredLabel = $translate('policychange.coverage.not.covered'),
			$orderBy = $filter('orderBy');

		/**
		 * Prepare a object list coverages with a coverage model object
		 * @param  {Object} coverageModelObj Coverage Object Model
		 * @return {Object}                  Coverage list object
		 */
		function toCoverageListObject(coverageModelObj){
			var c = coverageModelObj;
			return {
				code: c.code,
				productCode: c.productCode,
				sequence: c.sequence,
				description: c.description,
				section: c.section,
				current: c.label,
				mode: c.mode,
				displayModify: c.displayModify,
				displayType: c.displayType,
				displayPackage: c.displayPackage,
				isPackage: c.isPackage,
				values: {
					id: c.code,
					data: c.toSelectData()
				}
			};
		}


		function codeAvailable(pCodes, code){
			var r = false;

			if(code !== null){
				if(!pCodes.length || pCodes.indexOf(code) !== -1){
					r = true;
				}
			}

			return r;
		}

		function CoverageList(pCurrentCoverages, pChangeCoverages, pCodes){

			var currentObjs = {},
				changeObjs = {},
				list = [],
				codes = (angular.isArray(pCodes))? pCodes : [],
				$labelFilter = $filter('formatConstructCoverageLabel'),
				column = 2;/*,
				packageObjects = [];*/

			// var init = function (currentCoverages, changeCoverages) {

			// 	for(var i = 0, ll = changeCoverages.length ; i < ll ; i++) {
			// 		var cov = changeCoverages[i];

			// 		if(cov.productCode === 'NV3') {
			// 			if(cov.productCode === cov.code) {
			// 				packageObjects.push({
			// 					packageName : "NV3",
			// 					coverageCode : cov.code,
			// 					coverage : cov,
			// 					isParent : true
			// 				});
			// 			}
			// 			else {
			// 				packageObjects.push({
			// 					packageName : "NV3",
			// 					coverageCode : cov.code,
			// 					coverage : cov,
			// 					isParent: false
			// 				});
			// 			}
			// 		}
			// 	}
			// };


			// init(pCurrentCoverages, pChangeCoverages);

			var getDisplayType = function(obj){

				var displayType = "LABEL";
				var valuesLength = obj.values ? (obj.values.length !== undefined ? obj.values.length : obj.values.data.length) : null;
				// var isPackage = obj.isPackage;

				// //PACKAGE
				// if(isPackage) {
				// 	if(isParent(obj)) {
				// 		displayType = "RADIO";
				// 	}
				// 	else if(parentIsSelected(obj)) {
				// 		displayType = "LABEL";
				// 	}
				// 	else {
				// 		displayType = "RADIO";
				// 	}
				// }

				if(obj.values){				
					if(obj.values.length !== undefined){
						if(valuesLength > 1){
							displayType = "SELECT";
						}
						else if(valuesLength === 0 && obj.mode !== "MANDATORY"){
							displayType = "RADIO";
						}
						else if(valuesLength === 1 || 
								(valuesLength < 2 && obj.mode === "MANDATORY")){
							displayType = "LABEL";
						}	
					}
					else{
						if( valuesLength === 0 && obj.values.id || (valuesLength === 1 && obj.mode !== "MANDATORY") ){
							displayType = "RADIO";
						}
						else if( valuesLength < 1 || (valuesLength === 1 && obj.mode === "MANDATORY") ){
							displayType = "LABEL";
						}
						else{
							displayType = "SELECT";
						}
					}
				}

				return displayType;			
			};

			// var parentIsSelected = function(obj) {
			// 	for( var i = 0, ll = packageObjects.length ; i < ll ; i++ ) {
			// 		var parent = $filter('filter')(packageObjects, {isParent : true, })[0].coverage;

			// 		if(packageObjects[i].coverageCode === obj.code) {
			// 			return parent.selected;
			// 		}
			// 	}

			// 	return false;
			// };

			// var isParent = function(obj) {
			// 	for(var i = 0, ll = packageObjects.length ; i < ll ; i++) {
			// 		if(packageObjects[i].coverageCode === obj.code) {
			// 			return packageObjects[i].isParent;
			// 		}
			// 	}

			// 	return false;
			// }

			// Current objects coverages
			for(var i = 0, l = pCurrentCoverages.length; i < l; i++) {
				var c = pCurrentCoverages[i];
				// For policies return outside of Ontario
				if(codeAvailable(codes, c.sectionCode)) {
					// /**
					// * TODO ARRANGER APRES POC
					// */
					// if (c.productCode === "NV3"){
					// 	c.isPackage = true;

					// 	if(c.code != "NV3") {
					// 		c.productCode = c.code;
					// 		c.displayPackage = "pkg-child";
					// 		c.parentSelected = parentIsSelected(c);
					// 	}
					// 	else {
					// 		c.displayPackage = "pkg-parent";
					// 	}
					// }

					currentObjs[c.productCode] = new CoverageModel(c);
				}
			}

			// Change objects coverages
			for(var j = 0, ll = pChangeCoverages.length; j < ll; j++) {
				var cc = pChangeCoverages[j];
				// For policies return outside of Ontario
				if(codeAvailable(codes, cc.sectionCode)) {
					// /**
					// * TODO ARRANGER APRES POC
					// */

					// if (cc.productCode === "NV3") {
					// 	cc.isPackage = true;

					// 	if(cc.code != "NV3") {
					// 		cc.productCode = cc.code;
					// 		cc.displayPackage = "pkg-child";
					// 		cc.parentSelected = parentIsSelected(cc);
					// 	}
					// 	else {
					// 		cc.displayPackage = "pkg-parent";
					// 	}
					// }

					changeObjs[cc.productCode] = new CoverageModel(cc);
					if(!currentObjs[cc.productCode]) {
						continue;
					}

					if( changeObjs[cc.productCode].mode === "MANDATORY" || currentObjs[cc.productCode].mode === "MANDATORY" ){
						if(changeObjs[cc.productCode].values.length < 1){
							// /*POC*/
							// if(cc.isPackage && cc.parentSelected) {
							// 	changeObjs[cc.productCode].label = $labelFilter("MANDATORY", "1", true, 1);
							// }
							// else {
								changeObjs[cc.productCode].label = $labelFilter(changeObjs[cc.productCode].mode, changeObjs[cc.productCode].sectionCode, changeObjs[cc.productCode].selected, column);
							// }
						}
						else if((changeObjs[cc.productCode].values.length === 1 && angular.isNumber(changeObjs[cc.productCode].selectedAmount)) ){
							changeObjs[cc.productCode].values[0].label = $labelFilter( changeObjs[cc.productCode].mode, changeObjs[cc.productCode].sectionCode, changeObjs[cc.productCode].selected, column);
						} 
					}
				}
			}

			// Inspect current
			for(var p in currentObjs) {
				// Coverage list object
				var cObject = toCoverageListObject(currentObjs[p]);
				// If policy change exists push new values from policy change coverage
				if(changeObjs.hasOwnProperty(p)){

					var change = changeObjs[p],
						displayType = getDisplayType(changeObjs[p]),
						// POC displayPackage = $filter('filter')(pChangeCoverages, {productCode : p})[0].displayPackage,
						displayModify = $filter('filter')(pChangeCoverages, {productCode : p})[0].isPackage ? false : true;

					cObject = angular.extend(cObject, {
						sequence: change.sequence,
						displayType: displayType,
						displayModify : displayModify,
						// displayPackage : displayPackage,
						// isPackage : $filter('filter')(pChangeCoverages, {productCode : p})[0].isPackage,
						values: {
							id: changeObjs[p].code,
							data: change.toSelectData()
						}
					});

					if(cObject.displayType === "LABEL" || cObject.current !== changeObjs[p].label ){
						cObject.displayModify = false;
					}
				}

				list.push(cObject);
			}

			// Inspect change coverages not in current policy coverages
			for(var pp in changeObjs) {
				if(currentObjs.hasOwnProperty(pp)){
					continue;
				}

				var modify = false,
					notSelected = "",
					cNotInCurrent = toCoverageListObject(changeObjs[pp]);

				for(var o = 0, m = cNotInCurrent.values.data.length; o < m; o++){
					if( cNotInCurrent.values.data[o].selected ){
						notSelected = cNotInCurrent.values.data[o].value === $translate('policychange.coverage.not.covered');
					}
				}
				if(cNotInCurrent.values.data.length === 0){
					notSelected = !changeObjs[pp].selected;
				}

				if(((cNotInCurrent.mode !== "MANDATORY" && notSelected ) || (cNotInCurrent.values.data === undefined && !cNotInCurrent.selected) ) /*&& !cNotInCurrent.isPackage*/ ){
					modify = true;
				}

				notCoveredLabel = $labelFilter(changeObjs[pp].mode, changeObjs[pp].sectionCode, false, 1);
				// POC var _displayPackage = $filter('filter')(pChangeCoverages, {productCode : pp})[0].displayPackage;
				cNotInCurrent = angular.extend(cNotInCurrent, {
					displayModify: modify,
					displayType: getDisplayType(cNotInCurrent)//,
					// displayPackage: _displayPackage
				});

				//if(angular.isUndefined(cNotInCurrent.isPackage) || !cNotInCurrent.isPackage){
					cNotInCurrent.current = notCoveredLabel;
				//}

				// else if(cNotInCurrent.isPackage && !isParent(cNotInCurrent) && parentIsSelected(cNotInCurrent)) {
				// 	cNotInCurrent.values.data.push({
				// 		value : $labelFilter("MANDATORY", "1", true, 1)
				// 	});
				// }



				list.push(cNotInCurrent);
			}


			return $orderBy(list, '+sequence');
		}

		return CoverageList;
	}
})(angular);