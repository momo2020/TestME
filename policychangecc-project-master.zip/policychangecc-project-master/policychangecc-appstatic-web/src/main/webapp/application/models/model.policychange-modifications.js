(function(angular){
    'use strict';

    /**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:PolicyChangeModificationsModel
     * @description
     * Data object for mapping DTO Object from REST API (split current policy && policy change )
     *
     * @example
     * <pre>
     * // Data get by Api Rest /policy call (cf. $PolicyChangeService)
     * var PolicyData = {},
     * // Policy change modification Model
     * var modifications = new PolicyChangeModificationsModel(data);
     * </pre>
     */
    angular.module('INTACT.PolicyChange').factory('PolicyChangeModificationsModel', factory);

    function factory ($filter, $PolicyChange){
        function PolicyChangeModifications(data){

            var _data = angular.copy(data || {});
            
            // The policy change data
            var policyChangeData = $PolicyChange.$get().policyChange();
            

            /**
             * @description
             * Return an object with the address if it has been modified
             * the component.
             * @return {Object} Array Array of one item if the address has been updated
             */
            var addressChange = function(){

                var principalHolder = $filter('filter')(policyChangeData.policyChange.policyHolders, 
                        function(item) { return item.type === 'P';}
                )[0];

                if(_data.addressChanged){
                    return [
                        {
                            addressChanged: _data.addressChanged, 
                            address: $filter('displayAddress')(principalHolder.address)
                        }];
                }
                return [];
            };


            /**
             * @description
             * Return the list of added car, with all information required by
             * the component.
             * @return {Object} Array Array of added car (or empty array if not)
             */
            var getUsageModification = function(){
                var mChanges = $filter('filter')(_data.usageChanges, {modificationCode: "M"});
                var uChanges = $filter('filter')(_data.usageChanges, {modificationCode: "U"});
                var changes  = mChanges.concat(uChanges);

                // Update all vehicles with PCH information
                angular.forEach(changes, function(value){
                    value.vehicle = $filter('vehicleByIndex')(policyChangeData, value.index);
                });
                return changes;
            };


            /**
             * @description
             * Return a flag indicating there is vehicle changes
             * @return {boolean} Flag
             */
            var hasVehicleChanges = function(){
                var changes = false;
                if(_data.vehicleChanges){
                    if(angular.isArray(_data.vehicleChanges)){
                        if(_data.vehicleChanges.length>0){
                            changes = true;
                        }
                    }
                }
                return changes;
            };

            /**
             * @description
             * Return a flag indicating there is driver changes
             * @return {boolean} Flag
             */
            var hasDriverChanges = function(){
                var changes = false;
                if(_data.driverChanges){
                    if(angular.isArray(_data.driverChanges)){
                        if(_data.driverChanges.length>0){
                            changes = true;
                        }
                    }
                }
                return changes;
            };

            /**
             * @description
             * Return a flag indicating there is coverages changes
             * @return {boolean} Flag
             */
            var hasCoveragesChanges = function(){
                var changes = false;
                if(_data.coverageChanges){
                    if(angular.isArray(_data.coverageChanges)){
                        if(_data.coverageChanges.length>0){
                            changes = true;
                        }
                    }
                }
                return changes;
            };


            /**
             * @description
             * Return a flag indicating there is usages changes
             * @return {boolean} Flag
             */
            var hasUsagesChanges = function(){
                var changes = false;
                if(_data.usageChanges){
                    if(angular.isArray(_data.usageChanges)){
                        if(_data.usageChanges.length>0){
                            changes = true;
                        }
                    }
                }
                return changes;
            };



            /**
             * @description
             * Functions that extract the coverages changes
             * @return {Object} Array Array of coverages changes (or empty array if not)
             */
            var getCoveragesModifications = function(){
                if (_data) {
                    if(_data.coverageChanges){
                      var coverageChanges = _data.coverageChanges;
                      if(angular.isArray(coverageChanges)){
                        if(coverageChanges.length > 0){
                          
                            var coveragesToReturn = coverageChanges;
                        
                            // Update all vehicles with PCH information
                            angular.forEach(coveragesToReturn, function(value){
                                value.vehicle = $filter('vehicleByIndex')(policyChangeData, value.index);
                                angular.forEach(value.modifications, function(mod){

                                    if(mod.fieldName === 'selectedAmount'){
                                        mod.qualifierLabel = $filter('translate')('LBLXXXXX.coverage.' + mod.qualifier);
                                    }
                                    else if(mod.fieldName === 'selected' && mod.newValue === false){
                                        mod.qualifierLabel = $filter('translate')('LBLXXXXX.coverage.REMOVED');
                                    }
                                    else if(mod.fieldName === 'selected' && mod.newValue === true){
                                        mod.qualifierLabel = $filter('translate')('LBLXXXXX.coverage.ADDED');
                                    }

                                    // Format Data Type
                                    if(typeof mod.newValue === 'number'){
                                        if(mod.type.toUpperCase() === "NUMBER"){
                                            mod.newValueFormatted = '<span class="nowrap weight-500">' + $filter('currency')(mod.newValue, '$', 0) + '</span>';
                                        }
                                    }
                                });
                            });
                            return coveragesToReturn;
                        }
                      }
                    }
                  }
                return [];
            };


            /**
             * @description
             * Functions that extract the cars based on the modification code
             * @return {Object} Array Array of cars (or empty array if not)
             */
            var getVehicleByModificationCode = function(code){
                if (_data) {
                    if(_data.vehicleChanges){
                      var vehChanges = _data.vehicleChanges;
                      if(angular.isArray(vehChanges)){
                        if(vehChanges.length > 0){
                          var vehiclesToReturn = [];

                          vehiclesToReturn = $filter('filter')(vehChanges, {modificationCode: code});
                        
                          // Update all vehicles with PCH information
                          angular.forEach(vehiclesToReturn, function(value){
                            value.vehicle = $filter('vehicleByIndex')(policyChangeData, value.index);
                          });

                          return vehiclesToReturn;
                        }
                      }
                    }
                  }
                return [];
            };


            /**
             * @description
             * Functions that extract the cars based on the modification code
             * @return {Object} Array Array of cars (or empty array if not)
             */
            var getDriversByModificationCode = function(code){
                if (_data) {
                    if(_data.driverChanges){
                      var drChanges = _data.driverChanges;
                      if(angular.isArray(drChanges)){
                        if(drChanges.length > 0){
                          var driversToReturn = [];

                          driversToReturn = $filter('filter')(drChanges, {modificationCode: code});
                        
                          // Update all drivers with PCH information
                          angular.forEach(driversToReturn, function(value){
                            value.driver = $filter('driverByIndex')(policyChangeData, value.index);
                          });

                          return driversToReturn;
                        }
                      }
                    }
                  }
                return [];
            };


            return {
                data : _data,
                addressChange : addressChange,
                getUsageModification : getUsageModification,
                getVehiclesByCode : getVehicleByModificationCode,
                getDriversByCode : getDriversByModificationCode,
                getCoveragesModifications : getCoveragesModifications,
                hasVehicleChanges : hasVehicleChanges,
                hasDriverChanges : hasDriverChanges,
                hasCoveragesChanges : hasCoveragesChanges,
                hasUsagesChanges : hasUsagesChanges
            };
        }
       
        return PolicyChangeModifications;
    }

})(angular);
