(function(angular){
	'use strict';

	/*
	* @ngdoc service
	* @name INTACT.PolicyChange.service:ConvictionsModel
	* @description
	* Data mapping service for convictions DTO Object
	* 
	* @requires
	* 
	* @example
	* <pre>
	* // Data from API REST convictions object
	* var data = {};
	* 
	* // Model
	* var ConvictionsModel = new ConvictionsModel(data.convictions[x]);
	* // ConvictionsModel
	* {
	* }
	* </pre>
	*/

	angular.module('INTACT.PolicyChange').factory('ConvictionsModel', Factory);

	function Factory(){

		function Convictions(data){
			var _data = angular.copy(data || {});

			return {
				sequence	: _data.sequence || 0,
				code 		: _data.code || "",
				type		: _data.type || "",
				year		: _data.year || ""
			};
		}

		return Convictions;
	}
})(angular);