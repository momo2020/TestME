(function(angular){
	'use strict';

	/**
	* @ngdoc service
	* @name INTACT.PolicyChange.service:WarningModel
	* @description
	* Data mapping and functions related to warning messages
	* 
	* @requires
	* 
	* @example
	* <pre>
	* //Data from REST API 
	* var warnings = new WarningModel(data.validation);
	*
	* // warnings = {}
	*
	* </pre>
	*/

	angular.module('INTACT.PolicyChange').factory('WarningModel', Factory);

	function Factory ($filter){

		function WarningModel (data){
			var _warnings = [],
				_hasWarning = false,
				CLIENT_WARNING = 'FPX';

			// check out if validation has warning
			_hasWarning = data && data.warnings && data.warnings.length > 0;

			// map the warning object
			if(_hasWarning){
				angular.forEach(data.warnings, function(aWarning){
					_warnings.push({
						riskSequence : aWarning.riskSequence,
						code : aWarning.code,
						message : aWarning.message,
						elements : getElements(aWarning.elements)
					});
				});
			}

			// check out the code to know if toaster
			function isToaster (warning){
				return warning && warning.code !== CLIENT_WARNING;
			}


			function getToasters (){
				var _toasters = [];

				if(_hasWarning){
					angular.forEach(_warnings, function(aWarning){
						if(aWarning.code !== CLIENT_WARNING){
							_toasters.push(aWarning);
						}
					});
				}

				return _toasters;
			}

			function isClientWarning (){
				var hasClientWarning = false;
				angular.forEach(_warnings, function(aWarning){
					if(aWarning.code === CLIENT_WARNING){
						hasClientWarning = true;
					}
				});
				return hasClientWarning;
			}

			function getClientWarning (){
				return $filter('filter')(_warnings, {code : CLIENT_WARNING})[0];
			}

			function getElements (elements){
				var _elements = [];

				if(elements !== null && angular.isDefined(elements)){
					angular.forEach(elements, function(aElement){
						_elements.push({
							code : aElement.code,
							name : aElement.name,
							modificationCode : aElement.modificationCode,
							type : aElement.type
						});
					});
				}

				return _elements;
			}


			return {
				warnings : _warnings,
				hasWarning : _hasWarning,
				isToaster : isToaster,
				getToasters : getToasters,
				getClientWarning : getClientWarning,
				isClientWarning : isClientWarning
			}
		}

		return WarningModel;

	}  
})(angular);