(function(angular){
	'use strict';
	
	/**
	 * @ngdoc service
	 * @name INTACT.PolicyChange.service:CoverageModel
	 * @description 
	 * Data mapping service for coverage DTO Object
	 *
	 * @requires INTACT.PolicyChange.service:CoverageValueModel
	 * @requires https://docs.angularjs.org/api/ng/service/$log
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 * 
	 * @example
	 * <pre>
	 * // Data from API REST coverage object
	 * var data = {};
	 *
	 * // Model
	 * var coverageModel = new CoverageModel(data);
	 * // Coverage 
	 * {
	 * 	code: '',
	 * 	description: '',
	 * 	selected: {Boolean},
	 * 	selectedAmount: {Number|null}
	 * 	label: '',
	 *  type : '',
	 * 	mode: '',
	 * 	section: '',
	 * 	sequence: {Number},
	 * 	values: [],
	 * 	toSelectData: {Function}
	 * }
	 * </pre>
	 */
	angular.module('INTACT.PolicyChange').factory('CoverageModel', Factory);

	function Factory(CoverageValueModel, $filter, $log){
		var $translate = $filter('translate'),
			$currency = $filter('currency'),
			notCoveredLabel = $translate('policychange.coverage.not.covered');

		function Coverage(data){
			var _data = angular.copy(data || {}),
				values = [],
				selectedAmount = (_data.hasOwnProperty('selectedAmount') && _data.selectedAmount !== null)? _data.selectedAmount : null,
				selected = _data.selected || false,
				section = _data.sectionCode || "0",
				mode = _data.mode || "",
				label = notCoveredLabel,
				productCode = _data.productCode || "",
				$labelFilter = $filter('formatConstructCoverageLabel');

			if(!_data.hasOwnProperty('values')){
				_data.values = [];
			}

			var value;
			/* Populate values */
			if(_data.values){
				for(var i = 0, l = _data.values.length; i < l; i++) {
					value = new CoverageValueModel(_data.values[i]);
					if(selectedAmount === value.amount) {
						value.selected = true;
						selected = true;
					}

					values.push(value);
				}

				if(values.length && selected){
					if(selectedAmount !== null) {
				// CURRENT column, label Number
						if(angular.isNumber(selectedAmount)){
							label = $currency(selectedAmount, '$', 0);
						}
						else {
							$log.warn('CoverageModel exception : SelectedAmount must be a number if is different of null !');
						}
					}
					else{
				// CURRENT column, selected with select 
						label = $labelFilter(mode, section, true, 1);
					}
				} else if(selected) {
					// MANAGE PACKAGE
					// When parent is selected, child must say INCLUDED
					// if( _data.isPackage && !_data.isParent ) {
						// label = $labelFilter("MANDATORY", "1", true, 1);
					// }
				// CURRENT column, selected with yes / no 
					label = $labelFilter(mode, section, true, 1);
				} else if(!selected){
					// MANAGE PACKAGE
					//When parent is selected, child must say INCLUDED
					// if( _data.isPackage && !_data.isParent ) {
						// label = $labelFilter("MANDATORY", "1", true, 1);
					// }
					// else {
					// CURRENT column not selected yes / no
						label = $labelFilter(mode, section, false, 1);	
					// }
				}
			}
			else {
				// CHANGE TO column, not selected 
				values = null;
				label = $labelFilter(mode, section, false, 2);
			}

			return {
				code: _data.code || '',
				description: _data.description || '',
                selected: selected,
                selectedAmount: selectedAmount,
                label: label,
                mode: mode || '',
                productCode : productCode,
                displayPackage : _data.displayPackage,
                isPackage : _data.isPackage,
                section: $filter('formatSectionCodes')(_data.sectionCode) || '',
                sectionCode: section,
                sequence: (_data.hasOwnProperty('sequence'))? _data.sequence : 0,
                values: values,
     			toSelectData: function(){
     				var data = [];
     				if(values){
	     				if(this.values.length && this.selected) {
	     					// Others cases with select
	     					for(var i = 0, l = values.length; i < l; i++) {
		     					var v = values[i],
		     						d = {key: v.amount, value: v.label, selected: v.selected};

		     					data.push(d);
		     				}
	     				} else if(this.selected) {
	     					data.push({
	     						key: this.selectedAmount,
	     						value: this.label,
	     						selected: true
	     					});
	     				}
     				}
     				else{
     					data.push({
     						key : null,
     						value : this.label,
     						selected : false
     					});
     				}

     				return data;
     			}
			};
		}

		return Coverage;
	}
})(angular);