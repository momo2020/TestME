(function(angular){
	'use strict';

	/*
	* @ngdoc service
	* @name INTACT.PolicyChange.service:ClaimsModel
	* @description
	* Data mapping service for driver DTO Object
	*
	* @requires
	*
	* @example
	* <pre>
	* // Data from API REST driver object
	* var data = {};
	*
	* // Model
	* var claimsModel = new ClaimsModel(data.drivers[x]);
	* // claimsModel
	* {
	* }
	* </pre>
	*/

	angular.module('INTACT.PolicyChange').factory('ClaimsModel', Factory);

	function Factory(){

		return function(data){
			var _data = angular.copy(data || {});

			return {
				sequence				: _data.sequence || 0,
				dateCode				: _data.dateCode || "",
				nature 					: _data.nature || "",
				amount					: _data.amount || null,
				accidentAfterJuin1		: typeof _data.accidentAfterJuin1 === 'boolean' ? _data.accidentAfterJuin1: null,
				personHurtInAccident	: _data.personHurtInAccident || null,
				insurerPaidForDamage	: _data.insurerPaidForDamage || null,
				damageAmountExceeded2000: _data.damageAmountExceeded2000 || null,
				lossDate				: _data.lossDate || ""
			};

		};
	}
})(angular);
