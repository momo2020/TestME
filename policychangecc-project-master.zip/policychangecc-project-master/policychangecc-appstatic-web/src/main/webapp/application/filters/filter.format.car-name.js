(function(angular){
	'use strict';
	
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:formatCarName
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 *
	 * @description
	 * Return {String} translated string for car name
	 * 
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function($filter){
	 * 
	 * 	$scope.date = $filter('formatCarName')(make, model, year);
	 * }); 
	 * </pre>
	 *
	 * @param {String} pMake Car make name
	 * @param {String} pModel Car model name
	 * @param {String|Number} pYear Car year
	 * @return {String} translated string
	 */
	angular.module('INTACT.PolicyChange').filter('formatCarName', function($filter){
		
		return function(pMake, pModel, pYear){
			var make = (pMake)? pMake + '' : '',
				model = (pModel)? pModel + '' : '',
				year = pYear;

			return $filter('translate')( 'LBL2067.pc.car.description', {
	    		MAKE: (pModel && pModel.indexOf(pMake) > -1) ? '' : make.toUpperCase(),
	    		MODEL: model.toUpperCase(),
	    		YEAR: year
	    	});
		};
	});
})(angular);
