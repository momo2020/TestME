(function(angular){
	'use strict';
	
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:premium
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 *
	 * @description
	 * Return {String} translated string
	 * 
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function($filter){
	 * 
	 * 	$scope.date = $filter('premium')("226,00");
	 * }); 
	 * </pre>
	 *
	 * @param {String} premium value
	 * @return {String} translated string
	 */
	angular.module('INTACT.PolicyChange').filter('premium', function($filter){
		var $translate = $filter('translate');
		return function(text){
			if(angular.isString(text)){
				return text + '/' + $translate('global.year.label');
			} else {
				return '';
			}
		};
	});
})(angular);
