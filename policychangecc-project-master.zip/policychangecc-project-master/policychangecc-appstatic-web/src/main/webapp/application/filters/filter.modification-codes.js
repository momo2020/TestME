(function(angular){
	'use strict';
	
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:
	 * @requires https://docs.angularjs.org/api/ng/service/$filter.modificationCode
	 *
	 * @description
	 * Return {String} 
	 * 
	 * @example
	 * <pre>
	 * </pre>
	 *
	 * @param {String} newModificationCode
	 * @param {String} oldModificationCode
	 * @return {String} 
	 */
	angular.module('INTACT.PolicyChange').filter('modificationCode', function($filter){
		
		return function(newModificationCode, oldModificationCode){
			var $translate = $filter('translate'),
				codeNew = $translate('MODIFICATION.CODE.NEW'),
				codeModified = $translate('MODIFICATION.CODE.MODIFIED'),
				codeSubstituted = $translate('MODIFICATION.CODE.SUBSTITUTED'),
				codeRemoved = $translate('MODIFICATION.CODE.REMOVED'),
				wasNew = oldModificationCode === codeNew,
				wasSubstituted = oldModificationCode === codeSubstituted,
				isModified = newModificationCode === codeModified,
				isRemoved = newModificationCode === codeRemoved;

			if(isRemoved && wasNew){
				return codeRemoved;
			}

			//Hyerarchie :
			// an object that has been created within the pch will stay new
			// The lowest modification is Modified
			if(wasNew && !isRemoved){
				return codeNew;
			}
			else if(isRemoved && !wasNew){
				//user can only remove a car that is new on pch
				return oldModificationCode;
			}
			else if(wasSubstituted && isModified){
				return codeSubstituted;
			}
			else{
				return newModificationCode;
			}
		};
	});
})(angular);
