(function(angular){
	'use strict';

	angular.module('INTACT.PolicyChange').filter('absoluteValue', function(){

		return function(number){
			return Math.abs(number);
		};
	});
})(angular);
