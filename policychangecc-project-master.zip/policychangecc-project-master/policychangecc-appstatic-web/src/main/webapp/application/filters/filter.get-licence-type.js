/*jshint esnext: true */

(function(angular){
	'use strict';
	
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:formatCarName
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 *
	 * @description
	 * Return {String} translated string for car name
	 * 
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function($filter){
	 * 
	 * 	$scope.date = $filter('formatCarName')(make, model, year);
	 * }); 
	 * </pre>
	 *
	 * @param {String} pMake Car make name
	 * @param {String} pModel Car model name
	 * @param {String|Number} pYear Car year
	 * @return {String} translated string
	 */
	angular.module('INTACT.PolicyChange').filter('getLicenceType', function($log, $filter){
		//TODO = driverLicenceType is not used...
		return function(driverLicenceType, allLicenceTypes, isNewDriver, originalDriverLicenceType){
			var g1Licence = 'L',
				g2Licence = 'P',
				gLicence  = 'R',
				toRemove  = [];
			
			if( g1Licence === originalDriverLicenceType && !isNewDriver ){
				toRemove.push(gLicence);
			}
			else if( g2Licence === originalDriverLicenceType && !isNewDriver ){
				toRemove.push(g1Licence);
			}
			else if( gLicence === originalDriverLicenceType && !isNewDriver ){
				toRemove.push(g1Licence);
				toRemove.push(g2Licence);
			}

			$filter('orderBy')(allLicenceTypes, 'key');

			angular.forEach( allLicenceTypes, function(licenceType, index){
				if( toRemove.indexOf(licenceType.key) > -1 ){
					delete allLicenceTypes[index];
				}
			} );

			var newList = [];

			for(var i = 0, ll = allLicenceTypes.length ; i < ll ; i++){
				if(allLicenceTypes[i] !== undefined){
					newList.push(allLicenceTypes[i]);
				}
			}

			return newList;
		};
	});
})(angular);
