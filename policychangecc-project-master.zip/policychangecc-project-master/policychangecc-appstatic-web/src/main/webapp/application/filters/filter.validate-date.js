(function(angular){
	'use strict';
	
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:validateDate
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 *
	 * @description
	 * Return {Boolean} returns if date format is valid
	 * 
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function($filter){
	 * 
	 * 	$scope.validDate = $filter('validDate')('2000-10-33');
	 *	// $scope.validDate == false;
	 * }); 
	 * </pre>
	 *
	 * @param {String} Date to validate 'YYYY-MM-DD'
	 * @return {Boolean} isvalidDate
	 */
	angular.module('INTACT.PolicyChange').filter('validateDate', function($PolicyChange){
		
		return function(dateToValidate){

				var valid = true,
					date = dateToValidate.split('-'),
					year = parseInt(date[0]),
					month = parseInt(date[1]),
					day = parseInt(date[2]),
					isLeapYear = false,
					yearTreshold = $PolicyChange.$get().policyChange().data.state.driverAgeThreshold,
					minYear = new Date().getFullYear() - yearTreshold;

				if( year >= minYear ){
					if( year % 4 === 0 && 
						((year % 100 > 0) || (year % 400 === 0))){
						isLeapYear = true;
					}

					if( (month < 1) || (month > 12) ){
						valid = false;
					}
					else if( (day < 1) || (day > 31) ){
						valid = false;
					}
					else if( ((month === 4) || (month === 6) || (month ===9) || (month ===11)) && (day > 30) ){
						valid = false;
					}
					else if(isLeapYear && (day <= 29)){
						valid = true;
					}
					else if((month === 2) && (day > 28)){
						valid = false;
					}
				}
				else{
					valid = false;
				}
				
				return valid;
			};
	});
})(angular);
			