(function(angular){
	'use strict';
	
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:getDriverCombo
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 *
	 * @description
	 * Return [{key, value}] returns an array of key values objects to fill select
	 * 
	 * @example
	 * <pre>
	 * </pre>
	 *
	 * @param 
	 * @return 
	 */
	angular.module('INTACT.PolicyChange').filter('getDriverCombo', function($filter){
		
		return function(listIn, typeOfList){
			var listOut = [],
			    $capitalize = $filter('pcCapitalize'),
			    $orderBy = $filter('orderBy'),
			    fn = typeOfList === 'drivers' ? 'sequence' : 'partyId';
			var ll = listIn ? listIn.length : 0;
			for(var i = 0 ; i < ll ; i++){
			    listOut.push({
			        key : listIn[i][fn],
			        value : $capitalize(listIn[i].firstName) + " " + $capitalize(listIn[i].lastName)
			    });
			}
			return $orderBy(listOut, 'value');
		};
	});
})(angular);