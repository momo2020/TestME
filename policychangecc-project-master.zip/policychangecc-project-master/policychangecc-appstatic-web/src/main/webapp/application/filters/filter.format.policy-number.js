(function(angular){
	'use strict';
	
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:policyNumberFormat
	 *
	 * @description
	 * Return {String} policy Number with #
	 * 
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function($filter){
	 * 	$scope.date = $filter('policyNumberFormat')("3466");
	 * 	console.log($scope.date); // #3466
	 * }); 
	 * </pre>
	 *
	 * @param {String} policy Number
	 * @return {String} policy Number with #
	 */
	angular.module('INTACT.PolicyChange').filter('policyNumberFormat', function(){

		return function(number){
			if(angular.isString(number)){
				return '' + number;
			} else {
				return '';
			}
		};
	});
})(angular);
