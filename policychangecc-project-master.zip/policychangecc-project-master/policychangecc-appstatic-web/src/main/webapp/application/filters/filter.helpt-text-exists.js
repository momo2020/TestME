(function(angular){
	'use strict';
	/**
	 * @ngdoc filter
	 * @name INTACT.PoilicyChange.filter:helptextExists
	 *
	 * @description
	 * Return {Boolean} helptext html is on list
	 *
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function(Policies, $filter, $scope){
	 * 	showHelptext = $filter('helptextExists')("B");
	 * });
	 * </pre>
	 *
	 * @return {Boolean} helptext html is on list
	 */

	 angular.module('INTACT.PolicyChange').filter('helptextExists', function($PCAppConfiguration) {
	    return function(coverageCode) {
	    	var existingHT = {
	    		on : [
		    		'44',
		    		'A1',
		    		'A2',
		    		'AUTOCOMFORT',
		    		'B',
		    		'C1',
		    		'C2',
		    		'C3',
		    		'C4',
		    		'CPC',
		    		'CPF'/*,
		    		'DWA'*/
	    		],
	    		qc : [
	    			'A',
	    			'B2',
	    			'B3',
	    			'B4',
	    			'P1',
	    			'I90',
	    			'NBD',
	    			'43V',
	    			'43I',
	    			'33E'
	    		]},
	    	province = $PCAppConfiguration.province.toLowerCase();

	    	return existingHT[province].indexOf(coverageCode.toUpperCase()) > -1;
	    };
	});

})(angular);
