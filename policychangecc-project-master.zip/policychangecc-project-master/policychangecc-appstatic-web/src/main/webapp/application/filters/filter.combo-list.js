(function(angular){
	'use strict';
	
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:comboList
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 * @requires INTACT.PolicyChange.$PCAppConfigurationProvider
	 * @requires INTACT.PolicyChange.LOCALES
	 *
	 * @description
	 * Return [{key, value}] returns an array of key values objects to fill select
	 * 
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function($filter){
	 * 
	 * 	$scope.combo = $('comboList')('annualKm')
	 *	// $scope.combo = [
	 *	{key : '2000',
	 *	 value : '0 to 2999 km per year'},
	 *	{key : '6000',
	 *	 value : '3000 to 6999 km per year'}
	 * 	]
	 * }); 
	 * </pre>
	 *
	 * @param {String} key to locale list
	 * @return {array} [{key, value}] object to fill select
	 */
	angular.module('INTACT.PolicyChange').filter('comboList', function($filter, $PCAppConfiguration, LOCALES, $log){
		
		return function(objName, _typeOfKey){
			var listeIn = LOCALES[$PCAppConfiguration.preferredLanguage][objName],
				listeOut = [],
				typeOfKey = _typeOfKey !== undefined ? _typeOfKey : false;
			if(listeIn !== undefined && Object.keys(listeIn).length > 0){	
				for(var key in listeIn){
					if(typeOfKey !== false){
						switch (typeOfKey){
							case 'Integer' : 
								key = parseInt(key);
								break;
							case 'String' : 
								key = key.toString();
								break;
						}
					}
					listeOut.push({
						key : key,
						value : listeIn[key]
					});
				}
			}
			else{
				$log.warn('INTACT.PolicyChange.filter:comboList error: list ' + objName + ' does not exist');
			}

			return listeOut;
		};
	});
})(angular);

