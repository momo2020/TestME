(function(angular){
	'use strict';
	
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:province
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 *
	 * @description
	 * Return {String} returns the province string from the short version
	 * 
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function($filter){
	 * 
	 * 	$scope.province = $filter('province')('ON');
	 *	// $scope.province == "Ontario";
	 * }); 
	 * </pre>
	 *
	 * @param {String} Short province code
	 * @return {String} translated string to long province name
	 */
	angular.module('INTACT.PolicyChange').filter('province', function($filter){
		
		return function(provinceCode){
			var stringToTranslate = 'province_' + provinceCode.toLowerCase();

			return $filter('translate')( stringToTranslate);
		};
	});
})(angular);
