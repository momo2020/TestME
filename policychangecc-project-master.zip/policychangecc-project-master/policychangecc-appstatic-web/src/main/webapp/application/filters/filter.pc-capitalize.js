/*jshint esnext: true */

(function(angular){
	'use strict';
	
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:formatCarName
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 *
	 * @description
	 * Return {String} translated string for car name
	 * 
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function($filter){
	 * 
	 * 	$scope.date = $filter('formatCarName')(make, model, year);
	 * }); 
	 * </pre>
	 *
	 * @param {String} pMake Car make name
	 * @param {String} pModel Car model name
	 * @param {String|Number} pYear Car year
	 * @return {String} translated string
	 */
	angular.module('INTACT.PolicyChange').filter('pcCapitalize', function($log){

		function splitKeep (text, splitter){
			var regularex = new RegExp(splitter, 'g');
			if(typeof text !== "string"){
				return $log.warn('PolicyChange.filter.pcCapitalize : Format error - input must be string');
			}

			return text.split(regularex).reduce(function(chunks, item, index){
							if(item.match(regularex) && typeof item === 'string' && item !== undefined){
								if(chunks[index -1] !== undefined){
									chunks[index -1] += item;
								}
								else{
									chunks.push(item);
								}
							}
							else{
								if(item !== undefined){
									chunks.push(item);
								}
							}
							return chunks;
						}, [] );
		}
		
		return function(element){
			var original = angular.copy(element),
				matchExp = /([A-Za-z])\w+/g,
				specialChars = "(['-])", 
				names = splitKeep(original, specialChars ),
				newName = '';
			if(names !== undefined ){
				for(var i = 0, ll = names.length ; i < ll ; i++){
					var splitted = names[i].split(' '),
						temp = '';

					for(var j = 0, li = splitted.length ; j < li ; j++){
						if(splitted[j].match(matchExp)){
							temp += splitted[j].charAt(0).toUpperCase() + splitted[j].substr(1).toLowerCase();
						}
						else{
							temp += splitted[j];
						}
						//Do not put extra space on a name with ' or - 
						var nextMatches = names[i+1] !== null && names[i+1] && names[i+1] !== undefined ? names[i+1].match(specialChars) : false;
						if(!temp.match(specialChars) && !nextMatches){
							temp += ' ';
						}
					}
					newName += temp;
				}		
			}

			return newName.trim();
		};
	});
})(angular);
