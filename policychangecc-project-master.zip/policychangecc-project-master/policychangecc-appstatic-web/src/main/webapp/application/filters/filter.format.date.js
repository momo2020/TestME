(function(angular){
	'use strict';

	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:dateFormat
	 *
	 * @description
	 * Return {String} date in the right format for the backend
	 *
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function(Policies, $filter){
	 * 	// Param when must be an object with other property
	 *	var dateFormat = $filter('dateFormat')('2016-01-31');
	 *	var dateFormat = $filter('dateFormat')('31/01/2016');
	 * // var dateFormat value is now "2016-01-31"
	 * });
	 * </pre>
	 *
	 * @param {String} date in UI format
	 * @return {String} date in format "yyyy-MM-dd" in EN and  dd-mm-yyyy in FR. system date is always yyyy-MM-dd
	 */
	angular.module('INTACT.PolicyChange').filter('dateFormat', function($log, $PCAppConfiguration){
		return function(dateOld){
			var lang = $PCAppConfiguration.preferredLanguage,
				yyyy = null,
				mm = null,
				dd = null,
				separator= '-',
				_newDate = null;
			// TODO: split these or adapt datePicker as system uses a unique dateFormat yyyy-mm-dd
			var _oldDate;
			if (dateOld.indexOf('/') > -1) { // date picker has a none iso format "29/10/2016" and should not return FR date
					_oldDate = dateOld.replace(/\//g, '');
					dd 	 = _oldDate.substring(0,2);
					mm 	 = _oldDate.substring(2,4);
					yyyy = _oldDate.substring(4,10);

					if (isMatch()) {
						_newDate = yyyy + separator + mm + separator + dd;
					} else {
						$log.warn('INTACT.PolicyChange.filter:dateFormat - The input date has the wrong format: yyyy-mm-dd');
					}

			} else if (dateOld.indexOf('-') === 4) { // start with four digits and a dash in fifth position
				  _oldDate = dateOld.replace(/\-/g, '');
					yyyy = _oldDate.substring(0,4);
					mm 	 = _oldDate.substring(4,6);
					dd 	 = _oldDate.substring(6,9);

					if (isMatch()) {
						_newDate = (lang === 'en') ? yyyy + separator + mm + separator + dd : dd + separator + mm + separator + yyyy;
					} else {
						$log.warn('INTACT.PolicyChange.filter:dateFormat - The input date has the wrong format: yyyy-mm-dd');
					}

			} else {
				$log.warn('INTACT.PolicyChange.filter:dateFormat - The input date has the wrong format: yyyy-mm-dd');
			}

			function isMatch() {
				if( yyyy && !yyyy.match('^[0-9]{4}$') ||
					mm && !mm.match('^[0-9]{2}$') ||
					dd && !dd.match('^[0-9]{2}$')) {
					_newDate = "ERROR";
					return false;
				} else {
					return true;
				}
			}

			return _newDate;
		};
	});
})(angular);
