(function(angular){
	'use strict';
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:displayAddress
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 * @requires INTACT.Core.service:$CoreConfigurationProvider
	 *
	 * @description
	 * Return {Array} address array of string
	 * 
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function($filter){
	 * 	$scope.address = $filter('displayAddress')({input});
	 * }); 
	 * </pre>
	 *
	 * @param {Object} addrObj adress object
	 *
	 * <pre>
	 * // Input format
	 * 	{
	 * 		floor: '',
	 *		civicNumber: 896,
	 *		streetName: '',
	 *		streetType: '',
	 *		apartment: '',
	 *		postalCode: '',
	 *		poBox: '',
	 *		city: '',
	 *		municipality: '',
	 *		province: '',
	 *		station: '',
	 *		ruralRouteNumber: '',
	 *		unitNumber: '',
	 *		poBox: ''
	 * 	}
	 * </pre>
	 * @return {Array} address array of string
	 */

	 angular.module('INTACT.PolicyChange').filter('displayAddress', function($CoreConfiguration, $filter) {

	    var lang = $CoreConfiguration.preferredLanguage.toLowerCase(),
			ucFirst = $filter('ucFirst'),
			$translate = $filter('translate');

		/**
		 * Check if a string value is equal to null entry
		 * @param  {String}  value Value to check
		 * @return {Boolean}       True if the value equal to null
		 */
		function isNotNull(value){
			return (value && (value !== '' && value !== 'null' && value !== 'null null'));
		}

		/**
		 * Check if an address object is structured or not
		 * @param {Object} addrObj 	Object address interface (from client or policy service)
		 * @return {Boolean} 		True if the address is structured
		 */
		function isStructuredAddress(addrObj){
			return (isNotNull(addrObj.cp) &&  !isNotNull(addrObj.addressFormatType)) ;
		}


		/**
		 * Check if an address object is Hybrid
		 * @param {Object} addrObj 	Object address interface (from client or policy service)
		 * @return {Boolean} 		True if the address is structured
		 */
		function isHybridAdress(addrObj){
			return (isNotNull(addrObj.addressFormatType)) ;
		}

		/**
		 * Format a postal code
		 * @param  {String} cp Original not formatted postal code
		 * @return {String}    Formatted postal code
		 */
		function formatPostalCode(cp){
			var r = cp.replace(/([A-Z])([0-9])([A-Z])([0-9])([A-Z])([0-9])/, '$1$2$3 $4$5$6');
			return r;
		}

		/**
		 * Extract all field object of structured address
		 * @return {Object} Structured object address
		 */
		function struturedAddressObject(addrObj){
			if(addrObj){
				var obj = {
					civicNumber: isNotNull(addrObj.civicNumber)? addrObj.civicNumber : null,
					street: addrObj.streetName || '',
					streetType: addrObj.streetType || null,
					streetDirection: addrObj.streetDirection || null,
					apartment: addrObj.apartment || null,
					floor: addrObj.floor || null,
					boxNumber: isNotNull(addrObj.poBox)? addrObj.poBox : null,
					station: addrObj.poStation || null,
					ruralRouteNumber: addrObj.ruralRouteNumber || null,
					city: addrObj.municipality || '',
					province: addrObj.province || '',
					cp: isNotNull(addrObj.postalCode)? formatPostalCode(addrObj.postalCode) : null,

					//addressFormatType
					addressFormatType: isNotNull(addrObj.addressFormatType)? addrObj.addressFormatType : null,
				};

				// City format
				if(angular.isString(obj.city)){
					obj.city = ucFirst(obj.city);
				}

				//

				return obj;
			} else {
				return '';
			}
		}

		return function(addrObj){
			var addr = struturedAddressObject(addrObj),
				lines = [],
				line = '';

			if(isNotNull(addrObj)){
				if(isStructuredAddress(addr)) {


					// Logic for structured address first line
					if(isNotNull(addr.street) || addr.boxNumber) { // City address or PO box address
						if (addr.civicNumber || !addr.boxNumber) {
							line = [];
							if(lang === "en"){
								// en: Street name + street type
								if(isNotNull(addr.street)){
									line.push(addr.street);
								}
								if(isNotNull(addr.streetType)){
									line.push(addr.streetType);
								}
							} else {
								// fr: Street type + street name
								if(isNotNull(addr.streetType)){
									line.push(addr.streetType);
								}
								if(isNotNull(addr.street)){
									line.push(addr.street);
								}
							}
							//Steet direction
							if(addr.streetDirection) {
								line.push(addr.streetDirection);
							}
							// Civic number at first place
							if(addr.civicNumber) {
								line.unshift(addr.civicNumber + ',');
							}
							// Unit Number at last place
							if(addr.apartment && !addr.boxNumber) {
								line.push('#' + addr.apartment);
							}
	
							line = line.join(' ');
	
							// Floor
							if(addr.floor && !addr.boxNumber) {
								line += ', ' + $translate('global.floor') + ' ' + addr.floor;
							}
	
							lines.push($filter('pcCapitalize')(line));
						}
						if(addr.station || addr.boxNumber) { //PO address continued
							line = [];
							if(addr.boxNumber){
								line = $translate('po.box.label');
								line += ' ' + addr.boxNumber;
							}
							
							if(addr.station) {
								if(line.length){
									line += ', ';
								}
	
								line += $translate('po.succ.label') + ' ';
								line += addr.station;
							}
	
							if(line){
								lines.push(line);
							}
						}
					} else if(addr.ruralRouteNumber) { // Rural address
						lines.push('RR ' + addr.ruralRouteNumber);
					} else { // General delivery
						lines.push($translate('global.general.delivery').toUpperCase());
					}

					// Second line
					line = [];
					if(addr.city.length) {
						var p = addr.city;
						if(addr.cp || addr.province.length) {
							p += ',';
						}

						if(p){
							line.push(p);
						}					
					}

					if(addr.province) {
						line.push($filter('province')(addr.province));
					}
					
					lines.push($filter('pcCapitalize')(line.join(' ')));


					// Third line
					line = [];
					if(addr.cp) {
						line.push(addr.cp);
					}
					
					lines.push(line.join(' '));



				} else if(isHybridAdress(addr)) {
                    for(var i = 1, l = 4; i < l; i++){
						line = addrObj['unstructuredAddressLine' + i];
							if(line && line.length){
								lines.push(line);
							}
					}

					line = [];

					if(addrObj.municipality.length) {
						var pp = addrObj.municipality;
						if(addrObj.postalCode || addrObj.province.length) {
							pp += ',';
						}

						if(pp){
							line.push(pp);
						}					
					}

					if(addrObj.province) {
						line.push(addrObj.province);
					}

					if(addrObj.postalCode) {
						line.push(formatPostalCode(addrObj.postalCode));
					}
					
					lines.push(line.join(' '));
					
				} else {
					// Unstructured address
					for(var ii = 1, ll = 4; ii < ll; ii++){
						line = addrObj['unstructuredAddressLine' + ii];
						if(line && line.length){
							lines.push(line);
						}
					}
				}
				
				return lines;
			} else {
				return ['', '', ''];
			}
		};

	});

})(angular);
