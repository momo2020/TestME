(function(angular){
	'use strict';
	
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:comboList
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 * @requires INTACT.PolicyChange.$PCAppConfigurationProvider
	 * @requires INTACT.PolicyChange.LOCALES
	 *
	 * @description
	 * Return [{key, value}] returns an array of key values objects to fill select
	 * 
	 * @example
	 * <pre>
	 * </pre>
	 *
	 * @param {String} key of type of claim
	 * @return {Number} Default amount
	 */
	angular.module('INTACT.PolicyChange').filter('defaultAmountClaimQc', function(){
		
		return function(typeOfClaim){
			var amount = 0;

			switch(typeOfClaim){
				case 'GW'  :
				case 'FIR' :
				case 'TH'  :
				case 'VAN' :
				case 'WN'  :
					amount = 250;
					break;
				case 'GR'  :
				case 'AA'  : 
				case 'AAF' : 
				case 'NA'  : 
				case 'HR'  :
					amount = 1;
					break;
				default    : 
					break;
			}

			return amount;
		};
	});
})(angular);

