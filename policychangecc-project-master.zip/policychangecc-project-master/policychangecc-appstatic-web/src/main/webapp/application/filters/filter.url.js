(function(angular){
	'use strict';
	
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:url
	 * 
	 * @description
	 * Return {String} urlKey url string 
	 * 
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function(Policies, $filter, $scope){
	 * 	// Param when must be an object with other property
	 * 	$scope.url = $filter('url')('summary');
	 * }); 
	 * </pre>
	 *
	 * @param {String} urlKey 	Key access for requested url
	 * @return {String} urlKey url string 
	 */
	angular.module('INTACT.PolicyChange').filter('url', function($PCUrls, $log){
		return function(urlKey){
		
			if(angular.isString(urlKey)){
				var url = $PCUrls.getUrl(urlKey);
				if(url) {
					return url;
				} else {
					$log.error('INTACT.PolicyChange.filter:url Error - Url not found for key : ' + urlKey + ' !');
					return 'ERROR';
				}
			} else {
				$log.error('INTACT.PolicyChange.filter:url Error - Url not found for key : ' + urlKey + ' !');
				return 'ERROR';
				
			}
			
		};
	});
})(angular);