(function(angular){
	'use strict';
	
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:vehicleBySequence
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 *
	 * @description
	 * Return {Object} current and updated vehicle by sequenceNumber
	 * 
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function($filter){
	 * 
	 * 	$scope.date = $filter('vehicleBySequence')(policyChange, sequenceNumber);
	 * }); 
	 * </pre>
	 *
	 * @param {Object} PolicyChange Data
	 * @param {Integer} sequenceNumber The sequence Number
	 * @return {Object} Object containing the current and policy change vehicle
	 */
	angular.module('INTACT.PolicyChange').filter('vehicleBySequence', function($filter){
		
		return function(policyChange, _sequenceNumber){
			
			var _current = {},
				_updated = {};

			// Get the current vehicle by sequenceNumber
			if(policyChange){
				if(policyChange.currentPolicy){
					if(policyChange.currentPolicy.vehicles){
						_current = $filter('filter')(policyChange.currentPolicy.vehicles, {sequenceNumber : _sequenceNumber})[0] || null;
					}
				}

				// Get the policy change vehicle by sequenceNumber
				if(policyChange.policyChange){
					if(policyChange.policyChange.vehicles){
						_updated = $filter('filter')(policyChange.policyChange.vehicles, {sequenceNumber : _sequenceNumber})[0] || null;
					}
				}			
			}

			return {
				current: _current,
				updated: _updated
			};
		};
	});
})(angular);
