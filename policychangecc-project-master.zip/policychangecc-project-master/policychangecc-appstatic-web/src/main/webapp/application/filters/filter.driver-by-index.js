(function(angular){
	'use strict';
	
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:driverByIndex
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 *
	 * @description
	 * Return {Object} current and updated driver by index in the array
	 * 
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function($filter){
	 * 
	 * 	$scope.date = $filter('driverByIndex')(policyChange, index);
	 * }); 
	 * </pre>
	 *
	 * @param {Object} PolicyChange Data
	 * @param {Integer} index The index Number
	 * @return {Object} Object containing the current and policy change vehicle
	 */
	angular.module('INTACT.PolicyChange').filter('driverByIndex', function($filter){
		
		return function(policyChange, index){
			
			var _current = {},
				_updated = {};

			// Get the current vehicle by sequenceNumber
			if(policyChange){
				if(policyChange.currentPolicy){
					if(policyChange.currentPolicy.drivers){
						_current = $filter('filter')(policyChange.currentPolicy.drivers, {driverIndex : index})[0] || null;
					}
				}

				// Get the policy change vehicle by sequenceNumber
				if(policyChange.policyChange){
					if(policyChange.policyChange.drivers){
						_updated = $filter('filter')(policyChange.policyChange.drivers, {driverIndex : index})[0] || null;
					}
				}			
			}

			return {
				current: _current,
				updated: _updated
			};
		};
	});
})(angular);
