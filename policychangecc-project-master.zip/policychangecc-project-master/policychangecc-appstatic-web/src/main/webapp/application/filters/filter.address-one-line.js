(function(angular){
	'use strict';
	
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:addressOneLine
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 * @requires INTACT.PolicyChange.$PCAppConfigurationProvider
	 *
	 * @description
	 * Return {String} returns the one line structured address
	 * 
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function($filter){
	 * </pre>
	 *
	 * @param {Object} address from policy holder
	 * @return {String} Structured address one line
	 */
	angular.module('INTACT.PolicyChange').filter('addressOneLine', function($filter, $PCAppConfiguration){
		
		return function (address){
	 		    var $translate = $filter('translate'),
	 		    	addressOneLine = "",
	 		        streetType = address.streetType !== null ? address.streetType : '';
	 		    if(streetType !== ''){
	 		        streetType = $PCAppConfiguration.preferredLanguage.toUpperCase() === 'FR' ? streetType + ' ' : ' ' + streetType;
	 		    }

	 		    addressOneLine += $translate('LBLXXXXX.car.pch.address.line1',
	 		                        {civicNumber : address.civicNumber,
	 		                         streetName : address.streetName,
	 		                         streetType : streetType});
	 		    if(address.streetDirection !== null){
	 		        addressOneLine += $translate('LBLXXXXX.car.pch.address.line2', {streetDirection : address.streetDirection});
	 		    }
	 		    if(address.apartment !== null){
	 		        addressOneLine += $translate('LBLXXXXX.car.pch.address.line3', {unitNumber : address.apartment});
	 		    }
	 		    if(address.floor !== null){
	 		        addressOneLine += $translate('LBLXXXXX.car.pch.address.line4', {floor : address.floor});
	 		    }
	 		    addressOneLine = $filter('pcCapitalize')(addressOneLine);
	 		    addressOneLine += $translate('LBLXXXXX.car.pch.address.line5', {
	 		        municipality : $filter('pcCapitalize')(address.municipality),
	 		        postalCode : address.postalCode
	 		    });
	 		    return addressOneLine;
	 		};
	});
})(angular);

