(function(angular){
	'use strict';

	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:ageByDob
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 *
	 * @description
	 * Return {String} returns the age calculated with date of birth
	 *
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function($filter){
	 *
	 * 	$scope.getAge = $filter('ageByDob')('2000-10-33');
	 * </pre>
	 *
	 * @param {String} Date of birth 'YYYY-MM-DD'
	 */
	angular.module('INTACT.PolicyChange').filter('ageByDob', function(){

		return function(dob){
			var today = new Date();
		    var birthDate = new Date(dob);
			
		    var age = today.getFullYear() - birthDate.getFullYear();
		    var month = today.getMonth() - birthDate.getMonth();

		    if (month < 0 || (month === 0 && today.getDate() < birthDate.getDate())) {
		        age--;
		    }

		    return age;
		};
	});
})(angular);
