(function(angular){
	'use strict';

	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:formatSectionCodes
	 *
	 * @description
	 * Return {String} sectionName
	 *
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 * @requires https://docs.angularjs.org/api/ng/service/$log
	 *
	 * @example
	 * <pre>
	 * // In controller or Model
	 * angular.module('MyModule').controller('MyController', function($filter, $scope){
	 * // Param must be the section code as a String
	 * var section = $filter('formatSectionCodes')('2');
	 * // section value is translated Additional Coverage / Protections additionnelles
	 * });
	 * </pre>
	 *
	 * @param {String} sectionCode code as a String number
	 * @return {String} sectionName
	 */
	angular.module('INTACT.PolicyChange').filter('formatSectionCodes', function($log, $filter){
		var $translate = $filter('translate'),
		sections = {
			'1' : $translate('SECTION_MAIN'),
			'2' : $translate('SECTION_ADDITIONAL'),
			'5' : $translate('SECTION_SPECIAL'),
			'6' : $translate('SECTION_REBATES'),
			'7' : $translate('SECTION_HIDDEN')
		};

		return function(sectionCode){
			var sectionName = "";
			if(angular.isString(sectionCode)){
				sectionName = sections[sectionCode];
				if(sectionName === undefined ){
					$log.error('INTACT.PolicyChange.filter:formatSectionCodes - Section Code does not exist');
					return 'ERROR';
				}
				return sectionName;
			}
			else{
				$log.error('INTACT.PolicyChange.filter:formatSectionCodes - Invalid format for section code');
				return 'ERROR';
			}
		};
	});
})(angular);