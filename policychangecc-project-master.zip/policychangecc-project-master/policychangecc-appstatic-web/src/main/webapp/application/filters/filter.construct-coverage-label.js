(function(angular){
	'use strict';

	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:formatConstructCoverageLabel
	 *
	 * @description
	 * Return {String} label
	 *
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 * @requires https://docs.angularjs.org/api/ng/service/$log
	 *
	 * @example
	 * <pre>
	 * // In controller or Model
	 * angular.module('MyModule').controller('MyController', function($filter, $scope){
	 * // Param must be the section code as a String
	 * var label = $filter('formatConstructCoverageLabel')('OPTIONAL', '1', true, 1);
	 * // label value will be 'Included'
	 * });
	 * </pre>
	 *
	 * @param {String} mode 		'OPTIONAL', MANDATORY'
	 * @param {String} section 		current page number
	 * @param {Boolean} isIncluded 	true to include label value
	 * @param {number} column 		isCurrent == 1, isChange == 2 
	 * @return {String} label
	 */
	angular.module('INTACT.PolicyChange').filter('formatConstructCoverageLabel', function($log, $filter){
		var $translate = $filter('translate'),
			//notIncludedLabel 	= $translate('policychange.notincluded'),
			includedLabel 		= $translate('policychange.included'),
			yesLabel			= $translate('policychange.coverage.yes'),
			noLabel 			= $translate('policychange.coverage.no'),
			notCoveredLabel		= $translate('policychange.coverage.not.covered'),
			blankLabel			= $translate('policychange.coverage.blank');

		return function(mode, section, isIncluded, column){
			var label = blankLabel,
				isMandatory = (mode.toUpperCase() === $translate('INCLUSION.MANDATORY').toUpperCase()),
				isMain = (section === "1"),
				isAdditionnal = (section === "2"),
				isCurrent = (column === 1);
				//isChange = (column ===2);

			if(isMandatory){
				if(isCurrent){
					if(isMain && isIncluded){
						label = includedLabel;
					}
					else if (isAdditionnal && isIncluded){
						label = yesLabel;
					}
					else if (!isIncluded){
						label = notCoveredLabel;
					}
				} else {
					if(isAdditionnal && !isIncluded){
						label = blankLabel;
					}
					else if(isMandatory && isIncluded){
						label = blankLabel;
					}
					else{
						label = isMain ? includedLabel : yesLabel;
					}
				}
			}
			// suggested and optional modes have the same output
			else{
				if(!isIncluded){
					label = isMain ? notCoveredLabel : noLabel;
				}
				else{
					label = isMain ? includedLabel : yesLabel;
				}
			}

			return label;
		};
	});
})(angular);