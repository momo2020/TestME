(function(angular){
	'use strict';

	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:getStepPosition
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 *
	 * @description
	 * Return {String} returns the position of the given step
	 *
	 * @param {String} Step (PC_DRIVERS)
	 */
	angular.module('INTACT.PolicyChange').filter('getStep', function(){

		return function(stepNumber, stepName){
			var theStepName = "";

			switch (stepNumber) {
				case "PC_START":
					theStepName = stepName === false ? "0" : "taskboard";
					break;
				case "PC_ADDRESS":
					theStepName = stepName === false ? "1" : "address";
					break;
				case "PC_CARS":
					theStepName = stepName === false ? "2" : "cars";
					break;
				case "PC_DRIVERS":
					theStepName = stepName === false ? "3" : "drivers";
					break;
				case "PC_VEH_USAGE":
					theStepName = stepName === false ? "4" : "usage";
					break;
				case "PC_COV":
					theStepName = stepName === false ? "6" : "coverages";
					break;
				case "PC_PRM":
					theStepName = stepName === false ? "7" : "premium";
					break;
				case "PC_REVW":
					theStepName = stepName === false ? "8" : "review";
					break;
				case "PC_CONFIRM":
					theStepName = stepName === false ? "9" : "confirmation";
					break;
				
				default:
					theStepName = "";
			}

			return theStepName;
		};
	});
})(angular);
