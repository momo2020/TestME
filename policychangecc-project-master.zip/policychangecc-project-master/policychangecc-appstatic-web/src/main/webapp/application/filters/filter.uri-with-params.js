(function(angular){
	'use strict';
	
	/**
	 * @ngdoc filter
	 * @name INTACT.PolicyChange.filter:uriWithParams
	 * 
	 * @description
	 * Return {String} uri with parameters 
	 * 
	 * @example
	 * <pre>
	 * // In controller
	 * angular.module('MyModule').controller('MyController', function(Policies, $filter, $scope){
	 * 	// Param when must be an object with other property
	 * 	$scope.url = $filter('uriWithParams')(url, {param : param});
	 * }); 
	 * </pre>
	 *
	 * @param {String}  url with placeholders
	 * @param {Object}  url parameters to replace
	 * @return {String} urlKey url string 
	 */
	angular.module('INTACT.PolicyChange').filter('uriWithParams', function(){
		return function (pUri, pParams){
			var url = pUri;
			
			for(var p in pParams){
				// replacing '/' for make urls 
				var escaped = encodeURI(pParams[p]),
					pEscaped = escaped.replace(/\//g , '%2F');
				pParams[p] = pEscaped;
				
				url = url.replace(':' + p, pParams[p]);
			}
			return url;
		};
	});
})(angular);