(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:HardRoadBlockController
	 * @description
	 * Controller to manage the validation hard road block
     * @requires close
	 */
	angular.module('INTACT.PolicyChange').controller('HardRoadBlockController', Controller);

    	function Controller($stateParams, 
    						$PCAnalyticsService, 
    						$DebugButtonService,
    						$PCStateManagerService, 
    						$PCAppConfiguration, 
    						$window){
            var vm = this;
            vm.debugEnabled = $DebugButtonService.isDebugEnabled();
            vm.linkToClientCenter = $PCAppConfiguration.clientCentreUrl;
            vm.phoneNumber = $PCAppConfiguration.rdblckPhoneNumber;

            vm.errors = $stateParams.errors;

            vm.gotoCC = function (){
            	$window.location = vm.linkToClientCenter;
            };

            if(vm.debugEnabled){
	            angular.forEach(vm.errors, function(error){
	            	var code  = $DebugButtonService.isDebugEnabled ? error.code + " - " : '';
	            	error.message = code + error.message;
	            });
            }

           $PCStateManagerService.hideLoader();

			analytics();

			function analytics() {

            	var reasons = "";
            	angular.forEach(vm.errors, function(error){
	            	reasons = reasons !== "" ? reasons + '/' + error.code : error.code;
            	});
				
				fireTracking();

				function fireTracking() {
					// ******* Analytics - [F6.11] Error Screen page  (hard roadblock)
					var props = {
					 	s_pageState : "314-2-3",
						s_appStep: "pu:roadblock",
						s_reason: reasons,
						s_pageName: 'portfolio:policy update:hard roadblock'
					};

					$PCAnalyticsService.trackPageView(props);
				}
			}
        }
})(angular);
