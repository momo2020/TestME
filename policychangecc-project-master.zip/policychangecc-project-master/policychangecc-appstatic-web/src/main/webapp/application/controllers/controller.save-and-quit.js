(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:SaveAndQuitController
	 * @description
	 * Controller for the save and quit button

	 */
	angular.module('INTACT.PolicyChange').controller('SaveAndQuitController', Controller);

	function Controller($log, 
						close, 
						$element, 
						$PolicyChangeService, 
						$PCAnalyticsService, 
						PolicyChangeData, 
						$PCStateManagerService){
		var vm = this;

		init();

		/**
		 * @ngdoc method
		 * @name INTACT.PolicyChange.controller:SaveAndQuitController#close
		 * @methodOf INTACT.PolicyChange.controller:SaveAndQuitController
		 *
		 * @description
		 * Close current modal opened ({@link https://github.com/dwmkerr/angular-modal-service cf. Module})
		 */
		vm.close = function(){
			// Animation close pop-up (TODO wrap it in service)
			$element.addClass('animate-modal modal-hide');
			close(false, 200);
		};

		/**
		 * @ngdoc method
		 * @name INTACT.PolicyChange.controller:SaveAndQuitController#save
		 * @methodOf INTACT.PolicyChange.controller:SaveAndQuitController
		 *
		 * @description
		 * Gets initializationDTO object, puts update and
		 * close modal ({@link https://github.com/dwmkerr/angular-modal-service cf. Module})
		 */

		vm.saveAndQuit = function() {
			$PCStateManagerService.showLoader();
			vm.waiting = true;
			$PolicyChangeService.put(PolicyChangeData.policyChange, {goto : "CLIENT_CENTRE", ignoreErrors: true}).then(function () {
				vm.waiting = false;
				close(true, 200);
				$PCStateManagerService.hideLoader();
		    })
		    .catch(function() {
		    	vm.waiting = false;
		        close(false, 200);
		        $PCStateManagerService.hideLoader();
		    });
		};

		function init() {
			$PCAnalyticsService.trackPageView({
				s_pageName: 'pc:save-quit'
			});
			$PCStateManagerService.hideLoader();
		}
	}

})(angular);
