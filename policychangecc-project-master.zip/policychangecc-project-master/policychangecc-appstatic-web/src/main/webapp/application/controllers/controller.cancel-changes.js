(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:CancelChangesController
	 * @description
	 * Controller for the cancel changes button

	 */
	angular.module('INTACT.PolicyChange').controller('CancelChangesController', Controller);

	function Controller(close, $element, $PolicyChange, $PCAnalyticsService, $PolicyChangeService, $filter, $scope, $PCStateManagerService){
		var vm = this;
		vm.waiting = false;
		init();

		function init() {
			var PolicyChangeData = $PolicyChange.$get().policyChange();
			var currentPage = $filter('getStep')(PolicyChangeData.state.currentPage);

			// ******* Analytics - Pending policy change (modal popup)
			vm.fireAnalytics = function(param) {
				var props = {
					s_appStep : "pu:" + currentPage,
	    			s_pageState : "",
					s_pageName: "portfolio:policy update:pending policy change warning"
				};

				angular.extend(props, param);

				$PCAnalyticsService.trackPageView(props);
			};

			vm.fireAnalytics();
			$PCStateManagerService.hideLoader();
		}

		/**
		 * @ngdoc method
		 * @name INTACT.PolicyChange.controller:CancelChangesController#close
		 * @methodOf INTACT.PolicyChange.controller:CancelChangesController
		 *
		 * @description
		 * Close current modal opened ({@link https://github.com/dwmkerr/angular-modal-service cf. Module})
		 */
		vm.close = function(){
			// Animation close pop-up (TODO wrap it in service)
			$element.addClass('animate-modal modal-hide');
			close(false, 200);
		};

		/**
		 * @ngdoc method
		 * @name INTACT.PolicyChange.controller:CancelChangesController#cancelChanges
		 * @methodOf INTACT.PolicyChange.controller:CancelChangesController
		 *
		 * @description
		 * Gets initializationDTO object, puts update and
		 * close modal ({@link https://github.com/dwmkerr/angular-modal-service cf. Module})
		 */
		vm.cancelChanges = function() {
			$PCStateManagerService.showLoader();
			
			var action = $scope.cancelForm ? parseInt($scope.cancelForm.actionSelector.$viewValue, 10) : true;
			var btnEvent = action === 0 ? "continue making changes" : "cancel and start over";

			if (action) {
				vm.waiting = true;

				var PolicyChangeData = $PolicyChange.$get().policyChange().policyChange;
				$PolicyChangeService.cancel(PolicyChangeData.policyChange).then(function () {
					vm.waiting = false;
					close(true, 200);
			    }, function(e){
			    	vm.waiting = false;
			        close(false, 200);
			        $PCStateManagerService.hideLoader();
				});

			} else {
				vm.close();
				$PCStateManagerService.hideLoader();
			}

			// ******* Analytics - Fire analytics on button click
			var props_btn = {
				s_btnName: "pu:pending lightbox:" + btnEvent
			};
			vm.fireAnalytics(props_btn);
		};

	}
})(angular);
