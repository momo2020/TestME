(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:PolicyChangeReviewController
	 * @description
	 * PolicyChange Review Controller<br>
	 * ControllerAs : ReviewCtrl
	 *
	 */
	angular.module('INTACT.PolicyChange').controller('PolicyChangeReviewController', controller);

	 function controller($PolicyChange,
		 				$PCAnalyticsService,
	 					$PCStateManagerService,
						$scope){

	 	var vm = this,
			isFirstTime = true;
	 	vm.policyChangeData = $PolicyChange.$get().policyChange();

	 	init();

		function loadNavigationListener(){
			$scope.$on('eventRefreshDataForNavigation', function (){
				if(isFirstTime){
					$PCStateManagerService.setPolicyChangeData(getPolicyChange());
				}
				isFirstTime = false;
			});
		}

		function getPolicyChange (){
			return vm.policyChangeData;
		}

		function init(){
			loadNavigationListener();

			// ******* Analytics - [F6.9] Review & Accept page
			var props_init = {
				s_appStep : "pu:8",
				s_pageName: 'portfolio:policy update:review'
			};

			$PCAnalyticsService.trackPageView(props_init);
		}
	 }
})(angular);
