(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:ModalSoftRoadBlockController
	 * @description
	 * Controller to manage the validation soft road block modal popup
     * @requires close
	 */
	angular.module('INTACT.PolicyChange').controller('ModalSoftRoadBlockController', Controller);

	function Controller(messages, 
						brNumbers, 
						close, 
						$scope, 
						$filter, 
						$PCAnalyticsService,
						$PCAppConfiguration, 
						$PCStateManagerService){
		var translate = $filter('translate');
        var vm = this;

        vm.showBlueBox = false;

        vm.title = translate('LBL43494.softRdBlck.title');
        vm.messages = messages; //Array of all possible messages
        vm.btnSuccess = translate('LBL43506.softRdBlck.continue');

        vm.phoneNumber = $PCAppConfiguration.rdblckPhoneNumber;

		$PCStateManagerService.hideLoader();
		 
        // Handle the closing of the modal box
        vm.close = function(){
            $scope.$broadcast('$ModalServiceClose');
            $('body [lightbox-close]').addClass('animate-modal modal-hide').removeClass('show');
            $('body').removeClass('modal-opended');
            close(false, 200);
        };

		analytics();

		function analytics() {
			// ******* Analytics - [F6.11] Error Screen page (soft roadblock)
			var props = {
				s_pageState : "314-2-3",
				s_reason: brNumbers,
				s_pageName: 'portfolio:policy update:soft roadblock'
			};

			$PCAnalyticsService.trackPageView(props);
		}
	}

})(angular);
