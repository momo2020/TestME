(function(angular) {
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:PolicyChangeCarController
	 * @description
	 * PolicyChange Car Controller<br>
	 * ControllerAs : PolicyChange
	 *
	 */
	angular.module('INTACT.PolicyChange').controller('PolicyChangeCarController', controller);

	// TODO: We have to constantly remove the dead code.
	// TODO: Better model management (PolicyChangeData, PolicyHolderModel, DriverModel, VehicleModel, VehicleMakeModel ???).
	function controller($timeout,
						PolicyChangeData,
						PolicyHolderModel,
						$PCAnalyticsService,
						DriverModel,
						$PolicyChange,
						DropDownOptionsModel,
						$PolicyChangeService,
						$PCStateManagerService,
						$CoreWindowService,
						InitializationModel,
						VehicleModel,
						VehicleMakeModel,
						$filter,
						carService,
						$scope,
						$rootScope) {

		var vm = this,
			delay = 1000,
			$orderBy=$filter('orderBy'),
			$translate=$filter('translate'),
			$capitalize = $filter('pcCapitalize'),
			$modificationCode = $filter('modificationCode'),
			codeSubstituted = $translate('MODIFICATION.CODE.SUBSTITUTED'),
			codeModified = $translate('MODIFICATION.CODE.MODIFIED'),
			codeNew = $translate('MODIFICATION.CODE.NEW'),
			openedForm = null,
			message;

		vm.ddOptions = [];
		vm.policyChangeData = angular.copy(PolicyChangeData);
		vm.editCarIndex = null;
		vm.getPolicyChange = getPolicyChange;
		vm.showUsage = showUsage;
		vm.addressChanged = PolicyChangeData.state.addressModified;

		vm.refreshModels = function() {
			PolicyChangeData = $PolicyChange.$get().policyChange();
			init();
		};

		function getPolicyChange (){

			if(vm.editCarIndex != null ){
				var currentCar = {};
				if(vm.newCars.length){
					// New car is edited
					currentCar = vm.newCars[0];
					setDefaultCarValuesForAdd(currentCar);
				}
				else{
					// Existing car is edited

					currentCar = vm.cars[vm.editCarIndex];
					setDefaultCarValuesForUpdate(currentCar);
				}
				var _veh = angular.copy(vm.policyChangeData.policyChange.vehicles),
					tempVehicles = [];

				angular.forEach(_veh, function(vehicle){
					tempVehicles.push(new VehicleModel(vehicle));
				});

				tempVehicles[vm.editCarIndex] = currentCar;

				vm.policyChangeData.policyChange.vehicles = tempVehicles;
				vm.policyChangeData.policyChange.vehicles[vm.editCarIndex] = angular.copy(currentCar);
			}
			else{
				// when no car is expanded on edit mode (Done button was clicked), we still need to save the model to PolicyChangeData
				vm.policyChangeData.policyChange.vehicles = vm.cars;
			}
			return vm.policyChangeData;
		}

		function setEditCarIndex(index){
			if(index === null || vm.formVisibility[index]){
				vm.editCarIndex = null;
			}
			else{
				vm.editCarIndex = index;
			}
		}

		function showUsage(car){
			return car.vehicle.usageModified || car.vehicle.modificationCode === 'N' || car.vehicle.modificationCode === 'U';
		}

		function setDefaultCarValuesForUpdate(currentCar){
			if(currentCar.vehicle.usageModified){
				currentCar.vehicle.modificationCode = $modificationCode(codeSubstituted, currentCar.vehicle.modificationCode);
				message = $translate('LBL43057.car.successful.replace');
			}
			else{
				currentCar.vehicle.modificationCode = $modificationCode(codeModified, currentCar.vehicle.modificationCode);
				message = $translate('LBLXXXX.car.successful.update');
			}
		}

		function setDefaultCarValuesForAdd(newCar){
			newCar.vehicle.sequenceNumber = null;
			newCar.vehicle.usageModified = true;
			newCar.vehicle.modificationCode = $modificationCode(codeNew, newCar.modificationCode);
		}

		function init() {
			loadNavigationListener();
			var vehicles = [],
				drivers = [],
				policyHolders = [],
				vehiculeData = PolicyChangeData.policyChange ? PolicyChangeData.policyChange.vehicles : PolicyChangeData.currentPolicy.vehicles,
				driversListData	= PolicyChangeData.policyChange ? PolicyChangeData.policyChange.drivers : PolicyChangeData.currentPolicy.drivers,
				phListData = PolicyChangeData.policyChange ? PolicyChangeData.policyChange.policyHolders : PolicyChangeData.currentPolicy.policyHolders;

			// TODO: Is it necessary to have 3 variables for driver list (driverListData/drivers/driverList)
			angular.forEach(driversListData, function(driver){
				drivers.push(new DriverModel(driver).driver);
			});

			// TODO: Is it necessary to have 4 variables for vehicle list (vehicleData/vehicles/currentCars/cars)
			angular.forEach(vehiculeData, function(vehicule) {
				vehicles.push(new VehicleModel(vehicule));
				var option = _.where(vm.ddOptions, {riskIndex: vehicule.riskIndex});
				if(!angular.isDefined(option) || option.length === 0){
					vm.ddOptions.push(new DropDownOptionsModel({riskIndex : vehicule.riskIndex}));
				}
			});

			// TODO: Is it necessary to have 3 variables for driver list (phListData/policyHolders/policyHoldersList)
			angular.forEach(phListData, function(ph){
				policyHolders.push(new PolicyHolderModel(ph));
			});

			vehicles = $orderBy(vehicles, 'vehicle.riskIndex');
			vm.ddOptions = $orderBy(vm.ddOptions, 'riskIndex');

			vm.driversList = drivers;
			vm.currentCars = vehicles;
			openedForm = false;

			vm.policyHoldersList = policyHolders;

			vm.cars = angular.copy(vehicles);

			vm.formVisibility = {};
			vm.newCarVisibility = {};
			vm.vehiculesCount = 0;

			//Public property for the blue box
			vm.isReplaceCar = false;

			vm.cars.forEach(function(item) {
				setFormVisibilty();
				vm.vehiculesCount++;

                vm.ddOptions[item.vehicle.riskIndex].vehiclesYearMax = PolicyChangeData.state.vehiclesYearMax;
                vm.ddOptions[item.vehicle.riskIndex].vehiclesYearMin = PolicyChangeData.state.vehiclesYearMin;
			});

			// TODO: The user can add only one car. Must check if we could use a newCar object instead an array
			vm.newCars = [];
			setRdblkMessages();

			/* Analytics - [F6.3] Cars */
			var props = {
				s_appStep: "pu:2",
				s_pageName: 'portfolio:policy update:cars'
			};

			$PCAnalyticsService.trackPageView(props);
		}

		function setRdblkMessages (){
			vm.rdblkTitle = vm.cars.length > 1 ? $translate('LBLXXXXX.car.remove.rdblk.title') : $translate('LBL43495.car.remove.one.car');
			vm.rdblkText = vm.cars.length > 1 ? $translate('LBLXXXXX.car.remove.rdblk.desc') : '';
		}

		vm.canAddVehicle = function() {
			return vm.policyChangeData.state.canAddVehicle;
		};

		vm.getPrincipalDriver = function(index) {
			// When adding new car
			if (!vm.currentCars[index]){
				return "";
			}

			var drSeq = vm.currentCars[index].vehicle.principalDriver,
				driver = $filter('filter')(vm.driversList, {sequence : drSeq})[0];

			return driver ? $capitalize(driver.firstName)+" "+$capitalize(driver.lastName) : '';
		};

		vm.getDdOptions = function(riskIndex){
			return $filter('filter')(vm.ddOptions, {riskIndex : riskIndex})[0];
		};

		vm.translateCarName = $filter('formatCarName');

		function getVehicles(vehiclesList){
			var vehiclesListOut = [];

			angular.forEach( $orderBy(vehiclesList, 'riskIndex'), function(vehicle){
				vehiclesListOut.push(new VehicleModel(vehicle));
			} );

			return vehiclesListOut;
		}

		function setFormVisibilty() {
			vm.cars.forEach(function(item, index) {
				vm.formVisibility[index] = 0;
			});

			vm.newCarVisibility[0] = 0;
		}


		vm.resetReplaceButton = function(index) {
			$rootScope.$broadcast('refillAntitheftCombo', {index : index, reset : false});
			var selectList = ['year', 'make', 'model'];
			if (openedForm && vm.formVisibility[index]) {
				vm.reset(index);
			} else {
				if (!openedForm && !vm.formVisibility[index]) {
					mapCarSelects(vm.cars[index].vehicle, selectList);
					toggleAndSwapCancel(index);

					/* Analytics - [F6.14] Replace Car started */
					var props_modify_started = {
						s_appStep: "pu:2." + (index + 1),
						s_pageState : "132-1-0",
						s_pageName: 'portfolio:policy update:cars:update started'
					};

					$PCAnalyticsService.trackPageView(props_modify_started);
				}
			}

		};

		function mapCarSelects(car, selects) {

			car.model.year = String(car.model.year);
			var cnfg = {};
			var year = car.model.year;
			var make = car.model.make;
			var bottomTreshold = vm.ddOptions[car.riskIndex].vehiclesYearMin;
			var topTreshold = vm.ddOptions[car.riskIndex].vehiclesYearMax;

			if(vm.cars[car.riskIndex].isVehicleYearInList(year, bottomTreshold, topTreshold)){
				selects.forEach(function(selectName) {

					cnfg = {
					  	selectName: selectName,
	                    car: car,
	                    year: year,
	                    make: make,
	                    force: false,
	                    ddOptions: vm.ddOptions[car.riskIndex]
					};

					carService.getSelectValues(cnfg);
				});
			}
			else{
				cnfg = {
					selectName : 'year',
					car : car,
					year : year,
					make : '',
					force : false,
					ddOptions : vm.ddOptions[car.riskIndex]
				};

				carService.getSelectValues(cnfg);
				vm.ddOptions[car.riskIndex].makeOptions[0] = [{
					name : make
				}];
				vm.ddOptions[car.riskIndex].modelOptions = [{
					name : car.model.model,
					value : car.model.code.length === 4 ? car.model.code + "00" : car.model.code
				}];
				vm.ddOptions[car.riskIndex].yearOptions.push({
					value : year
				});
			}
		}

		function toggleAndSwapCancel(index) {
			$scope.$broadcast('ccButtonSwapLabelChanged', index);
			toggleForm(index);
		}

		function toggleForm(index) {
			setEditCarIndex(index);

			if(!openedForm || vm.formVisibility[index]){
				vm.formVisibility[index] = !vm.formVisibility[index];
				openedForm = !openedForm;
			}
		}

		function toggleFormNewCar(index) {
			setEditCarIndex(index);

			if(!openedForm || vm.newCarVisibility[0]){
				vm.newCarVisibility[0] = !vm.newCarVisibility[0];
				openedForm = !openedForm;
			}
		}

		function hideUsage (index){
			vm.cars[index].vehicle.usageModified = false;
		}

		vm.reset = function(index, _delay) {
			var duration = _delay || delay,
				selectList = ['year', 'make', 'model'];

			toggleAndSwapCancel(index);

			hideUsage(index);

			$timeout( function() {
				angular.copy(vm.currentCars[index].vehicle, vm.cars[index].vehicle);
				PolicyChangeData.policyChange.vehicles[index] = vm.cars[index].vehicle;

				$rootScope.$broadcast('fieldReset');
				vm['carForm' + index].$setPristine();
				vm['carForm' + index].$setUntouched();
			}, duration);

			// TODO: We have to make sure that we do not call the back end once values have been retrived
			if (vm.formVisibility[index]) {
				mapCarSelects(vm.cars[index].vehicle, selectList);
 			}
		};


		function cleanVehiclesForSave (vehList){
			var cleanVehicles = [];

			angular.forEach(vehList, function(vehicle){
				
				if( vehicle.vehicle.modificationCode == codeNew ){
					vehicle.vehicle.usageModified = true;
				}

				cleanVehicles.push(vehicle.vehicle);
			});

			return cleanVehicles;
		}

		function updateWorkKmModified (policyChange){

			angular.forEach( policyChange.vehicles , function(vehicle) {
				if(vehicle.modificationCode == codeNew) {
					vehicle.workKmModified = true;
				}
				else {
					if( PolicyChangeData.policyChange.vehicles[ vehicle.riskIndex ] ) {
						if( PolicyChangeData.policyChange.vehicles[vehicle.riskIndex].workOrSchoolKm != vehicle.workOrSchoolKm ) {
							vehicle.workKmModified = true;
						}
					}
				}
			} );
		}

		function updateAnnualKmModified (policyChange) {

			angular.forEach( policyChange.vehicles , function(vehicle) {
				if(vehicle.modificationCode == codeNew) {
					vehicle.annualKmModified = true;
				}
				else {
					if( PolicyChangeData.policyChange.vehicles[ vehicle.riskIndex ] ) {
						if( PolicyChangeData.policyChange.vehicles[vehicle.riskIndex].annualKm != vehicle.annualKm ) {
							vehicle.annualKmModified = true;
						}
					}
				}
			} );			
		}

		vm.updateCar = function(indexCar) {

			PolicyChangeData = getPolicyChange();

			vm.isReplaceCar = false;

			var payLoad = PolicyChangeData.policyChange;

			payLoad.vehicles = cleanVehiclesForSave(payLoad.vehicles);

			updateWorkKmModified(payLoad);
			updateAnnualKmModified(payLoad);

			$PolicyChangeService.put(payLoad, {}).then(

				//Success
				function(data) {
					//The PUT promise has been resolved
					if (data) {
						toggleAndSwapCancel(vm.editCarIndex);
						var vehUpdate = getVehicles(data.policyChange.vehicles);
						setRdblkMessages();

						angular.copy(vehUpdate, vm.currentCars);
						angular.copy(data.state, vm.policyChangeData.state);
						
						$CoreWindowService.scrollTop(100);
						$scope.$emit('defaultEventId', {message: message});
						// Breadcrumb must be refreshed in certain scenario right after a save. (New tabs could be added dynamically: Drivers, Coverage)
						refreshState(data);

						/* Analytics - [F6.15] Replace Car completed */
						var props_modify_completed = {
							s_appStep: "pu:2." + (indexCar + 1),
						  	s_pageState : "132-2-1",
							s_pageName: 'portfolio:policy update:cars:update completed'
						};

						$PCAnalyticsService.trackPageView(props_modify_completed);
					}
				});

		};


		vm.saveNewCar = function(newCar){
			setDefaultCarValuesForAdd(newCar);
			var payLoad = angular.copy(PolicyChangeData.policyChange);
           	payLoad.vehicles.push(newCar.vehicle);

			$PolicyChangeService.put(payLoad, {}).then(
				function(data) {
					if (data) {
						// update original policyChangeData
						angular.copy(data, PolicyChangeData);

						var vehiculeUpdate = getVehicles(data.policyChange.vehicles);

						// update current cars for reset
						angular.copy(vehiculeUpdate, vm.currentCars);

						var carIndex = newCar.vehicle.riskIndex;

						// update cars
						angular.copy(vehiculeUpdate, vm.cars);

						angular.copy(data.state, vm.policyChangeData.state);
						angular.copy(data.policyChange.vehicles, vm.policyChangeData.vehicles);
						angular.copy(data.policyChange.vehicles, PolicyChangeData.policyChange.vehicles);

						setRdblkMessages();
						vm.removeNewCar();
						message = $translate('LBL42283.car.successful.new');

						$CoreWindowService.scrollTop(100);
						$scope.$emit('defaultEventId', {message: message});
						// Breadcrumb must be refreshed in certain scenario right after a save. (New tabs could be added dynamically: Drivers, Coverage)
						refreshState();

						/* Analytics - [F6.13] Add Car completed */
						var props_add_completed = {
							s_appStep: "pu:2." + (carIndex + 1),
						  	s_pageState : "131-2-1",
							s_pageName: 'portfolio:policy update:cars:add completed'
						};

						$PCAnalyticsService.trackPageView(props_add_completed);
					}
				});
		};

		vm.removeNewCar = function() {
			toggleFormNewCar(null);

			$rootScope.$broadcast('fieldReset');

			// $timeout( function() {
				PolicyChangeData.policyChange.vehicles.splice(vm.newCars[0].vehicle.riskIndex, 1);
				vm.newCars = [];

			// }, delay);
		};

		vm.removeCar = function(riskIndex){
			var optionIndex = _.findIndex(vm.ddOptions, { riskIndex: riskIndex });
			vm.ddOptions.splice(optionIndex, 1);
			vm.refreshModels();
			$scope.$emit('defaultEventId', {message: $translate('LBL45889.car.successful.remove')});
		};
		
		vm.createNewCarForm = function(){
			var index = 0;

			if (!vm.newCars.length) {
				var emptyCar = new VehicleModel({
					riskIndex : vm.cars.length,
					usageModified : true,
					modificationCode : codeNew,
					registerOwner : $filter('filter')(vm.policyHoldersList, {type : "P"})[0].partyId
				});

				var newDdOption = new DropDownOptionsModel({
					riskIndex : emptyCar.vehicle.riskIndex,
					vehiclesYearMax : PolicyChangeData.state.vehiclesYearMax,
					vehiclesYearMin : PolicyChangeData.state.vehiclesYearMin
				});

				vm.newCars.push(emptyCar);

                var cnfg = {
                    selectName: 'year',
                    car: vm.newCars[index],
                    year: '',
                    make: '',
                    force: true,
                    ddOptions : newDdOption
                };

				carService.getSelectValues(cnfg);
				vm.ddOptions.push(newDdOption);

				vm.isReplaceCar = false;
				toggleFormNewCar(emptyCar.vehicle.riskIndex);

				/* Analytics - [F6.12] Add Car started */
				var props_add_started = {
					s_appStep: "pu:2." + (emptyCar.vehicle.riskIndex + 1),
				  	s_pageState : "131-1-0",
					s_pageName: 'portfolio:policy update:cars:add started'
				};

				$PCAnalyticsService.trackPageView(props_add_started);

			} else {
				vm.removeNewCar();
			}

		};

		function setUsageModifiedOnAllCars(vehicles){
			// as the back-end can't persist the usageModified, we have 
			// to make sure on multiple vehicles that we keep the flag right.
			if(vm.addressChanged){
				angular.forEach(vehicles, function(vehicle){
					if(vehicle.annualKm !== null){
						vehicle.usageModified = true;
					}
				});
			}
		}

		function loadNavigationListener(){
			$scope.$on('eventRefreshDataForNavigation', function (){

				vm.policyChangeData.policyChange.vehicles = cleanVehiclesForSave(getPolicyChange().policyChange.vehicles);
				setUsageModifiedOnAllCars(vm.policyChangeData.policyChange.vehicles);
				$PCStateManagerService.setPolicyChangeData(vm.policyChangeData);
			});
		}

		// Breadcrumb must be refreshed in certain scenario right after a save. (New tabs could be added dynamically: Drivers, Coverage)
		function refreshState(){
			vm.policyChangeData.policyChange.vehicles = cleanVehiclesForSave(getPolicyChange().policyChange.vehicles);
			$PCStateManagerService.setPolicyChangeData(vm.policyChangeData);

			$scope.$emit('eventReloadNavigation');
			$scope.$emit('eventReloadBreadcrumb');
		}

		init();
	}
})(angular);
