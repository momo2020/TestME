(function(angular) {
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:PolicyChangeSelectController
	 * @description
	 * PolicyChange Select Controller (taskboard)r<br>
	 * ControllerAs : PolicyChangeSelect
	 *
	 * @requires INTACT.PolicyChange.service:PolicyChangeData
	 *
	 */
	angular.module('INTACT.PolicyChange').controller('PolicyChangeSelectController', controller);

	function controller($state,
						$PCAppConfiguration,
						PolicyChangeData,
						ADMdtp,
						$PCAnalyticsService,
						$filter,
						$scope,
						$InitializationService,
						$DebugButtonService,
						$PcCalendar,
						$PCStateManagerService,
						mapperDataService,
						$IntactModalService)
	{
		var vm = this,
			$orderBy = $filter('orderBy'),
			$translate = $filter('translate'),
			PolicyChangeInitState = PolicyChangeData.PolicyChangeInitState,
			pcData = PolicyChangeData.PolicyChangeData,
			initialization = PolicyChangeInitState.initialization;

		//Public variables to get the policy
		vm.currentPolicy = pcData.currentPolicy;
		vm.vehicles = pcData.state.transactionInitialized ? pcData.policyChange.vehicles : pcData.currentPolicy.vehicles;
		vm.drivers 	= pcData.state.transactionInitialized ? $orderBy(pcData.policyChange.drivers, 'sequence') : $orderBy(pcData.currentPolicy.drivers, 'sequence');
		vm.currentAddress = (mapperDataService.getCurrentPrincipalHolder(PolicyChangeData)) ? (mapperDataService.getCurrentPrincipalHolder(PolicyChangeData)).address : null;
		vm.translateCarName = $filter('formatCarName');

		vm.currentAddress.unstructuredAddressLine1 = $filter('pcCapitalize')(vm.currentAddress.unstructuredAddressLine1);
		vm.currentAddress.municipality = $filter('pcCapitalize')(vm.currentAddress.municipality);
		vm.currentAddress.postalCode = vm.currentAddress.postalCode.substring(0,3) + ' ' + vm.currentAddress.postalCode.substring(3);

		//Public variable to get the state
		vm.stateDto = PolicyChangeInitState.state;

		//To feed the datepicker
		var dateFormat = $PcCalendar.getDateFormat();
		vm.mask = dateFormat.mask;
		vm.date = vm.stateDto.effectiveDateMin;
		vm.inputDate = vm.stateDto.effectiveDateMin;
		vm.minDate = $filter('date')(vm.stateDto.effectiveDateMin, dateFormat.format);
		vm.maxDate = $filter('date')(vm.stateDto.effectiveDateMax, dateFormat.format);
		vm.options = {
			default : vm.minDate
		};

		//Validation Public variables
		vm.dateValidationMessage = "";
		vm.emptyTask = false;
		vm.debugEnabled = $DebugButtonService.isDebugEnabled();
		vm.invalidDate = false;
		vm.exit = exit;

		//States public vairables
		vm.tasks = {
			policychangeaddress: {
				taskName: 'PC_CHANGE_ADDRESS',
				selected: false
			},
			policychangecar: {
				taskName: 'PC_UPDATE_CARS',
				selected: false
			},
			policychangedriver: {
				taskName: 'PC_UPDATE_DRIVERS',
				selected: false
			},
			policychangeusage: {
				taskName: 'PC_CHANGE_USAGE',
				selected: false
			},
			policychangecoverage: {
				taskName: 'PC_CHANGE_COVERAGES',
				selected: false
			},
			discounts: {
				taskName: 'PC_REVIEW_DISCOUNT',
				selected: false
			}
		};

		function init() {
			loadNavigationListener();
			selectTasks();

			// ******* Analytics - [F6.1] Home page
			var props = {
				s_appStep : "pu:0",
				s_pageState : "314-1-0",
				s_pageName: 'portfolio:policy update:welcome'
			};

			$PCAnalyticsService.trackPageView(props);
		}

		function exit(){
			$PCStateManagerService.redirectToCC();
		}

		function selectTasks() {
			if(pcData && pcData.state) {
				pcData.state.tasks.forEach( function(taskItem) {

					var itemToSelect = null;
					angular.forEach(vm.tasks, function(item) {
						if (item.taskName === taskItem) {
							itemToSelect = item;
						}
					});

					itemToSelect.selected = true;
				});
			}
		}


	    /**
	     * @ngdoc method
	     * @name PolicyChangeSelectController#renewalIsOut
	     * @methodOf INTACT.PolicyChange.controller:PolicyChangeSelectController
	     * @description
	     * Returns true if the currentEffectiveDate is future from today
	     */
		function renewalIsOut () {
			var currentEffectiveDate = pcData.currentPolicy.effectiveDate,
				isOut = false;

			if( dateIsGreater({greater : currentEffectiveDate}) ){
				isOut = true;
			}

			return isOut;
		}

	    /**
	     * @ngdoc method
	     * @name PolicyChangeSelectController#renewalIsOut
	     * @methodOf INTACT.PolicyChange.controller:PolicyChangeSelectController
	     * @description
	     * Returns true if the currentEffectiveDate is future from client's selected date
	     */
		function selectedDateIsPrevious () {
			var selectedDate = vm.date,
				currentEffectiveDate = pcData.currentPolicy.effectiveDate,
				isPrevious = dateIsGreater({
					smaller : selectedDate,
					greater : currentEffectiveDate
				});

			return isPrevious;
		}

		function dateIsGreater ( props ){

			var smaller = props.smaller,
				greater = props.greater,
				sDay,
				sMonth,
				sYear,
				gDay,
				gMonth,
				gYear,
				isGreater = false,
				today = new Date();

			if( smaller !== undefined && smaller !== null ){
				sDay = parseInt(smaller.substring(8,10));
				sMonth = parseInt(smaller.substring(5,7));
				sYear = parseInt(smaller.substring(0,4));
			}
			else{
				sDay = parseInt(today.getUTCDate());
				sMonth = parseInt(today.getUTCMonth()) + 1;
				sYear = parseInt(today.getFullYear());
			}

			if( greater !== undefined && greater !== null ){
				gDay = parseInt(greater.substring(8,10));
				gMonth = parseInt(greater.substring(5,7));
				gYear = parseInt(greater.substring(0,4));
			}
			else{				
				gDay = parseInt(today.getUTCDate());
				gMonth = parseInt(today.getUTCMonth()) + 1;
				gYear = parseInt(today.getFullYear());
			}			


			if( gYear > sYear ){
				isGreater = true;
			}
			else if( gYear === sYear ){
				if( gMonth > sMonth ){
					isGreater = true;
				}
				else if ( gMonth === sMonth ){
					if( gDay > sDay ){
						isGreater = true;
					}
				}
			}

			return isGreater;
		}

		vm.isTaskListItemSelected = function() {
			var result = false;
			angular.forEach(vm.tasks, function(item) {
				if (item.selected){
					result = true;
				}
			});

			vm.emptyTask = !result;
		};

		vm.close = function(date) {
			if ($PcCalendar.validateDate(date)) {
				vm.inputDate = date;
				if (dateFormat.isFrenchFormat(date)) { 
					vm.date  = dateFormat.reverse(date);
				}
				else {
					vm.date = date;
				}
			}
		};

		vm.continueToTask = function() {
			var taskSelected = false,
				tasksList = [],
				isPageValid = function() {
					return ($PcCalendar.validateDate(vm.date) && taskSelected) ? true : false;
				};

			for (var task in vm.tasks) {
				if (vm.tasks[task].selected) {
					tasksList.push(vm.tasks[task].taskName);
					taskSelected = true;
				}
			}

			initialization.selectedTasks = tasksList;

			if (!taskSelected) {
				vm.emptyTask = true;
			}

			if (isPageValid()) {
				if(renewalIsOut() && selectedDateIsPrevious()){
					var message = '<p>' + $translate('LBL45509.pc.renew.message.one') + '</p><p>' + $translate('LBL45509.pc.renew.message.two') + '</p><p>' + $translate('LBL45509.pc.renew.message.three') + '</p>';
					var modalOptions = {
					    templateUrl: '/directives/modal-generic-dialog.html',
					    controllerAs: '$ctrl',
					    controller: 'ModalDefaultController',
					    resolve: {
					    	modalContext:{
						        title : $translate('LBL45508.pc.renew.title'),
						        text : message,
						        btnSuccess : $translate('LBL45510.pc.renew.ok')
					    	}
					    }
					};

					$IntactModalService.modal(modalOptions).on('$ModalServiceClose', function(){
						initializePolicyChange();
					});
				}
				else{
					initializePolicyChange();
				}
			}
		};

		function getSelectedTasks (){
			var selectedTasksAsString = "";
			angular.forEach(initialization.selectedTasks, function(task){
				if(selectedTasksAsString === ""){
					selectedTasksAsString += task;
				}
				else{
					selectedTasksAsString += "|" + task; 
				}
			});

			return selectedTasksAsString;
		}

		function initializePolicyChange(){
			// ******* Analytics - Shopping list
			var selectedTransaction = getSelectedTasks();

			var props = {
				s_appStep : "pu:0",
				s_btnName : "policy update:start from shopping list",
				s_pageState : "",
				s_pageName: 'portfolio:policy update:welcome',
				s_selected_transaction_type : selectedTransaction
			};

			$PCAnalyticsService.trackPageView(props);

			initialization.transactionEffectiveDate = vm.date;
			var goto = 'next';
			$InitializationService.save(vm.currentPolicy.policyNumber, initialization, vm.stateDto, goto)
				.then(function(r) {
						$PCStateManagerService.goToPage(vm.currentPolicy.policyNumber, { goto: r.state.currentPage });
				});
		}

		function getPolicyChange(){
			return PolicyChangeData.PolicyChangeData;
		}

		function loadNavigationListener(){
			$scope.$on('eventRefreshDataForNavigation', function (){
				$PCStateManagerService.setPolicyChangeData(getPolicyChange());
			});
		}

		init();
	}
})(angular);
