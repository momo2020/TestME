(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:PolicyChangeManualAddressController
	 * @description
	 * PolicyChange Manual Address Controller<br>
	 * ControllerAs : addressManualCtrl
	 *
	 */
	angular.module('INTACT.PolicyChange').controller('PolicyChangeManualAddressController', controller);

	function controller($scope, $timeout, $filter, mapperDataService, $rootScope){
        var vm = this;


		vm.principalHolder = mapperDataService.getPrincipalHolder($scope.policyChangeData);
		var originalAddress = angular.copy(vm.principalHolder.address);
        vm.disableManualInput = true;
        vm.show_error = false;
		vm.manualAddress = {};
		resetAddress();

        vm.errorMessage = $filter('translate')('MSG00440.manual.address.error.label');

        vm.postalCodeChanged = function(postalCode) {
			$rootScope.$broadcast('fieldReset');
			if(postalCode && postalCode.length < 7){
        		resetAddress();
        		vm.principalHolder.address.postalCode = postalCode;
        	}
        	else if(postalCode === ""){
        		vm.principalHolder.address = angular.copy(originalAddress);
        	}
        };

		// Postal Code Found Event
		$scope.$on('ManualAddressPostalCodeFoundEvnt', function(evt, postalCode){
			vm.disableManualInput = false;
			vm.show_error = false;

			if(angular.isUndefined(postalCode) || postalCode === ""){
				vm.principalHolder.address = angular.copy(originalAddress);
			}
			else{
				focusOnStreet();
				resetAddress();
			}
		});

		// Postal Code Found Event
		$scope.$on('ManualAddressPostalCodeNotFoundEvnt', function(){
			vm.disableManualInput = true;
			vm.show_error = true;
		});

		// Manual Address Reset Event
		$scope.$on('ManualAddressPostalCodeResetEvnt', function(){
			vm.disableManualInput = true;
			// Test to be done
			vm.principalHolder.address = angular.copy(originalAddress);
		});

		// Manual Address Complete Event
		$scope.$on('ManualAddressCompleteEvnt', function(evt, manualAddress){
			vm.manualAddress = manualAddress;
			setAddress();
		});

		// Manual Address Incomplete Event
		$scope.$on('ManualAddressIncompleteEvnt', function(evt, manualAddress){
			vm.manualAddress = manualAddress;
			setAddress();
		});

        function setAddress(){
			var postalCode = $filter('uppercase')(vm.manualAddress.postalCode) || "";
			var city = "",
				municipalityCode = "";
			if(angular.isDefined(vm.manualAddress.city) && vm.manualAddress.city !== null){
				city = vm.manualAddress.city.city;
				municipalityCode = vm.manualAddress.municipalCode;
			}

			vm.principalHolder.address.province = vm.manualAddress.province;
			vm.principalHolder.address.postalCode = postalCode.replace(" ", "");
			vm.principalHolder.address.civicNumber = vm.manualAddress.streetNumber;
			vm.principalHolder.address.apartment = vm.manualAddress.aptNumber;
			vm.principalHolder.address.municipality = city;
			vm.principalHolder.address.municipalityCode = municipalityCode;

			if(angular.isDefined(vm.manualAddress.street) && vm.manualAddress.street !== null){
				vm.principalHolder.address.streetDirection = vm.manualAddress.street.streetDirection;
				vm.principalHolder.address.streetName = vm.manualAddress.street.streetName;
				vm.principalHolder.address.streetType = vm.manualAddress.street.streetType;
			}
			else{
				if(angular.isDefined(vm.manualAddress.streetFreeFormat) && vm.manualAddress.streetFreeFormat !== null && vm.manualAddress.streetFreeFormat !== ""){
					vm.principalHolder.address.streetDirection = "";
					vm.principalHolder.address.streetName = vm.manualAddress.streetFreeFormat;
					vm.principalHolder.address.streetType = "";
				}
			}
		}

		function resetAddress(){
			angular.forEach(vm.principalHolder.address, function(value, key){
				vm.principalHolder.address[key] = null;
			});
		}

		function focusOnStreet (){
			$timeout(function(){
				angular.element('street-number input')[0].focus();
			});
		}

	}
})(angular);
