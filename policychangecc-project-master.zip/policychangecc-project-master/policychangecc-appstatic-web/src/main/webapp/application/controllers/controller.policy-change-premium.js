(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:PolicyChangePremiumController
	 * @description
	 * PolicyChange Premium Controller<br>
	 * ControllerAs : PolicyChange
	 *
	 */
	angular.module('INTACT.PolicyChange').controller('PolicyChangePremiumController', controller);

	 function controller(PolicyChangeData,
					 	$PCAnalyticsService,
	 					$PCStateManagerService,
	 					$PCAppConfiguration,
	 					$filter,
	 					$scope){
		var vm = this;

		vm.policyChangeData = PolicyChangeData;
		vm.originalVehicles = PolicyChangeData.currentPolicy.vehicles;
		vm.vehicles = PolicyChangeData.policyChange.vehicles;
		vm.premiumHasChanged =  premiumHasChanged();
		vm.annualPremium = $filter('currency')(PolicyChangeData.currentPolicy.annualPremium, '$', 2);
		vm.newPremium = $filter('currency')(PolicyChangeData.policyChange.annualPremium, '$', 2);
		vm.step="#";
		vm.premiumInfo = getPremiumInfoByProvince();

		// toggle details
		vm.detailsVisibility = true;

		init();

		function premiumHasChanged() {
			return PolicyChangeData.currentPolicy.annualPremium !== PolicyChangeData.policyChange.annualPremium;
		}

		vm.toggleDetails = function() {
			vm.detailsVisibility = !vm.detailsVisibility;
		};

		vm.getCurrentVehiclePremium = function(index){
			var premium = vm.originalVehicles[index] ? vm.originalVehicles[index].annualPremium : 0;
			return $filter('currency')(premium, '$', 2);

		};

		vm.getNewVehiclePremium = function(index){
			var premium = vm.vehicles[index].annualPremium;
			return $filter('currency')(premium, '$', 2);
		};

		vm.getCarName = function(index) {
			var v = vm.vehicles[index];
			return $filter('formatCarName')(v.model.make, v.model.model, v.model.year);
		};

		function init(){
			$scope.$on('eventRefreshDataForNavigation', function (){
				setUsageModified(vm.policyChangeData.policyChange);
				$PCStateManagerService.setPolicyChangeData(vm.policyChangeData);
			});

			// ******* Analytics - [F6.8] Premium page
			var props = {
				s_appStep : "pu:7",
				s_pageName: 'portfolio:policy update:premium'
			};

			$PCAnalyticsService.trackPageView(props);
		}

		function getPremiumInfoByProvince(){
			var info;
			var province = $PCAppConfiguration.province.toLowerCase();

			switch (province) {
				case 'on':
				case 'qc':  
					info = $filter('translate')('LBL32341.premium');
					break;
			}
			
			return info;
		}

		function setUsageModified(policyChange){
			angular.forEach(policyChange.vehicles, function(car){
            	car.usageModified = true;
            });
		}
	}
})(angular);
