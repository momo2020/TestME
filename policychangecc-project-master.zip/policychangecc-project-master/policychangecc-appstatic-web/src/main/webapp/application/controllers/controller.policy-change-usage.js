(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:PolicyChangeUsageController
	 * @description
	 * PolicyChange Usage Controller<br>
	 * ControllerAs : UsageCtrl
	 *
	 */
	angular.module('INTACT.PolicyChange').controller('PolicyChangeUsageController', controller);

	 function controller(PolicyChangeData,
	 					$PCStateManagerService,
	 					$PolicyChangeValidation,
	 					DriverModel,
	 					PolicyHolderModel,
	 					VehicleModel,
	 					VehicleMakeModel,
	 					$filter,
	 					carService,
	 					$PolicyChangeService,
	 					$scope,
	 					$q,
	 					$state,
	 					$PCAnalyticsService){
	 	var vm = this,
	 		vehiclesData = PolicyChangeData.policyChange.vehicles ? PolicyChangeData.policyChange.vehicles : PolicyChangeData.currentPolicy.vehicles,
	 		driversData = PolicyChangeData.policyChange.drivers ? PolicyChangeData.policyChange.drivers : PolicyChangeData.currentPolicy.drivers ,
	 		phListData = PolicyChangeData.policyChange ? PolicyChangeData.policyChange.policyHolders : PolicyChangeData.currentPolicy.policyHolders,
	 		$translate = $filter('translate'),
	 		$modificationCode = $filter('modificationCode'),
	 		triedNext = false;


	 	// Public properties
	 	vm.translateCarName = $filter('formatCarName');
	 	vm.vehicles = getCarsList();
	 	vm.drivers = getDriversList();
	 	vm.policyHolders = getPchList();
	 	vm.carIndex = 0;
	 	vm.policyChangeData = PolicyChangeData;
		vm.errorOnPage = $PolicyChangeValidation.get().errors ? $PolicyChangeValidation.get().errors.length > 0 : false;

	 	// Public functions
	 	vm.getPolicyChange = getPolicyChange;
	 	vm.saveRisk = saveRisk;
	 	vm.canAddOtherDriver = canAddOtherDriver;

	 	vm.addressChanged = PolicyChangeData.state.addressModified;

	 	init();

	 	function errorIsCurrentCar(errors, currentCarIndex) {
	 		var carErrors = [];

	 		angular.forEach(errors, function(error) {
	 			if (error.elementIndex === currentCarIndex) {
	 				carErrors.push(error);
	 			}
	 		});

	 		return carErrors.length ? true : false;
	 	}

	 	function setUsageModified (){
	 		angular.forEach(vm.policyChangeData.policyChange.vehicles, function(vehicle){
	 			vehicle.usageModified = true;
	 		});
	 	}

	 	function cleanCarForSave(){
	 		var cleanVehicles = [];

	 		angular.forEach(vm.vehicles, function(vehicle){
	 			cleanVehicles.push(vehicle.vehicle);
	 		});

	 		vm.vehicles = cleanVehicles;
	 	}

	 	function saveRisk(index){
	 		var deferred = $q.defer();
	 		// Update modificationCode on the currentVehicle
	 		setDefaultUsageValuesForUpdate(vm.vehicles[vm.carIndex]);
	 		cleanCarForSave();
	 		setUsageModifiedOnAllCars();

	 		PolicyChangeData.policyChange.vehicles = vm.vehicles;
	 		$PolicyChangeService.put( PolicyChangeData.policyChange, {}).then(function(data){
				vm.carIndex = index;
				$scope.$emit('hideLoader');
	 			vehiclesData = data.policyChange.vehicles;
	 			vm.vehicles = getCarsList();
	 			driversData =  data.policyChange.drivers;
	 			vm.drivers = getDriversList();

	 			//refresh the policyHolders list 
	 			phListData = data.policyChange ? data.policyChange.policyHolders : data.currentPolicy.policyHolders;
	 			vm.policyHolders = getPchList();

	 			if(triedNext){
	 				setModifiedTrue();
	 			}
	 			$scope.$broadcast('reloadData', {policyHolders : vm.policyHolders, 
	 												vehicle : vm.vehicles[index], 
	 												carList : vm.vehicles,
	 												driverList : vm.drivers
	 											});
	 			vm.errorOnPage = false;
	 			deferred.resolve({hasValidationError: false});
	 		},function(error){
	 			if (error.hasValidationError){
	 				// validate error is on current car or reject error
	 				if(errorIsCurrentCar(error.errors, vm.carIndex)) {
	 					vm.errorOnPage = false;
	 					vehiclesData =PolicyChangeData.policyChange.vehicles;
			 			vm.vehicles = getCarsList();
			 			driversData =  PolicyChangeData.policyChange.drivers;
	 					vm.drivers = getDriversList();
			 			$scope.$broadcast('reloadData', {policyHolders : vm.policyHolders, 
	 												vehicle : vm.vehicles[vm.carIndex], 
	 												carList : vm.vehicles,
	 												driverList : vm.drivers
	 											});
						deferred.resolve({hasValidationError: true});
	 				}
	 				else {
	 					vm.errorOnPage = true;
	 					vehiclesData = vm.vehicles;
	 					vm.vehicles = getCarsList();
	 					vm.carIndex = index;
	 					$scope.$broadcast('reloadData', {policyHolders : vm.policyHolders, 
	 												vehicle : vm.vehicles[vm.carIndex], 
	 												carList : vm.vehicles,
	 												driverList : vm.drivers
	 											});
	 					deferred.resolve({hasValidationError: false});
	 				}
	 			}
	 		});
			return deferred.promise;

	 	}

	 	function getPolicyChange (){
			if(! vm.usageFormParent.$pristine){
				setDefaultUsageValuesForUpdate(vm.vehicles[vm.carIndex]);
				vm.policyChangeData.policyChange.vehicles[vm.carIndex] = vm.vehicles[vm.carIndex].vehicle; //vm.currentVehicle.vehicle;
			}

			return vm.policyChangeData;
		}

		function canAddOtherDriver(){
			var driverPageState = $filter("filter")(PolicyChangeData.state.pages, {type:'PC_DRIVERS'})[0];
			if(driverPageState && !driverPageState.otherPrincipalDriverAllowed){
				return false;
			}
			return true;
		}


		// Private functions
	 	function getDriversList (){
	 		var driverList = [];
		 	angular.forEach(driversData, function(driver){
		 		driverList.push(new DriverModel(driver).driver);
		 	});
	 		return driverList;
	 	}
	 	function getCarsList (){
	 		var carList = [];
		 	angular.forEach(vehiclesData, function(veh){
		 		carList.push(new VehicleModel(veh));
		 	});

	 		return carList;
	 	}
	 	function getPchList (){
	 		var policyHolderList = [];
 			angular.forEach(phListData, function(ph){
 				policyHolderList.push(new PolicyHolderModel(ph));
 			});

	 		return policyHolderList;
	 	}

		function setDefaultUsageValuesForUpdate(currentCar){
			currentCar.vehicle.modificationCode = $modificationCode($translate('MODIFICATION.CODE.MODIFIED'), currentCar.vehicle.modificationCode);
			currentCar.vehicle.usageModified = true;
		}

		function setUsageModifiedOnAllCars(){
			// as the back-end can't persist the usageModified, we have 
			// to make sure on multiple vehicles that we keep the flag right.
			if(vm.addressChanged){
				angular.forEach(vm.vehicles, function(vehicle){
					if(angular.isDefined(vehicle.vehicle)){
						if(vehicle.vehicle.annualKm !== null){
							vehicle.vehicle.usageModified = true;
						}	
					}
					else{
						if(vehicle.annualKm !== null){
							vehicle.usageModified = true;
						}	
					}
				});
			}
		}

		function setModifiedTrue(){
			if(vm.addressChanged){
				angular.forEach(vm.vehicles, function(vehicle){
					vehicle.vehicle.usageModified = true;
				});
			}
		}

		function loadNavigationListener(){
			$scope.$on('eventRefreshDataForNavigation', function (){
				if(! vm.usageFormParent.$pristine){
					setDefaultUsageValuesForUpdate(vm.vehicles[vm.carIndex]);
				}
				triedNext = true;
				setUsageModified();

				$PCStateManagerService.setPolicyChangeData(getPolicyChange());
			});
		}

		
		$scope.$on('ValidationDataUpdated', function(){

			if($PolicyChangeValidation.get()){
				if($PolicyChangeValidation.get().errors !== null){
					vm.errorOnPage = true;
				}
				else{
					vm.errorOnPage = false;
				}
			}
				
		});

		function init(){
			loadNavigationListener();

			if (!vm.canAddOtherDriver() && vm.vehicles[vm.carIndex].vehicle.principalDriver === -1) {
                // When principalDriver for the current vehicle is 'Other', we need to reset it to null
                // The 'Other' item in the dropdown should not be added when flag 'otherPrincipalDriverAllowed' is false
                vm.vehicles[vm.carIndex].vehicle.principalDriver = null;
            }

			/* Analytics - [F6.5] Usage */
			var props = {
				s_appStep: "pu:4",
				s_pageName: 'portfolio:policy update:usage'
			};

			$PCAnalyticsService.trackPageView(props);
		}

	 }
})(angular);
