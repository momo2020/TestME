(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:PolicyChangeCoverageController
	 * @description
	 * PolicyChange Coverage Controller<br>
	 * ControllerAs : PolicyChange
	 *
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 * @requires INTACT.PolicyChange.service:PolicyChangeData
	 */
	angular.module('INTACT.PolicyChange').controller('PolicyChangeCoverageController', controller);

	function controller(PolicyChangeData,
						$PCStateManagerService,
						$pcToasterService,
						$PCAnalyticsService,
						$filter,
						VehicleModel,
						WarningModel,
						$PCCoveragesService,
						$PolicyChangeValidation,
						$InlineValidationService,
						$PCValidationService,
						$log,
						CoveragesListModel,
						PolicyChangeModel,
						$PCAppConfiguration,
						$PolicyChange,
						$IntactModalService,
						$scope,
						$timeout,
						$q){
		var vm = this,
			sectionCodes = ['1', '2'],
			modelData = PolicyChangeData,
			isInitial = true,
			curVehData = modelData.currentPolicy.vehicles,
			pcVehData = modelData.policyChange.vehicles,
			codeNew = $filter('translate')('MODIFICATION.CODE.NEW'),
			codeSubstitute = $filter('translate')('MODIFICATION.CODE.SUBSTITUTED'),
			$helptextExists = $filter('helptextExists'),
			province = $PCAppConfiguration.province.toUpperCase();

		vm.premiumInfo = getPremiumInfoByProvince();
		vm.openScheduleCallDialog = openScheduleCallDialog;

		vm.policyChangeData = PolicyChangeData;

	    // Change this for dynamic with multiple vehicule (watch changes on this value for change all display)
	    vm.curentRiskSequence = null;

	    /**
	    * The effective policy
	    * @type {Object}
	    */
	    vm.currentPolicy = modelData.currentPolicy;

	    /**
	    * List of vehicles on current contract
	    * @type {Object}
	    */
	    vm.currVehicleList = [];

	    /*
	    * List of coverages codes the user changed at least once
	    * so that the modify button isn't displayed anymore
	    */
	    vm.coveragesChanged = [];

	    /**
	    * List of vehicles on policyChange
	    * @type {Object}
	    */
	    vm.pcVehicleList = [];

	    angular.forEach($filter('orderBy')(curVehData, 'riskIndex'), function(veh){
	    	vm.currVehicleList.push(new VehicleModel(veh));
	    });

	    angular.forEach($filter('orderBy')(pcVehData, 'riskIndex'), function(veh){
	    	vm.pcVehicleList.push(new VehicleModel(veh));
	    	vm.coveragesChanged.push([]);
	    });

	    if( vm.currVehicleList.length < vm.pcVehicleList.length ){
	    	var i = vm.pcVehicleList.length - vm.currVehicleList.length,
	    		riskIndex = vm.currVehicleList.length;
	    	for(i ; i > 0 ; i--){
	    		vm.currVehicleList.push(new VehicleModel({
	    			riskIndex : riskIndex
	    		}));
	    		riskIndex += 1;
	    	}
	    }

	    /**
	    * The policy that contains the user's changes
	    * @type {Object}
	    */
	    vm.policyChange = modelData.policyChange;

		/**
		* The selected risk on the current policy
		* @type {Object}
		*/
	    vm.currentRisk = null;

		/**
		* The selected risk on the policy change
		* @type {Object}
		*/
	    vm.currentPcRisk = null;

	    /**
	     * Sections coverages merges/formatted for display in page
	     * @type {CoveragesListModel}
	     */
	    vm.coveragesInSection = [];

	     /**
	     * Initialize interface with default risk index
	     */
	    onRiskChange(0);

	    showVehicleSubstitutionWarning();

	   	/**
	   	 * @ngdoc method
	     * @name PolicyChangeCoverageController#translateCarName
	     * @methodOf INTACT.PolicyChange.controller:PolicyChangeCoverageController
	     * @description
	     * Translate car information
	   	 */
	    vm.translateCarName = $filter('formatCarName');


		init();


		vm.showColumn = function (){
			return vm.pcVehicleList[vm.curentRiskSequence].vehicle.modificationCode !== codeNew;
		};

		vm.getFileKey = function(productCode){	    	
			return province + "/HLP_" + productCode.toUpperCase();
		};

	    vm.showHelptext = function(coverageCode){
	    	return $helptextExists(coverageCode);
	    };

	    /**
	    *
	    **/
	    vm.showBubble = function(){
	    	return (vm.currentPcRisk.vehicle.modificationCode === codeNew || vm.currentPcRisk.vehicle.modificationCode === codeSubstitute) && !vm.currentPcRisk.vehicle.coverageModified;
	    };

	    /**
		 * @ngdoc method
		 * @name INTACT.PolicyChange.controller:PCSidebarController#openScheduleCallDialog
		 * @methodOf INTACT.PolicyChange.controller:PCSidebarController
		 * @description
		 * Calls private function to create a modal instance && open Schedule a Call modal dialog
		*/
		function openScheduleCallDialog(){
			$PCStateManagerService.showLoader();
		
			var scheduleCallModalOptions = {
				templateUrl: '/partials/schedule-custom-call-dialog.html',
				controllerAs: 'scheduleCallCtrl',
				controller: 'ScheduleCallController'
			};

			return $IntactModalService.modal(scheduleCallModalOptions).on('$ModalServiceClose', function(redirect){
				if(redirect){
					
				}
			});
		}

	    function getCoveragesChanged (coveragesInSection) {
	    	var list = [];
	    	for(var i = 0, ll = coveragesInSection.length; i < ll; i++){
	    		if(!coveragesInSection[i].displayModify ||
	    			vm.coveragesChanged[vm.currentPcRisk.vehicle.riskIndex].indexOf(coveragesInSection[i].code) >= 0 ||
	    			(vm.currentPcRisk.vehicle.modificationCode === codeNew || vm.currentPcRisk.vehicle.modificationCode === codeSubstitute)){
	    			list.push(coveragesInSection[i].code);
	    		}
	    	}
	    	return list;
	    }

	    /*
	    * @ngdoc method
	    * @name PolicyChangeController#pushCoverageToChanged
	    * @methodOf INTACT.PolicyChange.controller:PolicyChangeCoverageController
	    * @description
	    * Insert the coverage in the list so that the modify button isn't displayed
	    * after a change.
	    */
	    vm.pushCoverageToChanged = function(id){
	    	vm.coveragesChanged[vm.currentPcRisk.vehicle.riskIndex].push(id);
	    };


	    /**
	    * @ngdoc method
	    * @name PolicyChangeCoverageController#onPackageElementRemove
	    * @mehtodOf INTACT.PolicyChange.controller:PolicyChangeCoverageController
	    * @description 
	    * manage the package coverages
	    * @param {Object} coverage 	Coverage to be removed
	    */
	    vm.onPackageElementRemove = function (coverage) {
	    	// Find the parent and deselect
	    	var parent = getParent(vm.currentPcRisk.vehicle.coverages, coverage.code);
	    	parent.selected = false;
	    	// Find other children and select them
	    	var children = getChildren(vm.currentPcRisk.vehicle.coverages, parent.code);
	    	for(var cov in children) {
	    		if(cov.code !== coverage.code) {
	    			cov.selected = true;
	    		}
	    	}
	    	// Ensure the coverage is still unselected
	    	coverage.selected = false;

	    	//M'oblige à faire autant de calls???


	    };

	    /**
	     * @ngdoc method
	     * @name PolicyChangeCoverageController#updateCoverage
	     * @methodOf INTACT.PolicyChange.controller:PolicyChangeCoverageController
	     * @description
	     * Update with Rest API call a specific coverage
	     * @param  {String} id       Coverage code
	     * @param  {String} value    Coverage new value
	     * @param  {String} oldValue Coevrage old value
	     */
	    vm.updateCoverage = function(id, value, oldValue){
	    	
	    	var coverage = null;
	    	var fn = 'put';

	    	if(isInitial){
	    		vm.coveragesChanged[vm.currentPcRisk.vehicle.riskIndex] = getCoveragesChanged(vm.coveragesInSection);
	    		isInitial = !isInitial;
	    	}

	    	for(var i = 0, l = vm.currentPcRisk.vehicle.coverages.length; i < l; i++) {
	    		if(vm.currentPcRisk.vehicle.coverages[i].code === id){
	    			coverage = vm.currentPcRisk.vehicle.coverages[i];
	    			break;
	    		}
	    	}

	    	if(coverage){
	    		value = (typeof(value) === 'boolean') ? value : (!value || angular.isString(value) && value.length === 0) ? null : + value;
	    		oldValue = (typeof(oldValue) === 'boolean') ? oldValue : (!oldValue || angular.isString(oldValue) && oldValue.length === 0) ? null : + oldValue;

	    		if(typeof(value) === 'boolean'){
	    			coverage.selected = value;
	    			coverage.selectedAmount = null;
	    		} else {
	    			coverage.selectedAmount = value;
	    		}

	    		if(value && oldValue) {
	    			fn = 'put';
	    		} else if(!oldValue && value) {
	    			fn = 'post';
	    		} else if(oldValue && (value === false || value === null)) {
	    			fn = 'delete';
	    		}

	    		$PCStateManagerService.showLoader();
	    		$PCCoveragesService[fn](vm.currentPcRisk.vehicle.sequenceNumber, coverage.code, coverage).then(function(r){

            		
	    			var resp = angular.fromJson(r.data);
	    			
	    			var warnings = new WarningModel(resp.validation);
	    			var hasWarnings = warnings.hasWarning;//resp.validation && resp.validation.warnings;

	    			modelData = new PolicyChangeModel(resp);
				    vm.pcVehicleList = [];

				    angular.forEach($filter('orderBy')(modelData.policyChange.vehicles, 'riskIndex'), function(veh){
				    	vm.pcVehicleList.push(new VehicleModel(veh));
				    });

				    if(hasWarnings){
				    	$pcToasterService.notifyToaster(warnings.getToasters());
					    // $pcToasterService.notifyToaster(resp.validation.warnings);
					}
					else{
				    	$pcToasterService.notifyToaster();
					}

	    			onRiskChange(vm.currentPcRisk.vehicle.riskIndex);

	    			// ******* Analytics - Coverage updated
	    			var props = {
	    				s_appStep: "pu:6",
	    				s_pageState: "313-0-0",
	    				s_recalcField: coverage.code + ":" + value,
	    				s_pageName: 'portfolio:policy update:coverage'
	    			};

	    			$PCAnalyticsService.trackPageView(props);
	    		});
	    	} else {
	    		$log.error('coverage not found for id == ' + id);
	    	}
	    };

	    vm.changeRisk = function(index){
	    	$PCStateManagerService.showLoader();

	    	return $q(function(resolve){
	    		onRiskChange(index);
	    		fireAnalytics();
	    		resolve({hasValidationError : false});
	    	});
	    };

	    function isPackage (coverage) {

	    }

	    function isParent (coverage) {

	    }

	    function getParent (coverages, coverageCode) {
	    	for(coverage in coverages) {
	    		if(coverage.code === coverageCode && coverage.packageCode === coverageCode) {
	    			return coverage;
	    		}
	    	}

	    	return null;
	    }

	    function getChildren (coverages, coverageCode) {
	    	var _children = [];

	    	for(coverage in coverages) {
	    		if(coverage.packageCode === coverageCode && coverage.code !== coverageCode){
	    			_children.push(coverage);
	    		}
	    	}

	    	return _children;
	    }

	    function showVehicleSubstitutionWarning() {
	 		$timeout( function() {
	 			// get warnings from provider since they're not  available on page load
	 			// var warnings = $PolicyChangeValidation.getValidationByType('warnings');
	 			var warnings = new WarningModel($PolicyChangeValidation.get());
	 			
	 			$pcToasterService.notifyToaster(warnings.getToasters, pcVehData);
	 			// $pcToasterService.notifyToaster(warnings, pcVehData);
	 		}, 1000);
	    }

	    function getCurrentPremium() {
	    	var premium = !modelData.currentPolicy.vehicles[vm.currentRisk.vehicle.riskIndex] ? $filter('currency')(0, '$', 2) :
	    		$filter('currency')(modelData.currentPolicy.vehicles[vm.currentRisk.vehicle.riskIndex].annualPremium, '$', 2);

	    	return premium;
	    }

	    function getNewPremium() {
	    	var premium = $filter('currency')(modelData.policyChange.vehicles[vm.currentRisk.vehicle.riskIndex].annualPremium, '$', 2);

	    	return premium;
	    }


	    /**
	     * @ngdoc method
	     * @name PolicyChangeCoverageController#onRiskChange
	     * @methodOf INTACT.PolicyChange.controller:PolicyChangeCoverageController
	     * @description
	     * Updates the current risk
	     * @param  {Integer} risk       Risk Sequence of the risk we want to view
	    */
		function onRiskChange(risk){
	    	if(!risk) {
	    		risk = 0;
	    	}

	    	// Set current Risk index
	    	vm.curentRiskSequence = risk;

	    	// Set current risk object
	    	vm.currentRisk = vm.currVehicleList[vm.curentRiskSequence];

		    // Set policyChange risk object
		    vm.currentPcRisk = vm.pcVehicleList[vm.curentRiskSequence];
	    	vm.currentPremium = getCurrentPremium();
	    	vm.newPremium = getNewPremium();

		    /**
		     * Sections coverages merges/formatted for display in page
		     * @type {CoveragesListModel}
		     */
		    vm.coveragesInSection = new CoveragesListModel(vm.currentRisk.vehicle.coverages, vm.currentPcRisk.vehicle.coverages, sectionCodes);

		    // Don't make the modify button reapear
		    var isInList = false;
		    for(var i = 0 ; i < vm.coveragesInSection.length; i++){
		    	isInList = (vm.coveragesChanged[vm.currentPcRisk.vehicle.riskIndex].indexOf(vm.coveragesInSection[i].code) >= 0) || (vm.currentPcRisk.vehicle.modificationCode === codeSubstitute || vm.currentPcRisk.vehicle.modificationCode === codeNew);
		    	if( isInList ){
		    		vm.coveragesInSection[i].displayModify = false;
		    	}
		    }
		    
		    $PCStateManagerService.hideLoader();
	    }

	    function getPolicyChange (){
			setUsageModified(modelData.policyChange);

			return modelData;
		}

		function setUsageModified(policyChange){
			angular.forEach(policyChange.vehicles, function(car){
            	car.usageModified = true;
            });
		}

		function loadNavigationListener(){
			$scope.$on('eventRefreshDataForNavigation', function (){
				$PCStateManagerService.setPolicyChangeData(getPolicyChange());
			});
		}

		function getPremiumInfoByProvince(){
			var info;
			var province = $PCAppConfiguration.province.toLowerCase();

			switch (province) {
				case 'on': 
				case 'qc': 
					info = '<span>' + $filter('translate')('LBL32341.premium') + '</span>' ;
					break;
			}
			
			return info;
		}

		function init(){
			loadNavigationListener();
			
 		    // ******* Analytics - [F6.7] Coverage page
			fireAnalytics();
			
		}

		function fireAnalytics(){

			var hasFPQ5 = _.some(vm.currentPcRisk.vehicle.coverages, {productCode: "FPX"}); 
			var props = {
			  	s_appStep: "pu:6",
			  	s_fastLane: hasFPQ5, 
				s_pageName: 'portfolio:policy update:coverage'
			};

			$PCAnalyticsService.trackPageView(props);
		}
	 }
})(angular);
