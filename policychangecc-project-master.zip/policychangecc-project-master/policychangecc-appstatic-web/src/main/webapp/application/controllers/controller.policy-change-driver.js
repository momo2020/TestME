(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:PolicyChangeDriverController
	 * @description
	 * PolicyChange Driver Controller<br>
	 * ControllerAs : pcDriverCtrl
	 *
	 * @requires INTACT.PolicyChange.service:PolicyChangeData
	 * @requires INTACT.PolicyChange.factory.DriverModel
	 * @requires https://docs.angularjs.org/api/ng/service/$filter
	 */
	angular.module('INTACT.PolicyChange').controller('PolicyChangeDriverController', controller);

	 function controller(PolicyChangeContext,
	 					$CoreWindowService,
		 				$PCAnalyticsService,
	 					DriverModel,
	 					$PCStateManagerService,
	 					$PolicyChangeState,
	 					$PolicyChange,
	 					$PolicyChangeService,
	 					$PCAppConfiguration,
	 					$filter,
						$scope,
						$rootScope,
						$log,
						$state,
						$q,
						$location,
						$anchorScroll){

		var vm = this;
		//vm.affinityGroups = PolicyChangeContext.AffinityGroupsData;
		var PolicyChangeData = PolicyChangeContext.PolicyChangeData;

		var	$orderBy = $filter('orderBy'),
			$translate = $filter('translate'),
			$modificationCode = $filter('modificationCode'),
			drivers = PolicyChangeData.policyChange ? PolicyChangeData.policyChange.drivers : PolicyChangeData.currentPolicy.drivers,
			codeNew = $translate('MODIFICATION.CODE.NEW'),
			codeModified = $translate('MODIFICATION.CODE.MODIFIED'),
			currentDrivers;

		/*
		*	Public properties
		*/
		vm.drivers = [];
		vm.showForm = {};
		vm.showFormNewDriver = false;
		vm.newDriver = {};
		vm.policyChangeData = angular.copy(PolicyChangeData);
		vm.editDriverIndex = null;
		vm.getPolicyChange = getPolicyChange;
		vm.studentTreshold = PolicyChangeData.studentAgeThreshold;
		vm.retiredTreshold = PolicyChangeData.retiredAgeThreshold;
		vm.setShowForm = setShowForm;
		vm.currDriverLicence = [];
		vm.currDriversGroup = [];
		vm.openedForm = null;
		vm.showBoxForToggledForm = false;
		

		vm.canAddDriver = function() {
			return $PolicyChangeState.$get().state().canAddDriver;
		};

		vm.removeDriver = function(){
			vm.refreshModels();
			$scope.$emit('defaultEventId', {message : $translate('LBL45888.driver.success.remove')});
		};

		vm.refreshModels = function() {
			PolicyChangeData = $PolicyChange.$get().policyChange();
			drivers = PolicyChangeData.policyChange ? PolicyChangeData.policyChange.drivers : PolicyChangeData.currentPolicy.drivers;

			init();
		};

		/*
		*	Public function to toggle any form
		*	Returns if the driver is existing in classic
		*/
		vm.toggleForm = function(sequence, add, driverIndex, reset){
			var currentDriverIndex = add ? vm.drivers.length : driverIndex;
			
			setEditDriverIndex(currentDriverIndex);

			if(add && !vm.openedForm){
				vm.newDriver = new DriverModel({
					driverIndex : vm.drivers.length,
					sequence : 0
				});

				var newDriverIndex = vm.newDriver.driver.driverIndex;

				vm.showFormNewDriver = true;
				sequence = 0;
				vm.openedForm = !vm.openedForm;
				$rootScope.$broadcast('loadOccupations');

				/* Analytics - [F6.18] Add Driver started */
				var props_add_started = {
					s_appStep: "pu:3." + (newDriverIndex + 1),
					s_pageState: "134-1-0",
					s_pageName: "portfolio:policy update:drivers:add started"
				};

				$PCAnalyticsService.trackPageView(props_add_started);
			}
			else if (add){
				vm.newDriver = {};
				vm.showFormNewDriver = false;
				vm.currDriverLicence.push({
					driverIndex : vm.drivers.length,
					sequence : 0,
					licenceType : ''
				});
				sequence = 0;
				vm.openedForm = !vm.openedForm;
				vm.showBoxForToggledForm = false;
			}

			// Cancel Modification on existing driver
			else if (vm.showForm[sequence] && vm.openedForm && (reset === undefined || reset)){
				$scope.$broadcast('ccButtonSwapLabelChanged', sequence);
				vm.resetDriver(driverIndex, sequence, false);
				vm.setShowForm(sequence, !vm.showForm[sequence]);
				vm.openedForm = !vm.openedForm;
			}

			// Modify Existing Driver
			else if ((vm.showForm[sequence] || !vm.openedForm) && !reset){
				$scope.$broadcast('ccButtonSwapLabelChanged', sequence);
				$rootScope.$broadcast('loadOccupations');
				vm.setShowForm(sequence, !vm.showForm[sequence]);
				vm.openedForm = !vm.openedForm;

				/* Analytics - [F6.20] Modify Driver started */
				var props_modify_started = {
					s_appStep: "pu:3." + sequence,
					s_pageState: "135-1-0",
					s_pageName: "portfolio:policy update:drivers:update started"
				};

				$PCAnalyticsService.trackPageView(props_modify_started);
			}
		};

		/*
		*	Function to determine if driver is part of the current policy or is a newly added driver on pch
		*/
		vm.isNewDriver = function(driverIndex){
			var isNewOnPCH = false;
			angular.forEach(vm.drivers, function(driver){
				if(driver.driver.driverIndex === driverIndex){
					isNewOnPCH = driver.driver.modificationCode === codeNew;
				}
			});

			return isNewOnPCH;
		};

		/**
		*	Updates the modified driver
		**/
		vm.updateDriver = function (driver, driverIndex){
			// if(driver.modificationCode === 'N'){
				setDefaultDriverValuesForUpdate(driver);

				PolicyChangeData = getPolicyChange();

				// send a copy since validation will not restaure data
				var payLoad = angular.copy(PolicyChangeData.policyChange);
				var drivers = vm.drivers.map( function(item) {
					return item.driver;
				});
				payLoad.drivers = getCleanDrivers(angular.copy(drivers));

				$PolicyChangeService.put(payLoad, {}).then(
					//Success
					function(data){
						if(data){
							vm.toggleForm(driver.sequence, false, driverIndex, false);
							vm.drivers = [];
							populateDriverList(data.policyChange.drivers);
							vm.isSpouseVisible = canAddSpouse();

							setRoadBlockMessages();
							angular.copy(data.policyChange, vm.policyChangeData.policyChange);
							currentDrivers = angular.copy(vm.drivers);
							$CoreWindowService.scrollTop(100);
							$scope.$emit('defaultEventId', {message : $translate('LBLXXXXX.driver.successmessage.updated')});

							/* Analytics - [F6.21] Modify Driver completed */
							var props_modify_completed = {
								s_appStep: "pu:3." + (driverIndex + 1),
								s_pageState: "135-2-1",
								s_pageName: "portfolio:policy update:drivers:update completed"
							};

							$PCAnalyticsService.trackPageView(props_modify_completed);
						}
					});
			// }
			// else{
			// 	vm.resetDriver(driverIndex, driver.sequence, true);
			// 	$CoreWindowService.scrollTop(100);
			// }
		};

		/**
		*	Save a new driver on the policy
		**/
		vm.saveNewDriver = function(_driver){
			setDefaultDriverValuesForAdd(_driver);

		    // send a copy since validation will not restaure data
			var payLoad = angular.copy(PolicyChangeData.policyChange);

			var driver = (_driver.driver) ? _driver.driver : _driver;
			payLoad.drivers.push(driver);

			payLoad.drivers = getCleanDrivers(payLoad.drivers);
			setUsageModified(payLoad);

			$PolicyChangeService.put(payLoad, {}).then(
				//success
				function(data){
					if(data){
						vm.toggleForm(driver.sequence, true);
						vm.drivers = [];
						populateDriverList(data.policyChange.drivers);
						vm.isSpouseVisible = canAddSpouse();

						currentDrivers = angular.copy(vm.drivers);
						setRoadBlockMessages();
						angular.copy(data.policyChange, vm.policyChangeData.policyChange);
						vm.newDriver = {};
						$CoreWindowService.scrollTop(100);
						$scope.$emit('hideLoader');
						$scope.$emit('defaultEventId', {message : $translate('LBL43612.driver.successmessage.new.from.other')});

						/* Analytics - [F6.19] Add Driver completed */
						var props_add_completed = {
							s_appStep: "pu:3." + (driver.driverIndex + 1),
							s_pageState: "134-2-1",
							s_pageName: "portfolio:policy update:drivers:add completed"
						};

						$PCAnalyticsService.trackPageView(props_add_completed);
					}
				});
		};
		/**
		* Resets the driver to previous state in case of Cancel
		**/
		vm.resetDriver = function(driverIndex, formSequence, toggle){
			vm.drivers[driverIndex].driver = angular.copy(currentDrivers[driverIndex].driver);

			if(toggle){
				vm.toggleForm(formSequence, false, driverIndex, true);
			}

			$scope.$emit('hideLoader');
			$scope.$broadcast('reloadDriver');
		};

		/*
		*	Set all forms at false if no parameters are entered
		*	Set selected form with the show parameter
		*/
		function setShowForm(sequence, show){
			if(sequence === null || sequence === undefined){
				vm.drivers.forEach(function(item){
					vm.showForm[item.driver.sequence] = false;
				});
				vm.showFormNewDriver = false;
			}
			else{
				vm.showForm[sequence] = show;
			}
		}

		function setDefaultDriverValuesForUpdate(currentDriver){
			currentDriver.modificationCode = $modificationCode(codeModified, currentDriver.modificationCode);
		}

		function setDefaultDriverValuesForAdd(newDriver){
			newDriver.driver.modificationCode = $modificationCode(codeNew, newDriver.driver.modificationCode);
			var province = $PCAppConfiguration.province.toUpperCase();
			if(province === "QC"){
				// Issue with the HardRoadblock 1225 for Qc
				newDriver.driver.driverTrainingCourse = false;
			}
		}

		function getCleanDrivers(drivers){
			var cleanDrivers = [];
			angular.forEach( drivers, function(driver){
				if(driver.driver) {
					driver = driver.driver;
				}

				if(driver.claims && driver.claims.length){
					var tmpClaims = [];
						angular.forEach(driver.claims, function(claim){
							if (angular.isObject(claim.claim)) {
								tmpClaims.push(claim.claim);
							} else {
								tmpClaims.push(claim);
							}
						});

					driver.claims = tmpClaims;
				}
				cleanDrivers.push(driver);
			} );

			return cleanDrivers;
		}

		function getPolicyChange (){
			var changedDrivers = angular.copy(vm.drivers);
			if(vm.editDriverIndex != null ){

				if(vm.showFormNewDriver){
					setDefaultDriverValuesForAdd(vm.newDriver);
					changedDrivers.push(vm.newDriver);
				}
			}
			vm.policyChangeData.policyChange.drivers = getCleanDrivers(changedDrivers);

			setUsageModified(vm.policyChangeData.policyChange);
			
			return vm.policyChangeData;
		}

		function setUsageModified(policyChange){
			var state = $PolicyChangeState.$get().state();

			// if usage page was completed then set for each car the usageModified = true
			var usagePage = $filter("filter")(state.pages, {type: 'PC_VEH_USAGE'})[0];
			if(angular.isDefined(usagePage)){
				if(usagePage.completed){
					angular.forEach(policyChange.vehicles, function(car){
		            	car.usageModified = true;
		            });
				}
				else if(state.addressModified){
					angular.forEach(policyChange.vehicles, function(vehicle){
						if(vehicle.annualKm !== null){
							vehicle.usageModified = true;
						}
					});
				}
			}			
			else if(state.addressModified){
				angular.forEach(policyChange.vehicles, function(vehicle){
					if(vehicle.annualKm !== null){
						vehicle.usageModified = true;
					}
				});
			}
		}

		function setRoadBlockMessages (){
			vm.roadBlockTitle = vm.drivers.length > 1 ? $translate('LBL43494.driver.remove.rdblk.title') : $translate('LBL43717.driver.remove.one.driver');
			vm.roadBlockText = vm.drivers.length > 1 ? $translate('LBL43494.driver.remove.rdblk.desc') : "";
		}

		function loadNavigationListener(){
			$scope.$on('eventRefreshDataForNavigation', function (){
				$PCStateManagerService.setPolicyChangeData(getPolicyChange());
			});
		}

		function populateDriverList(_drivers){
			//fill drivers list as DriverModel

			var driversToView = [];
			angular.forEach(_drivers, function(driver){
				driversToView.push(new DriverModel(driver));
			});

			driversToView = $orderBy(driversToView, 'driver.driverIndex');

			vm.drivers = driversToView;
		}

		function setCurrentDriversLicences(){
			var driversCurrPolicy = PolicyChangeData.currentPolicy.drivers,
				licencesList = [];
			angular.forEach(driversCurrPolicy, function(driver){
				licencesList.push({
					driverIndex : driver.driverIndex,
					licenceType : driver.driverLicenceType
				});
			});
			vm.currDriverLicence = licencesList;
		}

		function setEditDriverIndex(index){
			vm.editDriverIndex = index;
		}

		function isSpouseAssigned(){
			var spouseDriver =  vm.drivers.filter(function(d) {
                        			return d.driver.relationshipToPolicyHolder === "C";
            			        });

			if (spouseDriver !== undefined && spouseDriver.length>0){
				return true;
			}

			return false;
		}

		function isPolicyHolderMarried(){
			var policyHolder =  vm.drivers.filter(function(d) {
                        			return d.driver.policyHolder === true;
            			        });

			if(policyHolder && policyHolder.length > 0){
				if(policyHolder[0].driver && policyHolder[0].driver.maritalStatus === 'M'){
					return true;
				}
			}

			return false;
		}

		function canAddSpouse(){
			if(isPolicyHolderMarried() && !isSpouseAssigned()){
				return true;
			}

			return false;
		}

		// BEEN REMOVED FOR THE MOMENT
		// function setCurrDriversGroupList (){
		// 	currentDrivers = $orderBy(currentDrivers, 'driver.driverIndex');
		// 	angular.forEach(currentDrivers, function(driver){
		// 		var id = driver.driver.insuredGroup,
		// 			desc = driver.driver.insuredGroupDesc;
		// 		vm.currDriversGroup.push({
		// 			id : id,
		// 			desc : desc
		// 		});
		// 	});
		// }

		function scrollToNew(){
			var old = $location.hash();
			$location.hash('add-driver-anchor');
			$anchorScroll();
			$location.hash(old);
		}

		function automaticalyToggleNew (){
			var openingMode = $PCStateManagerService.getPageOpeningMode(PolicyChangeData.state),
				addNewMode = "ADD_NEW";
				if(openingMode === addNewMode){
					vm.toggleForm(0, true);

					angular.element('#add-driver-anchor').ready(function(){
						scrollToNew();
					});

					vm.showBoxForToggledForm = true;
				}
		}

		function init(){
			populateDriverList(drivers);
			currentDrivers = angular.copy(vm.drivers);
			vm.setShowForm();
			vm.openedForm = false;
			setCurrentDriversLicences();
			//setCurrDriversGroupList();

			loadNavigationListener();
			setRoadBlockMessages();
			vm.isSpouseVisible = canAddSpouse();

			//Toggle automaticaly New Driver if Other has been selected
			automaticalyToggleNew();

			/* Analytics - [F6.4] Drivers */
			var props = {
				s_appStep : "pu:3",
				s_pageName: 'portfolio:policy update:drivers'
			};

			$PCAnalyticsService.trackPageView(props);
		}
		init();

	 }
})(angular);
