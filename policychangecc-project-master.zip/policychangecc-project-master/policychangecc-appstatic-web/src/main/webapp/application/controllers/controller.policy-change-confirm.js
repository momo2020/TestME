(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:PolicyChangeConfirmController
	 * @description
	 * PolicyChange Confirm Controller<br>
	 * ControllerAs : ConfirmCtrl
	 *
	 */
	angular.module('INTACT.PolicyChange').controller('PolicyChangeConfirmController', controller);

	 function controller(PolicyChangeData,
					 	$PCAnalyticsService,
					 	$PCAppConfiguration,
	 					$PCStateManagerService,
	 					$PolicyChangeModifications,
	 					$scope,
	 					$filter, 
	 					$window){
	 	var vm = this;

	 	var translate = $filter('translate'),
            modificationsProvider = $PolicyChangeModifications.$get();

	 	vm.policyChangeData = PolicyChangeData;

	 	var firstName = PolicyChangeData.policyChange.user.firstName ? PolicyChangeData.policyChange.user.firstName  : "John";

	 	vm.fullName = firstName ;


	 	vm.linkToClientCenter = $PCAppConfiguration.clientCentreUrl;

	 	vm.annualPremiumLabel = getAnnualPremiumLabel();

        vm.gotoCC = function (){
        	$window.location = vm.linkToClientCenter;
        };

	 	init();

	 	function getAnnualPremiumLabel() {
	 		var label = translate('LBL45041.confirm');
	 		var premium = $filter('currency')(PolicyChangeData.policyChange.annualPremium);
	 		var labelStr = label.replace('{Current Annual Premium}', premium);
	 		return labelStr;
	 	}

	 	function getPolicyChange (){
			return vm.policyChangeData;
		}

		function loadNavigationListener(){
			$scope.$on('eventRefreshDataForNavigation', function (){
				$PCStateManagerService.setPolicyChangeData(getPolicyChange());
			});
		}

		/**
		* For Analytics -- concatenates with piping if necessary
		**/
		function concatValue (toBeAdded, aString, piping){
			if(aString !== ""){
				aString += piping + toBeAdded;
			}
			else{
				aString = toBeAdded;
			}
			return aString;
		}

		/**
		* For Analytics -- identifies the type of transaction
		*   and concatenates the modifications made
		**/
		function buildTransactionTypeString (modifications){
			var transactionType = "",
				piping = "|";

			//addressChange
			if(modifications.addressChange().length > 0){
				transactionType = concatValue("addressChanged", transactionType, piping);
			}

			//vehicles changes
			if(modifications.hasVehicleChanges()){
				var vehMod = modifications.getVehiclesByCode("M"),
					vehNew = modifications.getVehiclesByCode("N"),
					vehSub = modifications.getVehiclesByCode("U");

				if(vehMod.length > 0){
					angular.forEach(vehMod, function(vehicle){
						transactionType = concatValue(vehicle.index + ":vehicleModified", transactionType, piping);
					});
				}
				if(vehNew.length > 0){
					angular.forEach(vehNew, function(vehicle){
						transactionType = concatValue(vehicle.index + ":vehicleNew", transactionType, piping);
					});
				}
				if(vehSub.length > 0){
					angular.forEach(vehSub, function(vehicle){
						transactionType = concatValue(vehicle.index + ":vehicleSubstituted", transactionType, piping);
					});
				}
			}

			//driver changes
			if(modifications.hasDriverChanges()){
				var drMod = modifications.getDriversByCode("M"),
					drAdd = modifications.getDriversByCode("N");

				if(drMod.length > 0){
					angular.forEach(drMod, function(driver){
						transactionType = concatValue(driver.index + ":driverModified", transactionType, piping);
					});
				}

				if(drAdd.length > 0){
					angular.forEach(drAdd, function(driver){
						transactionType = concatValue(driver.index + ":driverAdded", transactionType, piping);
					});
				}
			}

			//coverageChanges 
			if(modifications.hasCoveragesChanges()){
				var toBeAdded = "";
				angular.forEach(modifications.getCoveragesModifications(), function(car){
					var vehicleSequence = car.vehicle.updated.sequenceNumber.toString();
					angular.forEach(car.modifications, function(modif){
						toBeAdded = vehicleSequence + ":" + modif.coverageCode + ":" + modif.qualifierLabel + ":" + modif.newValue;
						transactionType = concatValue( toBeAdded, transactionType, piping );
					});
				});
			}

			//usageChanges
			if(modifications.hasUsagesChanges()){
				angular.forEach(modifications.getUsageModification(), function(usage){
					transactionType = concatValue(usage.index + ":usageUpdated", transactionType, piping);
				});
			}

			return transactionType;
		}

		function initTagging(){
			var modifications = modificationsProvider.getModifications();
			var transactionType = buildTransactionTypeString(modifications);

			// ******* Analytics - [F6.10] Confirmation page
			var props = {
				s_appStep : "pu:9",
    			s_pageState : "314-2-1",
				s_pageName: 'portfolio:policy update:confirmation',
				s_transaction_type: transactionType
			};

			$PCAnalyticsService.trackPageView(props);
		}

		function init(){
			loadNavigationListener();

			initTagging();

		}

	 }
})(angular);
