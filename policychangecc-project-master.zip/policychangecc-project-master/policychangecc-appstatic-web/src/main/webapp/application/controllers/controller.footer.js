(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:PCFooterController
	 * @description
	 * Main controller
	 *
	 * @requires https://docs.angularjs.org/api/ng/service/$log
	 * @requires https://github.com/angular-ui/ui-router#$state
	 * @requires core/INTACT.Core.service:$CoreWindowService
	 * @requires INTACT.PolicyChange.service:$PCAppConfiguration
	 * @requires https://docs.angularjs.org/api/ng/filter/filter
	 */
	angular.module('INTACT.PolicyChange').controller('PCFooterController', Controller);

	function Controller(DistributorData, $PCAppConfiguration, $filter){
		var vm = this;
		var language = $PCAppConfiguration.preferredLanguage;
		var province = $PCAppConfiguration.province.toLowerCase();

		/**
		 * @ngdoc property
		 * @name INTACT.PolicyChange.controller:PCFooterController#distributor
		 * @propertyOf INTACT.PolicyChange.controller:PCFooterController
		 * @description
		 * List of informations : openning days and hours, phone numbers, etc.
		 * @returns {Object} List of informations
		 */
		vm.distributor = DistributorData;
		
		/**
		* @ngdoc property
		* @name INTACT.PolicyChange.controller:PCFooterController#urls
		* @propertyOf INTACT.PolicyChange.controller:PCFooterController
		* @description
		* List of urls used in footer. Come from backend configuration service
		* @returns {Object} List of urls
		*/
		vm.urls = {
			policies: $PCAppConfiguration.privacyURL.replace('{0}', province),
			terms: $PCAppConfiguration.useTermsURL.replace('{0}', province),
			security: $PCAppConfiguration.securityURL.replace('{0}', province),
			certificate: $PCAppConfiguration.entrustClientUrl.replace('{0}', language)
		};

		/**
		* @ngdoc property
		* @name INTACT.PolicyChange.controller:PCFooterController#copyright
		* @propertyOf INTACT.PolicyChange.controller:PCFooterController
		* @description
		* Copyright text concatenation with current year
		* @returns {String} Copyright text
		*/
		vm.copyright = $filter('date')(new Date(), 'yyyy') + ' ' + $PCAppConfiguration.copyright;
		
		/**
		* @ngdoc property
		* @name INTACT.PolicyChange.controller:PCFooterController#currentYear
		* @propertyOf INTACT.PolicyChange.controller:PCFooterController
		* @description
		* current year
		* @returns {String} Current Year 
		*/
		vm.currentYear = $filter('date')(new Date(), 'yyyy') ;
		
		/**
		* @ngdoc property
		* @name INTACT.PolicyChange.controller:PCFooterController#confirm
		* @propertyOf INTACT.PolicyChange.controller:PCFooterController
		* @description
		* disclaimer added for confirm page
		* @returns {String} Confirm page disclaimer
		*/
		var openningDays = "2";
		vm.confirm = $filter('translate')('LBL45911.confirm.footer', {
			NB_BUSINESSDAYS : openningDays
		});

		var disclaimerKey = 'global.footer.disclaimer';
		if(province !== 'qc'){
			disclaimerKey += '.' + province;
		}

		/**
		* @ngdoc property
		* @name INTACT.PolicyChange.controller:PCFooterController#disclaimer
		* @propertyOf INTACT.PolicyChange.controller:PCFooterController
		* @description
		* Disclaimer for specific provinces rules
		* @returns {String} Disclaimer text
		*/
		vm.disclaimer = $filter('translate')(disclaimerKey);
	}
})(angular);