(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:PCSummaryController
	 * @description
	 * Main controller
	 *
	 * @requires https://docs.angularjs.org/api/ng/service/$log
	 */
	angular.module('INTACT.PolicyChange').controller('PCSummaryController', Controller);

	function Controller(){}
})(angular);