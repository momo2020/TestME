(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:MainController
	 * @description
	 * Main controller
	 *
	 * @requires https://docs.angularjs.org/api/ng/service/$log
	 */
	angular.module('INTACT.PolicyChange').controller('MainController', MainController);

	function MainController($filter, $PCAppConfiguration, $state){
		var vm = this;

		vm.lang = $PCAppConfiguration.preferredLanguage;

		vm.getCurrentId = function(){
			return ($state.current.data)? $state.current.data.ID : '';
		};
	}
})(angular);