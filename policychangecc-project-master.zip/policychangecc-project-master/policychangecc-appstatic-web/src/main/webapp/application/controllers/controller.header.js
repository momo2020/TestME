(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:PCHeaderController
	 * @description
	 * Main controller
	 */
	angular.module('INTACT.PolicyChange').controller('PCHeaderController', Controller);

	function Controller(){}
})(angular);