(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:ScheduleCallController
	 * @description
	 * Controller for the schedule a call

	 */
	angular.module('INTACT.PolicyChange').controller('ScheduleCallController', Controller);

	function Controller($log, 
						close,
						$filter, 
						$element,
						$PCAppConfiguration, 
						$PolicyChangeService,
						$PolicyChange, 
						$PCAnalyticsService, 
						$PCStateManagerService,
						ScheduleCallModel,
						$ScheduleCallService){
		var vm = this;
		vm.scheduleInfo = new ScheduleCallModel($PolicyChange.$get().policyChange());
		vm.errorContext = null;
		vm.scheduleCallSelected = false;
		vm.helpPhoneNumber = $PCAppConfiguration.rdblckPhoneNumber;
		vm.showCustomScheduler = showCustomScheduler;

		var currentPage = $filter('getStep')($PolicyChange.$get().policyChange() ? $PolicyChange.$get().policyChange().state.currentPage: null, false);
											 
		init();

		/**
		 * @ngdoc method
		 * @name INTACT.PolicyChange.controller:SaveAndQuitController#close
		 * @methodOf INTACT.PolicyChange.controller:SaveAndQuitController
		 *
		 * @description
		 * Close current modal opened ({@link https://github.com/dwmkerr/angular-modal-service cf. Module})
		 */
		vm.close = function(isCustomDialog){
			// Animation close pop-up (TODO wrap it in service)
			$element.addClass('animate-modal modal-hide');
			close(false, 200);
			fireAnalyticsScheduleCallIgnored(isCustomDialog);
		};

		/**
		 * @ngdoc method
		 * @name INTACT.PolicyChange.controller:SaveAndQuitController#save
		 * @methodOf INTACT.PolicyChange.controller:SaveAndQuitController
		 *
		 * @description
		 * Gets initializationDTO object, puts update and
		 * close modal ({@link https://github.com/dwmkerr/angular-modal-service cf. Module})
		 */

		vm.createWorkItem = function(isCustomDialog) {
			$PCStateManagerService.showLoader();
			vm.waiting = true;

			$ScheduleCallService.createSchedule(vm.scheduleInfo).then(function () {
				vm.waiting = false;
				close(true, 200);
				fireAnalyticsScheduleCallSubmit(isCustomDialog);
				$PCStateManagerService.hideLoader();
		    },function(rejectObject) {
		    	vm.waiting = false;
		        $PCStateManagerService.hideLoader();

		        fireAnalyticsScheduleCallValidation(rejectObject, isCustomDialog);
		        
		        if(rejectObject.hasValidationError){
		        	vm.errorContext = rejectObject.errors;
		        }
		        else{
		        	close(false, 200);
		        }

		    });
		};

		function fireAnalyticsScheduleCallSubmit(isCustomDialog){
			var props;

			if (isCustomDialog){
				props = {
					s_appStep: "pu:" + currentPage,
					s_btnName: "pu:call scheduled from roadblock",
					s_pageName: "portfolio:policy update:soft roadblock:schedule a call completed",
					s_pageState: "",
					s_scheduleTime: vm.scheduleInfo.preferedTime
				};
			}
			else{
				props = {
					s_appStep: "pu:" + currentPage,
					s_pageName: "portfolio:policy update:schedule a call completed",
					s_pageState: "594-2-1",
					s_scheduleTime: vm.scheduleInfo.preferedTime
				};	
			}

			$PCAnalyticsService.trackPageView(props);
		}

		function fireAnalyticsScheduleCallValidation(errorContext, isCustomDialog){
			
			var message = "";
            var formError = "";
			var errors = errorContext.hasValidationError ? errorContext.errors : null;
			errors.forEach( function(validationMessage, key) {
				formError = validationMessage.field + ":" + validationMessage.message;
                message += key !== 0 ? "," + formError : formError;
            });
			
			var props = {
					s_appStep: "pu:" + currentPage,
					s_pageState: "",
					s_formErrors: message
			};

			if (isCustomDialog){
				props.s_btnName = "pu:call scheduled from roadblock";
				props.s_pageName = "portfolio:policy update:soft roadblock:schedule a call initiated";
			}
			else {
				props.s_pageName = "portfolio:policy update:schedule a call initiated";
			}
			

			$PCAnalyticsService.trackPageView(props);
		}

		function fireAnalyticsScheduleCallIgnored(isCustomDialog){

			if (isCustomDialog){
				var props = {
					s_appStep: "pu:" + currentPage,
					s_btnName: "pu:call not scheduled from roadblock",
					s_pageName: "portfolio:policy update:soft roadblock:schedule a call ignored",
					s_pageState: ""
				};

				$PCAnalyticsService.trackPageView(props);
			}

		}

		function showCustomScheduler(){
			vm.scheduleCallSelected = !vm.scheduleCallSelected;

			fireAnalyticsScheduleCallInit();
		}

		function fireAnalyticsScheduleCallInit(){
			var props = {
				s_appStep: "pu:" + currentPage,
				s_pageName: 'portfolio:policy update:soft roadblock:schedule a call initiated',
				s_pageState: "314-2-3",
				s_reason: "FPQ5"
			};
			$PCAnalyticsService.trackPageView(props);
		}

		function init() {
			$PCStateManagerService.hideLoader();
		}
	}

})(angular);
