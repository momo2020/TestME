(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:PolicyChangeAddressController
	 * @description
	 * PolicyChange Address Controller<br>
	 * ControllerAs : addressCtrl
	 *
	 */
	angular.module('INTACT.PolicyChange').controller('PolicyChangeAddressController', Controller);

	function Controller(PolicyChangeData,
						$PCAnalyticsService,
						mapperDataService,
						$PCStateManagerService,
						$scope,
						$filter){
		var vm = this;

		vm.policyChangeData = PolicyChangeData;
		vm.principalHolder = mapperDataService.getPrincipalHolder(PolicyChangeData);
		var originalAddress = angular.copy(vm.principalHolder.address),
			originalHomePhone = angular.copy(vm.principalHolder.homePhoneNumber),
			originalBusinessPhone = angular.copy(vm.principalHolder.businessPhoneNumber);

		vm.addressLines = $filter('displayAddress')(originalAddress);
		vm.homePhoneDummy = originalHomePhone;
		vm.businessPhoneDummy = originalBusinessPhone;

		// hideBusinessPhone if phone is not defined or if phones are identical to home phone
		vm.hideBusinessPhone = originalBusinessPhone === null || phonesAreIdentical();
		vm.displayErrorAutocomplete = false;

		init();

		vm.applyPhoneBehavior = function(propertyName){
			// if the user lose focus with an invalid homePhoneNumber or businessPhoneNumber the original value must be reassigned
			if (propertyName === 'homePhoneNumber'){
				if(vm.homePhoneDummy && vm.homePhoneDummy.length === 10){
					vm.principalHolder[propertyName] = vm.homePhoneDummy;
				}
				else{
					vm.principalHolder[propertyName] = originalHomePhone;
					vm.homePhoneDummy = originalHomePhone.substring(0, 3) + "-" +  originalHomePhone.substring(3, 6) + "-" + originalHomePhone.substring(6, 10);
				}
			}
			else if(propertyName === 'businessPhoneNumber'){
				if(vm.businessPhoneDummy && vm.businessPhoneDummy.length === 10 || vm.businessPhoneDummy.length === 0){
					vm.principalHolder[propertyName] = vm.businessPhoneDummy.length === 0 ? null : vm.businessPhoneDummy;
				}
				else{
					vm.principalHolder[propertyName] = originalBusinessPhone;
					vm.businessPhoneDummy = '';
				}
			}

			// Verify if phone are identical if not display both phone number
			if (isPhoneValid(propertyName)){
				if(originalBusinessPhone){
					vm.hideBusinessPhone = phonesAreIdentical();
				}else{
					// businessPhone undefined don't show it
					vm.hideBusinessPhone = true;
				}
			}
		};

		function phonesAreIdentical(){
			if (vm.principalHolder.homePhoneNumber && vm.principalHolder.businessPhoneNumber){
				return vm.principalHolder.homePhoneNumber === vm.principalHolder.businessPhoneNumber;
			}
			return false;
		}

		function isPhoneValid(propertyName){
			if (vm.principalHolder[propertyName]){
				return vm.principalHolder[propertyName].length === 10;
			}
			return false;
		}

		function loadNavigationListener(){
			$scope.$on('eventRefreshDataForNavigation', function (){
				$PCStateManagerService.setPolicyChangeData(vm.policyChangeData);
			});
		}

		function init(){
			loadNavigationListener();

			// ******* Analytics - [F6.2] Address page
			var props = {
				s_appStep : "pu:1",
				s_pageName: 'portfolio:policy update:address'
			};

			$PCAnalyticsService.trackPageView(props);
		}

	}
})(angular);
