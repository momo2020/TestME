(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:PCSidebarController
	 * @description
	 * Main controller
	 *
	 * @requires https://docs.angularjs.org/api/ng/service/$log
	 * @requires https://github.com/angular-ui/ui-router#$state
	 * @requires core/INTACT.Core.service:$CoreWindowService
	 * @requires INTACT.PolicyChange.service:$PCAppConfiguration
	 * @requires https://docs.angularjs.org/api/ng/filter/filter
	 */
	angular.module('INTACT.PolicyChange').controller('PCSidebarController', Controller);

	function Controller(DistributorData, 
						$PCAppConfiguration,
						$PCStateManagerService, 
						$IntactModalService, 
						$PolicyChange, 
						$PCAnalyticsService,
						$filter){
		var vm = this;
		vm.openScheduleCallDialog = openScheduleCallDialog;
		vm.fireAnalyticsLiveChatSubmit = fireAnalyticsLiveChatSubmit;

		var currentPage = $filter('getStep')($PolicyChange.$get().policyChange() ? $PolicyChange.$get().policyChange().state.currentPage: null, false);

		/**
		 * @ngdoc property
		 * @name INTACT.PolicyChange.controller:PCSidebarController#distributor
		 * @propertyOf INTACT.PolicyChange.controller:PCSidebarController
		 * @description
		 * Distributor data
		 * @returns {Object} Distributor data
		 */
		vm.distributor = DistributorData;
		
		/**
		 * @ngdoc property
		 * @name INTACT.PolicyChange.controller:PCSidebarController#isBrokerContextEnabled
		 * @propertyOf INTACT.PolicyChange.controller:PCSidebarController
		 * @description Indicates whether or not the broker information should be displayed
		 * @return {Boolean} Indicator
		 * */
		vm.isBrokerContextEnabled = $PCAppConfiguration.brokerContextEnabled;

		/**
		 * @ngdoc method
		 * @name INTACT.PolicyChange.controller:PCSidebarController#goToSelector
		 * @methodOf INTACT.PolicyChange.controller:PCSidebarController
		 * @description Redirect the user to the broker selector page
		 * */
		vm.goToSelector = function(){};

		/**
		 * @ngdoc method
		 * @name INTACT.PolicyChange.controller:PCSidebarController#openScheduleCallDialog
		 * @methodOf INTACT.PolicyChange.controller:PCSidebarController
		 * @description
		 * Calls private function to create a modal instance && open Schedule a Call modal dialog
		*/
		function openScheduleCallDialog(){
			$PCStateManagerService.showLoader();
		
			var scheduleCallModalOptions = {
				templateUrl: '/partials/schedule-call-dialog.html',
				controllerAs: 'scheduleCallCtrl',
				controller: 'ScheduleCallController'
			};

			fireAnalyticsScheduleCallInit();

			return $IntactModalService.modal(scheduleCallModalOptions).on('$ModalServiceClose', function(redirect){
				if(redirect){
					
				}
			});
		}

		function fireAnalyticsLiveChatSubmit(){
			var currentTag = $PolicyChange.$get().getPageNameTag()
			var props = {
				s_appStep: currentTag.s_step,
				s_btnName: "portofolio:click to chat",
				s_pageName: currentTag.s_pageName,
				s_pageState: "166-0-0"
			};
			$PCAnalyticsService.trackPageView(props);
		}

		function fireAnalyticsScheduleCallInit(){
			var props = {
				s_appStep: "pu:" + currentPage,
				s_pageName: 'portfolio:policy update:schedule a call initiated',
				s_pageState: "594-1-0"
			};
			$PCAnalyticsService.trackPageView(props);
		}

	}
})(angular);