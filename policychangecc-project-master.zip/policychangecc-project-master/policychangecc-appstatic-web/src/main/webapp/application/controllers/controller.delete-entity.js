(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pcDeleteEntityConfirmPanelControllerController
	 * @description
	 * Controller for deleting drivers or vehicles

	 */
	angular.module('INTACT.PolicyChange').controller('pcDeleteEntityConfirmPanelController', Controller);

	function Controller(modalContext, 
						close, 
						$PolicyChangeService, 
						$PCAnalyticsService, 
						$PCAppConfiguration,
						$PolicyChange, 
						$filter, 
						DriverModel){

		var vm = this,
			$translate = $filter('translate'),
			PolicyChangeData = $PolicyChange.$get().policyChange(),
			$modificationFilter = $filter('modificationCode'),
			$capitalize = $filter('pcCapitalize');
		
		var state = PolicyChangeData.state;

		if (state.currentPage === 'PC_CARS') {
			vm.title =  $translate('LBL42186.car.remove.title');
			vm.btnSuccess = $translate('LBL42190.car.remove.button');
			vm.text  = $translate('LBL42187.car.remove.are.you.sure', {
				MAKE : modalContext.entity.model.make,
				MODEL : modalContext.entity.model.model,
				YEAR : modalContext.entity.model.year
			});
		}
		else if (state.currentPage === 'PC_DRIVERS') {
			var driver = new DriverModel(modalContext.entity),
				firstname = $capitalize(driver.driver.firstName),
				lastname = $capitalize(driver.driver.lastName);
			vm.title =  $translate('LBL45882.driver.remove.title');
			vm.btnSuccess = $translate('LBL45884.driver.remove.button.confirm');
			vm.text = $translate('LBL45883.driver.remove.confirmation.text', {
				FIRSTNAME : firstname,
				LASTNAME : lastname
			});
		}

        vm.phoneNumber = $PCAppConfiguration.rdblckPhoneNumber;

		vm.btnCancel  = $translate('LBL40062.cancel.changes.dialogbox.footer');
		
		init();

		/**
		 * @ngdoc method
		 * @name INTACT.PolicyChange.controller:pcDeleteEntityConfirmPanelController#close
		 * @methodOf INTACT.PolicyChange.controller:pcDeleteEntityConfirmPanelController
		 *
		 * @description
		 * Close current modal opened ({@link https://github.com/dwmkerr/angular-modal-service cf. Module})
		 */
		vm.close = function(){
			$('body [lightbox-close]').addClass('animate-modal modal-hide').removeClass('show');
			$('body').removeClass('modal-opended');
			close(false, 200);
		};

		function updateModificationCode(entityType) {
			var codeRemoved = $translate('MODIFICATION.CODE.REMOVED');
			
			switch (entityType) {
				case 'vehicle': 
					PolicyChangeData.policyChange.vehicles[modalContext.entity.riskIndex].modificationCode = $modificationFilter(codeRemoved, PolicyChangeData.policyChange.vehicles[modalContext.entity.riskIndex].modificationCode);
					break;

				case 'driver': 
					PolicyChangeData.policyChange.drivers[modalContext.entity.driverIndex].modificationCode = $modificationFilter(codeRemoved, PolicyChangeData.policyChange.drivers[modalContext.entity.driverIndex].modificationCode);
					break;
			}
		}

		function getEntityType(entity) {
			var entityType = null;

			if (entity.hasOwnProperty('driverIndex')) {
				entityType = 'driver';
			} else if (entity.hasOwnProperty('model')) {
				entityType = 'vehicle';
			}

			return entityType;
		}

		/**
		 * @ngdoc method
		 * @name INTACT.PolicyChange.controller:pcDeleteEntityConfirmPanelController#delete
		 * @methodOf INTACT.PolicyChange.controller:pcDeleteEntityConfirmPanelController
		 *
		 * @description
		 * Gets initializationDTO object, puts update and
		 * close modal ({@link https://github.com/dwmkerr/angular-modal-service cf. Module})
		 */

		vm.onSuccess = function() {
			var entityType = getEntityType(modalContext.entity);

			if (entityType) {
				vm.waiting = true;

				updateModificationCode(entityType);
	
				$PolicyChangeService.put(PolicyChangeData.policyChange, {goto : null, ignoreErrors: true}).then(function () {
					close(true, 200);
					vm.waiting = false;
					modalContext.onSuccess();
			    })
			    .catch(function() {
			    	vm.waiting = false;
			        close(false, 200);
			    });
			}
		};

		function init() {
			vm.waiting = false;
			$PCAnalyticsService.trackPageView({
				s_pageName: 'pc:delete-entity'
			});
		}
	}

})(angular);
