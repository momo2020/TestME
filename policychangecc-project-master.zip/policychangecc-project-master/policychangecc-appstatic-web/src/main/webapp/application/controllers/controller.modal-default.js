(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:ModalDefaultController
	 * @description
	 * Controller to manage default behaviour for static soft road block modal popup
     * @requires close
	 */
	angular.module('INTACT.PolicyChange').controller('ModalDefaultController', Controller);

	function Controller(modalContext, 
						$PCAnalyticsService, 
						$PCAppConfiguration,
						close, 
						$scope,
						$filter){
		// bind modal props or methods here as inputs or scope are not passing through
		var self = this;

		self.title = modalContext.title;
		self.text  = modalContext.text;
		self.btnSuccess = modalContext.btnSuccess;
		self.btnCancel  = modalContext.btnCancel;
		self.bbTitle = modalContext.bbTitle;
		self.bbDesc = modalContext.bbDesc;
		self.showBlueBox = self.bbTitle !== undefined || self.bbDesc !== undefined;

		init();

		self.onSuccess = function(){
			$scope.onSuccess();
			close();
		};

		self.close = function() {
			$('body [lightbox-close]').addClass('animate-modal modal-hide').removeClass('show');
			$('body').removeClass('modal-opended');
			close(false, 200);
		};


        self.phoneNumber = $PCAppConfiguration.rdblckPhoneNumber;

		function init(){
			// ******* Analytics - Modal - Soft roadblock

			var props = {},
				renewalTitle = $filter('translate')('LBL45508.pc.renew.title');

			if(self.title.indexOf(renewalTitle) >= 0 ){
				props = {
					s_pageState : "",
					s_appStep : "pu:0",
					s_pageName : "portfolio:policy update:renewal warning"
				};
			}
			else{
				props = {
					s_pageState : "314-2-3",
					s_appStep: "pu:roadblock",
					s_reason: self.title,
					s_pageName: 'portfolio:policy update:soft roadblock'
				};
			}

			$PCAnalyticsService.trackPageView(props);
		}
	}

})(angular);
