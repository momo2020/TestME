(function(angular){
	'use strict';

	/**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:$PCAnalyticsService
     *
     * @description
     * Policy Change analytics Service
     * @example
     * <pre>
     * // In controller
     * MyModule.controller(function($PCAnalyticsService){
     * 		$PCAnalyticsService.tarckPageView({});
     * });
     * </pre>
     **/
	angular.module('INTACT.PolicyChange').service('$PCAnalyticsService', service);

	function service($AnalyticsService, $PolicyChange, $PCDistributorService, CONFIGURATION, $filter, $q, $log) {
		
		/**
		 * @description
		 * Get backend informations for tracking from client & distributor API Rest services
		 * @return {Object} AngularJs promise
		 */
		var getPageTrackingParams = function(){
			var deferred = $q.defer();

			$q.all([$PolicyChange.$get, $PCDistributorService.$get]).then(function(){
				/**
				 * Set global service data informations
				 */

			 	var config = CONFIGURATION;
				var lang = config.language;
				var province = config.province;

				var policyChange = $PolicyChange.$get().policyChange();

				var drivers = getDrivers(policyChange);
				var vehicles = getVehicles(policyChange);

				var countDrivers = drivers ? drivers.length: 0;
				var countVehicules = vehicles ? vehicles.length: 0;
				var clientProfile = countVehicules + "|" + countDrivers;

				var policyHolder = policyChange && policyChange.currentPolicy && policyChange.currentPolicy.policyHolders ? policyChange.currentPolicy.policyHolders[0]: null;
				var user = policyChange && policyChange.data && policyChange.data.response  && policyChange.data.response.user ? policyChange.data.response.user: null; 
				var sso = user ? user.clientId: null;
				var infoPerso = getLoggedInClientInfo(user);

				var helpPhone = $PCDistributorService.get().helpPhoneNumber;

				var driver_arr = [];
				var vehicle_arr = [];

				angular.forEach(drivers, function(val) {
					var date_of_bith = val.dateOfBirth;
					var gender = val.gender;

					var age = $filter('ageByDob')(date_of_bith);

					driver_arr.push({
						age: age ? age : null,
						gender: gender ? gender : null
					});
				});

				angular.forEach(vehicles, function(val) {
					var make = val.model.make ? val.model.make : null;
					var model = val.model.model ? val.model.model : null;
					var year = val.model.year ? val.model.year : null;

					vehicle_arr.push({
						make: make,
						model: model,
						year: year
					});
				});

				//fix for tagging on Initialization when policyChange is null
				if(driver_arr.length === 0){
					driver_arr = [{
						age: null,
						gender: null
					}];
				}

				/**
				 * Resolve promise
				 */
				deferred.resolve({
					sso: sso,
					infoPerso: infoPerso,
					lang: lang,
					clientProfile: clientProfile,
					province: province,
					helpPhone: helpPhone,
					policyHolder: policyHolder,
					driver_arr: driver_arr,
					vehicle_arr: vehicle_arr
				});
			}, function(err){
				deferred.reject(err);
			});

			return deferred.promise;
		};

		function getDrivers(policyChangeData){
			if(policyChangeData && policyChangeData.policyChange && policyChangeData.policyChange.drivers){
				return policyChangeData.policyChange.drivers;
			}
			return policyChangeData && policyChangeData.currentPolicy && policyChangeData.currentPolicy.drivers ? policyChangeData.currentPolicy.drivers: null;
		}

		function getLoggedInClientInfo(user){
			var policyChange = $PolicyChange.$get().policyChange();
			var policyHolderList = policyChange && policyChange.currentPolicy && policyChange.currentPolicy.policyHolders ? policyChange.currentPolicy.policyHolders: null;
			var loggedInPolicyHolder = _.find(policyHolderList, {firstName: user.firstName.toUpperCase(), lastName: user.lastName.toUpperCase()});

			if(loggedInPolicyHolder){
				var emailAddress = loggedInPolicyHolder.emailAddress ? loggedInPolicyHolder.emailAddress: "n/a";
				return loggedInPolicyHolder.lastName + " " + loggedInPolicyHolder.firstName + "|" + emailAddress + "|" + loggedInPolicyHolder.homePhoneNumber;
			}

			return  user.lastName + " " + user.firstName + "|n/a|n/a";
		}

		function getVehicles(policyChangeData){
			if(policyChangeData && policyChangeData.policyChange && policyChangeData.policyChange.vehicles){
				return policyChangeData.policyChange.vehicles;
			}
			return policyChangeData && policyChangeData.currentPolicy && policyChangeData.currentPolicy.vehicles ? policyChangeData.currentPolicy.vehicles: null;
		}

		/**
		 * @ngdoc method
		 * @name $AppAnalyticsService#trackPageView
		 * @methodOf INTACT.App.service:$AppAnalyticsService
		 *
		 * @description
		 * Track page view in Analytics Omniture
		 *
		 * @example
		 * <pre></pre>
		 */
		this.trackPageView = function(pageParams){
			getPageTrackingParams().then(function(infos){
				var params = angular.extend({}, {
					s_sso: infos.sso,
					s_infoPerso: infos.infoPerso,
					s_display_lang: infos.lang,
					s_clientProfile: infos.clientProfile,
					s_selected_province: infos.province,
					s_telephone: infos.helpPhone,
					s_quoteType : "car policy change",
					s_pc: infos.policyHolder && infos.policyHolder.address ? infos.policyHolder.address.postalCode : null,
					s_drivers: infos.driver_arr,
					s_vehicles: infos.vehicle_arr
				}, pageParams);

				if(params.s_pageName){
					$PolicyChange.updatePageNameTag({s_step: params.s_appStep , s_pageName: params.s_pageName});
				}

				$AnalyticsService.trackPageView(params);
			}, function(){
				$log.warn('Analytics service error : params access impossible !');
			});
		};


		/**
		 * @ngdoc method
		 * @name $AppAnalyticsService#trackError
		 * @methodOf INTACT.App.service:$AppAnalyticsService
		 *
		 * @description
		 * Track an error in Analytics Omniture
		 *
		 * @example
		 * <pre></pre>
		 */
		this.trackError = function(error){
			$AnalyticsService.trackError('bd:portfolio:' + error);
		};
	}

})(angular);
