(function(angular){
	'use strict';

    /**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:$AffinityGroupsService
     *
     * @description
     * Affinity Groups Service
     * @example
     * <pre>
     * // In controller
     * MyModule.controller(function($AffinityGroupsService){
     *
     *  });
     * });
     * </pre>
     *
     **/

     angular.module('INTACT.PolicyChange').service('$AffinityGroupsService', service);

     function service(	$PCCoreService,
     					$PCAppConfiguration,
     					$q ){

     	return {
     		get : get
     	};

     	function get (effectiveDate){
     		var deferred = $q.defer();

     		$PCCoreService.get('/misc/affinityGroups/' + effectiveDate, {cache : 'policychange', cacheDisabled : true})
     			.then(function(r){
     				if(r.data){
     					deferred.resolve(r.data);
     				}
     				else{
     					deferred.reject();
     				}
     			}, function(e){
     				deferred.reject(e);
     			});
     			
     		return deferred.promise;
     	}
     }

})(angular);