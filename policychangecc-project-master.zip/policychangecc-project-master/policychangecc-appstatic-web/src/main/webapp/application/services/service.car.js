(function(angular){
	'use strict';


	/**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:carService
     *
     * @description
     * Policy car service Service
     * @example
     * <pre>
     * // In controller
     * MyModule.controller(function(carService){possible strict violation
     *
     * });
     * </pre>
     **/
	angular.module('INTACT.PolicyChange').service('carService', service);

		function service($log, $PCCoreService, $InitializationService, $filter) {
			var cacheObj = {},
				url = '';

			return {
				getSelectList : getSelectList,
				getSelectValues : getSelectValues,
				getCarModelLabel : getCarModelLabel,
				setOptions : setOptions
			};

			function getCarModelLabel(vehicleCode, modelOptions) {
				vehicleCode = String(vehicleCode);
			 	return modelOptions.filter( function(item) {
					if (item.key === vehicleCode) {
						return item;
					}
				})[0].value;
			}

            function getSelectValues(cnfg) {
				var force = cnfg.force || false,
					select = cnfg.car[cnfg.selectName + 'Options'];

				if (!force && select && select.length) {
					return;
				}

				var isValidYear  = cnfg.year.length > 0,
					isValidMake  = cnfg.selectName === 'make' || cnfg.make.length > 0,
					isValidModel = cnfg.selectName === 'model';

				var yearCnfgObj = {vehiclesYearMax: cnfg.ddOptions.vehiclesYearMax, vehiclesYearMin : cnfg.ddOptions.vehiclesYearMin};

				if (cnfg.selectName === 'year') {
						var list = getSelectList('year', null, null, yearCnfgObj);
						setOptions(list, cnfg);
				} else if ((isValidYear && isValidMake) && !isValidModel) {
						getSelectList(cnfg.selectName, cnfg.year, cnfg.make, yearCnfgObj).then(function(list) {
							setOptions(list, cnfg);
						});
				} else if (isValidYear && isValidMake) {
					getSelectList('model', cnfg.year, cnfg.make).then(function(list) {
						setOptions(list, cnfg);
					});
				}  else {
					$log.warn('Could not load selector:' + cnfg.selectName +'. Invalid vehicule model values');
				}
			}

			function setOptions(list, cnfg) {
				cnfg.ddOptions[cnfg.selectName + 'Options'] = list;

				// copy original for reset;
				if (!cnfg.ddOptions[cnfg.selectName + 'OptionsOriginal']) {
					cnfg.ddOptions[cnfg.selectName + 'OptionsOriginal'] = list;
				}
			}

			function getSelectList(selectName, year, make, yearCnfgObj) {

				switch(selectName) {
					case 'year':
							var state = yearCnfgObj,
							yearList = [],
							yearSpan = (state.vehiclesYearMax - state.vehiclesYearMin),
							vehiclesYearMax = state.vehiclesYearMax,
							_year = vehiclesYearMax;

							for (var i = 0; i <= yearSpan; i++) {
								yearList.push({ 'value': String(_year), 'key': String(_year) });
								_year--;
							}

							yearList.unshift({
								key : '',
								value : $filter('translate')('LBLXXXX.car.select')
							});

							return yearList;
					case 'make':
					 	cacheObj = {cache: year+make,
					 				placeHolders : {
					 					year : year
					 				}};
						url = '/vehicles/:year/makes';

						return $PCCoreService.get(url, cacheObj).then(function(r){
			                if (r.data) {
			                	var makeList = [];
			                	var popularTitle = $filter('translate')('LBL34568.car.most.popular');
			                	var allTitle = $filter('translate')('LBLXXXX.car.all.makes');
			                	angular.forEach(r.data.popular, function(key, value){
			                		makeList.push({
			                			'key' : key,
			                			'value' : value,
			                			'group' : popularTitle
			                		});
			                		
			                	});
			                	angular.forEach(r.data.all, function(key, value){
			                		makeList.push({
			                			'key' : key,
			                			'value' : value,
			                			'group' : allTitle
			                		});
			                	});
			                	makeList.unshift({
			                		key : '',
			                		value : $filter('translate')('LBLXXXX.car.select')
			                	});

			                	return makeList;
			                } else {
			                    $log.warn('carService Make: response.data is missing');
			                }
			            });

					case 'model':
						cacheObj = {cache: year+make+'models',
									placeHolders : {
										year : year,
										make : make
									}};
						url = '/vehicles/:year/:make/models';

						return $PCCoreService.get(url, cacheObj).then(function(r){
							if (r.data) {
								var modelList = [];
								angular.forEach(r.data, function(key, value) {
									modelList.push({'key': value, 'value': key});
			                	});

			                	modelList = $filter('orderBy')(modelList, 'value');
			                	modelList.unshift({
			                		key : '',
			                		value : $filter('translate')('LBLXXXX.car.select')
			                	});

								return modelList;

							} else {
			                    $log.warn('carService Model: response.data is missing');
				            }
			            });

					default:
					 	break;
				}
			}
	}
})(angular);
