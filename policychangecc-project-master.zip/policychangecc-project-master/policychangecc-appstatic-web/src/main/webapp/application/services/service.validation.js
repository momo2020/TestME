(function(angular){
	'use strict';

	/**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:$PCValidationService
     *
     * @description
     * Service that verifies if the previous state was valid 
     * Applicable on complete pages or form - not inline validation
     * @example
     * 
     **/

	angular.module('INTACT.PolicyChange').service('$PCValidationService', service);

	function service ($state, $rootScope, $log,  $filter){

          this.validatePage = function(validationDTO){
               if(validationDTO.length){
                    //console.log(validationDTO);
               }
               else{
                    $log.warn("INTACT.PolicyChange.$PCValidationService DTO is empty");
               }
               return true;
          };

          this.getRoadblocks = function(rdblcks, type){
            var rdblcksList = [];
            angular.forEach($filter('filter')(rdblcks, { type : type }), function(error){
                rdblcksList.push(error);
            });
            return rdblcksList;
          };

     }
})(angular);