(function(angular) {
	'use strict';

	/**
	 * @ngdoc service
	 * @name INTACT.PolicyChange.service:$PCStateManagerService
	 *
	 * @description
	 * UI router state manager
	 * @example
	 * 
	 **/ 
	angular.module('INTACT.PolicyChange').service('$PCStateManagerService', service);

	function service($state, 
					$rootScope, 
					$IntactModalService, 
					$PCAppConfiguration,
					$PCAnalyticsService, 
					$window,
					$log,
					$filter,
					$timeout,
                    $location) {
		var PolicyChangeData = {};
		var rootPath = $PCAppConfiguration.rootPath;

		return {
			goToPage 						: goToPage,
			openCancelPolicyChangesDialog	: openCancelPolicyChangesDialog,
			validStateOrRedirect			: validStateOrRedirect,
			openDialog 						: openDialog,
			isDifferentPage 				: isDifferentPage,
			PolicyChangeData 				: PolicyChangeData,
			setPolicyChangeData 			: setPolicyChangeData,
			getPolicyChangeData 			: getPolicyChangeData,
			redirectToCC					: redirectToCC,
			getPageOpeningMode 				: getPageOpeningMode,
			gotoErrorPage					: gotoErrorPage,
			goToConcurrencyRdblk			: goToConcurrencyRdblk,
			goToHardRoadBlock				: goToHardRoadBlock,
			hideLoader						: hideLoader,
			showLoader						: showLoader
		};
		
        function showLoader() {
            $rootScope.$emit('showLoader');
        }

        function hideLoader() {
            $rootScope.$emit('hideLoader');
        }

		function setPolicyChangeData(data) {
			PolicyChangeData = data;
		}

		function getPolicyChangeData() {
			return PolicyChangeData;
		}

		function getPageOpeningMode (state){
			var currentPage 	= $rootScope.helpers.state.currentPage.data.page,
				pages 			= state.pages,
				myPage			= $filter('filter')(pages, {type : currentPage})[0],
				openingMode 	=  myPage ? myPage.pageOpeningModeEnum : null;

			return openingMode;
		}

		/**
		 * @ngdoc method
		 * @name $PCStateManagerService#getCurrentState
		 * @methodOf INTACT.PolicyChange.service:$PCStateManagerService
		 * @param {String} pageName 
		 * @description
		 * Returns UI router state according to provided currentPage name
		 */
		function getCurrentState(pageName) {
			/**
			 * @ngdoc variable
			 * @description
			 * fetches UI router routes states in array
			 */
			var _availableStates = $state.get().filter(function(state) {
				return (!state.abstract && state.data) ? true : false;
			});

			return _availableStates.filter(function(state) {
				return state.data.page === pageName;
			})[0];
		}

		function isDifferentPage(serverState){
			if(serverState && Object.keys(serverState).length !== 0){
				var serverPage = serverState.currentPage;
				if($rootScope.helpers.state.currentPage){
					var currentUiPage = $rootScope.helpers.state.currentPage.data.page;
					if(currentUiPage && (serverPage === currentUiPage)){
						return false;
					}
				}
				return true;
			}
			else{
				return false;
			}
		}

		/**
		 * @ngdoc method
		 * @name $PCStateManagerService#validStateOrRedirect
		 * @methodOf INTACT.PolicyChange.service:$PCStateManagerService
		 * @param {String} serverState current page from server stateMachine
		 * @description
		 * Redirects to instructed currentState when server state is different from UI currentPage
		 */

		function validStateOrRedirect(serverState) {

			var toState = serverState.currentPage;
			if ($rootScope.helpers.state.currentPage) {
				var uiState = $rootScope.helpers.state.currentPage.data.page;
				if (uiState && (toState !== uiState)) {
					var currentState = getCurrentState(toState);

					if(currentState){
						$state.go(currentState);
					}
					else {
						// you should be in taskboard
						// TODO:  why is this called twice
						$log.warn('There is no current state coming back from stateService');
					}
				}
			}
			return true;
		}

		/**
		 * @ngdoc method
		 * @name $PCStateManagerService#goToPage
		 * @methodOf INTACT.PolicyChange.service:$PCStateManagerService
		 * @param {String} toState current state to redirect to 
		 * @param {String} policyNumber policyNumber
		 * @description
		 * Redirect to instructed page after server response. Set UI $state currenTpage
		 */

		function goToPage(policyNumber, cnfg) {
			var stateName = getCurrentState(cnfg.goto);

			var stateParams = {
				id: policyNumber,
				goTo: cnfg.goto
			};

			$state.go(stateName, stateParams);
		}

		function goToConcurrencyRdblk(){
			var message = [$filter('translate')('LBL450533.concurrency')];
			// Concurrency error. Show Soft Roadblock and reload page
			var modalOptions = {
			    templateUrl: '/directives/modal-soft-roadblock.html',
			    controller: 'ModalSoftRoadBlockController', // TODO: Try to use a common controller when display modal popups (We created another controller for pcPopupWindow as well. Avoid code duplication)
			    controllerAs: "$ctrl",
			    resolve: {
			        messages: message,
			        brNumbers : 'concurrency'
			    }
			};

			$IntactModalService.modal(modalOptions).on('$ModalServiceClose', function(){
			    $window.location.reload();
			});
		}

		function goToHardRoadBlock(errorContext){
			$state.go(errorContext.hardRoadBlockState, {errors: errorContext.errors});
		}

        function gotoErrorPage(error) {

        	//TODO: Quand tous les services seront rattachés au Core PCH, 
        	//		il faudra enlever la partie if() au complet, car géré 
        	//		dans une nouvelle méthode
        	if(error.status === 403){
        	    var message = [$filter('translate')('LBL450533.concurrency')];
        	    // Concurrency error. Show Soft Roadblock and reload page
        	    var modalOptions = {
        	        templateUrl: '/directives/modal-soft-roadblock.html',
        	        controller: 'ModalSoftRoadBlockController', // TODO: Try to use a common controller when display modal popups (We created another controller for pcPopupWindow as well. Avoid code duplication)
        	        controllerAs: "$ctrl",
        	        resolve: {
        	            messages: message,
			        	brNumbers : 'concurrency'
        	        }
        	    };

        	    $IntactModalService.modal(modalOptions).on('$ModalServiceClose', function(){
        	        $window.location.reload();
        	    });
        	}
        	else{
	            // Call has been rejected, go to error 500 page
	            $timeout(function(){
	                var urlParams = document.location.search;
	                var errorPath = rootPath + '/500' + urlParams;
	                $location.path(errorPath);
	                $location.replace();
	            }, 10);

	            // ******* Analytics - [F6.11] Error Screen page (error 500, technical error)
                var props = {
                    s_appStep: "pu:error",
                    s_pageName: "portfolio:policy update:technical error",
                    s_pageState: "314-2-4",
                    s_reason: error.statusText
    			};

    			$PCAnalyticsService.trackPageView(props);
	        }
        }		

		function redirectToCC() {
			var url  = $PCAppConfiguration.clientCentreUrl;
			$window.location.assign(url);
		}

		function openCancelPolicyChangesDialog(cnfg) {
			/**
			 * Cancel changes Modal service options
			 * @type {Object}
			 */
			var cancelChangesModalOptions = {
				templateUrl: cnfg.templateUrl,
				controllerAs: cnfg.controllerAs,
				controller: cnfg.controller,
				target: 'PC_START',
				policyNumber: cnfg.policyNumber
			};

			return openDialog(cancelChangesModalOptions);
		}

		/**
		 * @ngdoc function
		 * @name openDialog
		 * @methodOf INTACT.PolicyChange.controller:NavigationButtonsController
		 *
		 * @params {Object} modalOptions Contains template URL, Controller and ControllerAs references
		 * @description
		 * Create instance && open the save and quit modal,
		 * Will redirect to target location on model close event: $ModalServiceClose
		 * Will console warn targetMessage otherwise 
		 */
		function openDialog(modalOptions) {
			return $IntactModalService.modal(modalOptions).on('$ModalServiceClose', function(redirect) {
				if (redirect) {
					switch (modalOptions.target) {
						case 'PC_START':
							goToPage(modalOptions.policyNumber, {
								goto: modalOptions.target
							});
							break;

						default:
							redirectToCC();
					}
				}
			});
		}
	}

})(angular);