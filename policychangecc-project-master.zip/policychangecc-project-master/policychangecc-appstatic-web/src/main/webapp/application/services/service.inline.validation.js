(function(angular){
    'use strict';

    /**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:$InlineValidationService
     *
     * @description
     * Inline Field Validation Service
     * @example
     * <pre>
     * // In controller
     *  MyModule.controller(function($InlineValidationService){
     * });
     * });
     * </pre>
     *
     **/
    angular.module('INTACT.PolicyChange').service('$InlineValidationService', service);

    function service( $log, 
                      $PCAppConfiguration, 
                      $timeout, 
                      $PCAnalyticsService, 
                      $PolicyChange, 
                      ValidationModel, 
                      $DebugButtonService, 
                      $filter, 
                      $rootScope, 
                      $IntactModalService) {
        /**
         * @ngdoc method
         * @name $InlineValidationService#get
         * @methodOf INTACT.PolicyChange.service:$InlineValidationService
         * @param {String} field field name attribute value
         * @param {String} value field value
         * @param {Number} index Entity item index
         * @description
         * Get validation field validation from server
         * @return {Object} AngularJs Promise
         */

        return {
            triggerValidation: triggerValidation,
            triggerSoftRoadBlockValidation  : triggerSoftRoadBlockValidation,
            scrollTo : scrollTo
        };

        function scrollTo(errors) {
            var delay = 500;
            $timeout( function() {
                var topElementPos = 0;
                var threshold = 60;
                
                angular.forEach(errors, function(error) {
                    var el = angular.element('[name^='+error.field+']')[0];
                    if (el) {
                        var pos = el.getBoundingClientRect().top;

                        var toTop = Number(pos.toString().replace('-',''));
                        if (topElementPos === 0) {
                            topElementPos = toTop - threshold;
                        }
                        else if (toTop < topElementPos) {
                            topElementPos = toTop - threshold;
                        }
                    }
                });

                
                if (topElementPos) {
                    angular.element('body').animate({
                        scrollTop: topElementPos
                    }, delay);
                }   
            }, delay);
        }

        function triggerSoftRoadBlockValidation(rdblks){ 

            //set the roadblock code if in debug mode
            var debugEnabled = $DebugButtonService.isDebugEnabled();
            //Prepare message for the roadblock
            var messages = [];
            //Analytics
            var brNumbers = "";
            if(rdblks){
              angular.forEach(rdblks, function(value) {
                var message = debugEnabled ? value.code + ' - ' + value.message : value.message;
                messages.push(message);
                //analytics
                brNumbers = brNumbers !== '' ? brNumbers + '/' + value.code : value.code;
              });
            }

            var modalOptions = {
                templateUrl: '/directives/modal-soft-roadblock.html',
                controller: 'ModalSoftRoadBlockController', // TODO: Try to use a common controller when display modal popups (We created another controller for pcPopupWindow as well. Avoid code duplication)
                controllerAs: "$ctrl",
                resolve: {
                    messages: messages,
                    brNumbers: brNumbers
                }
            };

            return $IntactModalService.modal(modalOptions);

        }

        function triggerValidation(validationResponse) {

            var message = "";
            var formError = "";

            $rootScope.$broadcast('validationChanged', validationResponse);

            validationResponse.forEach( function(validationMessage, key) {
                if (validationMessage.elementIndex === null){
                    // Backend will return elementIndex = null when we do not validate list of objects (ChangeAddress page)
                    validationMessage.elementIndex = 0;
                }

                var eventFieldValidation = 'customFieldValidation' + validationMessage.elementIndex.toString();
                $rootScope.$broadcast(eventFieldValidation, validationMessage);

                // ------------------------------
                // Will need to be placed in the future to the upcoming component specifically for the validation.
                // @ref: Simon Désielts
                formError = validationMessage.field + ":" + validationMessage.message;
                message += key !== 0 ? "," + formError : formError;
                // ------------------------------
            });

            analyticsValidation(message);
        }

        // ------------------------------
        // Will need to be placed in the future to the upcoming component specifically for the validation.
        // @ref: Simon Désielts
        function analyticsValidation(message) {

            var PolicyChangeData = $PolicyChange.$get().policyChange();
            var currentPage = PolicyChangeData.state.currentPage;
            var currentTask = PolicyChangeData.state.tasks[0];
            var currentAction = "";

            var currentPagePosition = $filter('getStep')(currentPage);
            var currentPageName = $filter('getStep')(currentPage, true);

            if(currentTask === "PC_UPDATE_CARS" || currentTask === "PC_UPDATE_DRIVERS") {
                currentAction = ":update started";
            }

            // ******* Analytics - [F6.11] Error Screen page (form errors)
			var props = {
                s_pageName: "portfolio:policy update:" + currentPageName,
                s_appStep: "pu:" + currentPagePosition + currentAction,
                s_pageState: "",
				s_formErrors: message,
			};

			$PCAnalyticsService.trackPageView(props);
        }
        // ------------------------------
    }
})(angular);
