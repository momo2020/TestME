(function(angular){
    'use strict';

    /**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:$ToasterService
     *
     * @description
     * Inline Field Validation Service
     * @example
     * <pre>
     * // In controller
     *  MyModule.controller(function($pcToasterService){
            $pcToasterService.notifyToaster(r.data.validation.warnings);
     * });
     * });
     * </pre>
     *
     **/
    angular.module('INTACT.PolicyChange').service('$pcToasterService', service);

    function service($rootScope, $filter) {

        return {
            notifyToaster: notifyToaster
        };

        function showToast(data) {
            $rootScope.$broadcast('pcShowToast', data);
        }

        function hideToast() {
            $rootScope.$broadcast('pcHideToast');
        }

        function notifyToaster(warnings, pcVehicles) {
            var hasWarnings = warnings && warnings.length ? true : false; 

              if(hasWarnings) {
                var substitutions = pcVehicles ? $filter('filter')(pcVehicles, {modificationCode : 'U'}).length > 0 : false;

                // pass pcVehicles shows substitutions only when comming from car page
                if (pcVehicles && !substitutions) {
                    return false;
                }
                else if (pcVehicles && substitutions) {
                    showToast({ 
                        'warnings': warnings,
                        'pcVehicles' : pcVehicles
                    });
                }
                else {
                    showToast({ 
                        'warnings': warnings
                    });
                }
                
            } else {
                hideToast();
            } 
        }
    }
})(angular);
