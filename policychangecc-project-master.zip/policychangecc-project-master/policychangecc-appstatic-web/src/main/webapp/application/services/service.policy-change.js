(function(angular){
    'use strict';

    /**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:$PolicyChangeService
     *
     * @description
     * Policy Change Service
     * @example
     * <pre>
     * // In controller
     * MyModule.controller(function($PolicyChangeService){
     *
     *  });
     * });
     * </pre>
     *
     **/
    angular.module('INTACT.PolicyChange').service('$PolicyChangeService', service);

    function service(PolicyChangeModel,
                    $PCCoreService,
                    $PCAnalyticsService,
                    $PCAppConfiguration,
                    $PCStateManagerService,
                    $filter,
                    $rootScope,
                    $log,
                    $q,
                    $PolicyChange,
                    $PolicyChangeState) {

        var policyNumber = $PCAppConfiguration.policyNumber,
            url = '/policy',
            cacheObj = {cache: 'policychange',
                        cacheDisabled: true};

        return {
            put         : put,
            cancel      : cancel,
            get         : get,
            updateState : updateState
        };

          /**
         * @ngdoc method
         * @name $PolicyChangeService#updateState
         * @methodOf INTACT.PolicyChange.service:$PolicyChangeService
         *
         * @description
         * Call updateState
         * @return {Object} AngularJs Promise
         */

        function updateState(cnfg){
            var options = {
                    cache : 'policychange',
                    cacheDisabled: true,
                    headers: {'If-Match': $PolicyChange.$get().getTimeStamp()}
                };

                var toUpdate = cnfg.toUpdate;

                $PCCoreService.put(url+"/updateState", toUpdate, options).then(function(r) {
                	$PolicyChangeState.update(r.data);
                });
        }

         /**
         * @ngdoc method
         * @name $PolicyChangeService#get
         * @methodOf INTACT.PolicyChange.service:$PolicyChangeService
         *
         * @description
         * Get distribution information from REST API
         * @return {Object} AngularJs Promise
         */
        function get(gotoPage){
            var deferred = $q.defer();

            var options =  {
                cache: 'policychange',
                cacheDisabled: true,
                params: {
                    goto : gotoPage
                }
            };

           $PCStateManagerService.showLoader();

           $PCCoreService.get(url +"/"+ policyNumber, options)
            .then(function(r){
                resolvePromise(deferred, r);
            }, function(e){
                deferred.reject(e);
            });

           return deferred.promise;
        }


         /**
         * @ngdoc method
         * @name $PolicyChangeService#put
         * @methodOf INTACT.PolicyChange.service:$PolicyChangeService
         *
         * @param {object} PolicyChangeModel Object
         * @description
         * Put distribution information from REST API
         * @return {Object} AngularJs Promise
         */

        function put(policyChange, cnfg) {
            var params = updateParams(cnfg);
            var deferred = $q.defer();
            var options = {
                cache : 'policychange',
                cacheDisabled: true,
                params: params,
                headers: {'If-Match': $PolicyChange.$get().getTimeStamp()}
            };

            $PCStateManagerService.showLoader();

            $PCCoreService.put(url +"/" + policyNumber +"/policychange", policyChange, options)
            .then(function(r){
                resolvePromise(deferred, r);
            }, function(e){
                deferred.reject(e);
            });

            return deferred.promise;
        }

         /**
         * @ngdoc method
         * @name $PolicyChangeService#cancel
         * @methodOf INTACT.PolicyChange.service:$PolicyChangeService
         *
         * @description
         * Delete distribution information from REST API
         * @return {Object} AngularJs Promise
         */
        function cancel(policyChange) {
            return $PCCoreService.delete(url +"/"+ policyNumber+"/policychange", policyChange, cacheObj)
            .catch(function(error){
                $PCStateManagerService.gotoErrorPage(error);
            });
        }

        // Private Functions
        function resolvePromise(deferred, r){
            saveData(r);
            setPromise(r, deferred);
        }

        function setPromise(r, deferred){
            var data = r.data || {},
                state = data.state || {};

            if(state && $PCStateManagerService.validStateOrRedirect(state)){
                var policyChangeModel = new PolicyChangeModel(data);
                deferred.resolve(policyChangeModel);
            }

            $PCStateManagerService.hideLoader();
        }

        function saveData(r){
            // Update the new policy change provider
            var pcModel = new PolicyChangeModel(r.data);

            $PolicyChange.update(pcModel);
            $PolicyChangeState.update(pcModel.state);
        }

        function updateParams(cnfg){
            var params = {};
            if (!angular.isUndefined(cnfg) && !angular.isUndefined(cnfg.goto)){
                params.goto = cnfg.goto;
            }
            if (!angular.isUndefined(cnfg) && !angular.isUndefined(cnfg.ignoreErrors)){
                params.ignoreErrors = cnfg.ignoreErrors;
            }
            return params;
        }
    }
})(angular);
