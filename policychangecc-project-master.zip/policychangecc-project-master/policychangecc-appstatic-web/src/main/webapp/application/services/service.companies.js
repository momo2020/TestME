(function(angular){
	'use strict';

	/**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:$CompaniesService
     *
     * @description
     * Companies service provides Financing And Location companies from the back-end
     * @example
     * <pre>
     * // In controller
     * MyModule.controller(function($CompaniesService){
     * 		
     * 	});
     * });
     * </pre>
     * 
     **/
	angular.module('INTACT.PolicyChange').service('$CompaniesService', service);
	
	function service($q, $PCCoreService, $PCAppConfiguration, CompaniesModel, $filter, $log) {
		
        /**
         * @ngdoc method
         * @name $InitializationService#getFinancingCompanies
         * @methodOf INTACT.PolicyChange.service:$CompaniesService
         * @description
         * Get Financing Companies
         * @return {Object} AngularJs Promise
         */
        this.getFinancingCompanies = function() {
            var url = "/misc/financingCompanies",
                deferred = $q.defer();
            $PCCoreService.get(url, {cache: 'policychange-financingcie'}).then(function(r){
                if (r.data) {
                   deferred.resolve(new CompaniesModel(r.data));
                } else {
                   deferred.reject($log.warn('CompaniesService : response.data is missing')) ;
                }
            }, function(e){
                deferred.reject(e);
            });

            return deferred.promise; 
    	}; 

         /**
         * @ngdoc method
         * @name $InitializationService#getLocationCompanies
         * @methodOf INTACT.PolicyChange.service:$CompaniesService
         * @description
         * Get Location Companies
         * @return {Object} AngularJs Promise
         */
        this.getLocationCompanies = function() {
            var url = "/misc/lessorCompanies",
                deferred = $q.defer();
            
            $PCCoreService.get(url, {cache: 'policychange-lessorcie'}).then(function(r){
                if (r.data) {
                   deferred.resolve(new CompaniesModel(r.data));
                } else {
                   deferred.reject($log.warn('CompaniesService : response.data is missing')) ;
                }
            }, function(e){
                deferred.reject(e);
            });

            return deferred.promise; 
        }; 
      
        
	}
})(angular);