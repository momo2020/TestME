(function(angular){
	'use strict';


	/**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:mapper
     *
     * @description
     * Get, Set Mapping Service
     * @example
     * <pre>
     * // In controller
     *
     *
     * });
     * </pre>
     **/
	angular.module('INTACT.PolicyChange').service('mapperDataService', service);

		function service($PolicyChangeService, $filter, $q, $log) {

			var policyChangeData = {};

			return {
				getPrincipalHolder : getPrincipalHolder,
				savePrincipalHolder : savePrincipalHolder,
				getCurrentPrincipalHolder : getCurrentPrincipalHolder
			};

			function getPrincipalHolder(_policyChangeData) {
				policyChangeData = _policyChangeData;
				var policyHolderList =  policyChangeData.policyChange.policyHolders;
				var principalHolder = $filter("filter")(policyHolderList, {type:'P'})[0];
				
				return principalHolder;
			}

			function setPrincipalHolder(updatedPrincipalHolder) {
				var policyHolderList =  policyChangeData.policyChange.policyHolders;
				$filter("filter")(policyHolderList, {type:'P'})[0] = updatedPrincipalHolder;
			}

			function getCurrentPrincipalHolder(_policyChangeData) {
				var currentPolicy = _policyChangeData.PolicyChangeData.currentPolicy;

				var policyHolderList =  currentPolicy.policyHolders;
				if(policyHolderList){
					var currentPrincipalHolder = $filter("filter")(policyHolderList, {type:'P'})[0];
					return currentPrincipalHolder;
				}

				return null;
			}

			function savePrincipalHolder(principalHolder){
				var deferred = $q.defer();
				setPrincipalHolder(principalHolder);

				$PolicyChangeService.put(policyChangeData.policyChange).then( function(data) {

					principalHolder = getPrincipalHolder(data);
					deferred.resolve(principalHolder);

				}, function(){

                    $log.warn('PolicyChangeService : response.data is missing');
                    deferred.reject();

                });

                return deferred.promise;
			}

	}
})(angular);
