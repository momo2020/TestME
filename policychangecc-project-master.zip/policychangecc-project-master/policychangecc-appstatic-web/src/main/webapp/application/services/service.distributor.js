(function(angular){
	'use strict';

	angular.module('INTACT.PolicyChange').service('$PCDistributorService', service);
	
	function service(DistributorsModel, $PCAppConfiguration) {
		
		this.get = function(){

           var data = new DistributorsModel({
            	helpPhoneNumber : $PCAppConfiguration.pchPhoneNumber,
            	openingHourMondayToFriday : $PCAppConfiguration.openingHourMondayToFriday ,
            	openingHourSaturday : $PCAppConfiguration.openingHourSaturday ,
            	closingHourMondayToFriday : $PCAppConfiguration.closingHourMondayToFriday ,
            	closingHourSaturday : $PCAppConfiguration.closingHourSaturday,
            	emergencyClaimsServicePhoneNumber: $PCAppConfiguration.claimsPhoneNumber
            });

            return data;
    	};
	}
})(angular);

