(function(angular){
	'use strict';

	angular.module('INTACT.PolicyChange').service('$PCCoreService', service);

	function service( $filter,
					  $CoreRestApiService,
					  $PolicyChange,
					  $PolicyChangeState,
					  PolicyChangeModel,
                      $InlineValidationService,
					  $PCStateManagerService,
					  $PCValidationService,
					  $PolicyChangeValidation,
					  $rootScope,
					  $q){

		/**
		*	JUST FOR POC
		*	TODO ENLEVER APRES
		*/
		var nv3YesNbdNo33eNo = {"response":{"effectiveDate":"2017-11-06","expiryDate":"2017-04-26","policyNumber":"E03-8036","underwriterName":null,"policyStatus":"ACTIVE","drivers":[{"sequence":1,"dateOfBirth":"1958-01-24","firstName":"CRD-DCL","gender":"F","lastName":"TEST-LGXHTKOBK","licenceNumber":"T123424015807","policyHolder":true,"maritalStatus":"F","relationshipToPolicyHolder":null,"fullTimeStudent":false,"permanentAddress":false,"retired":false,"driverLicenceClass":null,"licenceObtentionDate":"2012-07-01","g2LicenceDate":null,"modificationCode":null,"school100KmFromParent":null,"priorCarrierCancelled":false,"priorCarrier":null,"priorCarrierPolicyNumber":null,"driverLicenceType":"R","driverTrainingCourse":true,"drivingSchool":null,"trainingCertificateNumber":null,"obtainedG2OrG":null,"obtainedG2OrGDisplayed":null,"ageGotLicence":54,"infractionsPast3Years":false,"convictionsCount":null,"penaltyPointsAmount":null,"minorInfractionCount":0,"majorInfractionCount":null,"severeInfractionCount":0,"majorInfraction":false,"lossesYears":false,"claims":null,"driverIndex":0,"licenseRevoked":false,"workSector":null,"occupation":null,"monthNotLivingParent":null,"universityDiploma":null,"cancelledPolicyReason":null,"principalDriverSince":"36","convictions":null,"criminalRecord":null}],"policyHolders":[{"partyId":1000800736,"dateOfBirth":"1958-01-24","emailAddress":null,"firstName":"CRD-DCL","lastName":"TEST-LGXHTKOBK","maritalStatus":null,"gender":null,"homePhoneNumber":"4181712255","homePhoneExtension":null,"businessPhoneNumber":"4189575240","businessPhoneExtension":null,"address":{"civicNumber":"6187","apartment":null,"streetName":"OT DE LA EMJXRIYZD","streetDirection":null,"streetType":null,"floor":null,"poBox":null,"poStation":null,"ruralRouteNumber":null,"municipality":"LEVIS","province":"QC","postalCode":"G6X3B7","unstructuredAddressLine1":"6187, DE LA EMJXRIYZD","unstructuredAddressLine2":null,"unstructuredAddressLine3":null,"municipalityCode":"216000"},"type":"P"}],"vehicles":[{"sequenceNumber":1,"riskIndex":0,"coverages":[{"code":"A","productCode":"A","description":"Civil liability","selected":true,"section":"Coverage","type":"LIMIT_AMOUNT","sectionCode":"1","selectedAmount":1000000.0,"sequence":100.0,"values":[{"amount":1000000.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"B2","productCode":"B2","description":"Collision and upset","selected":true,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":500.0,"sequence":400.0,"values":[{"amount":500.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"B3","productCode":"B3","description":"All perils other than collision or upset","selected":true,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":250.0,"sequence":500.0,"values":[{"amount":250.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"P1","productCode":"P1","description":"Accident benefits","selected":true,"section":"Coverage","type":"LIMIT_MUTIL_DEATH_AMOUNT","sectionCode":"1","selectedAmount":15000.0,"sequence":800.0,"values":[{"amount":15000.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"P2","productCode":"P2","description":"Accident benefits","selected":true,"section":"Hidden","type":"DEDUCTIBLE_AMOUNT","sectionCode":"7","selectedAmount":null,"sequence":810.0,"values":[{"amount":null,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"I90","productCode":"I90","description":"Autocomfort","selected":true,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1000.0,"values":[{"amount":null,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"NV3","productCode":"NV3","description":"Package","selected":true,"type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1008.0,"values":[{"amount":null,"sequence":0}]}],"annualPremium":1095,"monthlyPremium":91.25,"conditionWhenBought":"N","serialNumber":"5XYKT4A75EG428473","leased":false,"modified":false,"modifiedForPerformance":false,"modificationWorth":null,"winterTire":false,"postalCodeOverriden":false,"annualKm":10000,"usedForBusiness":false,"usedToTransportGoods":false,"businessAnnualKm":null,"workOrSchoolKm":10,"usedOutsideProvinceOrCountry":false,"outsideProvinceOrCountryKm":null,"registerOwner":1000800736,"principalDriver":1,"model":{"make":"KIA","model":"SORENTO LX V6 4DR 2WD","year":2014,"code":"126600"},"purchaseDate":"2014-07-01","antiTheftDevice":false,"antiTheftDevices":[],"modificationCode":null,"usageModified":false,"coverageModified":false,"financed":null,"financingCompanyId":null,"otherFinancingCompany":null,"otherFinancingCompanyAddress":null,"lessorCompanyId":null,"otherLessorCompany":null,"otherLessorCompanyAddress":null,"secondRegisteredOwner":null,"secondRegisteredOwnerId":null,"addressChanged":false,"parkingType":null,"parkingIndoor":null,"principalDriverSince":"36","goodDriverDate":null,"unrepairedDamage":null,"showUnrepairedDamage":false,"annualKmModified":false,"workKmModified":false}],"user":{"firstName":"Crd-Dcl","lastName":"Test-Lgxhtkobk","clientId":512171844},"modificationCode":null,"annualPremium":1095,"monthlyPremium":45.63,"lockTimeStamp":1506009166289,"extendedTerm":null,"extendedTermMonths":null,"policyChange":{"effectiveDate":"2017-11-06","expiryDate":"2017-12-06","policyNumber":"E03-8036","underwriterName":null,"policyStatus":"ACTIVE","drivers":[{"sequence":1,"dateOfBirth":"1958-01-24","firstName":"CRD-DCL","gender":"F","lastName":"TEST-LGXHTKOBK","licenceNumber":"T123424015807","policyHolder":true,"maritalStatus":"F","relationshipToPolicyHolder":null,"fullTimeStudent":false,"permanentAddress":false,"retired":false,"driverLicenceClass":null,"licenceObtentionDate":"2012-07-01","g2LicenceDate":null,"modificationCode":null,"school100KmFromParent":null,"priorCarrierCancelled":false,"priorCarrier":null,"priorCarrierPolicyNumber":null,"driverLicenceType":"R","driverTrainingCourse":true,"drivingSchool":null,"trainingCertificateNumber":null,"obtainedG2OrG":null,"obtainedG2OrGDisplayed":null,"ageGotLicence":54,"infractionsPast3Years":false,"convictionsCount":null,"penaltyPointsAmount":null,"minorInfractionCount":0,"majorInfractionCount":null,"severeInfractionCount":0,"majorInfraction":false,"lossesYears":false,"claims":null,"driverIndex":0,"licenseRevoked":false,"workSector":null,"occupation":null,"monthNotLivingParent":null,"universityDiploma":null,"cancelledPolicyReason":null,"principalDriverSince":"36","convictions":null,"criminalRecord":null}],"policyHolders":[{"partyId":1000944178,"dateOfBirth":"1958-01-24","emailAddress":null,"firstName":"CRD-DCL","lastName":"TEST-LGXHTKOBK","maritalStatus":null,"gender":null,"homePhoneNumber":"4181712255","homePhoneExtension":null,"businessPhoneNumber":"4189575240","businessPhoneExtension":null,"address":{"civicNumber":"6187","apartment":null,"streetName":"OT DE LA EMJXRIYZD","streetDirection":null,"streetType":null,"floor":null,"poBox":null,"poStation":null,"ruralRouteNumber":null,"municipality":"LEVIS","province":"QC","postalCode":"G6X3B7","unstructuredAddressLine1":"6187, DE LA EMJXRIYZD","unstructuredAddressLine2":null,"unstructuredAddressLine3":null,"municipalityCode":"216000"},"type":"P"}],"vehicles":[{"sequenceNumber":1,"riskIndex":0,"coverages":[{"code":"A","productCode":"A","description":"Civil liability","selected":true,"section":"Coverage","type":"LIMIT_AMOUNT","sectionCode":"1","selectedAmount":1000000.0,"sequence":100.0,"values":[{"amount":1000000.0,"sequence":1},{"amount":2000000.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"B2","productCode":"B2","description":"Collision and upset","selected":true,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":500.0,"sequence":400.0,"values":[{"amount":250.0,"sequence":2},{"amount":500.0,"sequence":3},{"amount":1000.0,"sequence":0},{"amount":null,"sequence":1}],"mode":"SUGGESTED","modified":false},{"code":"B3","productCode":"B3","description":"All perils other than collision or upset","selected":true,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":250.0,"sequence":500.0,"values":[{"amount":50.0,"sequence":4},{"amount":100.0,"sequence":5},{"amount":250.0,"sequence":1},{"amount":500.0,"sequence":2},{"amount":1000.0,"sequence":3},{"amount":null,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"B4","productCode":"B4","description":"Specified Perils","selected":false,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":null,"sequence":600.0,"values":[{"amount":50.0,"sequence":0},{"amount":100.0,"sequence":1},{"amount":250.0,"sequence":4},{"amount":500.0,"sequence":2},{"amount":1000.0,"sequence":5},{"amount":null,"sequence":3}],"mode":"SUGGESTED","modified":false},{"code":"P1","productCode":"P1","description":"Accident benefits","selected":true,"section":"Coverage","type":"LIMIT_MUTIL_DEATH_AMOUNT","sectionCode":"1","selectedAmount":15000.0,"sequence":800.0,"values":[{"amount":15000.0,"sequence":0},{"amount":50000.0,"sequence":1}],"mode":"SUGGESTED","modified":false},{"code":"P2","productCode":"P2","description":"Accident benefits","selected":true,"section":"Hidden","type":"DEDUCTIBLE_AMOUNT","sectionCode":"7","selectedAmount":null,"sequence":810.0,"values":[],"mode":"MANDATORY","modified":false},{"code":"I90","productCode":"I90","description":"Autocomfort","selected":true,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1000.0,"values":[],"mode":"SUGGESTED","modified":false},{"code":"NV3","productCode":"NV3","description":"Accident forgiveness","selected":true,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1008.0,"values":[],"mode":"SUGGESTED","modified":false},{"code":"NBD","productCode":"NV3","description":"Accident forgiveness","selected":false,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1009.0,"values":[],"mode":"SUGGESTED","modified":false},{"code":"33E","productCode":"NV3","description":"belairdirect roadside assistance<sup>TM</sup>","selected":false,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1010.0,"values":[],"mode":"SUGGESTED","modified":false}],"annualPremium":1095,"monthlyPremium":91.25,"conditionWhenBought":"N","serialNumber":"5XYKT4A75EG428473","leased":false,"modified":false,"modifiedForPerformance":false,"modificationWorth":null,"winterTire":false,"postalCodeOverriden":false,"annualKm":10000,"usedForBusiness":false,"usedToTransportGoods":false,"businessAnnualKm":null,"workOrSchoolKm":10,"usedOutsideProvinceOrCountry":false,"outsideProvinceOrCountryKm":null,"registerOwner":1000944178,"principalDriver":1,"model":{"make":"KIA","model":"SORENTO LX V6 4DR 2WD","year":2014,"code":"126600"},"purchaseDate":"2014-07-01","antiTheftDevice":false,"antiTheftDevices":[],"modificationCode":null,"usageModified":false,"coverageModified":false,"financed":null,"financingCompanyId":null,"otherFinancingCompany":null,"otherFinancingCompanyAddress":null,"lessorCompanyId":null,"otherLessorCompany":null,"otherLessorCompanyAddress":null,"secondRegisteredOwner":null,"secondRegisteredOwnerId":null,"addressChanged":false,"parkingType":null,"parkingIndoor":null,"principalDriverSince":"36","goodDriverDate":null,"unrepairedDamage":null,"showUnrepairedDamage":false,"annualKmModified":false,"workKmModified":false}],"user":{"firstName":"Crd-Dcl","lastName":"Test-Lgxhtkobk","clientId":512171844},"modificationCode":null,"annualPremium":1095,"monthlyPremium":45.63,"lockTimeStamp":1506009166289,"extendedTerm":null,"extendedTermMonths":null}},"state":{"transactionInitialized":true,"taskschanged":false,"currentPage":"PC_COV","nextPage":"PC_PRM","previousPage":"PC_START","pages":[{"completed":false,"reachable":false,"type":"PC_COV","visible":true,"pageOpeningModeEnum":null,"otherPrincipalDriverAllowed":true},{"completed":false,"reachable":false,"type":"PC_PRM","visible":true,"pageOpeningModeEnum":null,"otherPrincipalDriverAllowed":true},{"completed":false,"reachable":false,"type":"PC_REVW","visible":true,"pageOpeningModeEnum":null,"otherPrincipalDriverAllowed":true},{"completed":false,"reachable":false,"type":"PC_TRX_CONFRM","visible":true,"pageOpeningModeEnum":null,"otherPrincipalDriverAllowed":true}],"effectiveDateMin":"2017-11-06","effectiveDateMax":"2017-12-06","transactionEffectiveDate":"2017-11-06","defaultEffectiveDate":"2017-11-06","studentAgeThreshold":25,"retiredAgeThreshold":50,"driverAgeThreshold":99,"vehiclesYearMin":1998,"vehiclesYearMax":2018,"tasks":["PC_CHANGE_COVERAGES"],"selectedTasks":["PC_CHANGE_COVERAGES"],"canAddDriver":true,"canAddVehicle":true,"addressModified":false,"vehicleImmobilizerMinYearThreshold":2008},"validation":{"resultType":null,"errors":null,"roadBlocks":null,"warnings":null}};
		var nv3NoNbdNo33eNo  = {"response":{"effectiveDate":"2017-11-06","expiryDate":"2017-04-26","policyNumber":"E03-8036","underwriterName":null,"policyStatus":"ACTIVE","drivers":[{"sequence":1,"dateOfBirth":"1958-01-24","firstName":"CRD-DCL","gender":"F","lastName":"TEST-LGXHTKOBK","licenceNumber":"T123424015807","policyHolder":true,"maritalStatus":"F","relationshipToPolicyHolder":null,"fullTimeStudent":false,"permanentAddress":false,"retired":false,"driverLicenceClass":null,"licenceObtentionDate":"2012-07-01","g2LicenceDate":null,"modificationCode":null,"school100KmFromParent":null,"priorCarrierCancelled":false,"priorCarrier":null,"priorCarrierPolicyNumber":null,"driverLicenceType":"R","driverTrainingCourse":true,"drivingSchool":null,"trainingCertificateNumber":null,"obtainedG2OrG":null,"obtainedG2OrGDisplayed":null,"ageGotLicence":54,"infractionsPast3Years":false,"convictionsCount":null,"penaltyPointsAmount":null,"minorInfractionCount":0,"majorInfractionCount":null,"severeInfractionCount":0,"majorInfraction":false,"lossesYears":false,"claims":null,"driverIndex":0,"licenseRevoked":false,"workSector":null,"occupation":null,"monthNotLivingParent":null,"universityDiploma":null,"cancelledPolicyReason":null,"principalDriverSince":"36","convictions":null,"criminalRecord":null}],"policyHolders":[{"partyId":1000800736,"dateOfBirth":"1958-01-24","emailAddress":null,"firstName":"CRD-DCL","lastName":"TEST-LGXHTKOBK","maritalStatus":null,"gender":null,"homePhoneNumber":"4181712255","homePhoneExtension":null,"businessPhoneNumber":"4189575240","businessPhoneExtension":null,"address":{"civicNumber":"6187","apartment":null,"streetName":"OT DE LA EMJXRIYZD","streetDirection":null,"streetType":null,"floor":null,"poBox":null,"poStation":null,"ruralRouteNumber":null,"municipality":"LEVIS","province":"QC","postalCode":"G6X3B7","unstructuredAddressLine1":"6187, DE LA EMJXRIYZD","unstructuredAddressLine2":null,"unstructuredAddressLine3":null,"municipalityCode":"216000"},"type":"P"}],"vehicles":[{"sequenceNumber":1,"riskIndex":0,"coverages":[{"code":"A","productCode":"A","description":"Civil liability","selected":true,"section":"Coverage","type":"LIMIT_AMOUNT","sectionCode":"1","selectedAmount":1000000.0,"sequence":100.0,"values":[{"amount":1000000.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"B2","productCode":"B2","description":"Collision and upset","selected":true,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":500.0,"sequence":400.0,"values":[{"amount":500.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"B3","productCode":"B3","description":"All perils other than collision or upset","selected":true,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":250.0,"sequence":500.0,"values":[{"amount":250.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"P1","productCode":"P1","description":"Accident benefits","selected":true,"section":"Coverage","type":"LIMIT_MUTIL_DEATH_AMOUNT","sectionCode":"1","selectedAmount":15000.0,"sequence":800.0,"values":[{"amount":15000.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"P2","productCode":"P2","description":"Accident benefits","selected":true,"section":"Hidden","type":"DEDUCTIBLE_AMOUNT","sectionCode":"7","selectedAmount":null,"sequence":810.0,"values":[{"amount":null,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"I90","productCode":"I90","description":"Autocomfort","selected":true,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1000.0,"values":[{"amount":null,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"NV3","productCode":"NV3","description":"Package","selected":true,"type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1008.0,"values":[{"amount":null,"sequence":0}]}],"annualPremium":1095,"monthlyPremium":91.25,"conditionWhenBought":"N","serialNumber":"5XYKT4A75EG428473","leased":false,"modified":false,"modifiedForPerformance":false,"modificationWorth":null,"winterTire":false,"postalCodeOverriden":false,"annualKm":10000,"usedForBusiness":false,"usedToTransportGoods":false,"businessAnnualKm":null,"workOrSchoolKm":10,"usedOutsideProvinceOrCountry":false,"outsideProvinceOrCountryKm":null,"registerOwner":1000800736,"principalDriver":1,"model":{"make":"KIA","model":"SORENTO LX V6 4DR 2WD","year":2014,"code":"126600"},"purchaseDate":"2014-07-01","antiTheftDevice":false,"antiTheftDevices":[],"modificationCode":null,"usageModified":false,"coverageModified":false,"financed":null,"financingCompanyId":null,"otherFinancingCompany":null,"otherFinancingCompanyAddress":null,"lessorCompanyId":null,"otherLessorCompany":null,"otherLessorCompanyAddress":null,"secondRegisteredOwner":null,"secondRegisteredOwnerId":null,"addressChanged":false,"parkingType":null,"parkingIndoor":null,"principalDriverSince":"36","goodDriverDate":null,"unrepairedDamage":null,"showUnrepairedDamage":false,"annualKmModified":false,"workKmModified":false}],"user":{"firstName":"Crd-Dcl","lastName":"Test-Lgxhtkobk","clientId":512171844},"modificationCode":null,"annualPremium":1095,"monthlyPremium":45.63,"lockTimeStamp":1506009166289,"extendedTerm":null,"extendedTermMonths":null,"policyChange":{"effectiveDate":"2017-11-06","expiryDate":"2017-12-06","policyNumber":"E03-8036","underwriterName":null,"policyStatus":"ACTIVE","drivers":[{"sequence":1,"dateOfBirth":"1958-01-24","firstName":"CRD-DCL","gender":"F","lastName":"TEST-LGXHTKOBK","licenceNumber":"T123424015807","policyHolder":true,"maritalStatus":"F","relationshipToPolicyHolder":null,"fullTimeStudent":false,"permanentAddress":false,"retired":false,"driverLicenceClass":null,"licenceObtentionDate":"2012-07-01","g2LicenceDate":null,"modificationCode":null,"school100KmFromParent":null,"priorCarrierCancelled":false,"priorCarrier":null,"priorCarrierPolicyNumber":null,"driverLicenceType":"R","driverTrainingCourse":true,"drivingSchool":null,"trainingCertificateNumber":null,"obtainedG2OrG":null,"obtainedG2OrGDisplayed":null,"ageGotLicence":54,"infractionsPast3Years":false,"convictionsCount":null,"penaltyPointsAmount":null,"minorInfractionCount":0,"majorInfractionCount":null,"severeInfractionCount":0,"majorInfraction":false,"lossesYears":false,"claims":null,"driverIndex":0,"licenseRevoked":false,"workSector":null,"occupation":null,"monthNotLivingParent":null,"universityDiploma":null,"cancelledPolicyReason":null,"principalDriverSince":"36","convictions":null,"criminalRecord":null}],"policyHolders":[{"partyId":1000944178,"dateOfBirth":"1958-01-24","emailAddress":null,"firstName":"CRD-DCL","lastName":"TEST-LGXHTKOBK","maritalStatus":null,"gender":null,"homePhoneNumber":"4181712255","homePhoneExtension":null,"businessPhoneNumber":"4189575240","businessPhoneExtension":null,"address":{"civicNumber":"6187","apartment":null,"streetName":"OT DE LA EMJXRIYZD","streetDirection":null,"streetType":null,"floor":null,"poBox":null,"poStation":null,"ruralRouteNumber":null,"municipality":"LEVIS","province":"QC","postalCode":"G6X3B7","unstructuredAddressLine1":"6187, DE LA EMJXRIYZD","unstructuredAddressLine2":null,"unstructuredAddressLine3":null,"municipalityCode":"216000"},"type":"P"}],"vehicles":[{"sequenceNumber":1,"riskIndex":0,"coverages":[{"code":"A","productCode":"A","description":"Civil liability","selected":true,"section":"Coverage","type":"LIMIT_AMOUNT","sectionCode":"1","selectedAmount":1000000.0,"sequence":100.0,"values":[{"amount":1000000.0,"sequence":1},{"amount":2000000.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"B2","productCode":"B2","description":"Collision and upset","selected":true,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":500.0,"sequence":400.0,"values":[{"amount":250.0,"sequence":2},{"amount":500.0,"sequence":3},{"amount":1000.0,"sequence":0},{"amount":null,"sequence":1}],"mode":"SUGGESTED","modified":false},{"code":"B3","productCode":"B3","description":"All perils other than collision or upset","selected":true,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":250.0,"sequence":500.0,"values":[{"amount":50.0,"sequence":4},{"amount":100.0,"sequence":5},{"amount":250.0,"sequence":1},{"amount":500.0,"sequence":2},{"amount":1000.0,"sequence":3},{"amount":null,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"B4","productCode":"B4","description":"Specified Perils","selected":false,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":null,"sequence":600.0,"values":[{"amount":50.0,"sequence":0},{"amount":100.0,"sequence":1},{"amount":250.0,"sequence":4},{"amount":500.0,"sequence":2},{"amount":1000.0,"sequence":5},{"amount":null,"sequence":3}],"mode":"SUGGESTED","modified":false},{"code":"P1","productCode":"P1","description":"Accident benefits","selected":true,"section":"Coverage","type":"LIMIT_MUTIL_DEATH_AMOUNT","sectionCode":"1","selectedAmount":15000.0,"sequence":800.0,"values":[{"amount":15000.0,"sequence":0},{"amount":50000.0,"sequence":1}],"mode":"SUGGESTED","modified":false},{"code":"P2","productCode":"P2","description":"Accident benefits","selected":true,"section":"Hidden","type":"DEDUCTIBLE_AMOUNT","sectionCode":"7","selectedAmount":null,"sequence":810.0,"values":[],"mode":"MANDATORY","modified":false},{"code":"I90","productCode":"I90","description":"Autocomfort","selected":true,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1000.0,"values":[],"mode":"SUGGESTED","modified":false},{"code":"NV3","productCode":"NV3","description":"Accident forgiveness","selected":false,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1008.0,"values":[],"mode":"SUGGESTED","modified":false},{"code":"NBD","productCode":"NV3","description":"Accident forgiveness","selected":false,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1009.0,"values":[],"mode":"SUGGESTED","modified":false},{"code":"33E","productCode":"NV3","description":"belairdirect roadside assistance<sup>TM</sup>","selected":false,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1010.0,"values":[],"mode":"SUGGESTED","modified":false}],"annualPremium":1095,"monthlyPremium":91.25,"conditionWhenBought":"N","serialNumber":"5XYKT4A75EG428473","leased":false,"modified":false,"modifiedForPerformance":false,"modificationWorth":null,"winterTire":false,"postalCodeOverriden":false,"annualKm":10000,"usedForBusiness":false,"usedToTransportGoods":false,"businessAnnualKm":null,"workOrSchoolKm":10,"usedOutsideProvinceOrCountry":false,"outsideProvinceOrCountryKm":null,"registerOwner":1000944178,"principalDriver":1,"model":{"make":"KIA","model":"SORENTO LX V6 4DR 2WD","year":2014,"code":"126600"},"purchaseDate":"2014-07-01","antiTheftDevice":false,"antiTheftDevices":[],"modificationCode":null,"usageModified":false,"coverageModified":false,"financed":null,"financingCompanyId":null,"otherFinancingCompany":null,"otherFinancingCompanyAddress":null,"lessorCompanyId":null,"otherLessorCompany":null,"otherLessorCompanyAddress":null,"secondRegisteredOwner":null,"secondRegisteredOwnerId":null,"addressChanged":false,"parkingType":null,"parkingIndoor":null,"principalDriverSince":"36","goodDriverDate":null,"unrepairedDamage":null,"showUnrepairedDamage":false,"annualKmModified":false,"workKmModified":false}],"user":{"firstName":"Crd-Dcl","lastName":"Test-Lgxhtkobk","clientId":512171844},"modificationCode":null,"annualPremium":1095,"monthlyPremium":45.63,"lockTimeStamp":1506009166289,"extendedTerm":null,"extendedTermMonths":null}},"state":{"transactionInitialized":true,"taskschanged":false,"currentPage":"PC_COV","nextPage":"PC_PRM","previousPage":"PC_START","pages":[{"completed":false,"reachable":false,"type":"PC_COV","visible":true,"pageOpeningModeEnum":null,"otherPrincipalDriverAllowed":true},{"completed":false,"reachable":false,"type":"PC_PRM","visible":true,"pageOpeningModeEnum":null,"otherPrincipalDriverAllowed":true},{"completed":false,"reachable":false,"type":"PC_REVW","visible":true,"pageOpeningModeEnum":null,"otherPrincipalDriverAllowed":true},{"completed":false,"reachable":false,"type":"PC_TRX_CONFRM","visible":true,"pageOpeningModeEnum":null,"otherPrincipalDriverAllowed":true}],"effectiveDateMin":"2017-11-06","effectiveDateMax":"2017-12-06","transactionEffectiveDate":"2017-11-06","defaultEffectiveDate":"2017-11-06","studentAgeThreshold":25,"retiredAgeThreshold":50,"driverAgeThreshold":99,"vehiclesYearMin":1998,"vehiclesYearMax":2018,"tasks":["PC_CHANGE_COVERAGES"],"selectedTasks":["PC_CHANGE_COVERAGES"],"canAddDriver":true,"canAddVehicle":true,"addressModified":false,"vehicleImmobilizerMinYearThreshold":2008},"validation":{"resultType":null,"errors":null,"roadBlocks":null,"warnings":null}};
		var nv3NoNbdYes33eNo = {"response":{"effectiveDate":"2017-11-06","expiryDate":"2017-04-26","policyNumber":"E03-8036","underwriterName":null,"policyStatus":"ACTIVE","drivers":[{"sequence":1,"dateOfBirth":"1958-01-24","firstName":"CRD-DCL","gender":"F","lastName":"TEST-LGXHTKOBK","licenceNumber":"T123424015807","policyHolder":true,"maritalStatus":"F","relationshipToPolicyHolder":null,"fullTimeStudent":false,"permanentAddress":false,"retired":false,"driverLicenceClass":null,"licenceObtentionDate":"2012-07-01","g2LicenceDate":null,"modificationCode":null,"school100KmFromParent":null,"priorCarrierCancelled":false,"priorCarrier":null,"priorCarrierPolicyNumber":null,"driverLicenceType":"R","driverTrainingCourse":true,"drivingSchool":null,"trainingCertificateNumber":null,"obtainedG2OrG":null,"obtainedG2OrGDisplayed":null,"ageGotLicence":54,"infractionsPast3Years":false,"convictionsCount":null,"penaltyPointsAmount":null,"minorInfractionCount":0,"majorInfractionCount":null,"severeInfractionCount":0,"majorInfraction":false,"lossesYears":false,"claims":null,"driverIndex":0,"licenseRevoked":false,"workSector":null,"occupation":null,"monthNotLivingParent":null,"universityDiploma":null,"cancelledPolicyReason":null,"principalDriverSince":"36","convictions":null,"criminalRecord":null}],"policyHolders":[{"partyId":1000800736,"dateOfBirth":"1958-01-24","emailAddress":null,"firstName":"CRD-DCL","lastName":"TEST-LGXHTKOBK","maritalStatus":null,"gender":null,"homePhoneNumber":"4181712255","homePhoneExtension":null,"businessPhoneNumber":"4189575240","businessPhoneExtension":null,"address":{"civicNumber":"6187","apartment":null,"streetName":"OT DE LA EMJXRIYZD","streetDirection":null,"streetType":null,"floor":null,"poBox":null,"poStation":null,"ruralRouteNumber":null,"municipality":"LEVIS","province":"QC","postalCode":"G6X3B7","unstructuredAddressLine1":"6187, DE LA EMJXRIYZD","unstructuredAddressLine2":null,"unstructuredAddressLine3":null,"municipalityCode":"216000"},"type":"P"}],"vehicles":[{"sequenceNumber":1,"riskIndex":0,"coverages":[{"code":"A","productCode":"A","description":"Civil liability","selected":true,"section":"Coverage","type":"LIMIT_AMOUNT","sectionCode":"1","selectedAmount":1000000.0,"sequence":100.0,"values":[{"amount":1000000.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"B2","productCode":"B2","description":"Collision and upset","selected":true,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":500.0,"sequence":400.0,"values":[{"amount":500.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"B3","productCode":"B3","description":"All perils other than collision or upset","selected":true,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":250.0,"sequence":500.0,"values":[{"amount":250.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"P1","productCode":"P1","description":"Accident benefits","selected":true,"section":"Coverage","type":"LIMIT_MUTIL_DEATH_AMOUNT","sectionCode":"1","selectedAmount":15000.0,"sequence":800.0,"values":[{"amount":15000.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"P2","productCode":"P2","description":"Accident benefits","selected":true,"section":"Hidden","type":"DEDUCTIBLE_AMOUNT","sectionCode":"7","selectedAmount":null,"sequence":810.0,"values":[{"amount":null,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"I90","productCode":"I90","description":"Autocomfort","selected":true,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1000.0,"values":[{"amount":null,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"NV3","productCode":"NV3","description":"Package","selected":true,"type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1008.0,"values":[{"amount":null,"sequence":0}]}],"annualPremium":1095,"monthlyPremium":91.25,"conditionWhenBought":"N","serialNumber":"5XYKT4A75EG428473","leased":false,"modified":false,"modifiedForPerformance":false,"modificationWorth":null,"winterTire":false,"postalCodeOverriden":false,"annualKm":10000,"usedForBusiness":false,"usedToTransportGoods":false,"businessAnnualKm":null,"workOrSchoolKm":10,"usedOutsideProvinceOrCountry":false,"outsideProvinceOrCountryKm":null,"registerOwner":1000800736,"principalDriver":1,"model":{"make":"KIA","model":"SORENTO LX V6 4DR 2WD","year":2014,"code":"126600"},"purchaseDate":"2014-07-01","antiTheftDevice":false,"antiTheftDevices":[],"modificationCode":null,"usageModified":false,"coverageModified":false,"financed":null,"financingCompanyId":null,"otherFinancingCompany":null,"otherFinancingCompanyAddress":null,"lessorCompanyId":null,"otherLessorCompany":null,"otherLessorCompanyAddress":null,"secondRegisteredOwner":null,"secondRegisteredOwnerId":null,"addressChanged":false,"parkingType":null,"parkingIndoor":null,"principalDriverSince":"36","goodDriverDate":null,"unrepairedDamage":null,"showUnrepairedDamage":false,"annualKmModified":false,"workKmModified":false}],"user":{"firstName":"Crd-Dcl","lastName":"Test-Lgxhtkobk","clientId":512171844},"modificationCode":null,"annualPremium":1095,"monthlyPremium":45.63,"lockTimeStamp":1506009166289,"extendedTerm":null,"extendedTermMonths":null,"policyChange":{"effectiveDate":"2017-11-06","expiryDate":"2017-12-06","policyNumber":"E03-8036","underwriterName":null,"policyStatus":"ACTIVE","drivers":[{"sequence":1,"dateOfBirth":"1958-01-24","firstName":"CRD-DCL","gender":"F","lastName":"TEST-LGXHTKOBK","licenceNumber":"T123424015807","policyHolder":true,"maritalStatus":"F","relationshipToPolicyHolder":null,"fullTimeStudent":false,"permanentAddress":false,"retired":false,"driverLicenceClass":null,"licenceObtentionDate":"2012-07-01","g2LicenceDate":null,"modificationCode":null,"school100KmFromParent":null,"priorCarrierCancelled":false,"priorCarrier":null,"priorCarrierPolicyNumber":null,"driverLicenceType":"R","driverTrainingCourse":true,"drivingSchool":null,"trainingCertificateNumber":null,"obtainedG2OrG":null,"obtainedG2OrGDisplayed":null,"ageGotLicence":54,"infractionsPast3Years":false,"convictionsCount":null,"penaltyPointsAmount":null,"minorInfractionCount":0,"majorInfractionCount":null,"severeInfractionCount":0,"majorInfraction":false,"lossesYears":false,"claims":null,"driverIndex":0,"licenseRevoked":false,"workSector":null,"occupation":null,"monthNotLivingParent":null,"universityDiploma":null,"cancelledPolicyReason":null,"principalDriverSince":"36","convictions":null,"criminalRecord":null}],"policyHolders":[{"partyId":1000944178,"dateOfBirth":"1958-01-24","emailAddress":null,"firstName":"CRD-DCL","lastName":"TEST-LGXHTKOBK","maritalStatus":null,"gender":null,"homePhoneNumber":"4181712255","homePhoneExtension":null,"businessPhoneNumber":"4189575240","businessPhoneExtension":null,"address":{"civicNumber":"6187","apartment":null,"streetName":"OT DE LA EMJXRIYZD","streetDirection":null,"streetType":null,"floor":null,"poBox":null,"poStation":null,"ruralRouteNumber":null,"municipality":"LEVIS","province":"QC","postalCode":"G6X3B7","unstructuredAddressLine1":"6187, DE LA EMJXRIYZD","unstructuredAddressLine2":null,"unstructuredAddressLine3":null,"municipalityCode":"216000"},"type":"P"}],"vehicles":[{"sequenceNumber":1,"riskIndex":0,"coverages":[{"code":"A","productCode":"A","description":"Civil liability","selected":true,"section":"Coverage","type":"LIMIT_AMOUNT","sectionCode":"1","selectedAmount":1000000.0,"sequence":100.0,"values":[{"amount":1000000.0,"sequence":1},{"amount":2000000.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"B2","productCode":"B2","description":"Collision and upset","selected":true,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":500.0,"sequence":400.0,"values":[{"amount":250.0,"sequence":2},{"amount":500.0,"sequence":3},{"amount":1000.0,"sequence":0},{"amount":null,"sequence":1}],"mode":"SUGGESTED","modified":false},{"code":"B3","productCode":"B3","description":"All perils other than collision or upset","selected":true,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":250.0,"sequence":500.0,"values":[{"amount":50.0,"sequence":4},{"amount":100.0,"sequence":5},{"amount":250.0,"sequence":1},{"amount":500.0,"sequence":2},{"amount":1000.0,"sequence":3},{"amount":null,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"B4","productCode":"B4","description":"Specified Perils","selected":false,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":null,"sequence":600.0,"values":[{"amount":50.0,"sequence":0},{"amount":100.0,"sequence":1},{"amount":250.0,"sequence":4},{"amount":500.0,"sequence":2},{"amount":1000.0,"sequence":5},{"amount":null,"sequence":3}],"mode":"SUGGESTED","modified":false},{"code":"P1","productCode":"P1","description":"Accident benefits","selected":true,"section":"Coverage","type":"LIMIT_MUTIL_DEATH_AMOUNT","sectionCode":"1","selectedAmount":15000.0,"sequence":800.0,"values":[{"amount":15000.0,"sequence":0},{"amount":50000.0,"sequence":1}],"mode":"SUGGESTED","modified":false},{"code":"P2","productCode":"P2","description":"Accident benefits","selected":true,"section":"Hidden","type":"DEDUCTIBLE_AMOUNT","sectionCode":"7","selectedAmount":null,"sequence":810.0,"values":[],"mode":"MANDATORY","modified":false},{"code":"I90","productCode":"I90","description":"Autocomfort","selected":true,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1000.0,"values":[],"mode":"SUGGESTED","modified":false},{"code":"NV3","productCode":"NV3","description":"Accident forgiveness","selected":false,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1008.0,"values":[],"mode":"SUGGESTED","modified":false},{"code":"NBD","productCode":"NV3","description":"Accident forgiveness","selected":true,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1009.0,"values":[],"mode":"SUGGESTED","modified":false},{"code":"33E","productCode":"NV3","description":"belairdirect roadside assistance<sup>TM</sup>","selected":false,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1010.0,"values":[],"mode":"SUGGESTED","modified":false}],"annualPremium":1095,"monthlyPremium":91.25,"conditionWhenBought":"N","serialNumber":"5XYKT4A75EG428473","leased":false,"modified":false,"modifiedForPerformance":false,"modificationWorth":null,"winterTire":false,"postalCodeOverriden":false,"annualKm":10000,"usedForBusiness":false,"usedToTransportGoods":false,"businessAnnualKm":null,"workOrSchoolKm":10,"usedOutsideProvinceOrCountry":false,"outsideProvinceOrCountryKm":null,"registerOwner":1000944178,"principalDriver":1,"model":{"make":"KIA","model":"SORENTO LX V6 4DR 2WD","year":2014,"code":"126600"},"purchaseDate":"2014-07-01","antiTheftDevice":false,"antiTheftDevices":[],"modificationCode":null,"usageModified":false,"coverageModified":false,"financed":null,"financingCompanyId":null,"otherFinancingCompany":null,"otherFinancingCompanyAddress":null,"lessorCompanyId":null,"otherLessorCompany":null,"otherLessorCompanyAddress":null,"secondRegisteredOwner":null,"secondRegisteredOwnerId":null,"addressChanged":false,"parkingType":null,"parkingIndoor":null,"principalDriverSince":"36","goodDriverDate":null,"unrepairedDamage":null,"showUnrepairedDamage":false,"annualKmModified":false,"workKmModified":false}],"user":{"firstName":"Crd-Dcl","lastName":"Test-Lgxhtkobk","clientId":512171844},"modificationCode":null,"annualPremium":1095,"monthlyPremium":45.63,"lockTimeStamp":1506009166289,"extendedTerm":null,"extendedTermMonths":null}},"state":{"transactionInitialized":true,"taskschanged":false,"currentPage":"PC_COV","nextPage":"PC_PRM","previousPage":"PC_START","pages":[{"completed":false,"reachable":false,"type":"PC_COV","visible":true,"pageOpeningModeEnum":null,"otherPrincipalDriverAllowed":true},{"completed":false,"reachable":false,"type":"PC_PRM","visible":true,"pageOpeningModeEnum":null,"otherPrincipalDriverAllowed":true},{"completed":false,"reachable":false,"type":"PC_REVW","visible":true,"pageOpeningModeEnum":null,"otherPrincipalDriverAllowed":true},{"completed":false,"reachable":false,"type":"PC_TRX_CONFRM","visible":true,"pageOpeningModeEnum":null,"otherPrincipalDriverAllowed":true}],"effectiveDateMin":"2017-11-06","effectiveDateMax":"2017-12-06","transactionEffectiveDate":"2017-11-06","defaultEffectiveDate":"2017-11-06","studentAgeThreshold":25,"retiredAgeThreshold":50,"driverAgeThreshold":99,"vehiclesYearMin":1998,"vehiclesYearMax":2018,"tasks":["PC_CHANGE_COVERAGES"],"selectedTasks":["PC_CHANGE_COVERAGES"],"canAddDriver":true,"canAddVehicle":true,"addressModified":false,"vehicleImmobilizerMinYearThreshold":2008},"validation":{"resultType":null,"errors":null,"roadBlocks":null,"warnings":null}};
		var nv3NoNbdNo33eYes = {"response":{"effectiveDate":"2017-11-06","expiryDate":"2017-04-26","policyNumber":"E03-8036","underwriterName":null,"policyStatus":"ACTIVE","drivers":[{"sequence":1,"dateOfBirth":"1958-01-24","firstName":"CRD-DCL","gender":"F","lastName":"TEST-LGXHTKOBK","licenceNumber":"T123424015807","policyHolder":true,"maritalStatus":"F","relationshipToPolicyHolder":null,"fullTimeStudent":false,"permanentAddress":false,"retired":false,"driverLicenceClass":null,"licenceObtentionDate":"2012-07-01","g2LicenceDate":null,"modificationCode":null,"school100KmFromParent":null,"priorCarrierCancelled":false,"priorCarrier":null,"priorCarrierPolicyNumber":null,"driverLicenceType":"R","driverTrainingCourse":true,"drivingSchool":null,"trainingCertificateNumber":null,"obtainedG2OrG":null,"obtainedG2OrGDisplayed":null,"ageGotLicence":54,"infractionsPast3Years":false,"convictionsCount":null,"penaltyPointsAmount":null,"minorInfractionCount":0,"majorInfractionCount":null,"severeInfractionCount":0,"majorInfraction":false,"lossesYears":false,"claims":null,"driverIndex":0,"licenseRevoked":false,"workSector":null,"occupation":null,"monthNotLivingParent":null,"universityDiploma":null,"cancelledPolicyReason":null,"principalDriverSince":"36","convictions":null,"criminalRecord":null}],"policyHolders":[{"partyId":1000800736,"dateOfBirth":"1958-01-24","emailAddress":null,"firstName":"CRD-DCL","lastName":"TEST-LGXHTKOBK","maritalStatus":null,"gender":null,"homePhoneNumber":"4181712255","homePhoneExtension":null,"businessPhoneNumber":"4189575240","businessPhoneExtension":null,"address":{"civicNumber":"6187","apartment":null,"streetName":"OT DE LA EMJXRIYZD","streetDirection":null,"streetType":null,"floor":null,"poBox":null,"poStation":null,"ruralRouteNumber":null,"municipality":"LEVIS","province":"QC","postalCode":"G6X3B7","unstructuredAddressLine1":"6187, DE LA EMJXRIYZD","unstructuredAddressLine2":null,"unstructuredAddressLine3":null,"municipalityCode":"216000"},"type":"P"}],"vehicles":[{"sequenceNumber":1,"riskIndex":0,"coverages":[{"code":"A","productCode":"A","description":"Civil liability","selected":true,"section":"Coverage","type":"LIMIT_AMOUNT","sectionCode":"1","selectedAmount":1000000.0,"sequence":100.0,"values":[{"amount":1000000.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"B2","productCode":"B2","description":"Collision and upset","selected":true,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":500.0,"sequence":400.0,"values":[{"amount":500.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"B3","productCode":"B3","description":"All perils other than collision or upset","selected":true,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":250.0,"sequence":500.0,"values":[{"amount":250.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"P1","productCode":"P1","description":"Accident benefits","selected":true,"section":"Coverage","type":"LIMIT_MUTIL_DEATH_AMOUNT","sectionCode":"1","selectedAmount":15000.0,"sequence":800.0,"values":[{"amount":15000.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"P2","productCode":"P2","description":"Accident benefits","selected":true,"section":"Hidden","type":"DEDUCTIBLE_AMOUNT","sectionCode":"7","selectedAmount":null,"sequence":810.0,"values":[{"amount":null,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"I90","productCode":"I90","description":"Autocomfort","selected":true,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1000.0,"values":[{"amount":null,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"NV3","productCode":"NV3","description":"Package","selected":true,"type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1008.0,"values":[{"amount":null,"sequence":0}]}],"annualPremium":1095,"monthlyPremium":91.25,"conditionWhenBought":"N","serialNumber":"5XYKT4A75EG428473","leased":false,"modified":false,"modifiedForPerformance":false,"modificationWorth":null,"winterTire":false,"postalCodeOverriden":false,"annualKm":10000,"usedForBusiness":false,"usedToTransportGoods":false,"businessAnnualKm":null,"workOrSchoolKm":10,"usedOutsideProvinceOrCountry":false,"outsideProvinceOrCountryKm":null,"registerOwner":1000800736,"principalDriver":1,"model":{"make":"KIA","model":"SORENTO LX V6 4DR 2WD","year":2014,"code":"126600"},"purchaseDate":"2014-07-01","antiTheftDevice":false,"antiTheftDevices":[],"modificationCode":null,"usageModified":false,"coverageModified":false,"financed":null,"financingCompanyId":null,"otherFinancingCompany":null,"otherFinancingCompanyAddress":null,"lessorCompanyId":null,"otherLessorCompany":null,"otherLessorCompanyAddress":null,"secondRegisteredOwner":null,"secondRegisteredOwnerId":null,"addressChanged":false,"parkingType":null,"parkingIndoor":null,"principalDriverSince":"36","goodDriverDate":null,"unrepairedDamage":null,"showUnrepairedDamage":false,"annualKmModified":false,"workKmModified":false}],"user":{"firstName":"Crd-Dcl","lastName":"Test-Lgxhtkobk","clientId":512171844},"modificationCode":null,"annualPremium":1095,"monthlyPremium":45.63,"lockTimeStamp":1506009166289,"extendedTerm":null,"extendedTermMonths":null,"policyChange":{"effectiveDate":"2017-11-06","expiryDate":"2017-12-06","policyNumber":"E03-8036","underwriterName":null,"policyStatus":"ACTIVE","drivers":[{"sequence":1,"dateOfBirth":"1958-01-24","firstName":"CRD-DCL","gender":"F","lastName":"TEST-LGXHTKOBK","licenceNumber":"T123424015807","policyHolder":true,"maritalStatus":"F","relationshipToPolicyHolder":null,"fullTimeStudent":false,"permanentAddress":false,"retired":false,"driverLicenceClass":null,"licenceObtentionDate":"2012-07-01","g2LicenceDate":null,"modificationCode":null,"school100KmFromParent":null,"priorCarrierCancelled":false,"priorCarrier":null,"priorCarrierPolicyNumber":null,"driverLicenceType":"R","driverTrainingCourse":true,"drivingSchool":null,"trainingCertificateNumber":null,"obtainedG2OrG":null,"obtainedG2OrGDisplayed":null,"ageGotLicence":54,"infractionsPast3Years":false,"convictionsCount":null,"penaltyPointsAmount":null,"minorInfractionCount":0,"majorInfractionCount":null,"severeInfractionCount":0,"majorInfraction":false,"lossesYears":false,"claims":null,"driverIndex":0,"licenseRevoked":false,"workSector":null,"occupation":null,"monthNotLivingParent":null,"universityDiploma":null,"cancelledPolicyReason":null,"principalDriverSince":"36","convictions":null,"criminalRecord":null}],"policyHolders":[{"partyId":1000944178,"dateOfBirth":"1958-01-24","emailAddress":null,"firstName":"CRD-DCL","lastName":"TEST-LGXHTKOBK","maritalStatus":null,"gender":null,"homePhoneNumber":"4181712255","homePhoneExtension":null,"businessPhoneNumber":"4189575240","businessPhoneExtension":null,"address":{"civicNumber":"6187","apartment":null,"streetName":"OT DE LA EMJXRIYZD","streetDirection":null,"streetType":null,"floor":null,"poBox":null,"poStation":null,"ruralRouteNumber":null,"municipality":"LEVIS","province":"QC","postalCode":"G6X3B7","unstructuredAddressLine1":"6187, DE LA EMJXRIYZD","unstructuredAddressLine2":null,"unstructuredAddressLine3":null,"municipalityCode":"216000"},"type":"P"}],"vehicles":[{"sequenceNumber":1,"riskIndex":0,"coverages":[{"code":"A","productCode":"A","description":"Civil liability","selected":true,"section":"Coverage","type":"LIMIT_AMOUNT","sectionCode":"1","selectedAmount":1000000.0,"sequence":100.0,"values":[{"amount":1000000.0,"sequence":1},{"amount":2000000.0,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"B2","productCode":"B2","description":"Collision and upset","selected":true,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":500.0,"sequence":400.0,"values":[{"amount":250.0,"sequence":2},{"amount":500.0,"sequence":3},{"amount":1000.0,"sequence":0},{"amount":null,"sequence":1}],"mode":"SUGGESTED","modified":false},{"code":"B3","productCode":"B3","description":"All perils other than collision or upset","selected":true,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":250.0,"sequence":500.0,"values":[{"amount":50.0,"sequence":4},{"amount":100.0,"sequence":5},{"amount":250.0,"sequence":1},{"amount":500.0,"sequence":2},{"amount":1000.0,"sequence":3},{"amount":null,"sequence":0}],"mode":"SUGGESTED","modified":false},{"code":"B4","productCode":"B4","description":"Specified Perils","selected":false,"section":"Coverage","type":"DEDUCTIBLE_AMOUNT","sectionCode":"1","selectedAmount":null,"sequence":600.0,"values":[{"amount":50.0,"sequence":0},{"amount":100.0,"sequence":1},{"amount":250.0,"sequence":4},{"amount":500.0,"sequence":2},{"amount":1000.0,"sequence":5},{"amount":null,"sequence":3}],"mode":"SUGGESTED","modified":false},{"code":"P1","productCode":"P1","description":"Accident benefits","selected":true,"section":"Coverage","type":"LIMIT_MUTIL_DEATH_AMOUNT","sectionCode":"1","selectedAmount":15000.0,"sequence":800.0,"values":[{"amount":15000.0,"sequence":0},{"amount":50000.0,"sequence":1}],"mode":"SUGGESTED","modified":false},{"code":"P2","productCode":"P2","description":"Accident benefits","selected":true,"section":"Hidden","type":"DEDUCTIBLE_AMOUNT","sectionCode":"7","selectedAmount":null,"sequence":810.0,"values":[],"mode":"MANDATORY","modified":false},{"code":"I90","productCode":"I90","description":"Autocomfort","selected":true,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1000.0,"values":[],"mode":"SUGGESTED","modified":false},{"code":"NV3","productCode":"NV3","description":"Accident forgiveness","selected":false,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1008.0,"values":[],"mode":"SUGGESTED","modified":false},{"code":"NBD","productCode":"NV3","description":"Accident forgiveness","selected":false,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1009.0,"values":[],"mode":"SUGGESTED","modified":false},{"code":"33E","productCode":"NV3","description":"belairdirect roadside assistance<sup>TM</sup>","selected":true,"section":"Options","type":"DEDUCTIBLE_AMOUNT","sectionCode":"2","selectedAmount":null,"sequence":1010.0,"values":[],"mode":"SUGGESTED","modified":false}],"annualPremium":1095,"monthlyPremium":91.25,"conditionWhenBought":"N","serialNumber":"5XYKT4A75EG428473","leased":false,"modified":false,"modifiedForPerformance":false,"modificationWorth":null,"winterTire":false,"postalCodeOverriden":false,"annualKm":10000,"usedForBusiness":false,"usedToTransportGoods":false,"businessAnnualKm":null,"workOrSchoolKm":10,"usedOutsideProvinceOrCountry":false,"outsideProvinceOrCountryKm":null,"registerOwner":1000944178,"principalDriver":1,"model":{"make":"KIA","model":"SORENTO LX V6 4DR 2WD","year":2014,"code":"126600"},"purchaseDate":"2014-07-01","antiTheftDevice":false,"antiTheftDevices":[],"modificationCode":null,"usageModified":false,"coverageModified":false,"financed":null,"financingCompanyId":null,"otherFinancingCompany":null,"otherFinancingCompanyAddress":null,"lessorCompanyId":null,"otherLessorCompany":null,"otherLessorCompanyAddress":null,"secondRegisteredOwner":null,"secondRegisteredOwnerId":null,"addressChanged":false,"parkingType":null,"parkingIndoor":null,"principalDriverSince":"36","goodDriverDate":null,"unrepairedDamage":null,"showUnrepairedDamage":false,"annualKmModified":false,"workKmModified":false}],"user":{"firstName":"Crd-Dcl","lastName":"Test-Lgxhtkobk","clientId":512171844},"modificationCode":null,"annualPremium":1095,"monthlyPremium":45.63,"lockTimeStamp":1506009166289,"extendedTerm":null,"extendedTermMonths":null}},"state":{"transactionInitialized":true,"taskschanged":false,"currentPage":"PC_COV","nextPage":"PC_PRM","previousPage":"PC_START","pages":[{"completed":false,"reachable":false,"type":"PC_COV","visible":true,"pageOpeningModeEnum":null,"otherPrincipalDriverAllowed":true},{"completed":false,"reachable":false,"type":"PC_PRM","visible":true,"pageOpeningModeEnum":null,"otherPrincipalDriverAllowed":true},{"completed":false,"reachable":false,"type":"PC_REVW","visible":true,"pageOpeningModeEnum":null,"otherPrincipalDriverAllowed":true},{"completed":false,"reachable":false,"type":"PC_TRX_CONFRM","visible":true,"pageOpeningModeEnum":null,"otherPrincipalDriverAllowed":true}],"effectiveDateMin":"2017-11-06","effectiveDateMax":"2017-12-06","transactionEffectiveDate":"2017-11-06","defaultEffectiveDate":"2017-11-06","studentAgeThreshold":25,"retiredAgeThreshold":50,"driverAgeThreshold":99,"vehiclesYearMin":1998,"vehiclesYearMax":2018,"tasks":["PC_CHANGE_COVERAGES"],"selectedTasks":["PC_CHANGE_COVERAGES"],"canAddDriver":true,"canAddVehicle":true,"addressModified":false,"vehicleImmobilizerMinYearThreshold":2008},"validation":{"resultType":null,"errors":null,"roadBlocks":null,"warnings":null}};

		/**
		* UP TO HERE
		*/

		var $uriWithParams = $filter('uriWithParams');
		var TIMEOUT = 40000;

		/*
		*	HTTP functions
		*/
		this.put = function(url, payLoad, _options){
			var deferred = $q.defer(),
				cleanUrl = getUrl(url, _options);
			_options.webserviceTimeout = TIMEOUT;
			
			$CoreRestApiService.put(cleanUrl, cleanUpData(payLoad), _options).then(function(r){
				resolvePromisePC(deferred, r, _options, 'PUT');
			}, function(e){
				rejectHttpExceptions(e, deferred);
			});

			return deferred.promise;
		};

		this.post = function(url, payLoad, _options){
			var deferred = $q.defer(),
				cleanUrl = getUrl(url, _options);
			_options.webserviceTimeout = TIMEOUT;

			//TODO REMOVE AFTER POC
			// var _33eSelected = $filter('filter')($PolicyChange.$get().policyChange().policyChange.vehicles[0].coverages, {code : '33E'})[0].selected;
			// var _nbdSelected = $filter('filter')($PolicyChange.$get().policyChange().policyChange.vehicles[0].coverages, {code : 'NBD'})[0].selected;
			// if( url.substr(-3) === "NV3" 
			// 	&& $PolicyChange.$get().policyChange().currentPolicy.policyNumber === "E03-8036") {
			// 	resolvePromisePC(deferred, {data : nv3YesNbdNo33eNo, headers : function(fn){return 0;}}, {deleteNv3:true}, 'POST');
			// }
			// else if(url.substr(-3) === "NBD" 
			// 	&& $PolicyChange.$get().policyChange().currentPolicy.policyNumber === "E03-8036"){
			// 	// si 33E est déjà à yes
			// 	if( _33eSelected ) {
			// 		resolvePromisePC(deferred, {data : nv3YesNbdNo33eNo, headers : function(fn){return 0;}}, {deleteNv3:true}, 'POST');
			// 	}

			// 	// si tout était à no
			// 	else {
			// 		resolvePromisePC(deferred, {data : nv3NoNbdYes33eNo, headers : function(fn){return 0;}}, {deleteNv3:true}, 'POST');
			// 	}

			// } else if(url.substr(-3) === "33E" 
			// 	&& $PolicyChange.$get().policyChange().currentPolicy.policyNumber === "E03-8036") {

			// 	if(_nbdSelected) {
			// 		resolvePromisePC(deferred, {data : nv3YesNbdNo33eNo, headers : function(fn){return 0;}}, {deleteNv3:true}, 'POST');
			// 	}
			// 	else {
			// 		resolvePromisePC(deferred, {data : nv3NoNbdNo33eYes, headers : function(fn){return 0;}}, {deleteNv3:true}, 'POST');
			// 	}
			// } else {
			$CoreRestApiService.post(cleanUrl, cleanUpData(payLoad), _options).then(function(r){
				resolvePromisePC(deferred, r, _options, 'POST');
			}, function(e){
				rejectHttpExceptions(e, deferred);
			});
		// }

			return deferred.promise;
		};

		this.get = function(url, _options){
			var deferred = $q.defer(),
				cleanUrl = getUrl(url, _options);
			_options.webserviceTimeout = TIMEOUT;
			
			$CoreRestApiService.get(cleanUrl, _options).then(function(r){
				resolvePromisePC(deferred, r, _options, 'GET');
			}, function(e){
				rejectHttpExceptions(e, deferred);
			});

			return deferred.promise;
		};

		this.delete = function(url, _options){
			var deferred = $q.defer(),
				cleanUrl = getUrl(url, _options);
			
			//TODO REMOVE AFTER POC
			// var _33eSelected = $filter('filter')($PolicyChange.$get().policyChange().policyChange.vehicles[0].coverages, {code : '33E'})[0].selected;
			// var _nbdSelected = $filter('filter')($PolicyChange.$get().policyChange().policyChange.vehicles[0].coverages, {code : 'NBD'})[0].selected;

			// if( url.substr(-3) === "NV3" || url.substr(-3) === "NBD" || url.substr(-3) === "33E" 
			// 	&& $PolicyChange.$get().policyChange().currentPolicy.policyNumber === "E03-8036") {
			// 	resolvePromisePC(deferred, {data : nv3NoNbdNo33eNo, headers : function(fn){return 0;}}, {deleteNv3:true}, 'DELETE');
			// } 
			// else{
			$CoreRestApiService.delete(cleanUrl, _options).then(function(r){
				// IE issue. On IE we don't receive the data as a JSON object. 
				// Need to manualy parse the string.
				if(!_.isObject(r.data) && !_.isEmpty(r.data)){
					require()
					r.data = JSON.parse(r.data);
				}
				resolvePromisePC(deferred, r, _options, 'DELETE');
			}, function(e){
				rejectHttpExceptions(e, deferred);
			}); 
		// }

			return deferred.promise;
		};

		// Private functions
		function resolvePromisePC(deferred, r, options, httpVerb){
			
			updateTimeStamp(r);
			updateValidation(r);

			if (isDataValid(r.data, options)){
				//TODO FOR POC -- REMOVE AFTER DEVELOPPEMENT
				// if(r.data.response && r.data.response.policyNumber === "E03-8036"
				// 	&& r.data.state.currentPage == "PC_COV") {

				// 	if(!options.deleteNv3) {
				// 		r.data = nv3YesNbdNo33eNo;
				// 	}

		  //           var pcModel = new PolicyChangeModel(r.data);

		  //           $PolicyChange.update(pcModel);

				// }
				return deferred.resolve(r);	
			}
			else{
				return rejectBusinessExceptions (r, httpVerb, options, deferred);
			}
		}

		function updateTimeStamp(r){
            
            if(r.headers("ETag")){
				$PolicyChange.updateTimeStamp(r.headers("ETag"));
			}
        }

        function updateValidation(r){
        	if(r.data && r.data.validation){
				$PolicyChangeValidation.update(r.data.validation, $rootScope);
			}
		}

		function rejectHttpExceptions (e, deferred){
			if(isStatusError(e.status)){
				$PCStateManagerService.gotoErrorPage(e);
			}
			else if(isStatusConcurrency(e.status)){
				$PCStateManagerService.goToConcurrencyRdblk();
			}

			$PCStateManagerService.hideLoader();

			deferred.reject(e);
		}

		function rejectBusinessExceptions (r, httpVerb, options, deferred){
			var data = r.data;
			var ignoreErrors = getParamIgnoreErrors(options);
			var reloadData = getOptionReloadData(options);
			var isBasicValidationOverriden = getBasicValidationOverridenFlag(options);

			$PCStateManagerService.hideLoader();
			
            getAssignations(data, httpVerb, deferred);
            getHardRoadBlocks(data, ignoreErrors);
            getSoftRoadBlocks(r, httpVerb, ignoreErrors, deferred, reloadData);
            getValidationErrors(data, httpVerb, ignoreErrors, deferred, isBasicValidationOverriden);
		}

		function getAssignations(data, httpVerb, deferred){
			var validation = data.validation || {};
			var hasAssignations = validation.resultType === 'ASSIGNATION_ROADBLOCKS';
			
			if(hasAssignations && (httpVerb === 'PUT' || httpVerb === 'GET')) {
                var assignationRoadBlocks = $PCValidationService.getRoadblocks(validation.roadBlocks, 'ASS');

                var rejectObject = {
                    hasAssignationRoadBlockErrors : true,
                    errors : assignationRoadBlocks,
                    policyChange : data.response.policyChange
                };

               	$rootScope.$emit('showAssignationPanel', rejectObject);

               	deferred.reject(rejectObject);
            }
		}

		function getHardRoadBlocks(data, ignoreErrors){
			var validation = data.validation || {};
			
			// TODO: temporary fix: when rate could not be calculated we have to display HardRoadBlock when we are not on the same page
			if((isRoadBlockCritical(data) || validateSamePage(data, ignoreErrors) || $rootScope.helpers.state.currentPage.data.page === "PC_START")
				&& hasRoadBlocks(data, 'HARD_ROADBLOCKS')){
				var errorContext = manageHardRoadblock(validation);
				if(errorContext.hasOwnProperty('hasHardRoadBlockErrors')  && errorContext.hasHardRoadBlockErrors){
					saveData(data);
					$PCStateManagerService.goToHardRoadBlock(errorContext);
				}
            }
		}

		function getSoftRoadBlocks(r, httpVerb, ignoreErrors, deferred, reloadData){
			var data = r.data;
			var validation = data.validation || {};
			var hasSoftRoadBlocks = hasRoadBlocks(data, 'SOFT_ROADBLOCKS');
			
			if(validateSamePage(data, ignoreErrors) && hasSoftRoadBlocks && (httpVerb === 'PUT' || httpVerb === 'POST' || httpVerb === 'DELETE')){ 
                var softRoadBlocks = $PCValidationService.getRoadblocks(validation.roadBlocks, 'SOFT');
                
                if(softRoadBlocks.length > 0){
                    $InlineValidationService.triggerSoftRoadBlockValidation(softRoadBlocks);
                    if(reloadData){
                    	return deferred.resolve(r);	
                    }
                }
            } 
		}

		function getValidationErrors(data, httpVerb, ignoreErrors, deferred, isBasicValidationOverriden){
			var validation = data.validation || {};
			var hasValidationError = validation.resultType === 'VALIDATION_ERRORS';

			if(validateSamePage(data, ignoreErrors) && hasValidationError && (httpVerb === 'PUT' || httpVerb === 'POST')){
                if(!isBasicValidationOverriden){
                	$InlineValidationService.triggerValidation(validation.errors);
                }

                var rejectObject = {
                    hasValidationError : true,
                    errors : validation.errors
                };

                deferred.reject(rejectObject);
            } 
		}

		function validateSamePage(data, ignoreErrors){
			var state = data.state || {};
			return (state && !$PCStateManagerService.isDifferentPage(state) ) && !ignoreErrors; 
		}

		function hasValidationErrors (data, ignoreErrors){
			var hasErrors = false;

			try{
				if(data.validation.resultType === 'VALIDATION_ERRORS' && !ignoreErrors){
					hasErrors = true;
				}
			}
			catch(err){
				hasErrors = false;
			}
			return hasErrors;
		}

		function isDataValid(data, options){
			var ignoreValidationErrors = getParamIgnoreErrors(options);
			var hasInlineErrors = hasValidationErrors(data, ignoreValidationErrors),
                hasHardRoadBlocks = hasRoadBlocks(data, 'HARD_ROADBLOCKS'),
                hasSoftRoadBlocks =  hasRoadBlocks(data, 'SOFT_ROADBLOCKS'),
                hasAssignations = hasRoadBlocks(data, 'ASSIGNATION_ROADBLOCKS');
			
			var hasBusinessExceptions = hasInlineErrors || hasHardRoadBlocks || hasSoftRoadBlocks || hasAssignations;
			
			return !hasBusinessExceptions;
		}

		function cleanUpData(pData){
			var data = angular.copy(pData);

			if(data && data.hasOwnProperty('$key')){
				delete data.$key;
			}

			return data;
		}

		function getUrl (url, _options){
			if(_options && _options.placeHolders){
				url = $uriWithParams(url, _options.placeHolders);
				delete _options.placeHolders;
			}

			return url;
		}

		function isStatusError (status){
			var errorCodes = [500, 412];

			return errorCodes.indexOf(status) >= 0;
		}

		function isStatusConcurrency (status){
			return status === 403; 
		}

		function hasRoadBlocks (data, type){
			var hasRoadblock = false;
			try{
				if(data.validation.hasOwnProperty('roadBlocks')){
					hasRoadblock = data.validation.roadBlocks !== null ? data.validation.resultType === type : false;
				}
			}
			catch(error){
				hasRoadblock = false;
			}

			return hasRoadblock;
		}

		function isRoadBlockCritical (data){
			var isRoadBlockCritical = false;
			try{
				if(data.validation.hasOwnProperty('roadBlocks') &&  data.validation.roadBlocks != null){
					isRoadBlockCritical = _.some(data.validation.roadBlocks,function(roadBlock){ return roadBlock.code === "BR1228_NOT_RECALCULATED_POLICY";});
				}
			}
			catch(error){
				isRoadBlockCritical = false;
			}

			return isRoadBlockCritical;

		}

        function getOptionReloadData(options){
            if (!angular.isUndefined(options) && !angular.isUndefined(options.reloadData)){
                return options.reloadData;
            }

            // default value
            return false;
        }
        
        function getParamIgnoreErrors(options){
            if (!angular.isUndefined(options) && !angular.isUndefined(options.params) && !angular.isUndefined(options.params.ignoreErrors)){
                return options.params.ignoreErrors;
            }

            // default value
            return false;
        }			

		function manageHardRoadblock (validation){
			var hardRoadBlocks = $PCValidationService.getRoadblocks(validation.roadBlocks, 'HARD');
			var rejectObject = {
			    hasHardRoadBlockErrors : true,
			    hardRoadBlockState: 'app.hardRoadBlock',
			    errors : hardRoadBlocks
			};

			return rejectObject;
		}

		function saveData(data){
            // Update the new policy change provider
            var pcModel = new PolicyChangeModel(data);

            $PolicyChange.update(pcModel);
            $PolicyChangeState.update(pcModel.state);
        }

        function getBasicValidationOverridenFlag(options){
        	if (!angular.isUndefined(options) && !angular.isUndefined(options.basicValidationOverriden)){
                return options.basicValidationOverriden;
            }
        	return false;
        }
	}

})(angular);