(function(angular){
	'use strict';

	angular.module('INTACT.PolicyChange').service('$PCCoveragesService', service);

	function service($PCAppConfiguration, 
					 $PCCoreService,
					 $PolicyChange,
					 $filter){
		var policyNumber = $PCAppConfiguration.policyNumber,
			restApiUrl = '/policy/:polycyNumber/risk/:riskSequence/coverage/:coverageCode';


		this.put = function(riskSequence, coverageCode, data){
			var url =  getUrl(riskSequence, coverageCode);
			var options = getOptions();

			return $PCCoreService.put(url, data, options);
		};

		this.post = function(riskSequence, coverageCode, data){
			var url = getUrl(riskSequence, coverageCode);
			var options = getOptions();

			return $PCCoreService.post(url, data, options);
		};

		this.delete = function(riskSequence, coverageCode){
			var url = getUrl(riskSequence, coverageCode);
			var options = getOptions();

			return $PCCoreService.delete(url, options);
		};

		// Private functions
		function getOptions(){
			var options = {
	                cache : 'coverages',
	                headers: {'If-Match': $PolicyChange.$get().getTimeStamp()},
	                reloadData: true
            };
            return options;
		}

		function getUrl(riskSequence, coverageCode){
			var url = $filter('uriWithParams')(restApiUrl, 
			{
				polycyNumber: policyNumber,
				riskSequence: riskSequence,
				coverageCode: coverageCode
			});
			return url;
		}
	}
})(angular);