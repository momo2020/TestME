(function(angular){
	'use strict';

	/**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:$WorkSectorService
     *
     * @description
     * Work sector list from back-end depending on the effective date
     * @example
     * <pre>
     * // In controller
     * MyModule.controller(function($WorkSectorService){
     * 		
     * 	});
     * });
     * </pre>
     * 
     **/
	angular.module('INTACT.PolicyChange').service('$WorkSectorService', service);
	
	function service($q, $PCCoreService, $PCAppConfiguration, WorkSectorModel) {
		
        /**
         * @ngdoc method
         * @name $InitializationService#getOccupation
         * @methodOf INTACT.PolicyChange.service:$WorkSectorService
         * @description
         * Get List of occupation
         * @return {Object} AngularJs Promise
         */

        this.getOccupations = function(workSectorSelected, effectiveDate){
            var url = "/misc/workSectors/:sectorCode/occupations/:effectiveDate",
                deferred = $q.defer(),
                props = {
                    placeHolders : {
                        sectorCode : workSectorSelected,
                        effectiveDate : effectiveDate
                    },
                    cache : 'policychange-occupation'
                };
            $PCCoreService.get(url, props).then(function(r){
                if(r.data){
                    deferred.resolve(new WorkSectorModel(r.data));
                }
                else{
                    deferred.reject(r);
                }
            });

            return deferred.promise;
        };

	}
})(angular);