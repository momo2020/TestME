(function(angular){
	'use strict';

	/**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:$InitializationService
     *
     * @description
     * Initialization Service
     * @example
     * <pre>
     * // In controller
     * MyModule.controller(function($InitializationService){
     * 		
     * 	});
     * });
     * </pre>
     * 
     **/
	angular.module('INTACT.PolicyChange').service('$InitializationService', service);
	
	function service($q, 
                    InitializationModel, 
                    PolicyChangeModel,  
                    $PCAppConfiguration, 
                    $PCStateManagerService, 
                    $PCValidationService,
                    $filter, 
                    $log, 
                    $state,
                    $PCCoreService) {
		var url = '/policy/:policyNo/initialization',
            cacheObj = {cache: 'policychange'},
            $urlFilter = $filter('uriWithParams');

        /**
         * @ngdoc method
         * @name $InitializationService#get
         * @methodOf INTACT.PolicyChange.service:$InitializationService
         * @param {String} policyNo Policy Number
         * @description
         * Get transation information from REST API
         * @return {Object} AngularJs Promise
         */
        this.get = function(policyNo) {

            var deferred = $q.defer(),
                options = {
                    placeHolders : {policyNo : policyNo},
                    cache : 'policychange'
                };
            $PCCoreService.get(url, options).then(function(r){
                if(r.data){
                    deferred.resolve(new InitializationModel(r.data));
                }
                else{
                    deferred.reject($log.warn('InitializationService : response.data is missing'));
                }
            });

            return deferred.promise;
    	}; 
      
        /**
         * @ngdoc method
         * @name $InitializationService#put
         * @methodOf INTACT.PolicyChange.service:$InitializationService
         * 
         * @param {String} policyNo Policy Number
         * @param {Object} initializationDTO Initialization Object
	     * @param {string} gotoPage Specify action triggered other than continue btn

         * @description
         * Put transation information from REST API
         * @return {Object} AngularJs Promise
         */ 

        this.put = function(policyNo, initialization, gotoPage) {
            var pUrl = $urlFilter(url, {policyNo : policyNo});
            pUrl = gotoPage ? pUrl + '?goto='+gotoPage : pUrl;

            return $PCCoreService.put(pUrl, initialization, cacheObj)
                .then(function(r) {
                    var data = r.data,
                        state = data.state;

                    if(state && $PCStateManagerService.validStateOrRedirect(state)){
                        return { 
                                'state'         : new InitializationModel(data),
                                'policyChange'  : new PolicyChangeModel(data)
                               };
                    }
                     else {
                        $log.warn('InitializationService : invalid state');
                    }
                });
        };

        /**
         * @ngdoc method
         * @name $InitializationService#post
         * @methodOf INTACT.PolicyChange.service:$InitializationService
         * @param {String} policyNo Policy Number
         * @param {Object} initialization Initialization Object
         * @param {string} gotoPage Specify action triggered other than continue btn
         * @description
         * Post transation information from REST API
         * @return {Object} AngularJs Promise
         */
        this.post = function(policyNo, initialization, gotoPage) {
            var poUrl = $urlFilter(url, {policyNo : policyNo});
            poUrl = gotoPage ? poUrl + '?goto='+gotoPage : poUrl;
            
            return $PCCoreService.post(poUrl, initialization, cacheObj)
                .then(function(r) {

                    var data = r.data,
                        state = data.state;  
                    
                    if(state && $PCStateManagerService.validStateOrRedirect(state)){
                        return { 
                                'state'         : new InitializationModel(data),
                                'policyChange'  : new PolicyChangeModel(data)
                               };
                    }
                    else {
                        $log.warn('InitializationService : invalid state');
                    }
                });
        };

        /**
         * @ngdoc method
         * @name $InitializationService#save
         * @methodOf INTACT.PolicyChange.service:$InitializationService
         * @param {String} policyNo Policy Number
         * @param {Object} initialization Initialization Object
         * @param {Object} stateDto Application State Object
         * @param {string} gotoPage Specify action triggered other than continue btn. 'Next' for initialization.
         * @description
         * Save transation information from REST API 
         * put method when transactionInitialized is true, post otherwise 
         * @return {Object} AngularJs Promise
         */

        this.save = function(policyNo, initialization, stateDto, _gotoPage) {
            $PCStateManagerService.showLoader();
            
            var deferred = $q.defer(),
                isInitialized = stateDto.transactionInitialized,
                gotoPage = _gotoPage ? _gotoPage : null;

            if(isInitialized) {
                this.put(policyNo, initialization, gotoPage).then(function(r){
                    deferred.resolve(r.state);
                });
            } else {
                this.post(policyNo, initialization, gotoPage).then(function(r){
                    deferred.resolve(r.state);  
                });
            }

            return deferred.promise;
        };
	}
})(angular);