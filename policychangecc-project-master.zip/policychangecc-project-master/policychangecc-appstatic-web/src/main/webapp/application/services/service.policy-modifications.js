(function(angular){
    'use strict';

    /**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:$PolicyModificationsService
     *
     * @description
     * Policy Change Modifications Service
     * Returns the information from a comparison between the current and the policy change
     * @example
     * <pre>
     * // In controller
     * MyModule.controller(function($PolicyModificationsService){
     *
     *  });
     * });
     * </pre>
     *
     **/
    angular.module('INTACT.PolicyChange').service('$PolicyModificationsService', service);

    function service($PCAppConfiguration, 
                    $PCCoreService, 
                    $PCStateManagerService,
                    PolicyChangeModificationsModel, 
                    $PolicyChangeModifications, 
                    $q) {

        var policyNumber = $PCAppConfiguration.policyNumber,
            url = '/policy',
            modificationsProvider = $PolicyChangeModifications.$get();

        // Exposed
        return {
            get : get
        };

         /**
         * @ngdoc method
         * @name $PolicyChangeService#get
         * @methodOf INTACT.PolicyChange.service:$PolicyChangeService
         *
         * @description
         * Get distribution information from REST API
         * @return {Object} AngularJs Promise
         */
        function get(){
            var deferred = $q.defer();
            var options =  {
                cacheDisabled: true,
                params: {}
            };
            var service = url +"/"+ policyNumber + "/modifications";

           $PCCoreService.get(service, options).then(function(success){

                // Send the data through the model
                var data = new PolicyChangeModificationsModel(success.data);

                // Update the provider
                modificationsProvider.update(data);

                // Resolve
                deferred.resolve(data);
            });

           return deferred.promise;
        }
    }
})(angular);
