(function(angular){
	'use strict';

	/**
     * @ngdoc service
     * @name INTACT.PolicyChange.service:$ScheduleCallService
     *
     * @description
     * Create a work item when schedule a call
     * @example
     * <pre>
     * // In controller
     * MyModule.controller(function($ScheduleCallService){
     * 		
     * 	});
     * });
     * </pre>
     * 
     **/
	angular.module('INTACT.PolicyChange').service('$ScheduleCallService', service);
	
	function service($q, 
                $PCCoreService, 
                $PolicyChange) {
		
        /**
         * @ngdoc method
         * @name $InitializationService#createSchedule
         * @methodOf INTACT.PolicyChange.service:$ScheduleCallService
         * @description
         * Create a work item when client schedule a call
         * @return {Object} AngularJs Promise
         */

        this.createSchedule = function(scheduleData){
            var url = "/misc/callback",
                deferred = $q.defer(),
                props = {
                    cache : 'policychange-schedule-call',
                    headers: {'If-Match': $PolicyChange.$get().getTimeStamp()},
                    basicValidationOverriden: true
                };

            $PCCoreService.post(url, scheduleData, props).then(function(r){
                deferred.resolve();
            }, function(rejectObject){
                deferred.reject(rejectObject);
            });

            return deferred.promise;
        };

	}
})(angular);