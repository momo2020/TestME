(function(angular){
    'use strict';

    /**
     * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccConfirmationMessage
     * @description
     * Directive to display confirmation messages. Default behavior: The confirmation message will be displayed
     * for 3 seconds.
     * @param {String}  eventId             Event id used for the listener to be attached. Default value 'defaultEventId'.
     * @param {Integer} secondsDisplayed    Number of seconds the message to be displayed. Default value '3'.
     * @param {Boolean} disableTimer        If 'true' the message will be allways visible. Default value 'false'.
     * @param {String}  message             The message to be displayed as is. Message will not be translated.
     * @param {String}  messageLabel        The messageLabel key to be translated. Key must exists in the language dictionary.
     *
     * Example
     * <pre>
     *  Diffrent implementations on Html page:
     *  <cc-confirmation-message />
     *  <cc-confirmation-message message='Dummy message to be displayed'/>
     *  <cc-confirmation-message message-label='LBL41815.car.principal.driver'/>
     *  <cc-confirmation-message disable-timer='true'
     *                           message-label='LBL41815.car.principal.driver'/>
     *  <cc-confirmation-message event-id='eventCustomId' 
     *                           seconds-displayed='7' 
     *                           message-label='LBL41815.car.principal.driver'/>
     *
     * To trigger the event we have to use the 'eventId' attribute. If 'eventId' was not provided, we use de default one: 'defaultEventId'.
     * $scope.$emit('defaultEventId'); // when default event id is used.
     * $scope.$emit('eventCustomId');  // when event id is provided with the directive.
     * $scope.$emit('eventCustomId', {message: 'Dummy message to be displayed'});  // when message attribute is not provided with the directive.
     * $scope.$emit('eventCustomId', {messageLabel: 'LBL41815.car.principal.driver'});  // when messageLabel attribute is not provided with the directive.
     * </pre>
     */
    angular.module('INTACT.PolicyChange').directive('ccConfirmationMessage', function($rootScope, $PCAppConfiguration) {

        return {
            restrict: 'AE',
            controller: Controller,
            controllerAs : '$ctrl',
            replace: true,
            scope:{
                eventId: '@?',
                disableTimer: '@',
                secondsDisplayed: '=?',
                message: '@',
                messageLabel: '@'

            },
            templateUrl: $PCAppConfiguration.directivesViewsPath + '/confirmation-message.html',
        };

        function Controller ($filter, $PCAppConfiguration, $scope, $timeout){
            

            var vm = this;
            vm.isVisible = false;    

            setDefaultValues();
            
            setEventListener();



            function setDefaultValues (){
                var defaultSecondsDisplayed = 3;
                var defaultDisableTimer = false;
                var defaultEventId = 'defaultEventId';

                if(!angular.isDefined($scope.eventId)){
                    $scope.eventId = defaultEventId;
                }

                if (!angular.isDefined($scope.secondsDisplayed)){
                    $scope.secondsDisplayed =  defaultSecondsDisplayed;
                }

                if (!angular.isDefined($scope.disableTimer)){
                    $scope.disableTimer =  defaultDisableTimer;
                }

                if(angular.isDefined($scope.messageLabel)){
                    translateMessage($scope.messageLabel);
                }
            }

            function setEventListener(){
                $rootScope.$on($scope.eventId, function(event, args){
                    if(angular.isDefined(args) && angular.isDefined(args.messageLabel)){
                        translateMessage(args.messageLabel);
                    }
                    if(angular.isDefined(args) && angular.isDefined(args.message)){
                        $scope.message = args.message;
                    }

                    showConfirmationMessage($scope.secondsDisplayed);
                });
            }

            function showConfirmationMessage (seconds){

                vm.isVisible = true;

                // set display timer if any
                if(!$scope.disableTimer){
                    $timeout(function () {
                        vm.isVisible = false; 
                        }, seconds*1000); 
                }
            }

            function translateMessage (messageLabel){
                 $scope.message = $filter('translate')(messageLabel);
            }

        }
    });

 })(angular);
