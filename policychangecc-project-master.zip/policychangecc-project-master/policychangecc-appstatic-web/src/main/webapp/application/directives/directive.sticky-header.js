(function(angular){
	'use strict';

    /**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccStickyHeader
     * @restrict A
     * @priority 0
     * @requires https://docs.angularjs.org/api/ng/service/$window
     * 
     * @description
     * Initialize && configure sticky HTML header.
	*/
	angular.module('INTACT.PolicyChange').directive('ccStickyHeader', function($window){
		return {
			restrict: 'A',
			priority: 0,
			replace: false,
			link: function(scope, element, attrs){
                var $header = angular.element('.main-header', element),
                    points = scope.$eval(attrs.points),
                    lastPageOffSet = 0;

                // Initial state
			    for(var p in points) {
                    if($window.pageYOffset > parseInt(p)){
                        $header.addClass(points[p]);
                    }
                }

                // Scroll listener
                angular.element($window).on('scroll', function(){
                    var pageOffSet = $window.pageYOffset,
                        p = null;

                    if (pageOffSet > lastPageOffSet){     
                        // Stick
                        for(p in points) {
                            if(pageOffSet > parseInt(p)){
                                $header.addClass(points[p]);
                            }
                        }
                     } else {
                        // Stick
                        for(p in points) {
                            if(pageOffSet < parseInt(p)){
                                $header.removeClass(points[p]);
                            }
                        }
                    }

                    lastPageOffSet = pageOffSet;
                });
			}
		};
	});
})(angular);