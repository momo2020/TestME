(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:pcPremiumHeader
     * @restrict A
     * 
     * @description
     * Premium Table Header template for reuse
     * 
     * @example
     * <pre>
     * <th pc-premium-header data-header-title="{{'LBL01453.premium' | translate }}" data-premium="{{PremiumCtrl.annualPremium}}"></th>
     * </pre>
	 */
	angular.module('INTACT.PolicyChange').directive('pcPremiumHeader', function($PCAppConfiguration){
		return {
			restrict: 'A',
			templateUrl: $PCAppConfiguration.directivesViewsPath + '/premium-header.html',
			scope: {
                headerTitle: '@',
                premium: '@',
                id: '@'
            }
		};
	});

})(angular);