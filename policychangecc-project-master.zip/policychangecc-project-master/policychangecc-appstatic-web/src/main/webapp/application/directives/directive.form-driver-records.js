(function(angular){
    'use strict';

    /**
     * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccFormCarAbout
     */
    angular.module('INTACT.PolicyChange').directive('pcFormDriverRecords', function($PCAppConfiguration) {

        return {
            restrict: 'AE',
            priority: 0,
            controller: Controller,
            controllerAs : '$ctl',
            require: 'ngModel',
            templateUrl: function(){
              var province = $PCAppConfiguration.province.toLowerCase();
              return $PCAppConfiguration.directivesViewsPath + '/form-driver-records-' + province + '.html';
            },
            scope: {
                ngModel     : "=",
                driverIndex : "=",
                isNewDriver : "=",
                currDriverLicence : "="
            }
        };

        function Controller($scope, $filter){
            var vm = this,
                $translate = $filter('translate'),
                originalLicenceType = getOriginalLicenceType();

            vm.ngModel = $scope.ngModel;
            vm.isNewDriver = $scope.isNewDriver;
            vm.currDriverLicence = $scope.currDriverLicence;
            vm.driverIndex = $scope.ngModel.driver.driverIndex;
            vm.originalLicenceType = originalLicenceType;

            vm.driverLicenceDate = {
                year: $scope.ngModel.driver.licenceObtentionDate !== "" ? $scope.ngModel.getDateOfBirth('year', $scope.ngModel.driver.licenceObtentionDate).toString() : null,
                month:$scope.ngModel.driver.licenceObtentionDate !== "" ? $scope.ngModel.getDateOfBirth('month',$scope.ngModel.driver.licenceObtentionDate).toString() : null
            };

            /*TODO -- Peut être placé à un meilleur endroit? (driverLicenceType et driverLicence12months s'en servent)*/
            vm.showLicence12Months = function (){
              var licence = vm.currDriverLicence[vm.driverIndex];
              var driver = vm.ngModel.driver;
              var isShow = false;

              if( vm.isNewDriver && angular.isDefined(driver)){
                isShow = (driver.driverLicenceType ==='R' || driver.driverLicenceType ==='P');
              }
              else if( angular.isDefined(licence) && angular.isDefined(driver)){
                if ( licence.licenceType === 'L' && driver.driverLicenceType === 'P' || 
                      licence.licenceType === 'P' && driver.driverLicenceType === 'R') {
                    isShow = true;
                }
              }
              // set flag for obtainedG2OrGDisplayed
              vm.ngModel.driver.obtainedG2OrGDisplayed = isShow;

              return isShow;
            };

            $scope.currDriverLicence = $scope.currDriverLicence !== undefined ? $filter('orderBy')($scope.currDriverLicence, 'driverIndex') : [];

            // Get the list of years ()
            var getGorG2Years = function(){
              var years = [];
              var currentYear = new Date().getFullYear();
              years.push({key: currentYear.toString(), value: currentYear.toString()});
              years.push({key: (currentYear-1).toString(), value: (currentYear-1).toString()});
              return years;
            };

            vm.combos = {
                gOrg2Years      : getGorG2Years()
            };

            vm.labels = {
              title         : $translate('LBL00109.driver.record.title')
            };

            vm.driverLicenceType = $scope.ngModel.driver.driverLicenceType;

            vm.g2LicenceDate = {year: null, month: null};

            vm.licenceLastFiveYears = false;
           
            function getOriginalLicenceType(){
              if($scope.currDriverLicence[$scope.driverIndex] && $scope.currDriverLicence[$scope.driverIndex].licenceType){
                return $scope.currDriverLicence[$scope.driverIndex].licenceType;
              }
              return null;
            }

            //Watch the data change 
            $scope.$watch('$ctl.driverLicenceDate', function(){
              //$scope.ngModel.updateLicenseObtainedDate(vm.driverLicenceDate);
              if( vm.driverLicenceDate.year !== null && vm.driverLicenceDate.month !== null ){
                $scope.ngModel.updateDriverDate("licenceObtentionDate", vm.driverLicenceDate);
                vm.licenceLastFiveYears = $scope.ngModel.licenceObtained5YearsOrLess();
              }
              else{
                vm.driverLicenceDate = { year : null, month : null };
              }
            }, true);


            $scope.$watch('$ctl.g2LicenceDate', function(){
              if( vm.g2LicenceDate.year !== null && vm.g2LicenceDate.month !== null ){
                $scope.ngModel.updateDriverDate("g2LicenceDate", vm.g2LicenceDate);
              }
              else{
                vm.g2LicenceDate = { year : null, month : null };
              }             
            }, true);


        }
    });
})(angular);
