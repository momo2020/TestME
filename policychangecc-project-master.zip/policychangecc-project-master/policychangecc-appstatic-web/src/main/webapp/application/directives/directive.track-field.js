(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccTrackField
     * @restrict A
     * @requires https://docs.angularjs.org/api/ng/service/$timeout
     * @requires https://docs.angularjs.org/api/ng/service/$filter
     *
     * @description
     * Directive to track events on an input field
	 */
	angular.module('INTACT.PolicyChange').directive('pcTrackField', function($PCAnalyticsService, $PolicyChange, $filter) {
		var counter = 0;
		var currentAction = "";

		return {
			restrict: 'A',
			link: function(scope, ele, attrs){
				var props = {};

				ele.bind('focus', function() {
					counter++;

					var PolicyChangeData = $PolicyChange.$get().policyChange();
					var currentPage = PolicyChangeData.state.currentPage;

					var currentPagePosition = $filter('getStep')(currentPage);
					var currentPageName = $filter('getStep')(currentPage, true);

					var getCtrlForm = scope.$parent.$ctrl ? scope.$parent.$ctrl : "";

					// target if new driver OR new car
					if(scope.isNewDriver === true || scope.isReplaceCar === false) {
						currentAction = "add started";
					} else if (getCtrlForm.showChangeDriversAssignments === true) {
						currentPageName = "drivers assignment warning";
						currentAction = "";
					} else {
						currentAction = "update started";
					}

					// Dont track field analytics in button, but reset the counter
					if(attrs.type === "button") {
						counter = 0;
					} else {
						props = {
							s_appStep: "pu:" + currentPagePosition + ":" + currentAction,
							s_pageName: "portfolio:policy update:" + currentPageName,
							s_btnName: "pu:" + attrs.id + ":" + counter
						};

						$PCAnalyticsService.trackPageView(props);
					}
				});
			}
		};
	});

})(angular);
