(function(angular){
    'use strict';

    /**
     * @ngdoc directive
     * @name INTACT.PolicyChange.directive:pcDriverClaims
     */
    angular.module('INTACT.PolicyChange').directive('pcDriverClaims', function($PCAppConfiguration) {

        return {
            restrict: 'AE',
            priority: 0,
            controller: Controller,
            controllerAs : '$ctrl',
            require: 'ngModel',
            templateUrl: $PCAppConfiguration.directivesViewsPath + '/driver-claims.html',
            scope: {
                ngModel : '=',
                driverIndex : '@',
                claimIndex : '@',
                validationIndex : '@',
                removeVisible : '@',
                removeClaim  : "&"
            }
        };

        function Controller ($filter, $PCAppConfiguration, $scope, $PolicyChangeState){
            var vm = this;
            vm.labelClaimsWhen = $filter('translate')('LBL12251.driver.claims.when');
            vm.combos = {
                claimNature : $filter('comboList')('claimNature'),
                claimNatureYear : $filter('comboList')('claimNatureYear')
            };
            vm.combos.claimNature.unshift({key : "", value : $filter('translate')('LBLXXXX.car.select')});
            vm.combos.claimNatureYear.unshift({key : "", value : $filter('translate')('LBLXXXX.car.select')});
            vm.removeClaim = removeClaim;
            // Ontario only
            vm.isAtFaultAfterJune2016 = isAtFaultAfterJune2016;
            vm.resetClaim = resetClaim;
            vm.needClaimDetail = needClaimDetail;
            // Quebec only
            vm.setDefaultAmount = setDefaultAmount;

            /**
            * For Ontario only
            * @ngdoc method
            * @name INTACT.PolicyChange.directive:pcDriverClaims#isAtFaultAfterJune2016
            * @methodOf INTACT.PolicyChange.directive:pcDriverClaims
            * @description
            * Display Radio questions when true
            */
            function isAtFaultAfterJune2016() {
                if($PCAppConfiguration.province.toLowerCase() != 'on'){
                    return false;
                }

                if(!angular.isDefined($scope.ngModel)){
                    return false;
                }
               
                if($scope.ngModel.nature != "AA" && $scope.ngModel.nature != "AAF"){
                    return false;
                }

                if($scope.ngModel.dateCode === ""){
                    return false;
                }

                var today = $PolicyChangeState.$get().state().effectiveDateMin;
                var dateArray = today.split('-');
                var year = parseInt(dateArray[0]),
                    monthJS = parseInt(dateArray[1])-1,
                    day = parseInt(dateArray[2]);

                // DateCode key is used to get the numbers of year. If it changes the code must be updated too
                var claimYearsMin = parseInt($scope.ngModel.dateCode);
                var claimDateMin = new Date(year-claimYearsMin , monthJS, day, 0, 0, 0, 0);
                var june2016Date = new Date(2016, 5, 1, 0, 0, 0, 0);

                return claimDateMin>june2016Date;
            };

            // For Ontario only
            function resetClaim(){
                if(!vm.isAtFaultAfterJune2016()){
                    $scope.ngModel.accidentAfterJuin1 = null;
                    $scope.ngModel.insurerPaidForDamage = null;
                    $scope.ngModel.damageAmountExceeded2000 = null;
                    $scope.ngModel.personHurtInAccident = null;
                }
                if(!$scope.ngModel.accidentAfterJuin1){
                    $scope.ngModel.insurerPaidForDamage = null;
                    $scope.ngModel.damageAmountExceeded2000 = null;
                    $scope.ngModel.personHurtInAccident = null;
                }
            };

            /**
            * For Ontario only
            * @ngdoc method
            * @name INTACT.PolicyChange.directive:pcDriverClaims#needClaimDetail
            * @methodOf INTACT.PolicyChange.directive:pcDriverClaims
            * @description
            * Display Claim detail section
            */
            function needClaimDetail(){
                if(angular.isDefined($scope.ngModel)){
                    return vm.isAtFaultAfterJune2016() && $scope.ngModel.accidentAfterJuin1;
                }
                return false;
            };
            
            /**
            * For Quebec only
            * @ngdoc method
            * @name INTACT.PolicyChange.directive:pcDriverClaims#setDefaultAmount
            * @methodOf INTACT.PolicyChange.directive:pcDriverClaims
            * @description
            * Sets the default amount for type in Qc
            **/
            function setDefaultAmount(){
                if($PCAppConfiguration.province.toUpperCase() === 'QC'){
                    $scope.ngModel.amount = $filter('defaultAmountClaimQc')($scope.ngModel.nature);
                }
            };

            /**
            * @ngdoc method
            * @name INTACT.PolicyChange.directive:pcDriverClaims#removeClaim
            * @methodOf INTACT.PolicyChange.directive:pcDriverClaims
            * @description
            * Trigger remove claim function from the parent when click on remove link
            */
            function removeClaim(claimIndex){
                var index = parseInt(claimIndex);
                $scope.removeClaim({
                    claimIndex: index
                });
            };
        }
    });

 })(angular);
