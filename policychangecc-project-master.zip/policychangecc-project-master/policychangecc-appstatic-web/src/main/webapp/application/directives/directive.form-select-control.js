(function(angular){
    'use strict';

    /**
     * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccFormSelectControl
     * @restrict AE
     * @requires INTACT.PolicyChange.$PCAppConfiguration
     *
     * @description
     * Handles the display of a select control
     *
     * @example
     * <pre>
     * // In controller
     * angular.module('PC').controller('$crtl', ctrl);
     *
     * function ctrl(){
     *   var vm = this;
     *   vm.onUpdate = function(id, value, oldValue){};
     *   vm.data = {id: 'myId', data: [{key: 1, value: 'One', selected: true}, {key: 2, value: 'two', selected: false}]}
     * }
     *
     * // In view
     * <cc-form-select-control data-ng-model='$ctrl.data' data-on-change='$ctrl.onUpdate(id, value, oldValue)'></cc-form-select-control>
     * </pre>
     */
    angular.module('INTACT.PolicyChange').directive('ccFormSelectControl', function($PCAppConfiguration) {

        return {
            restrict: 'AE',
            priority: 0,
            require: 'ngModel',
            templateUrl: $PCAppConfiguration.directivesViewsPath + '/form-select.html',
            scope: {
              ngModel: "=",
              onChange: "&"
            },
            link: function(scope){
                scope.$watcher = scope.$watch('item', function(n, o){
                    if(o !== n) {
                        scope.onChange({id: scope.ngModel.id, value: n, oldValue: o});
                    }
                });

                var itemSelected = null;
                if(scope.ngModel && scope.ngModel.data.length){
                    itemSelected = scope.ngModel.data[0].key;
                    for(var i = 0, l = scope.ngModel.data.length; i < l; i++) {
                        if(scope.ngModel.data[i].selected){
                           itemSelected = scope.ngModel.data[i].key;
                           break; 
                        }
                    }
                }

                scope.item = (itemSelected !== null)? itemSelected + '' : itemSelected;
               
                /**
                 * Clean-up directive destroy
                 */
                scope.$on('$destroy', function() {
                    if(scope.$watcher){
                        scope.$watcher();
                    }
                });

            }
        };
    });

 })(angular);
