(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:pcCaroussel
     * @restrict A
     *
     * @description
     * Slider that allow the user to select the vehicle on the car policy
     * detail page.
     *
     * @example
     * <pre>
     * <div pc-caroussel></div>
     * </pre>
	 */
	angular.module('INTACT.PolicyChange').directive('pcCaroussel', function($PCAppConfiguration, $window, $filter, $PolicyChangeValidation){

		var templateUrl = $PCAppConfiguration.directivesViewsPath + '/caroussel.html';

		return {
			require: "ngModel",
			restrict: 'A',
			templateUrl: templateUrl,
			scope: {
    	        ngModel: '=',
    	        selectedRisk: '=',
    	        callSave : '=',
    	        saveRisk : '&'
	        },
			link: function(scope, element){
				var translate = 0;
				var tabList = {};
				var tabWidth = 0;
				var maxwidth =  0;
				var tabWrapper = {};
				var previousControl = {};
				var nextControl = {};

				scope.trySave = function(item){
					if(scope.callSave){
						scope.saveRisk({index : item.vehicle.riskIndex}).then(function(validationContext){
								if(!validationContext.hasValidationError){
									scope.change(item);
								}
							});
					}
					else{
						scope.change(item);
					}
				};

				//Function that change the risk on click
				scope.change = function(item){
					$PolicyChangeValidation.removeErrorForRisk(item.vehicle.riskIndex);

					scope.$parent.activeRisk = item;
					scope.selectedRisk = item;

				};
				scope.translateCarName = function(make, model, year){
					return $filter('formatCarName')(make, model, year);
				};
				//Set a default risk at first
				if(scope.$parent.activeRisk == null || !angular.isDefined(scope.$parent.activeRisk)){
					if(scope.ngModel){
						scope.change(scope.ngModel[0]);
					}
				}



				if(element.width() <= 500){
					var hasError = false;
					angular.forEach(scope.ngModel, function(risk){
						if(risk.hasError()){
							hasError = true;
						}
					});

					if(hasError){
						element.addClass('error');
					}
				}

				//Setup the slider sizes and style once the last item is loaded
				//into the slider.
				scope.$on("slider.loop.end", function(){

					tabList = element.find(".tab-wrapper .tab");
					tabWidth = angular.element(tabList[0]).width();
					maxwidth =  tabWidth * tabList.length;
					tabWrapper = element.find('.tab-wrapper');
					previousControl = element.find('#prev-tab');
					nextControl = element.find('#next-tab');
					// var displaySize = angular.element(element).width() - angular.element(previousControl).width() - angular.element(nextControl).width();
					// var sliderNeeded = angular.element(tabWrapper).width() > displaySize;

					isSliderNeeded();

				});


				element.find('.tab-controller').bind('mousedown', function(e){

					e.stopPropagation();

					var control = angular.element(this);

				 	if(!control.hasClass('disabled')){

				 		//Add class for animation
				 		control.addClass('pressed');

				 		//Get translate value depending the direction of the controller clicked
		    			translate = control.data("dir") === "next" ?  (translate - 41) - Math.abs(tabWidth) :   (translate + 41) + tabWidth;
		    			tabWrapper.css(translateX(translate));

		    			// Calculate if the right edge of the wrapper fits in the slider
		    			var right = tabWrapper.width() + tabWrapper.position().left;

		    			//Enable and disable controllers depending on the wrapper position
						if(translate < 0){

							previousControl.removeClass("disabled");
							nextControl.removeClass("disabled");

							if((right) < element.width()){
								nextControl.addClass("disabled");
							}
						}else if(translate === 0){
							previousControl.addClass("disabled");
							nextControl.removeClass("disabled");
						}

						if(control[0].id === 'prev-tab'){
							nextControl.removeClass("disabled");
						}

				 	}

				})
				.bind('mouseup', function(){

					//Remove animation class
					angular.element(this).removeClass("pressed");

				});


				//Listen to screen size change
				angular.element($window).bind('resize', function(){
					isSliderNeeded();
				});


				//Determine if slider control are needed
				var isSliderNeeded = function(){
					var displaySize = angular.element(element).width() - angular.element(previousControl).width() - angular.element(nextControl).width();
					var tbsize = element.find('.tab-wrapper .tab')[0].offsetWidth;
					var sliderNeeded = (tbsize * tabList.length) > displaySize;
					if(sliderNeeded){
						angular.element(element).addClass('slider');
					}
					else{
						angular.element(element).removeClass('slider');
					}
				};

				//
				//Function that provide CSS for the sliding translation effect
				//
				var translateX = function(value){
					return {'-webkit-transform' : 'translateX(' + value + 'px)',
				 		'-moz-transform'    : 'translateX(' + value + 'px)',
				  		'-ms-transform'     : 'translateX(' + value + 'px)',
				  		'-o-transform'     : 'translateX(' + value + 'px)',
				  		'transform'         : 'translateX(' + value + 'px)'};
				};

			}
		};
	});

})(angular);
