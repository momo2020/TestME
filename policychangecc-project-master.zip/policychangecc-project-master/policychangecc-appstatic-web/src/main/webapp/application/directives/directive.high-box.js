(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:pcHighBox
     * @restrict A
     *
     * @description
     *
     * @example
     * <pre>
     * </pre>
	 */
	angular.module('INTACT.PolicyChange').directive('pcHighBox', function(){
		return {
			restrict: 'A',
			scope:{
				limitHeight : "="
			},
			link: function(scope, el){
				angular.element(el[0]).ready(function(){
					var elementHeight = angular.element(el)[0].offsetHeight,
						minHeight = scope.limitHeight;

					if(elementHeight > minHeight){
						angular.element(el).addClass('highbox');
					}
				});
			}
		};
	});
})(angular);
