(function(angular){
    'use strict';

    /**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:pcNestedFormValidator
     * @restrict A
     *
     * @requires ^form
     *
     * @description
     * Shows validation labels and highlight fields
     * Use in conjonction with ng-repeat and ng-form
	 *
     * @example
     * <pre>
     * <div ng-repeat="car in pcCarCtrl.cars track by $index">
	 *      <form pc-nested-form-validator name="mainForm"
	            data-childforms="carForm{{$index}}, usageForm{{$index}}"
	            data-index="{{$index}}">
	            <ng-form name="carForm{{$index}}">
	                <input name="DE0003{{$index}}"/>
	                <span class="error" ng-show="carForm{{$index}}.DE0003{{$index}}.$error.required"
	                data-errorFor="DE0003{{$index}}"></span>
	            </ng-form>
	            <ng-form name="usageForm{{$index}}">
	                <input name="DE0009{{$index}}"/>
	                <span class="error" ng-show="usageForm{{$index}}.DE0009{{$index}}.$error.required"
	                data-errorFor="DE0009{{$index}}"></span>
	            </ng-form>
	        </form>
	   </div>
     * </pre>
	 */

	angular.module('INTACT.PolicyChange').directive('pcNestedFormValidator', function($CoreWindowService, $InlineValidationService) { 
		 return {
            restrict: 'A',
            priority: 0,
            require: '^form',
            link: function($scope, element, attrs, mainForm) {
            	if (attrs.forcelistener) {
            		// hard fix for usage section validation
            		var vehicles = $scope[attrs.forcelistenerCtrl][attrs.forcelistenerEntities];

            		angular.forEach(vehicles, function(v) {

            			// prevent duplicated events
            			var eventName = 'customFieldValidation' + v.vehicle.riskIndex; 
            			$scope.$root.$$listeners[eventName]=[];

            			$scope.$on(eventName, function(event, error){
							setValidator(error);
            			});

            			$scope.$on('validationChanged', function(event, errors) {
            				$InlineValidationService.scrollTo(errors);
            			});
            		});
            	} else {
            			// prevent duplicated events
						var eventName = 'customFieldValidation' + attrs.index;
            			$scope.$root.$$listeners[eventName]=[];
						$scope.$on(eventName, function(event, error){
							setValidator(error);
						});

						$scope.$on('validationChanged', function(event, errors) {
            				$InlineValidationService.scrollTo(errors);
            			});
				}

				// tracks invalid fields
				var invalidFeilds = [];

				function setValidator(error) {
					var nestedForms = attrs.childforms,
						formList = nestedForms.replace(/ /g, ''),
						forms = formList.split(',');// make into an array

					angular.forEach(forms, function(childForm) {
						var nestedForm = mainForm[childForm],
							index = error.elementIndex.toString(),
							subIndex = error.elementSubIndex !== null ? error.elementSubIndex.toString() : '',
							field = error.field + index + subIndex,
							el = element.find('[name=' + field + ']');

						el.removeClass('ng-valid ng-valid-required');

						setLabel(error, field);

						invalidateMainForm(); // invalidate mainform to control buttons

						addInvalidField(field); // show field errors

						setField(field, false, true);

						setClasses(el, true);

						// set callback for field validation reset and remove events
						var boundEvents = 'change';
						el.on(boundEvents, function() {
							resetOnChange();
						});

						function resetOnChange() {
							setClasses(el, false);

							removeLabel(field);

							removeInvalidField(field);

							setField(field, false, true);

							if( element.find('[data-linkedField="' + field + '"]')[0] !== undefined ){
								setField( element.find('[data-linkedField="' + field + '"]')[0].dataset.errorfor , true, false );
							}

							if(invalidFeilds.length){
								invalidateMainForm();
							}
							else{
								resetMainForm();
							}
            			}

						// used with  btn cancel/ remove car which triggers an event catched by each form element
						var reset = 'fieldReset';
						$scope.$on(reset, function() {
							setClasses(el, false);

							removeInvalidField(field);
							removeLabel(field);

							if (!invalidFeilds.length) {
								resetMainForm();
							}

							setField(field, true, false);
						});

						function setField(field, isValid, isRequired) {
							if (nestedForm && nestedForm[field]) {
								nestedForm[field].$valid = isValid;
								nestedForm[field].$error.required = isRequired;
							}
		       			}
					});
		        }

		        function addInvalidField(field) {
		        	invalidFeilds.push(field);
		        }

		        function removeInvalidField(field) {
		        	var index = invalidFeilds.indexOf(field);
		        	invalidFeilds.splice(index, 1);
		        	if(element.find('[data-linkedField="' + field + '"]')[0] !== undefined){
		        		index = invalidFeilds.indexOf(element.find('[data-linkedField="' + field + '"]')[0].dataset.errorfor);
		        		invalidFeilds.splice(index, 1);
		        	}		        	
		        }

		        function invalidateMainForm() {
		        	// manualy set form to invalid
		        	mainForm.$setDirty();
					mainForm.$valid = false;
					mainForm.$invalid = true;
		        }

		        function resetMainForm() {
		        	// manualy reset form
					mainForm.$setPristine();
					mainForm.$valid = true;
					mainForm.$invalid = false;
		        }

		        function setClasses(el, invalid) {
		        	if(invalid) {
		        		el.addClass('ng-invalid ng-invalid-required');
		        	} else {
						el.removeClass('ng-invalid ng-invalid-required');
		        	}
		        }

		        function setLabel(error, field) {
		        	element.find('[data-errorFor='+field+']').text(error.message);
		        	forceLabel(field, true);
		        }

		        function removeLabel(field) {
		        	element.find('[data-errorFor='+field+']').text('');
		        	if(element.find('[data-linkedField="' + field + '"]')[0] !== undefined){
		        		element.find('[data-linkedField="' + field + '"]').text('');
		        	}
		        	forceLabel(field, false);
		        }

		        function forceLabel(field, showHide) {
			        if (attrs.forcelistener || field.indexOf('DE') !== -1) {
			        	// hard fix - force show label as ng-show is not working in this case
			        	var el = element.find('[data-errorFor='+field+']');
		                if(showHide){
		                  el.removeClass('ng-hide');
		                }
		                else{
		                  el.addClass('ng-hide');
		                }
			        }
		        }
		}
        };
    });
})(angular);
