(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccLightboxClose
     * @restrict A
     * @scope ngModel
     * 
     * @description
     * Close modal box on overlay click HTML element.
     * The root lightbox element must has one css class to identfy him.
     * The attribute ng-model must reference the modal controller witch implement the close method.
     *
     * @example
     * <pre>
     * // Pass as model the lightbox controller exposed close method
     * <div class="lightbox" cc-lightbox-close data-ng-model="MyControllerAsName">
     * 	<div>Lightbox content</div>
     * </div>
     * </pre>
	 */
	angular.module('INTACT.PolicyChange').directive('ccLightboxClose', function(){
		return {
			restrict: 'A',
			priority: 0,
			scope: {
				ngModel: '='
			},
			link: function(scope, element, attrs){
				var selector = attrs.class,
					close = null;
				
				var stopWatchNgModel = scope.$watch('ngModel', function(){
					if(scope.ngModel){
						close = scope.ngModel.close;
						stopWatchNgModel();
					}
				});

				element.on('click', function(event){
					var $target = angular.element(event.target);
					if($target.hasClass(selector) && angular.isFunction(close)){
						close();
					}
				});

				scope.$on('$destroy', function(){
					element.remove();
					if(stopWatchNgModel){
						stopWatchNgModel();
					}
				});
			}
		};
	});
})(angular);