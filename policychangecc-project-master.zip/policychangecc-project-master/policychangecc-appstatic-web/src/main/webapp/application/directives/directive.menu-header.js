(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccMenuHeader
     * @restrict A
     * 
     * @description
     * Build header responsive menu.
     * 
     * @requires https://docs.angularjs.org/api/ng/service/$window
     * @requires core/INTACT.Core.service:$CoreWindowService
     * @requires https://docs.angularjs.org/api/ng/service/$timeout
     *
	 */
	angular.module('INTACT.PolicyChange').directive('ccMenuHeader', function($window, $CoreWindowService, $timeout, $rootScope){
		return {
			restrict: 'A',
			priority: 0,
			link: function(scope, element, attrs){
				var $root = element,
					$link = null,
					$subLinks = null,
					cssVisibleClass = 'click',
					cssActiveClass = 'active',
					$timer;

				/* On DOM ready in repeater */
				scope.$on(attrs.ccMenuHeader, function(){
					init();
				});

				/**
				 * Event handler on window resize
				 */
				angular.element($window).on('resize', function(){
					if($link) {
						$link.removeClass(cssVisibleClass);
					}
				});

				/**
				 * Event handler on url change
				 */
				$rootScope.$on('$stateChangeSuccess', function(){
					if($timer && $timeout.cancel($timer)){
						$timer = null;
					}

					$timer = $timeout(function(){
						setActiveState();
					}, 20);
				});


				/* Initialize behavior */
				var init = function(){
					$link = angular.element('a:first', $root);
					$subLinks = angular.element('.submenu a', $root);

					if($link) {
						$link.click(function(evt){
							evt.stopPropagation();
							$link.toggleClass(cssVisibleClass);
						});

						$root.on('mouseleave', function(){
							$link.removeClass(cssVisibleClass);
						});
					}

					setActiveState();
				};

				/**
				 * [setActiveState description]
				 */
				var setActiveState = function(){
					if($link) {
						$link.removeClass(cssVisibleClass + ' ' + cssActiveClass);
						angular.forEach($subLinks, function(l){
							var $l = angular.element(l);
							if($l.hasClass(cssActiveClass)) {
								$link.addClass(cssActiveClass);
							}
						});
					}
				};

				scope.$on('$destroy', function(){
					if($timer && $timeout.cancel($timer)){
						$timer = null;
					}

					/**
					 * Remove angular elements attached event
					 */
					$link.remove();
					$root.remove();
				});
			}
		};
	});
})(angular);