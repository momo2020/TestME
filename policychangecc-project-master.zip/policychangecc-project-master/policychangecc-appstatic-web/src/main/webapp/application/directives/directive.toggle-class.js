(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:toggleclass
     * @restrict A
     * 
     * @description
     * Toggle a class 
     *
	 */
	angular.module('INTACT.PolicyChange').directive('toggleclass', function($CoreConfiguration, $filter){

		var $t = $filter('translate'),
			showLabel = $t('lbl.show.label'),
			hideLabel = $t('lbl.hide.label');

	    return {
	      restrict: 'A',
	      link: function(scope, element) {

	        element.bind('click', function(e) {
	        	if(angular.element(e.target).hasClass('heading')){
	        		var parent = angular.element(e.target).parents('.heading-box'),
	        			content = parent.find(".hide-content"),
	        			txt = (!parent.hasClass('toggleclass'))? showLabel : hideLabel;

	        		parent.toggleClass('toggleclass');
	        		content.text(txt);
	        	} else {
	        		angular.element(e.target).toggleClass('toggleclass');
	        	}
	        });
	      }
	    };
	});
})(angular);