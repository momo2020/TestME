(function(angular){
    'use strict';

    /**
     * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccFormCarUsage
     * @restrict AE
     * @requires INTACT.PolicyChange.$PCAppConfiguration
     *
     * @description
     * Handles the display of a select control
     *
     * @example
     * <pre>
     * // In controller
     * angular.module('PC').controller('$crtl', ctrl);
     * </pre>
     */
    angular.module('INTACT.PolicyChange').directive('ccFormCarUsage', function($PCAppConfiguration) {

        return {
            restrict: 'AE',
            priority: 0,
            controller: Controller,
            controllerAs : '$ctl',
            templateUrl: function(){
                var province = $PCAppConfiguration.province.toLowerCase();
                return $PCAppConfiguration.directivesViewsPath + '/form-car-usage-' + province + '.html';
            },
            scope: {
                newCar              : "=?",
                carIndex            : "=",
                drivers             : "=",
				vehicles			: "=",
                policyHolders       : "=",
                addressChanged      : "=",
                otherDriverAllowed  : "="
            },
            link : function(){
            }
        };

        function Controller ($filter, $scope){
            var vm = this;

            vm.ngModel = $scope.newCar ? $scope.newCar : $scope.vehicles[$scope.carIndex];
            vm.carIndex = $scope.carIndex;
            vm.driversList = $scope.drivers;
			vm.vehicleList = $scope.vehicles;
            vm.policyHolders = $scope.policyHolders;
            vm.resetBusinessAnnualKm = $scope.vehicles[$scope.carIndex] ? $scope.vehicles[$scope.carIndex].resetBusinessAnnualKm : null;
            vm.otherDriverAllowed = $scope.otherDriverAllowed;

            $scope.$on('reloadData', function(event, attrs){
                vm.ngModel = attrs.vehicle;
                vm.carIndex = attrs.vehicle.vehicle.riskIndex;
                vm.vehicleList = attrs.carList;
                vm.driversList = attrs.driverList;
            });

            vm.showBlueBox = function(fn){
                return $scope.addressChanged && (vm.ngModel.vehicle[fn] === null || vm.ngModel.vehicle[fn] === "");
            };  


        }
    });

 })(angular);
