(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccBackFromError
     * @restrict A
     * @requires https://docs.angularjs.org/api/ng/service/$timeout
     * @requires https://docs.angularjs.org/api/ng/service/$filter
     * 
     * @description
     * Force page reload on back button from 404 page
     * 
     * @example
     * <pre>
     * // Loop on policies list in header menu
     * <div cc-back-from-error></div>
     * </pre>
	 */
	angular.module('INTACT.PolicyChange').directive('pcCoveragesBubble', function($PCAppConfiguration){
	

		return {
			restrict: 'AE',
			priority: 0,
			templateUrl: $PCAppConfiguration.directivesViewsPath + '/coverages-bubble.html',
			link : function(scope, element){
				angular.element('.pc-coverages-main-table').addClass('margin-85');
				
				var carCount = scope.$parent.CoverageCtrl.currVehicleList.length;

				if(carCount === 1){
					// adjust the top margine when no carousel is displayed
					angular.element('#coverages-new-car').addClass("bubbleNoCarousel");
				}
				else{
					// Carousel is displayed
					angular.element('#coverages-new-car').addClass("bubbleWithCarousel");	
				}

				element.on('$destroy', function(){
					angular.element('.pc-coverages-main-table').removeClass('margin-85');
				});
			}
		};
	});

})(angular);