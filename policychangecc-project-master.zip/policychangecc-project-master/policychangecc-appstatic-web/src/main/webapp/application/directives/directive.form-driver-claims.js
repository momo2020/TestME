(function(angular){
    'use strict';

    /**
     * @ngdoc directive
     * @name INTACT.PolicyChange.directive:pcFormDriverClaims
     */
    angular.module('INTACT.PolicyChange').directive('pcFormDriverClaims', function($PCAppConfiguration) {

        return {
            restrict: 'AE',
            priority: 0,
            controller: Controller,
            controllerAs : '$ctrl',
            require: 'ngModel',
            templateUrl: function(){
                var province = $PCAppConfiguration.province.toLowerCase();
                return $PCAppConfiguration.directivesViewsPath + '/form-driver-claims-' + province + '.html';
            },
            scope: {
                ngModel         : "="
            }
        };


        function Controller ($filter, $PCAppConfiguration, $scope, ClaimsModel){
            var vm = this;
            
            vm.driverIndex = $scope.ngModel.driver.driverIndex;
            vm.ngModel = $scope.ngModel;
            vm.labelClaims = $filter('translate')('LBL42889.driver.claims.indicator');
            /**
    		* @ngdoc method
    		* @name INTACT.PolicyChange.directive:pcFormDriverClaims#addClaim
    		* @methodOf INTACT.PolicyChange.directive:pcFormDriverClaim
    		* @description
    		* Create a new claim
    		*/
            vm.addClaim = function(){
                var claims =  $scope.ngModel.driver.claims;
                var claimsLength =  claims.length;
                var newClaim = new ClaimsModel({
                    sequence : claimsLength 
                });

                $scope.ngModel.driver.claims.push(newClaim);
            };

            /**
            * @ngdoc method
            * @name INTACT.PolicyChange.directive:pcFormDriverClaims#removeClaim
            * @methodOf INTACT.PolicyChange.directive:pcFormDriverClaims
            * @description
            * Removes a claim from the driver model
            */
            vm.removeClaim = function(claimKey){
                $scope.ngModel.driver.claims.splice(claimKey.claimIndex, 1);
                // Reorder sequence  zero base for claims validation
                angular.forEach($scope.ngModel.driver.claims, function(claim, index){
                    claim.sequence = index;
                })
            };
        }
    });

 })(angular);
