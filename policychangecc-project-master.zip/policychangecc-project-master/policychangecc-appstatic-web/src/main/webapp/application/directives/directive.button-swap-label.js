(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccButtonSwapLabel
     * @restrict A
     * 
     * @description
     * Swaps button label
     * 
     * @property {string} name contains form carIndex index
     * @property {string} data-defaultState element property containing default text
     * @property {string} data-text element bound to CSS animation
     * @property {string} data-alternateState element property containing alternate text
     * @example
     * <pre>
     * // Loop on policies list in header menu
     * <button cc-button-swap-label
     *  data-name="btn_{{$index}}"
     *	data-defaultState="defaultText"
     *  data-alternateState="data-alternateState">
	 *  data-text="defautltext"
     * </button>
     * </pre>
     * // trigger event
     * @param {bool} isVisible passes context form visibility
     * $scope.$broadcast('ccButtonSwapLabelRChanged', vm.formVisibility[index]);
	 */
	angular.module('INTACT.PolicyChange').directive('ccButtonSwapLabel', function(){
		return {
			restrict: 'A',
			priority: 0,
			replace: false,
			link: function(scope, element){
				element.attr('data-cancel', false);
				
				// TODO: use a bindings instead of event			
				scope.$on('ccButtonSwapLabelChanged', function(event, index) {
					var btnNameIndex = element.attr('name').split('_')[1],
						sIndex = ''+index;

					// event will be caught by all btns intances
					if (btnNameIndex !== sIndex) {
						return;
					}

					var isCancel = element.attr('data-cancel') === 'false';

					if (isCancel) {
						setAlternate(element);	
					} else {
						setDefault(element);
					}
				});

				function setAlternate(el) {
					var alternateState = el.attr('data-alternateState');

					el.find("span").text(alternateState);
		 			el.attr('data-text', alternateState);
		 			el.attr('data-cancel', true);
				}

				function setDefault(el) {
					var defaultState = el.attr('data-defaultState');

					el.find("span").text(defaultState);
					el.attr('data-text', defaultState);
					el.attr('data-cancel', false);
				}
			}
		};
	});

})(angular);