(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:ccStatusBar
	 * @description
	 * Directive for the breadcrumb navigation (status bar)

	 */
	angular.module('INTACT.PolicyChange').directive('ccStatusBar', function($PCAppConfiguration){

		return {
	        restrict: 'AE',
	        priority: 0,
	        controller: Controller,
	        controllerAs : 'statusBarCtrl',
	        templateUrl: $PCAppConfiguration.directivesViewsPath + '/statusbar.html'
	    };

	    function Controller($PolicyChangeService,
	    					$PCStateManagerService, 
	    					$PCAppConfiguration, 
	    					$PolicyChange,
	    					$state, 
	    					$filter, 
	    					$rootScope,
	    					$scope, 
	    					$location){

	    	var PolicyChangeData = $PolicyChange.$get().policyChange(),
	    		$translate = $filter('translate');
	    	
	    	var vm = this;
			vm.visiblePages = [];
			vm.cnfg = {};
			vm.navigate = navigate;
			vm.isHidden = isHidden;
			vm.getIconState = getIconState;

			// Reload breadcrumb when container view is saved
			$rootScope.$on('eventReloadBreadcrumb', function () {
				PolicyChangeData = $PCStateManagerService.getPolicyChangeData();
				init();
		    });

			init();

			// Public functions
			function navigate($event, toPage) {
				// $event.preventDefault();
				// $event.stopPropagation();

				PolicyChangeData = getRefreshedData();

				if(toPage === "PC_START") {
	    			
	    			var cnfg = {
	    				templateUrl: '/partials/cancel-changes-confirmation.html',
						controllerAs: 'cancelCtrl',
						controller: 'CancelChangesController',
						policyNumber: PolicyChangeData.currentPolicy.policyNumber
					};

	    			$PCStateManagerService.openCancelPolicyChangesDialog(cnfg);

	    			return false;
	    		}

				var ignoreErrors = true;

				if (!isCurrentPage(toPage)) {
			    	$PolicyChangeService.put(PolicyChangeData.policyChange, { goto: toPage, ignoreErrors:ignoreErrors }).then( 
			    		function(data) {
				    		toPage = data.state.currentPage;
				    		$PCStateManagerService.goToPage(PolicyChangeData.currentPolicy.policyNumber, { goto: toPage });	
			    		});
				}
			}

			function isHidden() {
				var hidden = $state.current.name.indexOf('select') > -1;
				return hidden ? true : false;
			}

			function getIconState(pageName) {
				return  isCurrentPage(pageName) ? 'current' 
					: isCompleted(pageName) ? 'completed' 
					: pageIsReachable(pageName) ? 'reachable' : 'disabled';
			}

			// Private functions
			function init() {
				vm.visiblePages = [];
				vm.cnfg = {
					'PC_START': {
							name: 'start',
							iconName: getAssetPath('icon_status_start'),
							label: $translate('LBL45043.breadcrumb.start')
					},
					'PC_ADDRESS': {
							name: 'address',
							iconName: getAssetPath('icon_status_address'),
							label: $translate('LBL42222.section')
					},
					'PC_CARS': {
							name: 'cars',
							iconName: getAssetPath('icon_status_car'),
							label: $translate('LBL42223.section')
					},	
					'PC_DRIVERS': {
							name: 'drivers',
							iconName: getAssetPath('icon_status_driver'),
							label: $translate('LBL15941.section')
					},
					'PC_VEH_USAGE': {
							name: 'usage',
							iconName: getAssetPath('icon_status_usage'),
							label: $translate('LBL42002.section')
					},
					'PC_COV': {
							name: 'coverage',
							iconName: getAssetPath('icon_status_coverage'),
							label: $translate('LBL42224.section')
					},
					'PC_PRM': {
							name: 'premium',
							iconName: getAssetPath('icon_status_premium'),
							label: $translate('LBL29572.section')
					},
					'PC_REVW': {
							name: 'review',
							iconName: getAssetPath('icon_status_reviewaccept'),
							label: $translate('LBL42211.section')
					},
					'PC_TRX_CONFRM': {
							name: 'confirm',
							iconName: getAssetPath('icon_status_reviewaccept'),
							label: $translate('LBL01237.section')
					},
					'RDBLK': {
							name: 'rdblk',
							iconName: getAssetPath('icon_status_reviewaccept'),
							label: 'rdblk'
					}
				};

				vm.visiblePages = getVisiblePages(PolicyChangeData.state.pages);

			}

			function getAssetPath(asset) {
				var assetsPath = $PCAppConfiguration.assetsPath + '/img/icons/';
				var ext = '.svg';
				var host = '';
				
				if($location.protocol === 'https') {
					host = $location.protocol +'://'+ $location.host;
				}
				
				return host + assetsPath + asset + ext;
			}

			function getVisiblePages(_pages) {
				var visiblePages = [];
				angular.forEach(_pages, function(page) {
					visiblePages.push(page); 
				});
				
				return visiblePages;
			}

			function isCurrentPage(_page) {
				return (PolicyChangeData.state && PolicyChangeData.state.currentPage && _page) ? PolicyChangeData.state.currentPage.indexOf(_page.toUpperCase()) > -1 : false; 
			}

			function getPage(_page) {
				var page = PolicyChangeData.state.pages.filter( function(item) {
					return item.type === _page;
				})[0];
				return page ? page : false;
			}

			function pageIsReachable(_page) {
				if (_page === 'PC_START') { 
					return true;
				}

				var page = getPage(_page);
				return page ? page.reachable : false;
			}

			function isCompleted(_page) {
				if (_page === 'PC_START') { 
					return false;
				}

				var page = getPage(_page);
				return page ? page.completed : false;
			}

			function getRefreshedData(){
				$rootScope.$broadcast('eventRefreshDataForNavigation'); 
				return $PCStateManagerService.getPolicyChangeData();
			}
					
		}
	});
})(angular);
