(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccBackFromError
     * @restrict A
     * @requires https://docs.angularjs.org/api/ng/service/$timeout
     * @requires https://docs.angularjs.org/api/ng/service/$filter
     * 
     * @description
     * Force page reload on back button from 404 page
     * 
     * @example
     * <pre>
     * // Loop on policies list in header menu
     * <div cc-back-from-error></div>
     * </pre>
	 */
	angular.module('INTACT.PolicyChange').directive('ccBackFromError', function($rootScope, $location, $window){
	

		return {
			restrict: 'A',
			priority: 0,
			replace: false,
			link: function(scope){
				/* $timeout reference to clean on $destroy directive event */
				var page404Url,
				page404Flag = true;

				/* Back on error page */
		        var clearLocationChangeWatcher  = $rootScope.$on('$locationChangeSuccess', function() {
			        page404Url = $location.path();
			    });   

				/* Watcher unbind function */
				var clearWatcher = $rootScope.$watch(function () { 
					return $location.path();
				}, function (newLocation) {
			        if(page404Url === newLocation && page404Flag) {
			        	page404Url = undefined;
			            $window.location.href = newLocation;
			        }
			    });

				scope.$on('$destroy', function(){
					page404Flag = false;
					clearLocationChangeWatcher();
					clearWatcher();
				});

			}
		};
	});

})(angular);