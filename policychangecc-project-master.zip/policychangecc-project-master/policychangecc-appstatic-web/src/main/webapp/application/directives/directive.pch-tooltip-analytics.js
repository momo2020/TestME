(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:pchTooltipAnalytics
     * @restrict A
     * 
     * @description
     * 
	 */
	angular.module('INTACT.PolicyChange').directive('pchTooltipAnalytics', function($PCAnalyticsService ){
		return {
			restrict: 'A',
			priority: 0,
			replace: false,
			link : function(scope, element, attrs){
				scope.$watcher = scope.$watch(function(){return element.attr('class')},
					function(newValue){
						if( newValue.toUpperCase().indexOf('ZINDEX') > -1 ){
							var elementCode = element.attr('id').replace('toolTip-', '');
							fireAnalyticsForHelptext(elementCode, attrs.tooltipPageName, attrs.tooltipAppStep)
						}
					});

				/**
                 * Clean-up directive destroy
                 */
                scope.$on('$destroy', function() {
                    if(scope.$watcher){
                        scope.$watcher();
                    }
                });
			}
		};



	    function fireAnalyticsForHelptext(elementCode, pageName, appStep){
			// ******* Analytics - Helptexts
			var props = {
			  	s_appStep: appStep,
				s_pageName: 'portfolio:policy update:'+ pageName,
				s_helpText : elementCode
			};

			$PCAnalyticsService.trackPageView(props);
	    }
	});

})(angular);