(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccEventLoader
     * @restrict E
     * 
     * @description
     * Loader wrapper to minimize controller properties
     * 
     * @requires $rootScope
     * @requires $PCAppConfiguration -required by ccLoader

       * @example
     * <pre>
     * // Pass as label to cc-event-loader
     * <cc-event-loader label="{{'LBLXXXX.pc.loader' | translate }}"></cc-event-loader>
     * // call to show
     * $scope.$emit('showLoader');
     * // call to hide - no need to hide on $stateChange events when inside view.
     * $scope.$emit('hideLoader');
     * </pre>
     *
	 */
	angular.module('INTACT.PolicyChange').directive('ccEventLoader', function($rootScope, $PCAppConfiguration){
		return {
			restrict: 'E',
			priority: 0,
			template: '<div><div class="loader-wrapper" cc-loader lang="' +
						$PCAppConfiguration.preferredLanguage +
						'" label="{{ label }}"></div></div>',
			scope: {
				label: '@'
			},
			link: function(scope, element){
				$rootScope.$on('showLoader', function(){
					showLoader();
				});

				$rootScope.$on('hideLoader', function(){
					// retards until $digest is done	
					scope.$evalAsync( function() { 
						hideLoader();
					});
				});	

				function showLoader() {
					element.addClass('currently-loading');
				} 

				function hideLoader() {
					element.removeClass('currently-loading');
				}
			}
		};
	});
})(angular);