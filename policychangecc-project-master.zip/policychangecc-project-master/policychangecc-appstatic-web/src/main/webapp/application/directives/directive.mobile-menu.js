(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccMobileMenu
     * @restrict A
     * 
     * @description
     * Manage mobile menu states/behaviours
     *  
     * @requires https://docs.angularjs.org/api/ng/service/$window
	 */
	angular.module('INTACT.PolicyChange').directive('ccMobileMenu', function($window){
		/**
		 * DOM collection of elements to interact with
		 * @type {Object}
		 */
		var elts = angular.element('body, header, .menu-overlay');
		
		/**
		 * @description
		 * Open menu and overlay
		 */
		function open(){
			elts.addClass('open');
		}

		/**
		 * @description
		 * Close menu and overlay
		 */
		function close(){
			elts.removeClass('open');
		}

		/**
		 * @description
		 * Open/close menu
		 */
		function toggle(){
			if(elts.hasClass('open')){
				close();
			} else {
				open();
			}
		}

		return {
			restrict: 'A',
			priority: 0,
			link: function(scope){
				var subNav = angular.element('.mobile .navbar-toggle'),
					menuOverlay = angular.element('.menu-overlay');

				/**
				 * Event handler on open/close button
				*/
				subNav.on('click', function(){
					toggle();
				});
				
				/**
				 * Event handler on overlay click
				*/
				menuOverlay.on('click', function(){
					close();
				});
				
				/**
				 * Event handler on window resize
				 */
				angular.element($window).on('resize', function(){
					close();
				});

				/**
				 * Event handler on url change
				 */
				scope.$on('$locationChangeSuccess', function(){
					close();
				});

				/**
				 * Remove element on destroy event
				 */
				scope.$on('$destroy', function(){
					subNav.remove();
					menuOverlay.remove();
				});
			}
		};
	});
})(angular);