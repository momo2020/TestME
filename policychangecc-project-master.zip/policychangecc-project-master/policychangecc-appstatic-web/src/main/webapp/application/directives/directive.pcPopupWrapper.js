(function(angular){
	'use strict';

	/**
	 * @ngdoc method
	 * @name INTACT.PolicyChange.directive:pcPopupWrapper
	 *
	 * @restrict E
     * @requires $IntactModalService
     *
	 * @description
	 * Binds a modal an element
	 * fetches template by type, template text and success callback.
     *
     * @example
     * <pre>
     * 	<pc-popup-wrapper data-type="generic" on-success="$ctrl.successCallback()"
     	 data-title="ABC" data-text="Some text" data-btnSucces="OK" data-btnCancel="OK" />
     * </pre>
     **/
	angular.module('INTACT.PolicyChange').directive('pcPopupWrapper', function() {
  		return {
  			restrict: 'AE',
  			priority: 100,
			controller: Controller,
			scope: {
				title:'@',
				text:'@',
				boxTitle:'@',
				boxDesc:'@',
				btnSuccess:'@',
				btnCancel:'@',
				type:'@',
				onSuccess:'&',
				entity: '='
			}
		};
	});

	function Controller($scope, $element, $IntactModalService) {
		var types = {
			generic 		: '/directives/modal-generic-dialog.html',
			withCallback 	: '/directives/modal-generic-dialog-with-callback.html',
			softRoadblock 	: '/directives/modal-soft-roadblock.html'
		};

		var modalOptions = {
			templateUrl: getTemplate($scope.type),
			controllerAs: '$ctrl',
			controller: 'ModalDefaultController',
			resolve: {
				modalContext: {
					title: $scope.title,
					text: $scope.text,
					btnSuccess: $scope.btnSuccess,
					btnCancel: $scope.btnCancel,
					bbTitle: $scope.boxTitle,
					bbDesc: $scope.boxDesc
				}
			}
		};

		var hasModificationCode = $scope.entity && $scope.entity.modificationCode && $scope.entity.modificationCode === 'N';

		if (hasModificationCode) {
			modalOptions.controller = 'pcDeleteEntityConfirmPanelController';
			modalOptions.templateUrl = getTemplate('withCallback');
			modalOptions.resolve = {
				modalContext: {
					onSuccess: $scope.onSuccess,
					entity : $scope.entity
				}
			};
		}

		function getTemplate(type) {
			return types[type];
		}

		$element.on('click', function(){
			$IntactModalService.modal(modalOptions).on('$ModalServiceClose', function(success){
				if(success){
					$scope.onSuccess();
				}
			});
		});

		$scope.$watch('title', function(){
			modalOptions.resolve.modalContext.title = $scope.title;
			modalOptions.resolve.modalContext.text = $scope.text;
		});

		$scope.$watch('entity', function(){
			modalOptions.resolve.modalContext.entity = $scope.entity;
		});

	}
})(angular);
