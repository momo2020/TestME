(function(angular){ 
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:ccNavigationButtons
	 * @description
	 * Directive for the navigation buttons

	 */
	angular.module('INTACT.PolicyChange').directive('ccNavigationButtons', function($PCAppConfiguration){

		return {
	        restrict: 'AE',
	        priority: 0,
	        controller: Controller,
	        controllerAs : 'buttonsCtrl',
	        templateUrl: $PCAppConfiguration.directivesViewsPath + '/navigation-buttons.html'
	    };

		function Controller( $IntactModalService,
							 $state,
							 $PolicyChangeService,
							 $PCStateManagerService,
							 $PolicyChangeState,
							 $PCAppConfiguration,
							 $DebugButtonService,
							 $PolicyChange,
							 $rootScope,
							 $scope,
							 $window,
							 $filter){

			var PolicyChangeData = $PolicyChange.$get().policyChange(),
				$translate = $filter('translate');

			var vm = this;
			vm.debugEnabled = null; 
			vm.backTo = null;
		    vm.continueTo = null; 
			vm.backBtnLabel = null; 
	    	vm.nextBtnLabel = null;
	    	vm.go = go;
			vm.openSaveAndQuitDialog = openSaveAndQuitDialog;
			vm.openCancelChangesDialog = openCancelChangesDialog;
			vm.navgationButtonsVisible = navgationButtonsVisible();

			// Reload navigatin when container view is saved
			$rootScope.$on('eventReloadNavigation', function () {
				PolicyChangeData = $PCStateManagerService.getPolicyChangeData();
				init();
		    });

	    	init();

	    	function navgationButtonsVisible() {
	    		var currentPage = $PolicyChangeState.$get().state().currentPage;
	    		
	    		return  (currentPage && currentPage !== 'PC_START' && currentPage !== 'PC_TRX_CONFRM') ? true : false;
	    	}	

		    function getBackBtn (){
		    	var page = PolicyChangeData.state.previousPage;
		    	if(page === "PC_START"){
		    		return $translate('LBL43465.nav.back.to.start');
		    	}
		    	else{
		    		return $translate('LBL43447.nav.previous.step') + ': ' + getPageName(page);
		    	}
		    }

		    function getNextBtn(){
		    	var page = PolicyChangeData.state.nextPage,
		    		currentPage = PolicyChangeData.state.currentPage;
		    	if(currentPage === "PC_START"){
		    		return $translate('LBL42726.nav.start');
		    	}
		    	else{
		    		return $translate('LBL43446.nav.next.step') + ': ' + getPageName(page);
		    	}
		    }

		    /**
			 * @ngdoc method
			 * @name INTACT.PolicyChange.controller:NavigationButtonsController#go
			 * @methodOf INTACT.PolicyChange.controller:NavigationButtonsController
			 * @params Bool direction Pass true to go foward
			 * @description
			 * Saves data and redirects tos currentPage as instructed by statemachine
			 */
		    function go(forward) {

	    		PolicyChangeData = getRefreshedData();
	    		var ignoreErrors = forward ? false : true;
		    	var toPage = forward ? $PolicyChangeState.$get().state().nextPage :  $PolicyChangeState.$get().state().previousPage;

	    		//TODO: make sure state.previous page is not NULL - Must be PC_START in order to detect cancel popup appropriatelly
	    		if(!toPage || toPage === "PC_START") {
	    			$PCStateManagerService.showLoader();
	    			
	    			var cnfg = { 
	    				templateUrl: '/partials/cancel-changes-confirmation.html',
						controllerAs: 'cancelCtrl',
						controller: 'CancelChangesController',
						policyNumber: PolicyChangeData.currentPolicy.policyNumber
					};
	    			$PCStateManagerService.openCancelPolicyChangesDialog(cnfg);
	    		}
	    		else {
			    	$PolicyChangeService.put(PolicyChangeData.policyChange, { goto: toPage, ignoreErrors: ignoreErrors});
			    }
		    }

			/**
			 * @ngdoc method
			 * @name INTACT.PolicyChange.controller:NavigationButtonsController#openSaveAndQuitDialog
			 * @methodOf INTACT.PolicyChange.controller:NavigationButtonsController
			 * @description
			 * Calls private function to create a modal instance && open Save and Quit modal
			*/
			function openSaveAndQuitDialog(){
				$PCStateManagerService.showLoader();
			
				/**
				* Save and Quit Modal service options
				* @type {Object}
				*/
				PolicyChangeData = getRefreshedData();
				var saveAndQuitmodalOptions = {
					templateUrl: '/partials/save-and-quit-dialog.html',
					controllerAs: 'saveCtrl',
					controller: 'SaveAndQuitController',
					resolve: {
		      			PolicyChangeData: PolicyChangeData
		      		}

				};
				return openDialog(saveAndQuitmodalOptions);
			}

			/**
			 * @ngdoc method
			 * @name INTACT.PolicyChange.controller:NavigationButtonsController#openSaveAndQuitDialog
			 * @methodOf INTACT.PolicyChange.controller:NavigationButtonsController
			 * @description
			 * Call private function to create a modal instance and open Cancel Changes modal
			 */
			function openCancelChangesDialog(){
				/**
				 * Cancel changes Modal service options
				 * @type {Object}
				 */

				var cancelChangesModalOptions = {
					templateUrl: '/partials/cancel-changes-dialog.html',
					controllerAs: 'cancelCtrl',
					controller: 'CancelChangesController'
				}; 

				return openDialog(cancelChangesModalOptions);
			}

			function getPageName(page) {
				switch(page) {
					case 'PC_START':
						return $translate('LBL42726.nav.start');

					case 'PC_ADDRESS':
						return $translate('LBL42222.nav.pages.address');

					case 'PC_CARS':
						return $translate('LBL42223.nav.pages.car');

					case 'PC_DRIVERS':
						return $translate('LBL15941.nav.pages.driver');

					case 'PC_VEH_USAGE':
						return $translate('LBL42002.nav.pages.usage');

					case 'PC_COV':
						return $translate('LBL42224.nav.pages.coverage');

					case 'PC_PRM':
						return $translate('LBL29572.nav.pages.premium');

					case 'PC_REVW':
						return $translate('LBL42211.nav.pages.review');

					case 'PC_TRX_CONFRM':
						return $translate('LBL01237.nav.pages.confirm');
				}
			}

			/**
			 * @ngdoc function
			 * @name openDialog
			 * @methodOf INTACT.PolicyChange.controller:NavigationButtonsController
			 *
			 * @params {Object} modalOptions Contains template URL, Controller and ControllerAs references
			 * @description
			 * Create instance && open the save and quit modal,
			 * Will redirect to target location on model close event: $ModalServiceClose
			 * Will console warn targetMessage otherwise
			 */

			// TODO merge with state service popup method
			function openDialog(modalOptions){
				return $IntactModalService.modal(modalOptions).on('$ModalServiceClose', function(redirect){
					if(redirect){
						$PCStateManagerService.redirectToCC();
					}
				});
			}

			function getRefreshedData(){
				$rootScope.$broadcast('eventRefreshDataForNavigation'); 
				return $PCStateManagerService.getPolicyChangeData();
			}

			function init(){
				vm.debugEnabled = $DebugButtonService.isDebugEnabled();
				vm.backTo = getPageName(PolicyChangeData.state.previousPage);
			    vm.continueTo =  getPageName(PolicyChangeData.state.nextPage);
				vm.backBtnLabel = getBackBtn();
		    	vm.nextBtnLabel = getNextBtn();
			}
		}
	});
})(angular);
