(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:pcToaster
     * @restrict E
     * 
     * @description
     * Toater nofication directive
     * 
     * @requires $rootScope

       * @example
     * <pre>
     * <pc-toaster></cc-toaster>
     * </pre>
     *
	 */
	angular.module('INTACT.PolicyChange').directive('pcToaster', function($rootScope, $PCAppConfiguration, $timeout, $filter){
		return {
			restrict: 'E',
			replace: true,
			controller: Controller,
			controllerAs: '$ctrl',
			priority: 0,
			templateUrl: $PCAppConfiguration.directivesViewsPath + '/toaster.html'
		};

		function Controller($scope, $element) {
			var vm = this,
				resetDelay = 1000,
				$translate = $filter('translate');
			
			vm.notifications = [];

			vm.hide = function() {
				hideToast();
			};

			function init() {
				$rootScope.$on('pcShowToast', function(event, data){
					showToast(data);
				});

				$rootScope.$on('pcHideToast', function(){
					hideToast();
				});
			}

			function getAddedLabels (addedNum){
				var label = '';

				if ( addedNum === 1 ){
					label = $translate('LBL45083.toaster.A.sing');
				}

				else if ( addedNum > 1 ){
					label = $translate('LBL45084.toaster.A.plur');
				}

				return label;
			}

			function getRemovedLabels (removedNum){
				var label = '';

				if ( removedNum === 1 ){
					label = $translate('LBL45086.toaster.D.sing');
				}

				else if ( removedNum > 1 ){
					label = $translate('LBL45085.toaster.D.plur');
				}

				return label;
			}

			function formatNotifications(data) {
				var warning = data !== null && angular.isDefined(data) ? data.warning : {};

				var notification 				= {};
				notification.text 				= warning.message;
				notification.added 				= $filter('filter')(warning.elements, {modificationCode : 'A'});
				notification.removed 			= $filter('filter')(warning.elements, {modificationCode : 'D'});
				notification.labels				= [{
					added : getAddedLabels(notification.added.length),
					removed : getRemovedLabels(notification.removed.length)
				}];
				notification.modificationCodes 	= [];
				notification.codes 				= [];
				notification.codesAdded			= [];
				notification.codesRemoved 		= [];
				notification.vehicleDesc 		= '';
				
				angular.forEach(warning.elements, function(element) {
					var code = ' - <b>' + element.name + '</b>';

					// notification.codes.push(code);
					notification.modificationCodes.push(element.modificationCode);

					// show vehicule description for substituted vehicle
					if(element.modificationCode === "U") {
						var v = data.pcVehicles[warning.riskSequence-1];
						notification.vehicleDesc = $filter('formatCarName')(v.model.make, v.model.model, v.model.year);
						notification.codes.push(code);
					}
					else if( element.modificationCode === 'A' && notification.added.length === 1 ){
						notification.codesAdded.push(code);
					}
					else if ( element.modificationCode === 'A' && notification.added.length > 1 ){
						notification.codesAdded.push(code);
					}
					else if ( element.modificationCode === 'D' && notification.removed.length === 1 ){
						notification.codesRemoved.push(code);
					}
					else if ( element.modificationCode === 'D' && notification.removed.length > 1 ){
						notification.codesRemoved.push(code);
					}

				});

				vm.notifications.push(notification);
			}

			function showToast(data) {
				
				if(isShown()) {
					hideToast();
				}

				$timeout( function() {
					angular.forEach(data.warnings, function(warning) {							
						formatNotifications({
							'warning': warning,
							'pcVehicles': data.pcVehicles
						});
					});
					$element.addClass('show');
				}, resetDelay);	
			}

			function isShown() {
				return $element.hasClass('show');
			}

			function hideToast() {
				$element.removeClass('show');
				resetNotifications();
			}

			function resetNotifications() {
				$timeout( function() {
					vm.notifications = [];
				}, resetDelay);
			}

			init();
		}
	});
})(angular);