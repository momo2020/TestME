(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccTouchCallToAction
     * @restrict A
     * 
     * @description
     * Stop link action when user can access to a specific button in interface to browse content. 
     * If buttons are not visible, the touch/click event is available.
     * 
     * @example
     * <pre>
     * // Loop on policies list in header menu
     * <div cc-touch-call-to-action></div>
     * </pre>
	 */
	angular.module('INTACT.PolicyChange').directive('ccTouchCallToAction', function(){
		return {
			restrict: 'A',
			priority: 0,
			replace: false,
			link: function(scope, element){
				var $btn = element.find('.btn-primary');
				element.on('click', function(event){
					var $target = angular.element(event.target);
					if(!$target.hasClass('btn-primary')){
						// Prevent default if btn action exists and are visible
						if($btn.length && $btn.is(':visible')){
							event.preventDefault();
						}
					}
				});

				// Remove active state (focus) on link element
				element.on('mouseleave', function(){
					element.blur();
				});
			}
		};
	});

})(angular);