(function(angular){
    'use strict';
    /**
     * @ngdoc directive
     * @name INTACT.PolicyChange.directive:pcChangeDriversAssignment
     */
    angular.module('INTACT.PolicyChange').directive('pcChangeDriversAssignments', function( $PCAppConfiguration, 
                                                                                            $PCAnalyticsService, 
                                                                                            $PolicyChangeState, 
                                                                                            $PolicyChangeValidation, 
                                                                                            $PolicyChange, 
                                                                                            $PolicyChangeService, 
                                                                                            $rootScope) {

        var province = $PCAppConfiguration.province.toLowerCase();

        return {
            restrict: 'E',
            priority: 0,
            controller: Controller,
            controllerAs : '$ctrl', 
            templateUrl: $PCAppConfiguration.directivesViewsPath + '/changeDriversAssignments-' + province + '.html',
            scope: {
                refreshModels : '&'
            }
        };

        function Controller ($scope, $filter, $rootScope){
            var vm = this,
                    $capitalize = $filter('pcCapitalize'),
                    $translate = $filter('translate');
                    
            vm.showChangeDriversAssignments = false;
            vm.waiting = false;
            vm.policyChange =  null;
            vm.validationMessages = [];
            vm.mustShowCustomValidation = false;
            vm.labelPrincipalDriver = $translate('LBL43803.driver.principal');
            vm.updateModificationCode = updateModificationCode;
           
            // used for Quebec only
            if(province === 'qc'){
                vm.changePrincipalDriverSince = function (currentCar){
                    vm.updateModificationCode(currentCar);
                    $rootScope.$broadcast('eventSetPrincipalDriverSinceVisibility', {currentCar: currentCar});
                };
            }

            $rootScope.$on('showAssignationPanel', function(event, rejectObject) {
                vm.validationMessages =  getValidationMessages($PolicyChangeValidation.getRoadBlocks());
                vm.policyChange = rejectObject.policyChange;
                vm.showChangeDriversAssignments = true;
                vm.combos = {
                    drivers : fillDriversCombo()
                };
                vm.combos.drivers.unshift({key : null, value : $translate('LBLXXXX.car.select')});
                formatPrincipalDriverWhenOther();

                analytics();
            });

            vm.hasAssignedDriver = function(index) {
                return vm.policyChange.vehicles[index].principalDriver >= 0;
            };

            function fillDriversCombo(){
                var listOut = [],
                    listIn = vm.policyChange ? vm.policyChange.drivers : [];
                
                angular.forEach(listIn, function(driver){
                    var name = $capitalize(driver.firstName) + ' ' + $capitalize(driver.lastName);
                    listOut.push({
                        key : driver.sequence,
                        value : name
                    });
                });

                return listOut;
            }

            function updateModificationCode(currentCar){
                currentCar.modificationCode = $filter('modificationCode')($translate('MODIFICATION.CODE.MODIFIED'), currentCar.modificationCode);
            }

            function save(rollback) {
                vm.waiting = true;
                
                // cast from string to number
                angular.forEach(vm.policyChange.vehicles, function(vehicle) {
                    if(vehicle.principalDriver){
                        vehicle.principalDriver = Number(vehicle.principalDriver);
                    }
                    vehicle.usageModified = true;
                });

                var params = {
                    goto: rollback ? $PolicyChangeState.$get().state().currentPage : $PolicyChangeState.$get().state().nextPage ,
                    ignoreErrors: true
                };

                $PolicyChangeService.put(vm.policyChange, params)
                .then( function() {

                    $scope.refreshModels();
                    vm.showChangeDriversAssignments = false;
                    vm.waiting = false;

                    refreshCustomValidation(rollback);
                })
                .catch( function(rejectObject) {
                    if (rollback) {
                        vm.showChangeDriversAssignments = false;
                        vm.policyChange = null;
                        $scope.refreshModels();
                    }
                    else {
                        var errors = [];
                        if(rejectObject.hasAssignationRoadBlockErrors) {
                             angular.forEach(rejectObject.errors, function() {
                                errors = getValidationMessages(rejectObject.errors);
                            });
                            
                        }
                        vm.policyChange = rejectObject.policyChange;
                        vm.validationMessages = errors;
                    }

                    vm.waiting = false;
                    refreshCustomValidation(rollback);
                });
            }

            vm.confirm = function() {
                save();
            };

            vm.cancel = function() {
                var rollback = true;
                save(rollback);
            };

            vm.getVehicleName = function(vehicle) {
                return $filter('formatCarName')(vehicle.model.make, vehicle.model.model, vehicle.model.year);
            };

            vm.showCustomValidation = function (index, fieldName){
                if(fieldName === 'BR375'){
                    return !vm.hasAssignedDriver(index) && vm.mustShowCustomValidation;
                }
                if(fieldName === 'BR14476'){
                    var hasError = _.some(vm.validationMessages,function(error){ return error.code === fieldName;});
                    return hasError;
                }
                return false;
            };

            function getValidationMessages(messages){
                var validationMessages = [];
                
                angular.forEach(messages, function(roadBlock) {
                	// ignore messages that have the flag 'conditional' false
                    if (!roadBlock.conditional && roadBlock.message) {
                      validationMessages.push({code: roadBlock.code,
                                               message: roadBlock.message
                                            });
                    }
                  });   
                return validationMessages;           
            }

            function refreshCustomValidation(rollback){
                if(rollback){
                    vm.mustShowCustomValidation = false; 
                }
                else{
                    vm.mustShowCustomValidation = true;    
                }
            }

            function formatPrincipalDriverWhenOther(){
                var vehiclesWithOtherPrincipalDriver = $filter("filter")(vm.policyChange.vehicles, {principalDriver: -1});
                angular.forEach(vehiclesWithOtherPrincipalDriver, function(vehicle){
                    vehicle.principalDriver = null;
                });
            }

            function analytics() {
                // ******* Analytics - Driver's assignment
                var props = {
                    s_appStep : "pu:3",
                    s_pageState : "",
                    s_pageName: 'portfolio:policy update:drivers:drivers assignment warning'
                };

                $PCAnalyticsService.trackPageView(props);
            }
        }
    });

 })(angular);
