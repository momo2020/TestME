(function(angular){
    'use strict';

    /**
     * @ngdoc directive
     * @name INTACT.PolicyChange.directive:pcFormDriverInfraction
     */
    angular.module('INTACT.PolicyChange').directive('pcFormDriverInfraction', function($PCAppConfiguration) {

        return {
            restrict: 'AE',
            priority: 0,
            controller: Controller,
            controllerAs : '$ctl',
            require: 'ngModel',
            templateUrl: function(){
                var province = $PCAppConfiguration.province.toLowerCase();
                return $PCAppConfiguration.directivesViewsPath + '/form-driver-infraction-' + province + '.html';
            },
            scope: {
                ngModel     : "=",
                driverIndex : "="
            }
        };

        function Controller($scope){
            var vm = this;

            vm.ngModel = $scope.ngModel;
            vm.driverIndex = $scope.ngModel.driver.driverIndex;

        }
    });


})(angular);
