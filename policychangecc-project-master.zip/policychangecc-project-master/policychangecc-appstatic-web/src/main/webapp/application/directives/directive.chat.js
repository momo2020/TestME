(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccChat
     * @restrict A
     * @priority 0
     * 
     * @description
     * Activate the chat function to the targeted element
     * 
     * @requires $window
     * @requires $AppConfiguration
     * @requires $document
     * 
     * @example
     * <pre>
     * // Add to any element
     * <any cc-chat></any>
     * </pre>
	 */
	angular.module('INTACT.PolicyChange').directive('ccChat', function($window, $PCAppConfiguration, $document){
		return {
			restrict: 'A',
			priority: 0,
			link: function(scope, element){
                    // Define vars and URLs
                    var conf = $PCAppConfiguration;
				var localHost = $window.location.origin;

                    var iconsPath = localHost + $PCAppConfiguration.assetsPath + "/img/icons/";
                    var chatURL = conf.chatUrl + "/netagent/cimlogin.aspx?questid=" + conf.chatQuestId + "&portid=" + conf.chatPostId + "&pageid=DASH__fr_QC&nareferer=" + $window.escape(localHost);
                    var imgURL = conf.chatUrl + "/netagent/client/invites/chatimage.aspx?style=style0&questid=" + conf.chatQuestId + "&portid=" + conf.chatPostId + "&imagelanguage=en-us&customopenimage=" + iconsPath + "chat-open-biticon.png&customcloseimage=" + iconsPath + "chat-closed-biticon.png";

                    // Process the chat if available in the config
                    if (conf.chatAvailable) {
                         // Create the image in the DOM
                         var flagImage = $document[0].createElement('IMG');

                         // Event on the image load. Fired once loaded
                         flagImage.onload = function(){
                              if (flagImage.width > 1){
                                   element.on('click', function(){
                                        $window.open(chatURL, '_blank','resizable= no,width=500,height=475,scrollbars=yes');
                                   });
                              } else {
                                   element.addClass('chat-closed');
                              }
                         };

                         // Load the image URL
                         flagImage.src = imgURL;
                    } else {
                         //Chat not available
                         element.css('display', 'none'); 
                    }

                    scope.$on('$destroy', function(){
                         element.remove();
                    });
			}
		};
	});
})(angular);