(function(angular){
    'use strict';

    /**
     * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccFormRadioControl
     * @restrict AE
     * @requires INTACT.PolicyChange.$PCAppConfiguration
     *
     * @description
     * Handles the display of a radio button control
     *
     * @example
     * <pre>
     * // In controller
     * angular.module('PC').controller('$crtl', ctrl);
     *
     * function ctrl(){
     *   var vm = this;
     *   vm.onUpdate = function(id, value, oldValue){};
     *   vm.data = {id: 'myId', data: []}
     * }
     *
     * // In view
     * <cc-form-radio-control data-ng-model='$ctrl.data' data-on-change='$ctrl.onUpdate(id, value, oldValue)'></cc-form-select-control>
     * </pre>
     */
    angular.module('INTACT.PolicyChange').directive('ccFormRadioControl', 
        function($PCAppConfiguration, 
                $PCAnalyticsService) {

            return {
                restrict: 'AE',
                priority: 0,
                require: 'ngModel',
                templateUrl: $PCAppConfiguration.directivesViewsPath + '/form-radio.html',
                scope: {
                  ngModel: "=",
                  onChange: "&",
                  openScheduleDialog: "&"
                },
                link: function(scope){
                    scope.$watcher = scope.$watch('item', function(n, o){
                        if(o !== n) {
                            // Do not save if current coverage is FPX - an agent should manualy add this coverage.
                            if(scope.ngModel.id != "FPX"){
                                scope.onChange({id: scope.ngModel.id, value: n, oldValue: o});               
                            }
                            else if(n){
                                // Show popup if coverage is FPX
                                scope.openScheduleDialog();
                                    
                                scope.item = false;

                                // ******* Analytics - Coverage FPX selected
                                var props = {
                                    s_appStep: "pu:6",
                                    s_pageState: "313-0-0",
                                    s_recalcField: scope.ngModel.id + ":" + n,
                                    s_fastLane: n, 
                                    s_pageName: 'portfolio:policy update:coverage'
                                };

                                $PCAnalyticsService.trackPageView(props);
                            }
                        }
                    });

                    /*
                    * Make sure the selected value is the right one
                    */
                    var itemSelected = null;
                    if(scope.ngModel && scope.ngModel.data[0] === undefined){
                        itemSelected = false;
                    } else {
                        itemSelected = scope.ngModel.data[0].selected;
                    }

                    scope.item = itemSelected;

                    /**
                     * Clean-up directive destroy
                     */
                    scope.$on('$destroy', function() {
                        if(scope.$watcher){
                            scope.$watcher();
                        }
                    });
                }
            };
    });

 })(angular);