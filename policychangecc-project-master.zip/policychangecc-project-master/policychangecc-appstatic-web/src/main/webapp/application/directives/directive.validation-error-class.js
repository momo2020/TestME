(function(angular){
	'use strict';

    /**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccStickyHeader
     * @restrict A
     * @priority 0
     * @requires https://docs.angularjs.org/api/ng/service/$window
     * 
     * @description
     * Initialize && configure sticky HTML header.
	*/
	angular.module('INTACT.PolicyChange').directive('pchErrorValidationClass', function($filter){
		return {
			restrict: 'A',
			priority: 0,
			replace: false,
			link: function($scope, element, attrs){

                $scope.$on("ValidationDataUpdated", function(event, data){
    
                    var attrClass = attrs.pchErrorValidationClass;
                    attrClass = attrClass === "" ? 'ng-invalid-required' : attrClass;
                    var errorElement = attrs.pchErrorValidationElement || element[0].name;
                    element.removeClass(attrClass);
                    if(errorElement){
                        var error = $filter('filter')(data.errors, {'indexedName':errorElement});
                        if(error){
                            if(angular.isArray(error)){
                                if(error.length > 0){
                                    //There is an error for this field... 
                                    element.addClass(attrClass);
                                }
                            }
                        }
                    }
                });

			}
		};
	});
})(angular);