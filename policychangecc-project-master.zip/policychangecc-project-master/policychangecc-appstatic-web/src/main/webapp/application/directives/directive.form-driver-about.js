(function(angular){
    'use strict';

    /**
     * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccFormCarAbout
     */
    angular.module('INTACT.PolicyChange').directive('pcFormDriverAbout', function($PCAppConfiguration) {

        return {
            restrict: 'AE',
            priority: 0,
            controller: Controller,
            controllerAs : '$ctl',
            require: 'ngModel',
            templateUrl: function(){
                var province = $PCAppConfiguration.province.toLowerCase();
                return $PCAppConfiguration.directivesViewsPath + '/form-driver-about-' + province + '.html';
            },
            scope: {
                ngModel         : "=",
                driverIndex     : "=",
                isNewDriver     : "=",
                isSpouseVisible : "="
            }
        };

        function Controller($scope){
            var vm = this;

            vm.ngModel = $scope.ngModel;
            vm.isNewDriver = $scope.isNewDriver;
            vm.isSpouseVisible = $scope.isSpouseVisible;


            var updateStatus = {
                name: false,
                dob: false
            };

            vm.updatedFields = function(field){
                if($scope.ngModel.driver.modificationCode && $scope.ngModel.driver.modificationCode === "N"){
                    updateStatus[field] = true;
                    // Reset all fields if name and dob modified
                    if(updateStatus.name && updateStatus.dob){
                        updateStatus = {name: false, dob: false};
                        $scope.ngModel.clearDriverInformations();
                    }
                }
            };

        }
    });
})(angular);
