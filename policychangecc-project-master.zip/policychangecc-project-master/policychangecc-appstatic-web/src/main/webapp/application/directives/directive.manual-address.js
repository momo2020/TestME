(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:pcManualAddress
     * @restrict E
     * @priority 0
     *
     * @description
     * Manual address component
     *
     * @example
     * <pre>
     * // Add to any element
     * <pc-manual-address></pc-manual-address>
     * </pre>
	 */
	angular.module('INTACT.PolicyChange').directive('pcManualAddress', function($PCAppConfiguration){
		return {
			restrict: 'E',
            controller: 'PolicyChangeManualAddressController',
            controllerAs: 'manualAddressCtrl',
            templateUrl: $PCAppConfiguration.directivesViewsPath + '/manual-address.html',
			scope :{
				policyChangeData : "="
			}
		};
	});
})(angular);
