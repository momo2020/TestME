(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:pcProvinceVisibility
     * @restrict A
        *
     * @description
     * Directive to Show/Hide HTML control by Province
	 */
	angular.module('INTACT.PolicyChange').directive('pcSetProvinceVisibilityFor', function($PCAppConfiguration) {
		
		return {
			restrict: 'A',
			replace: true,
			link: function(scope, element, attrs) {
				var province = $PCAppConfiguration.province.toLowerCase();
		    	attrs.$observe('pcSetProvinceVisibilityFor', function(value) {
			        if (province != value) {
			          element.remove();
			        }
		      });
		    }
		};
	});

})(angular);
