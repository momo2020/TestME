(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
     * @name INTACT.PolicyChange.directive:pcCarousselItem
     * @restrict A
     * 
     * @description
     * Slider that allow the user to select the vehicle on the car policy
     * detail page.
     * 
     * @example
     * <pre>
     * <div cc-slider></div>
     * </pre>
	 */
	angular.module('INTACT.PolicyChange').directive('pcCarousselItem', function(){
		return {
			restrict: 'A',
			priority: 0,
			replace: false
		};
	});

})(angular);