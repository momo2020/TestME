(function(angular){
    'use strict';

    /**
     * @ngdoc directive
     * @name INTACT.PolicyChange.directive:ccFormCarAbout
     */
    angular.module('INTACT.PolicyChange').directive('ccFormCarAbout', function($PCAppConfiguration) {

        return {
            restrict: 'AE',
            priority: 0,
            controller: Controller,
            controllerAs : '$ctl',
            require: 'ngModel',
            templateUrl: function(){
                var province = $PCAppConfiguration.province.toLowerCase();
                return $PCAppConfiguration.directivesViewsPath + '/form-car-about-' + province + '.html';
            },
            scope: {
                ngModel         : "=",
                carIndex        : "=",
                ddOptions       : "=",
                isReplaceCar    : "=",
                policyHolders   : "="
            }
        };


        function Controller ($filter, $scope, $PolicyChange){

            var vm = this;
            vm.currentVehicles = $PolicyChange.$get().policyChange().data.response.vehicles;
            vm.carIndex = $scope.ngModel.vehicle.riskIndex;
            vm.ngModel = $scope.ngModel;
            vm.ddOptions = $scope.ddOptions;
            vm.isReplaceCar = $scope.isReplaceCar;
            vm.policyHolders = $scope.policyHolders;
            vm.vehicleCurr = angular.copy($scope.ngModel.vehicle);
            vm.showBlueBox = showBlueBox;

            function showBlueBox(fn){
                return vm.isReplaceCar && ($scope.ngModel.vehicle[fn] === null || $scope.ngModel.vehicle[fn] === "");
            }
        }
    });

 })(angular);
