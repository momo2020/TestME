(function(angular){
	'use strict';

  /**
	* @ngdoc controller
	* @name INTACT.PolicyChange.controller:pchErrorMessageController
	* @description
	* Controller for pchErrorMessage component<br>
	*
	*/
	angular.module('INTACT.PolicyChange').controller('pchErrorMessageController', controller);

	function controller($filter, $scope, $InlineValidationService) {

		var vm = this;
		var $translate = $filter('translate');
		
		init();

		function init(){
			vm.error = "";
			$scope.$on("ValidationDataUpdated", function(event, data){
				setError(data.errors);
				$InlineValidationService.scrollTo(data.errors);
			});
		}

		// Set the error on the component
		function setError(errors){
			vm.error = "";
			if(errors){
				angular.forEach(errors, function(error, key){
					var elementInError = error.field.toUpperCase();
					var componentElement = vm.element.toUpperCase();
					var errorMessage =  vm.message ? vm.message : error.message;
					if(elementInError === componentElement){
						if(error.elementIndex){
							if(error.elementIndex == vm.index){
								vm.error = errorMessage;
							}
						}
						else{
							vm.error = errorMessage;
						}

					}
				});
			}
			
		}


	}

})(angular);
