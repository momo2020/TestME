(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchErrorMessage
	 * @description
	 * Component used to define the basement question
	 *
	 * @requires RQQ.App.service:$AppRouteStatesProvider
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchErrorMessage', /*@ngInject*/ {
		bindings: {
			element: "@",
			index: "@",
			class: "@",
			message: "@"
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/error-message/error-message.html';
	    },
	    controller: 'pchErrorMessageController'
	});

})(angular);
