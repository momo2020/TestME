(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchRadioGroup
	 * @description
	 * Component used to manage a radio button group format
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchRadioGroup', /*@ngInject*/ {
		bindings: {
			value: "=",
			label: "@",
			validationField: "@",
			innerClass: "@",
			items: "=",
			onClick: "&"
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/custom-fields/radio-group/radio-group.html';
	    },
	    controller: 'pchRadioGroupComponentController',
		require: {
			
		}
	});

})(angular);
