(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDropDown
	 * @description
	 * Component used to manage a drop down format
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDropDown', /*@ngInject*/ {
		bindings: {
			value: "=",
			label: "@",
			validationField: "@",
			innerClass: "@",
			items: "="
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/custom-fields/drop-down/drop-down.html';
	    },
	    controller: 'pchDropDownComponentController',
		require: {
			
		}
	});

})(angular);
