(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchInputNumberComponentController
	 * @description
	 * Controller for pchInputNumber component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchInputNumberComponentController', controller);

	 function controller($filter, $rootScope) {
	 	var vm = this;
	 	
	 	this.$onInit = function(){
	 		
        }
    }
})(angular);
