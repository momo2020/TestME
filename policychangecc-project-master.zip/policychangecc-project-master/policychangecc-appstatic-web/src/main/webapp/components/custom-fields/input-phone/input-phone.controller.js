(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchInputPhoneComponentController
	 * @description
	 * Controller for pchInputPhone component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchInputPhoneComponentController', controller);

	 function controller($filter, $rootScope) {
	 	var vm = this;
	 	
	 	this.$onInit = function(){

        }

        this.$doCheck = function(){
        	var element = $('[validationfield="' + vm.validationField + '"]'); 
        	var errorElement = $('[errorfor="' + vm.validationField + '"]'); 
        	element.on('keypress', function() {
    			errorElement.text();
	        	errorElement.removeClass("error").addClass("ng-hide"); 
	            element.removeClass("ng-invalid ng-invalid-required");
	      });
        }

    }
})(angular);
