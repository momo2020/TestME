(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchInputPhone
	 * @description
	 * Component used to manage an input phone format
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchInputPhone', /*@ngInject*/ {
		bindings: {
			value: "=",
			label: "@",
			validationField: "@",
			innerClass: "@",
			maxLength: "@",
			onBlur: "&"
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/custom-fields/input-phone/input-phone.html';
	    },
	    controller: 'pchInputPhoneComponentController',
		require: {
			
		}
	});

})(angular);
