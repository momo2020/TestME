(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchInputNumber
	 * @description
	 * Component used to manage an input number format
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchInputNumber', /*@ngInject*/ {
		bindings: {
			value: "=",
			label: "@",
			validationField: "@",
			innerClass: "@",
			maxLength: "@"
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/custom-fields/input-number/input-number.html';
	    },
	    controller: 'pchInputNumberComponentController',
		require: {
			
		}
	});

})(angular);
