(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchRadioGroupComponentController
	 * @description
	 * Controller for pchRadioGroup component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchRadioGroupComponentController', controller);

	 function controller($filter, $rootScope) {
	 	var vm = this;
	 	
	 	this.$onInit = function(){

        }

        this.$doCheck = function(){
        	var element = $('[validationfield="' + vm.validationField + '"]'); 
        	var errorElement = $('[errorfor="' + vm.validationField + '"]'); 
        	element.on('click', function() {
    			errorElement.text();
	        	errorElement.removeClass("error").addClass("ng-hide"); 
	            element.removeClass("ng-invalid ng-invalid-required");
	      });
        }

    }
})(angular);
