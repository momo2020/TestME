(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDropDownComponentController
	 * @description
	 * Controller for pchDropDown component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDropDownComponentController', controller);

	 function controller($filter, $rootScope) {
	 	var vm = this;
	 	
	 	this.$onInit = function(){

        }

        this.$doCheck = function(){
        	var element = $('[validationfield="' + vm.validationField + '"]'); 
        	var errorElement = $('[errorfor="' + vm.validationField + '"]'); 
        	element.on('change', function() {
    			errorElement.text();
	        	errorElement.removeClass("error").addClass("ng-hide"); 
	            element.removeClass("ng-invalid ng-invalid-required");
	      });
        }

    }
})(angular);
