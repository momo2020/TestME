(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchAddressComponentController
	 * @description
	 * Controller for pchAddress component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchAddressComponentController', controller);

	 function controller($filter) {

      // ready to work when the parent controller is initialized
		this.$onInit = function() {

			var vm = this;
		    var $translate = $filter('translate');

			init();

			function init(){

				vm.labels = {
					title : $translate('LBL43755.address.title'),
					modify : $translate('LBL01631.modify.button')
				}

				// Return to address page
				vm.navigate = function(){
					vm.raform.navigate("PC_ADDRESS");
				}

			}
  		}

	}

})(angular);
