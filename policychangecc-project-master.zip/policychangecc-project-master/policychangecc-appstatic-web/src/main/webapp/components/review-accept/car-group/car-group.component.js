(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarGroup
	 * @description
	 * Component used to group car updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarGroup', /*@ngInject*/ {
		bindings: {
			address: "="
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/review-accept/car-group/car-group.html';
	    },
	    controller: 'pchCarGroupComponentController',
		require: {
			raform: '^pchReviewAcceptForm'
		}
	});

})(angular);
