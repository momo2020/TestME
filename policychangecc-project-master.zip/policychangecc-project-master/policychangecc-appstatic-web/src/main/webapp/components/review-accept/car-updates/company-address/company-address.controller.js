(function(angular){
	'use strict';

	/**
	* @ngdoc controller
	* @name INTACT.PolicyChange.controller:pchCompanyAddressComponentController
	* @description
	* Controller for pchCompanyAddress component<br>
	*
	*/
	angular.module('INTACT.PolicyChange').controller('pchCompanyAddressComponentController', controller);

	function controller($filter, $scope) {

		// ready to work when the parent controller is initialized
		this.$onInit = function() {

			var vm = this;

			var $translate = $filter('translate');


			init();

			// Manual Address
			// Postal Code Found Event
			$scope.$on('ManualAddressPostalCodeFoundEvnt', function(evt, postalCode){
				vm.disableManualInput = false;
				vm.show_error = false;
			});

			// Postal Code Not Found Event
			$scope.$on('ManualAddressPostalCodeNotFoundEvnt', function(){
				vm.disableManualInput = true;
				vm.show_error = true;
			});

			// Manual Address Reset Event
			$scope.$on('ManualAddressPostalCodeResetEvnt', function(){
				vm.disableManualInput = true;
				resetAddress();
			});

			// Manual Address Complete Event
			$scope.$on('ManualAddressCompleteEvnt', function(evt, manualAddress){
				vm.manualAddress = manualAddress;
				setAddress();
			});

			// Manual Address Incomplete Event
			$scope.$on('ManualAddressIncompleteEvnt', function(evt, manualAddress){
				vm.manualAddress = manualAddress;
				setAddress();
			});

	        function setAddress(){

				var postalCode = $filter('uppercase')(vm.manualAddress.postalCode) || "";
				var city = "",
					municipalityCode = "";
				if(angular.isDefined(vm.manualAddress.city) && vm.manualAddress.city !== null){
					city = vm.manualAddress.city.city;
					municipalityCode = vm.manualAddress.municipalCode;
				}

				vm.address.province = vm.manualAddress.province;
				vm.address.postalCode = postalCode.replace(" ", "");
				vm.address.civicNumber = vm.manualAddress.streetNumber;
				vm.address.apartment = vm.manualAddress.aptNumber;
				vm.address.municipality = city;
				vm.address.municipalityCode = municipalityCode;

				if(angular.isDefined(vm.manualAddress.street)){
					vm.address.streetDirection = vm.manualAddress.street.streetDirection;
					vm.address.streetName = vm.manualAddress.street.streetName;
					vm.address.streetType = vm.manualAddress.street.streetType;
				}
				else{
					if(angular.isDefined(vm.manualAddress.streetFreeFormat) && vm.manualAddress.streetFreeFormat !== ""){
						vm.address.streetDirection = "";
						vm.address.streetName = vm.manualAddress.streetFreeFormat;
						vm.address.streetType = "";
					}
				}
			}


			function init(){

				// Manual Address variables
				vm.disableManualInput = true;
		        vm.show_error = false;
				vm.manualAddress = {};

				vm.labels = {
					companyAddress: $translate('LBLXXXX.car.company.financing.address.label'),
					address :{
						postalCode : $translate('LBL42272.manual.address.postalcode.label'),
						city : $translate('LBL42274.manual.address.city.label'),
						streetNumber : $translate('LBL42265.manual.address.streetNumber.label'),
						street : $translate('LBL42266.manual.address.street.label'),
						suite : $translate('LBLXXXX.car.company.financing.address.suite.label')
					},
					errorMessage : $translate('MSG00440.manual.address.error.label')
				};

				vm.address = {
					apartment: "",
					civicNumber: "",
					streetName : "",
					streetType : "",
					streetDirection : "",
					municipality : "",
					// municipalCode : "", 
					postalCode : "",
					province : ""
				};
			}

			function resetAddress(){
				angular.forEach(vm.address, function(value, key){
					vm.address[key] = "";
				});
			}

		}

	}

})(angular);
