(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarDamage
	 * @description
	 * Component that allow user to confirm damages when existing vehicle has been modify and 
	 * basic coverage has been added or deductible of basic coverage has been decreased.
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarDamage', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/review-accept/car-damage/car-damage.html';
	    },
	    controller: 'pchCarDamageComponentController',
		require: {
			raform: '^pchReviewAcceptForm',
			updateCoverageForm: '^pchUpdateCoverages'
		}
	});

})(angular);
