(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchAddress
	 * @description
	 * Component used to define the basement question
	 *
	 * @requires RQQ.App.service:$AppRouteStatesProvider
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchAddressUpdate', /*@ngInject*/ {
		bindings: {
			address: "="
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/review-accept/address/address.html';
	    },
	    controller: 'pchAddressComponentController',
		require: {
			raform: '^pchReviewAcceptForm'
		}
	});

})(angular);
