(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarDamageComponentController
	 * @description
	 * Controller for pchCarDamageComponentController component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarDamageComponentController', controller);

	 function controller() {

      	// ready to work when the parent controller is initialized
		this.$onInit = function() {
			var vm = this;
  		}
	}

})(angular);
