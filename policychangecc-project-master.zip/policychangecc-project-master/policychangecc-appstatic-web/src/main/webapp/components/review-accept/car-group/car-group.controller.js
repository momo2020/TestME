(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarGroupComponentController
	 * @description
	 * Controller for pchAddress component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarGroupComponentController', controller);

	 function controller($filter, $PCAnalyticsService, $PolicyChangeModifications, $PolicyChange) {

      // ready to work when the parent controller is initialized
		this.$onInit = function() {

			var vm = this;

		    var modifications = $PolicyChangeModifications.$get().getModifications();
			var $translate = $filter('translate');

			init();

			function init(){

				vm.policyChange = $PolicyChange.$get().policyChange();

				vm.labels = {
					title : $translate('LBL43755.address.title'),
					modifyButton: $translate('LBL01631.modify.button')
				}


				// Car Updates ("M")
				vm.updatedCars = modifications.getVehiclesByCode("M");

				// Car Addition ("N")
				vm.addedCars = modifications.getVehiclesByCode("N");

				// Car Substitution ("U")
				vm.replacedCars = modifications.getVehiclesByCode("U");

				vm.hideContainer = vm.updatedCars.length <= 0 && 
									vm.addedCars.length <= 0 &&
									vm.replacedCars.length <= 0;

				// Return to address page
				vm.navigate = function(){

					// ******* Analytics - [F6.24] Modify (at Review)
					var props_modify = {
						s_pageState : "137-0-0",
						s_pageName: 'portfolio:policy update:review'
					};

					$PCAnalyticsService.trackPageView(props_modify);

					vm.raform.navigate("PC_CARS");
				}


			}
  		}

	}

})(angular);
