(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCompanyAddress
	 * @description
	 * Component used when the user selects Other in dropdown Name of the financingCompany or leasedCompany
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCompanyAddress', /*@ngInject*/ {
		bindings: {
			vehicleIndex : "@",
			address : "="
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/review-accept/car-updates/company-address/company-address.html';
	    },
	    controller: 'pchCompanyAddressComponentController',
		require: {
			raform: '^pchReviewAcceptForm'
		}
	});

})(angular);
