(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarUpdates
	 * @description
	 * Component used when there is a car update/add/replace
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarUpdates', /*@ngInject*/ {
		bindings: {
			car: "=",
			policyChange: "=",
			change: "@"
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/review-accept/car-updates/car-updates.html';
	    },
	    controller: 'pchCarUpdatesComponentController',
		require: {
			raform: '^pchReviewAcceptForm'
		}
	});

})(angular);
