(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarUpdatesComponentController
	 * @description
	 * Controller for pchCarUpdates component<br>
	 * ControllerAs : $ctrl
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarUpdatesComponentController', controller);

	 function controller($q, 
	 					$filter, 
	 					$scope, 
	 					$PolicyChangeModifications, 
	 					PolicyHolderModel, 
	 					$CompaniesService, 
	 					$PolicyChange,
	 					WarningModel) {

	 	// ready to work when the parent controller is initialized
		this.$onInit = function() {

	     	var $translate = $filter('translate'),
	     		otherChoice = {key:-1, value: $translate('LBLXXXX.review.other')},
	     		CLIENT_WARNING = 'FPX';

	     	var vm = this;
	     	vm.hasFPQ5 = hasFPQ5; 
	     	var modifications = $PolicyChangeModifications.$get().getModifications();
	     	var warningsFPQ5 = getWarningsFPQ5();

	     	init();

			function init(){

				// Car Year/Make/Model descriptions (used in labels)
				var carDescriptions = getVehiclesDescription();

				/**
				 * @ngdoc property
				 * @name INTACT.PolicyChange.controller:pchCarUpdatesComponentController#labels
		         * @propertyOf INTACT.PolicyChange.controller:pchCarUpdatesComponentControlle
				 * @description
				 * Stock the labels for the display
				 */
				vm.labels = {
		     		componentTitle : $translate('LBLXXXXX.car.component.title.' + vm.change, {current: carDescriptions.current, new: carDescriptions.updated}),
		     		modifyButton: $translate('LBL01631.modify.button'),
		     		aboutTitle: $translate('LBL42251.about'),
		     		formVin: $translate('LBL43679.vin'),
		     		acquisitionDate: $translate('LBL43680.possession'),
		     		secondOwner: $translate('LBL00584.secondOwner'),
		     		secondOwnerName: $translate('LBL45133.secondOwnerName'),
		     		carFinanced: $translate('LBL43681.financed'),
		     		financingCompany: $translate('LBL43682.financingCompany'),
		     		leasingCompany: $translate('LBL43683.leasedCompany'),
		     		yes: $translate('LBLXXXX.policyChange.yes'),
		     		no: $translate('LBLXXXX.policyChange.no'),
		     		companyNameLabel : $translate('LBLXXXX.car.company.financing.name.label')
		     	}

		     	/**
				 * @ngdoc property
				 * @name INTACT.PolicyChange.controller:pchCarUpdatesComponentController#infoFormObject
		         * @propertyOf INTACT.PolicyChange.controller:pchCarUpdatesComponentController
				 * @description
				 * Hold information of the info Form
				 */
				vm.infoForm = {
					leasedCompany: null,
					secondOwner: null,
				};

				/**
				 * @ngdoc property
				 * @name INTACT.PolicyChange.controller:pchCarUpdatesComponentController#combos
		         * @propertyOf INTACT.PolicyChange.controller:pchCarUpdatesComponentController
				 * @description
				 * Holds the values for all combos
				 */
				vm.combos = {
	                financingCompanies   : [{}],
	                leasedCompanies   : [{}],
	                licenceMonths : $filter('comboList')('licenceMonth'),
	                licenceYears : getAcquisitionYears(),
	                policyHolders : getPolicyHolders()
	            };


	            vm.toUppercase = function(serialnumber){
	            	vm.car.vehicle.updated.serialNumber = serialnumber.toUpperCase();
	            };


				/**
				 * @ngdoc property
				 * @name INTACT.PolicyChange.controller:pchCarUpdatesComponentController#infoForm
		         * @propertyOf INTACT.PolicyChange.controller:pchCarUpdatesComponentController
				 * @description
				 * Display the form to collect information or not based on the type of change
				 */
				vm.infoFormRequired = (vm.change==="U" || vm.change==="N");

				/**
				 * @ngdoc property
				 * @name INTACT.PolicyChange.controller:pchCarUpdatesComponentController#infoChange
		         * @propertyOf INTACT.PolicyChange.controller:pchCarUpdatesComponentController
				 * @description
				 * Display the change information or not based on the type of change
				 */
				vm.infoChangeRequired = (vm.change==="M");

				/**
				 * @ngdoc property
				 * @name INTACT.PolicyChange.controller:pchCarUpdatesComponentController#leased
		         * @propertyOf INTACT.PolicyChange.controller:pchCarUpdatesComponentController
				 * @description
				 * Flag indicating if the concerned car is leased or not
				 */
				vm.leased = vm.car.vehicle.updated ? vm.car.vehicle.updated.leased : false;

				/**
				 * @ngdoc property
				 * @name INTACT.PolicyChange.controller:pchCarUpdatesComponentController#leased
		         * @propertyOf INTACT.PolicyChange.controller:pchCarUpdatesComponentController
				 * @description
				 * Flag indicating if the concerned car is leased or not
				 */
				vm.vehicleIndex = vm.car.vehicle.updated.riskIndex;

				/**
				 * @ngdoc property
				 * @name INTACT.PolicyChange.controller:pchCarUpdatesComponentController#acquisitionDate
		         * @propertyOf INTACT.PolicyChange.controller:pchCarUpdatesComponentController
				 * @description
				 * Hold the 2 date fields for acquisition date
				 */
				vm.acquisitionDate = {
					year: null,
					month: null
				}

				/**
				 * @ngdoc property
				 * @name INTACT.PolicyChange.controller:pchCarUpdatesComponentController#getLabel
		         * @propertyOf INTACT.PolicyChange.controller:pchCarUpdatesComponentController
				 * @description
				 * Returns labels for the review and update
				 */
				vm.getLabel = function(key){
					return $filter('translate')('LBLXXXXX.review.updated.' + key);
				}

				/**
				 * @ngdoc property
				 * @name INTACT.PolicyChange.controller:pchCarUpdatesComponentController#navigate
		         * @propertyOf INTACT.PolicyChange.controller:pchCarUpdatesComponentController
				 * @description
				 * Navigate to the proper page
				 */
				vm.navigate = function(){
					vm.raform.navigate("PC_CARS");
				}

				// Init Companies
				initCompanies();

				// Watchers
				$scope.$watch('$ctrl.acquisitionDate', function(){
					if( vm.acquisitionDate.year !== null && vm.acquisitionDate.month !== null ){
	                	vm.car.vehicle.updated.purchaseDate = vm.acquisitionDate.year.toString() + "-" + vm.acquisitionDate.month.toString() + "-01";
	              	}
	              	else{
		                vm.car.vehicle.updated.purchaseDate = "";
	    	        }
	            }, true);

			}

			function getWarningsFPQ5(){
				var warningContext = new WarningModel($PolicyChange.$get().policyChange().validation);
				if(warningContext.hasWarning && warningContext.isClientWarning()){
					return _.where(warningContext.warnings, {code: CLIENT_WARNING});
				}
				return null;
			}

			function hasFPQ5 (carIndex){
				return _.some(warningsFPQ5, {riskSequence: carIndex+1}); 
			}

			// Get the companies for the form
			function initCompanies(){
				$CompaniesService.getFinancingCompanies().then(function(success){
					vm.combos.financingCompanies = $filter('orderBy')(success.data, 'value');
					vm.combos.financingCompanies.push(otherChoice);
				},
				function(error){
					vm.combos.financingCompanies = [otherChoice];
				});

				$CompaniesService.getLocationCompanies().then(function(success){
					vm.combos.leasedCompanies = $filter('orderBy')(success.data, 'value');
					vm.combos.leasedCompanies.push(otherChoice);
				},
				function(error){
					vm.combos.leasedCompanies = [otherChoice];
				})
			}

			// Process each vehicle to get the proper Year/Make/Model description
			function getVehiclesDescription() {
				var descriptions = {
					current: "",
					updated: ""
				};
				// Current
				if(vm.car.vehicle.current){
					descriptions.current = $filter('formatCarName')(vm.car.vehicle.current.model.make, vm.car.vehicle.current.model.model, vm.car.vehicle.current.model.year) ;
				}

				// Updated
				if(vm.car.vehicle.updated){
					descriptions.updated =  $filter('formatCarName')(vm.car.vehicle.updated.model.make, vm.car.vehicle.updated.model.model, vm.car.vehicle.updated.model.year) ;
				}
				return descriptions
			}

			function getAcquisitionYears(){
				var yearList = [];
				var currentYear = new Date().getFullYear();
				var carYear = 0;
				if(vm.car.vehicle.updated){
					carYear = vm.car.vehicle.updated.model.year;
				}
				for (var y = currentYear; y >= carYear - 1; y--){
					yearList.push({key: y.toString(), value: y.toString()})
				}
				return yearList
			}

			function getPolicyHolders(){
				var phs = [];
				var _phData = vm.raform.policyChange.policyChange ? vm.raform.policyChange.policyChange.policyHolders : policyChange.currentPolicy.policyHolders;
				angular.forEach(_phData, function(ph){
					var m = new PolicyHolderModel(ph);
					if(m.partyId !== vm.car.vehicle.updated.registerOwner){
						phs.push({
							key: m.partyId,
							value: $filter('pcCapitalize')(m.firstName) + " " + $filter('pcCapitalize')(m.lastName)
						});
					}
				});
				phs.push({key: -1,value: $translate('global.other')});
                return $filter('orderBy')(phs, 'value');
			};


		}
	}

})(angular);
