(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverNotLivingWithParentsComponentController
	 * @description
	 * Controller for pchDriverGender component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverNotLivingWithParentsComponentController', controller);

	 function controller($filter,
	 					$PolicyChange,
	 					$rootScope) {

 		var vm = this,
 			$comboList = $filter('comboList');

	 	this.$onInit = function(){
	 		vm.labelNotLivingWithParent = $filter('translate')('LBL45921.driver.about.monthNotLivingParent');
	 		vm.combos = {
	 			allValues : $comboList('monthNotLivingParent')
	 		};

        }

        this.$doCheck = function(){
        	
	 		vm.showMonthsNotLivingParents = function(){
	 			var isMale = vm.formDriverAbout.ngModel.driver.gender === 'M',
	 				isInAge = vm.formDriverAbout.ngModel.showIsStudent(vm.formDriverAbout.ngModel.driver.dateOfBirth, $PolicyChange.$get().policyChange().state.studentAgeThreshold),
	 				isFullTimeStudent = vm.formDriverAbout.ngModel.driver.occupation === "0123";
	 			
	 			var show = isMale && isInAge && isFullTimeStudent ;

	 			if(!show){
	 				vm.formDriverAbout.ngModel.driver.monthNotLivingParent = null;
	 			}

	 			return show;
	 		};
        };
    }
})(angular);
