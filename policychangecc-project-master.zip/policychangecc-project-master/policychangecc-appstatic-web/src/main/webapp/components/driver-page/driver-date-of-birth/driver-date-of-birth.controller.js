(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarAnnualKmComponentController
	 * @description
	 * Controller for pchCarConditionComponent component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverDateOfBirthComponentController', controller);

	 function controller($filter, $rootScope) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$orderBy = $filter('orderBy'),
	 			$comboList = $filter('comboList');
	 		
	 		vm.viewDriver = {
	 			dayBirth    : vm.formDriverAbout.ngModel.driversDobObject().day,
	 			monthBirth  : vm.formDriverAbout.ngModel.driversDobObject().month, 
	 			yearBirth   : vm.formDriverAbout.ngModel.driversDobObject().year
	 		};

	 		vm.combos = {
	 			months          : getMonthsList()
	 		};
            vm.combos.months.unshift({key : '', value : $filter('translate')('policychange.placeholder.month')});

	 		vm.setDateOfBirth = function(){
	 		    var wasDobChanged = true;
	 		    if( vm.viewDriver.dayBirth && vm.viewDriver.monthBirth && vm.viewDriver.yearBirth ){
	 		        var date = {
	 		            year : vm.viewDriver.yearBirth,
	 		            month : vm.viewDriver.monthBirth,
	 		            day : vm.viewDriver.dayBirth
	 		        };
	 		        var newDob = vm.formDriverAbout.ngModel.buildDob(date, vm.formDriverAbout.ngModel.driver.driverIndex);

	 		        wasDobChanged =  vm.formDriverAbout.ngModel.driver.dateOfBirth !== newDob;
	 		        if(wasDobChanged){
	 		            vm.formDriverAbout.ngModel.driver.dateOfBirth = newDob;
	 		            vm.formDriverAbout.ngModel.driver.licenceObtentionDate = "";
	 		            $rootScope.$broadcast('dobChanged', vm.formDriverAbout.ngModel);
	 		        }
	 		    }
	 		    else{
	 		        vm.formDriverAbout.ngModel.driver.dateOfBirth = null;
	 		    }

	 		    if(wasDobChanged){
	 		        vm.formDriverAbout.updatedFields("dob");
	 		    }
	 		    
	 		};

            function getMonthsList (){
                var liste = $comboList('licenceMonth');
                return $orderBy(liste, 'key');
            }

            $rootScope.$on('reloadDriver', function(){
            	vm.viewDriver = {
            		dayBirth    : vm.formDriverAbout.ngModel.getDateOfBirth('day', vm.formDriverAbout.ngModel.driver.dateOfBirth),
            		monthBirth  : vm.formDriverAbout.ngModel.getDateOfBirth('month', vm.formDriverAbout.ngModel.driver.dateOfBirth),
            		yearBirth   : vm.formDriverAbout.ngModel.getDateOfBirth('year', vm.formDriverAbout.ngModel.driver.dateOfBirth)
            	};
            });
        }
    }
})(angular);
