(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverRelationshipComponentController
	 * @description
	 * Controller for pchDriverRelationship component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverRelationshipComponentController', controller);

	 function controller($filter, $rootScope) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$comboList = $filter('comboList');

	 		vm.combos = {
	 			relationship : vm.formDriverAbout.ngModel.driver.gender !== '' ? getRelationshipCombo() : [{key : '', value : ''}]
	 		};

            vm.showRelationship = function(){
                var hasGender = vm.formDriverAbout.ngModel.driver.gender !== '',
                    hasRelationshipSet = false;
                if( vm.formDriverAbout.ngModel.driver.relationshipToPolicyHolder === null && !vm.formDriverAbout.isNewDriver ){
                    hasRelationshipSet = true;
                }

                return hasGender && !hasRelationshipSet;
            };

            vm.setRelationshipList = function(){
                vm.combos.relationship = getRelationshipCombo();
            };

            vm.removeError = function (field){
                angular.element('[data-errorFor='+field+']').addClass('ng-hide');
            };

            function getRelationshipCombo(){
                var param = 'familyRelationShip',
                    driverGender = vm.formDriverAbout.ngModel.driver.gender;
                param += driverGender;
                var relationshipCombo = $comboList(param);
                
                // Remove spouse from the list if spouse is not visible
                if(!vm.formDriverAbout.isSpouseVisible && !isSpouseSelectedForCurrentDriver()){
                    relationshipCombo = relationshipCombo.filter(function(relationship) {
                        return relationship.key !== "C";
                    });
                }
                relationshipCombo.unshift({key : null, value : $filter('translate')('LBLXXXX.car.select')});

                return relationshipCombo;
            }


            function isSpouseSelectedForCurrentDriver(){
                return vm.formDriverAbout.ngModel.driver.relationshipToPolicyHolder === 'C';
            }

            $rootScope.$on('loadRelationship', function(){
            	vm.setRelationshipList();
            });

        }
    }
})(angular);
