(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverInfractionMinorComponentController
	 * @description
	 * Controller for pchDriverInfractionMinor component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverInfractionMinorComponentController', controller);

	 function controller($filter, $rootScope) {
 		var vm = this,
 			$comboList = $filter('comboList');

	 	this.$onInit = function(){

            vm.comboInfraction = $comboList('minorInfractions', 'Integer');

        };

        this.$doCheck = function(){

	 		vm.showInfractionDetail = function(){
	 			return vm.formDriverInfraction.ngModel.driver.infractionsPast3Years;
	 		};

        };

    }
})(angular);
