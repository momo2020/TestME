(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverLicenceTrainingOnComponentController
	 * @description
	 * Controller for pchDriverLicenceType component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverLicenceTrainingOnComponentController', controller);

	 function controller($filter) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$translate = $filter('translate'),
	 			$getLicenceType = $filter('getLicenceType'),
	 			$comboList = $filter('comboList');

	 		vm.labels = {
	 			driverTraining 	: $translate('LBL42783.driver.record.training'),
              	yes           	: $translate('policychange.radio.yes'),
              	no            	: $translate('policychange.radio.no')
	 		};
        }
    }
})(angular);
