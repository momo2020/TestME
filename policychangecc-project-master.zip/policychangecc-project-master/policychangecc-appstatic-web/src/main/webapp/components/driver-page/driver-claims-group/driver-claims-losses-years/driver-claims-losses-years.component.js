(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverClaims
	 * @description
	 * Component used to group driver updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverClaimsLossesYears', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-claims-group/driver-claims-losses-years/driver-claims-losses-years.html';
	    },
	    controller: 'pchDriverClaimsLossesYearsComponentController',
		require: {
			formDriverClaims: '^pcFormDriverClaims'
		}
	});

})(angular);
