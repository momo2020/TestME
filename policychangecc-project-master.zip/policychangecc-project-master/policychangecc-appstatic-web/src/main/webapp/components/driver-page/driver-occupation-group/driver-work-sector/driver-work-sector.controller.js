(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverWorkSectorComponentController
	 * @description
	 * Controller for pchDriverGender component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverWorkSectorComponentController', controller);

	 function controller($filter,
	 					$rootScope) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$comboList = $filter('comboList'),
	 			$translate = $filter('translate');

			vm.combos = {
	 			workSector : $comboList('workSector')
	 		};
	 		vm.combos.workSector.push({key : '0015', value : $translate('LBLXXXXX.work.sector.other')})
	 		vm.combos.workSector.unshift({key : '', value : $translate('LBLXXXX.car.select')})

	 		vm.loadOccupationsByWorksector = function(){
	 		 	$rootScope.$broadcast('loadOccupations');
	 		}
        }
    }
})(angular);
