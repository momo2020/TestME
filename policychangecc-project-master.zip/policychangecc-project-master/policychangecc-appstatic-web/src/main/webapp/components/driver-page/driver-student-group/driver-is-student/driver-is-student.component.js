(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverIsStudent
	 * @description
	 * Component used to group driver updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverIsStudent', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-student-group/driver-is-student/driver-is-student.html';
	    },
	    controller: 'pchDriverIsStudentComponentController',
		require: {
			formDriverStudent: '^pcFormDriverStudent'
		}
	});

})(angular);
