(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverInfractionMajor
	 * @description
	 * Component used to group driver updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverInfractionMajor', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-infraction-group/driver-infraction-major/driver-infraction-major.html';
	    },
	    controller: 'pchDriverInfractionMajorComponentController',
		require: {
			formDriverInfraction: '^pcFormDriverInfraction'
		}
	});

})(angular);
