(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverStudentAddressOutside
	 * @description
	 * Component used to group driver updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverStudentAddressOutside', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-student-group/driver-student-address-outside/driver-student-address-outside.html';
	    },
	    controller: 'pchDriverStudentAddressOutsideComponentController',
		require: {
			formDriverStudent: '^pcFormDriverStudent'
		}
	});

})(angular);
