(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverOccupationComponentController
	 * @description
	 * Controller for pchDriverOccupation component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverOccupationComponentController', controller);

	 function controller($filter, 
	 					$rootScope, 
	 					$PolicyChange, 
	 					$WorkSectorService) {
	 	var vm = this;
	 	this.$onInit = function(){

	 		vm.occupationList = [];
	 		vm.showOccupation = displayOccupation();

	 		$rootScope.$on('loadOccupations', function(){
	 			// Show ocuppation only for new drivers
	 			if(isDriverNew(vm.formDriverAbout.ngModel)){
		 			if(vm.formDriverAbout.ngModel.driver.workSector === ''){
		 				resetOccupation();
		 			}
		 			else if(angular.isDefined(vm.formDriverAbout.ngModel.driver.workSector)){
		 				getOccupations();
		 			}
		 		}
	 		});


	 		// Private functions
	 		function displayOccupation (){
	 			return  vm.occupationList.length > 0 ? true : false;
	 		}

	 		function resetOccupation (){
	 			vm.formDriverAbout.ngModel.driver.occupation = null;
	 		}

	 		function getOccupations(){
	 			var effectiveDate = $PolicyChange.$get().policyChange().currentPolicy.effectiveDate;
	 			var workSector = vm.formDriverAbout.ngModel.driver.workSector;

				return $WorkSectorService.getOccupations(workSector, effectiveDate).then(function (success){
					var list = $filter('orderBy')(success.data, 'value');
					var show = list.length > 1;

					if(show){
						list.unshift({key : null, value : $filter('translate')('LBLXXXX.car.select')});
					}

					loadOccupationCombo(list, show);

				});

			};

			function loadOccupationCombo(occupationList, show){

	 			if(show){
	 				vm.occupationList = occupationList;
	 				show = vm.occupationList.length > 0 ? true : false;
	 			}
	 			else{
	 				vm.formDriverAbout.ngModel.driver.occupation = occupationList[0].key;
	 			}

	 			vm.showOccupation = show;
			}

			function isDriverNew(driverObject){
				return driverObject.driver.modificationCode === 'N' || vm.formDriverAbout.isNewDriver;
			}

        };

    }
})(angular);
