(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverCancelledComponentController
	 * @description
	 * Controller for pchDriverCancelled component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverInfractionComponentController', controller);

	 function controller($filter, $rootScope) {
	 	this.$onInit = function(){
	 		var vm = this;
			vm.labelInfractionIndicator = $filter('translate')('LBL42886.driver.infractions.indicator');
        }
    }
})(angular);
