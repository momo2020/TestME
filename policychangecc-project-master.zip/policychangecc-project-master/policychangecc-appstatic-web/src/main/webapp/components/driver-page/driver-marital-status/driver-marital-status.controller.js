(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverMaritalStatusComponentController
	 * @description
	 * Controller for pchDriverMaritalStatus component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverMaritalStatusComponentController', controller);

	 function controller($filter) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$comboList = $filter('comboList');

	 		vm.combos = {
                maritalStatus   : $comboList('maritalStatus')
	 		};
            vm.combos.maritalStatus.unshift({key : '', value : $filter('translate')('LBLXXXX.car.select')});

        }
    }
})(angular);
