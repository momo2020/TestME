(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverRetiredComponentController
	 * @description
	 * Controller for pchDriverRetired component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverRetiredComponentController', controller);

	 function controller($filter, $rootScope) {
	 	this.$onInit = function(){
	 		var vm = this;

        }
    }
})(angular);
