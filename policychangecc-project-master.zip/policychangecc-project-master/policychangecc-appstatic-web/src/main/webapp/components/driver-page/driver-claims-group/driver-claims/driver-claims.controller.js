(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverClaimsComponentController
	 * @description
	 * Controller for pchDriverClaims component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverClaimsComponentController', controller);

	 function controller($filter, $rootScope) {
	 	this.$onInit = function(){
	 		var vm = this;

            /**
    		* @ngdoc method
    		* @name INTACT.PolicyChange.directive:pcFormDriverClaims#resetDriverClaims
    		* @methodOf INTACT.PolicyChange.directive:pcFormDriverClaims
    		* @description
    		* Remove claim section and remove claims
    		*/
            vm.resetDriverClaims = function(){
                vm.formDriverClaims.ngModel.driver.claims = [];
            };

	 		/**
	 		* @ngdoc method
	 		* @name INTACT.PolicyChange.directive:pcFormDriverClaims#initClaims
	 		* @methodOf INTACT.PolicyChange.directive:pcFormDriverClaim
	 		* @description
	 		* Adds a claim when claims are empty
	 		*/
	 		vm.initClaims = function() {
	 		    if (!vm.formDriverClaims.ngModel.driver.claims.length) {
	 		        vm.formDriverClaims.addClaim();
	 		    }
	 		};
        };

    }
})(angular);
