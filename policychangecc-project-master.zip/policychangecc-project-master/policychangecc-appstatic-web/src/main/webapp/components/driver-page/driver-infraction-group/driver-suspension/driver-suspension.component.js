(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverSuspension
	 * @description
	 * Component used to group driver updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverSuspension', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-infraction-group/driver-suspension/driver-suspension.html';
	    },
	    controller: 'pchDriverSuspensionComponentController',
		require: {
			formDriverInfraction: '^pcFormDriverInfraction'
		}
	});

})(angular);
