(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverSuspensionComponentController
	 * @description
	 * Controller for pchDriverSuspension component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverSuspensionComponentController', controller);

	 function controller($filter) {
 		var vm = this;

	 	this.$onInit = function(){
	 		vm.labelSuspension = $filter('translate')('LBL43043.driver.infractions.suspension.text');
        };

        this.$doCheck = function(){
        };
    }
})(angular);
