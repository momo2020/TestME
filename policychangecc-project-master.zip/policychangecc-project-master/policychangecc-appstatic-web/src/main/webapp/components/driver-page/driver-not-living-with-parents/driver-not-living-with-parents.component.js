(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverNotLivingWithParents
	 * @description
	 * Component used to group driver updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverNotLivingWithParents', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-not-living-with-parents/driver-not-living-with-parents.html';
	    },
	    controller: 'pchDriverNotLivingWithParentsComponentController',
		require: {
			formDriverAbout: '^pcFormDriverAbout'
		}
	});

})(angular);
