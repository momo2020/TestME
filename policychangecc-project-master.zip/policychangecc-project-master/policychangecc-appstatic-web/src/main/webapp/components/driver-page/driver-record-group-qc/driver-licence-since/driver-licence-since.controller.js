(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverLicenceSinceComponentController
	 * @description
	 * Controller for pchDriverLicenceSince component<br>
	 *
	*/
	angular.module('INTACT.PolicyChange').controller('pchDriverLicenceSinceComponentController', controller);

	function controller($filter, $rootScope, $PolicyChange) {
	 	var dobSet = false,
	 		genderSet = false,
	 		vm,
	 		$translate = $filter('translate');

	 	this.$onInit = function(){
	 		vm = this;
	 		vm.driverAge = null;
	 		vm.labels = {
	 			licenseDate : $translate('LBL122213.driver.record.licence.date', {
	 				gender : vm.dobAndGenderSet ? $translate('driver.gender.' + vm.formDriverRecords.ngModel.driver.gender.toLowerCase())  : ''
	 			})
	 		};

	 		vm.combos = {
	 			agesList : vm.formDriverRecords.ngModel.getAgesList()
        	};
        	vm.showLicenceSince = showLicenceSince;

	 		$rootScope.$on('dobChanged', function(event, currentDriver){
	 			vm.combos.agesList = currentDriver.getAgesList();
	 			resetAgeGotLicence(currentDriver.driver);
	 			dobSet = true;
	 		});

	 		$rootScope.$on('loadRelationship', function(){
	 			genderSet = vm.formDriverRecords.ngModel.driver.gender !== '';
	 		});

	 		$rootScope.$on('eventresetLicenceSince', function(event, currentDriver){
	 			resetAgeGotLicence(currentDriver.driver);
	 		});

	 		function showLicenceSince(){
	 			// Add new Driver with populated Dob
	 			if (vm.dobAndGenderSet && vm.formDriverRecords.isNewDriver &&  vm.formDriverRecords.ngModel.driver.driverLicenceType === 'R'){
	 				return true;
	 			}
	 			// Modify existing Driver (recently added on the policy)
	 			else if (vm.formDriverRecords.ngModel.driver.sequence != 0 && !existCurrentDriverOnOriginalPolicy() && !hasOriginalRegularLicence() && hasCurrentRegularLicence()){
	 				return true;
	 			}
	 			// Modify existing Driver already on the original policy
	 			else if (vm.formDriverRecords.ngModel.driver.sequence != 0 && !hasOriginalRegularLicence() && hasCurrentRegularLicence()){
	 				return true;	
	 			}
	 			
	 			return  false;
	 		}

	 		var originalDriver = $PolicyChange.$get().policyChange().currentPolicy.drivers[vm.formDriverRecords.driverIndex];
            var originalDriverLicenceTypeKey = getOriginalLicenceTypeKey(); 

	 		function resetAgeGotLicence(driver){
 				driver.ageGotLicence = null;
	 		}

	 		function hasOriginalRegularLicence(){
              return originalDriverLicenceTypeKey != null && originalDriverLicenceTypeKey === 'R';
            }

            function hasCurrentRegularLicence(){
              var currentDriverLicenceTypeKey = vm.formDriverRecords.ngModel.driver.driverLicenceType;

              return currentDriverLicenceTypeKey != null && currentDriverLicenceTypeKey === 'R';
            }

            function getOriginalLicenceTypeKey (){
              return originalDriver ? originalDriver.driverLicenceType: null; 
            }

	 		function existCurrentDriverOnOriginalPolicy(){
	 			return originalDriver != null && originalDriver != undefined;
	 		}
        };

        this.$doCheck = function(){

        	vm.dobAndGenderSet = dobSet && genderSet;
	 		
	 		if(vm.dobAndGenderSet){
	        	vm.labels = {
		 			licenseDate : $translate('LBL122213.driver.record.licence.date', {
		 				gender : $translate('driver.gender.' + vm.formDriverRecords.ngModel.driver.gender.toLowerCase())
		 			})
		 		};
	 		}
        };

    }
})(angular);
