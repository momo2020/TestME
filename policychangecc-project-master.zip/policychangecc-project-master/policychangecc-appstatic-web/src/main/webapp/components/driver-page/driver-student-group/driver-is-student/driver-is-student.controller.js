(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverIsStudentComponentController
	 * @description
	 * Controller for pchDriverGender component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverIsStudentComponentController', controller);

	 function controller($filter, $rootScope) {
	 	this.$onInit = function(){
	 		var vm = this;
        }
    }
})(angular);
