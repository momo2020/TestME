(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverPriorCarrierComponentController
	 * @description
	 * Controller for pchDriverPriorCarrier component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverPriorCarrierComponentController', controller);

	 function controller($filter) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$translate = $filter('translate'),
	 			$getLicenceType = $filter('getLicenceType'),
	 			$comboList = $filter('comboList');

        }
    }
})(angular);
