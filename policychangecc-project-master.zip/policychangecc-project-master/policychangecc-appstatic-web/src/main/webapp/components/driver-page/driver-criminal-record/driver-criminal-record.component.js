(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverCriminalRecord
	 * @description
	 * Component used to update criminal record
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverCriminalRecord', /*@ngInject*/ {
		bindings: {
			ngModel: '=',
			isNewDriver: '='
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-criminal-record/driver-criminal-record.html';
	    },
	    controller: 'pchDriverCriminalRecordComponentController',
		require: {}
	});

})(angular);
