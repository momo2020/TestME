(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverCriminalRecordComponentController
	 * @description
	 * Controller for pchDriverCriminalRecordComponentController component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverCriminalRecordComponentController', controller);

	 function controller($filter, $PCAppConfiguration, $rootScope) {
 		var vm = this;

	 	this.$onInit = function(){
	 		vm.labelCriminalRecord = $filter('translate')('LBL46688.driver.criminal.record.question');
	 		vm.showCriminalRecord = showCriminalRecord;

	 		// Quebec Province Only
	 		function showCriminalRecord(){
	 			var province = $PCAppConfiguration.province.toLowerCase();
	 			return province === 'qc' && ((vm.isNewDriver && vm.isNewDriver == true) || vm.ngModel.driver.modificationCode === 'N') ;
	 		}

        };
        
    }
})(angular);
