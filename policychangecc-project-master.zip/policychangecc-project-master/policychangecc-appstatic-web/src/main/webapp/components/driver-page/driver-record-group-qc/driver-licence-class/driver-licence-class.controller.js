(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverLicenceClassComponentController
	 * @description
	 * Controller for pchDriverLicenceType component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverLicenceClassComponentController', controller);
  
	 function controller($filter, $rootScope, $PolicyChange) {
	 	this.$onInit = function(){

	 		var vm = this;
	 		
	 		var originalDriver = $PolicyChange.$get().policyChange().currentPolicy.drivers[vm.formDriverRecords.driverIndex];
            var originalDriverLicenceTypeKey = getOriginalLicenceTypeKey();

	 		vm.isDriverLicenceReadOnly = isDriverLicenceReadOnly;
	 		vm.resetLicenceSince = resetLicenceSince;
	 		vm.labels = {
	 			licenseClass : $filter('translate')('LBL42758.driver.record.licence.type')
	 		};

	 		vm.combos = {
	 			licenceClass : filterComboList()
	 		};

	 		// used for car modification
	 		function isDriverLicenceReadOnly(){
	 			// if is existing car with 'Regular' licence then question is readonly
	 			if(hasOriginalRegularOrOtherLicence()){ 
	 				return true;
	 			}
	 			
	 			return false;
	 		}
			
	 		function hasOriginalRegularOrOtherLicence(){
              return originalDriverLicenceTypeKey != null && (originalDriverLicenceTypeKey === 'R' || originalDriverLicenceTypeKey === 'A');
            }

            function hasOriginalLearnerLicence(){
              return originalDriverLicenceTypeKey != null && originalDriverLicenceTypeKey === 'L';
            }

	 		function getOriginalLicenceTypeKey (){
              return originalDriver ? originalDriver.driverLicenceType: null; 
            }

	 		function resetLicenceSince(){
 				$rootScope.$broadcast('eventresetLicenceSince', vm.formDriverRecords.ngModel);
	 		}

	 		function filterComboList(){
	 			var licenceClassList = $filter('comboList')('driverLicenceType');
	 			if (hasOriginalRegularOrOtherLicence()){
	 				licenceClassList = $filter("filter")(licenceClassList, {key: vm.formDriverRecords.ngModel.driver.driverLicenceType});
	 			}
	 			else if(hasOriginalLearnerLicence()){
	 				licenceClassList =$filter("filter")(licenceClassList, {key: "!A"});
	 			}

	 			return licenceClassList;
	 		}
        }
    }
})(angular);
