(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverInfractionPastYearsComponentController
	 * @description
	 * Controller for pchDriverCancelled component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverInfractionPastYearsComponentController', controller);

	 function controller($filter) {
	 	var vm = this;
	 	
	 	this.$onInit = function(){

	 		vm.showInfractionDetail = function(){
	 			// Reset conditionnal info
	 			if(!vm.formDriverInfraction.ngModel.driver.infractionsPast3Years){
	 			    vm.formDriverInfraction.ngModel.driver.majorInfraction = null;
	 			    vm.formDriverInfraction.ngModel.driver.minorInfractionCount = 0;
	 			}

	 		};
        }
    }
})(angular);
