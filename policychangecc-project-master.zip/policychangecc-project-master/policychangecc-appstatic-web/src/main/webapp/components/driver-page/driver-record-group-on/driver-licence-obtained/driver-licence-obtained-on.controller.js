(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverLicenceObtainedOnComponentController
	 * @description
	 * Controller for pchDriverLicenceType component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverLicenceObtainedOnComponentController', controller);

	 function controller($filter, $rootScope) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$translate = $filter('translate'),
	 			$comboList = $filter('comboList');

	 		vm.labels = {
	 			licenseDate   : $translate('LBL42812.driver.record.licence.date')
	 		};

	 		vm.combos = {
	 			licenceMonths   : $comboList('licenceMonth', 'String'),
	 			licenceYears    : vm.formDriverRecords.ngModel.getDriverLicenceYears()
	 		};

	 		vm.combos.licenceMonths.unshift({key : '', value : $filter('translate')('policychange.placeholder.month')});
	 		vm.monthsReady = vm.combos.licenceYears.length > 0;

	 		
	 		$rootScope.$on('dobChanged', function(){
	 		  vm.combos.licenceYears = vm.formDriverRecords.ngModel.getDriverLicenceYears();
	 		  vm.monthsReady = vm.combos.licenceYears.length > 0;
	 		  vm.formDriverRecords.driverLicenceDate = {
	 		      year: vm.formDriverRecords.ngModel.driver.licenceObtentionDate !== "" ? vm.formDriverRecords.ngModel.getDateOfBirth('year', vm.formDriverRecords.ngModel.driver.licenceObtentionDate).toString() : "",
	 		      month:vm.formDriverRecords.ngModel.driver.licenceObtentionDate !== "" ? vm.formDriverRecords.ngModel.getDateOfBirth('month',vm.formDriverRecords.ngModel.driver.licenceObtentionDate).toString() : ""
	 		  };
	 		}, true);
        }
    }
})(angular);
