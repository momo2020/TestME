(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverLicence12monthsOnComponentController
	 * @description
	 * Controller for pchDriverLicenceType component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverLicence12monthsOnComponentController', controller);

	 function controller($filter, $rootScope) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$getLicenceType = $filter('getLicenceType'),
	 			$translate = $filter('translate'),
	 			$comboList = $filter('comboList');


	 		// Obtain the letter of the licence and update labels for questions
	 		var driverObtainedQuestion = function(){
	 		  var letter = "",
	 		      licenceTypes = $getLicenceType(vm.formDriverRecords.ngModel.driver.driverLicenceType, $comboList('driverLicenceType'), vm.formDriverRecords.isNewDriver, vm.formDriverRecords.originalLicenceType);
	 		  for(var i = 0; i <= licenceTypes.length; i++){
	 		    var itm = licenceTypes[i];
	 		    if(vm.formDriverRecords.ngModel.driver.driverLicenceType){
	 		      if(itm){
	 		        if(itm.key.toUpperCase() === vm.formDriverRecords.ngModel.driver.driverLicenceType.toUpperCase() ){
	 		          letter = itm.value.split("(")[0].trim();
	 		        }
	 		      }
	 		    }
	 		  }
	 		  return [
	 		    $translate('LBL42799.driver.record.twelvemonths', {"licencetype": letter}),
	 		    $translate('LBL43025.driver.record.obtentiondate', {"licencetype": letter})
	 		  ];
	 		};

	 		vm.labels = {
	 			driverObtained 	: driverObtainedQuestion()[0],
	 			driverLast12M 	: driverObtainedQuestion()[1],
	 			yes           	: $translate('policychange.radio.yes'),
	 			no            	: $translate('policychange.radio.no')
	 		};


	 		$rootScope.$on('licenceTypeTrigger', function(){
	 		  vm.labels.driverObtained = driverObtainedQuestion()[0];
	 		  vm.labels.driverLast12M = driverObtainedQuestion()[1];
	 		}, true);
        }
    }
})(angular);
