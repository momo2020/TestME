(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverRetired
	 * @description
	 * Component used to group driver updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverRetired', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-retired/driver-retired.html';
	    },
	    controller: 'pchDriverRetiredComponentController',
		require: {
			formDriverStudent: '^pcFormDriverStudent'
		}
	});

})(angular);
