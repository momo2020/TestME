(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverCancellationReasonComponentController
	 * @description
	 * Controller for pchDriverCancelled component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverCancellationReasonComponentController', controller);

	 function controller($filter, $rootScope) {
 		var vm = this,
 			$comboList = $filter('comboList'),
 			$translate = $filter('translate');

	 	this.$onInit = function(){

	 		vm.combos = {
	 			cancellationReason : $comboList('cancelledPolicyReason')
	 		};
	 		vm.combos.cancellationReason.unshift({key : '', value : $translate('LBLXXXX.car.select')})

        }
        this.$doCheck = function(){

	 		vm.showCancellationReason = function(){
	 			return vm.formDriverStudent.ngModel.driver.priorCarrierCancelled;
	 		};

        };
    }
})(angular);
