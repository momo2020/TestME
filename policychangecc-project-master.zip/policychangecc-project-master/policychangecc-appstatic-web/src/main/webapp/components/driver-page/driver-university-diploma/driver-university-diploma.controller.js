(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverUniversityDiplomaComponentController
	 * @description
	 * Controller for pchDriverRetired component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverUniversityDiplomaComponentController', controller);

	 function controller($filter, $rootScope) {
	 	this.$onInit = function(){
	 		var vm = this;
	 		vm.labelUniversityDiploma = $filter('translate')('LBL45923.driver.about.universityDiploma');
        }
    }
})(angular);
