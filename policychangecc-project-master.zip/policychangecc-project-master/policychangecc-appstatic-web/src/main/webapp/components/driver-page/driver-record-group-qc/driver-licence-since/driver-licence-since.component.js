(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverLicenceSince
	 * @description
	 * Component used to group driver updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverLicenceSince', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-record-group-qc/driver-licence-since/driver-licence-since.html';
	    },
	    controller: 'pchDriverLicenceSinceComponentController',
		require: {
			formDriverRecords: '^pcFormDriverRecords'
		}
	});

})(angular);
