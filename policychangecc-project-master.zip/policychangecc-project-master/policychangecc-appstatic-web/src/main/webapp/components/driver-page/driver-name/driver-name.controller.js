(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverNameComponentController
	 * @description
	 * Controller for pchDriverNameComponentController component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverNameComponentController', controller);

	 function controller($filter, $rootScope) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$capitalize = $filter('pcCapitalize');

	 		vm.viewDriver = {
	 			firstName : $capitalize(vm.formDriverAbout.ngModel.driver.firstName),
	 			lastName : $capitalize(vm.formDriverAbout.ngModel.driver.lastName)
	 		};

	 		vm.setFirstName = function(){
	 			if (isValueChanged(vm.formDriverAbout.ngModel.driver.firstName, vm.viewDriver.firstName)) {
	 			     vm.formDriverAbout.ngModel.driver.firstName = $capitalize(vm.viewDriver.firstName); 
	 			     vm.formDriverAbout.updatedFields("name");
	 			}
	 		};

	 		vm.setLastName = function(){
	 			if (isValueChanged(vm.formDriverAbout.ngModel.driver.lastName, vm.viewDriver.lastName)) {
	 			    vm.formDriverAbout.ngModel.driver.lastName = $capitalize(vm.viewDriver.lastName);
	 			    vm.formDriverAbout.updatedFields("name");
	 			}
	 		};

	 		function isValueChanged(oldValue, newValue){
	 		    if(newValue.length > 0){
	 		        if(oldValue === '' || oldValue === null || oldValue.toUpperCase() !== newValue.toUpperCase()) {
	 		            return true;
	 		        }
	 		    }
	 		    if(oldValue.length > 0){
	 		        if(newValue === '' || newValue === null || newValue.toUpperCase() !== oldValue.toUpperCase()) {
	 		            return true;
	 		        }
	 		    }

	 		    return false;
	 		}

	 		$rootScope.$on('reloadDriver', function(){
			 	vm.viewDriver = {
			 	    firstName   : $capitalize(vm.formDriverAbout.ngModel.driver.firstName),
			 	    lastName    : $capitalize(vm.formDriverAbout.ngModel.driver.lastName)
			 	};		
	 		});

        }
    }
})(angular);
