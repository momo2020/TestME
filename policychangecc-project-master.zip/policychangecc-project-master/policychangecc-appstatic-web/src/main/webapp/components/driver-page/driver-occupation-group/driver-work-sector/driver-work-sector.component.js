(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverWorkSector
	 * @description
	 * Component used to group driver updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverWorkSector', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-occupation-group/driver-work-sector/driver-work-sector.html';
	    },
	    controller: 'pchDriverWorkSectorComponentController',
		require: {
			formDriverAbout: '^pcFormDriverAbout'
		}
	});

})(angular);
