(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverInfractionMajorComponentController
	 * @description
	 * Controller for pchDriverInfractionMinor component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverInfractionMajorComponentController', controller);

	 function controller() {
 		var vm = this;

	 	this.$onInit = function(){
        };

        this.$doCheck = function(){

	 		vm.showInfractionDetail = function(){
	 			return vm.formDriverInfraction.ngModel.driver.infractionsPast3Years;
	 		};

        };
    }
})(angular);
