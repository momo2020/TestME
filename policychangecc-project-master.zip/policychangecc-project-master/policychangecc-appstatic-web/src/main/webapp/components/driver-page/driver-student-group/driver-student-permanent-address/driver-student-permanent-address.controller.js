(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverStudentPermanentAddressComponentController
	 * @description
	 * Controller for pchDriverGender component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverStudentPermanentAddressComponentController', controller);

	 function controller() {
	 	this.$onInit = function(){
	 		var vm = this;
        }
    }
})(angular);
