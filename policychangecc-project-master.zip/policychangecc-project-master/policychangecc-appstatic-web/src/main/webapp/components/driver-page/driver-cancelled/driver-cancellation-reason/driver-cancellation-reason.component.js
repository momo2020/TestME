(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverCancelled
	 * @description
	 * Component used to group driver updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverCancellationReason', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-cancelled/driver-cancellation-reason/driver-cancellation-reason.html';
	    },
	    controller: 'pchDriverCancellationReasonComponentController',
		require: {
			formDriverStudent: '^pcFormDriverStudent'
		}
	});

})(angular);
