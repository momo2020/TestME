(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverCancelledComponentController
	 * @description
	 * Controller for pchDriverCancelled component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverCancelledComponentController', controller);

	 function controller($filter, $rootScope) {
	 	this.$onInit = function(){
	 		var vm = this;
	 		vm.labelCancellation = $filter('translate')('LBL43120.driver.about.cancellation');
        }
    }
})(angular);
