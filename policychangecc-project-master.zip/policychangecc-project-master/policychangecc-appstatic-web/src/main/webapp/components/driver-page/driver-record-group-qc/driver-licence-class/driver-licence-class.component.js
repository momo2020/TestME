(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverLicenceClass
	 * @description
	 * Component used to group driver updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverLicenceClass', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-record-group-qc/driver-licence-class/driver-licence-class.html';
	    },
	    controller: 'pchDriverLicenceClassComponentController',
		require: {
			formDriverRecords: '^pcFormDriverRecords'
		}
	});

})(angular);
