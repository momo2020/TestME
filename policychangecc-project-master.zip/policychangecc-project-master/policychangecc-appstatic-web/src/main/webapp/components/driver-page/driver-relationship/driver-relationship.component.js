(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverRelationship
	 * @description
	 * Component used to group driver updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverRelationship', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-relationship/driver-relationship.html';
	    },
	    controller: 'pchDriverRelationshipComponentController',
		require: {
			formDriverAbout: '^pcFormDriverAbout'
		}
	});

})(angular);
