(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverInfractionPastYears
	 * @description
	 * Component used to group driver updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverInfractionPastYears', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-infraction-group/driver-infraction-past-years/driver-infraction-past-years.html';
	    },
	    controller: 'pchDriverInfractionPastYearsComponentController',
		require: {
			formDriverInfraction: '^pcFormDriverInfraction'
		}
	});

})(angular);
