(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverClaimsLossesYearsComponentController
	 * @description
	 * Controller for pchDriverClaims component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverClaimsLossesYearsComponentController', controller);

	 function controller($filter, $rootScope) {
	 	this.$onInit = function(){
	 		var vm = this;
	 		vm.addClaim = vm.formDriverClaims.addClaim;
            vm.maxClaim = 10;

        };

    }
})(angular);
