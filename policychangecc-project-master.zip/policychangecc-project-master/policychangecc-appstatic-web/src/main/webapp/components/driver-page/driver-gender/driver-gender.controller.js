(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverGenderComponentController
	 * @description
	 * Controller for pchDriverGender component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverGenderComponentController', controller);

	 function controller($filter, $rootScope) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$comboList = $filter('comboList');

	 		vm.combos = {
	 			gender : $comboList('gender')
	 		};

	 		vm.loadRelationship = function(){
	 			$rootScope.$broadcast('loadRelationship');
	 		};

        }
    }
})(angular);
