(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDriverLicenceTypeComponentController
	 * @description
	 * Controller for pchDriverLicenceType component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDriverLicenceTypeOnComponentController', controller);

	 function controller($filter, $rootScope) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$translate = $filter('translate'),
	 			$getLicenceType = $filter('getLicenceType'),
	 			$comboList = $filter('comboList');

	 		vm.labels = {
	 			licenseClass : $translate('LBL42758.driver.record.licence.type')
	 		};

	 		vm.combos = {
	 			licenceType : $getLicenceType(vm.formDriverRecords.ngModel.driver.driverLicenceType, $comboList('driverLicenceType'), vm.formDriverRecords.isNewDriver, vm.formDriverRecords.originalLicenceType)
	 		};

	 		vm.licenceDisabled = vm.formDriverRecords.originalLicenceType === 'R' && !vm.formDriverRecords.isNewDriver;
	 		vm.resetDependentValue = resetDependentValue;



	 		// obtainedG2OrG
	 		function resetDependentValue(){
	 		  if(!vm.formDriverRecords.showLicence12Months()){
	 		    vm.formDriverRecords.ngModel.driver.obtainedG2OrG = null;
	 		  }
	 		  $rootScope.$broadcast('licenceTypeTrigger');
	 		}

        }
    }
})(angular);
