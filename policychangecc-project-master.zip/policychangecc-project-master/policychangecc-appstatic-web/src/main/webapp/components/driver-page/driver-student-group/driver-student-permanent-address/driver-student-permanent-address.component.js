(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverStudentPermanentAddress
	 * @description
	 * Component used to group driver updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverStudentPermanentAddress', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-student-group/driver-student-permanent-address/driver-student-permanent-address.html';
	    },
	    controller: 'pchDriverStudentPermanentAddressComponentController',
		require: {
			formDriverStudent: '^pcFormDriverStudent'
		}
	});

})(angular);
