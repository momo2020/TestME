(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverInfractionMinor
	 * @description
	 * Component used to group driver updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverInfractionMinor', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-infraction-group/driver-infraction-minor/driver-infraction-minor.html';
	    },
	    controller: 'pchDriverInfractionMinorComponentController',
		require: {
			formDriverInfraction: '^pcFormDriverInfraction'
		}
	});

})(angular);
