(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDriverLicenceTypeOn
	 * @description
	 * Component used to group driver updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDriverLicenceTypeOn', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/driver-page/driver-record-group-on/driver-licence-type/driver-licence-type-on.html';
	    },
	    controller: 'pchDriverLicenceTypeOnComponentController',
		require: {
			formDriverRecords: '^pcFormDriverRecords'
		}
	});

})(angular);
