(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarPrincipalDriverGroup
	 * @description
	 * Component used to manage the principal driver group of the vehicle
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarPrincipalDriverGroup', /*@ngInject*/ {
		bindings: {},
	    templateUrl: function($PCAppConfiguration){
	    	var province = $PCAppConfiguration.province.toLowerCase();
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-principal-driver/car-principal-driver-group/car-principal-driver-group-' + province + '.html';
	    },
	    controller: 'pchCarPrincipalDriverGroupComponentController',
	    require: {
			formCarUsage: '^ccFormCarUsage'
		}
	});

})(angular);
