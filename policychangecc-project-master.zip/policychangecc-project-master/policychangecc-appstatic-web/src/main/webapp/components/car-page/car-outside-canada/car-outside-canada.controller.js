(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarOutsideCanadaComponentController
	 * @description
	 * Controller for pchCarOutsideCanadaComponent component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarOutsideCanadaComponentController', controller);

	 function controller() {
	 	this.$onInit = function(){
	 		var vm = this;
        }
    }
})(angular);
