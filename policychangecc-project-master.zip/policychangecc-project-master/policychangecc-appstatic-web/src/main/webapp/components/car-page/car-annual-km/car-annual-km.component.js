(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarAnnualKm
	 * @description
	 * Component used to group car updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarAnnualKm', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-annual-km/car-annual-km.html';
	    },
	    controller: 'pchCarAnnualKmComponentController',
		require: {
			formCarUsage: '^ccFormCarUsage'
		}
	});

})(angular);
