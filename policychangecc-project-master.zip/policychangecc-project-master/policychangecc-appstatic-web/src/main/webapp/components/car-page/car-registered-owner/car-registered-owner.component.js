(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarRegisteredOwner
	 * @description
	 * Component used to group car updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarRegisteredOwner', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-registered-owner/car-registered-owner.html';
	    },
	    controller: 'pchCarRegisteredOwnerComponentController',
		require: {
			formCarUsage: '^ccFormCarUsage'
		}
	});

})(angular);
