(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarOutsideProvinceGroup
	 * @description
	 * Component used to manage the use of car outside Quebec
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarOutsideProvinceGroup', /*@ngInject*/ {
		bindings: {},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-outside-province/car-outside-province-group/car-outside-province-group.html';
	    },
	    controller: 'pchCarOutsideProvinceGroupComponentController',
	    require: {
			formCarUsage: '^ccFormCarUsage'
		}
	});

})(angular);
