(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarLeasedComponentController
	 * @description
	 * Controller for pchCarLeased component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarLeasedComponentController', controller);

	 function controller($filter) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$translate = $filter('translate'),
	 			codeNew = $translate('MODIFICATION.CODE.NEW'),
	 			codeSubstitution = $translate('MODIFICATION.CODE.SUBSTITUTED');

	 		vm.showLeased = showLeased;

            function showLeased () {
                var isShow      = false,
                    isChanged   = (vm.formCarAbout.ngModel.vehicle.usageModified),
                    isLeased    = (vm.formCarAbout.vehicleCurr.leased !== null && vm.formCarAbout.vehicleCurr.leased !== false),
                    isCarNewOrSubstituted    = vm.formCarAbout.ngModel.vehicle.modificationCode === codeNew || vm.formCarAbout.ngModel.vehicle.modificationCode === codeSubstitution;
                if(isChanged || isLeased || isCarNewOrSubstituted){
                    isShow = true;
                }
                return isShow;
            }

	 	}
	 
	 }

})(angular);