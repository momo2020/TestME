(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarOutsideProvinceGroupComponentController
	 * @description
	 * Controller for using car outside Quebec <br>
	 *
	*/
	angular.module('INTACT.PolicyChange').controller('pchCarOutsideProvinceGroupComponentController', controller);

	function controller() {
		
	}

})(angular);
