(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarRegisteredOwnerComponentController
	 * @description
	 * Controller for pchCarConditionComponent component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarRegisteredOwnerComponentController', controller);

	 function controller($filter,
	 					$rootScope) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$getDriverCombo = $filter('getDriverCombo');
            vm.showRegisterOwner = showRegisterOwner;

	 		preselectOwner();

	 		vm.combos = {
	 			policyHolders : $getDriverCombo(vm.formCarUsage.policyHolders, 'ph')
        	};

            function preselectOwner(){
                var actualOwner = vm.formCarUsage.ngModel.vehicle.registerOwner,
                    hasActualOwner = actualOwner !== undefined && actualOwner !== null,
                    principalPolicyHolder = $filter('filter')(vm.formCarUsage.policyHolders, {type : "P"})[0],
                    principalHolderId = null;

                if (principalPolicyHolder){
                	principalHolderId = principalPolicyHolder.partyId;
                }


                if(!hasActualOwner){
                    vm.formCarUsage.ngModel.vehicle.registerOwner = principalHolderId;
                }
            }

            function showRegisterOwner(){
                return vm.formCarUsage.ngModel.vehicle.modificationCode === 'U' || vm.formCarUsage.ngModel.vehicle.modificationCode === 'N';
            }

            $rootScope.$on('reloadData', function(event, attrs){
                vm.formCarUsage.policyHolders = attrs.policyHolders;
                vm.combos.policyHolders = $getDriverCombo(vm.formCarUsage.policyHolders, 'ph');
            });

        }
    }
})(angular);
