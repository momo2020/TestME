(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarOutsideProvinceUsage
	 * @description
	 * Component used to manage the use outside Quebec
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarOutsideProvinceUsage', /*@ngInject*/ {
		bindings: {},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-outside-province/car-outside-province-usage/car-outside-province-usage.html';
	    },
	    controller: 'pchCarOutsideProvinceUsageComponentController',
	    require: {
			formCarUsage	: '^ccFormCarUsage'
		}
	});

})(angular);
