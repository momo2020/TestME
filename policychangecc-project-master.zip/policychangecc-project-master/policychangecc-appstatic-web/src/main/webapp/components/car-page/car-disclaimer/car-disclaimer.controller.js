(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarDisclaimerComponentController
	 * @description
	 * Controller for pchCarDisclaimer component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarDisclaimerComponentController', controller);

	 function controller($filter, $PCAppConfiguration) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$translate = $filter('translate');
	 		vm.disclaimer = $translate('LBL41869.car.disclaimer.province', {province : $filter('province')($PCAppConfiguration.province)});
	 		vm.province = $PCAppConfiguration.province.toLowerCase();
	 	}
	 
	 }

})(angular);