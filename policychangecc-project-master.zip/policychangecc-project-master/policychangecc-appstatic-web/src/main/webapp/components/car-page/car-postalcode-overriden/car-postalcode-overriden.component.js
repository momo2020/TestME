(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarPCOverriden
	 * @description
	 * Component used to group car updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarPostalcodeOverriden', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-postalcode-overriden/car-postalcode-overriden.html';
	    },
	    controller: 'pchCarPCOverridenComponentController',
		require: {
			formCarAbout: '^ccFormCarAbout'
		}
	});

})(angular);
