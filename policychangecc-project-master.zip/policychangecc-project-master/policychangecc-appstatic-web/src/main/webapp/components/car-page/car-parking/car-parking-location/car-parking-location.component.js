(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarParkingLocation
	 * @description
	 * Component used to manage the parking location on the car: inside/outside parking
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarParkingLocation', /*@ngInject*/ {
		bindings: {},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-parking/car-parking-location/car-parking-location.html';
	    },
	    controller: 'pchCarParkingLocationComponentController',
	    require: {
			formCarUsage: '^ccFormCarUsage'
		}
	});

})(angular);
