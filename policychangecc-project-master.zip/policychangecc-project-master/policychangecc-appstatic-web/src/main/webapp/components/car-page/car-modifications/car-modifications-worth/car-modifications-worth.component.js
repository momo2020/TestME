(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarModificationsWorth
	 * @description
	 * Component used to manage the modifications worth on the car
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarModificationsWorth', /*@ngInject*/ {
		bindings: {},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-modifications/car-modifications-worth/car-modifications-worth.html';
	    },
	    controller: 'pchCarModificationsWorthComponentController',
	 	require: {
			formCarAbout: '^ccFormCarAbout'
		}
	});

})(angular);
