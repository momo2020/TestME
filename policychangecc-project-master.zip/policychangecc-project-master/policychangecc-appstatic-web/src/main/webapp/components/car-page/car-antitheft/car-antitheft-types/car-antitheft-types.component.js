(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarAntitheftTypes
	 * @description
	 * Component used to manage the antitheft types on the car
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarAntitheftTypes', /*@ngInject*/ {
		bindings: {},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-antitheft/car-antitheft-types/car-antitheft-types.html';
	    },
	    controller: 'pchCarAntitheftTypesComponentController',
	    require: {
			formCarAbout: '^ccFormCarAbout'
		}
	});

})(angular);
