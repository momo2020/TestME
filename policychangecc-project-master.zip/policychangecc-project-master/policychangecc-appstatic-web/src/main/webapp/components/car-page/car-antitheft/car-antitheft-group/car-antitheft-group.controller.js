(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarAntitheftGroupComponentController
	 * @description
	 * Controller for Antitheft Group <br>
	 *
	*/
	angular.module('INTACT.PolicyChange').controller('pchCarAntitheftGroupComponentController', controller);

	function controller() {
		
	}

})(angular);
