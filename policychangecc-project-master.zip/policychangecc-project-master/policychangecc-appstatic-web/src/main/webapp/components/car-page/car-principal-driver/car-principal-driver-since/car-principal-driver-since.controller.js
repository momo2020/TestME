(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarPrincipalDriverSinceComponentController
	 * @description
	 * Controller for Nb of Years Insured as Principal Driver <br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarPrincipalDriverSinceComponentController', controller);

	 function controller($filter, $rootScope, $PolicyChange) {
	 	var vm = this;
        // ready to work when the parent controller is initialized
		this.$onInit = function() {
			var originalCarList = $PolicyChange.$get().policyChange().currentPolicy.vehicles,
				originalDriverList = $PolicyChange.$get().policyChange().currentPolicy.drivers;
			
			
			vm.comboSince = getSinceOptions();
			vm.labelPrincipalDriverSince = $filter('translate')('LBL45963.driver.since');            
			vm.showPrincipalDriverSince = showPrincipalDriverSince; 
			vm.setDriverSince = setDriverSince;

			vm.showPrincipalDriverSince();
			
			$rootScope.$on('eventSetPrincipalDriverSinceVisibility', function (events, args){
				// update the right car - Assignation Popup manage more cars
				if(args.currentCar.riskIndex === vm.currentCar.riskIndex){
					setCarDefaultDriverSince();
					showPrincipalDriverSince();
				}
			});

	        function getSinceOptions(){
                var comboSince = $filter('comboList')('principalDriverSince', "String");
	            comboSince = $filter('orderBy')(comboSince, 'key');
	            comboSince.unshift({
            		key: null, 
            		value : $filter('translate')('LBLXXXX.car.select')
	            });
	            
	            return comboSince;
            }

            function showPrincipalDriverSince(){
                if(isPrincipalDriverNullOrOther() || isPrincipalDriverOnOtherCar()){
                    return false;
                }
                
                return true;
            }

            // When DriverSince is changed for a car, we have to refresh DriverSince on all others cars with the same PrincipalDriver 
            function setDriverSinceOnAllCars (){
           		for(var i = 0; i < vm.carList.length; i++){
            		var car = angular.isDefined(vm.carList[i].vehicle) ? vm.carList[i].vehicle : vm.carList[i];
            		if(car.principalDriver === vm.currentCar.principalDriver && car.riskIndex != vm.currentCar.riskIndex){
		            	car.principalDriverSince = vm.currentCar.principalDriverSince;
		            }
            	}

            }

            function isPrincipalDriverOnOtherCar(){
            	var selectedDriverSequence = vm.currentCar.principalDriver;
            	var originalCar = $filter("filter")(originalCarList, {principalDriver: selectedDriverSequence})[0]; 

            	var isPrincipalOnOriginalCars = angular.isDefined(originalCar) && originalCar !== null &&  originalCar.principalDriver === selectedDriverSequence;
	            // Compare against original Policy
                if(isPrincipalOnOriginalCars){
	                return true;
	            }

	            return false;
            }

            function isPrincipalDriverNullOrOther(){
                // Compare against current Policy
                return vm.currentCar.principalDriver === null || vm.currentCar.principalDriver == -1;
            }

			// Refresh DriverSince information from Driver to Car 
            function setCarDefaultDriverSince (){
				// set DriverSince from original Driver when principal driver 
				var selectedDriverSequence = vm.currentCar.principalDriver;
				var selectedDriver = $filter("filter")(originalDriverList, {sequence: selectedDriverSequence})[0];

    			if (selectedDriver && isPrincipalDriverOnOtherCar()){
                    vm.currentCar.principalDriverSince = selectedDriver.principalDriverSince;

					// and transalte the good driver date
                    var oldDriversCar = $filter("filter")(originalCarList, {principalDriver : selectedDriverSequence})[0];
                    vm.currentCar.goodDriverDate =  oldDriversCar ? oldDriversCar.goodDriverDate : null;
                }
                else{
					// set DriverSince from current Driver when ocasional driver
					var currentDriver = $filter("filter")(vm.driverList, {sequence: selectedDriverSequence})[0];
	            	if(currentDriver){
		            	vm.currentCar.principalDriverSince = currentDriver.principalDriverSince;
		            }
		            else{
		            	vm.currentCar.principalDriverSince = null;	
		            }
		        }
            }

            function setDriverSince(){
            	setDriverSinceOnAllCars();
            }

  		}

	}

})(angular);
