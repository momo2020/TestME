(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarCommercialUseBusinesskmComponentController
	 * @description
	 * Controller for pchCarCommercialUseBusiness component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarCommercialUseBusinesskmComponentController', controller);

	 function controller() {
	 	this.$onInit = function(){
	 		var vm = this;
        }
    }
})(angular);
