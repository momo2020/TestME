(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarWinterTires
	 * @description
	 * Component used to group car updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarWinterTires', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-winter-tires/car-winter-tires.html';
	    },
	    controller: 'pchCarWinterTiresComponentController',
		require: {
			formCarAbout: '^ccFormCarAbout'
		}
	});

})(angular);
