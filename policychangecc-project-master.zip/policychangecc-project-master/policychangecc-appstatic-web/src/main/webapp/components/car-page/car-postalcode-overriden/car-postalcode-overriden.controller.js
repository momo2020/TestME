
(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarPCOverridenComponentController
	 * @description
	 * Controller for pchPostalcodeOverriden component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarPCOverridenComponentController', controller);

	 function controller($filter) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$translate = $filter('translate'),
	 			_address = vm.formCarAbout.policyHolders[0].address;

	 		_address = $filter('addressOneLine')(_address);

	 		vm.lbl = {
	 			vehLocation : $translate('LBL41888.car.location', {address : _address})
	 		}

	 		vm.showPCOverriden = function (){
                var initialCar = vm.formCarAbout.currentVehicles[vm.formCarAbout.vehicleCurr.riskIndex];
                if(initialCar){
                    return initialCar.postalCodeOverriden;
                }
                
                return false;
	 		};

	 	}
	 
	 }

})(angular);