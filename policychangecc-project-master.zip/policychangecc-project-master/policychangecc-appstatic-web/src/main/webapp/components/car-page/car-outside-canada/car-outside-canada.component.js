(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarOutsideCanada
	 * @description
	 * Component used to group car updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarOutsideCanada', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-outside-canada/car-outside-canada.html';
	    },
	    controller: 'pchCarOutsideCanadaComponentController',
		require: {
			formCarUsage: '^ccFormCarUsage'
		}
	});

})(angular);
