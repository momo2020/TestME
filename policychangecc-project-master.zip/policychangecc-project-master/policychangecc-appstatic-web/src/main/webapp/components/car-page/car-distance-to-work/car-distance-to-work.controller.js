(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchDistanceToWorkComponentController
	 * @description
	 * Controller for pchCarConditionComponent component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchDistanceToWorkComponentController', controller);

	 function controller($filter, $rootScope) {
	 	this.$onInit = function(){
	 		var vm = this;
	 		vm.updateWorkKm = updateWorkKm;

	 		function updateWorkKm(){
	 			$rootScope.$broadcast('fieldReset');
		 		vm.formCarUsage.ngModel.vehicle.workKmModified = true;
		 	}
        }
    }
})(angular);
