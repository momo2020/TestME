(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarAntitheftBrands
	 * @description
	 * Component used to manage the antitheft brands on the car
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarAntitheftBrands', /*@ngInject*/ {
		bindings: {},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-antitheft/car-antitheft-brands/car-antitheft-brands.html';
	    },
	    controller: 'pchCarAntitheftBrandsComponentController',
	    require: {
			formCarAbout: '^ccFormCarAbout'
		}
	});

})(angular);
