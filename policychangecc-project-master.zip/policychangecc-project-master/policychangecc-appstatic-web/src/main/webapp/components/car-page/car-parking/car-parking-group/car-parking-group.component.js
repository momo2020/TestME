(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarParkingGroup
	 * @description
	 * Component used to manage the parking group on the car: inside/outside parking - street/garage parking
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarParkingGroup', /*@ngInject*/ {
		bindings: {},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-parking/car-parking-group/car-parking-group.html';
	    },
	    controller: 'pchCarParkingGroupComponentController',
	    require: {
			formCarUsage: '^ccFormCarUsage'
		}
	});

})(angular);
