(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarCommercialUse
	 * @description
	 * Component used to group car updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarCommercialUse', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-commercial-use/car-commercial-use-ind/car-commercial-use.html';
	    },
	    controller: 'pchCarCommercialUseComponentController',
		require: {
			formCarUsage: '^ccFormCarUsage'
		}
	});

})(angular);
