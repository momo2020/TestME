(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarParkingLocationComponentController
	 * @description
	 * Controller for Parking location <br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarParkingLocationComponentController', controller);

	 function controller($filter, $rootScope) {

        // ready to work when the parent controller is initialized
		this.$onInit = function() {

			var vm = this;
			vm.resetParkingDetail = resetParkingDetail;

            function resetParkingDetail(){
                $rootScope.$broadcast('eventResetParkingDetail', vm.formCarUsage.ngModel.vehicle);
            }
			
  		}
	}

})(angular);
