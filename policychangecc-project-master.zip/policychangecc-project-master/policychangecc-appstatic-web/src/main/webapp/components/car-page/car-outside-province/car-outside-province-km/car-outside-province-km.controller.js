(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarOutsideProvinceKmComponentController
	 * @description
	 * Controller for km used outside Quebec <br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarOutsideProvinceKmComponentController', controller);

	 function controller($filter, $rootScope) {

        // ready to work when the parent controller is initialized
		this.$onInit = function() {

			var vm = this;
			vm.comboKmRange = getKmRangeOptions();
            vm.showOutsideProvinceKm = showOutsideProvinceKm;

            $rootScope.$on('eventResetOutsideProvinceKm', function(event, params){
            	if(params.index === vm.formCarUsage.ngModel.vehicle.riskIndex){
            		resetOutsideProvinceKm();
            	}
            });

            function showOutsideProvinceKm(){
            	return vm.formCarUsage.ngModel.vehicle.usedOutsideProvinceOrCountry; 
            }

            function getKmRangeOptions(){
                var comboKmRange = $filter('comboList')('outsideProvince');
	            comboKmRange.unshift({key: null, value : $filter('translate')('LBLXXXX.car.select')});
	            
	            return comboKmRange;
            }

            function resetOutsideProvinceKm() {
            	vm.formCarUsage.ngModel.vehicle.outsideProvinceOrCountryKm = null;
            }
			
  		}
	}

})(angular);
