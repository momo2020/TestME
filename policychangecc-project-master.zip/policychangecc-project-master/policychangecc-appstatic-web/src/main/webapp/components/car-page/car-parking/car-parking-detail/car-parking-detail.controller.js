(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarParkingDetailComponentController
	 * @description
	 * Controller for Parking detail <br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarParkingDetailComponentController', controller);

	 function controller($filter, $rootScope) {

		var vm = this,
			$translate = $filter('translate');



		function isParkingShared (){
			var type = vm.formCarUsage.ngModel.vehicle.parkingType,
				radio = false;
			if(type == null){
				return null;
			}

			if(type !== "" && type === 'S' || type ==='O'){
				radio = true;
			}

			return radio;
		}

        // ready to work when the parent controller is initialized
		this.$onInit = function() {
			vm.isParkingShared = isParkingShared();
			vm.showParkingDetail = showParkingDetail;
			vm.getParkingDetailLabel = getParkingDetailLabel;
			vm.setParkingDetailByLocation = setParkingDetailByLocation;
			
			$rootScope.$on('eventResetParkingDetail', function(event, currentCar){
				currentCar.parkingType = null;
				vm.isParkingShared = isParkingShared();
			});

            function showParkingDetail(){
	            return  vm.formCarUsage.ngModel.vehicle.parkingIndoor != null ? true: false;
	        }

	        function getParkingDetailLabel(){
	        	if(vm.formCarUsage.ngModel.vehicle.parkingIndoor){
	        		return  $translate('LBL11251.car.shared.parking');
	        	}
	        	else{
	        		return  $translate('LBL11267.car.street.parking');	
	        	}
	        }

	        function setParkingDetailByLocation(){
	        	var parkingType = null,
	        		isParkedIndoor = vm.formCarUsage.ngModel.vehicle.parkingIndoor;
	        	
	        	if(isParkedIndoor){// Car is parked in a garage
	        		if(vm.isParkingShared){
	        			// parking is shared with other cars
	        			parkingType = "S";
	        		}
	        		else
	        		{
	        			// parking is private
	        			parkingType = "I";
	        		}
	        	}
	        	else{// Car is parked on the street
	        		if(vm.isParkingShared){
	        			// parking is on the street shared with other cars
	        			parkingType = "O";
	        		}
	        		else
	        		{
	        			// car is parked on a private outdoor parking spot
	        			parkingType = "D";
	        		}
	        	}

	        	vm.formCarUsage.ngModel.vehicle.parkingType = parkingType;
	        }
  		}

  		this.$doCheck = function(){
  			vm.isParkingShared = isParkingShared();
  		}
	}

})(angular);
