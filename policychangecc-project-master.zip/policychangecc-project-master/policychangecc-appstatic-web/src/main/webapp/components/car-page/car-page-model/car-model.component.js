(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarModel
	 * @description
	 * Component used to group car updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarAboutModel', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-page-model/car-page.model.html';
	    },
	    controller: 'pchCarModelComponentController',
		require: {
			formCarAbout: '^ccFormCarAbout'
		}
	});

})(angular);
