(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarOutsideProvinceKm
	 * @description
	 * Component used to manage the km used outside Quebec
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarOutsideProvinceKm', /*@ngInject*/ {
		bindings: {},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-outside-province/car-outside-province-km/car-outside-province-km.html';
	    },
	    controller: 'pchCarOutsideProvinceKmComponentController',
	    require: {
			formCarUsage: '^ccFormCarUsage'
		}
	});

})(angular);
