(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarAntitheftBrandsComponentController
	 * @description
	 * Controller for antitheft brand values<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarAntitheftBrandsComponentController', controller);

	 function controller($filter, $PolicyChange, $rootScope) {

        // ready to work when the parent controller is initialized
		this.$onInit = function() {

			var vm = this;
			vm.comboBrands = getBrandOptions();
			vm.showAntitheftBrands = showAntitheftBrands;
			vm.selectedTS = selectedTS();

			vm.setTSType = function(){
				var antitheft = $filter('filter')(vm.formCarAbout.ngModel.vehicle.antiTheftDevices, {type : 'TS'})[0];
            	if(angular.isDefined(antitheft)){
            		antitheft.brand = vm.selectedTS;
            	}
			};

			$rootScope.$on('resetTrackingBrand', function(event, params){
           		vm.selectedTS = null;
            });

            function showAntitheftBrands(){
	            if(!hasAntitheftOnOriginalCar() && vm.formCarAbout.ngModel.vehicle.antiTheftDevice &&  hasTrackingSystem()){
		            return true;
		        }

			    setTrackingSystemNull();

	            return  false;
	        }

	        // Private Section
	        var originalVehicles = $PolicyChange.$get().policyChange().data.response.vehicles;

	        function getBrandOptions(){
                var comboBrands = $filter('comboList')('trackingSystems');
	            comboBrands.unshift({key: null, value : $filter('translate')('LBLXXXX.car.select')});
	            
	            return comboBrands;
            }

            function hasAntitheftOnOriginalCar (){
            	var originalVehicle  = originalVehicles[vm.formCarAbout.ngModel.vehicle.riskIndex];
            	return originalVehicle && originalVehicle.antiTheftDevices.length > 0;
            }

            function hasTrackingSystem(){
            	return $filter('filter')(vm.formCarAbout.ngModel.vehicle.antiTheftDevices, {type : 'TS'}).length > 0;
            }

            function setTrackingSystemNull(){
            	var antitheft = $filter('filter')(vm.formCarAbout.ngModel.vehicle.antiTheftDevices, {type : 'TS'})[0];
            	if(angular.isDefined(antitheft)){
            		antitheft.brand = null;
            	}
            }

            function selectedTS (){
                var antitheft = $filter('filter')(vm.formCarAbout.ngModel.vehicle.antiTheftDevices, {type : 'TS'})[0];
            	if(angular.isDefined(antitheft)){
            		return antitheft.brand;
            	}
            	return null;
            }

  		}

	}

})(angular);
