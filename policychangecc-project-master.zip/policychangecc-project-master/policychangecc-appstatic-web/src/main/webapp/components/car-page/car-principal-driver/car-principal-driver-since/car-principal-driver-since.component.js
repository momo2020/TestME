(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarPrincipalDriverSince
	 * @description
	 * Component used to manage the Nb of Years Insured as Principal Driver 
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarPrincipalDriverSince', /*@ngInject*/ {
		bindings: {
			currentCar: '=',
			carList: '=',
			driverList: '=',
			customSinceClass: '@',
			customSelectClass: '@',
			isInvalid: '@'
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-principal-driver/car-principal-driver-since/car-principal-driver-since.html';
	    },
	    controller: 'pchCarPrincipalDriverSinceComponentController'
	});

})(angular);
