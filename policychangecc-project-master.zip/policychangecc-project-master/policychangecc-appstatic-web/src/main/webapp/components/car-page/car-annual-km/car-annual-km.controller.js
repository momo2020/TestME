(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarAnnualKmComponentController
	 * @description
	 * Controller for pchCarConditionComponent component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarAnnualKmComponentController', controller);

	 function controller($filter) {
	 	var vm = this;
	 	this.$onInit = function(){
	 		var $translate          = $filter('translate'),
                $comboList          = $filter('comboList');

            vm.combos = {
            	annualKm : $comboList('annualKm')
            };
            
            vm.combos.annualKm.unshift({key : null, value : $translate('LBLXXXX.car.select')});
        }
    }
})(angular);
