(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarModelComponentController
	 * @description
	 * Controller for pchCarModelComponent component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarModelComponentController', controller);

	 function controller($filter, 
	 					carService,
                        $rootScope) {
	 	this.$onInit = function(){
	 		var vm = this,
                $translate          = $filter('translate'),
                $comboList          = $filter('comboList');

            if( vm.formCarAbout.ngModel.vehicle.model.code.length === 4 ) {
                vm.formCarAbout.ngModel.vehicle.model.code += "00";
            }

        vm.selectionChanged = function(selectName) {
            var car = vm.formCarAbout.ngModel.vehicle,
                carModel = car.model,
                selectedYear = String(carModel.year),
                selectedMake = carModel.make;

            var cnfg = {
                selectName: 'make',
                car: car,
                year: selectedYear || String(new Date().getFullYear()),
                make: selectedMake || '',
                force: true,
                ddOptions : vm.formCarAbout.ddOptions
            };

            switch (selectName) {
                case 'year':
                    carModel.make = "";
                    carModel.model = "";
                    carModel.code = "";
                    vm.formCarAbout.ngModel.vehicle.conditionWhenBought = null;
                    vm.formCarAbout.ddOptions.makeOptions = carService.getSelectValues(cnfg);
                    vm.formCarAbout.ddOptions.modelOptions = [];
                    break;

                case 'make':
                    carModel.model = "";
                    carModel.code = "";
                    cnfg.selectName = 'model';
                    vm.formCarAbout.ngModel.vehicle.conditionWhenBought = null;
                    vm.formCarAbout.ddOptions.modelOptions = carService.getSelectValues(cnfg);
                    break;

                default:
                    break;
            }

        };


        vm.setCarModel = function() {
            vm.formCarAbout.ngModel.vehicle.model.model = carService.getCarModelLabel(vm.formCarAbout.ngModel.vehicle.model.code, vm.formCarAbout.ddOptions.modelOptions);
            
            resetAboutThisCar();

            $rootScope.$broadcast('refillAntitheftCombo', {index : vm.formCarAbout.ngModel.vehicle.riskIndex, reset : true});

            setIsReplaceCar();
        };


        function setIsReplaceCar (){
            if(vm.formCarAbout.ngModel.vehicle.sequenceNumber !== 0){
                vm.formCarAbout.ngModel.vehicle.modificationCode = $filter('modificationCode')($translate('MODIFICATION.CODE.SUBSTITUTED'), vm.formCarAbout.ngModel.vehicle.modificationCode);
                vm.formCarAbout.isReplaceCar = true;
            }
            else{
                vm.formCarAbout.isReplaceCar = false;
            }
        }

        function resetAboutThisCar (){
            vm.formCarAbout.ngModel.vehicle = vm.formCarAbout.ngModel.resetAboutThisCar(vm.formCarAbout.ngModel.vehicle);
        }

  	}
}
})(angular);
