(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarCommercialUseDelivery
	 * @description
	 * Component used to group car updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarCommercialUseDelivery', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-commercial-use/car-commercial-use-delivery/car-commercial-use-delivery.html';
	    },
	    controller: 'pchCarCommercialUseDeliveryComponentController',
		require: {
			formCarUsage : '^ccFormCarUsage',
			pchCommercialUse : '^pchCarCommercialUse'
		}
	});

})(angular);
