(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarAntitheftGroup
	 * @description
	 * Component used to manage the antitheft group on the car: installations, type and brand
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarAntitheftGroup', /*@ngInject*/ {
		bindings: {},
	    templateUrl: function($PCAppConfiguration){
	    	var province = $PCAppConfiguration.province.toLowerCase();
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-antitheft/car-antitheft-group/car-antitheft-group-' + province + '.html';
	    },
	    controller: 'pchCarAntitheftGroupComponentController',
	    require: {
			formCarAbout: '^ccFormCarAbout'
		}
	});

})(angular);
