(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarCommercialUseComponentController
	 * @description
	 * Controller for pchCarConditionComponent component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarCommercialUseComponentController', controller);

	 function controller($filter) {
	 	this.$onInit = function(){
	 	
            var vm = this;
            vm.showDelivery = showDeliveryQuestion;
            vm.showBusinessKm = showBusinessKmQuestion;

            function showDeliveryQuestion (){
            	var isShow = vm.formCarUsage.ngModel.vehicle.usedForBusiness !== null
            			&& vm.formCarUsage.ngModel.vehicle.usedForBusiness === true;

            	if(!isShow){
            		vm.formCarUsage.ngModel.vehicle.usedToTransportGoods = null;
            	}

            	return isShow;
            }

            function showBusinessKmQuestion (){
            	var isShow = (vm.formCarUsage.ngModel.vehicle.usedForBusiness !== null 
            	            	&& vm.formCarUsage.ngModel.vehicle.usedForBusiness)
            				&& (!vm.formCarUsage.ngModel.vehicle.usedToTransportGoods 
            					&& vm.formCarUsage.ngModel.vehicle.usedToTransportGoods !== null);

            	if(!isShow){
            		vm.formCarUsage.ngModel.vehicle.businessAnnualKm = null;
            	}

            	return isShow;
            }
        }
    }
})(angular);
