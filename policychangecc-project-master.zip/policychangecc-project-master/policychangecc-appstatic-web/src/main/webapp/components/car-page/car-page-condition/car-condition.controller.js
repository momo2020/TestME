(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarConditionComponentController
	 * @description
	 * Controller for pchCarConditionComponent component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarConditionComponentController', controller);

	 function controller($filter) {
	 	this.$onInit = function(){
	 		var vm = this,
                $translate          = $filter('translate');
            vm.disableCondition = disableCondition;
            vm.showCondition = showCondition;
            vm.lbl = {
                condNew         : $translate('vehicleConditionWhenBought.N'),
                condUsed        : $translate('vehicleConditionWhenBought.U'),
                condDemo        : $translate('vehicleConditionWhenBought.D')
            };

            function showCondition (){
                var isShow = showConditionAtTimeOfAcquisition();
                if(!isShow && vm.formCarAbout.ngModel.vehicle.conditionWhenBought === ""){
                    vm.formCarAbout.ngModel.vehicle.conditionWhenBought = 'U';
                }

                return isShow;
            }

            function disableCondition(){
                return vm.formCarAbout.ngModel.vehicle.modificationCode == "M"|| vm.formCarAbout.ngModel.vehicle.modificationCode == null ;
            }


            function showConditionAtTimeOfAcquisition () {
                var nbYearToShow = 5,
                    carYear      = parseInt(vm.formCarAbout.ngModel.vehicle.model.year),
                    thisYear     = parseInt(new Date().getFullYear());

                return carYear > (thisYear - nbYearToShow);
            }

        }
    }
})(angular);
