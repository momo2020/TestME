(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarCommercialUseDeliveryComponentController
	 * @description
	 * Controller for pchCarCommercialUseDelivery component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarCommercialUseDeliveryComponentController', controller);

	 function controller($filter) {
	 	this.$onInit = function(){
	 		var vm = this;
        }
    }
})(angular);
