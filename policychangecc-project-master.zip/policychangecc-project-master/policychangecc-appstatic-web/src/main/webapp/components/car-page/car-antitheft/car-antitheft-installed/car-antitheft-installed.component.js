(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarAntitheftInstalled
	 * @description
	 * Component used to manage the antitheft installations on the car
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarAntitheftInstalled', /*@ngInject*/ {
		bindings: {},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-antitheft/car-antitheft-installed/car-antitheft-installed.html';
	    },
	    controller: 'pchCarAntitheftInstalledComponentController',
	    require: {
			formCarAbout 		: '^ccFormCarAbout'
		}
	});

})(angular);
