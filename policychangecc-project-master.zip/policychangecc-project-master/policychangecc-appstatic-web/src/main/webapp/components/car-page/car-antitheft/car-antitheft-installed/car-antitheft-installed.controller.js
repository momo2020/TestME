(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarAntitheftInstalledComponentController
	 * @description
	 * Controller for Antitheft Installations<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarAntitheftInstalledComponentController', controller);

	 function controller($filter, $rootScope) {

        // ready to work when the parent controller is initialized
		this.$onInit = function() {

			var vm = this;
			vm.resetAntitheftCombo = resetAntitheftCombo;

			function resetAntitheftCombo(){
				$rootScope.$broadcast('refillAntitheftCombo', {index : vm.formCarAbout.ngModel.vehicle.riskIndex, reset : true});
			}
  		}

	}

})(angular);
