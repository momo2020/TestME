(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarModificationsGroup
	 * @description
	 * Component used to manage the modification group on the car: worth, performance and value
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarModificationsGroup', /*@ngInject*/ {
		bindings: {},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-modifications/car-modifications-group/car-modifications-group.html';
	    },
	    controller: 'pchCarModificationsGroupComponentController',
	    require: {
			formCarAbout: '^ccFormCarAbout'
		}
	});

})(angular);
