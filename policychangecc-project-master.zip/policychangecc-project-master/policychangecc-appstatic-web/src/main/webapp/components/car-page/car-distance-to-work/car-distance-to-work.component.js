(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchDistanceToWork
	 * @description
	 * Component used to group car updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchDistanceToWork', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-distance-to-work/car-distance-to-work.html';
	    },
	    controller: 'pchDistanceToWorkComponentController',
		require: {
			formCarUsage: '^ccFormCarUsage'
		}
	});

})(angular);
