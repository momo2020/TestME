(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarModificationsGroupComponentController
	 * @description
	 * Controller for Modification Group<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarModificationsGroupComponentController', controller);

	 function controller() {
		
	}

})(angular);
