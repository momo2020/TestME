(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarModificationsValueComponentController
	 * @description
	 * Controller for Modifications Value component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarModificationsValueComponentController', controller);

	 function controller($filter) {

        // ready to work when the parent controller is initialized
		this.$onInit = function() {

			var vm = this;
			vm.comboModfications = getModificationOptions();
			vm.showModificationWorth = showModificationWorth;

            function showModificationWorth(){
            	var showModificationWorth = shouldShowModificationWorth();
	            if(!showModificationWorth){
	                vm.formCarAbout.ngModel.vehicle.modificationWorth = null;
	            }

	            return showModificationWorth;
	        }

	        function getModificationOptions (){
	            var comboModfications = $filter('comboList')('valueOfModifications');
	            comboModfications.unshift({key: null, value : $filter('translate')('LBLXXXX.car.select')});
	            
	            return comboModfications;
	        }

	        function shouldShowModificationWorth(){
	        	return (!vm.formCarAbout.ngModel.vehicle.modifiedForPerformance && vm.formCarAbout.ngModel.vehicle.modifiedForPerformance !== null) && vm.formCarAbout.ngModel.vehicle.modified;
	        }
  		}

	}

})(angular);
