(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarModificationsPerformance
	 * @description
	 * Component used to manage the modifications performance on the car
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarModificationsPerformance', /*@ngInject*/ {
		bindings: {},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-modifications/car-modifications-performance/car-modifications-performance.html';
	    },
	    controller: 'pchCarModificationsPerformanceComponentController',
	    require: {
			formCarAbout: '^ccFormCarAbout'
		}
	});

})(angular);
