
(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarWinterTiresComponentController
	 * @description
	 * Controller for pchCarWinterTires component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarWinterTiresComponentController', controller);

	 function controller($filter) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$translate = $filter('translate');

	 		vm.lbl = {
	 			winterTires : $translate('LBL11798.car.winter.tires')
	 		};

	 	}
	 
	 }

})(angular);