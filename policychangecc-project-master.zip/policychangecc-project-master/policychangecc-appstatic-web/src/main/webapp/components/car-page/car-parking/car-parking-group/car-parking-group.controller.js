(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarParkingGroupComponentController
	 * @description
	 * Controller for Parking Group <br>
	 *
	*/
	angular.module('INTACT.PolicyChange').controller('pchCarParkingGroupComponentController', controller);

	function controller() {
		
	}

})(angular);
