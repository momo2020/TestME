(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarModificationsPerformanceComponentController
	 * @description
	 * Controller for Modification Performance component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarModificationsPerformanceComponentController', controller);

	 function controller($filter) {

        // ready to work when the parent controller is initialized
		this.$onInit = function() {

			var vm = this;
			vm.showModifiedForPerformance = showModifiedForPerformance;

			function showModifiedForPerformance(){
				var showModifiedForPerformance = vm.formCarAbout.ngModel.vehicle.modified;
	            if(!showModifiedForPerformance){
	                vm.formCarAbout.ngModel.vehicle.modifiedForPerformance = null;
	                vm.formCarAbout.ngModel.vehicle.modificationWorth = 0;
	            }
	            
	            return showModifiedForPerformance;
        	}
  		}

	}

})(angular);
