(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarCommercialUseBusinesskm
	 * @description
	 * Component used to group car updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarCommercialUseBusinesskm', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-commercial-use/car-commercial-use-businesskm/car-commercial-use-businesskm.html';
	    },
	    controller: 'pchCarCommercialUseBusinesskmComponentController',
		require: {
			formCarUsage : '^ccFormCarUsage',
			pchCommercialUse : '^pchCarCommercialUse'
		}
	});

})(angular);
