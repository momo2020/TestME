(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarPrincipalDriver
	 * @description
	 * Component used to group car updates
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarPrincipalDriver', /*@ngInject*/ {
		bindings: {
		},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-principal-driver/car-principal-driver/car-principal-driver.html';
	    },
	    controller: 'pchCarPrincipalDriverComponentController',
		require: {
			formCarUsage: '^ccFormCarUsage'
		}
	});

})(angular);
