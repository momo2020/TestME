(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarPrincipalDriverComponentController
	 * @description
	 * Controller for pchCarConditionComponent component<br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarPrincipalDriverComponentController', controller);

	 function controller($filter,
	 					$PolicyChangeState,
	 					$rootScope) {
	 	this.$onInit = function(){
	 		var vm = this,
	 			$getDriverCombo = $filter('getDriverCombo'),
	 			$translate = $filter('translate');

            vm.combos = {
            	drivers : $getDriverCombo(vm.formCarUsage.driversList, 'drivers')
            };
            vm.combos.drivers.unshift({key : null, value : $translate('LBLXXXX.car.select')});

            // Add 'Other' item on drivers drop down if flag 'otherPrincipalDriverAllowed' is true
            if(vm.formCarUsage.otherDriverAllowed && $PolicyChangeState.$get().state().canAddDriver){
                vm.combos.drivers.push({key : -1, value : $translate('LBLXXXX.driver.other')});
            }

			vm.changePrincipalDriverSince = function(){
				$rootScope.$broadcast('eventSetPrincipalDriverSinceVisibility', {currentCar: vm.formCarUsage.ngModel.vehicle});
			};

        }
    }
})(angular);
