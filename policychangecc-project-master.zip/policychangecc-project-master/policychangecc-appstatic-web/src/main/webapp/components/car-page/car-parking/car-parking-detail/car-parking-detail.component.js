(function(angular){
	'use strict';

	/**
	 * @ngdoc directive
	 * @name INTACT.PolicyChange.directive:pchCarParkingDetail
	 * @description
	 * Component used to manage the Parking Detail on the car: shared garage/shared street parking spot
	 *
	 * @restrict 'E'
	 */
	angular.module('INTACT.PolicyChange').component('pchCarParkingDetail', /*@ngInject*/ {
		bindings: {},
	    templateUrl: function($PCAppConfiguration){
	    	return $PCAppConfiguration.componentsViewsPath + '/car-page/car-parking/car-parking-detail/car-parking-detail.html';
	    },
	    controller: 'pchCarParkingDetailComponentController',
	    require: {
			formCarUsage	: '^ccFormCarUsage'
		}
	});

})(angular);
