(function(angular){
	'use strict';

	/**
	 * @ngdoc controller
	 * @name INTACT.PolicyChange.controller:pchCarAntitheftTypesComponentController
	 * @description
	 * Controller for Antitheft Types <br>
	 *
	 */
	 angular.module('INTACT.PolicyChange').controller('pchCarAntitheftTypesComponentController', controller);

	 function controller($filter, $rootScope, $PCAppConfiguration, $PolicyChange) {

        // ready to work when the parent controller is initialized
		this.$onInit = function() {

			var vm = this,
                codeRemoved = $filter('translate')('MODIFICATION.CODE.REMOVED');
			vm.antitheftTypeList = fillAntitheftCombo(false);
			vm.showAntitheftTypes = showAntitheftTypes;
			vm.updateAntitheftList = updateAntitheftList;
			
            $rootScope.$on('refillAntitheftCombo', function(event, params){
                if(params.index === vm.formCarAbout.ngModel.vehicle.riskIndex){
                    vm.antitheftTypeList = fillAntitheftCombo(params.reset);
                }
            });

            var province = $PCAppConfiguration.province.toLowerCase();
            var originalVehicles = $PolicyChange.$get().policyChange().data.response.vehicles;

            function originalHasAntitheft (type){
                var originalVehicle  = originalVehicles[vm.formCarAbout.ngModel.vehicle.riskIndex];
                if(originalVehicle){
                	if( angular.isDefined(originalVehicle.antiTheftDevices) && originalVehicle.antiTheftDevices.length > 0){
                		var antitheft = $filter('filter')(originalVehicle.antiTheftDevices, {type : type})[0];
                		return angular.isDefined(antitheft);
                	}                	
                }
                return false;
            }
            
            function showAntitheftTypes(){
                var originalVehicle  = originalVehicles[vm.formCarAbout.ngModel.vehicle.riskIndex];
                if(province === "qc" && (vm.formCarAbout.ngModel.vehicle.modificationCode !== "N" && vm.formCarAbout.ngModel.vehicle.modificationCode !== "S") && originalVehicle && originalVehicle.antiTheftDevices.length > 0){
                    // when original car has an antitheft we persist  always the antitheft types whenever the antitheft type 'yes' checkbox is selected
                    if(vm.formCarAbout.ngModel.vehicle.antiTheftDevice){
                        vm.formCarAbout.ngModel.vehicle.antiTheftDevices = originalVehicle.antiTheftDevices;
                    }
                    return false;
                }

	            return  vm.formCarAbout.ngModel.vehicle.antiTheftDevice;
	        }

	        function updateAntitheftList(key, isSelected){
                if(isSelected){
                    var antitheft = {
                        type : key,
                        brand : null,
                        modificationCode : $filter('translate')('MODIFICATION.CODE.NEW')
                    }
                    vm.formCarAbout.ngModel.vehicle.antiTheftDevices.push(antitheft);
                }
                else{
                    var antitheft = $filter('filter')(vm.formCarAbout.ngModel.vehicle.antiTheftDevices, {type : key})[0];
                    if(angular.isDefined(antitheft) && originalHasAntitheft(key)){
                        antitheft.modificationCode = codeRemoved;
                    }
                    else if(!originalHasAntitheft(key)){
                        var count = 0, index;
                        angular.forEach(vm.formCarAbout.ngModel.vehicle.antiTheftDevices, function(antitheft){
                            if(antitheft.type === key){
                                index = count;
                            }
                            count ++;
                        });

                        if(angular.isDefined(index)){
                            vm.formCarAbout.ngModel.vehicle.antiTheftDevices.splice(index, 1);
                            $rootScope.$broadcast('resetTrackingBrand');
                        }
                    }
                }
            }

            function resetAntitheftCombo(){
                vm.antitheftTypeList = fillAntitheftCombo(true);
            }

            function vehicleHasAntiTheft(){
                var hasAntiTheft = false;
                angular.forEach(vm.formCarAbout.ngModel.vehicle.antiTheftDevices, function(antitheft){
                    if(antitheft.modificationCode !== codeRemoved){
                        hasAntiTheft = true;
                    }
                });

                return hasAntiTheft;
            }

            function fillAntitheftCombo (reset){
                var removeAll = false;
                if (reset){
                    angular.forEach(vm.formCarAbout.ngModel.vehicle.antiTheftDevices, function(antitheft){
                        if(originalHasAntitheft(antitheft.type)){
                            antitheft.modificationCode = codeRemoved;
                        }
                        else{
                            removeAll = true;
                        }
                    });

                    if(removeAll){
                        vm.formCarAbout.ngModel.vehicle.antiTheftDevices = [];
                    }
                }

                var liste = $filter('comboList')('antiTheftDevices'),
                    hasAntiTheft = vehicleHasAntiTheft();
					
                for(var i = 0 , ll = liste.length ; i < ll ; i++){

                    if(hasAntiTheft && $filter('filter')(vm.formCarAbout.ngModel.vehicle.antiTheftDevices, {type : liste[i].key} ).length > 0 ){
                        liste[i].ind = true;
                    }
                    else{
                        liste[i].ind = false;
                    }
                }

                return liste;
            }
  		}
	}

})(angular);
