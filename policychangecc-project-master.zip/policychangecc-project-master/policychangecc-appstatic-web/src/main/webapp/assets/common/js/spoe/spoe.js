window.onload = init;

function init() {
	// Event object
	var objEvent = {};

	/* Class loader */
	function Loader($wrapper){
		this.$elt = $('span', $wrapper);
		return this;
	}

	$.extend(Loader.prototype, {
		show: function(){
			this.$elt.removeClass('hidden');
			return this;
		},
		hide: function(){
			this.$elt.addClass('hidden');
			return this;
		}
	});

	function Btn(selector){
		this.$elt = $(selector);
		return this;
	}

	$.extend(Btn.prototype, {
		enable: function(){
			this.$elt.attr('disabled', false);
			$(this).trigger('onEnabled');
			return this;
		},

		disable: function(){
			this.$elt.attr('disabled', true);
			$(this).trigger('onDisabled');
			return this;
		}
	});

	var $loader = new Loader($('.btn-wrapper')).hide(),
		$loaderCancel = new Loader($('.btn-wrapper-cancel')).hide(),
		btnCancelId = '#spoeCancelButton',
		$btn = new Btn('#spoeButton'),
		$btnCancel = new Btn(btnCancelId);
	
	// Loader manager events
	$($btn).on('onDisabled', function(){
		$loader.show();
	}).on('onEnabled', function(){
		$loader.hide();
	});
	
	$($btnCancel).on('onDisabled', function(){
		$loaderCancel.show();
	}).on('onEnabled', function(){
		$loaderCancel.hide();
	});

	//url
	var urlOrigin = location.origin;
	if(urlOrigin != 'http://localhost:3001' && urlOrigin != 'http://localhost:9083'){
		urlOrigin += "/pc-u";
	}
	var policiesURL = urlOrigin + "/assets/js/spoe/_policies.json";
	var envsURL = urlOrigin + "/assets/js/spoe/envs.json";

	var loadPolicies = function(province){
		$.getJSON(policiesURL, function(data){
			var listItems= "<option value=''></option>";
			 
			var newPolicies = data.policies[province].sort(function(a,b) {return (a.group > b.group) ? 1 : ((b.group > a.group) ? -1 : 0);} );
			var currentGroupName = newPolicies[0].group;
			var currentGroupList = [];
			var allList = [];

			for(var i = 0, ll = newPolicies.length ; i < ll ; i++){
				if(newPolicies[i].group !== currentGroupName){
					var sorted = currentGroupList.sort(function(a,b) {return (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0);} );
					allList.push(sorted);
					currentGroupName = newPolicies[i].group;
					currentGroupList = [];
				}
				currentGroupList.push(newPolicies[i]);
			}
			allList.push(currentGroupList);
			currentGroupName = '';

			for (var i = 0; i < allList.length; i++){
				for(var j = 0 ; j < allList[i].length ; j++){
					if(allList[i][j].group !== currentGroupName){
						currentGroupName = allList[i][j].group;
						if(i !== 0 && j !== 0){
							listItems += "</optgroup>";
						}
						listItems += "<optgroup label='" + currentGroupName + "'>";
					}
					listItems+= "<option value='" + allList[i][j].id + "'>" + allList[i][j].value + "</option>";				
				}
			}
			$(".policies").html(listItems);
		});
	}
	
	$.getJSON(envsURL, function(data){
		var listItems= "";   
		var junction = location.href.replace("/pcspoe.html", "");
		  
		for (var i = 0; i < data.envs.length; i++){
			if (data.envs[i].env == "") {
				data.envs[i].env = junction;
			}
			
			if ( location.href.indexOf(data.envs[i].value.toLowerCase()) < 0 ) {
				listItems+= "<option value='" + data.envs[i].env + "'>" + data.envs[i].value + "</option>";
			} else {
				listItems+= "<option selected='true' + value='" + data.envs[i].env + "'>" + data.envs[i].value + "</option>";
			}
		}
		
		$(".envs").html(listItems);
	});

	$("input[name=province]").change(function(){
		var province = $(this).val();
		loadPolicies(province);
	});
	
	$(btnCancelId).click(function () {
		var language = $("input[name=language]:checked").val();
		var province = $("input[name=province]:checked").val();
		var selectedPolicy = $( "#policies option:selected" ).val();	
		var policyNumber = selectedPolicy ? selectedPolicy : $("#policies-txt").val().toUpperCase().trim();
		
		var selectedEnv = ($( "#envs option:selected" ).val() !== undefined) ? $( "#envs option:selected" ).val() : location.origin;
		var ajaxURL = selectedEnv + '/policychangerest/v1/spoe/'+policyNumber+'/'+language+'/'+province;
		$.ajax({
			type: "DELETE",
			dataType: "json",
			url: ajaxURL , 
			beforeSend: function(){
				$btnCancel.disable();
			},
			xhrFields: {
				 withCredentials: true
			},
			success:function(data, status, response) {
				if ( selectedEnv == "http://localhost:9083" ){
					selectedEnv = "http://localhost:3001";
				}
				window.location.href = selectedEnv + '/' + policyNumber + '/' + province + '/' + language ;
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) { 
				if (textStatus == 'Unauthorized') {
					console.log('custom message. Error: ' + errorThrown);
				} else {
					console.log('custom message. Error: ' + errorThrown);
				}
			}, 
			complete: function(){
				$btnCancel.enable();
			}
		});
	});
	
	$('#spoeButton').click(function () {
	var language = $("input[name=language]:checked").val();
	var province = $("input[name=province]:checked").val();
	var selectedPolicy = $( "#policies option:selected" ).val();	
	var policyNumber = selectedPolicy ? selectedPolicy : $("#policies-txt").val().toUpperCase().trim();
	var agreementDate = '010716';//$.datepicker.formatDate('ddmmyy', $('#agreementDate').datepicker('getDate'));
	var selectedEnv = ($( "#envs option:selected" ).val() !== undefined) ? $( "#envs option:selected" ).val() : location.origin;
	var ajaxURL = selectedEnv + '/policychangerest/v1/spoe/'+policyNumber+'/'+language+'/'+province;
	$.ajax({
	    type: "GET",
	    dataType: "json",
	    url: ajaxURL , 
	    beforeSend: function(){
	    	$btn.disable();
	    },
	    xhrFields: {
	         withCredentials: true
	    },
	    success:function(data, status, response) {
	    	if ( selectedEnv == "http://localhost:9083" ){
	    		selectedEnv = "http://localhost:3001";
	    	}
	    	window.location.href = selectedEnv + '/' + policyNumber + '/' + province + '/' + language ;
	    },
		error: function(XMLHttpRequest, textStatus, errorThrown) { 
			if (textStatus == 'Unauthorized') {
				console.log('custom message. Error: ' + errorThrown);
		    } else {
		    	console.log('custom message. Error: ' + errorThrown);
		    }
	    }, 
	    complete: function(){
	    	$btn.enable();
	    }
	});
});
}
	
