(function(){
    'use strict';

    module.exports = function(grunt) {
        // ==================================================
        // Global Config
        // ==================================================
        var globalConfig = {
            src:                'src/main/webapp',
            dest:               'target/<%= APP_NAME %>',
            npm:                'node_modules',
            uiModulesBasePath:  'node_modules',            
            assets:             '<%= globalConfig.src %>/assets/common',
            specificAssets:     '<%= globalConfig.src %>/assets/<%= APP_NAME %>',
            applicationSrc:     '<%= globalConfig.src %>/application',
            selectorSrc:        '<%= globalConfig.src %>/broker-selector',
            applicationPort:    '<%= PORT %>',
            watchedFiles: [
                '<%= globalConfig.assets %>/js/*.js',
                '<%= globalConfig.assets %>/js/**/*.js',
                '<%= globalConfig.assets %>/css/**/*.css',
                '<%= globalConfig.specificAssets %>/css/**/*.css',
                '<%= globalConfig.applicationSrc %>/*.js',
                '<%= globalConfig.applicationSrc %>/**/*.js',
                '<%= globalConfig.selectorSrc %>/*.js',
                '<%= globalConfig.selectorSrc %>/**/*.js',
                '<%= globalConfig.src %>/modules/**/*.js',
                '<%= globalConfig.src %>/components/**/*.*',
                '<%= globalConfig.applicationSrc %>/views/*.html',
                '<%= globalConfig.applicationSrc %>/views/**/*.html',
                '<%= globalConfig.src %>/modules/**/views/*.html',
                '<%= globalConfig.src %>/index.html',
                '<%= globalConfig.src %>/redirect.html',
                '<%= globalConfig.src %>/selector.html',
                '<%= globalConfig.src %>/pcspoe.html',
                '<%= globalConfig.src %>/domxmlviewer.html',
                '<%= globalConfig.npm %>/intact-address/dist/*.*',
                '<%= globalConfig.src %>/domready.js'
            ],
            vendorsFiles: [
                '<%= globalConfig.npm %>/jquery/dist/jquery.js',
                '<%= globalConfig.npm %>/match-media/matchMedia.js',
                '<%= globalConfig.npm %>/angular/angular.js',
                '<%= globalConfig.npm %>/angular-animate/angular-animate.js',
                '<%= globalConfig.npm %>/angular-cookies/angular-cookies.js',
                '<%= globalConfig.npm %>/angular-route/angular-route.js',
                '<%= globalConfig.npm %>/angular-sanitize/angular-sanitize.js',
                '<%= globalConfig.npm %>/angular-aria/angular-aria.js',
                '<%= globalConfig.npm %>/angular-breadcrumb/dist/angular-breadcrumb.js',
                '<%= globalConfig.npm %>/angular-cache/dist/angular-cache.js',
                '<%= globalConfig.npm %>/angular-filter/dist/angular-filter.js',
                '<%= globalConfig.npm %>/angular-modal-service/dst/angular-modal-service.js',
                '<%= globalConfig.npm %>/angular-pretty-xml/dist/angular-pretty-xml.js',
                '<%= globalConfig.npm %>/angular-touch/angular-touch.js',
                '<%= globalConfig.npm %>/angular-translate/dist/angular-translate.js',
                '<%= globalConfig.npm %>/angular-ui-router/release/angular-ui-router.js',
                '<%= globalConfig.npm %>/matchmedia-ng/matchmedia-ng.js',
                '<%= globalConfig.npm %>/angular-dynamic-locale/dist/tmhDynamicLocale.js',
                '<%= globalConfig.npm %>/ng-mask/dist/ngMask.js',
                '<%= globalConfig.npm %>/moment/moment.js',
				'<%= globalConfig.npm %>/clientcentre-helptext/libs/jquery.tooltipster.min.js',
				'<%= globalConfig.npm %>/underscore/underscore-min.js'
            ],
            vendorsFilesDest: '<%= globalConfig.dest %>/assets/js/vendors.js',
            appFiles: [
                '<%= globalConfig.src %>/application/*.js',
                '<%= globalConfig.src %>/application/providers/provider.configuration.js',
                '<%= globalConfig.src %>/application/providers/provider.policy-change-configuration.js',
                '<%= globalConfig.src %>/application/providers/provider.application-calendar.js',
                '<%= globalConfig.src %>/application/providers/provider.validation.js',
                '<%= globalConfig.src %>/application/providers/provider.policychange.js',
                '<%= globalConfig.src %>/application/providers/provider.policychange-state.js',
                '<%= globalConfig.src %>/application/providers/provider.policychange-modifications.js',
                '<%= globalConfig.src %>/application/providers/provider.urls.js',
                '<%= globalConfig.src %>/application/providers/provider.routes.js',
                '<%= globalConfig.src %>/application/services/*.js',
                '<%= globalConfig.src %>/application/models/*.js',
                '<%= globalConfig.src %>/application/controllers/*.js',
                '<%= globalConfig.src %>/application/directives/*.js',
                '<%= globalConfig.src %>/application/filters/*.js',
                '<%= globalConfig.src %>/components/**/*.js',
                '<%= globalConfig.src %>/domready.js'
            ],
            appFilesDest:'<%= globalConfig.dest %>/application/app.js',
            selectorFiles: [
                '<%= globalConfig.selectorSrc %>/broker-selector.js',
                '<%= globalConfig.selectorSrc %>/controllers/*.js',
                '<%= globalConfig.src %>/domready.js'
            ],
            selectorFilesDest: '<%= globalConfig.dest %>/selector/selector.js',
            modulesFiles: [
                '<%= globalConfig.npm %>/clientcentre-core-http/dist/index.js',
                '<%= globalConfig.npm %>/clientcentre-core/dist/index.js',
                '<%= globalConfig.npm %>/clientcentre-bootstrap/dist/index.js',
                '<%= globalConfig.npm %>/clientcentre-analytics/dist/index.js',
                '<%= globalConfig.npm %>/clientcentre-configs-extractor/dist/index.js',
                '<%= globalConfig.npm %>/clientcentre-cookies/dist/index.js',
                '<%= globalConfig.npm %>/clientcentre-distributors/dist/index.js',
                '<%= globalConfig.npm %>/clientcentre-helptext/dist/index.js',
                '<%= globalConfig.npm %>/clientcentre-interceptors/dist/index.js',
                '<%= globalConfig.npm %>/clientcentre-page-transition/dist/index.js',
                '<%= globalConfig.npm %>/clientcentre-single-request/dist/index.js',
                '<%= globalConfig.npm %>/clientcentre-policies/dist/index.js',
                '<%= globalConfig.npm %>/clientcentre-modal/dist/index.js',
                '<%= globalConfig.npm %>/clientcentre-error-page/dist/index.js',
                '<%= globalConfig.npm %>/clientcentre-error-404/dist/index.js',
                '<%= globalConfig.npm %>/clientcentre-calendar/dist/index.js',
                '<%= globalConfig.npm %>/intact-address/dist/index.js',
                '<%= globalConfig.src %>/modules/debug/*.js',
                '<%= globalConfig.src %>/modules/debug/**/*.js'
            ],
            modulesFilesDest: '<%= globalConfig.dest %>/modules/modules.js',
            cssFiles: [
                '<%= globalConfig.assets %>/css/bootstrap.min.css',
                '<%= globalConfig.assets %>/css/tooltipster.css',
                '<%= globalConfig.assets %>/css/styles.css',
                '<%= globalConfig.specificAssets %>/css/styles.css',
                '<%= globalConfig.assets %>/css/media_queries.css',
                '<%= globalConfig.specificAssets %>/css/media_queries.css',
                '<%= globalConfig.assets %>/css/custom/*.css',
                '<%= globalConfig.specificAssets %>/css/custom/*.css',
                '<%= globalConfig.npm %>/clientcentre-calendar/dist/styles.css',
                '<%= globalConfig.src %>/modules/debug/*.css'
            ],
            cssFilesDest: '<%= globalConfig.dest %>/assets/css/styles.css',
            watchTaks: [
                'concat:vendors',
                'concat:app',
                'concat:modules',
                'concat:css',
                'ngAnnotate:app',
                'copy:assets',
                'copy:pcspoe',
                'copy:domxmlviewer'
            ]
        };

        // ==================================================
        // Project Config
        // ==================================================
        grunt.initConfig({
            pkg: grunt.file.readJSON('package.json'),
            globalConfig: globalConfig,

            // ENV variable change @t runtime
            env: require('./grunt-tasks/env.js')(grunt, globalConfig),

            // JS & CSS Concat sourcemap
            concat_sourcemap: require('./grunt-tasks/concat-source-map.js')(grunt, globalConfig),

            // JS & CSS Concat sans sourceMap
            concat: require('./grunt-tasks/concat.js')(grunt, globalConfig),

            // JS Minifcation
            uglify: require('./grunt-tasks/uglify.js')(grunt, globalConfig),

            // File Watch
            watch: require('./grunt-tasks/watch.js')(grunt, globalConfig),

            // JS Hint
            jshint: require('./grunt-tasks/jshint.js')(grunt, globalConfig),

            // Start Express Server
            express: require('./grunt-tasks/express.js')(grunt, globalConfig),

            // Copy css, js && html files
            copy: require('./grunt-tasks/copy.js')(grunt, globalConfig),

            // Remove dest folder before generate another one
            clean: require('./grunt-tasks/clean.js')(grunt, globalConfig),

            // Dependencies injection
            ngAnnotate: require('./grunt-tasks/annotate.js')(grunt, globalConfig),

            // Replace dynamic values in code
            replace: require('./grunt-tasks/replace.js')(grunt, globalConfig),

            // Doc AngularJs generator
            ngdocs: require('./grunt-tasks/ng-doc.js')(grunt, globalConfig),

            // Unit testing
            karma: require('./grunt-tasks/karma.js')(grunt, globalConfig),

            //Accessibility
            accessibility: require('./grunt-tasks/accessibility')(grunt, globalConfig),

            // Accessibility static files
            htmlSnapshot: require('./grunt-tasks/htmlSnapshot')(grunt, globalConfig)
        });
      
        // Optimization code task.
        grunt.registerTask('optimize', ['jshint']);

        // Doc. angular task.
        grunt.registerTask('ng-doc', [
            'env:doc',
            'load-exec-config',
            'clean:doc',
            'ngdocs',
            'set-express-env',
            'express:app',
            'express-keepalive'
        ]);

        // Build tasks.
        var build_tasks = ['load-exec-config', 'jshint', 'clean:dev', 'concat_sourcemap:vendors', 'concat_sourcemap:app', 'concat_sourcemap:modules', 'ngAnnotate:app', 'concat_sourcemap:css', 'copy:assets'];
        var build_tasks_pc = build_tasks.concat(['replace:build', 'replace:all', 'uglify:app', 'uglify:modules', 'uglify:vendors','copy:pcspoe','copy:domxmlviewer']);
        
        grunt.registerTask('belair-build', ['env:pc'].concat(build_tasks_pc));
        
        // Developpement task with map.
        grunt.registerTask('belair-dev-map', [
            'env:pc',
            'load-exec-config',
            'clean:dev',
            'concat_sourcemap:vendors',
            'concat_sourcemap:app',
            'concat_sourcemap:modules',
            'ngAnnotate:app',
            'uglify:app', 
	    'uglify:modules', 
	    'uglify:vendors',
            'concat_sourcemap:css',
            'copy:assets',
            'copy:pcspoe',
            'copy:domxmlviewer',
            'replace:dev',
            'replace:all',
            'set-express-env',
            'express:app',
            'watch:all'
        ]);

        grunt.registerTask('belair-dev', [
            'env:pc',
            'load-exec-config',
            'clean:dev',
            'concat:vendors',
            'concat:app',
            'concat:modules',
            'concat:css',
            'copy:assets',
            'copy:pcspoe',
            'copy:domxmlviewer',
            'replace:dev',
            'replace:all',
            'set-express-env',
            'express:app',
            'watch:all'
        ]);

        // Set Global configs with context belair/intact
        grunt.registerTask('load-exec-config', 'load exec. context configs', function(){
            grunt.config('APP_NAME', process.env.APP_NAME);
            grunt.config('APP_DOMAIN', process.env.APP_DOMAIN);
            grunt.config('PORT', process.env.PORT);
        });

        grunt.registerTask('set-express-env', 'Set Express Environment Variable', function() {
            grunt.config('globalConfig.expressStarted-' + process.env.APP_NAME, true);
        });
      
        if(!grunt.config('karma').error){
            grunt.registerTask('unit-tests', [
                'jshint',
                'copy:mocks',
                'karma'
            ]);
        } else {
            grunt.registerTask('unit-tests', 'Dependency Error', function() {
                console.log('\x1b[31m', grunt.config('karma').errorMessage, '\x1b[0m');
                return false;
            });
        }

        function logError(){
            if(grunt.config('accessibility').error){
               console.log('\x1b[31m', grunt.config('accessibility').errorMessage, '\x1b[0m'); 
            }
            if(grunt.config('htmlSnapshot').error){
               console.log('\x1b[31m', grunt.config('htmlSnapshot').errorMessage, '\x1b[0m'); 
            }
        }

        if(!grunt.config('accessibility').error && !grunt.config('htmlSnapshot').error){
            grunt.registerTask('wcag', [
                'clean:wcag',
                'env:pc',
                'load-exec-config',
                'clean:dev',
                'concat_sourcemap:vendors',
                'concat_sourcemap:app',
                'ngAnnotate:app',
                'concat_sourcemap:css',
                'copy:assets',
                'replace:dev',
                'replace:all',
                'set-express-env',
                'express:app',
                'htmlSnapshot:pc', 
                'copy:wcagBelair',
                'accessibility:pc'
            ]);
        } else {
            grunt.registerTask('wcag', 'Dependency Error', function() {
                logError();
                return false;
            });
        }
    };
})();


