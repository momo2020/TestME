/* ================================================================================
 * Modules dependencies & Variables
 * ============================================================================== */
var express         = require('express');
var errorHandler    = require('errorhandler');
var cookieParser    = require('cookie-parser');
var bodyParser      = require('body-parser');
var methodOverride  = require('method-override');
var morgan          = require('morgan');
var compression     = require('compression');
var http            = require('http');
var path            = require('path');
var conf            = require('nconf');
var colors          = require('colors');
var _               = require('underscore');
var app             = express();
var grunt           = require('grunt');

/* ================================================================================
 * Global configuration
 * ============================================================================== */
var APP_PATH = '/stub';
var CONFIG_PATH = APP_PATH + '/config';
var ROOT_PATH = '';

app.config = conf.argv().env().defaults({store:require(path.join(__dirname, CONFIG_PATH + '/default'))});


if(process.env.NODE_ENV == 'development'){
    app.config.defaults({store:_.extend(require(path.join(__dirname, CONFIG_PATH + '/default')),require(path.join(__dirname, CONFIG_PATH + '/dev')))});
}

if(process.env.NODE_ENV == 'production'){
    app.config.defaults({store:_.extend(require(path.join(__dirname, CONFIG_PATH + '/default')), require(path.join(__dirname, CONFIG_PATH + '/prod')))});
}

/* ================================================================================
 * App Settings
 * ============================================================================== */
app.set('port', process.env.PORT || grunt.config('globalConfig.applicationPort') || app.config.get('application:port') || 3000);
app.set('basePath', __dirname);
app.set('views', path.join(__dirname, APP_PATH + '/views'));
app.set('X-Powered-By', 'NodeJS');
app.set('staticPublicDir', path.join(__dirname, '/target/' + process.env.APP_NAME));

/**
 * Context application (intact|belair)
 */
var contextApp = process.env.APP_DOMAIN.match(/(belair|intact)/);
app.set('contextApp', (contextApp)? contextApp[0] : null);
app.set('rootPath', ROOT_PATH);

app.use(cookieParser());
app.use(errorHandler());
app.use(morgan('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(methodOverride());
app.locals.pretty = true;
app.use(ROOT_PATH + '/application/src', express.static(path.join(__dirname, './src')));
app.use(ROOT_PATH + '/assets/js/src', express.static(path.join(__dirname, './src')));
app.use(ROOT_PATH + '/assets/css/src', express.static(path.join(__dirname, './src')));
app.use(ROOT_PATH + '/modules/src', express.static(path.join(__dirname, './src')));
app.use(ROOT_PATH + '/modules/node_modules', express.static(path.join(__dirname, './node_modules')));
app.use(ROOT_PATH + '/', express.static(app.get('staticPublicDir')));
app.use(compression());

/* ================================================================================
 * Routing
 * ============================================================================== */
require(path.join(__dirname, APP_PATH + '/routes'))(app);


/* ================================================================================
 * Start Server
 * ============================================================================== */
console.log(('\nApplication ' + process.env.APP_NAME.toUpperCase() + ' running on http://localhost:' + process.env.PORT + '\n').green.underline);

if(!grunt.config('globalConfig.expressStarted-' + process.env.APP_NAME)){
    http.createServer(app).listen(app.get('port'), function(){
        if(app.config.get('application:verbose')){
            console.log(('Server listening on port ' + app.get('port')).green);
        }
    });
}

module.exports = app;