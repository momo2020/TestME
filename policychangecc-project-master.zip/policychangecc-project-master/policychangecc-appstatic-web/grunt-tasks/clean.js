module.exports = function(grunt, globalConfig){
	grunt.loadNpmTasks('grunt-contrib-clean');
	return {
    	dev: ['<%= globalConfig.dest %>'],
    	doc: ['target/docs'],
    	wcag: ['target/wcag', 'target/html-snapshots']
    };
};