module.exports = function(grunt, globalConfig){
	grunt.loadNpmTasks('grunt-contrib-copy');
	return {
    	assets: {
	        files: [{
	            cwd: "<%= globalConfig.assets %>/img",
	            expand: true,
	            src: ["**"],
	            dest: '<%= globalConfig.dest %>/assets/img',
	            filter: 'isFile'
	        },
	        {
	            cwd: "<%= globalConfig.specificAssets %>/img",
	            expand: true,
	            src: ["**"],
	            dest: '<%= globalConfig.dest %>/assets/img',
	            filter: 'isFile'
	        },
	        {
	            cwd: "<%= globalConfig.specificAssets %>/helptexts",
	            expand: true,
	            src: ["**"],
	            dest: '<%= globalConfig.dest %>/assets/helptexts',
	            filter: 'isFile'
	        },
	        {
	            cwd: "<%= globalConfig.assets %>/fonts",
	            expand: true,
	            src: ["**"],
	            dest: '<%= globalConfig.dest %>/assets/fonts',
	            filter: 'isFile'
	        },
	        {
	            cwd: "<%= globalConfig.npm %>/angular-i18n",
	            expand: true,
	            src: ["angular-locale_fr-ca.js", "angular-locale_en-ca.js"],
	            dest: '<%= globalConfig.dest %>/application/angular-i18n',
	            filter: 'isFile'
	        },
	        {
	            cwd: "<%= globalConfig.assets %>/js/spoe",
	            expand: true,
	            src: ["**"],
	            dest: '<%= globalConfig.dest %>/assets/js/spoe',
	            filter: 'isFile'
	        },
	        {
	            cwd: "<%= globalConfig.applicationSrc %>/views",
	            expand: true,
	            src: ["**"],
	            dest: '<%= globalConfig.dest %>/application/views',
	            filter: 'isFile'
	        },
	        {
	            cwd: "<%= globalConfig.src %>/components",
	            expand: true,
	            src: ['**/*.html'],
	            dest: '<%= globalConfig.dest %>/application/views/components',
	            filter: 'isFile'
	        },
	        {
	              cwd: "<%= globalConfig.npm %>/clientcentre-error-page/dist/views",
	              expand: true,
	              src: ["**"],
	              dest: '<%= globalConfig.dest %>/modules/error-page/views',
	              filter: 'isFile'
	        },
	        {
	              cwd: "<%= globalConfig.npm %>/clientcentre-page-transition/dist/views",
	              expand: true,
	              src: ["**"],
	              dest: '<%= globalConfig.dest %>/modules/page-transition/views',
	              filter: 'isFile'
	        },
	        {
	              cwd: "<%= globalConfig.npm %>/clientcentre-error-404/dist/views",
	              expand: true,
	              src: ["**"],
	              dest: '<%= globalConfig.dest %>/modules/error-404/views',
	              filter: 'isFile'
	        },
	        {
	              cwd: "node_modules/clientcentre-helptext/dist/views",
	              expand: true,
	              src: ["**"],
	              dest: '<%= globalConfig.dest %>/modules/helptext/views',
	              filter: 'isFile'
	        },
	        {
	            cwd: "<%= globalConfig.src %>",
	            expand: true,
	            src: ['index.html'],
	            dest: '<%= globalConfig.dest %>',
	            filter: 'isFile'
	        },
	        {
	            cwd: "<%= globalConfig.src %>",
	            expand: true,
	            src: ['redirect.html'],
	            dest: '<%= globalConfig.dest %>',
	            filter: 'isFile'
	        }]
      	},
      	pcspoe: {
	        files: [
	        {
	            cwd: "<%= globalConfig.src %>",
	            expand: true,
	            src: ['pcspoe.html'],
	            dest: '<%= globalConfig.dest %>',
	            filter: 'isFile'
	        }]
      	},
      	domxmlviewer: {
	        files: [
	        {
	            cwd: "<%= globalConfig.src %>",
	            expand: true,
	            src: ['domxmlviewer.html'],
	            dest: '<%= globalConfig.dest %>',
	            filter: 'isFile'
	        }]
      	},
      	wcagBelair:{
	        files: [
	        {
	            cwd: "target/belair/assets/css",
	            expand: true,
	            src: ["**"],
	            dest: 'target/html-snapshots/belair/assets/css',
	            filter: 'isFile'
	        },
	        {
	            cwd: "target/belair/assets/fonts",
	            expand: true,
	            src: ["**"],
	            dest: 'target/html-snapshots/belair/assets/fonts',
	            filter: 'isFile'
	        },
	        {
	            cwd: "target/belair/assets/img",
	            expand: true,
	            src: ["**"],
	            dest: 'target/html-snapshots/belair/assets/img',
	            filter: 'isFile'
	        }
	        ]
      	},
      	wcagIntact:{
	        files: [
	        {
	            cwd: "target/intact/assets/css",
	            expand: true,
	            src: ["**"],
	            dest: 'target/html-snapshots/intact/assets/css',
	            filter: 'isFile'
	        },
	        {
	            cwd: "target/intact/assets/fonts",
	            expand: true,
	            src: ["**"],
	            dest: 'target/html-snapshots/intact/assets/fonts',
	            filter: 'isFile'
	        },
	        {
	            cwd: "target/intact/assets/img",
	            expand: true,
	            src: ["**"],
	            dest: 'target/html-snapshots/intact/assets/img',
	            filter: 'isFile'
	        }
	        ]
      	},
      	mocks: {
      		files: [
      		{
      			cwd: "stub/mocks",
      			expand: true,
      			src: ['**'],
      			dest: 'tests/mocks',
      			filter: 'isFile'
      		}
      		]
      	}
    };
};
