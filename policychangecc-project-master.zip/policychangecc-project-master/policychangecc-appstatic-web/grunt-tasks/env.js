module.exports = function(grunt, globalConfig) {
    grunt.loadNpmTasks('grunt-env');
    return {
        pc: {
            APP_NAME: 'belair',
            APP_DOMAIN: 'www.belairdirect.com',
            PORT: 3001
        },
        doc: {
            APP_NAME: 'docs/ngdocs',
            APP_DOMAIN: 'ngdoc',
            PORT: 4001
        }
    };
};