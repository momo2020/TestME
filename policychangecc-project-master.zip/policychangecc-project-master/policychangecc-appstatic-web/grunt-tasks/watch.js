module.exports = function(grunt, globalConfig) {
    grunt.loadNpmTasks('grunt-contrib-watch');
    return {
        all: {
            tasks: globalConfig.watchTaks.concat([
                'replace:dev',
                'replace:all',
                'watch:all'
            ]),
            files: globalConfig.watchedFiles.concat([])
        },
          options: {
            nospawn: true
        }
    };
};