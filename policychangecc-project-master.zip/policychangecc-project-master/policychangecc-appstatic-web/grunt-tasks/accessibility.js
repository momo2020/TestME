module.exports = function(grunt, globalConfig) {

    var optionalDependencies = grunt.file.readJSON('package.json').optionalDependencies,
        dependencies = ["grunt-accessibility"],
        errorMessage,
        getConfigs = function(project){
            return {
                options:{
                    force:false,
                    domElement:true,
                    verbose:true,
                    reportType: 'json',
                    reportLocation : 'target/wcag/'+project,
                    reportLevels: {
                      notice: true,
                      warning: true,
                      error: true
                    },
                    ignore: [
                        //'WCAG2AA.Principle3.Guideline3_1.3_1_1.H57.3.Lang', // The language specified in the lang attribute of the document element does not appear to be well-formed.
                        //'WCAG2AA.Principle3.Guideline3_1.3_1_1.H57.3.XmlLang', // The language specified in the xml:lang attribute of the document element does not appear to be well-formed.
                        //'WCAG2AA.Principle2.Guideline2_4.2_4_2.H25.1.NoTitleEl', // A title should be provided for the document, using a non-empty title element in the head section.
                        //'WCAG2AA.Principle3.Guideline3_1.3_1_1.H57.2', // The html element should have a lang or xml:lang attribute which describes the language of the document.
                        //'WCAG2AA.Principle2.Guideline2_4.2_4_2.H25.2', // Check that the title element describes the document.
                        //'WCAG2AA.Principle4.Guideline4_1.4_1_2.H91.A.EmptyNoId', // (Angular ng-click)
                        //'WCAG2AA.Principle4.Guideline4_1.4_1_2.H91.A.NoHref', // (Angular ng-click) //Anchor elements should not be used for defining in-page link targets. If not using the ID for other purposes (such as CSS or scripting), consider moving it to a parent element.
                        //'WCAG2AA.Principle4.Guideline4_1.4_1_2.H91.A.Placeholder', // Anchor element found with link content, but no href, ID or name attribute has been supplied.
                        //'WCAG2AA.Principle1.Guideline1_4.1_4_3.G18.Fail',
                        //'WCAG2AA.Principle1.Guideline1_4.1_4_3.G18.BgImage', // This element's text is placed on a background image. Ensure the contrast ratio between the text and all covered parts of the image are at least 4.5:1.
                        //'WCAG2AA.Principle1.Guideline1_3.1_3_1.H48' // If this element contains a navigation section, it is recommended that it be marked up as a list.
                        //'WCAG2AA.Principle4.Guideline4_1.4_1_2.H91.Select.Value', // weird bug because of stub
                        //'WCAG2AA.Principle4.Guideline4_1.4_1_2.H91.Select.Name', // weird bug because of stub
                        //'WCAG2AA.Principle1.Guideline1_3.1_3_1.H44.2' // weird bug because of stub
                    ]
                },
                files: [{
                    expand  : true,
                    cwd     : 'target/html-snapshots/'+project,
                    src     : ['**/*.html','*.html'],
                    dest    : 'target/wcag/'+project,
                    ext     : '-report.txt'
                }]
            };
        };

     /**
     * html-snapshot for wcag tests
     * Warning : Package Phantom not available on Nexus !
     * Add those package in dependencies inside package.json then run 'npm install' :
     * "grunt-html-snapshot": "~0.6.1",
     */
    var hasRequiredDependencies = function(){
        var missingDependencies = [];
            
        for(var i = 0, l = dependencies.length; i < l; i++){
            var dependency = dependencies[i];
            if(!optionalDependencies[dependency]){
                errorMessage = 'Warning !\n Dependency not included in json file (in optionalDependencies) :\n ' + dependency + '.\n Check more informations in /grunt-tasks/htmlSnapshot.js !\n';
                missingDependencies.push(dependency);
            } else {
                try {
                    require.resolve(dependency);
                } catch(e){
                     try {
                        if(!grunt.file.exists('node_modules/'+dependency)){
                            missingDependencies.push(dependency);
                        }
                     } catch(e){
                         missingDependencies.push(dependency);
                     } 
                   
                } 
            }
        }

        if(missingDependencies.length){
            errorMessage = 'Warning !\n Dependencies missing list to run wcag task :\n ' + missingDependencies.join('\n ') + '.\n Check more informations in /grunt-tasks/htmlSnapshot.js !\n';
            return false;
        } else return true;
    }; 


    if(hasRequiredDependencies()){
        for(var i = 0, l = dependencies.length; i < l; i++){
            var dependency = dependencies[i];
            if (dependency.substring(0, 6) == "grunt-") {
                grunt.loadNpmTasks(dependency);
            }
        }
        return {
            options : {
                accessibilityLevel: 'WCAG2A'
            },
            pc : getConfigs('policychange')
        };
    } else {
        return {
            error: true,
            errorMesssage: errorMessage
        };  
    } 
    

}; 