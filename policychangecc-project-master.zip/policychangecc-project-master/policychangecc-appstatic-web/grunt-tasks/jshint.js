module.exports = function(grunt, globalConfig) {
    grunt.loadNpmTasks('grunt-contrib-jshint');
    return {
        allFiles: [
            'Gruntfile.js',
            '<%= globalConfig.src %>/application/*.js',
            '<%= globalConfig.src %>/application/**/*.js'
        ],
        options: {
            curly: true,
            eqeqeq: true,
            eqnull: true,
            browser: true,
            validthis: true,
            force: true,
            freeze: true,
            maxdepth: 3,
            undef: true,
            unused: true,
            strict: 'implied',
            globals: {
                "$": false,
                jQuery: true,
                angular: true,
                console: true,
                module: true,
                require: true,
                process: true
            },
            ignores:[],
            reporter: require('jshint-stylish')
        }
    };
};