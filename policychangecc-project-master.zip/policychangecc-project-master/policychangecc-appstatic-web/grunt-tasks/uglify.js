module.exports = function(grunt, globalConfig) {
    grunt.loadNpmTasks('grunt-contrib-uglify');
    return {
        options : {},
        app: {
            src: '<%= globalConfig.dest %>/application/app.js',
            dest: '<%= globalConfig.dest %>/application/app.js'
        },
        modules: {
            src: '<%= globalConfig.dest %>/modules/modules.js',
            dest: '<%= globalConfig.dest %>/modules/modules.js'
        },
        vendors: {
            src: '<%= globalConfig.dest %>/assets/js/vendors.js',
            dest: '<%= globalConfig.dest %>/assets/js/vendors.js'
        }
    };
};