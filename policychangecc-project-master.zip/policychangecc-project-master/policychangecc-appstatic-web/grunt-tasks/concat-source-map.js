"use strict";
module.exports = function(grunt, globalConfig) {
    grunt.loadNpmTasks('grunt-concat-sourcemap');

    return {
        options:{
            separator:'\n'
        },
        vendors: {
            src:  globalConfig.vendorsFiles,
            dest: globalConfig.vendorsFilesDest
        },
        app: {
            src:  globalConfig.appFiles,
            dest: globalConfig.appFilesDest
        },
        selector: {
            src:  globalConfig.selectorFiles,
            dest: globalConfig.selectorFilesDest
        },
        modules: {
            src:  globalConfig.modulesFiles,
            dest: globalConfig.modulesFilesDest
        },
        css: {
            src:  globalConfig.cssFiles,
            dest: globalConfig.cssFilesDest,
        }
    };
};
