module.exports = function(grunt, globalConfig){
	grunt.loadNpmTasks('grunt-ngdocs');
	return {
        app: {
            api: true,
            title: 'Policy Change App',
            titleLink: '/#/app/INTACT.PolicyChange',
            src: [
            '<%= globalConfig.applicationSrc %>/*.js',
            '<%= globalConfig.applicationSrc %>/**/*.js'
            ]
        },
        errorpage: {
            api: true,
            title: 'ErrorPage',
            titleLink: '/#/errorpage/INTACT.ErrorPage',
            src: [
            '<%= globalConfig.src %>/modules/error-page/*.js',
            '<%= globalConfig.src %>/modules/error-page/**/*.js'
    
            ]
        },
        options: {
          dest: 'target/docs/ngdocs',
          html5Mode: false,
          startPage: '/app/INTACT.App',
          title: 'Intact/Belair Client Center',
          titleLink: '/#/app/INTACT.App',
          styles: ['src/main/doc/doc-override.css']
        }
    };
};