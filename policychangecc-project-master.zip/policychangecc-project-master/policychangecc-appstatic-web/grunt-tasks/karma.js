module.exports = function(grunt, globalConfig){

    var optionalDependencies = grunt.file.readJSON('package.json').optionalDependencies,
    dependencies = [
        "grunt-karma",
        "jasmine-core",
        "karma",
        "karma-chrome-launcher",
        "karma-html-reporter",
        "karma-jasmine",
        "karma-junit-reporter",
        "karma-coverage",
        "karma-ng-html2js-preprocessor"
    ],
    errorMessage;
      
      /**
     * Karma for unit tests
     * Warning : Package Karma not available on Nexus !
     * Add those package in dependencies inside package.json then run 'npm install' to enable unit testing:
     * "grunt-karma": "^0.12.1",
     * "jasmine-core": "^2.3.4",
     * "karma": "^0.13.11",
     * "karma-chrome-launcher": "^0.2.1",
     * "karma-html-reporter": "^0.2.7",
     * "karma-jasmine": "^0.3.6",
     * "karma-junit-reporter": "^0.3.8",
     * "karma-coverage": "~0.5.0",
     * "karma-ng-html2js-preprocessor": "^0.2.0"
    */
    
    var hasRequiredDependencies = function(){
        var missingDependencies = [];
            
        for(var i = 0, l = dependencies.length; i < l; i++){
            var dependency = dependencies[i];
            if(!optionalDependencies[dependency]){
                errorMessage = 'Warning !\n Dependency not included in json file (in optionalDependencies) :\n ' + dependency + '.\n Check more informations in /grunt-tasks/htmlSnapshot.js !\n';
                missingDependencies.push(dependency);
            } else {
                try {
                    require.resolve(dependency);
                } catch(e){
                     try {
                        if(!grunt.file.exists('node_modules/'+dependency)){
                            missingDependencies.push(dependency);
                        }
                     } catch(e){
                         missingDependencies.push(dependency);
                     } 
                   
                } 
            }
            
        }

        if(missingDependencies.length){
            errorMessage = 'Warning !\n Dependencies missing list to run wcag task :\n ' + missingDependencies.join('\n ') + '.\n Check more informations in /grunt-tasks/htmlSnapshot.js !\n';
            return false;
        } else return true;
    }; 


    if(hasRequiredDependencies()){
        for(var i = 0, l = dependencies.length; i < l; i++){
            var dependency = dependencies[i];
            if (dependency.substring(0, 6) == "grunt-") {
                grunt.loadNpmTasks(dependency);
            }
        }
		return {
    	    unit: {
    	    	configFile: 'karma.unit-tests.conf.js',
    	    }
        };
	} else {
        return {
            error: true,
            errorMessage: errorMessage
        }; 
    }
};