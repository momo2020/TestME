module.exports = function(grunt, globalConfig){
	grunt.loadNpmTasks('grunt-ng-annotate');
	return {
    	options: {
        	remove: true,
        	add: true
      	},
      	app: {
        	files: {
          	'<%= globalConfig.dest %>/application/app.js': ['<%= globalConfig.dest %>/application/app.js'],
            '<%= globalConfig.dest %>/modules/modules.js': ['<%= globalConfig.dest %>/modules/modules.js']
        	}
      	},
        selector: {
          files: {
            '<%= globalConfig.dest %>/selector/selector.js': ['<%= globalConfig.dest %>/selector/selector.js']
          }
        }
    };
};