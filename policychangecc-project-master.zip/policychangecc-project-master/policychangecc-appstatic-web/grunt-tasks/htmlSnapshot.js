module.exports = function(grunt, globalConfig) {
 
    var optionalDependencies = grunt.file.readJSON('package.json').optionalDependencies,
    dependencies = ["grunt-html-snapshot"],
    errorMessage,
    getConfigs = function(project, port){
        return {
            options: {
                //that's the path where the snapshots should be placed
                //it's empty by default which means they will go into the directory
                //where your Gruntfile.js is placed
                snapshotPath:'target/html-snapshots/'+project+'/',
                //This should be either the base path to your index.html file
                //or your base URL. Currently the task does not use it's own
                //webserver. So if your site needs a webserver to be fully
                //functional configure it here.
                sitePath: 'http://localhost:'+port+'/',
                //you can choose a prefix for your snapshots
                //by default it's 'snapshot_'
                fileNamePrefix: '',
                //by default the task waits 500ms before fetching the html.
                //this is to give the page enough time to to assemble itself.
                //if your page needs more time, tweak here.
                msWaitForPages: 2000,
                //sanitize function to be used for filenames. Converts '#!/' to '_' as default
                //has a filename argument, must have a return that is a sanitized string
                sanitize: function (requestUri) {
                    //returns 'index.html' if the url is '/', otherwise a prefix
                    if (/\/$/.test(requestUri)) {
                        return 'summary.html';
                        console.log("--------------------------------------");
                        console.log("URL : ", 'summary.html');
                    } else {
                        var newUrl = requestUri.replace(/\?/g, '_');
                        newUrl = newUrl.replace(/\=/g, '_');
                        newUrl = newUrl.replace(/\//g, '-');
                        console.log("--------------------------------------");
                        console.log("URL : ", newUrl);
                        return newUrl;
                    }
                },
                //if you would rather not keep the script tags in the html snapshots
                //set `removeScripts` to true. It's false by default
                removeScripts: true,
                //set `removeLinkTags` to true. It's false by default
                removeLinkTags: false,
                //set `removeMetaTags` to true. It's false by default
                removeMetaTags: false,
                //Replace arbitrary parts of the html
                replaceStrings:[
                   {'/assets/': 'assets/'}
                ],
                // allow to add a custom attribute to the body
                bodyAttr: '',
                // List of all urls that should be fetched
                urls: [
                    "/",
                    "car",
                    "car/B88-1297",
                    "home",
                    "billings",
                    "discounts",
                    "claims",
                    "profile"
                ],
                // a list of cookies to be put into the phantomjs cookies jar for the visited page
                cookies: [

                ]
            }
        };
    };

     /**
     * html-snapshot for wcag tests
     * Warning : Package Phantom not available on Nexus !
     * Add those package in dependencies inside package.json then run 'npm install' :
     * "grunt-html-snapshot": "~0.6.1",
     */
    var hasRequiredDependencies = function(){
        var missingDependencies = [];
            
        for(var i = 0, l = dependencies.length; i < l; i++){
            var dependency = dependencies[i];
            if(!optionalDependencies[dependency]){
                errorMessage = 'Warning !\n Dependency not included in json file (in optionalDependencies) :\n ' + dependency + '.\n Check more informations in /grunt-tasks/htmlSnapshot.js !\n';
                missingDependencies.push(dependency);
            } else {
                try {
                    require.resolve(dependency);
                } catch(e){
                     try {
                        if(!grunt.file.exists('node_modules/'+dependency)){
                            missingDependencies.push(dependency);
                        }
                     } catch(e){
                         missingDependencies.push(dependency);
                     } 
                   
                } 
            }
        }

        if(missingDependencies.length !== 0){
            errorMessage = 'Warning !\n Dependencies missing list to run wcag task :\n ' + missingDependencies.join('\n ') + '.\n Check more informations in /grunt-tasks/htmlSnapshot.js !\n';
            return false;
        } else return true;
    }; 

    if(hasRequiredDependencies()){
        for(var i = 0, l = dependencies.length; i < l; i++){
            var dependency = dependencies[i];
            if (dependency.substring(0, 6) == "grunt-") {
                grunt.loadNpmTasks(dependency);
            }
        }
        return { 
            pc: getConfigs('policychange', 3001)
        };
    } else {
        return {
            error: true,
            errorMessage: errorMessage
        };  
    }  
};