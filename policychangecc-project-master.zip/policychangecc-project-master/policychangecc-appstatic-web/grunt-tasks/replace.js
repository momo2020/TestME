module.exports = function(grunt, globalConfig){
	grunt.loadNpmTasks('grunt-replace');
	return {
        dev: {
            options: {
              	patterns: [{
                  	match: "ENV",
                  	replacement: "DEV"
                },
                {
                  	match: "ROOT_PATH",
                  	replacement: ""
                },
                {
                    match: "API_REST_URL",
                    replacement: "http://localhost:9083"
                }
              ],
              verbose: false,
            },
            files: [
            	{
                	src: ['<%= globalConfig.dest %>/index.html'],
                	dest: '<%= globalConfig.dest %>/index.html'
              	},
                {
                  src: ['<%= globalConfig.dest %>/application/app.js'],
                  dest: '<%= globalConfig.dest %>/application/app.js'
                }
            ]
        },
        build: {
            options: {
              	patterns: [{
                  	match: "ENV",
                  	replacement: "BUILD"
                },
                {
                  	match: "ROOT_PATH",
                  	replacement: ""
                },
                {
                    match: "API_REST_URL",
                    replacement: ""
                }
              	],
              	verbose: false,
            },
            files: [
            	{
                	src: ['<%= globalConfig.dest %>/index.html'],
                	dest: '<%= globalConfig.dest %>/index.html'
              	},
                {
                  src: ['<%= globalConfig.dest %>/application/app.js'],
                  dest: '<%= globalConfig.dest %>/application/app.js'
                }
            ]
        },
        all: {
            options: {
              	patterns: [{
                  	match: "APP_DOMAIN",
                  	replacement: '<%= APP_DOMAIN %>'
                },
                {
                    match: "APP_NAME",
                    replacement: '<%= APP_NAME %>'
                },
                {
                  	match: "TIMESTAMP",
                  	replacement: new Date().getTime()
                }
              	],
              	verbose: false,
            },
            files: [
              	{
                	src: ['<%= globalConfig.dest %>/index.html'],
                	dest: '<%= globalConfig.dest %>/index.html'
              	}
            ]
        }
    };
};