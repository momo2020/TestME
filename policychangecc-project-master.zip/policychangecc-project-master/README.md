# policychangecc-project 
PolicyChange CC projects

[![Build Status](https://prod-jenkins-2020.iad.ca.inet/job/Intact/job/policychangecc-project/job/master/badge/icon)](https://prod-jenkins-2020.iad.ca.inet/job/Intact/job/policychangecc-project/job/master/)

## Built With

- [Jenkinsfile jobs](https://prod-jenkins-2020.iad.ca.inet/job/Intact/job/policychangecc-project/)
  - [pipeline activity](https://prod-jenkins-2020.iad.ca.inet/blue/organizations/jenkins/GitHub%2FIntact%2Fpolicychangecc-project/activity)
