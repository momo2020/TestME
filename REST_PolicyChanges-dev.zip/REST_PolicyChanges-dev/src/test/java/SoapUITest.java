import org.junit.Test;

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = { "/spring-config.xml" })
public class SoapUITest  {
	//@Test
	//public void test() throws Exception {
	public static void main(String[] args)
		System.out.println( "Process TEST !" );
		
		 try {
				String filepath = "c:\\tmp\\test.xml";
				DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
				Document doc = docBuilder.parse(filepath);

				// Get the root element
				Node company = doc.getFirstChild();

				// Get the staff element , it may not working if tag has spaces, or
				// whatever weird characters in front...it's better to use
				// getElementsByTagName() to get it directly.
				// Node staff = company.getFirstChild();

				// Get the staff element by tag name directly
				Node staff = doc.getElementsByTagName("staff").item(0);

				// update staff attribute
				NamedNodeMap attr = staff.getAttributes();
				Node nodeAttr = attr.getNamedItem("id");
				nodeAttr.setTextContent("2");

				// append a new node to staff
				Element age = doc.createElement("age");
				age.appendChild(doc.createTextNode("28"));
				staff.appendChild(age);

				// loop the staff child node
				NodeList list = staff.getChildNodes();

				for (int i = 0; i < list.getLength(); i++) {

		                   Node node = list.item(i);

				   // get the salary element, and update the value
				   if ("salary".equals(node.getNodeName())) {
					node.setTextContent("2000000");
				   }

		                   //remove firstname
				   if ("firstname".equals(node.getNodeName())) {
					staff.removeChild(node);
				   }

				}

				// write the content into xml file
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				DOMSource source = new DOMSource(doc);
				StreamResult result = new StreamResult(new File(filepath));
				transformer.transform(source, result);

				System.out.println("Done");

			   } catch (ParserConfigurationException pce) {
				pce.printStackTrace();
			   } catch (TransformerException tfe) {
				tfe.printStackTrace();
			   } catch (IOException ioe) {
				ioe.printStackTrace();
			   } catch (SAXException sae) {
				sae.printStackTrace();
			   }
			}
	}
 }