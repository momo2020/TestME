# Policy Changes [![Build Status](https://prod-jenkins-2020.iad.ca.inet/view/QA-IT/job/ITESTS_DAY_soa-tests.soapui-test-projects_REST_POLICY_CHANGE_DEV/badge/icon)](https://prod-jenkins-2020.iad.ca.inet/view/QA-IT/job/ITESTS_DAY_soa-tests.soapui-test-projects_REST_POLICY_CHANGE_DEV/)


Policy changes est une application pour permettant aux client de changer leur police automobile en ligne

<p align="left" valign="center">
  <img src="/img/policyChange_breadcrump.png" width="auto" height="auto"/>
</p>


## Applications et environnements testés

1. Ontario and Quebec  
 
 * [Released version : INTG-Z](https://intg-belairdirect-sso.iad.ca.inet/pc-z/pcspoe.html)
 * [Released version : UAT-Z](https://uat-belairdirect-sso.iad.ca.inet/pc-z/pcspoe.html)
 * [Dev version : INTG-U](https://intg-belairdirect-sso.iad.ca.inet/pc-u/pcspoe.html)
 * [Dev version : UAT-U](https://uat-belairdirect-sso.iad.ca.inet/pc-u/pcspoe.html)
 
## Initialisation

> todo

### Pré-requis

> todo

### Installation

> todo


#### Link to excel datasource used :
* [ON and QC](./5_Release_Dispatch_Workspace/Rest_Policy_Change_WorksPace/REST_ClientCentre_PolicyChange/Consumers/Belair/Data/)

#### Application links for SPOE page access :
* [UAT-Z](https://uat-belairdirect-sso.iad.ca.inet/pc-z/pcspoe.html)
* [UAT-U](https://uat-belairdirect-sso.iad.ca.inet/pc-u/pcspoe.html)
* [INTG-Z](https://intg-belairdirect-sso.iad.ca.inet/pc-z/pcspoe.html)
* [INTG-U](https://intg-belairdirect-sso.iad.ca.inet/pc-u/pcspoe.html)

#### Sharepoint extra documentations :
* [Documentations](https://teamsites.iad.ca.inet/ifc/MontrealADTests/Project%20%20Release%20Follow%20up/Forms/AllItems.aspx?RootFolder=%2Fifc%2FMontrealADTests%2FProject%20%20Release%20Follow%20up%2FSOA%2FPolicyChange%20_Documentation&FolderCTID=0x0120005720432FC8B86E42ACE0013C5D16A39C&View={7A4FA676-4144-4683-BCC3-25662BE23DE3})

## Remerciements

> todo

## Sources externes

> todo
