package quickquote.rest

import static java.util.Calendar.*
import com.eviware.soapui.model.testsuite.*
import groovy.json.JsonSlurper
import org.apache.log4j.Logger

/*
 *
 *
 */
class RequestHelper
{	
	def static propertyToIgnoreList = ["Request", "ResponseAsXml", "Response", "RawRequest", "Endpoint", "Domain", "Password", "Username", "environmentPath"]
	
	/*
	 *
	 *
	 */
	static boolean setResourceParameters(TestStep requestTestStep, String requestResourceParameters) {
		def urlParametersArray = requestResourceParameters.split('&')
		if (urlParametersArray.size() > 0) {
			for (parameter in urlParametersArray) {
				def keyValue = parameter.split('=')
				if (keyValue.size() == 2) {
					if (requestTestStep.hasProperty(keyValue[0])) {
						requestTestStep.setPropertyValue(keyValue[0], keyValue[1])
					}
				}
			}
			return true
		}
		return false
	}
	
	/*
	 *
	 *
	 */
	static String getCurrentYearAddYears(int years) {
		def now = new Date().toCalendar().get(YEAR)
		return (now + years).toString()
	}
	
	/*
	 *
	 *
	 */
	static String getCurrentYearAddMonth(int month) {
		def now = new Date().toCalendar().get(MONTH)
		return (now + month).toString()
	}
	
	/*
	 * Reset the default request resources to blank values for the next test cases.
	 * Insert the calls in the tear down script section of your test cases.
	 *
	 */
	 static boolean resetAllResourceToBlankValues(TestStep getRestTestStep) {
		if (getRestTestStep != null & getRestTestStep.getPropertyList().size() > 0) {
			for (property in getRestTestStep.getPropertyList()) {
				if (!propertyToIgnoreList.contains(property.getName())) {
					getRestTestStep.setPropertyValue(property.getName(), "")
				}
			}
			return true
		}
		return false
	 }
	 
	/*
	 * Returns all the resource parameters for a REST request.
	 * Call this method after all the resources has been updated first to get the latest updates.
	 *
	 */
	static String getAllResourceParameters(TestStep aRestTestStep) {
		if (aRestTestStep != null & aRestTestStep.getPropertyList().size() > 0) {
			String resourceParameters = ""
			for (property in aRestTestStep.getPropertyList()) {
				if (!propertyToIgnoreList.contains(property.getName())) {
					resourceParameters = property.getName() + "=" + property.getValue() + "&" + resourceParameters
				}
			}
			return resourceParameters
		}
		return ""
	}
	
	/*
	 * Return the resources input parameters merged with REST response and the the REST input resources for the next REST step.
	 *
	 */
	static String mergeRequestInputResourcesWithTheResponse(String getResponseJason, TestStep getRequest) {
		if (getResponseJason != null & getResponseJason != "" & getRequest != null & getRequest.getPropertyList().size() > 0) {
			def slurper = new JsonSlurper()
			def result = slurper.parseText(getResponseJason)
			int objectCount = result.rowsValueBO.size() - 1
			// Merge the new response values to the request input resources.
			String key = ""
			String value = ""
			for (object in 0..objectCount) {
				key = result.rowsValueBO[object].value
				value = result.rowsValueBO[object].label
				if (getRequest.hasProperty(key)) {
					getRequest.setPropertyValue(key, value)
				}
			}
			// Build the resources request url.
			return getAllResourceParameters(getRequest)
		}
		return ""
	}
}