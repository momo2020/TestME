package com.intact.soapui.policychange.rest

class CoverageDTO {
	String code
	String description
   	String selected
   	String selectedAmount
   	String mode
   	String section
   	String sectionCode
   	String sequence
	String type
	def values
}