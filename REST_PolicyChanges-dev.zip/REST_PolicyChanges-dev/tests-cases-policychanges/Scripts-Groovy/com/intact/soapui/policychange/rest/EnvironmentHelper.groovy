package quickquote.rest

import com.eviware.soapui.impl.wsdl.WsdlProjectPro
import com.eviware.soapui.impl.wsdl.panels.support.MockTestRunner
import com.eviware.soapui.model.testsuite.*
import com.eviware.soapui.model.testcase.*

/*
 *
 *
 */
class EnvironmentHelper
{	
    public static final String COMPANY_NAME_BELAIR = "belair"
	public static final String COMPANY_NAME_INTACT = "intact"
	
	
	/*
	 * Will set the company environment for the default instance environment.
	 *
	 */
	static boolean setEnvironment(String pCompany, TestRunner pTestRunner) {
		def activeEnvironment = pTestRunner.getTestCase().getTestSuite().getProject().getActiveEnvironment().getName()
		def environmentTokens = activeEnvironment.split('-')
		if (environmentTokens.size() == 3) {
			String company =  environmentTokens[0]
			String environment =  environmentTokens[1]
			String instance =  environmentTokens[2]
			pTestRunner.testCase.testSuite.project.setActiveEnvironment(pCompany + "-" + environment + "-" + instance)
			return true
		}
		return false
	}
	
	/*
	 * Will set the company environment for the default instance environment.
	 *
	 */
	static boolean setEnvironment(String pCompany, MockTestRunner pTestRunner) {
		def activeEnvironment = pTestRunner.testCase.testSuite.project.getActiveEnvironment().getName()
		def environmentTokens = activeEnvironment.split('-')
		if (environmentTokens.size() == 3) {
			String company =  environmentTokens[0]
			String environment =  environmentTokens[1]
			String instance =  environmentTokens[2]
			pTestRunner.testCase.testSuite.project.setActiveEnvironment(pCompany + "-" + environment + "-" + instance)
			return true
		}
		return false
	}
}