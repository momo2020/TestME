class JasonGroovyBean{
		//quoteDetails
		def policyVersionId
        def noHitState
        def agreementNumber
        def monthlyPriceDisplayed
        def automeritDiscount
        def automeritDiscountDisplay
		
		//
		 def insuredContinuously
         def  durationOfInsuranceTerm
         def  city":"MONTREAL
         def  creditScoreState
         def  fullTimeStudentInd
         def  retiredInd
         def  obtainedGorG2LicenseLastYearInd
         def  groupCode
         def  workSector
         def  occupation
         def  yearsAtThisAddress
         def  universityDegreeInd
         def  multiVehicleDiscount
         def  homeAndAutoInd
         def  maritalStatus
         def  minorInfractionCount
         def  majorInfractionCount
         def  lossesYearsInd
         def  driverTrainingInd
         def  dateOfbirthDay
         def  dateOfbirthMonth
         def  dateOfbirthYear
         def  driverLicenseClass
         def  driverLicenseType
         def  firstName
         def  gender
         def  lastName
         def  licenseNumber
         def  postalCode
		



}



