
# Groovy scripts

Groovy scripts with various functionality

To use a script, copy-paste the groovy code in the Jenkins console and press execute button.

https://prod-jenkins-2020.iad.ca.inet/script


