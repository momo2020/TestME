import hudson.maven.MavenModuleSet
import jenkins.model.*
import hudson.plugins.git.*
import hudson.plugins.git.extensions.*
import hudson.plugins.git.browser.*

viewName = "all"
all = Jenkins.instance.getView(viewName)

mavenJobs = all.items.findAll { item -> item instanceof MavenModuleSet }

jobToModifyList = ["BUILD_DAY_soa.bi.entity.client-analytical-service.client-analytical-service-webservice_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.bi.entity.contract-analytical-service.contract-analytical-service-webservice_CONTACT_D16_DEF",
                   "BUILD_DAY_soa-resources.client.entity.credit-score-service.credit-score-service-resources_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.client.entity.credit-score-service.credit-score-service-message_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.client.entity.driving-record-service.driving-record-webservice_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.distributor.entity.distributor-information-service.dis-webservice_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.finance.entity.corporate-information-service.corporate-information-service-consumer_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.finance.entity.corporate-information-service.corporate-information-service-webservice_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.finance.entity.product-distribution-service.product-distribution-service-webservice_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.plpolicy.business.contractbilling-service.contractbilling-service-webservice_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.plpolicy.business.contract-distributor-service.cdis-webservice_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.plpolicy.business.contract-verification-service.cvs-consumer_CONTACT_D16_DEF",
                   "BUILD_DAY_soa-resources.plpolicy.entity.contract-repository-service.crs-resources_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.plpolicy.entity.contract-repository-service.crs-message_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.plpolicy.entity.contract-repository-service.crs-webservice_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.plpolicy.utility.message-authority-service.message-authority-service-webservice_CONTACT_D16_DEF",
                   "BUILD_DAY_soa-resources.utility.entity.b2b-message-repository-service.b2b-message-repository-service-resources_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.utility.entity.b2b-message-repository-service.b2b-message-repository-message_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.utility.entity.b2b-message-repository-service.b2b-message-repository-service-consumer_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.utility.entity.b2b-message-repository-service.b2b-message-repository-webservice_CONTACT_D16_DEF",
                   "BUILD_DAY_soa-resources.utility.entity.geographical-info-service.geographical-info-service-resources_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.utility.entity.geographical-info-service.geographical-info-service-consumer_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.utility.entity.geographical-info-service.geographical-info-service-message_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.utility.entity.geographical-info-service.geographical-info-service-webservice_CONTACT_D16_DEF",
                   "BUILD_DAY_soa-resources.utility.system-accessor-service.system-accessor-service-resources_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.utility.system-accessor-service.system-accessor-service-consumer_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.utility.system-accessor-service.system-accessor-service-message_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.utility.system-accessor-service.system-accessor-webservice_CONTACT_D16_DEF",
                   "BUILD_DAY_soa.ws-common-utils_CONTACT_D16_DEF",
                   "BUILD_DAY_soa-resources.ws-commons-message-resources_CONTACT_D16_DEF"] as Set

String modifyGitUrl(String name) {
    index = name.lastIndexOf(".")
    artifactIdSubStr = name.substring(index + 1)
    indexUnderscore = artifactIdSubStr.indexOf("_")
    artifactId = artifactIdSubStr.substring(0, indexUnderscore)
    return "git@githubifc.iad.ca.inet:SOA/" + artifactId + ".git"
}

for (job in mavenJobs) {
    if (job.scm != null && job.scm instanceof com.ibm.team.build.internal.hjplugin.RTCScm) {
        if (job.displayName in jobToModifyList) {
            println "Job found :" + job.displayName
            println "SCM :" + job.getScm()
            println "Regex : " + modifyGitUrl(job.displayName)
			
			ParametersDefinitionProperty parameters = job.getProperty(ParametersDefinitionProperty.class)
            if (parameters == null) {
              parameters = new ParametersDefinitionProperty(new ArrayList<ParameterDefinition>()) 
              job.addProperty(parameters)
            }
			if (parameters.getParameterDefinition("GIT_BRANCH") == null) {
				ParameterDefinition gitBranchParam = new StringParameterDefinition("GIT_BRANCH", "dev-d16") 
				parameters.getParameterDefinitions().add(gitBranchParam)
			}

            String credentialsId = "01bd3005-0c2e-4a2e-a475-3e009bb25478"
            List<BranchSpec> branches = [new BranchSpec("\${GIT_BRANCH}")]
            Boolean doGenerateSubmoduleConfigurations = false
            List<SubmoduleConfig> emptySubmoduleConfigList = []
            List<GitSCMExtension> emptyExtensionsList = []

            def List<UserRemoteConfig> newUserRemoteConfigs = [new UserRemoteConfig(modifyGitUrl(job.displayName), "", "", credentialsId)]

            def newScm = new GitSCM(newUserRemoteConfigs, branches, doGenerateSubmoduleConfigurations,
                    emptySubmoduleConfigList, new GithubWeb(""), "", emptyExtensionsList)

            job.setScm(newScm)
			job.setRootPOM("pom.xml")
           
            job.save()
        }
    }
}

//println "list of methods"
//println hudson.maven.MavenModuleSet.metaClass.methods*.name.sort().unique()

