import jenkins.model.*

ValueToMatch = 'D11'

def matchedJobs = Jenkins.instance.items.findAll { p -> p.name.contains(ValueToMatch)  }

matchedJobs.each { job ->
    println job.name
    //job.delete()
}