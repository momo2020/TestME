package intact.jenkins.groovy

import java.text.SimpleDateFormat;

SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
Calendar tomorrowLimit = Calendar.getInstance();
tomorrowLimit.set(Calendar.HOUR_OF_DAY, 6);
tomorrowLimit.set(Calendar.MINUTE, 0);
tomorrowLimit.add(Calendar.DAY_OF_MONTH, 1);
Calendar cal=Calendar.getInstance();
ArrayList<String> choices = [];
cal.set(Calendar.MINUTE, (5*(Math.ceil(Math.abs(cal.get(Calendar.MINUTE)/5)))+5).intValue());
choices.add(formatter.format(cal.getTime()));
choices.add('now');
int count = 0;
while (cal.getTime()<tomorrowLimit.getTime()){
    cal.add(Calendar.MINUTE, 5);
    choices.add(formatter.format(cal.getTime()));
    count++;
}
println(choices);