package intact.jenkins.groovy.notifications;

import groovy.json.JsonSlurper

def jsonSlurper = new JsonSlurper()
def json = jsonSlurper.parseText('[\n' +
        '    {\n' +
        '      "name": "aggregationservice_soa",\n' +
        '      "version": "6.2.1.1.0.0-SNAPSHOT",\n' +
        '      "overwrite": false,\n' +
        '      "environmentLetter": "x"\n' +
        '    },\n' +
        '    {\n' +
        '      "name": "addressservice_soa",\n' +
        '      "version": "6.2.1.1.0.0-SNAPSHOT",\n' +
        '      "overwrite": false,\n' +
        '      "environmentLetter": "x"\n' +
        '    },\n' +
        '    {\n' +
        '      "name": "transformationservice_soa",\n' +
        '      "version": "6.2.0.1.0.0-SNAPSHOT",\n' +
        '      "overwrite": false,\n' +
        '      "environmentLetter": "x"\n' +
        '    }\n' +
        '  ]')
String deploymentList = '';
json.each {
    deploymentList = deploymentList + it.name +'-'+it.environmentLetter+': '+it.version + '\n'
}
return deploymentList.substring(0, deploymentList.length()-1);