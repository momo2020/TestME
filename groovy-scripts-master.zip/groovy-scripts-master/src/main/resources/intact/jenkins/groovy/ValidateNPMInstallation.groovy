package intact.jenkins.groovy;
import groovy.json.JsonSlurper;

def packageFilePath = System.getenv("APPDATA")+File.separator+'npm'+File.separator+'node_modules'+File.separator+packageName+File.separator+'package.json'
def jsonSlurper = new JsonSlurper()
def Reader reader = (new File(packageFilePath)).newReader('UTF-8');
def packageDescriptor = jsonSlurper.parse(reader);
reader.close()
if (targetVersion == packageDescriptor.version){
    println('NPM Package '+packageName+' is up to date.');
} else {
    executeNPM(['install','-g',packageName+'@'+targetVersion] as String[]);
}

private def executeNPM(String [] npmArgs) {
    def ArrayList<String> npmCommand = new ArrayList<String>();
    npmCommand.add(System.getenv('BASE')+File.separator+'tools'+File.separator+'jenkins.plugins.nodejs.tools.NodeJSInstallation'+File.separator+'nodejs-4.2.1-x64'+File.separator+'bin'+File.separator+'npm.cmd');
    npmCommand.addAll(npmArgs);
    println 'Executing: '+npmCommand.join(' ');
    def processBuilder = new ProcessBuilder(npmCommand.toArray() as String[])
    Map<String, String> env = processBuilder.environment()
    env.putAll(System.getenv())
    if (env.get('PATH') == null && env.get('Path') != null){
        env.put('PATH', env.get('Path'))
    }
    env.put('NPM_CONFIG_CA', '-----BEGIN CERTIFICATE-----\nMIIDzzCCAregAwIBAgIQJV20a6hn5LRD63VNm4qcnDANBgkqhkiG9w0BAQUFADBR\nMRQwEgYKCZImiZPyLGQBGRYEaW5ldDESMBAGCgmSJomT8ixkARkWAmNhMRMwEQYK\nCZImiZPyLGQBGRYDaWFkMRAwDgYDVQQDEwdpUm9vdENBMB4XDTA5MTAyMDE5NDMw\nOVoXDTI5MTAyMDE5NTMwOFowUTEUMBIGCgmSJomT8ixkARkWBGluZXQxEjAQBgoJ\nkiaJk/IsZAEZFgJjYTETMBEGCgmSJomT8ixkARkWA2lhZDEQMA4GA1UEAxMHaVJv\nb3RDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJpVqBd+6htdlhIn\nNPC/vc/AMGTIt2pkTAjnS+17lpgQgN+81fIPxc2G8q8UG8rWTzBsq2GouAQsGpn4\nCYmNXejwzrJQW8YhE1kbYxlY6uH/OduVglyK8E8vR8yb8JXCwTiWBuX66iBBb+LT\nUeYvsVDz/bbhg5rQoJrBcgDkT7roQAALfMIosxIXyBwboDsaD4eRHyhOBrdprEjm\nThjfHEvx0RClW+C+7GqM7RkN6WLvB/9eeuoz8U92RqtJFK5sBrFte8csKaQ5xgjw\nbYD17hsKzPWatNl9O18EsfB9ovU0NsRMp0K5ODUdYH6HNyKPdSHY+qXifeJWQQrm\nrp0jIScCAwEAAaOBojCBnzALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAd\nBgNVHQ4EFgQUR7HE7pRHqnWIp0ExZnWuJ8VP0SAwEAYJKwYBBAGCNxUBBAMCAQAw\nTgYDVR0gBEcwRTBDBgsrBgEEAYKIfQoKATA0MDIGCCsGAQUFBwIBFiZodHRwOi8v\naWNlcnRzcnYuaWFkLmNhLmluZXQvY2VydHBvbGljeTANBgkqhkiG9w0BAQUFAAOC\nAQEAlH7gmpQbW1ix+lRLYEzUeVrOzvpK5ggBExX5/vWLKzxGUnKlsi6vmJ0tj7Bj\njct2hJ8oMIhhNSkjVOP1FlVbanVYKd07vG+XQDMo8IqwrocWEOSLERiC8umOnVQG\n7q6oR0tZp0vEt7D0sVRILRFdQkIz8Ak/NwQycmExC3OiM/OW8wPryR9PW8Lrkc/h\n1ANsWWY/q19RX8MSYGe6UJNPM0HBl9PLF0iPtI6gleDzsVbeXUTcdhW9iZvHShh2\n5DsS+vKupcQDHILGRPqxOQvJI2eVZbqV47T5UdlCjDJaWDCmr2Mo4bRJruakCLgA\nID5AHb9ypryfZXSlNmH61P5VcQ==\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nMIIFzzCCBLegAwIBAgIKYSMfdAAAAAAABjANBgkqhkiG9w0BAQUFADBRMRQwEgYK\nCZImiZPyLGQBGRYEaW5ldDESMBAGCgmSJomT8ixkARkWAmNhMRMwEQYKCZImiZPy\nLGQBGRYDaWFkMRAwDgYDVQQDEwdpUm9vdENBMB4XDTA5MTIwMTE5MTEwOVoXDTE5\nMTIwMTE5MjEwOVowUDEUMBIGCgmSJomT8ixkARkWBGluZXQxEjAQBgoJkiaJk/Is\nZAEZFgJjYTETMBEGCgmSJomT8ixkARkWA2lhZDEPMA0GA1UEAxMGaVN1YkNBMIIB\nIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA3grRzEpRmeaGYDXU8ilfkCsV\nRoZxBdBWwFzcPp6nr39A3DJ7HZfvws8iGJAdm6R0lImpReWsRUpBW1v2SE8SqaAA\n3NjhkyvboFGwy1Tx18HUfDUl1emU8QpOMddGtbz4tjNw521QZ4KmaXk33FnGO6Jx\n9Zr5aYQYfJyymsZj8izW9YIaQqUDTLg1iZX76D8FXdkr8nJ+Fetohsn/f2QJKAu7\nn78jThhooHe9+/Zb8EiIaKHMvjwpfhxsPOmMun2oSaPVspuhr5bEMx+5I3Enddwn\nSt4EL2SYN6tM1Evw8CXCkBxDfXg24M/vvhQVZbJBSrUl7/hL/iG3Q1h/pXjKNQID\nAQABo4ICqDCCAqQwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUGHYBFBF4x5Ua\nkB6cqzticaFm67UwCwYDVR0PBAQDAgGGMBIGCSsGAQQBgjcVAQQFAgMDAAQwIwYJ\nKwYBBAGCNxUCBBYEFOauzuYN+rw4VZvedq7jPlscoBA1MBkGCSsGAQQBgjcUAgQM\nHgoAUwB1AGIAQwBBMB8GA1UdIwQYMBaAFEexxO6UR6p1iKdBMWZ1rifFT9EgMIH3\nBgNVHR8Ege8wgewwgemggeaggeOGgaxsZGFwOi8vL0NOPWlSb290Q0EsQ049U1RI\nQTMxNTcxLENOPUNEUCxDTj1QdWJsaWMlMjBLZXklMjBTZXJ2aWNlcyxDTj1TZXJ2\naWNlcyxDTj1Db25maWd1cmF0aW9uLERDPWNhLERDPWluZXQ/Y2VydGlmaWNhdGVS\nZXZvY2F0aW9uTGlzdD9iYXNlP29iamVjdENsYXNzPWNSTERpc3RyaWJ1dGlvblBv\naW50hjJodHRwOi8vaWNlcnRzcnYuaWFkLmNhLmluZXQvQ2VydEVucm9sbC9pUm9v\ndENBLmNybDCB9QYIKwYBBQUHAQEEgegwgeUwgaIGCCsGAQUFBzAChoGVbGRhcDov\nLy9DTj1pUm9vdENBLENOPUFJQSxDTj1QdWJsaWMlMjBLZXklMjBTZXJ2aWNlcyxD\nTj1TZXJ2aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPWNhLERDPWluZXQ/Y0FDZXJ0\naWZpY2F0ZT9iYXNlP29iamVjdENsYXNzPWNlcnRpZmljYXRpb25BdXRob3JpdHkw\nPgYIKwYBBQUHMAKGMmh0dHA6Ly9pY2VydHNydi5pYWQuY2EuaW5ldC9DZXJ0RW5y\nb2xsL2lSb290Q0EuY3J0MA0GCSqGSIb3DQEBBQUAA4IBAQBAbIq8MoPP3wseWxdr\nJj/zn0+Fp0z1VMoQDyJTtlVezyGvW+EriGkbOpGvjwiPRcF8p6LoWERwuwCjfpys\nHHAmCjaBan8uBwCE59J15CnAZmQSI59CIcnaJWKW/PO2XexDuXi4XXBC2UcoaIxT\nFJlmcCYTN7Lyb8Rrf0LuUkdUj/5+pXIzYDacEz+IHd8sfKZ2z5mvobQmlR6lMzks\n3grlXEx+oOhGTHLh2e2JN15CChlfx4wkCI0/a1iywpqq9c8726Sb5Aq8W8kLCAjV\nD5lKGDFFryMyRKVNTskfY4MFTQBn9fu4zKIXjBD5CMBPY03xfijSQ78JLySKiUUN\nMpdK\n-----END CERTIFICATE-----');
    env.put('NPM_CONFIG_REGISTRY', 'https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/content/groups/npm-public/')
    env.put('NPM_CONFIG_COLOR', 'false')
    def process = processBuilder.redirectErrorStream(true).start()
    process.inputStream.eachLine {println it}
    process.waitFor();
    return process.exitValue()
}