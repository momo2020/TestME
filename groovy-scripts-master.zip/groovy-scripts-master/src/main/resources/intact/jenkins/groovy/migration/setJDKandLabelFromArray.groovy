import hudson.maven.*
import hudson.model.*
import jenkins.model.*

/**
 * Used to modify the Goals and Options from the list of builds
 * 
 * @author raudet
 */
List<MavenModuleSet> jobs = Jenkins.instance.items.findAll { item -> containedInBuildInfoToExport(item.name) }

//PLZ TURN ME ON AND OFF
setJDK(jobs)
setNode(jobs)

def containedInBuildInfoToExport(String buildName){
	// COPY buildInfosToExport.json from jenkins-migration HERE
	String[] buildInfoToExports = [
		  "BUILD_DAY_soa-external.dmti.recognition-service-consumer_MASTER_DEF",
		  "BUILD_DAY_soa-resources.client-claims-history-service-resources_MASTER_DEF",
		  "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-message_MASTER_DEF",
		  "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-webservice_FIX_DEF",
		  "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-consumer_MASTER_DEF",
		  "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-webservice_MASTER_DEF"
	];

	for (String buildInfoToExport in buildInfoToExports){
		if (buildName.contains(buildInfoToExport)){
			return true;
		}
	}
	return false;
}

def setJDK(List<MavenModuleSet> items) {
	println('UPDATING ' + items.size() + ' jobs')
	JDK java7System = Jenkins.instance.getJDK("java7-system");
	for (MavenModuleSet item in items) {
		item.setJDK(java7System);
		println(item.getJDK());
		//item.save();
	}
}

def setNode(List<MavenModuleSet> items) {
	Label mtl2020;
	for (Label label in Jenkins.instance.getLabels()){
		if ("mtl2020-main" == label.getName()){
			mtl2020 = label;
		}
	}
	for (MavenModuleSet item in items) {
		item.setAssignedLabel(mtl2020);
		println(item.getAssignedLabel());
		//item.save();
	}
}