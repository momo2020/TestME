package intact.jenkins.groovy

import java.util.*
import hudson.maven.*
import jenkins.model.*;
import java.util.regex.*;
import groovy.json.*;

List<MavenModuleSet> jobs = Jenkins.instance.items.findAll { item -> item instanceof MavenModuleSet }
def missingSnapshotsMap = [:];
def missingReleasesMap = [:];
for (MavenModuleSet job : jobs) {
    if (job.getLastBuild() != null){
        List<String> lines = job.getLastBuild().getLogReader().readLines();
        Pattern missingDependency = Pattern.compile('Could not find artifact (.*)? in nexus.*');
        Pattern isSnapshot = Pattern.compile('-SNAPSHOT$');
        for (String line: lines){
            Matcher match = missingDependency.matcher(line);
            if (match.find()){
                if (isSnapshot.matcher(match.group(1)).find()){
                    missingSnapshotsMap[job.getName()] = match.group(1);
                } else {
                    missingReleasesMap[job.getName()] = match.group(1);
                }
            }
        }
    }
}
Set<String> uniques = new HashSet<>();
for (Map.Entry<String, String> entry : missingSnapshotsMap.entrySet())
{
    uniques.add(entry.getValue());
}
println("Number of projects to fix: "+missingSnapshotsMap.size())
println("Missing unique dependencies: "+uniques.size())
println((new JsonBuilder(uniques)).toPrettyString());
println('=== All missing snapshot projects')
println((new JsonBuilder(missingSnapshotsMap)).toPrettyString());
println('=== All missing releases projects')
println((new JsonBuilder(missingReleasesMap)).toPrettyString());