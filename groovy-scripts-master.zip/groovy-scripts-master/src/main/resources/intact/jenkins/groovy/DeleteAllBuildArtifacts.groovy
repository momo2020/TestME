import hudson.maven.MavenModuleSet

label = "mtl2020-main"
topView = "Montreal 2020"
 
jenkins = Jenkins.instance

views = jenkins.getView(topView).views

printer = new PrintWriter("F:/Data/tmp/batch-delete-artifacts-03.txt")

for(view in views){
	printer.println ""
	println "Processing view \"${view.name}\""
	printer.println "Processing view \"${view.name}\""
    printer.flush()
	jobs = view.items.findAll { item -> item instanceof MavenModuleSet && item.assignedLabelString == label }
	for(job in jobs) {
		for(build in job.builds) {
  			modules = build.moduleBuilds
    		for(key in modules.keySet()) {
      			for(moduleBuild in modules.get(key)) {
      				if(moduleBuild.hasArtifacts) {
      					moduleBuild.deleteArtifacts()
	      				println "\tDeleted artifacts in ${job.displayName} [${moduleBuild.number}]"
    	  				printer.println "\tDeleted artifacts in ${job.displayName} [${moduleBuild.number}]"
      					printer.flush()
      				}
      			}
    		}
    	}
	}
}

printer.println "Done"
printer.flush()
println "Done"
