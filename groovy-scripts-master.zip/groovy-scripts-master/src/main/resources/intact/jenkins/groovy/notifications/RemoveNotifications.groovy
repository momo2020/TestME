package intact.jenkins.groovy.notifications

import hudson.model.FreeStyleProject
import hudson.tasks.Mailer
import jenkins.model.*
/**
 * thbrown: 2016-04-28.
 */
List<FreeStyleProject> soapUIJobs = Jenkins.instance.items.findAll { item -> item.name.contains('soapui-test-projects') && item instanceof FreeStyleProject}

for(item in soapUIJobs) {
    println("removing mailer for job $item.name")
    Mailer mailer = new Mailer()
    item.publishersList.remove(mailer.descriptor)
}