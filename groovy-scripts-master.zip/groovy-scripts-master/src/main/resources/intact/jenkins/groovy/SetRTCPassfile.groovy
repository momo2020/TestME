import hudson.maven.MavenModuleSet
  
viewName = "All"

all = Jenkins.instance.getView(viewName)
  
mavenJobs = all.items.findAll { item -> item instanceof MavenModuleSet}

files = [] as Set
foundJobs = [] as Set
notFoundJobs = [] as Set
passfile = "F:\\Data\\var\\rtc-credentials\\pass-build-integration.txt"

for(job in mavenJobs) {
  if(job.scm != null && job.scm instanceof com.ibm.team.build.internal.hjplugin.RTCScm && job.scm.overrideGlobal ) {
  	if(job.displayName != "BUILD_DAY_test.test-project-prod_MASTER_DEF") {
  		continue
  	}
    println "${job.displayName}\t${job.scm.passwordFile}"
    files.add(job.scm.passwordFile)
    foundJobs.add(job)
    job.scm.setPasswordFile(passfile)
    job.save()
    
  }
  else {
  	notFoundJobs.add(job)
  }
}

println files
println foundJobs.size()
println notFoundJobs.size()

