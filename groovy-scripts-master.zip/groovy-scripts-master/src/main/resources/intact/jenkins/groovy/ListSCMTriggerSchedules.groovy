package intact.jenkins.groovy

import hudson.maven.MavenModuleSet
import jenkins.model.*
import java.util.HashSet
import java.util.HashMap

viewName = "All"

all = Jenkins.instance.getView(viewName).items.findAll { job -> job.triggers.size() > 0 }

schedules = new HashMap()
   
for(job in all) {
    spec = job.triggers.values().toArray()[0].spec
    if(schedules.keySet().contains(spec)) {
    	n = schedules.get(spec)
    	schedules.put(spec, n + 1)
    }
    else
    {
        schedules.put(spec, 1)
    }
}
for(schedule in schedules) {
  println "------------------------" 
  println schedule.key
  println "Total for schedule = ${schedule.value}" 
}
