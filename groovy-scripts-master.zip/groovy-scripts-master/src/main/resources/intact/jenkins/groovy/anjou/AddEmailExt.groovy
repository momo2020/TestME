#!Groovy
package intact.jenkins.groovy

import jenkins.model.*

viewName = "Anjou"

views = Jenkins.instance.getView(viewName).views

for(view in views) {
  println "View: ${view.displayName}"
  projects = view.items

  for (project in projects) {
    if(project instanceof hudson.maven.MavenModuleSet || project instanceof FreeStyleProject) {
      println "project:" + project.getFullName()
      def notif = new hudson.plugins.emailext.ExtendedEmailPublisher()
      notif.recipientList = "frederic.fortin@intact.net,serge.nassar@intact.net"
      notif.contentType = "text/html"
      notif.defaultSubject = "\$DEFAULT_SUBJECT"
      notif.defaultContent = '\${CHANGES_SINCE_LAST_SUCCESS, reverse=true, format="<b>Changes for Build #%n</b><br>%c<br>", changesFormat="<br>[<a href=\'${JENKINS_URL}/user/%a/builds\'>%a</a>] - (%r) %p<br> %m<br>"}'
      notif.replyTo = "\$DEFAULT_REPLYTO"

      def trigger = hudson.plugins.emailext.plugins.trigger.FailureTrigger.createDefault()
      notif.configuredTriggers = [trigger]

      for (publisher in project.publishersList) {
        if (publisher instanceof hudson.plugins.emailext.ExtendedEmailPublisher) {
          project.publishersList.remove(publisher)
        }
      }
      project.publishersList.replace(notif)
    }
  }
}
