import hudson.maven.MavenModuleSet
import hudson.plugins.sonar.SonarBuildWrapper
import hudson.plugins.sonar.SonarPublisher
import hudson.plugins.sonar.SonarRunnerBuilder
import jenkins.model.Jenkins

ArrayList<String> projectNames = new ArrayList<String>()
Jenkins.instance.items.findAll { item ->
    ArrayList<String> states = new ArrayList<String>()
    if (item instanceof MavenModuleSet && item.name != 'BUILD_DAY_RTC_SONAR_MASTER_TEST_DEF' && item.name != 'QUICKQUOTE_FRONTEND_INTACT_JUNIT_COVERAGE'){
        if (item.getBuildWrappersList().find{
            it instanceof SonarBuildWrapper
        } != null){
            states.add('prepareEnv')
        }
        if (item.getPublishers().find{
            it instanceof SonarPublisher
        } != null){
            states.add('publisher')
        }
        if (item.getPostbuilders().find{
            it instanceof SonarRunnerBuilder
        } != null){
            states.add('postBuild')
        }
        if (states.size()>0){
            projectNames.push(item.name+': '+states.join(', '))
        }
    }
}
return projectNames.size()+'\n'+projectNames.join('\n')