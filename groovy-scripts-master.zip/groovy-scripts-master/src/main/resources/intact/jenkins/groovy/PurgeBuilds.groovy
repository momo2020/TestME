import hudson.maven.MavenModuleSet
import java.io.PrintWriter

printer = new PrintWriter("F:/Data/tmp/batch-logrotate-01.txt")

jobs = Jenkins.instance.items.findAll{ item -> item instanceof MavenModuleSet }

for(job in jobs) { 
  try {
    printer.println "Rotation ${job.displayName}"
    printer.flush()
  	job.logRotate() 
  }
  catch(e) {
    printer.println "Exception ${job.displayName}"
    printer.flush()
  }

}

printer.println "Done"
printer.close()