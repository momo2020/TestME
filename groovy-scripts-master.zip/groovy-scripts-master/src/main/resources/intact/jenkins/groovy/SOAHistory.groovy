import hudson.maven.MavenModuleSet
import hudson.tasks.LogRotator
import org.jvnet.hudson.plugins.m2release.M2ReleaseBuildWrapper

jenkins = Jenkins.instance
soaView = jenkins.getView("Montreal 2020").getView("Day Montreal 2020")

soaJobs = soaView.items.findAll { item -> item instanceof MavenModuleSet }

for(job in soaJobs) {

	println "\tProcessing job ${job.displayName}"

    wrappers     = job.buildWrappersList
    
    oldM2Release = wrappers.get(M2ReleaseBuildWrapper)
    
    if(oldM2Release == null) {
    	println "\t\tNo release configuration"
    	continue
    }
    
    oldWetGoals  = oldM2Release.releaseGoals
    oldDryGoals  = oldM2Release.dryRunGoals
    
    println "\t\tOld wet goals: ${oldWetGoals}.\n\t\tOld dry goals: ${oldDryGoals}"
    
    oldWetGoalsClean = oldWetGoals.replaceAll(" *-PskipReleasePrepareTests", "")
    newWetGoals = "${oldWetGoalsClean} -PskipReleasePrepareTests"
    newDryGoals = oldDryGoals
    
    newM2Release = new M2ReleaseBuildWrapper(newWetGoals, oldDryGoals, false, false, false, 'IS_M2RELEASEBUILD', null, null, 1)
    
    println "\t\tNew wet goals: ${newWetGoals}.\n\t\tNew dry goals: ${oldDryGoals}"
    
    wrappers.replace(newM2Release)
    
    job.save()
}

println "Done!"
