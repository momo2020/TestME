import hudson.maven.MavenModuleSet
import hudson.tasks.LogRotator
 
jenkins = Jenkins.instance

views = jenkins.getView("Montreal 2020").views

for(view in views) {
	println ""
	println "Processing view \"${view.name}\""
	jobs = view.items.findAll { item -> item instanceof MavenModuleSet}
	for(job in jobs) {
		println "${job.name}"
		job.setIsArchivingDisabled(true)
		job.save()
	}
}

println "Done"
