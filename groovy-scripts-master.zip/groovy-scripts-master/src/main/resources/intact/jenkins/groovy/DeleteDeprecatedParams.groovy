import hudson.maven.MavenModuleSet
import hudson.model.ParameterDefinition
import hudson.model.ParametersDefinitionProperty
import hudson.model.TopLevelItem
import jenkins.model.Jenkins
import org.jenkinsci.plugins.conditionalbuildstep.ConditionalBuilder
import org.jenkinsci.plugins.envinject.EnvInjectBuildWrapper
import org.jenkinsci.plugins.envinject.EnvInjectJobProperty

String[] deprecatedParams = ['BuildAndDeploy','Environment_Deploy', 'Schedule_Deploy']
ArrayList<String> report = new ArrayList<String>()
Jenkins.instance.items.each {TopLevelItem mavenJob ->
    if (mavenJob instanceof MavenModuleSet) {
        ParametersDefinitionProperty parameters = mavenJob.getProperty(ParametersDefinitionProperty.class)
        ArrayList<ParameterDefinition> parameterToDelete = new ArrayList<ParameterDefinition>()
        if(parameters != null) {
            for(int i=0; i<parameters.getParameterDefinitions().size(); i++) {
                deprecatedParams.each{deprecatedParam ->
                    if (parameters.getParameterDefinitions().get(i).name == deprecatedParam) {
                        parameterToDelete.add(parameters.getParameterDefinitions().get(i))
                    }
                }
            }
            if (parameterToDelete.size() == deprecatedParams.length){
                ArrayList<String> toDelete = ['parameters']
                //remove call
                parameterToDelete.each {parameters.getParameterDefinitions().remove(it)}
                EnvInjectJobProperty envInjectProperties = mavenJob.getProperty(EnvInjectJobProperty.class)
                if (envInjectProperties != null && envInjectProperties.on &&
                        envInjectProperties.info.propertiesContent =~ /Service_Deploy=.*?\nService_Path_Name=.*?\nService_Path_EAR=.*?/){
                    toDelete.add('envinject props')
                    //remove call
                    envInjectProperties.setOn(false)
                }
                if (mavenJob.getBuildWrappersList().find {it instanceof EnvInjectBuildWrapper} != null){
                    toDelete.add('build wrapper')
                    //remove call
                    mavenJob.getBuildWrappersList().remove(EnvInjectBuildWrapper)
                }
                for (int i=0; i<mavenJob.getPostbuilders().size(); i++){
                    if (mavenJob.getPostbuilders().get(i) instanceof ConditionalBuilder
                            && mavenJob.getPostbuilders().get(i).runCondition.token =~ /\$\{BuildAndDeploy}/){
                        toDelete.add('conditional')
                        //remove call
                        mavenJob.getPostbuilders().remove(mavenJob.getPostbuilders().get(i))
                    }
                }
                report.add(mavenJob.name+': '+toDelete.join(', '))
            }
        }
    }
}
return report.size()+"\n"+report.join("\n")