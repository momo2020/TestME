import hudson.maven.MavenModuleSet
import jenkins.model.*

viewName = "all"
all = Jenkins.instance.getView(viewName)

mavenJobs = all.items.findAll { item -> item instanceof MavenModuleSet }

jobToModifyList = ["test-scm-script",
                   "BUILD_DAY_abc.test2-scm-script_BRANCH_DEF"] as Set

for (job in mavenJobs) {
    if (job.scm != null && job.scm instanceof com.ibm.team.build.internal.hjplugin.RTCScm) {
        if (job.displayName in jobToModifyList) {
            println "Job found :" + job.displayName
            println "Actual RootPOM : " + job.getRootPOM()

//            job.setRootPOM("pom.xml")
//            job.save()
        }
    }
}

//println "list of methods"
//println hudson.maven.MavenModuleSet.metaClass.methods*.name.sort().unique()

