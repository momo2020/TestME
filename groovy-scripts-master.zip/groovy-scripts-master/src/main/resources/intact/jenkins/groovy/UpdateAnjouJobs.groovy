import hudson.maven.MavenModuleSet
import hudson.tasks.LogRotator
import hudson.plugins.timestamper.TimestamperBuildWrapper
import hudson.maven.RedeployPublisher

jenkins = Jenkins.instance
views = jenkins.getView("Anjou").views

for(view in views){
	if(view.name == "00-TEST-BATCH-JOB-UPDATES") {
		continue
	}
	println "Processing view \"${view.name}\""
	jobs = view.items.findAll { item -> item instanceof MavenModuleSet }
	for(job in jobs) {
		println "\tProcessing job ${job.displayName}"
		println "\t\tArchiving disabled: ${job.archivingDisabled}. Will be set to true"
		println "\t\tDay to keep: ${job.buildDiscarder.daysToKeep}. Will be set to 10"
		println "\t\tNum to keep: ${job.buildDiscarder.numToKeep}. Will be set to 5"
		job.setIsArchivingDisabled(true)
		logrotator = new LogRotator(10, 5, -1, -1)
		job.setBuildDiscarder(logrotator)
		
		switch(job.goals) {
			case "-Dmaven.test.skip=true deploy -U":
				newGoals =  "deploy -Dmaven.test.skip=true -Dmaven.test.failure.ignore=false -q"
				break
			case "clean install deploy -P\$PROFILE":
				newGoals =  "deploy -P\$PROFILE -Dmaven.test.failure.ignore=false -q"
				break
			case "deploy -Dmaven.test.skip=true":	
				newGoals =  "deploy -Dmaven.test.skip=true -Dmaven.test.failure.ignore=false -q"
				break
			case "deploy -P\$PROFILE":
				newGoals =  "deploy -P\$PROFILE -Dmaven.test.failure.ignore=false -q"
				break
			case "deploy -Pintg-cp":
				newGoals =  "deploy -Pintg-cp -Dmaven.test.failure.ignore=false -q"
				break
			case "install -Pintg-cp":
				newGoals =  "deploy -Pintg-cp -Dmaven.test.failure.ignore=false -q"
				break
			case "install -Pintg-v":
				newGoals =  "deploy -Pintg-v -Dmaven.test.failure.ignore=false -q"
				break
			case "install -q":
				newGoals =  "deploy -Dmaven.test.failure.ignore=false -q"
				break
			case "install":
				newGoals =  "deploy -Dmaven.test.failure.ignore=false -q"
				break
			case "install site-deploy -Preports":
				newGoals =  "deploy site-deploy -Preports -Dmaven.test.failure.ignore=false -q"
				break
			default:
				newGoals = job.goals
				break
		}
		
		println "\t\tCurrent goals: ${job.goals}. Will change to ${newGoals}"
		job.goals = newGoals
		
		if(job.buildWrappersList.get(TimestamperBuildWrapper) == null) {
			println "\t\tJob will be configured to add timestamps in logs."
			timestamper = new TimestamperBuildWrapper()
			job.buildWrappers.replace(timestamper)
		}
		
		if(job.publishers.get(RedeployPublisher) != null)  {
			println "\t\tDeploy to Nexus repository post action will be removed from job configuration"	
			job.publishers.remove(RedeployPublisher)	
		}
		
		job.save()
	}
}
println "Done"


