package intact.jenkins.groovy

import hudson.maven.MavenModuleSet
import jenkins.model.*
import com.sonatype.insight.ci.hudson.PreBuildScan
import hudson.tasks.Maven
import java.util.HashSet

viewName = "All"

all = Jenkins.instance.getView(viewName)
  
mavenJobs = all.items.findAll { item -> item instanceof MavenModuleSet }
  
// only maven pre step
println "------------------------------------------------------------"
println "ONLY MAVEN PRE STEP"
println "------------------------------------------------------------"
only = mavenJobs.findAll { item -> item.prebuilders.size() == 1 && item.prebuilders.get(Maven.class) != null }
targets = new HashSet()
sizes = new HashSet()  

for(job in only) {
  println "${job.displayName}"
  targets.add(job.prebuilders.get(Maven.class).targets)
  sizes.add(job.prebuilders.size())
  job.prebuilders.clear()
}

println "\tOnly maven targets = ${targets}"
println "\tOnly maven sizes = ${sizes}"

// only nexus iq
println "------------------------------------------------------------"
println "ONLY NEXUS IQ"
println "------------------------------------------------------------"
only = mavenJobs.findAll { item -> item.prebuilders.size() == 1 && item.prebuilders.get(PreBuildScan.class) != null }
targets = new HashSet()
sizes = new HashSet()  

for(job in only) {
  println "${job.displayName}"
  sizes.add(job.prebuilders.size())
}

println "\tOnly nexus iq sizes = ${sizes}"

// nexus iq && maven
println "------------------------------------------------------------"
println " NEXUS IQ && MAVEN"
println "------------------------------------------------------------"
both = mavenJobs.findAll { item -> ! item.prebuilders.empty && item.prebuilders.get(PreBuildScan.class) != null && item.prebuilders.get(Maven.class) != null}
targets = new HashSet()
sizes = new HashSet()  

for(job in both) {
  println "${job.displayName}: ${job.prebuilders.get(Maven.class).targets}"
  targets.add(job.prebuilders.get(Maven.class).targets)
  sizes.add(job.prebuilders.size())
  job.prebuilders.clear()
}

println "\tOnly nexus iq & maven targets = ${targets}"
println "\tOnly nexus iq & maven sizes = ${sizes}"
