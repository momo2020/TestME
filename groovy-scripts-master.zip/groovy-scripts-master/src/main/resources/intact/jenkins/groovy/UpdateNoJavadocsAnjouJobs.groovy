import hudson.maven.MavenModuleSet
import hudson.tasks.LogRotator
import hudson.plugins.timestamper.TimestamperBuildWrapper
import hudson.maven.RedeployPublisher

jenkins = Jenkins.instance
views = jenkins.getView("Anjou").views

for(view in views){
	if(view.name == "00-TEST-BATCH-JOB-UPDATES") {
		continue
	}
	println "Processing view \"${view.name}\""
	jobs = view.items.findAll { item -> item instanceof MavenModuleSet }
	for(job in jobs) {
		println "\tProcessing job ${job.displayName}"
		println "\t\tArchiving disabled: ${job.archivingDisabled}. Will be set to true"
		println "\t\tDay to keep: ${job.buildDiscarder.daysToKeep}. Will be set to 10"
		println "\t\tNum to keep: ${job.buildDiscarder.numToKeep}. Will be set to 5"
		job.setIsArchivingDisabled(true)
		logrotator = new LogRotator(10, 5, -1, -1)
		job.setBuildDiscarder(logrotator)
		
		newGoals = job.goals.replaceAll(" +", " ").replaceAll(" -Dmaven\\.javadoc\\.skip=TRUE", "").replaceAll(" -Dmaven\\.javadoc\\.skip=true", "").replaceAll(" -q", "")
		newGoals = "${newGoals} -Dmaven.javadoc.skip=true -q"

		job.goals = newGoals
		println "\t\tCurrent goals: ${job.goals}. Changed to ${newGoals}"
		
		if(job.buildWrappersList.get(TimestamperBuildWrapper) == null) {
			println "\t\tJob will be configured to add timestamps in logs."
			timestamper = new TimestamperBuildWrapper()
			job.buildWrappers.replace(timestamper)
		}
		
		if(job.publishers.get(RedeployPublisher) != null)  {
			println "\t\tDeploy to Nexus repository post action will be removed from job configuration"	
			job.publishers.remove(RedeployPublisher)	
		}
		
		job.save()
	}
}
println "Done"


