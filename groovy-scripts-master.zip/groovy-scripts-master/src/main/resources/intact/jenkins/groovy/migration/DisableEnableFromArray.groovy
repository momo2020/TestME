import hudson.maven.*
import hudson.model.*
import jenkins.model.*

/**
 * Comment or Uncomment the call of disableJobs() or enableJobs() depending on what you want to do.
 * @author raudet
 */
List<MavenModuleSet> jobs = Jenkins.instance.items.findAll { item -> containedInBuildInfoToExport(item.name) }

//PLZ TURN ME ON AND OFF
disableJobs(jobs)
//enableJobs(jobs)

def containedInBuildInfoToExport(String buildName){
	// COPY buildInfosToExport.json from jenkins-migration HERE
	String[] buildInfoToExports = [
		  "BUILD_DAY_soa-external.dmti.recognition-service-consumer_MASTER_DEF",
		  "BUILD_DAY_soa-resources.client-claims-history-service-resources_MASTER_DEF",
		  "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-message_MASTER_DEF",
		  "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-webservice_FIX_DEF",
		  "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-consumer_MASTER_DEF",
		  "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-webservice_MASTER_DEF"
	];

	for (String buildInfoToExport in buildInfoToExports){
		if (buildName.contains(buildInfoToExport)){
			return true;
		}
	}
	return false;
}

def disableJobs(List<MavenModuleSet> items) {
	println('DISABLING ' + items.size() + ' jobs')
	for (MavenModuleSet item in items) {
		// do not disable already disabled builds
		if (!item.isDisabled()){
			println(item.getName())
			item.disable()
			item.setDescription(item.getDescription() + "\n[Migrated to new jenkins : https://prod-jenkins-2020.iad.ca.inet]");
			item.save()
		}
	}
}

def enableJobs(List<MavenModuleSet> items) {
	println('ENABLING '  + items.size() + ' jobs')
	for (MavenModuleSet item in items) {
		// do not enable already enabled builds
		if (item.isDisabled()){
			println(item.getName())
			item.enable()
			item.setDescription(item.getDescription().replace("\n[Migrated to new jenkins : https://prod-jenkins-2020.iad.ca.inet]", ""));
			item.save()
		}
	}
}