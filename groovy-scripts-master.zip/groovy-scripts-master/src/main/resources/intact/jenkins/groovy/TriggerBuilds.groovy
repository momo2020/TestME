import hudson.maven.MavenModuleSet
import hudson.tasks.LogRotator
import java.util.Calendar
import java.util.concurrent.CancellationException
import java.io.PrintWriter

label = "mtl2020-main"
topView = "AD"
 
jenkins = Jenkins.instance

views = jenkins.getView(topView).views

printer = new PrintWriter("F:/Data/tmp/batch-build-trigger-03.txt")

for(view in views){
	printer.println "Processing view \"${view.name}\""
	jobs = view.items.findAll { item -> item instanceof MavenModuleSet && ! item.disabled && item.assignedLabelString == label}
	for(job in jobs) {
		printer.println "\t\tWaiting for build completion of job ${job.displayName}"
		job.builds.take(1).findAll { build ->
			now = Calendar.instance
			printer.println "\t\t\tbuild=${build.number}, time=${build.timestamp.compareTo(now)}"
			println "now in millis=${now.timeInMillis}"
			println "build.timestamp in millis=${build.timestamp.timeInMillis}"
		}
		printer.flush()
		
		try {
			//future = job.scheduleBuild2(0, new Cause.UserIdCause(), new ParametersAction([]))
			//result = future.get()
			//printer.println "\t\tBuild finished ${result}"	
			printer.flush()
		}
		catch(CancellationException e) {
			printer.println "Cancellation: ${e.message}"
			printer.flush()
		} 
		break
	}
	break
}

printer.close()
printer.println "Done"
println "Done"
