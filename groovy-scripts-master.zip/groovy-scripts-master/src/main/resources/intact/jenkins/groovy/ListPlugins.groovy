plugins = Jenkins.instance.pluginManager.plugins
for(plugin in plugins) {
  println "${plugin.shortName}:${plugin.version}"
}