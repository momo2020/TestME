import hudson.maven.MavenModuleSet
import hudson.model.Label
import hudson.tasks.LogRotator
import hudson.plugins.timestamper.TimestamperBuildWrapper
 
jenkins = Jenkins.instance
label = Label.parseExpression("mtl2020-main")

views = jenkins.getView("Montreal 2020").views

for(view in views) {
	println "Processing view \"${view.name}\""
	tag = "<!-- FILTER:MTL2020_${view.name} -->"
	println "Tag = ${tag}"
	jobs = view.items.findAll { item -> item instanceof MavenModuleSet}
	for(job in jobs) {
		println "${job.name}: ${job.description}"
		logrotator = new LogRotator(30 ,15, -1, -1)
		job.setBuildDiscarder(logrotator)
		description = job.description
		job.setDescription("${description}\n${tag}")
		job.setAssignedLabel(label)
		wrappers = job.buildWrappers
		timestamper = new TimestamperBuildWrapper()
		wrappers.replace(timestamper)
		job.save()
	}
}

println "Done"
