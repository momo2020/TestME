import hudson.maven.MavenModuleSet
import hudson.plugins.sonar.SonarBuildWrapper
import jenkins.model.Jenkins

List<MavenModuleSet> mavenJobs = Jenkins.instance.items.findAll { it instanceof MavenModuleSet && it.name =~ /.*webservice_CONTACT_D16_DEF/} as List<MavenModuleSet>
ArrayList<String> fullStatus = new ArrayList<String>()
mavenJobs.each {mavenJob ->
	ArrayList<String> status = new ArrayList<String>()

	String sonarConfig = 'SonarQube SOA Server'
	if (mavenJob.getBuildWrappersList().get(SonarBuildWrapper) != null){
		if (mavenJob.getBuildWrappersList().get(SonarBuildWrapper).getInstallationName() == sonarConfig){


			String goalsString = mavenJob.getGoals()
			ArrayList<String> mavenTokens = new ArrayList<String>()
			Collections.addAll(mavenTokens, goalsString.split(/\s+/))
			String sonarGoal = 'sonar:sonar'
			String sonarBranch='-Dsonar.branch=/D16'
			String goalsChanged = false
			if (mavenTokens.find{it == sonarGoal} != null){

				if (mavenTokens.find{it == sonarBranch} != null){

					status.add('\tSonar Branch already on ')
				}
				else {
						mavenTokens.add(sonarBranch)
						goalsChanged = true

					status.add('\tno Sonar Branch on ')
				}
			}

			if (goalsChanged){
				mavenJob.setGoals(mavenTokens.join(' '))
				mavenJob.save();
			}
		}
		else {
			status.add('\tno Sonar Config on ')
		}


		status.add(mavenJob.name)
	}


	fullStatus.addAll(status)
}
println(fullStatus.join('\n'))