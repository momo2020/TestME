import jenkins.*
import jenkins.model.*
import hudson.*
import hudson.model.*

import hudson.scm.*
import hudson.tasks.*
import com.cloudbees.hudson.plugins.folder.*

jen = Jenkins.instance

jen.getItems().each{
	if(it instanceof Folder){
		processFolder(it)
	}else{
		processJob(it)
	}
}

void processJob(Item job){
	oldJDK = "jdk-1.7.0_45"
	newJDK = "Oracle JDK 1.8.0_25 Windows"
	JDK jdk = Jenkins.instance.getJDK(newJDK)
	if (job.fullName =~ /Digital\/Distribution_tools\// && job.getJDK() != null && job.getJDK().name == oldJDK){
		println(job.fullName)
		//job.setJDK(jdk)
		//job.save()
	}
}

void processFolder(Item folder){
	folder.getItems().each{
		if(it instanceof Folder){
			processFolder(it)
		}else{
			processJob(it)
		}
	}
}

println("done")
