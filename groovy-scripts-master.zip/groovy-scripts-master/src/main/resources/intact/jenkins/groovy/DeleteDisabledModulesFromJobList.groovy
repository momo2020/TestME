import hudson.maven.MavenModuleSet
  
names = [
"BUILD_DAY_soa-resources.client-service-resources_WEEZER_DEF",
"BUILD_DAY_soa.client.entity.client-service.client-webservice_WEEZER_DEF",
"BUILD_DAY_soa.client.entity.client-service.client-service-message_WEEZER_DEF",
"BUILD_DAY_soa.client.entity.client-service.client-service-consumer_WEEZER_DEF",
"BUILD_DAY_business-object-domain.core-business-components-persistent_WEEZER_DEF",
"BUILD_DAY_soa.client.entity.client-service.client-webservice-external-config_WEEZER_DEF",
"BUILD_DAY_soa.ws-commons-message_DOM6_DEF",
"BUILD_DAY_soa-resources.client-service-resources_DOM6_DEF",
"BUILD_DAY_business-object-domain.basic-data-types_DOM6_DEF",
"BUILD_DAY_soa-resources.address-service-resources_DOM6_DEF",
"BUILD_DAY_soa-resources.basic-data-types-resources_DOM6_DEF",
"BUILD_DAY_soa-resources.ws-commons-message-resources_DOM6_DEF",
"BUILD_DAY_soa-resources.enterprise-domain-data-resources_DOM6_DEF",
"BUILD_DAY_soa.utility.address-service.address-webservice_DOM6_DEF",
"BUILD_DAY_soa-resources.configuration-item-service-resources_DOM6_DEF",
"BUILD_DAY_soa.client.entity.client-service.client-webservice_DOM6_DEF",
"BUILD_DAY_soa-resources.vehicle-information-service-resources_DOM6_DEF",
"BUILD_DAY_soa.utility.address-service.address-service-message_DOM6_DEF",
"BUILD_DAY_soa.client.entity.client-service.client-service-message_DOM6_DEF",
"BUILD_DAY_soa-tests.client-entity-service-request-generator_DOM6_MASTER_DEF",
"BUILD_DAY_soa.client.entity.client-service.client-service-consumer_DOM6_DEF",
"BUILD_DAY_business-object-domain.core-business-components-persistent_DOM6_DEF",
"BUILD_DAY_soa.client.entity.client-service.client-webservice-external-config_DOM6_DEF",
"BUILD_DAY_soa.it.entity.configuration-item-service.configuration-item-service-message_DOM6_DEF",
"BUILD_DAY_soa.it.entity.configuration-item-service.configuration-item-service-consumer_DOM6_DEF"
]
  
for(name in names) {
	job = Jenkins.instance.getItem(name)
	if(job != null) {
		job.getDisabledModules(true).each{module -> module.delete()} 
		println "Cleaned: ${name}"
	}
	else {
		println "Null job: ${name}"
	}
	
}
