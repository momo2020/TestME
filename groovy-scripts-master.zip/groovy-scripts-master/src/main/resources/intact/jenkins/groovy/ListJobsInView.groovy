import hudson.maven.MavenModuleSet
import jenkins.model.*

viewName = "CONTACT_D16 SCM Git"
all = Jenkins.instance.getView(viewName)

mavenJobs = all.items.findAll { item -> item instanceof MavenModuleSet }

for (job in mavenJobs) {
    println job.displayName
}

//println "list of methods"
//println hudson.maven.MavenModuleSet.metaClass.methods*.name.sort().unique()

