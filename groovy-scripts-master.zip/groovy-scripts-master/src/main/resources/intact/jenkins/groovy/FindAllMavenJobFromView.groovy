import hudson.maven.MavenModuleSet
  
viewName = "All"
  
all = Jenkins.instance.getView(viewName)
  
mavenJobs = all.items.findAll { item -> item instanceof MavenModuleSet}
  
 for(job in mavenJobs) {
	println job.displayName
}