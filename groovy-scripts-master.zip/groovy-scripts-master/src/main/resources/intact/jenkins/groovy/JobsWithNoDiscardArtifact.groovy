import hudson.maven.MavenModuleSet
import hudson.maven.RedeployPublisher
import hudson.maven.RedeployPublisher
  
viewName = "All"
  
all = Jenkins.instance.getView(viewName)
  
mavenJobs = all.items.findAll { item -> item instanceof MavenModuleSet}
  
totalDisabled = 0
totalEnabled = 0
postDeploy = 0
    
for(job in mavenJobs) {
	if(job.archivingDisabled) {
		totalDisabled++
	}
	else {
		totalEnabled++
		println "Disabling automatic archiving on ${job.displayName}"
	}
	if(job.publishers.get(RedeployPublisher) != null)  {
		postDeploy++
		println "Removing post deploy action on ${job.displayName}"
	}
	
}

println "Total disabled: ${totalDisabled}"
println "Total enabled: ${totalEnabled}"
println "Total postDeploy: ${postDeploy}"

