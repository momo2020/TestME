import hudson.maven.MavenModuleSet
import org.sonatype.nexus.ci.iq.IqPolicyEvaluatorBuildStep
import java.util.List

// mavenJobs = Jenkins.instance.getView("SwEPT").getView("Nexus IQ Implementation").getView("SOA Jobs For Nexus IQ").items.findAll { it instanceof MavenModuleSet }

mavenJobNames = [
			// "BUILD_DAY_soa.bi.entity.client-analytical-service.client-analytical-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.bi.entity.contract-analytical-service.contract-analytical-service-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.bi.entity.contract-analytical-service.contract-analytical-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.claim.entity.claim-activity-service.claim-activity-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.claim.entity.vendor-information-service.vendor-information-service-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.claim.entity.vendor-information-service.vendor-information-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.claim.utility.claim-notification-service.claim-notification-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.claim.utility.vendor-assignment-service.vendor-assignment-service-webservice_MASTER_DEF",

			// NOT "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-webservice_MASTER_DEF",

			// "BUILD_DAY_soa.client.entity.client-service.client-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.client.entity.client-service.client-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.client.entity.client-service.client-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.client.entity.credit-score-service.credit-score-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.client.entity.credit-score-service.credit-score-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.client.entity.credit-score-service.credit-score-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.client.entity.driving-record-service.driving-record-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.client.entity.driving-record-service.driving-record-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.client.entity.driving-record-service.driving-record-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.distributor.entity.distributor-information-service.dis-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.distributor.entity.distributor-information-service.dis-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.finance.entity.corporate-information-service.corporate-information-service-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.finance.entity.corporate-information-service.corporate-information-service-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.finance.entity.corporate-information-service.corporate-information-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.finance.entity.product-distribution-service.product-distribution-service-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.finance.entity.product-distribution-service.product-distribution-service-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.finance.entity.product-distribution-service.product-distribution-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.it.entity.configuration-item-service.configuration-item-service-webservice_CONTACT_D15_DEF",
			// "BUILD_DAY_soa.it.entity.configuration-item-service.configuration-item-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.plclaim.entity.claim-service.claim-service-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.plclaim.entity.claim-service.claim-service-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.plclaim.entity.claim-service.claim-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-claim-service.contract-claim-service-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-claim-service.contract-claim-service-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-claim-service.contract-claim-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-client-service.contract-client-service-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-client-service.contract-client-service-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-client-service.contract-client-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-conversion-service.contract-conversion-service-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-conversion-service.contract-conversion-service-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-conversion-service.contract-conversion-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-distributor-service.cdis-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-distributor-service.cdis-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-task-service.contract-task-service-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-task-service.contract-task-service-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-task-service.contract-task-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-transfer-service.contract-transfer-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-transfer-service.contract-transfer-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-transfer-service.contract-transfer-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-ubi-service.contract-ubi-service-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-verification-service.cvs-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-verification-service.cvs-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contract-verification-service.cvs-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contractbilling-service.contractbilling-service-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contractbilling-service.contractbilling-service-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.plpolicy.business.contractbilling-service.contractbilling-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.plpolicy.business.product-service.product-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.plpolicy.business.product-service.product-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.plpolicy.business.product-service.product-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.plpolicy.entity.contract-repository-service.crs-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.plpolicy.entity.contract-repository-service.crs-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.plpolicy.entity.contract-repository-service.crs-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.plpolicy.entity.vehicle-information-service.vehicle-information-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.plpolicy.entity.vehicle-information-service.vehicle-information-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.plpolicy.entity.vehicle-information-service.vehicle-information-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.plpolicy.utility.message-authority-service.message-authority-service-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.plpolicy.utility.message-authority-service.message-authority-service-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.plpolicy.utility.message-authority-service.message-authority-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.policy.business.contract-locator-service.contract-locator-service-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.policy.business.contract-locator-service.contract-locator-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.utility.aggregation-service.aggregation-service-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.utility.backward-compatibility-service.backward-compatibility-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.utility.communication-service.communication-service-webservice_MASTER_DEF",

			// NOT FOUND "BUILD_DAY_soa.utility.dom-converter-service.dom-converter-service-webservice_MASTER_DEF",

			// "BUILD_DAY_soa.utility.entity.activity-service.activity-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.utility.entity.b2b-message-repository-service.b2b-message-repository-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.utility.entity.b2b-message-repository-service.b2b-message-repository-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.utility.entity.b2b-message-repository-service.b2b-message-repository-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.utility.entity.communication-repository-service.communication-repository-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.utility.entity.geographical-info-service.geographical-info-service-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.utility.entity.geographical-info-service.geographical-info-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.utility.idgenerator-service.idgenerator-service-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.utility.system-accessor-service.system-accessor-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.utility.system-accessor-service.system-accessor-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.utility.system-accessor-service.system-accessor-webservice_MASTER_DEF",
			// "BUILD_DAY_soa.utility.transformation-service.transformation-webservice_CONTACT_D16_DEF",
			// "BUILD_DAY_soa.utility.transformation-service.transformation-webservice_D14WRTY2MAINTENANCE_DEF",
			// "BUILD_DAY_soa.utility.transformation-service.transformation-webservice_MASTER_DEF" 
            ]

STAGE = "build"
IQ_SCAN_PATTERNS = []
FAIL_BUILD_ON_NETWORK_ERROR = false
JOB_SPECIFIC_CREDENTIALS = null

for(jobName in mavenJobNames) {
    job = Jenkins.instance.getItem(jobName)
        application = job.displayName.replaceFirst("^.+\\.", "").replaceFirst("_DEF\$", "")
        println job.displayName
        println application
        iqStep = new IqPolicyEvaluatorBuildStep(STAGE, application, IQ_SCAN_PATTERNS, FAIL_BUILD_ON_NETWORK_ERROR, JOB_SPECIFIC_CREDENTIALS)
        job.postbuilders.add(iqStep)
}
