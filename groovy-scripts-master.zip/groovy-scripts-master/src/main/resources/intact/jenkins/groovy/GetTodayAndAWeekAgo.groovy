package intact.jenkins.groovy

Calendar today = Calendar.getInstance();
println(today.format('yyyy-MM-dd'));
today.add(Calendar.DAY_OF_MONTH, -7);
println(today.format('yyyy-MM-dd'));
