import hudson.maven.MavenBuild
import hudson.maven.MavenModule
import hudson.maven.MavenModuleSet
import hudson.model.TopLevelItem
import jenkins.model.Jenkins

List<TopLevelItem> jobs = Jenkins.instance.items.findAll { item -> item instanceof MavenModuleSet && item.name =~ /^BUILD_DAY_.*/ }
for(job in jobs) {
	job = job as MavenModuleSet
	for(build in job.builds) {
		Map<MavenModule, List<MavenBuild>> modules = build.moduleBuilds
		for(key in modules.keySet()) {
			for(moduleBuild in modules.get(key)) {
				if(moduleBuild.hasArtifacts) {
					moduleBuild.deleteArtifacts()
					println "\tDeleted artifacts in ${job.displayName} [${moduleBuild.number}]"
				}
			}
		}
	}
}
println "Done"