package intact.jenkins.groovy.notifications

import hudson.plugins.emailext.*
import hudson.tasks.*
import jenkins.model.*
import hudson.model.*

/**
 *  thbrown: 2016-04-28.
 *  Mostly inspired from : https://github.com/jenkinsci/jenkins-scripts/blob/master/scriptler/updateEmailAddress.groovy
 */
String newRecipients = '#SOA-test-2020@intact.net'
List<FreeStyleProject> soapUIJobs = Jenkins.instance.items.findAll { item -> item.name.contains('soapui-test-projects') && item instanceof FreeStyleProject}
for(item in soapUIJobs) {
    println(item.name + ": Checking for email notifiers");
    for(publisher in item.publishersList) {
        // Search for default Mailer Publisher (doesn't exist for Maven projects)
        if(publisher instanceof Mailer) {
            println(item.name + " - Updating publisher: " + publisher + " changing recipients from '" + publisher.recipients + "' to '" + newRecipients + "'");
            publisher.recipients = newRecipients;
        }
        // Or for Extended Email Publisher
        else if(publisher instanceof ExtendedEmailPublisher) {
            println(item.name + " - Updating publisher: " + publisher + " changing recipients from '" + publisher.recipientList + "' to '" + newRecipients + "'");
            publisher.recipientList = newRecipients;
        }
    }
}