import hudson.maven.MavenModuleSet
import hudson.plugins.sonar.SonarBuildWrapper
import jenkins.model.Jenkins

List<MavenModuleSet> mavenJobs = Jenkins.instance.items.findAll { it instanceof MavenModuleSet && it.name =~ /.*webservice.*CONTACT_D16_DEF/} as List<MavenModuleSet>
ArrayList<String> fullStatus = new ArrayList<String>()
mavenJobs.each {mavenJob ->
    ArrayList<String> status = new ArrayList<String>()
    status.add(mavenJob.name)
    String sonarConfig = 'SonarQube SOA Server'
    if (mavenJob.getBuildWrappersList().get(SonarBuildWrapper) != null){
        if (mavenJob.getBuildWrappersList().get(SonarBuildWrapper).getInstallationName() == sonarConfig){
            status.add('\tSonar wrapper already present')
        } else {
            mavenJob.getBuildWrappersList().remove(SonarBuildWrapper)
            mavenJob.getBuildWrappersList().add(new SonarBuildWrapper(sonarConfig))
        }
    } else {
        mavenJob.getBuildWrappersList().add(new SonarBuildWrapper(sonarConfig))
    }
    String goalsString = mavenJob.getGoals()
    ArrayList<String> mavenTokens = new ArrayList<String>()
    Collections.addAll(mavenTokens, goalsString.split(/\s+/))
    String sonarGoal = 'sonar:sonar'
    String goalsChanged = false
    if (mavenTokens.find{it == sonarGoal} == null){
        for (int i = 0; i<mavenTokens.size(); i++){
            if (mavenTokens.get(i) == 'deploy'){
                if (i == mavenTokens.size() - 1){
                    mavenTokens.add(sonarGoal)
                } else {
                    mavenTokens.add(i+1, sonarGoal)
                }
                goalsChanged = true
                i = mavenTokens.size()
            }

        }
    } else {
        status.add('\tSonar goal is already present')
    }
    String jacocoProfile = 'jacoco'
    String profiles = mavenTokens.find{it =~ /^-P/}
    if (profiles != null && profiles =~ jacocoProfile){
        status.add('\tJacoco profile already present')
    } else if (profiles != null) {
        for (int i = 0; i<mavenTokens.size(); i++){
            if (mavenTokens.get(i) =~ /^-P/){
                ArrayList<String> profileTokens = new ArrayList<String>()
                Collections.addAll(profileTokens, mavenTokens.get(i).replaceAll(/^-P/,'').split(','))
                profileTokens.add(jacocoProfile)
                mavenTokens.set(i, '-P'+profileTokens.join(','))
                goalsChanged = true
                status.add('\t-> Jacoco profile added.')
            }
        }
    } else {
        status.add('\tno profiles present at all... this is not managed by this script.')
    }
    if (goalsChanged){
        mavenJob.setGoals(mavenTokens.join(' '))
    }
    if (status.size() < 4){
        status.add('\t-> Sonar configuration added.')
    }
    fullStatus.addAll(status)
}
println(fullStatus.join('\n'))