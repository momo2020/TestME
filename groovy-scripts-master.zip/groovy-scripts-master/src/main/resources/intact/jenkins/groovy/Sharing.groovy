import hudson.maven.MavenModuleSet
import hudson.model.Label
import hudson.tasks.LogRotator
import hudson.plugins.timestamper.TimestamperBuildWrapper
 
jenkins = Jenkins.instance
 
jobs = jenkins.getView("AD").getView("Base").items.findAll { item -> item instanceof MavenModuleSet}
label = Label.parseExpression("mtl2020-main")
tag = "<!-- FILTER:MTL2020_DAY -->"

for(job in jobs) {
	println "${job.name}: ${job.description}"
	logrotator = new LogRotator(10 ,5, -1, -1)
	job.setBuildDiscarder(logrotator)
	job.setDescription(tag)
	job.setAssignedLabel(label)
	wrappers = job.buildWrappers
	timestamper = new TimestamperBuildWrapper()
	wrappers.replace(timestamper)
	job.save()
}
