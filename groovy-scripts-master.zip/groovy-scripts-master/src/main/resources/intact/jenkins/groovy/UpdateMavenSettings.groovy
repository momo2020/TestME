import hudson.maven.MavenModuleSet
import jenkins.mvn.FilePathSettingsProvider  
  
viewName = "All"
settingsPath = "F:\\Data\\var\\maven\\settings.xml" 
  
all = Jenkins.instance.getView(viewName)
  
mavenJobs = all.items.findAll { item -> item instanceof MavenModuleSet}
  
for(job in mavenJobs) {
   	job.settings = new FilePathSettingsProvider(settingsPath)
   	job.save()
	println job.displayName
    println "\t$job.settings.path"
}
