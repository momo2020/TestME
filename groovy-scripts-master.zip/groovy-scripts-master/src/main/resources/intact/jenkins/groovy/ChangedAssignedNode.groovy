package intact.jenkins.groovy
import java.util.*
import hudson.maven.*
import jenkins.model.*;

List<MavenModuleSet> jobs = Jenkins.instance.items.findAll { item -> item instanceof MavenModuleSet }

for (MavenModuleSet job : jobs) {
    if (!job.getAssignedLabelString().equals('mtl2020-main')){
        println(job.getName())
        println(job.getAssignedLabelString())
    }
}