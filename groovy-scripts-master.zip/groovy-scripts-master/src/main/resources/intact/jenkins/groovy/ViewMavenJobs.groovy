package intact.jenkins.groovy

import hudson.maven.MavenModuleSet
import jenkins.model.*

viewName = "All"

all = Jenkins.instance.getView(viewName)
  
List<MavenModuleSet> mavenJobs = all.items.findAll { item -> item instanceof MavenModuleSet}
  
for(job in mavenJobs) {
	sonar = job.publishers.get(hudson.plugins.sonar.SonarPublisher.class)
    if(sonar != null) {
  		println job.displayName
    }
}
