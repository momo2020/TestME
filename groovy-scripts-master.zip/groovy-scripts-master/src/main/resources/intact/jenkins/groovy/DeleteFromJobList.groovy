import hudson.maven.MavenModuleSet

names = [
        "BUILD_DAY_soa.ws-commons-message_D11BUGFIX_DEF",
        "BUILD_DAY_commons.persistent-layer_D11BUGFIX_DEF",
        "BUILD_DAY_soa-resources.dis-resources_D11BUGFIX_DEF",
        "BUILD_DAY_soa-tests.bco-object-builder_D11BUGFIX_DEF"
]

for(name in names) {
    job = Jenkins.instance.getItem(name)
    if(job != null) {
        //job.delete()
        println "delete: ${name}"
    }
    else {
        println "Null job: ${name}"
    }

}
