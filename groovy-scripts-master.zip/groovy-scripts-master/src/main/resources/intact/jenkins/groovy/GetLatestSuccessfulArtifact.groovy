package intact.jenkins.groovy

import hudson.model.FreeStyleProject;
import jenkins.model.*;
import groovy.json.JsonSlurper;

FreeStyleProject deployDescriptorJob = (FreeStyleProject)Jenkins.instance.getItemByFullName(jobName);
String deploymentList = '';
deployDescriptorJob.getLastSuccessfulBuild().getArtifacts().each {
    artifact ->
        if (artifact.getFileName().equals('deploy-data.json')){
            def json = new JsonSlurper().parseText(artifact.getFile().text)
            json.each {
                deploymentList = deploymentList + it.name +'-'+it.environmentLetter+': '+it.version + ' | '
            }
        }
};
build.getArtifacts().each {
    artifact ->
        if (artifact.getFileName().equals('deploymentItems.json')){
            def deployments = new JsonSlurper().parseText(artifact.getFile().text)
        }
}
return deploymentList.substring(0, deploymentList.length()-3);