package intact.jenkins.groovy

import hudson.maven.MavenModuleSet
import jenkins.model.*
import org.jvnet.hudson.plugins.m2release.M2ReleaseBuildWrapper

viewName = "All"

all = Jenkins.instance.getView(viewName)
  
List<MavenModuleSet> mavenJobs = all.items.findAll { item -> item instanceof MavenModuleSet}
  
for(job in mavenJobs) {
	if(job.displayName.startsWith('BUILD_COMPILE') && job.goals.contains('MVN_TOOLCHAINS')) {
		println "\tProcessing job ${job.displayName}"
		
		wrappers     = job.buildWrappersList
	    oldM2Release = wrappers.get(M2ReleaseBuildWrapper)
    
    	if(oldM2Release == null) {
    		println "\t\tNo release configuration"
    		continue
    	}
    	oldWetGoals  = oldM2Release.releaseGoals
    	oldDryGoals  = oldM2Release.dryRunGoals
    
    	println "\t\tOld wet goals: ${oldWetGoals}.\n\t\tOld dry goals: ${oldDryGoals}"
    
    	oldWetGoalsClean = oldWetGoals.replaceAll(" *-PMVN_TOOLCHAINS", "")
    	oldDryGoalsClean = oldDryGoals.replaceAll(" *-PMVN_TOOLCHAINS", "")
    	newWetGoals = "${oldWetGoalsClean} -PMVN_TOOLCHAINS"
    	newDryGoals = "${oldDryGoalsClean} -PMVN_TOOLCHAINS"
    
    	newM2Release = new M2ReleaseBuildWrapper(newWetGoals, newDryGoals, false, false, false, 'IS_M2RELEASEBUILD', null, null, 1)
    	
    	oldGoals = job.goals
    	oldGoalsClean = oldGoals.replaceAll(" *-PMVN_TOOLCHAINS", "")
        newGoals = "${oldGoalsClean} -PMVN_TOOLCHAINS"
        
        println "\t\tNew wet goals: ${newWetGoals}.\n\t\tNew dry goals: ${newDryGoals}.\n\t\tNew goals: ${newGoals}"
        
    	wrappers.replace(newM2Release)
        job.goals = newGoals
    
    	job.save()
	}
}
