import hudson.maven.MavenModuleSet
import hudson.model.JDK
import jenkins.model.Jenkins
  
List<MavenModuleSet> mavenJobs = Jenkins.instance.items.findAll { item -> item instanceof MavenModuleSet} as List<MavenModuleSet>
JDK jdk = Jenkins.instance.getJDK("jdk-1.7.0_45")
mavenJobs.each {job ->
	if (job.name =~ /^BUILD_DAY_/ && job.getJDK() != null && job.getJDK().name == "java6"){
		println(job.name)
		//job.setJDK(jdk)
		//job.save()
	}
}
println("Done")