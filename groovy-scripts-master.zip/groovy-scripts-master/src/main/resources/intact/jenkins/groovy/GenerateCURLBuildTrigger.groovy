import hudson.maven.MavenModuleSet

List<MavenModuleSet> mavenJobs = jenkins.model.Jenkins.instance.items.findAll { it instanceof MavenModuleSet && it.name =~ /.*webservice.*CONTACT_D16_DEF/} as List<MavenModuleSet>
String prefix = "curl -n -XPOST https://prod-jenkins-2020.iad.ca.inet/job"
mavenJobs.each { mavenJob ->
    if (mavenJob.parameterized){
        println("${prefix}/${mavenJob.name}/buildWithParameters")
    } else {
        println("${prefix}/${mavenJob.name}/build")
    }
}
println('Done')