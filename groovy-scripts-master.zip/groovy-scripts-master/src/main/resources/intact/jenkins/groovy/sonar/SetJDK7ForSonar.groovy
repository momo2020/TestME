package intact.jenkins.groovy.sonar

import java.util.*
import hudson.maven.*
import jenkins.model.*;
import hudson.plugins.sonar.SonarPublisher;

List<MavenModuleSet> jobs = Jenkins.instance.items.findAll { item -> item instanceof MavenModuleSet }

for (MavenModuleSet job : jobs) {
    SonarPublisher sonarPublisher = job.getPublishers().get(SonarPublisher.class);
    if (sonarPublisher != null) {
        println(job.getName())
        println(sonarPublisher.getJdkName())
    }
}