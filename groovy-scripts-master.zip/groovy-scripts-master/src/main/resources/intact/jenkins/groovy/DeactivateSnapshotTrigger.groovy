package intact.jenkins.groovy

import hudson.maven.MavenModuleSet
import hudson.model.TopLevelItem

projectPatterns = [
        '\\.task\\.add-party-process',
        '\\.task\\.add-risk-process',
        '\\.task\\.assess-contract-credit-score-process',
        '\\.task\\.assignment-process',
        '\\.task\\.b2b-new-quote-process',
        '\\.task\\.calculate-payment-schedule-process',
        '\\.task\\.can-add-party-process',
        '\\.task\\.can-add-risk-process',
        '\\.task\\.cancel-policy-automated-process',
        '\\.task\\.cancel-policy-process',
        '\\.task\\.cede-uncede-process',
        '\\.task\\.claims-assignment-process',
        '\\.task\\.complete-policy-transaction-process',
        '\\.task\\.consult-client-process',
        '\\.task\\.consult-quote-contract-summary-process',
        '\\.task\\.contract-geo-enrichment-process',
        '\\.task\\.convert-to-new-business-process',
        '\\.task\\.copy-contract-process',
        '\\.task\\.create-quote-process',
        '\\.task\\.delete-quote-process',
        '\\.task\\.delete-transaction-process',
        '\\.task\\.generate-contract-task-process',
        '\\.task\\.generate-offer-process',
        '\\.task\\.get-premium-process',
        '\\.task\\.lapse-policy-automated-process',
        '\\.task\\.lapse-policy-process',
        '\\.task\\.match-clients-process',
        '\\.task\\.merge-contract-process',
        '\\.task\\.personallines-create-client-process',
        '\\.task\\.personallines-delete-client-process',
        '\\.task\\.personallines-rating-process',
        '\\.task\\.personallines-search-client-contract-process',
        '\\.task\\.personallines-update-client-process',
        '\\.task\\.policy-document-composition-process',
        '\\.task\\.policy-document-preview-process',
        '\\.task\\.product-management-process',
        '\\.task\\.reinstate-policy-process',
        '\\.task\\.remove-party-process',
        '\\.task\\.remove-risk-process',
        '\\.task\\.renew-policy-process',
        '\\.task\\.retrieve-contract-billing-process',
        '\\.task\\.retrieve-contract-claims-process',
        '\\.task\\.retrieve-contract-distributor-process',
        '\\.task\\.save-transaction-process',
        '\\.task\\.search-contract-entity-process',
        '\\.task\\.submit-transaction-process',
        '\\.task\\.underwrite-contract-process',
        '\\.task\\.unlapse-policy-process',
        '\\.task\\.update-contract-notes-process',
        '\\.task\\.update-driving-experience-process',
        '\\.task\\.update-pending-renewal-process',
        '\\.task\\.update-policy-automated-process',
        '\\.task\\.update-policy-process',
        '\\.task\\.update-quote-new-business-process',
        '\\.task\\.user-login-process',
]
regexp = '('+projectPatterns.join('|')+')_\\w+_DEF$'
List<TopLevelItem> jobs = jenkins.model.Jenkins.instance.items.findAll {
    it instanceof MavenModuleSet && it.name =~ /^BUILD_DAY[-_]soa\./ && it.name =~ /$regexp/
}
jobs.each {
    (it as MavenModuleSet).setIgnoreUpstremChanges(true)
    it.save()
    println(it.name)
}
println('\nDone')