import hudson.maven.*
import hudson.model.*
import jenkins.model.*

/**
 * Used to modify the Goals and Options from the list of builds
 *
 * @author raudet
 */
List<MavenModuleSet> jobs = Jenkins.instance.items.findAll { item -> containedInBuildInfoToExport(item.name) }

//PLZ TURN ME ON AND OFF
removeForkCount(jobs)

def containedInBuildInfoToExport(String buildName){
	// COPY buildInfosToExport.json from jenkins-migration HERE
	String[] buildInfoToExports = [
		  "BUILD_DAY_soa-external.dmti.recognition-service-consumer_MASTER_DEF",
		  "BUILD_DAY_soa-resources.client-claims-history-service-resources_MASTER_DEF",
		  "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-message_MASTER_DEF",
		  "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-webservice_FIX_DEF",
		  "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-consumer_MASTER_DEF",
		  "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-webservice_MASTER_DEF"
	];

	for (String buildInfoToExport in buildInfoToExports){
		if (buildName.contains(buildInfoToExport)){
			return true;
		}
	}
	return false;
}

def removeForkCount(List<MavenModuleSet> items) {
	println('UPDATING ' + items.size() + ' jobs')
	for (MavenModuleSet item in items) {
		if (!item.getGoals().contains("-PMVN_TOOLCHAINS")){
//			println(item.getName());
			//println(item.getGoals() + " -PMVN_TOOLCHAINS --toolchains F:\\Data\\var\\maven\\toolchains.xml")
			item.setGoals(item.getGoals() + " -PMVN_TOOLCHAINS --toolchains F:\\Data\\var\\maven\\toolchains.xml");
			println(item.getGoals());
			item.save();
			//println(item.getGoals() + " BECOMES " + item.getGoals().replace("-DforkCount=0 ", ""));
		}
	}
}
