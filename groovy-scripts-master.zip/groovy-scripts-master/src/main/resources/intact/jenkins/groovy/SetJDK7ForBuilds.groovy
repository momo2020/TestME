import hudson.maven.MavenModuleSet
  
viewName = "All"
  
all = Jenkins.instance.getView(viewName)
  
mavenJobs = all.items.findAll { item -> item instanceof MavenModuleSet}
jdk = Jenkins.instance.getJDK("java6")
  
for(job in mavenJobs) {
	if(job.displayName != "BUILD_DAY_test.test-project-prod_MASTER_DEF") {
		continue
	}
	job.setJDK(jdk)
	job.save()
	println job.displayName
}
