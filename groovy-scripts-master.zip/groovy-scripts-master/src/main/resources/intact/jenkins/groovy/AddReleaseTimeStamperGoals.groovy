import hudson.maven.MavenModuleSet
import hudson.tasks.LogRotator
import org.jvnet.hudson.plugins.m2release.M2ReleaseBuildWrapper
import hudson.plugins.timestamper.TimestamperBuildWrapper
import hudson.maven.RedeployPublisher
import java.io.File
import java.io.FileWriter

jenkins = Jenkins.instance
  
jobs = jenkins.getView("Tools And Utilities").getView("Batch Job Configuration Updates").getView("Batch Update 001").items.findAll { job -> job instanceof MavenModuleSet }  
jobs.addAll(jenkins.getView("Tools And Utilities").getView("Batch Job Configuration Updates").getView("Build Update 002").items.findAll { job -> job instanceof MavenModuleSet } )
jobs.addAll(jenkins.getView("Tools And Utilities").getView("Batch Job Configuration Updates").getView("Build Update 003").items.findAll { job -> job instanceof MavenModuleSet } )
jobs.addAll(jenkins.getView("Tools And Utilities").getView("Batch Job Configuration Updates").getView("Build Update 004").items.findAll { job -> job instanceof MavenModuleSet } )  

log = new FileWriter(new File("F:/Data/tmp/bath-update-0001.log"))  
  
for(job in jobs) {
  println "Processing: " + job.name
  log.write(job.name + "\n")
  
  job.logRotator = new LogRotator(30, 10, -1, -1)
  job.goals = "deploy -Dmaven.test.failure.ignore=false -Penforce-snapshot"
    
  job.publishers.removeAll {p ->  (p instanceof RedeployPublisher)}
  
  job.buildWrappers.removeAll {p ->  (p instanceof TimestamperBuildWrapper)}
  job.buildWrappers.add(new TimestamperBuildWrapper())
  
  job.buildWrappers.removeAll {p ->  (p instanceof M2ReleaseBuildWrapper)}
  branch = job.name.replaceAll('^.+_([^_]+)_DEF$', '$1')
  wetGoal = '-Dresume=false -DscmRepositoryWorkspace=BUILD_DAY_${shortGroupId}.${project.artifactId}_' + branch + '_WS -DbaseReleaseWorkingDirectory=F:/Data/tmp/intact-release release:prepare release:perform rtc:push'
  dryGoal = '-Dresume=false -DdryRun=true -DscmRepositoryWorkspace=BUILD_DAY_${shortGroupId}.${project.artifactId}_' + branch + '_WS release:prepare'
  m2Release = new M2ReleaseBuildWrapper(wetGoal, dryGoal, false, false, false, 'IS_M2RELEASEBUILD', null, null, 1)  
  job.buildWrappers.add(m2Release) 
  job.save()     
    
}

log.flush()
log.close()
