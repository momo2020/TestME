import org.springframework.util.StringUtils;

import hudson.maven.*
import hudson.model.*
import jenkins.model.*

/**
 * Merge all the -P to a single one
 *
 * @author raudet
 */
List<MavenModuleSet> jobs = Jenkins.instance.items.findAll { item -> containedInBuildInfoToExport(item.name) }

//PLZ TURN ME ON AND OFF
mergeProfiles(jobs)

def containedInBuildInfoToExport(String buildName){
	// COPY buildInfosToExport.json from jenkins-migration HERE
	String[] buildInfoToExports = [
		  "BUILD_DAY_soa-external.dmti.recognition-service-consumer_MASTER_DEF",
		  "BUILD_DAY_soa-resources.client-claims-history-service-resources_MASTER_DEF",
		  "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-message_MASTER_DEF",
		  "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-webservice_FIX_DEF",
		  "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-consumer_MASTER_DEF",
		  "BUILD_DAY_soa.client.entity.client-claims-history-service.client-claims-history-service-webservice_MASTER_DEF"
	];

	for (String buildInfoToExport in buildInfoToExports){
		if (buildName.contains(buildInfoToExport)){
			return true;
		}
	}
	return false;
}

def mergeProfiles(List<MavenModuleSet> items) {
	println('LOOKING AT ' + items.size() + ' jobs')
	int modifiedItems = 0;
	for (MavenModuleSet item in items) {
		List<String> tokensToMerge = new ArrayList<String>();
		if (StringUtils.countOccurrencesOf(item.getGoals(), "-P") > 1){
			String finalString = "";
			println("*** " + item.getName() + " ***");
			println("\t " + item.getGoals());
			StringTokenizer tokenizer = new StringTokenizer(item.getGoals());
			while (tokenizer.hasMoreTokens()){
				String token = tokenizer.nextToken();
				//print("["+token+"] ");
				if (token.startsWith("-P") && !token.contains("-PMVN_TOOLCHAINS")){
					tokensToMerge.add(token);
				} else {
					finalString += token + " ";
				}
			}
			String mergedProfile = "-P";
			for (String tokenToMerge in tokensToMerge){
				mergedProfile+=tokenToMerge.replace("-P", "");
				mergedProfile+=",";
			}
			mergedProfile+="MVN_TOOLCHAINS";
			String modifiedString = finalString.replace("-PMVN_TOOLCHAINS", mergedProfile).trim();
			modifiedString = modifiedString.replace(" -q ", " ");
			modifiedString = modifiedString.replace(" -DforkCount=0 ", " ");
			println("DEVIENT:["+ modifiedString + "]");
			//item.setGoals(modifiedString);
			//item.save();
			modifiedItems++;
		}
	}
	println('\nmodified ' + modifiedItems + ' jobs')
}
