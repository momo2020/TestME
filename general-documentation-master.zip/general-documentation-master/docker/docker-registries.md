# Intact Docker Registries
We have an internal private docker hub. This is Nexus 3. To access its content, a user must be member of the nexus-developer group.

It consists of several registries:
* hosted registeries to store internally produced images<br/>These registeries are used for only for push operations. Take note we are working on a new recipe to build image on OpenShift that may change the usage of our hosted registries.
  * `docker-mutable`: for internal mutable images
  * `docker-release`: for internal immutable images
* `docker-group`: A _virtual_ registry that regroups all other registries. It is used for all read operations (that is all except push, including pull, FROM...)<br/>This group registry includes
  * A proxy to `registry.access.redhat.com` where we can find RedHat certificated images. This  images are all available to nexus-developer users. For searching available certified images got to [RedHat Registry](https://access.redhat.com/containers/)
  * a private hosted registry with copy of images from Docker Hub. This registry is filled by ourselves (Tools team) on demand with images from Docker Hub This should be very rare, only when there is no other solution from redhat
  * `docker-mutable` (see hosted registries above)
  * `docker-release` (see hosted registries above)

Host to use (port is relevant):
* `docker-group.iad.ca.inet:8473`
* `docker-mutable.iad.ca.inet:8463`
* `stha8p0co.iad.ca.inet:8493` (this will change to docker-release in the near future)
* For browsing the content through the UI: [Nexus 3](https://docker-group.iad.ca.inet:8443)

# Docker API
* List repositories: `curl -k -u nexus-upgrade-tester:****** https://docker-group.iad.ca.inet:8473/v2/_catalog -o catalog.json`
* Listing Image Tags: `curl -k -u nexus-upgrade-tester:****** https://docker-group.iad.ca.inet:8473/v2/intact/address-service-endpoints/tags/list -o image-tags.json`
* Pull image
  * Existing An Image Manifest (does not seem to work currently): `curl -k -I -u nexus-upgrade-tester:****** https://docker-group.iad.ca.inet:8473/v2/intact/address-service-endpoints/manifests/6.2.5.0.0.4.HQQV2.0-UAT`
  * Pulling An Image Manifest: `curl -k -u nexus-upgrade-tester:****** https://docker-group.iad.ca.inet:8473/v2/intact/address-service-endpoints/manifests/6.2.5.0.0.4.HQQV2.0-UAT -o manifest.json`
  * Pulling An Image Layer: `curl -k -u nexus-upgrade-tester:****** https://docker-group.iad.ca.inet:8473/v2/intact/address-service-endpoints/blobs/sha256:055bf2c29dfdd5a9aafe943439cfcbf997d1bdb4826a66b6cd304279e210c3e5 -O`
