# GitHub Administration
## Pre requisite
GitHub administrators are part of the gitadmin LDAP group
## Access to the host
Some administrive commands require access to the GitHub server. Take notice we need to use the hostname of the server to let netscaler go through with ssh.
```
ssh -p 122 admin@stha9p0f0.iad.ca.inet
```
## Take ownership of an Organization
You need to be Site Admin with SSH access. <br/>
By default, the utility gives admin privileges to all Site Admins in all organizations, so you will want to narrow the scope by using the -u and -o paramaters:
```
ghe-org-admin-promote -u Username -o OrganizationName
```
Once you have access to the organization, you can transfer repositories by following our Transferring a repository owned by your organization guide.
