# General Installation
Use standard Intact jenkins rhel base docker image as explained [here](jenkins-docker.md)

# EIS Specific configuration
## Filesystem
* Copy `dxtoolkit` directory to `/opt/tools/jenkins`

## Configure Jenkins System
* Environment variables
  * `JOB_ALERT_EMAIL`: `pavan.pandurang@intact.net`
  * `QA_NOTIFY_EMAIL`: `pavan.pandurang@intact.net, france.pare@intact.net, martin.dalpe@intact.net, raymond.nadeau@intact.net, marie-claude.rene@intact.net`
