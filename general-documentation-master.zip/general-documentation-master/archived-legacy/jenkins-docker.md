# Jenkins Docker

## General Notes

### Tar
Note on content archived tgz uzed to build images and to copy tools on nodes.
If possible follow these rules:

* Create the archive with tar on a Linux host with the userid that will extract and use the content
* Use option -p to preserve permissions
* Use relative paths for symbolic links that reference elements inside the extracted archive. Example: `RTC-BuildSystem-Toolkit-Linux64 -> RTC-BuildSystem-Toolkit-Linux64-6.0.2/`
* Use absolute paths for symbolic links that reference elements outside the extracted archive. This is especially usefull for secrets. Example: `jazz-scm -> /opt/tools/jenkins/secrets/jazz-scm/`

## Master & Nodes Hosts

### Secrets
In every master and node host:

* As jenkins user `mkdir -p /opt/tools/jenkins/secrets`
* Copy maven settings
  * `mkdir -p /opt/tools/jenkins/secrets/maven`
  * `cp -a settings.xml /opt/tools/jenkins/secrets/maven`
* Copy jazz-scm secrets
  * `cp -a jazz-scm /opt/tools/jenkins/secrets`

## Build & publish the Jenkins master image
* `git clone https://githubifc.iad.ca.inet/DockerBaseImages/jenkins-rhel-base`
* `cd jenkins-rhel-base`
* If needed correct the versions inside `bin/versions.sh`
* Build: `source bin/build.sh`
* Push: `source bin/push.sh`

## Run the Jenkins master image as a service
This is way to run the Jenkins master in production.

WARNING: This procedure is currently broken. Until it is
fixed use the procedure below _Run the Jenkins master image with a script_

* Ensure `/opt/tools/jenkins/scripts/version.sh` contains to correct version of your image
* Run jenkins: `sudo systemctl start docker-jenkins`
* Stop jenkins: `sudo systemctl stop docker-jenkins`

## Run the Jenkins master image with a script
Use if using the service does not work.

* Run jenkins: `/opt/tools/jenkins/scripts/run-jenkins.sh`
* Stop jenkins: `/opt/tools/jenkins/scripts/stop-jenkins.sh`

## Run the Jenkins master image manually
This can be useful for testing in another host that does not have the 
service docker-jenkins installed

* `docker pull docker-group.iad.ca.inet:8473/intact/jenkins-rhel-base:${VERSION}`
* `docker run -d -P -v /opt/tools/docker/jenkins-rhel:/var/lib/jenkins -v /docker/jenkins-rhel-builds:/var/lib/jenkins-builds -e HTTPS_KEY_STORE_PASSWORD=<jenkins.jks SSL keystore> docker-group.iad.ca.inet:8473/intact/jenkins-rhel-base:${VERSION}`

## Login
* user: `admin`
* password: `password`

## Misc configurations

### Change update center url
* Manage Jenkins > Manage Plugins > Advanced > Update Site
  * URL: `https://updates.jenkins-ci.org/stable/update-center.json`
  * Submit
  * Click Check Now button
    *	After a few seconds or  minutes, update information last date is changed

### Global credentials
Go to Credentials > System > Global credentials and add the following credentials.

* build-maven
  * Add credentials
  * Kind: Username with password
  * Scope: Globals (...)
  * Username: `build-maven`
  * Password: ``******``
  * ID: `<leave empty>`
  * Description: `Build Maven Credentials used in Git & RTC production`

## Global Tool Configuration

### Maven Configuration
* Default settings provider: `Settings file in filesystem`
  * File path: `/opt/tools/jenkins/maven/settings.xml`
* Default global settings provider. `Use default maven global settings`

### RTC Build toolkit
* RTC Build toolkit installations > Add RTC Build toolkit
* Name: `rtc`
* Home: `/opt/tools/RTC-BuildSystem-Toolkit-Linux/jazz/buildsystem/buildtoolkit`
* WARNING: do not use automatic installers with rtc build toolkit since it may cause errors, especially when having several installations.

## JDK
* JDK installations
  * JDK
    * Name: `java6_64`
    * Install automatically: checked
    * Extract `*.zip/*.tar.gz`
      * Label: `linux`
      * Download URL for binary archive: `https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/service/local/repositories/installers/content/ibm_jdk/ibm_jdk/1.6-16.30/ibm_jdk-1.6-16.30-linux-x86_64.tar.gz`
      * Subdirectory of extracted archive: `ibm-java-x86_64-60`
  * JDK
    * Name: `jdk-1.7.0_45`
    * Install automatically: checked
    * Extract `*.zip/*.tar.gz`
      * Label: `linux`
      * Download URL for binary archive: `https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/content/repositories/installers/oracle/jdk/1.7.0_45/jdk-1.7.0_45-linux-x64.tar.gz`
      * Subdirectory of extracted archive: `jdk1.7.0_45`
  * JDK
    * Name: `ibm-java-linux-1.7-x86_64-71`
    * Install automatically: checked
    * Extract `*.zip/*.tar.gz`
      * Label: `linux`
      * Download URL for binary archive: `https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/service/local/repositories/installers/content/ibm-java-linux/ibm-java-linux/1.7-x86_64-71-v2/ibm-java-linux-1.7-x86_64-71-v2.tgz`
      * Subdirectory of extracted archive: `ibm-java-linux-1.7-x86_64-71-v2`
  * JDK
    * Name: `oracle-jdk1.8.0_102-linux`
    * Install automatically: checked
    * Extract `*.zip/*.tar.gz`
      * Label: `linux`
      * Download URL for binary archive: `https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/service/local/repositories/installers/content/oracle/oracle-linux-jdk/1.8.0_102/oracle-linux-jdk-1.8.0_102.tgz`
      * Subdirectory of extracted archive: `oracle-jdk1.8.0_102`

## Git
* Git > Git installations> Git > Delete Git
* Git > Git installations> Add Git > JGit

## Groovy installation
TODO

## Maven installation
* Maven > Maven installations > Add Maven
  * Name: `maven-3.0.5`
  * Delete default installer
  * Add an Extract `*.zip / *.tgz` installer
  * Extract `*.zip / *.tgz` > Label:  `<leave empty>`
  * Extract  `*.zip / *.tgz` > Download URL for binary archive:  `https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/service/local/repositories/installers/content/apache-maven/apache-maven/3.0.5/apache-maven-3.0.5.tgz`
  * Extract `.zip / *.tgz` > Subdirectory of extracted archive: `apache-maven-3.0.5`
* Maven > Maven installations > Add Maven
  * Name: `maven-3.5.0`
  * Delete default installer
  * Add an Extract `*.zip / *.tgz` installer
  * Extract `*.zip / *.tgz` > Label:  `<leave empty>`
  * Extract  `*.zip / *.tgz` > Download URL for binary archive:  `https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/service/local/repositories/installers/content/apache-maven/apache-maven/3.5.0/apache-maven-3.5.0.tgz`
  * Extract `.zip / *.tgz` > Subdirectory of extracted archive: `apache-maven-3.5.0`

## NodeJS
Add the following NodeJS installations by clicking on `NodeJS > NodeJS installations > Add NodeJS`.  For every new NodeJS installation:

* Check Install automatically
* Add an Extract `*.zip / *.tgz` installer

These are the NodeJS to install:

* TODO: see Jenkins 2020

##	Configure Jenkins System
This configuration is done in Manage Jenkins > Configure System. While doing your configuration you can regularly click the Apply button at the button to save your changes without leaving the configuration page.

### Advanced configuration
* Under Home Directory click the Advanced… button
* Change field Build Record Root Directory to `/var/lib/jenkins-builds/${ITEM_FULL_NAME}/builds`. This will make Jenkins store build history outside at F:\Data\var\jenkins-builds which is outside $JENKINS_HOME and will make restores and upgrade easier.
* System Message : RRQ Pipelines or any description you might find useful. Take note it is supposed to render html tags, but for this you need to have chosen Manage Jenkins > Configure Global Security > Markup Formatter >Safe HTML .
* `#` of executors : 0

### Global properties
Check Environment variables and add the following environment variables.

* SCM_CONFIG_DIRECTORY:`/opt/tools/jenkins/jazz-scm`

### Audit trail
* Loggers > Adder Logger > Log File
* Log Location : `/var/jenkins/logs/audit/auditing-%g.log`
* Log File Size MB : `50`
* Log File Count : `20`

### Build Trigger Badge
* Make sure the option is checked

### Uncheck build monitor sending anonymous data
* Uncheck Build Monitor > Help make Jenkins better by sending anonymous usage statistics and crash reports to the Jenkins project.

### Jenkins Location
* Jenkins URL:  `<be sure to have the proper Jenkins URL>`
* System Admin e-mail address: `<email-of-jenkins-admin>`

### GitHub Enterprise Servers
* Add
* API endpoint: `https://githubifc.iad.ca.inet/api/v3`
* Name: `Intact GitHub`

### Rational Team Concert (RTC)
* Build toolkit: `rtc`  
* Server URI: `https://prod-rtc-b2e.iad.ca.inet/ccm`
* Credentials: select `build-maven/****`
* Test connexion should return: Connection test was successful

### Veracode Jenkins Plugin
* Veracode User Credentials
  * Username: `epm.toolsupport@intact.net`
  * Password:  `******`
* Check all options except "Run in debug mode." and "Connect using proxy"
* Test connexion should return “Success!”

### E-mail Notification
* SMTP server: `smtp.iad.ca.inet`
* Default user e-mail suffix : `@intact.net`
* Check `Test configuration by sending test e-mail` and send an email to your address to check the configuration.

### Sonatype Nexus

* Nexus Repository Manager Servers > Add Nexus Repository Manager Server
  * Nexus Repository Manager 2.x Server
    * Display Name: `Nexus Repository Manager 2.x`
    * Server ID: `nexus-repository-manager-2.x`
    * Server URL: `https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus`
    * Credentials: select `build-maven/****`
    * Test connection should return "Nexus Repository Manager 2.x connection succeeded (1 hosted release Maven 2 repositories)"
  * Nexus IQ Server > Add Nexus IQ Server
    * Nexus IQ Server
      * Server URL: `https://prod-sonatype-clm.iad.ca.inet:8443`
      * Credentials: select `build-maven/****`
      * Test connection should return Nexus IQ Server connection succeeded (xxx applications)

### Extended E-mail Notification
* SMTP server: `smtp.iad.ca.inet`
* Default Content Type: `HTML (text/html)`

## Configure Global Security

### Enable security
* Go to Manage Jenkins > Configure Global Security
* Check Enable security
* DO NOT SAVE BEFORE ADDING ACCESS RIGHTS TO ANONYMOUS (SEE BELOW)

### Authorization
* Take note that some authorization with admin rights granted to anonymous needs to have been configured in order to be able to add nodes on Windows with Web Start.
* Go to Manage Jenkins > Configure Global Security > Access Control > Matrix-based security
* Grant all rights to anonymous during initial configuration. This will prevent from getting access denied while doing the initial configuration. Once all installation is done you can check that login can be done with an administrative account and then remove all rights to anonymous, except Discover.
* Grant rights based on usename or group depending on the policy you choose for your Jenkins instance.

### LDAP Authentication
* Access Control > Authorization: check LDAP
  * Server: `ldaps://prod-tam-ldap.iad.ca.inet`
  * Click Advanced… button
  * root DN: `dc=ca,dc=ecamericas`
  * User search filter : `uid={0}`
  *	Manager DN: `uid=pastools,ou=serviceaccounts,dc=ca,dc=ecamericas`
  *	Manager Password: `******`

### LDAP Authentication
* Go to Manage Jenkins > Configure Global Security
* Check `Enable Agent → Master Access Control`

## Misc configurations in Configure Global Security
* Markup Formatter > Safe HTML
* Check `Prevent Cross Site Request Forgery exploits`
* Check `	Crumbs > Crumb Algorithm > Default Crumb Issuer`
* Check `Enable Slave → Master Access Control`

## Nodes
Example with node-digital-001, change name accordling for other new nodes.

### Prepare Node Host
* Create user jenkins, with following permissions
  * Read / Write / Execute under /tools/jenkins
  * Permission to run docker
* `mkdir -p /opt/tools/jenkins/nodes/node-digital-001`
* `cd /opt/tools/jenkins/nodes/node-digital-001`
* Adapt version bundle accordling
  * `export BUNDLE_VERSION=1.1`
* `curl -O https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/service/local/repositories/installers/content/intact/jenkins/jenkins-node-bundle/${BUNDLE_VERSION}/jenkins-node-bundle-${BUNDLE_VERSION}.tgz`
* `tar -xzf jenkins-node-bundle-${BUNDLE_VERSION}.tgz`
* `rm jenkins-node-bundle-${BUNDLE_VERSION}.tgz`

### Configure Node in Jenkins
Please adapt, below, the paths and name to your actual node.

* Go to Manage System > Manage Node > New Nodes
* Node name: `node-digital-001`
* Check Permanent Agent and click OK
* \# of executors: `4`
* Remote root directory: `/opt/tools/jenkins/nodes/node-digital-001`
* Labels: `linux`
* Usage: `Use this node as much as possible`
* Launch method: `Launch slave agents as SSH`
  * Host: `<node-hostname>`
  * Crendentials: `Jenkins Private Key`
  * Host Key Verification Strategy: `Manually trusted key Verification Strategy`
  * Port: `22`
  * JVM Options: `-Dfile.encoding=UTF8 -Djavax.net.ssl.trustStore=/opt/tools/jenkins/nodes/node-digital-001/certs/cacerts.jks`
  * Availability: `Keep this agent online as much as possible`
* Node properties
  * Environment variables > List of variables (`<name>: <value>`)
    * DOCKER_HOST: `tcp://0.0.0.0:2375`
    * MAVEN_OPTS: `-Djavax.net.ssl.trustStore=/opt/tools/jenkins/nodes/node-digital-001/certs/cacerts.jks`
    * MAVEN_SETTINGS: `/opt/tools/jenkins/nodes/node-digital-001/maven/settings.xml`
    * PATH+SCM: `/opt/tools/jenkins/nodes/node-digital-001/rtc-scmtools/rtc-scmtools`
  * Tool Locations > List of tool locations (`<name>: <value>`)
    * (RTC Build toolkit) rtc: `/opt/tools/jenkins/nodes/node-digital-001/RTC-BuildSystem-Toolkit-Linux64/jazz/buildsystem/buildtoolkit`
