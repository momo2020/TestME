# Docker
Docker installation for Jenkins Nodes for Docker pipelines.

# Installation

## Log as root

* Connect to host
* Gain root access: `ingroot`

## Install utilities

* `yum update`
* `yum install -y git`

## Accounts, folders & files

* Create `jenkins` user
* Create mount `/opt/tools/jenkins` with size `400GB`
* User `jenkins` must have all the rights under `/opt/tools`
* Create `/var/lib/docker` with size `50GB`. This volume must be configured for docker (devicemapper)
* Copy from `stha2p333` => new server (same destination, ownership and access)
* `/home/jenkins/.ssh`
* `/opt/tools/jenkins/certs`
* `/opt/tools/jenkins/jazz-scm`
* `/opt/tools/jenkins/maven/*.xml`
* `/opt/tools/jenkins/RTC-BuildSystem-Toolkit-Linux64-6.0.2`
* `/opt/tools/jenkins/rtc-scmtools-6.0.2`
* `/usr/local/bin/oc`
* Symboclic links
  * `cd /opt/tools/jenkins`
  * `ln -s RTC-BuildSystem-Toolkit-Linux64-6.0.2 RTC-BuildSystem-Toolkit-Linux64`
  * `ln -s rtc-scmtools-6.0.2 rtc-scmtools`
* Create empty directory `/opt/tools/jenkinss/nodes/<name-of-node>`

## Install java

* `yum install java`

## Install docker engine

* `yum install docker`

