# Servers

## Jenkins

### National
* stha38b32
  * Integrators / support: Ron Blanchette, Sylvain Charron
  * STHA-PROD-ITMgmt-80
  * [Jenkins National Master](https://prod-jenkins-001.iad.ca.inet)
  * Jenkins National Node 001
  * Windows
* stha38c60
  * Integrators / support: Ron Blanchette, Sylvain Charron
  * STHA-NPROD-ITMgmt-127
  * Jenkins National Node 002
  * Windows
* stha38c61
  * Integrators / support: Ron Blanchette, Sylvain Charron
  * STHA-NPROD-ITMgmt-127
  * Jenkins National Node 003
  * Windows
* mtlb31810
  * Integrators / support: Ron Blanchette, Sylvain Charron
  * Segment ???
  * Jenkins Anjou Node 001
  * Windows
* stha38b92
  * Integrators / support: Ron Blanchette, Sylvain Charron
  * STHA-PROD-ITMgmt-212
  * Jenkins Anjou Node 002
  * Windows
* stha38c18
  * Integrators / support: Ron Blanchette, Sylvain Charron
  * STHA-PROD-ITMgmt-212
  * Jenkins Anjou Node 003
  * Windows
* stha8n086
  * Integrators / support: Serge Landry
  * STHA-NPROD-App-13
  * Jenkins Claims Node 001
  * Linux
* stha38c07
  * Integrators / support: Kannan Muthia
  * STHA-NPROD-ITMgmt-127
  * Jenkins Toronto Node 001
  * Windows

### National Prod
* stha38b33
  * Integrators / support: Oscar Picasso, Guy Dumais
  * STHA-PROD-ITMgmt-80
  * [Jenkins National Master](https://prod-jenkins-001.iad.ca.inet)
  * Jenkins National Node 001
  * Windows

### 2020
* stha38d49
  * Integrators / support: David Bernard, Alex Perkins, Benoit Beaudin, Maxime Lafond
  * STHA-PROD-ITMgmt-80
  * [Jenkins 2020 Master](https://prod-jenkins-2020.iad.ca.inet/)
  * Windows
* stha38d51
  * Integrators / support: David Bernard, Alex Perkins, Benoit Beaudin, Maxime Lafond
  * STHA-PROD-ITMgmt-80
  * Jenkins 2020 Node 001
  * Windows  
* stha38d52
  * Integrators / support: David Bernard, Alex Perkins, Benoit Beaudin, Maxime Lafond
  * STHA-PROD-ITMgmt-80
  * Jenkins 2020 Node 002
  * Windows  
* stha38d53
  * Integrators / support: David Bernard, Alex Perkins, Benoit Beaudin, Maxime Lafond
  * STHA-PROD-ITMgmt-80
  * Jenkins 2020 Node 003
  * Windows  
* stha38d54
  * Integrators / support: David Bernard, Alex Perkins, Benoit Beaudin, Maxime Lafond
  * STHA-PROD-ITMgmt-80
  * Jenkins 2020 Node 004
  * Windows  
* stha38d55
  * Integrators / support: David Bernard, Alex Perkins, Benoit Beaudin, Maxime Lafond
  * STHA-PROD-ITMgmt-80
  * Jenkins 2020 Node 005
  * Windows  
* stha38d56
  * Integrators / support: David Bernard, Alex Perkins, Benoit Beaudin, Maxime Lafond
  * STHA-PROD-ITMgmt-80
  * Jenkins 2020 Node 006
  * Windows  
* stha38d57
  * Integrators / support: David Bernard, Alex Perkins, Benoit Beaudin, Maxime Lafond
  * STHA-PROD-ITMgmt-80
  * Jenkins 2020 Node 007
  * Windows  
* stha8p0d4
  * Integrators / support: David Bernard, Alex Perkins, Benoit Beaudin, Maxime Lafond
  * STHA-PROD-ITMgmt-80
  * Jenkins 2020 Node Linux 001
  * Linux  
* stha8p0d5
  * Integrators / support: David Bernard, Alex Perkins, Benoit Beaudin, Maxime Lafond
  * STHA-PROD-ITMgmt-80
  * Jenkins 2020 Node Linux 002
  * Linux  
* stha8n0fr
  * Integrators / support: Raymond Audet, Oscar Picasso, Guy Dumais
  * Segment STHA-NPROD-ITMgmt-233
  * Jenkins 2020 Node Linux HQQ 001
  * Linux  
* stha8n0bv
  * Integrators / support: Raymond Audet, Oscar Picasso, Guy Dumais
  * Segment ?? (Probably non prod)
  * Jenkins 2020 Node Linux Lab 001
  * Linux  
* stha8n0fk
  * Integrators / support: Raymond Audet, Oscar Picasso, Guy Dumais
  * Segment STHA-NPROD-App-28
  * Jenkins 2020 Node Linux Lab 002
  * Linux  
* stha2p333
  * Integrators / support: Raymond Audet, Oscar Picasso, Guy Dumais
  * STHA-PROD-ITMgmt-212
  * Jenkins 2020 Node Linux Prd 004
  * Linux 
* stha2p358
  * Integrators / support: Raymond Audet, Oscar Picasso, Guy Dumais
  * STHA-PROD-ITMgmt-212
  * Jenkins Digital From Docker Image
  * Linux 

### 2020 Prep
* stha38d50
  * Integrators / support: David Bernard, Alex Perkins, Benoit Beaudin, Maxime Lafond
  * STHA-PROD-ITMgmt-80
  * [Jenkins 2020 Prep Master](https://prod-jenkins-2020.iad.ca.inet/)
  * Windows  

### Billing
* stha38a94
  * Integrators / support: Christine Lambert, Antoine Raymond
  * STHA-NPROD-ITMgmt-127
  * [Jenkins Billing Master](https://billing-jenkins-001.iad.ca.inet)
  * Jenkins Billing Node 001
  * Windows

### Digital
* stha2p358
  * Integrators / support: Raymond Audet, Oscar Picasso, Guy Dumais
  * IT Management Prod
  * [Jenkins Dockerized Master](https://stha2p358.iad.ca.inet:8443)
  * Jenkins Host Node

## Nexus IQ
* stha38c20
  * STHA-NPROD-ITMgmt-127
  * [Nexus IQ Production](https://prod-sonatype-clm.iad.ca.inet:8443)
* stha38c19
  * STHA-PPROD-App-26
  * [Nexus IQ Prep](https://prep-sonatype-clm.iad.ca.inet:8443)

## Nexus Repository Manager

### Version 2.xxx
* stha28a20
  * STHA-PROD-ITMgmt-80
  * [Nexus Repository Manager 2 Production](https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus)
  * Aliases
    * prod-nexus-b2eapp
* stha28a04
  * STHA-PPROD-App-126
  * [Nexus Repository Manager 2 Prep](https://stha28a04.iad.ca.inet:8443/nexus)

### Version 3.xxx
* stha8p0co
  * STHA-PROD-ITMgmt-80
  * [Nexus Repository Manager 3 Production](https://docker-group.iad.ca.inet:8443/)
  * Aliases
    * docker-group
    * docker-immutable
    * docker-mutable
    * TODO - Defined in DNS but need to change certificate to include the domains below since currently
      we get the error: `Error response from daemon: Get https://nexus-3.iad.ca.inet:8473/v1/users/: x509: certificate is valid for docker-mutable.iad.ca.inet, stha8p0co.iad.ca.inet, docker-immutable.iad.ca.inet, docker-group.iad.ca.inet, not nexus-3.iad.ca.inet`
      * docker-release
      * nexus-3
* stha8n0fp
  * STHA-PPROD-App-26
  * [Nexus Repository Manager 3 Prep](https://prep-docker-group.iad.ca.inet:8443/)
  * Aliases
    * prep-docker-group
    * prep-docker-immutable
    * prep-docker-mutable

## SonarQube (currently down)
* stha38c65
  * STHA-NPROD-ITMgmt-127
  * [SonarQube Production](https://sonarqube.iad.ca.inet/)
* stha38c69
  * STHA-NPROD-App-13
  * [SonarQube Prep](https://prep-sonarqube.iad.ca.inet/)

## Jazz/DNG/RTC
### Prod
* stha3p723 (ccm)
* stha3p721 (rm)
* stha3p734 (jts/ldx/gc)
* stha3p722 (dcc)
* stha3p735 (rs)
* stha3p736 (lqe)
* stha38e53 (ihs-1)
* stha38e54 (ihs-2)

### Prep
* stha38e47 (ccm)
* stha38e45 (rm)
* stha38e48 (jts/ldx/gc)
* stha38e46 (dcc)
* stha38e49 (rs)
* stha38e50 (lqe)
* stha38e51 (ihs-1)
* stha38e52 (ihs-2)

## GitHub
