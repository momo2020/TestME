# Versioning And Pruning

## Version Policy & Releases
### Maven
TODO
### Images
TODO
### Others
TODO
## Pruning
### Containers
TODO
### Images
TODO
### OCP Objects
#### Short lived objects
TODO builds, deployements etc.
#### Medium lived objects
TODO pods, others (?)
#### Long lived objects
TODO routes, services etc.