# Backup & Restore - Persistent Volumes For Jenkins
## Backup
### Backup Recipe
* `oc rsync $POD:/var/lib/jenkins $BACKUP_DIR --delete=true --exclude=.groovy*,.java*,.trashcan*,caches*,deadlocks*,fingerprints*,war*,tools*,monitoring*,slow-requests*,jobs**builds*,jobs**workspace* -n $PROJECT`

### Automation Backup - Decentralized Recipe
* Preparation (one time per tools project)
  * Generate account for the project on target linux host
  * Generate ssh keys with no password for the target account: `ssh-keygen -t rsa -b 4096 -f bk_rsa -C "tools-contactpl@no-reply.net"`
  * Add public ssh key to the target account `ssh-copy-id -i bk_rsa jenkins@stha8n0bv`
  * Add private key in Jenkins (Credentials ?)

### Automation Backup - Centralized Recipe
Brainstorming script. To start quickly testing it we can provide a list and run step 4
* Must run on the target Linux box
* Triggered by TSM for backup of all the volumes that need to be backed up
* Steps
    1. Login to OCP Tools
    2. Get all projects
    3. For each project
        1. Retrieve backupable pods
        2. For each backupable pod
            1. Retrieve backupable volumes
            2. For each backupable volume
                1. Append record to list: project, pod, volume mountpath
    4. For every line [project, pod, volume mountpath] list
        1. oc rsync POD:/path localpath
    5. Backup local folder

## Restore
### Restore Recipe
* Prepare Jenkins For Shutdown
* Restore with rsync
  * `oc rsync $RESTORE_DIR/jenkins $POD:/var/lib/jenkins --delete=true -n $PROJECT`
* Deploy Jenkins

### Restore Automation
## Test Backup / Restore
TODOs: Automated backup / restore test
## Upgrade Procedure
TODO
