# OpenShift API Objects

## Characteristics of OpenShif API Objects

### Update Frequencies
Below the OpenShift API Objects based on the frequencies of their expected updates.

Dependending on their frequency we may want to put them in different places in the workflow, or in different pipelines or different templates.
We may want also to redeploy some of the everytime to simplify configurations, that is to reduce the number of templates (ex. routes, services).
* One Time
  * Should be created only time if the recipe is clear. Update should me made only if there was a mistake on creation.
* Sometime
  * May need some upate during the lifecycle of an application
* Every new deploy
* Every new build

### Cardinalities
Depending on the cardinalities we may decide to include corresponding objects in different templates and deploy them at different point in time.
* Cardinality Object x OCP Project
* Cardinality Object x Application

## API Object
* General
  * Templates
  * Pipeline models
  * PersistentVolumes
* Project
  * Update frequency: one time for all environment (may add other environments)
  * ServiceAccounts
  * RoleBindings
* Application
  * One time creation
    * Service
    * Route
    * Endpoints (implicit)
    * ImageStreams (where to put ImageStreamTags and ImageStreamImages?)
  * Some updates
    * Secrets
    * Configmap
  * Build
    * BuildConfig: some changes, tweaking, new versions
    * Build: change on every new build, implicit
  * Runtime
    * DeploymentConfig
    * ReplicationController (implicit)
  