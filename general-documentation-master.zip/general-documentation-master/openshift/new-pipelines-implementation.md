# New Pipelines Implementation

## Working session TO-BE-SCHEDULED
### CLSE
* Backup / Restore
  * rsync-jenkins account created on all projects
  * backup / restore pipelines uses now jenkins@stha2p358 
  * restore path is now /var/lib/pvc-backups/pvc-restore
  * script to retrieve token
* Credentials
  * Do not use generated ids for credentials.
  * Use explicit names with naming conventions
* Image management
  * Use docker-release only for released images
  * Do not use SNAPSHOT version convention
  * Build images in OCP
  * Store images in development in OCP
  * Nexus 3 used only to:
    * To store intact released images in docker-release
    * To retrieve some external curated images from docker-group. This should be rare.
  * For all released image reference them from docker-group
  * For all non release image reference them from your NP registries
* Parallelism / tokens

## Working session 2018-03-22
### Digital, ContactPL, Rating Rev
* Backup / Restore
  * rsync-jenkins account created on all projects
  * backup / restore pipelines uses now jenkins@stha2p358 
  * restore path is now /var/lib/pvc-backups/pvc-restore
* Promote
  * Promote correction last tagging
    * Use POST_DEPLOY_IMAGE or always use the destination project inside the image name we tag

## Working session 2018-03-16
### CLSE
* Backup / Restore
* Cleanup workspace
* Promote
  * Nexus 3 release account
  * Credentials
  * Nexus Token
* Official image
* Service Account Token
* Tracking 
  * Agenda in GitHub
  * ocp-tools-utils
  * ocp-build-deploy-promote

## Working session 2018-03-15
### Digital, ContactPL, Rating Rev
* __TODOS__
* Création compte de service locaux
  * rsync-jenkins sur tous les project OCP Tools (pour backup)
  * ocp-jenkins dans les projets rqq-dev, rqq-intg et misc-image-builds avec mêmes permissions que le compte ocp-jenkins-np-rqq. 
  * Permettre un pull à partir de tous les projets np des images dans misc-image-builds.

* Images releases
  * Account for Nexus 3: local or LDAP
  * User Token in credentials
  * Activity Disable redeploy
  * Cleanup release registry of snapshot
    * Confirm Sonatype Procedure
    * Delete all -SNAPSHOT in release at any time
* Backup / restore 
  * Restore 
    * No auto restart
    * Test if zombie
  * Isolation on the filesystem (several accounts?)
  * OCP Service Accounts and Tokens
    * Usage example
      * Rsync for backup / restore
      * To replace ocp-jenkins-xx-yy in oc commands 
        * Avoid login
        * Possible solution to paralelism issue
    * Manual or playbook ?
    * What to do with existing
    * Recipe to get token
* Best Practices OCP Tools
  * Health
  * Kill zombies in pods?
  * Scale 0 before deletion
    * oc scale does not work with dc
      * Use patch or
      * Use UI
  * Force kill pods (Terminating)
* Garbage Collection Next Steps
  * Check pruning  
  * TODO 
* SE Team Agenda 
  * Parameters company, release, province
    * Service name length
    * Template BC, DC
  * Service account for skopeo (e.g. ubi)
  * Misc-build project
  * login TOKEN for oc commands

## Working session 2018-03-05
* Status
* Tasks
* Information exchanges

### Changes
* backup / restore
   * pipeline backup: **done to be tested**
   * restore 
     * in place restore: **almost done**
     * A / B restore without routing from single url: **good progress**
     * A / B restore with routing from single url: **to be done**
* parallelism
  * do not use login but instead always use for oc command, `--serve=$url --token=xxxxx` connect params 
    * **poc done**
    * **TODO** with Erik Lalancette (see best strategy)
      * needs OCP service account & inside project 
      * need to retrieve service account token in OCP Project: 
          * rsync-jenkins > yaml > rsync-jenkins-token-1dmmw
          * secrets > rsync-jenkins-token-1dmmw -> reveal secret > token -> debase64
  * ocp-tools-utils/test/test-parallelism.groovy **done, but needs improvement to systemically test the issue**
* cleanup Nexus 3 release registry
* clean jenkins
    * ocp-tools-utils/cleanup.groovy **pipeline fragment. move to shared lib? more cleanup?**
* prepare easy Jenkins upgrade procedure based on restore A / B 
* monitor changes configs and impact on xmls in in JENKINS_HOMES 

### Corrections since last session
None currently

### Todos
* docker release service account in Nexus 3: which one to use? Currently uses temporary local accounts like ocp-jenkins-nexus3-release-rqq
* garbage collection images and OCP objects
* jenkins master upgrade strategy

### Technical debt
* first deploy / promote / rollout => automatic triggers ?
* cleanup credentials (more explicit credential names?)
* migrate build, deploy & promote history logging

### Questions 
* What is the status of inter cluster promotes?

### Links
* [Templates & pipelines](https://githubifc.iad.ca.inet/Intact/ocp-build-deploy-promote.git)
* [Secrets & access](https://githubifc.iad.ca.inet/pages/DevTools/general-documentation/openshift/build-deploy-promote.html)
* [OCP Tools](https://ocp-tools-master.iad.ca.inet:8443)
* [OCP Tools Utils (backup, restore, cleanup...)](https://githubifc.iad.ca.inet/Intact/ocp-tools-utils.git)
* [Service test](https://githubifc.iad.ca.inet/Intact/sandbox-ocp-direct-build-cycle.git)<br/>See branch recette-1
