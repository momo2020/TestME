# OpenShift Tools
OpenShift Tools is typically used for Jenkins usage. 

## OCP Service Accounts
This services accounts are defined directly in OCP as opposed to those defined in LDAP.
### (New) Usage
 These services accounts are used for:
* For the backup and restore pipeline. This the rsync-jenkins account.
* To replace all the ocp-jenkins-xxx-yyy for all oc operations in the pipeline. This allows:
  * To avoid the need to login to an OCP Cluster, thus maybe solving parallelism issues.
  * To use tokens instead of actual username/passwords. Example: `$ oc get secret rsync-jenkins-token-1dmmw -o go-template --template='{{.data.token}}' | base64 -d -n myproject`

### Howto
Service account [scripts](https://githubifc.iad.ca.inet/DevTools/bash-scripts/tree/master/openshift). Include create, add edit role and retrieve token.

## Jenkins Services Account

* ocp-jenkins-np-[team], example ocp-jenkins-np-digital
  * Used to connect to OpenShift np projects from Jenkins
  * Used to connect to GitHub from Jenkins in the context of OpenShift pipelines
  * Must have access to GitHub
  * Must have edit role in the related OCP projects in the target cluster. Example: ocp-jenkins-np-contactpl must have edit role in contactpl-dev, contactpl-intg, contactpl-uat (but not contactpl-prod)
* ocp-jenkins-prod-[team], example ocp-jenkins-prod-digital
  * Used to connect to OpenShift prod projects from Jenkins
  * User to push released images to Nexus 3
  * Must be part of the `nexus-developer` LDAP group

## Service Account Password Management
* Owned by the SE team, usually a senior integrator of the team (example David Bernard for ocp-jenkins-xx-contactpl)
* Password management should be done by a Notes tiles. Owner must provide access to the password the users that need to access the passwords.
* It is advised to limit access to the password, usually to integrators from its team
* And also, but only for ocp-jenkins-np-xxx accounts to the following members of the tools team: Ghyslain Cloutier, Guy Dumais, Oscar Picasso
* These service accounts are typically added as credentials to the Jenkins instance of the SE team used for its OCP pipelines

## LDAP Groups
*  ocp-np-[team]-admin example ocp-np-digital-admin
*  ocp-prod-[team]-viewer example ocp-np-digital-viewer

## OCP Tools Create Form
### Typical Values
* What is the project name? `tools-iqq`
* Provide a project description.`Some description`
* What is the integrator email address? `some address`
* Which node selector the new project will be assigned on? `appsrv`
* What will be the Jenkins user (pattern = ocp-jenkins-np-yourteam)? `ocp-jenkins-np-iqq`
* Provide the admin Tam group for the project (pattern = ocp-np-yourteam-admin)? `ocp-np-iqq-admin`
* Provide the view Tam group for the project (pattern = ocp-np-yourteam-viewer)? `ocp-np-ubi-viewer`
* What is the the CPU quota for your project? `4 cores`
* What is the the memory quota for your project? `10 GB`
* What is the the storage quota for your project? `15 G`

### Form
![alt text](../images/ocp-tools-create-form.jpg "OpenShift Tools Create Form")
