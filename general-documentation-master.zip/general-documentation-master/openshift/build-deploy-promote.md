# Build, Deploy & Promote with OpenShift

## Service Accounts & Roles
For every new project we need to create some secrets various services accounts and add some roles to perform the build, deploy and promotions.

## Roles to enable projects to pull images from other projects
To allow infra cluster promotes we need to allow any potential destination project of a promote to pull images from any releated potential origin project of this promote. For example, assume we have a base project called `mywebservice` that could be promoted from or to any of the following environment `dev`, `int`, `uat`, we need to execute the following commands:

* `oc policy add-role-to-group system:image-puller system:serviceaccounts:mywebservice-intg -n mywebservice-dev`
* `oc policy add-role-to-group system:image-puller system:serviceaccounts:mywebservice-uat -n mywebservice-dev`
* `oc policy add-role-to-group system:image-puller system:serviceaccounts:mywebservice-dev -n mywebservice-intg`
* `oc policy add-role-to-group system:image-puller system:serviceaccounts:mywebservice-uat -n mywebservice-intg`
* `oc policy add-role-to-group system:image-puller system:serviceaccounts:mywebservice-dev -n mywebservice-uat`
* `oc policy add-role-to-group system:image-puller system:serviceaccounts:mywebservice-intg -n mywebservice-uat`

## Access to GitHub from OpenShift
* Configure access right to deploy from Intact GitHub 
  * github-openshift must have read access to the source repository defined inside the BuildConfig
  * `ssh-keygen -t rsa -C github_openshift_no_pass -f /$HOME/.ssh/id_github-openshift_no-pass_rsa` 
  * Add generated public key to github-openshift settings in Intact GitHub.
  * Upload the secret key to OpenShift: `oc secrets new-sshauth sshsecret --ssh-privatekey=$HOME/.ssh/id_github_openshift_no-pass_rsa`
  * Provide this key to the build service account: `oc secrets add serviceaccount/builder secrets/sshsecret`
  * References
    * [Deploying From Private Git Repositories](https://blog.openshift.com/deploying-from-private-git-repositories/)
    * [Private Git Repositories: Part 1 – Best Practices](https://blog.openshift.com/private-git-repositories-part-1-best-practices/)

## Access to Nexus 2 from OpenShift
A command in the Dockerfile retrieve the war during the build from Nexus 2. We need to configure the token used to connect to Nexus 2 as OpenShift secrets. 
* We will use the account nexus2-openshift-local
* This account will be deleted once s2i is implemented
* This account is create locally in Nexus 2. It is not in LDAP.
* We will use its tokens as credentials
* Secret configuration
  * Retrieve tokens
    * Login to nexus 2 as nexus2-openshift-local
    * Go to Profile > User Token > Access User Token. Once you the nexus2-openshift-local you will be displayed with the tokens in a settings snippet. You can then copy these credentials tokens for use in configuring the nexus 2 secret below.
  * Create secret in OpenShift
    * `echo -n "<username token>" > ./nexus2-username-token`
    * `echo -n "<password-token>" > ./nexus2-pass-token`
    * For every project that perform a build
      * `oc create secret generic nexus2-secret --from-file . -n mywebservice-dev`
      * `oc secrets add serviceaccount/builder secrets/nexus2-secret -n mywebservice-dev`

## Read access to Nexus 3 from OpenShift
To access FROM images during the build, we need to add the Nexus 3 password as secret inside OpenShift.
The service account is `nexus-openshift`.

## Write to Nexus 3 (releases) from Jenkins
The `ocp-jenkins-prod-xxx` service accounts are used to push golden images to the release registry in Nexus 3.
These accounts must be member of the `nexus-developer` LDAP group.

## Access to OCP from Jenkins
Every team has its own jenkins service account that is used to connect from Jenkins to OCP to trigger build, deploys and promotes in OpenShift.
This service must have the edit role in OpenShift.
 This services account has the pattern `ocp-jenkins-<env>-<team>` example `ocp-jenkins-np-rqq`. The list of currently defined service accounts is [here](../security/ldap.md) 

 This service account is also used to connect from the Jenkins pipeline to git to retrieve the actual ocp templates.

<!--#### Configuration 
* All build configuration is inside the source code of the project (for example the war maven project)
* Build configuration includes
  * A Dockerfile
  * The content needed to build the image
  * The OCP yaml BuildConfig<br/>
  An example of a very [Simple Build](https://githubifc.iad.ca.inet/Sandbox/ocp-simple-build/blob/master/ocp-simple-build-bc.yaml). Take note: 
    * The source is a git repository (in that the same repository that contains the BuildConfig) and 
    * The output is an ImageStream. The ImageSteam needs to exist before creating the buid config. A very simple [Image Stream](https://githubifc.iad.ca.inet/Sandbox/ocp-simple-build/blob/master/ocp-simple-stream-is.yaml) 
    * Both BuildConfig, ImageStream and other objects could be defined in templates instead actual root level yaml.

#### Execute Build
* Clone source: `git clone git@githubifc.iad.ca.inet:Sandbox/ocp-simple-build.git`
* Create ImageStream (one time): `oc apply -f ocp-simple-stream-is.yaml`
* Create BuildConfig (first time, and only if build config has config has changed): `oc apply -f ocp-simple-build-bc.yaml`
* Start build: `oc start-build ocp-simple-build-bc`
* Logging & Debugging
  * Look at the build config yaml generated in OCP can give you information (for exampe some error)
  * On starting the build
  * `oc status -v`
  * `oc get events`
  * `oc logs bc/ocp-simple-build`
  * In the console, look at the log inside the builder pod created when the build started
-->
