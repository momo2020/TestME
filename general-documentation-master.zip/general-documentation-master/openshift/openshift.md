# Openshift

## Project Administrators Responsabilities
Project administrators have a lot of power on their project. With that comes great responsability in particular it is the responsability of the project administrator to make their project work. If modifications are done on the project, OpenShift SME support will be based on the best effort and the responsability will be still on the project administrator. 

As a project administrator, please respect the following rules:
* Never edit the project membership section. Either to change permissions, or add or remove users and groups. If you have permissions issues related to a user ensure the user is in the correct LDAP group for its expected rights or contact your OpenShift Cluster administrator.

Please complete this section with the new rules you find important to follow to avoid to put OpenShift projects in jeopardy.

## Command Line

### Installing the command line tools (CLI)
* Download the lastest release from https://access.redhat.com/downloads/content/290
* Copy oc.exe to a folder configured in your environment path.
* `Copy oc.exe and oc.sh to C:\Apps\openshift`.

#### How to configure your environment PATH
* Press `Windows + Pause` on your keyboard.
* Choose `Advanced system parameters` > `Environment Variable` > `PATH`.
* Add `C:\Apps\openshift` at the end of the `PATH` value.
* Open the command prompt `CMD` or `PowerShell`.
**Note: if you had a command prompt already opened please close it and re-open a new one.**
* Verify if the environment has been updated by typing `PATH` in the command prompt and press `Enter`.
* Type `oc` and press `Enter`.
* If everything was setup correctly you should see `OpenShift Client`.
* Reference : [command line](https://ocp-np-master.iad.ca.inet:8443/console/command-line)

### How to use the CLI
* Login into the system with `oc login` and enter your LDAP credentials for the `username` and `password`.
* Use `oc project <project-name>` to navigate between projects.
* Type `oc status` to get an overview of the current project.
* To create a new project type `oc new-project <project_name>`
* to create a new app use `oc new-app <source code path>`
* Reference : [basic CLI operations](https://docs.openshift.com/container-platform/3.3/cli_reference/basic_cli_operations.html)

## Web UI

### How to use the Web UI
* You can access the UI by following one of these links:
  *  [Non Production (OCP-3.3)](https://ocp-np-master.iad.ca.inet:8443/)
  *  [Pre Production (OCP-3.3)](https://ocp-prep-master.iad.ca.inet:8443/)
  *  [Production (OCP-3.3)](https://ocp-master.iad.ca.inet:8443/)
  *  [Non Production (OCP-3.6)](https://ocp-np-a-master.iad.ca.inet:8443/)  
  *  [Pre Production (OCP-3.6)](https://ocp-prep-a-master.iad.ca.inet:8443/)  
  *  [Production (OCP-3.6)](https://ocp-a-master.iad.ca.inet:8443/)    
  *  [Tools](https://ocp-tools-master.iad.ca.inet:8443/)
  *  [Lab A](https://ocp-lab-a-master.iad.ca.inet:8443/)
* After a successful login, you should be greeted by a list of projects to which you have access (e.g. rqq-dev, rqq-intg, etc).
* Select a project.

### Overview
* The overview screen will show every application in the current project.
* For every applications are listed the following informations:
    * The number of active pods 
    * The image used for the container
    * The listening ports
    * The time elapsed since the last deployment of the container.

### Applications Menu
* `Deployments`: list all the deployments
* `Pods`: list all the active pods. 
Every applications has their own unique name (e.g. crs-endpoint-XX-YYYYY) generated automatically at the deploy stage.
** Those are the two most used page when you connect to OpenShift. We will skip the other menus for now.

### PODS
* In this view you can get an overview of the status of every active containers.
* During a deployment of an application, you will see two entries for the same application.
    * `crs-endpoint-deploy` and `crs-endpoint-XX-YYYYY`
    * `crs-endpoint-deploy` will disappear once `crs-endpoint-XX-YYYYY` is stable.
* If an instance of `crs-endpoint` was already active, it will also disappear once the new instance is up and running.
* Select a pod.
* At the top of the page you will see the labels associated with the pod.
`artifactId`, `configMapLongVersion`, `configMapVersion`, `deployment`, `deploymentconfig`, `groupId`, `name`, `projectLongVersion` and `ProjectVersion`
* From this page you have access to the `Readiness` and `Liveness` Probe.
    * `Readiness Probe`: Check if the container is ready to accept requests (Is the container ready to answer?).
        > "A readiness probe determines if a container is ready to service requests. If the readiness probe fails a container, the endpoints controller ensures the container has its IP address removed from the endpoints of all services. A readiness probe can be used to signal to the endpoints controller that even though a container is running, it should not receive any traffic from a proxy. Set a readiness check by configuring the template.spec.containers.readinessprobe stanza of a pod configuration."

    * `Liveness Probe`: Check if the container is still running, if it is not the container is killed and subjected to the restart policy.
        >"A liveness probe checks if the container in which it is configured is still running. If the liveness probe fails, the kubelet kills the container, which will be subjected to its restart policy. Set a liveness check by configuring the template.spec.containers.livenessprobe stanza of a pod configuration."

    Reference: [Application Health](https://docs.openshift.com/enterprise/3.1/dev_guide/application_health.html)

* The `Logs` and `Terminal` tabs are mostly used for troubleshooting. 
The `terminal` gives a direct access to the container via a `sh` command interpreter or a `bash` shell
    > Use the terminal with caution, since it gives you a direct access to the application in the container.
