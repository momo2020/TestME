# Docker Pipelines

## Docker Cleanup

* `docker rm -vf $(docker ps -f 'status=exited' -qa)`
* `docker rmi $(docker images --filter dangling=true -q 2>/dev/null)`

## Nodes

### node-2020-linux-hqq-001
* host: stha8n0fr
* Docker version: 1.12.1, build 23cf638
* [jenkins configuration](https://prod-jenkins-2020.iad.ca.inet/computer/node-2020-linux-hqq-001/)
* jenkins build user
  * username: tooluser
  * connection (assumes private ssh key): `ssh tooluser@stha8n0fr -i .ssh/jenkins/id_rsa`
  * Maximum number of days between password change: -1

### node-2020-linux-lab-001
* host: stha8n0bv
* Docker version: 1.12.1, build 23cf638
* [jenkins configuration](https://prod-jenkins-2020.iad.ca.inet/computer/node-2020-linux-lab-001/)
* jenkins build user
  * username: jenkins
  * connection (assumes private ssh key): `ssh jenkins@stha8n0bv`
  * Maximum number of days between password change: 60
* other tools
  * ELK

### node-2020-linux-lab-002
* host: stha8n0fk
* Docker version: 1.12.1, build 23cf638
* [jenkins configuration](https://prod-jenkins-2020.iad.ca.inet/computer/node-2020-linux-lab-002/)
* jenkins build user
  * username: jenkins
  * connection jenkins build user (assumes private ssh key): `ssh jenkins@stha8n0fk`
  * Maximum number of days between password change: 60

### node-2020-linux-prd-004
* host: stha2p333
* Docker version: 1.10.3, build 5206701-unsupported
* [jenkins configuration](https://prod-jenkins-2020.iad.ca.inet/computer/node-2020-linux-prd-004/)
* jenkins build user
  * jenkins
  * connection (assumes private ssh key): `ssh jenkins@stha2p333`
  * Maximum number of days between password change: 60
