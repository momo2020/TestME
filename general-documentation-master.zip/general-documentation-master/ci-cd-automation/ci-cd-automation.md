# CI/CD & Automation

## Jenkins 
### Jenkins Organization
* New Item > GitHub Organization (Name = The Organization ex. Intact)
    * GitHub Organization	> API endpoint: Intact GitHub
    * Owner: The Organization (Example: Intact)
    * Credentials: build-maven (GitHub Token)
    * Default for all other properties:
        * Discover branches
            * Strategy: All branches
        * Discover pull requests from origin
            * Strategy: Merging the pull request with the current target branch revision
        * Discover pull requests from forks
            * Strategy: Merging the pull request with the current target branch revision

### Jenkins User Organization
* Jenkins > My Views > (choose a view) > New Item > GitHub Organization (Name = username ex. opicasso)
    * GitHub Organization	> API endpoint: Intact GitHub
    * Owner: your username
    * Credentials: build-maven (GitHub Token)
    * Default for all other properties:
        * Discover branches
            * Strategy: Exclude branches that are also filed PRs
        * Discover pull requests from origin
            * Strategy: Merging the pull request with the current target branch revision
        * Discover pull requests from forks
            * Strategy: Merging the pull request with the current target branch revision
  
## GitHub
### GitHub Organization
* Settings > Hook > Webhooks
    * Payload URL: https://prod-jenkins-2020.iad.ca.inet/github-webhook/
    * Content type: application/x-www-form-urlencoded
    * Let me select individual events:
        * Pull request
        * Push
        * Repository
    * Active
    
### GitHub Repository
* Settings > Branches > Protected branches > Choose a branch... (choose one)
    * Protect this branch
        * Require pull request reviews before merging
            * Dismiss stale pull request approvals when new commits are pushed
        * Require status checks to pass before merging
            * Require branches to be up to date before merging
            * _Status checs found in the last wee for this repository_
                * continuous-integration/jenkins/branch
                * continuous-integration/jenkins/pr-merge
        
    