# Graddle

## Installation
This should include tools configuration if any: 

* IDE
* Jenkins
* Nexus Settings
* DSM

## Benefits
This section should contain only proven benefits in the context of Intact project.

## Integrations

### Continuous Integration - Jenkins

### Integration with Nexus IQ