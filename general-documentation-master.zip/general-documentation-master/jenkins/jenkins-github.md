# GitHub Organization Folder

### How to create a Basic GitHub Organization Folder in Jenkins
* Open Jenkins
* In the menu select `New Item` > `Define a name` > `GitHub Organization`.
* Specify a `Display Name`.
* API endpoint `Intact Github POC`.
* In the `Owner` input box, enter the GitHub Organization to be watched.
* For `Scan credentials` choose `build-maven` in the dropdown menu.
* `Repository name pattern` the default value is set to monitor every repository under the specified `organization`.
* Leaving the subsequent sections by default should be OK for most project.

### Setup Webhook on the GitHub Organization
* Go to [GitHub](https://githubifc.iad.ca.inet/).
* Navigate to the `Organization`.
* Access the organisation's `settings` page.
* In the menu select `Hooks`, then `Add webhook`.
* Add the webhook url `https://prod-jenkins-2020.iad.ca.inet/github-webhook/` into the `Payload URL` inputbox.
* **NOTE: You should use exactly this URL, the "/" shouldn't be neglected.**
* The `Content type` value should be set to `application/x-wwww-form-urlencoded`.
* You should configure the events that will trigger the webhook. By default, only push event will trigger the webhook.
* We suggest using the option `Let me select individual events` with these options:
  * `Pull request`
  * `Push`
  * `Repository`
* Make sure build-maven has access to the repository or jenkins won't be able to update the build status to GitHub.
  * Add build-maven as a team member associated to the repository. The user should have write access.
  * Without write access the user won't be able to commit the status change to GitHub.
  
### Setup Protected Branches
* Navigate to the `Settings` page of a `Repository`.
* Select the `Branches` option in the left menu.
* Under the Protected branches section, in the dropdown menu, select the `branch` you want to protect.
* Check `Protect this branch`.
* Check `Require pull request reviews before merging`.
* Check `Require status checks to pass before merging`, this will require a successful Jenkins build of the project subjected to the pull request.
  * Check `Require branches to be up to date before merging`, this will assure the code is up-to-date with the branch and will detect conflicts. Note: this option will be visible once the previous one (`Require status checks to pass before merging`) is checked.
