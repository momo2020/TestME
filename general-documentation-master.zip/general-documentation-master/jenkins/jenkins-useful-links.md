# Jenkins Useful Links

* [Jenkins Best Pratices Java Options 	:Tuning Jenkins GC For Responsiveness and Stability with Large Instances](https://jenkins.io/blog/2016/11/21/gc-tuning/)
* [Java Flight recorder](https://docs.oracle.com/javase/8/docs/technotes/guides/troubleshoot/tooldescr004.html)
* [7 Ways of Optimize Jenkins](http://web-static-cloudfront.s3.amazonaws.com/whitepapers/7WaysToOptimizeJenkins.pdf)
