# Jenkins in Openshift
## Build &amp; Deploy Jenkins Master Image
### Build
#### Steps
1. Clone jenkins-rhel-base repository: `git@githubifc.iad.ca.inet:DockerBaseImages/jenkins-rhel-base.git`
2. Checkout the desired branch. It should not be ocp since ocp is the production branch.
3. Update `bin/var-build.sh` accordingly.
4. Commit and push your changes
5. Run `bin/build-jenkins-image.sh` 

#### Build time customization
__TODO more...__
* Traceability
  * Image tag, image id
  * Git commit id
  * Git tag (for releases)
* Message from Tools to Team in general description
  * Rules, roles &amp; responsabilities
* List of plugins
  * List of default plugins in RHEL
  * List of added plugins during the build (plugins.txt)  
  * Make easy list easy to read and find in the backups and the running instance
* jenkins-manangement folder
  * Description DO NOT delete or change
  * backup
  * restore
  * cleanup fragment
  * other __TODO?__

### Deploy
#### Steps
1. Clone jenkins-rhel-base repository: `git@githubifc.iad.ca.inet:DockerBaseImages/jenkins-rhel-base.git`
2. Checkout the desired branch. It should not be 
  * ocp since ocp is the production branch.
3. Update `bin/var-deploy.sh` accordingly.
4. Run `bin/deploy.sh` 

### Live instance
__TODO__
Display traceability information

#### Runtime customization
__TODO more...__
* Name instance in description
* Email admin recipient
* Plugins list for some teams. This solve the need to have custom image with different plugins

### Misc script
The bin directory contains other usefull scripts: clenaup, list etc.

## Plugins management
TODO Insert here all your findings about managing plugins in OPC Jenkins. See [documentation](https://github.com/openshift/jenkins)

### Plugin related envirnoment variables
Needs testing. 

* OVERRIDE_PV_PLUGINS_WITH_IMAGE_PLUGINS
* INSTALL_PLUGINS ldap:1.15 

## Utils
* oc rsh jenkins-5-f0750  java -jar //var//lib//jenkins//war//WEB-INF//jenkins-cli.jar -s http://localhost:8080/ -auth [user]-admin:[token]list-plugins > /c/data/tools-lab-se_plugins.txt 

## Backup, restore, upgrades, rollback 
### Use cases
#### In place rollback to previous state
##### Goal
The goal is to restore the Jenkins instance, in place, to a previous state. Both the image, the plugins, configurations will be restored in a chosen previous state 
This may be needed because, for example in case of:
* Catastrophic failure either at the cluster level or Jenkins instance level
* Big mistake in configuration that makes the instance install or make it difficult to rollback by other means.

##### What is restored?
Ideally everything from a previous state:
* Image
* Plugins
* Configurations
  * General Jenkins configurations 
  * Plugin configurations
  * View, folders configurations
  * Jobs configurations
  * Credentials. We can restore the credentials entries but their values must reentered manually
* All OCP relevant objects including service, route, pvc etc. This includes the names of these object. 

##### Steps
1. Restore previous backup either directly from the backup filesystem or from TSM. The restore is copied inside `/var/lib/pvc-backups/pvc-restore/[ocp-project]/[jenkins-instance-name]`
2. Retrieve complete image name from restored files __TODO: where exactly to find it__
3. Delete everything from current deployment
4. Deploy image using image name retrieved at step 2
5. Perform full restore on deployed image from the restore pipeline in the image itself. Restore options:
  * _OVERRIDE_CREDENTIALS_ must be checked since we start from scracth to at least have the actual credentials entries. We will still need to enter manually the secret on the live instance. 
  * _REMOVE_ALL_BUILDS_ since we start from scratch this option is irrelevant. Can be left unchecked.

#### Restore a live instance to another new instance
##### Goal
To test the effects of changes on existing instances This changes we want to test can be:
* Master upgrade
* Plugin upgrade
* Plugin addition
* Plugin deletion

##### What is restored?
Ideally almost everything from from the live instance, execpt the names.
* Image
* Plugins
* Configurations
  * General Jenkins configurations 
  * Plugin configurations
  * View, folders configurations
  * Jobs configurations
  * Credentials. We can restore the credentials entries but their values must reentered manually
* All OCP relevant objects including service, route, pvc etc. This __DOES NOT__ includes the names of these object. 

##### Steps
1. Restore the live instance usually directly from the backup filesystem. The restore is copied inside `/var/lib/pvc-backups/pvc-restore/[ocp-project]/[new-jenkins-instance-name]`
2. Retrieve complete image name from restored files __TODO: where exactly to find it__
3. In the relevant configurations, change hard coded references from _live-instance-jenkins-name_ and _live-instance-ocp-project_ to _new-instance-jenkins-name_ and _new-instance-ocp-project_ __TODO: list configurations to update, write script to do it?__
3. Deploy image using image name retrieved at step 2
4. Perform full restore on deployed image from the restore pipeline in the image itself. Restore options:
  * _OVERRIDE_CREDENTIALS_ must be checked since we start from scracth to at least have the actual credentials entries. We will still need to enter manually the secret on the live instance. 
  * _REMOVE_ALL_BUILDS_ since we start from scratch this option is irrelevant. Can be left unchecked.

## Upgrades &amp; rollbacks (Work in progess)
### Side effects
* Image
  * Effect on general configuraiton
  * Effect on plugins versions
     Effect on plugins configurations
  * Intact customization
    * General customization (description, credentials placeholder)
    * Folders, jobs / pipelines
* Plugins
  * Add plugins
  * Delete plugins
  * Update plugins
    * Effect on plugin configurations

### In place master upgrade with A/B test phase
#### Steps
We assume jenkins-instance-a is running at tools-project. This upgrade will keep history. It is quite similar to what we do in legacy tools.
It makes rollback less trivial than `A/B master upgrade`
1. Backup jenkins-instance-a. The backup will be on `stha2p358` at `/var/lib/pvc-backup/tools-project/jenkins-instance-a`
2. Copy `/var/lib/pvc-backup/tools-project/jenkins-instance-a` to `/var/lib/pvc-backup/pvc-restore/tools-project/jenkins-instance-b`. Ensure before destination is empty.
3. In the relevant configurations, change hard coded references from _jenkins-instance-a_ to _jenkins-instance-b_
__TODO: list configurations to update, write script to do it?__
4. Deploy __original master__ as `jenkins-instance-b`
5. Restore
6. Deploy __new master__ as `jenkins-instance-b`
7. Test __TODO Automation___
8. Deploy __new master__ as `jenkins-instance-a`
9. Cleanup `jenkins-instance-b` after some delay

#### Rollback
1. Cleanup `jenkins-instance-b`
2. Copy to `/var/lib/pvc-backup/pvc-restore/tools-project/jenkins-instance-b` to `/var/lib/pvc-backup/pvc-restore/tools-project/jenkins-instance-a`. Ensure before destination is empty.
2. Deploy __original master__ as `jenkins-instance-a`
3. Restore

### A/B master upgrade
#### Steps
We assume jenkins-instance-a is running at tools-project. This is a variation on _In place master upgrade with A/B test phase_ but it will __not__ keep history.
On the other hand it make rollback trivial since the previous version is still up and running.
1. Backup jenkins-instance-a. The backup will be on `stha2p358` at `/var/lib/pvc-backup/tools-project/jenkins-instance-a`
2. Copy `/var/lib/pvc-backup/tools-project/jenkins-instance-a` to `/var/lib/pvc-backup/pvc-restore/tools-project/jenkins-instance-b`. Ensure before destination is empty.
3. In the relevant configurations, change hard coded references from _jenkins-instance-a_ to _jenkins-instance-b_
__TODO: list configurations to update, write script to do it?__
4. Deploy __original master__ as `jenkins-instance-b`
5. Restore
6. Deploy __new master__ as `jenkins-instance-b`
7. Test __TODO Automation___
9. Cleanup `jenkins-instance-a` after some delay. The official instance is now `jenkins-instance-b`. 

#### TODOs
* Generic routing
* Keep history

#### Rollback
1. Just use `jenkins-instance-a` which was not changed.
2. Cleanup `jenkins-instance-b` after some delay. The official instance is now `jenkins-instance-a`. 

### Plugin Upgrades
__TODO__

## General process
* Any deployment must be done from a released image (unless we are testing the new image)
* The backup must identify the image used
  * With its name / tag and
  * With its id
* The backup must identify the source origin
  * With it git commit id
  * With it git release tag
* A released image must be tagged in GitHub
* A release image must be deployed in the docker-release registry
* The _jenkins-rhel-base_ production branch is _ocp_. All development mut be done in separate branches.

