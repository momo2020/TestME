# LDAP Groups
* Nexus Repository Manager
  * nexus-administrator
    * Administrator for all Nexus Repository managers (versions 2 & 3), Nexus IQ, and Jenkins
  * nexus-developer
    * Read access on all Nexus 2 & 3 repository instances, Nexus IQ and Jenkins
    * Write acces to some Nexus 2 & 3 hosted repositories
    * Run Jenkins builds
    * Some Jenkins instance allow also for job configuration
  * nexus-integrator
    * Same as nexus-developer + procurement on Nexus repository managers
    * Extended right on Jenkins: job configuration etc.
    * Restricted: reserved to power integrators
  * nexus-visitor
* Nexus IQ
  * nexus-iq-policy-manager
* Jenkins
  * jenkins-developer
  * jenkins-integrator
  * jenkins-administrator
* OpenShift
  * ocp-prod-super-admin
  * ocp-np-super-admin
  * ocp-tmp-super-admin
  * ocp-np-contactpl-viewer
  * ocp-np-contactpl-admin	
  * ocp-np-digital-viewer
  * ocp-np-digital-admin
  * ocp-devtools-viewer
  * ocp-devtools-admin
  * sysdig-contactpl (acces au team sysdig contactpl)
  * sysdig-ops  (acces au team ops qui aura tout les namespace et host)
  * sysdig-rqq (acces au team sysdig rqq)
* RTC
  * JazzAdmins
  * JazzUsers
  * JazzDWAdmins
  * JazzProjectAdmins
  * JazzGuests
* GitHub
  * gitusers
  * gitadmin
* Python
  * python-developer

# Service Accounts
* ocp-jenkins-[env]-[team]
  * [env] can take the values _np_ or _prod_
  * Examples of the ocp-jenkins services accounts for Contact PL team
    * ocp-jenkins-np-contactpl
    * ocp-jenkins-prod-contactpl
  * Used to connect to OpenShift projects from Jenkins
    * ocp-jenkins-np-[team] are used to connect to OpenShift NP Cluster
    * ocp-jenkins-prod-[team] are used to connect to OpenShift Prod Cluster
    * __TODO:__ which one to use for Prep?
  * Used to connect to GitHUb from Jenkins in the context of OpenShift pipelines
  * Must have edit role in the related OCP projects in the target cluster. Example: ocp-jenkins-np-contactpl must have edit role in contactpl-dev, contactpl-intg, contactpl-uat (but not contactpl-prod)
  * Must have access to GitHub
  * Must have at least read access to the project storing the templates in GitHub
  * Owned by the SE team, usually a senior integrator of the team (example David Bernard for ocp-jenkins-xx-contactpl)
  * Password management should be done by a Notes tiles. Owner must provide access to the password to
    * All the users that need to access the passwords. It is advised to limit access to the password, usually to integrators from its team
    * And also, __but only for ocp-jenkins-np-xxx accounts__ to the following members of the tools team: Ghyslain Cloutier, Guy Dumais, Oscar Picasso
  * These service accounts are typically added as credentials to the Jenkins instance of the SE team used for its OCP pipelines
  * Current actual accounts
    * ocp-jenkins-np-contactpl (TODO ownership + end users)
      * Owner: David Bernard
      * End users: TODO David Bernard, Maxime Lafond, Oscar Picasso, Ghyslain Cloutier, Guy Dumais
      * To be removed: Raymond Leclerc, Charles Daneau, Nathalie Ng, Marie St-James, Stephane Villeneuve, Eric Gadbois, Alexandre Dumont, Ed Rumboldt
    * ocp-jenkins-np-ratingrev (TODO ownership + end users)
      * Owner: Kasra Zandi
      * End users: Kasra Zandi, Julien Grenier, Oscar Picasso, Ghyslain Cloutier, Guy Dumais
      * To be removed: Charles Daneau, Raymond Leclerc, Nathalie Ng, Marie St-James, Stephane Villeneuve, Eric Gadbois, Alexandre Dumont, Ed Rumboldt
    * ocp-jenkins-np-rqq (TODO ownership + end users)
      * Owner: Raymond Audet
      * End users: Raymond Audet, Oscar Picasso, Ghyslain Cloutier, Guy Dumais
      * To be removed: Charles Daneau, Raymond Leclerc, Nathalie Ng, Marie St-James, Stephane Villeneuve, Eric Gadbois, Alexandre Dumont, Ed Rumboldt
    * ocp-jenkins-prod-contactpl (TODO ownership + end users)
      * Owner: David Bernard
      * End users: David Bernard, Maxime Lafond
      * To be removed: Stephane Villeneuve, Eric Gadbois, Alexandre Dumont, Ed Rumboldt
    * ocp-jenkins-prod-ratingrev: 
      * Owner: Kasra Zandi
      * End users: Kasra Zandi, Julien Grenier
    * ocp-jenkins-prod-rqq (TODO ownership + end users)
      * Owner: Raymond Audet
      * End users: Raymond Audet
      * To be removed: Stephane Villeneuve, Eric Gadbois, Alexandre Dumont, Ed Rumboldt
* ocp-jenkins-devtools
  * Generic Jenkins user to connect to OCP devtools
  * Owner:
  * End users: 
  * NOT CURRENTLY IMPLEMENTED - WAITING FOR SECURE JENKINS - IN THE MEANTIME USE _openshift-user
* _openshift-user
  * Generic user to connect from OCP to Nexus
  * NEEDS TO VERIFIY WITH IS - TEMPORARLY USED ALSO AS SUBSTITUTE FOR ocp-jenkins-xxx users
* nexus-openshift (TODO ownership + end users)
  * To connect to Nexus from OpenShift
  * LDAP group: nexus-developer
  * Owner: Oscar Picasso
  * End users: Oscar Picasso, Ghyslain Cloutier, Guy Dumais, Erik Lalancette, Filipe Santos
  * To be removed: Charles Daneau, Raymond Leclerc, Nathalie Ng, Marie St-James, Stephane Villeneuve, Eric Gadbois, Alexandre Dumont, Ed Rumboldt
  * IN THE PROCESS OF BEING IMPLEMENTED - WILL REPLACE _OPENSHIFT_USER
* nexus2-openshift-local
  * THIS NOT A LDAP SERVICE ACCOUNT
  * Account defined locally in Nexus 2
  * Use to retrieve war and docker.tgz content from Nexus inside a docker build with the docker strategy.
  * Use its tokens as credentials in OpenShift
  * Will be probably deleted when S2I is implemented
* github-openshift (TODO ownership + end users + LDAP group)
  * To connect to GitHub from OpenShift 
  * LDAP group: gitusers
  * Owner: Oscar Picasso
  * End users: Guy Dumais, Erik Lalancette, Filipe Santos
  * To be removed: Charles Daneau, Raymond Leclerc, Nathalie Ng, Marie St-James, Stephane Villeneuve, Eric Gadbois, Alexandre Dumont, Ed Rumboldt
  * NEEDS TO BE IMPLEMENTED AS SECRETS FOR BUILD IN OPENSHIFT
* jenkins-nexus-docker-promoter (REQUESTED, created temporarly as local user in Nexus 3 as jenkins-nexus-docker-promoter-local)
  * To connect to Nexus from Jenkins when doing Docker image promotes
  * Owner: Oscar Picasso
  * End users: Guy Dumais, Ghysalin Cloutier
* build-maven
  * Generic Jenkins user to access Nexus repositories, Nexus IQ, Git and RTC

# Deprecated LDAP Groups
* ~~ocp-prod-project-admin~~
* ~~ocp-np-project-admin~~
* ~~ocp-tmp-project-admin~~
* ~~ocp-prod-tech-lead~~
* ~~ocp-np-tech-lead~~
* ~~ocp-np-rqq-viewer~~
* ~~ocp-np-rqq-admin~~

# Deprecated Service Accounts
* ~~ocp-prod-project-admin~~
* ~~ocp-jenkins-prep~~
* ~~ocp-jenkins-prod~~
* ~~ocp-prod-view~~



