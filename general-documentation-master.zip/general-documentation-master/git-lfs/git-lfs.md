# GIT-LFS

Git Large File Storage (LFS) is a Git extension mechanism that allows large files to be stored outside of a normal Git repository, yet allows end users to interact with those files as if they were part of the same project. Instead of the actual large file, a small pointer file replaces the file in your Git repository, and the file content is stored in a separate location. This documentation explains the steps to install and use the GIT-LFS functionalities with storage of files in Nexus Repository Manager 3.

### GIT LFS LOCAL INSTALLATION

GIT-LFS is not part of the regular GIT packages and must be installed separately.

1. [Download package](https://github.com/git-lfs/git-lfs/releases/download/v2.3.4/git-lfs-windows-2.3.4.exe)
2. Install git-lfs
```
git lfs install
```

### GIT LFS CONFIGURATION

GIT-LFS configuration has to be done in each repository with the following command. This will add the file .lfsconfig at the root of the repository.

```
git config -f .lfsconfig lfs.url https://nexus-3.iad.ca.inet:8443/repository/git-lfs/info/lfs
```

### TRACKING LARGE FILES

Select the file types, file pattern, individual file or directories you'd like Git LFS to manage (or directly edit your .gitattributes). You can configure additional file extensions at anytime but it is recommended to add them before pushing the files to GITHUB. Any file pushed before being tracked will remain in the GIT history (directory .git). The example below tracks all files with the jpg extension.

```
git lfs track "*.jpg"
```

### GIT LFS LOCKING API

The [Git locking API](https://github.com/git-lfs/git-lfs/wiki/File-Locking) is not available with the current version of Git. It is good practice to lock a file before modifying it because concurent binary files are generally very hard to merge. To avoid getting an annoying warning message each time you push a tracked file, execute the following command.

```
git config lfs.https://nexus-3.iad.ca.inet:8443/repository/git-lfs/.locksverify false
``` 

### 

### GIT LFS Demo

This [demo](https://www.youtube.com/watch?v=l5SIbsy21jE) explains the Git LFS usage (does not use Nexus as storage).

<a href="http://www.youtube.com/watch?feature=player_embedded&v=l5SIbsy21jE" target="_blank"><img src="gitlfsdemo.jpg" width="240" height="180" border="10" /></a>

### TODO : BFG Repo-cleaner

The [BFG Repo-cleaner](https://rtyley.github.io/bfg-repo-cleaner/) is a utility tool that helps removing large blobs in Git repositories.
