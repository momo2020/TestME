# General Documentation

This is the general documentation related to development, when it is not directly related to source code inside one of our GitHub repository.

## Table of contents
### Security
* [Tools Security](security/ldap.md)

### Servers
* [Servers List](servers/list.md)

### Jenkins
  * [Jenkins Openshift](jenkins/ocp-jenkins.md)
  * [Jenkins Useful Links](jenkins/jenkins-useful-links.md)
  * [GitHub Organization Folder](jenkins/jenkins-github.md)
  * [Jenkins Archived Legacy](archived-legacy/jenkins-archived-legacy.md)
  
### OpenShift
  * [OpenShift Usage](openshift/openshift.md)
  * [OpenShift API Objects](openshift/ocp-api-objects.md)
  * [Build, Deploy & Promote (Work in Progress)](openshift/build-deploy-promote.md)
  * [Versioning & Pruning](openshift/versioning-pruning.md)
  * [Backup & Restore - Persistent Volumes For Jenkins](openshift/backup-restore-pv.md)
  * [OpenShift Tools](openshift/ocp-tools.md)
  * [Pipelines Implementation](openshift/new-pipelines-implementation.md)
  * [Docker Registries](docker/docker-registries.md)

### GitHub  
* [GitHub LFS](git-lfs/git-lfs.md)
* [GitHub Administration](github/github-admin.md)

### CI/CD & Automation
* [CI/CD & Automation](ci-cd-automation/ci-cd-automation.md)

### Misc
* [Elasticsearch Stack](elk/elk.md)
* [Graddle](graddle/graddle.md)

