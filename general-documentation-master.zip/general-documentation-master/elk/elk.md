# ELK
Temporary documentation - Misc notes

## Elasicsearch
* [ElasticSearch On Docker Documentation](https://www.elastic.co/guide/en/elasticsearch/reference/current/docker.html)

### Image From Vendor
* `docker run -d -p 9200:9200 -e "http.host=0.0.0.0" -e "transport.host=127.0.0.1" stha8p0co.iad.ca.inet:8503/elasticsearch/elasticsearch:5.5.0`
* `curl localhost:9200`
* `curl stha8n0bv:9200`
  * Production mode<br/>
    The `vm_max_map_count` kernel setting needs to be set to at least `262144` for production use.
    * Reading current vm_max_map_count: `grep vm.max_map_count /etc/sysctl.conf`
    * Setting new vm_max_map_count value: `sysctl -w vm.max_map_count=262144`

### Custom Image
* `git clone git@githubifc.iad.ca.inet:DockerBaseImages/elasticsearch.git`
* `cd elasticsearch`
* `docker build --tag=elasticsearch-custom .`
* Running the image
  * With docker: `docker run -d -p 9200:9200 -e "http.host=0.0.0.0" -e "transport.host=127.0.0.1" elasticsearch-custom`
  * With docker compose: `docker-compose up -d`
* `curl localhost:9200`
* `curl stha8n0bv:9200`
* Stop the image with docker compose: `docker-compose down`

## Logstash
* [LogStash On Docker Documentation](https://www.elastic.co/guide/en/logstash/current/docker.html)

### Image From Vendor
* `docker run -d -p 9600:9600 -v /tmp/kibana/:/usr/share/logstash/pipeline/ stha8p0co.iad.ca.inet:8503/logstash/logstash:5.5.0`
* `curl localhost:9600`
* `curl stha8n0bv:9600`

### Custom Image
* `git clone git@githubifc.iad.ca.inet:DockerBaseImages/logstash.git`
* `cd logstash`
* `docker build --tag=logstash-custom .`
* Running the image
  * With docker: `docker run -d -p 8080:8080 logstash-custom`
  * With docker compose: `docker-compose up -d`
* `curl localhost:8080`
* `curl stha8n0bv:8080`
* Stop the image with docker compose: `docker-compose down`

## Kibana
* [Kibana On Docker Documentation](https://www.elastic.co/guide/en/kibana/current/docker.html)

### Image From Vendor
* `docker run -d -p 5601:5601 stha8p0co.iad.ca.inet:8503/kibana/kibana:5.5.0`
* `curl -i localhost:5601`
* `curl -i stha8n0bv:5601`
* [UI](http://stha8n0bv.iad.ca.inet:5601)

### Custom Image
* `git clone git@githubifc.iad.ca.inet:DockerBaseImages/kibana.git`
* `cd kibana`
* `docker build --tag=kibana-custom .`
* Running the image
  * With docker: `docker run -d -p 5601:5601 kibana-custom`
  * With docker compose: `docker-compose up -d`
* `curl localhost:5601`
* `curl stha8n0bv:5601`
* [In your browser](http://stha8n0bv.iad.ca.inet:5601)
* Stop the image with docker compose: `docker-compose down`
