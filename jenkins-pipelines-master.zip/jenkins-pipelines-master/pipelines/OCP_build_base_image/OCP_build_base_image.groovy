#!Groovy
import intact.elasticsearch.domain.BaseImageBuild
import intact.elasticsearch.Logstash

node(NODE) {
	repositories = REPOSITORY.split(',')

	deleteDir()
	wrap([$class: 'BuildUser']) {
		buildUserId = env.BUILD_USER_ID
	}

	dir("base-images") {
		stage("Build & Push Images") {
			for (int i = 0; i < repositories.length; i++) {
				currentRepository = repositories[i].trim()
				git credentialsId: '0afacacb-18d1-4b9a-a0db-d2c44495bae8', url: "https://githubifc.iad.ca.inet/DockerBaseImages/${currentRepository}.git"
				version = sh script: 'sed -n  \'s/^LABEL *version *=[ \\t]*"\\(.*\\)"/\\1/p\' Dockerfile', returnStdout: true
				version = version.trim()
				dockerfile = sh script: 'cat Dockerfile', returnStdout: true
				from = sh script: 'grep "^FROM" Dockerfile', returnStdout: true
				from = from.replaceFirst("^FROM +", "").trim()
				echo "from=${from}"
				imageBuild = new BaseImageBuild(currentRepository, version, dockerfile, from, env, buildUserId)
				sh "docker build --pull -t ${imageBuild.push_name} ."
				cmd = imageBuild.imageIdCMD
				imageId = sh script: "${cmd}", returnStdout: true
				imageId = imageId.trim()
				imageBuild.set_mage_id(imageId)
				sh "docker tag ${imageBuild.push_name} ${imageBuild.build_name}"
				sh "docker push ${imageBuild.push_name}"
				//sh "docker push ${imageBuild.build_name}"

				if (RECORD_HISTORY.toBoolean()) {
					Logstash.instance.add(imageBuild)
				}
				currentBuild.displayName = "last image: #${BUILD_NUMBER} ${imageBuild.push_name}"

			}
		}
	}
}
