#!Groovy
import intact.cluster.ocp.Cluster
import groovy.json.JsonSlurperClassic

def jsonFile = libraryResource 'intact/util/ocp/rqq.json'
def json = new JsonSlurperClassic().parseText(jsonFile)
def ocp_env_project

properties([
        parameters(
                [
                        booleanParam(defaultValue: false, description: 'check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
                        choice(choices: json.ocp_base_projects.join("\n"), description: '', name: 'OCP_BASE_PROJECT'),
                        string(defaultValue: '5', description: 'how many replicationControllers we want to keep of the same dc', name: 'NUMBER_TO_KEEP'),
                ]),
        pipelineTriggers([cron('H 4 * * *')])
])

if (!ONLY_REFRESH_CHOICES.toBoolean()) {

     node('linux') {

        currentBuild.displayName = "#${BUILD_NUMBER} : cleaning ${OCP_BASE_PROJECT}"

        stage('cleanup environments'){
            def environmentList = json.environments
            for (String environmentItem in environmentList) {
                originClusterURL = Cluster.clusterByEnv(environmentItem).url
                originClusterCredentials = Cluster.clusterByEnv(environmentItem).credentialsId
                // log to OCP
                logToOCP(originClusterURL, originClusterCredentials)


                ocp_env_project = "${OCP_BASE_PROJECT}-${environmentItem}"

                // Clean up
                cleanProjects(ocp_env_project)
            }
        }

        stage('Clean up workspace') {
            ws(pwd() + "@tmp") {
                step([$class: 'WsCleanup'])
            }
            ws(pwd() + "@libs") {
                step([$class: 'WsCleanup'])
            }
            ws(pwd() + "@script") {
                step([$class: 'WsCleanup'])
            }
            deleteDir()
        }
    }
} else {
    currentBuild.displayName = 'REFRESHED CHOICES'
}

void logToOCP(final String url, final String credentialsId) {
    echo "attempting oc login with credentialsID ${credentialsId}"
    withCredentials([
            usernamePassword(credentialsId: credentialsId, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
    ]) {
        sh "oc login ${url} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
    }
}

void cleanProjects(String envProject) {
    sh "oc get project -o json > projectList-${OCP_BASE_PROJECT}.json"
    String projectLists = sh script: "cat projectList-${OCP_BASE_PROJECT}.json", returnStdout: true
    ProjectListsJson = new JsonSlurperClassic().parseText(projectLists)
    def items = ProjectListsJson.items
    // loop through projects
    for (def item in items) {
        //todo refactor this in a loop and a the NUMBER_TOO_KEEP parameter ${ocp_base_projects}
        String Project = "${item.metadata.name}"
        // Only process projects that match your selection
        if (Project.startsWith("${envProject}")) {
            sh "oc project ${envProject}"
            sh "oc get dc -n ${envProject} -o json > deploymentConfigs-${envProject}.json"
            sh "oc get rc -n ${envProject} -o json > replicationControllers-${envProject}.json"

            String deploymentConfigs = sh script: "cat deploymentConfigs-${envProject}.json", returnStdout: true
            String replicationControllers = sh script: "cat replicationControllers-${envProject}.json", returnStdout: true

            deploymentConfigsJson = new JsonSlurperClassic().parseText(deploymentConfigs)
            replicationControllersJson = new JsonSlurperClassic().parseText(replicationControllers)
            def ConfigItems = deploymentConfigsJson.items
            def goldenRcs = []
            def unwantedRcs = []

            // loop through Config list to build a list of the 5 latest deployments that will be kept.
            String strnumber = "${NUMBER_TO_KEEP}"
            def goldenToKeep = strnumber.isInteger() ? strnumber.toInteger() : 5

            for (def ConfigItem in ConfigItems) {
                for (int i = 0; i < goldenToKeep&& i < ConfigItems.size; i++) {
                        //todo refactor this in a loop and a the NUMBER_TOO_KEEP parameter
                        goldenRcs << "${ConfigItem.metadata.name}-${ConfigItem.status.latestVersion - i}"
                }
            }

            // build a list of
            for (def rc in replicationControllersJson.items) {
                String rcName = rc.metadata.name
                if ((goldenRcs as String[]).contains(rcName)){
                } else {
                    unwantedRcs << rcName
                }
            }

            // log for testing
            println("goldenToKeep = "+goldenToKeep.toString())
            println("***** ${Project} to be kept start *****")
            println(goldenRcs.join('\n'))
            println("***** ${Project} to be kept end *****")
            println("***** ${Project} to be deleted start *****")
            println(unwantedRcs.join('\n'))
            println("***** ${Project} to be deleted end *****")


            if (unwantedRcs != []) {
                sh "oc delete rc -n ${Project} ${unwantedRcs.join(' ')}"
            } else {
                println('nothing to delete for project ${Project}')
            }

        }
    }
}
