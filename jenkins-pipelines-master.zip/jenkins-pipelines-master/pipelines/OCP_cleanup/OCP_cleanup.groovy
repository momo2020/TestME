#!Groovy
import intact.cluster.ocp.Cluster
import groovy.json.JsonSlurperClassic

def jsonFile = libraryResource 'intact/util/ocp/rqq.json'
def json = new JsonSlurperClassic().parseText(jsonFile)

properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			choice(choices: json.ocp_base_projects.join("\n"), description: '', name: 'OCP_BASE_PROJECT'),
			choice(choices: json.environments.join("\n"), description: '', name: 'ORIGIN_ENVIRONMENT'),
			choice(choices: json.branches.join("\n"), description: '', name: 'ORIGIN_BRANCH'),
			// TODO use this parameter to specify how many rcs we want to keep
			// string(defaultValue: '5', description: 'how much replicationControllers we want to keep of the same dc', name: 'NUMBER_TOO_KEEP'),
		])
])

if (!ONLY_REFRESH_CHOICES.toBoolean()) {
	final String OCP_PROJECT = "${OCP_BASE_PROJECT}-${ORIGIN_ENVIRONMENT}${ORIGIN_BRANCH.empty ? '' : "-${ORIGIN_BRANCH}"}"

	originClusterURL = Cluster.clusterByEnv(ORIGIN_ENVIRONMENT).url
	originClusterCredentials = Cluster.clusterByEnv(ORIGIN_ENVIRONMENT).credentialsId

	def deploymentConfigsJson
	def replicationControllersJson
	def goldenRcs = []
	def unwantedRcs = []

	node('linux') {
		currentBuild.displayName = "#${BUILD_NUMBER} : cleaning ${OCP_PROJECT}"
		deleteDir()
		JAVA_HOME = tool 'oracle-jdk1.8.0_102-linux'
		MAVEN_HOME = tool 'maven-3.5.0'
		withEnv([
			"JAVA_HOME=${JAVA_HOME}",
			"MAVEN_HOME=${MAVEN_HOME}",
			"PATH=${JAVA_HOME}/bin:${MAVEN_HOME}/bin:/usr/local/bin:/usr/bin:/bin"
		]) {
			stage("Retrieve all deployment configs and replicationControllers") {
				withCredentials([
					usernamePassword(credentialsId: originClusterCredentials, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
				]) {
					sh "oc login ${originClusterURL} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
				}
				sh "oc project ${OCP_PROJECT}"
				sh "oc get dc -n ${OCP_PROJECT} -o json > deploymentConfigs-${OCP_BASE_PROJECT}-${ORIGIN_ENVIRONMENT}.json"
				sh "oc get rc -n ${OCP_PROJECT} -o json > replicationControllers-${OCP_BASE_PROJECT}-${ORIGIN_ENVIRONMENT}.json"

				String deploymentConfigs = sh script: "cat deploymentConfigs-${OCP_BASE_PROJECT}-${ORIGIN_ENVIRONMENT}.json", returnStdout: true
				String replicationControllers = sh script: "cat replicationControllers-${OCP_BASE_PROJECT}-${ORIGIN_ENVIRONMENT}.json", returnStdout: true

				deploymentConfigsJson = new JsonSlurperClassic().parseText(deploymentConfigs)
				replicationControllersJson = new JsonSlurperClassic().parseText(replicationControllers)
			}
			stage("find all the golden Dcs") {
				def items = deploymentConfigsJson.items
				for (def item in items) {
					//todo refactor this in a loop and a the NUMBER_TOO_KEEP parameter
					goldenRcs << "${item.metadata.name}-${item.status.latestVersion}"
					goldenRcs << "${item.metadata.name}-${item.status.latestVersion - 1}"
					goldenRcs << "${item.metadata.name}-${item.status.latestVersion - 2}"
					goldenRcs << "${item.metadata.name}-${item.status.latestVersion - 3}"
					goldenRcs << "${item.metadata.name}-${item.status.latestVersion - 4}"
				}
//				println(goldenRcs.join('\n'))
			}
			stage("retrieve all the non unwanted Rcs") {
				for (def rc in replicationControllersJson.items) {
					String rcName = rc.metadata.name
					if ((goldenRcs as String[]).contains(rcName)){
//						println("keeping rc ${rcName}")
					} else {
						//println("DELETING rc ${rcName}")
						unwantedRcs << rcName
						// oc delete rc ${rcName} -n ${OCP_PROJECT}
					}
				}
			}

			stage ("delete the unwanted Rcs"){
				if (unwantedRcs != []) {
					sh "oc delete rc -n ${OCP_PROJECT} ${unwantedRcs.join(' ')}"
				} else {
					println('nothing to delete')
				}

			}
		}
	}
} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}
