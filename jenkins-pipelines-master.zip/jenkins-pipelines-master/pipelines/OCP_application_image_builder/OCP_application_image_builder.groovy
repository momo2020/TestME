#!Groovy
import groovy.json.JsonSlurperClassic

//noinspection GroovyAssignabilityCheck
properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),

			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'GAV'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'OCP_BASE_PROJECT'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'NODE'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'COMPANY'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'JSON_FILE'],

		])
])

if (!ONLY_REFRESH_CHOICES.toBoolean()) {
	def json = new JsonSlurperClassic().parseText(JSON_FILE)
	TOKENS = GAV.split(':')
	POM_GROUPID = TOKENS[0]
	POM_ARTIFACTID = TOKENS[1]
	POM_VERSION = TOKENS[2]
	POM_ARTIFACT_TYPE = TOKENS[3]

	POM_RELEASEVERSION = POM_VERSION.replaceFirst('-SNAPSHOT$', '')
	String POM_COMPANY = COMPANY as String

	DOCKER_MUTABLE_PUSH_REGISTRY = "docker-mutable.iad.ca.inet:8463"
	def project
	def POM_DOCKERID

	node(NODE) {
		deleteDir()
		JAVA_HOME = tool 'ibm-java-linux-1.7-x86_64-71'
		MAVEN_HOME = tool 'maven-3.0.5'
		withEnv(["JAVA_HOME=${JAVA_HOME}", "MAVEN_HOME=${MAVEN_HOME}", "PATH=${JAVA_HOME}/bin:${MAVEN_HOME}/bin:/usr/local/bin:/usr/bin:/bin"]) {
			stage("retrieve project from json shared property") {
				project = retrieveProjectFromArtifactId(POM_ARTIFACTID, json)
				POM_DOCKERID = project.dockerId
			}

			stage('Prepare environment') {
				echo "POM_GROUPID=${POM_GROUPID}"
				echo "POM_ARTIFACTID=${POM_ARTIFACTID}"
				echo "POM_DOCKERID=${POM_DOCKERID}"
				SHORT_TAG = "${POM_ARTIFACTID}:${POM_VERSION}-${OCP_BASE_PROJECT.toUpperCase()}"
				echo "POM_VERSION=${POM_VERSION}"
				echo "POM_RELEASEVERSION=${POM_RELEASEVERSION}"
				echo "JAVA_HOME=${JAVA_HOME}"
				echo "MAVEN_HOME=${MAVEN_HOME}"
				sh "java -version" // To force jdk download on the node
			}
			stage("Retrieve artifacts") {
				parallel(retrieveWar: {
					if (POM_COMPANY != '' || project.company != null) {
						if (POM_COMPANY == '') {
							echo 'using default company from sharedLibraries'
							POM_COMPANY = ':' + project.company
						} else {
							POM_COMPANY = ':' + POM_COMPANY
						}
						echo "POM_COMPANY=${POM_COMPANY}"
					}
					sh "mvn org.apache.maven.plugins:maven-dependency-plugin:2.10:copy -Dartifact=${POM_GROUPID}:${POM_ARTIFACTID}:${POM_VERSION}:${POM_ARTIFACT_TYPE}${POM_COMPANY} -DoutputDirectory=. -s ${MAVEN_SETTINGS} -Dmdep.stripVersion=true -q"
				}, retrieveDockerTgz: {
					sh "mvn org.apache.maven.plugins:maven-dependency-plugin:2.10:copy -Dartifact=${POM_GROUPID}:${POM_DOCKERID}:${POM_VERSION}:tar.gz:image-content -DoutputDirectory=. -s ${MAVEN_SETTINGS} -Dmdep.stripVersion=true -q"
				})
			}

			stage("Extract docker content") {
				sh "tar -xzf ${POM_DOCKERID}-image-content.tar.gz"
				sh "find . -name \"Dockerfile\" | xargs cp -t ."
				sh "find . -name \"content\" | xargs cp -rt ."

			}

			stage("Build image") {
				load 'content/common/jenkins-build.properties'

				PUSH_NAME = "${DOCKER_MUTABLE_PUSH_REGISTRY}/intact/${SHORT_TAG}"

				echo "PUSH_NAME=${PUSH_NAME}"
				// TODO is there a way to refactor this..?
				if ('webquote-residential-appstatic' == POM_ARTIFACTID ||
					'webquote-commercial-appstatic' == POM_ARTIFACTID ||
					'quickquote-intact-appstatic-web' == POM_ARTIFACTID ||
					'quickquote-belair-appstatic-web' == POM_ARTIFACTID) {
					echo 'rereYuck'
					sh "docker build --pull -t ${PUSH_NAME} ."
				} else {
					sh "docker build --pull --build-arg WAR_NAME=${POM_ARTIFACTID} -t ${PUSH_NAME} ."
				}
			}
			stage("Push image") {
				sh "docker push ${PUSH_NAME}"
				currentBuild.displayName = "${PUSH_NAME}"
			}
		}
	}
} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}


def retrieveProjectFromArtifactId(String artifactId, json) {
	def project
	boolean found = false
	for (def p : json.projects) {
		if (p.artifactId.equals(artifactId)) {
			project = p
			found = true
		}
	}
	if (!found) {
		echo "artifact + [${artifactId}] not found in shared library"
		assert false
	}
	return project
}
