#!Groovy
package DOCKER_build_create_deploy

import com.cloudbees.groovy.cps.NonCPS
import groovy.json.JsonSlurperClassic
import intact.cluster.ocp.Cluster

/**
 * @Author Raymond Audet, Chou Khorng Trang
 * pipeline used to build, create a docker image and deploy it
 */

//@See https://githubifc.iad.ca.inet/DevTools/jenkins-pipeline-shared-librairies
def jsonFile = libraryResource 'intact/util/ocp/rqq.json'
def json = new JsonSlurperClassic().parseText(jsonFile)

def buildNameFilteredByTopicScript = '''	
import groovy.json.JsonSlurper
def json = new JsonSlurper().parseText(JSON_FILE)
def buildList = []
def topic = TOPIC

if (topic.equals('')) {
	return json.projects.buildName
} else {	
	for (def project in json.projects) {
		if (project.topics.contains(topic)) {
			buildList.add(project.buildName)
		}
	}
return buildList
}
'''

//todo export to an external file
def booleanScript = "return ['NO','YES']"

//todo export to an external file
def fallbackScript = "return ['ERROR']"

//todo export to an external file
def explicitVersionScript = 'if(SKIP_DEPLOY.equals(\'NO\')){\n' +
	'return "<input name=\\"value\\" value=\\"\\" class=\\"setting-input\\" type=\\"text\\"><p>Build the image and retrieve the artifact from nexus using this version. <br>If you don\'t specify a version, it will retrieve the one we just built from nexus.</p>"\n' +
	'}\n' +
	'else{\n' +
	'return ""\n' +
	'}'

//todo export to an external file
def explicitConfigMapScript = 'if(SKIP_UPDATE_PROPERTIES.equals(\'NO\')){\n' +
	'return "<input name=\\"value\\" value=\\"\\" class=\\"setting-input\\" type=\\"text\\"><p>\tBuild the configMap and retrieve the properties directly from nexus using the specified version. <br>If there is no explicit configMap version specified, we use the version we just built</p>"\n' +
	'}\n' +
	'else{\n' +
	'return ""\n' +
	'}'

//todo export to an external file
def actionPerformScript = 'String title = "<hr><h2>Action to be performed</h2>"\n' +
	'String error = "<font color=\\"red\\"><b>This build will crash because you chose to skip the deployment and the properties update.</b></font>"\n' +
	'String message = "<font color=\\"red\\"><b>Skipping</b></font> the image creation step and the deployment to openshift. <br>The latest configmap version in Nexus will be <font color=\\"green\\"><b>applied</b></font> and the pod restarted"\n' +
	'String message1 = "<font color=\\"red\\"><b>Skipping</b></font> the image creation step and the deployment to openshift. <br>The version <font color=\\"red\\"><b>${EXPLICIT_CONFIGMAP_VERSION}</b></font> configmap in Nexus will be <font color=\\"green\\"><b>applied</b></font>."\n' +
	'String message2 = "A new image will be built and deployed to Nexus. <br>The deployment in openshift will be executed and the configmap version we just built will be <font color=\\"green\\"><b>applied</b></font>."\n' +
	'String message3 = "A new image will be built from the version <font color=\\"red\\"><b>${EXPLICIT_VERSION}</b></font> in Nexus and the deployment in openshift will be executed.<br>The latest configmap version in Nexus will be <font color=\\"green\\"><b>applied</b></font>."\n' +
	'String message4 = "A new image will be built from the version <font color=\\"red\\"><b>${EXPLICIT_VERSION}</b></font> in Nexus and the deployment in openshift will be executed.<br>The <font color=\\"red\\"><b>${EXPLICIT_CONFIGMAP_VERSION}</b></font> configmap version in Nexus will be <font color=\\"green\\"><b>applied</b></font>."\n' +
	'String message5 = "A new image will be built and deployed to Nexus. <br>The deployment in openshift will be executed and the <font color=\\"red\\"><b>${EXPLICIT_CONFIGMAP_VERSION}</b></font> configmap version in Nexus will be <font color=\\"green\\"><b>applied</b></font>."\n' +
	'String message6 = "A new image will be built and deployed to Nexus. <br>The deployment in openshift will be executed. The configuration files and configMap update will be <font color=\\"red\\"><b>skipped</b></font>."\n' +
	'String message7 = "A new image will be built from the version <font color=\\"red\\"><b>${EXPLICIT_VERSION}</b></font> in Nexus and the deployment in openshift will be executed.<br>The configuration files and configMap update will be <font color=\\"red\\"><b>skipped</b></font>."\n' +
	'\n' +
	'if(SKIP_DEPLOY.equals(\'YES\') && SKIP_UPDATE_PROPERTIES.equals(\'YES\')){\n' +
	'return (title + error)\n' +
	'}\n' +
	'if(SKIP_DEPLOY.equals(\'YES\') && SKIP_UPDATE_PROPERTIES.equals(\'NO\') && EXPLICIT_CONFIGMAP_VERSION.isEmpty()){\n' +
	'return (title + message)\n' +
	'}\n' +
	'if(SKIP_DEPLOY.equals(\'YES\') && SKIP_UPDATE_PROPERTIES.equals(\'NO\') && !EXPLICIT_CONFIGMAP_VERSION.isEmpty()){\n' +
	'return (title + message1)\n' +
	'}\n' +
	'if(SKIP_DEPLOY.equals(\'NO\') && SKIP_UPDATE_PROPERTIES.equals(\'NO\') && EXPLICIT_VERSION.isEmpty() && EXPLICIT_CONFIGMAP_VERSION.isEmpty()){\n' +
	'return (title + message2)\n' +
	'}\n' +
	'if(SKIP_DEPLOY.equals(\'NO\') && SKIP_UPDATE_PROPERTIES.equals(\'NO\') && !EXPLICIT_VERSION.isEmpty() && EXPLICIT_CONFIGMAP_VERSION.isEmpty()){\n' +
	'return (title + message3)\n' +
	'}\n' +
	'if(SKIP_DEPLOY.equals(\'NO\') && SKIP_UPDATE_PROPERTIES.equals(\'NO\') && !EXPLICIT_VERSION.isEmpty() && !EXPLICIT_CONFIGMAP_VERSION.isEmpty()){\n' +
	'return (title + message4)\n' +
	'}\n' +
	'if(SKIP_DEPLOY.equals(\'NO\') && SKIP_UPDATE_PROPERTIES.equals(\'NO\') && EXPLICIT_VERSION.isEmpty() && !EXPLICIT_CONFIGMAP_VERSION.isEmpty()){\n' +
	'return (title + message5)\n' +
	'}\n' +
	'if(SKIP_DEPLOY.equals(\'NO\') && SKIP_UPDATE_PROPERTIES.equals(\'YES\') && EXPLICIT_VERSION.isEmpty()){\n' +
	'return (title + message6)\n' +
	'}\n' +
	'if(SKIP_DEPLOY.equals(\'NO\') && SKIP_UPDATE_PROPERTIES.equals(\'YES\') && !EXPLICIT_VERSION.isEmpty()){\n' +
	'return (title + message7)\n' +
	'}'

properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'Check this if you only need to refresh the BUILDNAME or other choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			[
				$class              : 'ChoiceParameter',
				choiceType          : 'PT_SINGLE_SELECT',
				description         : 'Select a topic in order to filter the buildNames',
				filterable          : false,
				name                : 'TOPIC',
				randomName          : 'choice-parameter-48293583925954',
				referencedParameters: '',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: "return ''"],
					script        : [classpath: [], sandbox: false, script: "return ${retrieveAllTopics(json)}"]
				]
			],
			[$class: 'WHideParameterDefinition', defaultValue: "${jsonFile}", description: 'used to pass down to other pipelines', name: 'JSON_FILE'],
			[
				$class              : 'CascadeChoiceParameter',
				choiceType          : 'PT_SINGLE_SELECT',
				description         : '',
				filterable          : true,
				name                : 'BUILDNAME',
				randomName          : 'choice-parameter-68065844775948',
				referencedParameters: 'TOPIC, JSON_FILE',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
					script        : [classpath: [], sandbox: false, script: buildNameFilteredByTopicScript]
				]
			],

			[$class            : 'ExtensibleChoiceParameterDefinition',
			 choiceListProvider: [$class: 'TextareaChoiceListProvider', addEditedValue: true, choiceListText: ['', 'origin/dev', 'origin/release', 'origin/master'].join("\n"), whenToAdd: 'CompletedStable'],
			 description       : 'The git branch to build from (if applicable)',
			 editable          : true,
			 name              : 'GIT_BRANCH'
			],
			choice(choices: json.ocp_base_projects.join("\n"), description: '', name: 'OCP_BASE_PROJECT'),
			choice(choices: json.environments.join("\n"), description: '', name: 'ENVIRONMENT'),
			choice(choices: json.branches.join("\n"), description: '', name: 'BRANCH'),
			choice(choices: json.nodes.join("\n"), description: '', name: 'NODE'),
			choice(choices: json.companies.join("\n"), description: '', name: 'COMPANY'),
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'BATCH_DESCRIPTION'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'DESCRIPTION'],
			[$class: 'WHideParameterDefinition', defaultValue: 'master', description: '', name: 'TEMPLATE_BRANCH'],
			[
				$class              : 'CascadeChoiceParameter',
				choiceType          : 'PT_SINGLE_SELECT',
				description         : 'Choose YES if you want to SKIP the create image step and the deployment to openshift',
				filterable          : false,
				name                : 'SKIP_DEPLOY',
				randomName          : 'choice-parameter-68065844385948',
				referencedParameters: '',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
					script        : [classpath: [], sandbox: false, script: booleanScript]
				]
			],
			[
				$class              : 'DynamicReferenceParameter',
				choiceType          : 'ET_FORMATTED_HTML',
				description         : '',
				name                : 'EXPLICIT_VERSION',
				omitValueField      : true,
				randomName          : 'choice-parameter-68846874905399',
				referencedParameters: 'SKIP_DEPLOY',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
					script        : [classpath: [], sandbox: false, script: explicitVersionScript]
				]
			],
			[
				$class              : 'CascadeChoiceParameter',
				choiceType          : 'PT_SINGLE_SELECT',
				description         : 'Choose YES if you want to SKIP the configuration files update and SKIP the configMap update in ocp as well',
				filterable          : false,
				name                : 'SKIP_UPDATE_PROPERTIES',
				randomName          : 'choice-parameter-68062847385858',
				referencedParameters: '',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
					script        : [classpath: [], sandbox: false, script: booleanScript]
				]
			],
			[
				$class              : 'DynamicReferenceParameter',
				choiceType          : 'ET_FORMATTED_HTML',
				description         : '',
				name                : 'EXPLICIT_CONFIGMAP_VERSION',
				omitValueField      : true,
				randomName          : 'choice-parameter-68846321493533',
				referencedParameters: 'SKIP_UPDATE_PROPERTIES',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
					script        : [classpath: [], sandbox: false, script: explicitConfigMapScript]
				]
			],
			[$class: 'WHideParameterDefinition', defaultValue: 'false', description: '', name: 'SKIP_WAIT_FOR_OCP_DEPLOYMENT'],
			booleanParam(defaultValue: false, description: 'Check this if you do not want to call the SOAP UI test at the end of the promote', name: 'SKIP_TEST'),
			[
				$class              : 'DynamicReferenceParameter',
				choiceType          : 'ET_FORMATTED_HTML',
				description         : '',
				name                : '',
				omitValueField      : false,
				randomName          : 'choice-parameter-68846872653719',
				referencedParameters: 'SKIP_DEPLOY, SKIP_UPDATE_PROPERTIES,EXPLICIT_VERSION,EXPLICIT_CONFIGMAP_VERSION, BUILDNAME',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
					script        : [classpath: [], sandbox: false, script: actionPerformScript]
				]
			]
		])
])

final String OCP_PROJECT = "${OCP_BASE_PROJECT}-${ENVIRONMENT}${BRANCH.empty ? '' : "-${BRANCH}"}"

if (!ONLY_REFRESH_CHOICES.toBoolean()) {
	node(NODE) {
		def project
		String groupId
		String artifactId
		String dockerId
		String projectVersion
		String configMapVersion = ''
		String configMapLongVersion = ''
		String artifactType
		String GAV
		String configMapGAV
		String imageName
		String buildPomVersion

		JAVA_HOME = tool 'ibm-java-linux-1.7-x86_64-71'
		MAVEN_HOME = tool 'maven-3.0.5'
		withEnv([
			"JAVA_HOME=${JAVA_HOME}",
			"MAVEN_HOME=${MAVEN_HOME}",
			"PATH=${JAVA_HOME}/bin:${MAVEN_HOME}/bin:/usr/local/bin:/usr/bin:/bin"
		]) {
			deleteDir()
			stage('validate inputs') {
				if (SKIP_DEPLOY.equals('YES') && SKIP_UPDATE_PROPERTIES.equals('YES')) {
					echo "Please validate input, you want to skip both the deploy and the deploy of the configMaps!!"
					assert false
				}
				echo 'inputs are looking good'
			}

			stage('checking user permission') {
				wrap([$class: 'BuildUser']) { buildUserId = env.BUILD_USER_ID }
				if (json.security.integrator) {
					// Check if the user has permission to deploy into the protected environment
					if (json.security.protected_env.contains(ENVIRONMENT) && !json.security.integrator.contains(buildUserId)) {
						echo "The current user ${buildUserId} cannot deploy in ${ENVIRONMENT}"
						echo "This event has been logged into the system. For more information, please contact an integrator."
						echo "Contact list:\n${json.security.integrator.join('\n')}"
						assert false
					} else {
						echo "Access granted, welcome ${buildUserId}! You can deploy in ${ENVIRONMENT}"
					}
				} else {
					echo "Skipping permission check: No security value in the shared libraries"
					assert false
				}
			}

			stage("retrieve project from json shared property") {
				boolean found = false
				for (def p : json.projects) {
					if (p.buildName.equals(BUILDNAME)) {
						project = p
						found = true
					}
				}
				if (!found) {
					echo "The specificed BuildName [${BUILDNAME}] not found in json file"
					assert false
				}
			}

			groupId = project.groupId
			artifactId = project.artifactId
			artifactType = project.artifactType
			dockerId = project.dockerId

			stage("build from jenkins") {
				if (shouldBuildForProject() || shouldBuildForProperties()) {
					if (GIT_BRANCH == null || GIT_BRANCH.isEmpty()) {
						GIT_BRANCH = project.defaultBranch
						println("GIT_BRANCH not specified, defaulting to ${GIT_BRANCH}")
					}
					def result = build job: 'remote_build', parameters: [string(name: 'REMOTE_JOB_NAME', value: "${BUILDNAME}"), [$class: 'GitParameterValue', name: 'REMOTE_GIT_BRANCH', value: "${GIT_BRANCH}"]]
					def buildEnvVariables = result.getRawBuild().getEnvironment()
					String triggeredBuildNumberNameKey = 'TRIGGERED_BUILD_NUMBER_' + BUILDNAME.replaceAll('\\-', '\\_').replaceAll('\\.', '\\_')
					remoteBuildNumber = buildEnvVariables.get(triggeredBuildNumberNameKey)
					println("remoteBuildNumber = ${remoteBuildNumber}")

					def jsonObj = getRemoteArtifactInfo(BUILDNAME, remoteBuildNumber)
					for (def artifact in jsonObj.moduleRecords.mainArtifact) {
						if (artifact.artifactId.contains(dockerId)) {
							buildPomVersion = artifact.version
						}
					}
					echo "buildPomVersion = ${buildPomVersion}"

				} else {
					echo 'no need to build from Jenkins, skipping this step.. [build from jenkins]'
				}
			}

			stage('update properties') {
				if (!SKIP_UPDATE_PROPERTIES.equals('YES')) {
//				if there is no explicit configMap version specified, we take the version we just built
					configMapVersion = !EXPLICIT_CONFIGMAP_VERSION.isEmpty() ? EXPLICIT_CONFIGMAP_VERSION : buildPomVersion
					configMapGAV = [groupId, artifactId, configMapVersion, artifactType].join(':')
					echo configMapGAV
					build job: 'OCP_014_create_properties_configmap', parameters: [
						string(name: 'GAV', value: configMapGAV),
						string(name: 'OCP_BASE_PROJECT', value: OCP_BASE_PROJECT),
						string(name: 'ENVIRONMENT', value: ENVIRONMENT),
						string(name: 'BRANCH', value: BRANCH),
						string(name: 'NODE', value: NODE),
						string(name: 'POM_DOCKERID', value: dockerId)
					]
				} else {
					echo 'Skipping updateProperties, but we still have to retrieve the configMapVersion from what is already in Openshift'
					logToOCP(ENVIRONMENT, OCP_PROJECT)
					configMapVersion = retrieveOCPLabelFromDeploymentConfig('configMapVersion', artifactId, OCP_PROJECT)
					configMapLongVersion = retrieveOCPLabelFromDeploymentConfig('configMapLongVersion', artifactId, OCP_PROJECT)
				}
			}

			stage("create docker image") {
				if (!SKIP_DEPLOY.equals('YES')) {
					projectVersion = !EXPLICIT_VERSION.isEmpty() ? EXPLICIT_VERSION : buildPomVersion
					GAV = [groupId, artifactId, projectVersion, artifactType].join(':')
					echo GAV

					if ('soa' == artifactType) {
						// @See DOCKER_application_image_builder/DOCKER_service_image_builder.groovy
						build job: 'OCP_20_build_service_image', parameters: [
							string(name: 'GAV', value: GAV),
							string(name: 'OCP_BASE_PROJECT', value: OCP_BASE_PROJECT),
							string(name: 'NODE', value: NODE),
							string(name: 'JSON_FILE', value: "${jsonFile}")
						]
					} else {
						// @See DOCKER_application_image_builder/DOCKER_application_image_builder.groovy
						build job: 'OCP_25_build_application_image', parameters: [
							string(name: 'GAV', value: GAV),
							string(name: 'NODE', value: NODE),
							string(name: 'OCP_BASE_PROJECT', value: OCP_BASE_PROJECT),
							string(name: 'COMPANY', value: COMPANY),
							string(name: 'JSON_FILE', value: "${jsonFile}")
						]
					}
				} else {
					echo 'skipping create image step'
				}
			}

			stage("deploy docker image to OCP") {
				if (!SKIP_DEPLOY.equals('YES')) {
					imageName = [artifactId, projectVersion].join(':')

					build job: 'OCP_30_deploy', parameters: [
						string(name: 'NAME', value: imageName),
						string(name: 'OCP_BASE_PROJECT', value: OCP_BASE_PROJECT),
						string(name: 'ENVIRONMENT', value: ENVIRONMENT),
						string(name: 'BRANCH', value: BRANCH),
						string(name: 'PROJECT_VERSION', value: projectVersion),
						string(name: 'CONFIGMAP_VERSION', value: configMapVersion),
						string(name: 'NODE', value: NODE),
						string(name: 'TEMPLATE_BRANCH', value: TEMPLATE_BRANCH),
						string(name: 'DESCRIPTION', value: DESCRIPTION),
						string(name: 'BATCH_DESCRIPTION', value: BATCH_DESCRIPTION),
						string(name: 'SKIP_WAIT_FOR_OCP_DEPLOYMENT', value: SKIP_WAIT_FOR_OCP_DEPLOYMENT),
						string(name: 'JSON_FILE', value: "${jsonFile}")
					]
				} else {
					echo 'skipping deploy step'
				}
			}
			stage("restarting the pods to update the properties") {

				// restart the pods if only the properties has been updated and update the configMapVersion in the labels
				if (!SKIP_UPDATE_PROPERTIES.equals('YES') && SKIP_DEPLOY.equals('YES')) {
					if (configMapVersion.contains('SNAPSHOT')) {
						configMapLongVersion = getLongVersion(groupId, dockerId, configMapVersion)
					} else {
						configMapLongVersion = configMapVersion
					}
					// TODO should we login right from the start?
					logToOCP(ENVIRONMENT, OCP_PROJECT)

					dir('processed') {
						withCredentials([usernamePassword(credentialsId: '0afacacb-18d1-4b9a-a0db-d2c44495bae8', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
							final String UUID = UUID.randomUUID().toString()
							git branch: 'master', credentialsId: '0afacacb-18d1-4b9a-a0db-d2c44495bae8', url: 'https://githubifc.iad.ca.inet/DevTools/openshift-processed-templates.git'
							final String processedPath = "${OCP_BASE_PROJECT}/${ENVIRONMENT}/${artifactId}"
							sh "sed -i 's/uuid:.*/uuid: ${UUID}/' ${processedPath}/processed.yaml"
							sh "sed -i 's/configMapVersion:.*/configMapVersion: ${configMapVersion}/' ${processedPath}/processed.yaml"
							sh "sed -i 's/configMapLongVersion:.*/configMapLongVersion: ${configMapLongVersion}/' ${processedPath}/processed.yaml"
							sh "git add *"
							sh "git commit -m \'configMapVersion : ${configMapLongVersion}\'"
							sh "git push --set-upstream https://${GIT_USERNAME}:${GIT_PASSWORD.replace('$', '\\$')}@githubifc.iad.ca.inet/DevTools/openshift-processed-templates.git master"
							sh "oc apply -n ${OCP_PROJECT} -f ${processedPath}/processed.yaml"
						}
					}

					if (SKIP_WAIT_FOR_OCP_DEPLOYMENT.equals('false')) {
						timeout(time: 5, unit: 'MINUTES') {
							String rolloutHistory = ''
							waitUntil {
								sleep time: 10, unit: 'SECONDS'
								rolloutHistory = sh script: "oc rollout history dc/${artifactId} -n ${OCP_PROJECT} | tail -2", returnStdout: true
								println('status : ' + rolloutHistory)
								return rolloutHistory.contains('Complete') || rolloutHistory.contains('Failed')
							}
						}
					} else {
						echo 'Skipping waiting for deployment'
					}

				} else {
					echo 'skipping restart step'
				}
			}
			if (json.soapui_tests) {
				// Do we need to wait for ocp deployment before running this stage? if skip wait for deployment is equal yes we should still wait before running the tests
				stage('calling SOAP UI test') {
					// check if the SKIP_TEST checkbox is checked
					if (!SKIP_TEST.toBoolean()) {
						def deployment = artifactId

						// load the environment whitelist
						def environmentWhitelist = json.soapui_tests.environments

						// fetch the soap UI test in the list
						String testJob = json.soapui_tests.soapui_test_builds.get(0)

						// check if the project needs to be tested
						boolean launchSoapUITest = project.launchSoapUITest.toBoolean()

						if (launchSoapUITest) {
							echo "The soap UI tests environments found in the shared library = ${environmentWhitelist}"
							if (environmentWhitelist.contains(ENVIRONMENT)) {
								echo "DESTINATION_ENVIRONMENT ${ENVIRONMENT} has been found in the whitelist" // DEBUG

								// May or may not be relevant anymore
								if (ENVIRONMENT.equals('uat')) {
									environment = ENVIRONMENT.capitalize()
								}
								echo "${deployment} is tagged to run a test and ${ENVIRONMENT} was found in the whitelist. We will now make an asynchronous call to the test build"
								build job: 'remote_build_SOAPUI_tests', parameters: [
									string(name: 'REMOTE_JOB_NAME', value: "${testJob}")
								], wait: false

							} else {
								echo "${ENVIRONMENT} environment is not in the whitelist. Skipping SOAP UI test call"
							}
						} else {
							echo "Skipping SOAP UI test because ${deployment} isn't tagged to run a test"
						}
					} else {
						echo "Skipping SOAP UI test because SKIP_TEST has been checked"
					}
				}
			} else {
				echo "Skipping SOAP UI test because soapui_tests doesn't exist in the shared library"
			}

		}

		// Set the build history name in jenkins
		if (SKIP_DEPLOY.equals('YES')) {
			currentBuild.displayName = "#${BUILD_NUMBER} skip deploy -> ${OCP_PROJECT}"
		} else {
			currentBuild.displayName = "#${BUILD_NUMBER} ${BATCH_DESCRIPTION} ${imageName} -> ${OCP_PROJECT}"
		}

	}
} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}

// user wants to deploy the project but don't provide any explicits versions
boolean shouldBuildForProject() {
	EXPLICIT_VERSION.isEmpty() && SKIP_DEPLOY.equals('NO')
}

// user wants to deploy the properties but don't provide any explicits versions
boolean shouldBuildForProperties() {
	EXPLICIT_CONFIGMAP_VERSION.isEmpty() && SKIP_UPDATE_PROPERTIES.equals('NO')
}

//todo export me as a sharedLibrary?
String retrieveOCPLabelFromDeploymentConfig(
	final String LABEL_NAME, final String DEPLOYMENT, final String OCP_PROJECT) {
	sh "if [[ `oc get dc/${DEPLOYMENT} -n ${OCP_PROJECT} | tail -1 | cut -f 1 -d ' ' ` == '${DEPLOYMENT}' ]]; then echo FOUND; else echo Deployment ${DEPLOYMENT} not found in ocp project; exit 1;  fi"
	String labelValue = sh script: "oc get dc/${DEPLOYMENT} -n ${OCP_PROJECT} -o yaml | grep ${LABEL_NAME}: | sed 's/.*${LABEL_NAME}://'", returnStdout: true
	labelValue.trim()
}

//todo export me as a sharedLibrary?
void logToOCP(final String OCP_ENV, final String OCP_PROJECT) {
	String ocpClusterURL = Cluster.clusterByEnv(OCP_ENV).url
	String ocpClusterCredentials = Cluster.clusterByEnv(OCP_ENV).credentialsId
	withCredentials([
		usernamePassword(credentialsId: ocpClusterCredentials, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
	]) {
		sh "oc login ${ocpClusterURL} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
		sh "oc project ${OCP_PROJECT}"
	}
}

/**
 * retrieves the long snapshot version from nexus using the restAPI
 */
//todo export me as a sharedLibrary?
def getLongVersion(String group, String artifact, String version) {
	final String repo = 'snapshots'
	final String packageType = 'pom'
	String base = 'https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/service/local/artifact/maven/resolve'
	String request = "${base}?g=${group}&a=${artifact}&v=${version}&r=${repo}&p=${packageType}"
	String tag = 'version'
	withCredentials([
		usernamePassword(credentialsId: '0afacacb-18d1-4b9a-a0db-d2c44495bae8', passwordVariable: 'MVN_PASSWORD', usernameVariable: 'MVN_USERNAME')
	]) {
		def xml = sh(
			script: "curl  -u ${MVN_USERNAME}:${MVN_PASSWORD.replace('$', '\\$')} '${request}' | grep ${tag} | sed -e 's/<[^>]*>//g' ",
			returnStdout: true
		)
		xml.trim()
	}
}

@NonCPS
String retrieveAllTopics(json) {
	// collects all the different topics in the jsonSharedLibrary in an array, with the default topic first
	String[] allTopics = ([''] + json.projects.topics).flatten().unique()

	// reformats the array into a string that can be used as a GroovyScript having the format "['', 'topic1', 'topic2']"
	allTopics = allTopics.collect { topic ->
		return "'${topic}'"
	}
	return "[${allTopics.join(', ')}]"
}

def getRemoteArtifactInfo(buildName, buildNumber) {
	final String base = 'https://prod-jenkins-2020.iad.ca.inet/job'
	final String baseQuery = 'mavenArtifacts/api/json?tree='
	final String query = 'moduleRecords[mainArtifact[artifactId,canonicalName,groupId,version],attachedArtifacts[artifactId,groupId,version]]&pretty=true'
	final String request = "${base}/${buildName}/${buildNumber}/${baseQuery}${query}"

	withCredentials([
		usernamePassword(credentialsId: '0afacacb-18d1-4b9a-a0db-d2c44495bae8', passwordVariable: 'MVN_PASSWORD', usernameVariable: 'MVN_USERNAME')
	]) {
		def result = sh(
			script: "curl  -g -u ${MVN_USERNAME}:${MVN_PASSWORD.replace('$', '\\$')} '${request}'",
			returnStdout: true
		)
		echo "${result}"
		def json = new JsonSlurperClassic().parseText(result)
		return json
	}
}
