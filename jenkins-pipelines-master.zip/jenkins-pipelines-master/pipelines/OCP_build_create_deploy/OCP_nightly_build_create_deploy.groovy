#!Groovy
package OCP_build_create_deploy

import intact.cluster.ocp.Cluster
import groovy.json.JsonSlurperClassic

/**
 * This pipeline is used to call a massBuildCreateDeploy daily of all SNAPSHOTS	in an environment
 */
def jsonToMassBCD

//noinspection GroovyAssignabilityCheck
properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'Check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			[$class: 'WHideParameterDefinition', defaultValue: 'rqq', description: '', name: 'OCP_BASE_PROJECT'],
			[$class: 'WHideParameterDefinition', defaultValue: 'intg', description: '', name: 'ENVIRONMENT'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'BRANCH'],
			[$class: 'WHideParameterDefinition', defaultValue: 'linux', description: '', name: 'NODE'],
		]),
	pipelineTriggers([cron('H 22 * * *')])
])

if (!ONLY_REFRESH_CHOICES.toBoolean()) {
	currentBuild.displayName = "${new Date().format('yyyy-MM-dd')} daily build"
	node(NODE) {
		final String OCP_PROJECT = "${OCP_BASE_PROJECT}-${ENVIRONMENT}${BRANCH.empty ? '' : "-${BRANCH}"}"
		def whatsDeployedJson
		def servicesToBuild
		def buildNamesToBuild

		stage('logging in to ocp project') {
			logToOCP(ENVIRONMENT, OCP_PROJECT)
		}

		stage('whats deployed') {
			sh "oc get dc -n ${OCP_PROJECT} -o json > deploymentConfig-${OCP_PROJECT}.json"
			String deploymentConfig = sh script: "cat deploymentConfig-${OCP_PROJECT}.json", returnStdout: true
			whatsDeployedJson = new JsonSlurperClassic().parseText(deploymentConfig)
		}

		stage('retrieve list of services to build') {
			servicesToBuild = listSnapshot(whatsDeployedJson)
			println("services in SHAPSHOT:${servicesToBuild.toString()}")
		}

		stage('filter services for special cases') {
			servicesToBuild = filterList(servicesToBuild)
			println("filtered list:${servicesToBuild.toString()}")
		}

		stage('retrieve which buildName to build from list of services') {
			buildNamesToBuild = retrieveBuildNamesFromServiceName(servicesToBuild)
		}

		stage('fill the template') {
			String template = getTemplate()
			jsonToMassBCD = fillTemplate(template, buildNamesToBuild)
			println(jsonToMassBCD)
		}

		stage('call the MassBuildCreateDeploy') {
			build job: 'Openshift-pipelines/OCP_35_HQQ_mass_build_create_deploy',
				wait: false,
				parameters: [
					booleanParam(name: 'ONLY_REFRESH_CHOICES', value: false),
					booleanParam(name: 'SKIP_TEST', value: true),
					text(name: 'JSON', value: "${jsonToMassBCD}"),
				]
		}
	}

} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}

//todo export me as a sharedLibrary?
void logToOCP(final String OCP_ENV, final String OCP_PROJECT) {
	String ocpClusterURL = Cluster.clusterByEnv(OCP_ENV).url
	String ocpClusterCredentials = Cluster.clusterByEnv(OCP_ENV).credentialsId
	withCredentials([
		usernamePassword(credentialsId: ocpClusterCredentials, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
	]) {
		sh "oc login ${ocpClusterURL} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
		sh "oc project ${OCP_PROJECT}"
	}
}

/**
 * lists all the services not released yet. Only looks at the projectVersion, not configmap
 * @param json
 * @return
 */
@NonCPS
def listSnapshot(json) {
	final String[] names = json.items.spec.template.metadata.name
	return names.findAll { name ->
		def template = json.items.spec.template.findAll { t ->
			t.metadata.name == name
		}
		String projectVersion = template.metadata.labels.projectVersion[0]
//		println("${name}:${projectVersion}")
		return projectVersion?.endsWith("-SNAPSHOT")
	}
}

/**
 * 	filter special cases that we don't want to rebuild
 * @param servicesToBuild
 * @return
 */
@NonCPS
def filterList(servicesToBuild) {
	println('excluding mongo')
	servicesToBuild.findAll { serviceName ->
		return serviceName != 'mongo'
	}
}

String getTemplate() {
	def templateAsJson = libraryResource 'intact/util/ocp/templates/rqq/massBuildCreateDeploy.json'
	return templateAsJson.toString()
}

@NonCPS
String[] retrieveBuildNamesFromServiceName(servicesToBuild) {
	def jsonFile = libraryResource 'intact/util/ocp/rqq.json'
	def jsonRqq = new JsonSlurperClassic().parseText(jsonFile.toString())
	def projects = jsonRqq.projects.findAll { project ->
		servicesToBuild.contains(project.artifactId)
	}

	return projects.buildName
}

@NonCPS
def fillTemplate(String template, buildNamesToBuild) {
	def json = new groovy.json.JsonSlurper().parseText(template)
	json.deploymentInfo.ENVIRONMENT = 'intg'
	json.deploymentInfo.DESCRIPTION = "${new Date().format('yyyy-MM-dd')} daily build"
	json.projects = json.projects.findAll { project ->
		buildNamesToBuild.contains(project.BUILDNAME)
	}
	def jsonBuilder = new groovy.json.JsonBuilder(json)
	return jsonBuilder.toPrettyString()
}
