#!Groovy
package OCP_build_create_deploy

import groovy.json.JsonSlurperClassic

//@See https://githubifc.iad.ca.inet/DevTools/jenkins-pipeline-shared-librairies
def jsonFile = libraryResource 'intact/util/ocp/rqq.json'
def jsonRqq = new JsonSlurperClassic().parseText(jsonFile)

properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'Check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			booleanParam(defaultValue: false, description: 'Check this if you do not want to call the SOAP UI test at the end of the promote', name: 'SKIP_TEST'),
			[$class: 'TextParameterDefinition', defaultValue: getTemplate(), description: '', name: 'JSON'],
			[$class: 'WHideParameterDefinition', defaultValue: 'mtl2020-docker', description: '', name: 'NODE'],
			[$class: 'WHideParameterDefinition', defaultValue: 'master', description: '', name: 'TEMPLATE_BRANCH']
		])
])

if (!ONLY_REFRESH_CHOICES.toBoolean()) {
	def json = new JsonSlurperClassic().parseText(JSON)
	boolean shouldRunTest = false
	stage('validate input') {
		assert json instanceof Map
		assert !json.deploymentInfo.OCP_BASE_PROJECT.isEmpty(): 'OCP_BASE_PROJECT in json file is empty'
		assert !json.deploymentInfo.ENVIRONMENT.isEmpty(): 'ENVIRONMENT in json file is empty'
		assert json.projects instanceof List
	}
	String description = json.deploymentInfo.DESCRIPTION
	if (!description.isEmpty()) {
		currentBuild.displayName = "#${BUILD_NUMBER}" + description
	}

	String OCP_BASE_PROJECT = json.deploymentInfo.OCP_BASE_PROJECT
	String ENVIRONMENT = json.deploymentInfo.ENVIRONMENT
	String BRANCH = json.deploymentInfo.BRANCH
	int THRESHOLD = Integer.parseInt(json.deploymentInfo.THRESHOLD)

	stage('deploy them all') {
		def projects = json.projects
		def batch
		int batchNumber = 1
		while (!projects.isEmpty()) {
			if (projects.size() > THRESHOLD) {
				batch = projects[0..THRESHOLD - 1]
			} else {
				batch = projects
			}

			def builds = [:]
			node(NODE) {
				for (int i = 0; i < batch.size(); i++) {
					// @ see https://jenkins.io/doc/pipeline/examples/ section : Jobs In Parallel
					def index = i
					String batchDescription = "[${BUILD_NUMBER} : ${batchNumber}]"
					builds["batch${batchNumber} : build${i}"] = {
						BUILDNAME = batch[index].BUILDNAME
						GIT_BRANCH = batch[index].GIT_BRANCH
						COMPANY = batch[index].COMPANY != null ? batch[index].COMPANY : ''
						SKIP_UPDATE_PROPERTIES = batch[index].SKIP_UPDATE_PROPERTIES
						EXPLICIT_VERSION = batch[index].EXPLICIT_VERSION
						EXPLICIT_CONFIGMAP_VERSION = batch[index].EXPLICIT_CONFIGMAP_VERSION
						SKIP_DEPLOY = batch[index].SKIP_DEPLOY


						build job: 'OCP_35_HQQ_build_create_deploy', wait: true, parameters: [

							string(name: 'BUILDNAME', value: BUILDNAME),
							string(name: 'GIT_BRANCH', value: GIT_BRANCH),
							string(name: 'EXPLICIT_VERSION', value: EXPLICIT_VERSION),
							string(name: 'EXPLICIT_CONFIGMAP_VERSION', value: EXPLICIT_CONFIGMAP_VERSION),
							string(name: 'OCP_BASE_PROJECT', value: OCP_BASE_PROJECT),
							string(name: 'ENVIRONMENT', value: ENVIRONMENT),
							string(name: 'BRANCH', value: BRANCH),
							string(name: 'TEMPLATE_BRANCH', value: TEMPLATE_BRANCH),
							string(name: 'SKIP_UPDATE_PROPERTIES', value: SKIP_UPDATE_PROPERTIES),
							string(name: 'COMPANY', value: COMPANY),
							string(name: 'SKIP_DEPLOY', value: SKIP_DEPLOY),
							string(name: 'dummy', value: "${index}"),
							string(name: 'DESCRIPTION', value: description),
							string(name: 'BATCH_DESCRIPTION', value: batchDescription),
							string(name: 'SKIP_WAIT_FOR_OCP_DEPLOYMENT', value: 'true'),
							string(name: 'SKIP_TEST', value: 'true')
						]
					}

					// If one build in the batch needs a test, the soap UI test will be called at the end of this mass job.
					if (!shouldRunTest) {
						for (def p : jsonRqq.projects) {
							if (p.buildName.equals(batch[index].BUILDNAME)) {
								shouldRunTest = p.launchSoapUITest.toBoolean()
							}
						}
					}
				}
				builds.failFast = false
				parallel builds
			}
			projects = projects.drop(THRESHOLD)
			batchNumber++
		}
	}

	if (json.soapui_tests) {
		stage('Calling SOAP UI test') {
			// check if the SKIP_TEST checkbox is checked
			if (!SKIP_TEST.toBoolean()) {

				// test is needed if at least one job in the batch is tagged to launch a soap UI test
				if (shouldRunTest) {

					echo "An application in the batch is tagged to run a soap UI test."
					// load the environment whitelist
					def environmentWhitelist = jsonRqq.soapui_tests.environments

					echo "The soap UI tests environments found in the shared library = ${environmentWhitelist}"

					if (environmentWhitelist.contains(ENVIRONMENT)) {
						echo "${ENVIRONMENT} environment has been found in the whitelist"

						// fetch the soap UI test in the list
						String testJob = jsonRqq.soapui_tests.soapui_test_builds.get(0)

						build job: 'remote_build_SOAPUI_tests', parameters: [
							string(name: 'REMOTE_JOB_NAME', value: "${testJob}")
						], wait: false
					} else {
						echo "${ENVIRONMENT} environment is not in the whitelist. Skipping SOAP UI test call"
					}
				} else {
					echo "The applications in this batch doesn't need to run a test. The SOAP UI test will NOT be called."
				}
			} else {
				echo "Skipping SOAP UI test because SKIP_TEST has been checked"
			}
		}
	} else {
		echo "Skipping SOAP UI test because soapui_tests doesn't exist in the shared library"
	}

} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}

String getTemplate() {
	def templateAsJson = libraryResource 'intact/util/ocp/templates/rqq/massBuildCreateDeploy.json'
	return templateAsJson.toString()
}
