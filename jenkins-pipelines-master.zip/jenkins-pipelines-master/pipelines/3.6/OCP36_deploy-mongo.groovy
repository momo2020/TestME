#!Groovy
package pipelines.OCP_deploy

import groovy.json.JsonSlurperClassic
import intact.cluster.ocp.ClusterInfo
import intact.util.SharedLibraryUtils

def fallbackScript = "return ['ERROR']"
def paths = ["intact/util/ocp/digital/rqq.json",
             "intact/util/ocp/digital/quoters.json",
             "intact/util/ocp/digital/ubi.json",
             "intact/util/ocp/contactpl_36.json"]

// Combine the json files into one big json
def combinedJsonFile = SharedLibraryUtils.combineJson(paths, this)

// Slurp the resulting json enabling access as an object
def json = new JsonSlurperClassic().parseText(combinedJsonFile)

//noinspection GroovyAssignabilityCheck
properties([
        parameters(
                [
                        booleanParam(defaultValue: false, description: 'Check this if you only need to refresh the BUILDNAME or other choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
                        [
                            $class              : 'ChoiceParameter',
                            choiceType          : 'PT_SINGLE_SELECT',
                            description         : 'Select a tribe in order to filter the applications',
                            filterable          : false,
                            name                : 'TRIBE',
                            randomName          : 'choice-parameter-48293583925954',
                            referencedParameters: '',
                            script              : [
                                $class        : 'GroovyScript',
                                fallbackScript: [classpath: [], sandbox: false, script: "return ''"],
                                script        : [classpath: [], sandbox: false, script: "return ['contactpl_36','rqq', 'quoters', 'ubi']"]
                            ]
                        ],
                        [$class: 'WHideParameterDefinition', defaultValue: "${combinedJsonFile}", description: 'used to pass down to other pipelines', name: 'JSON_FILE'],
                        [
                            $class              : 'CascadeChoiceParameter',
                            choiceType          : 'PT_SINGLE_SELECT',
                            description         : '',
                            filterable          : true,
                            name                : 'BASE_PROJECT',
                            randomName          : 'choice-parameter-67545844545948',
                            referencedParameters: 'TRIBE, JSON_FILE',
                            script              : [
                                $class        : 'GroovyScript',
                                fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                script        : [classpath: [], sandbox: false, script: createParameterScript("ocp_base_projects")]
                            ]
                        ],
                        [
                            $class              : 'CascadeChoiceParameter',
                            choiceType          : 'PT_SINGLE_SELECT',
                            description         : '',
                            filterable          : true,
                            name                : 'ENVIRONMENT',
                            randomName          : 'choice-parameter-66545844545948',
                            referencedParameters: 'TRIBE, JSON_FILE',
                            script              : [
                                $class        : 'GroovyScript',
                                fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                script        : [classpath: [], sandbox: false, script: createParameterScript("environments")]
                            ]
                        ],
                        [
                            $class              : 'CascadeChoiceParameter',
                            choiceType          : 'PT_SINGLE_SELECT',
                            description         : '',
                            filterable          : true,
                            name                : 'BRANCH',
                            randomName          : 'choice-parameter-67545844570948',
                            referencedParameters: 'TRIBE, JSON_FILE',
                            script              : [
                                $class        : 'GroovyScript',
                                fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                script        : [classpath: [], sandbox: false, script: createParameterScript("branches")]
                            ]
                        ]
                ])
])

final String REPOSITORY = 'mongo'
final String PROJECT = "${BASE_PROJECT}-${ENVIRONMENT}${BRANCH.empty ? '' : "-${BRANCH}"}"

currentBuild.displayName = "#${BUILD_NUMBER} ${REPOSITORY} -> ${PROJECT}"
if (!ONLY_REFRESH_CHOICES.toBoolean()) {
    node('master') {
        stage("Load sources") {
            dir("templates") {
                git branch: 'master', credentialsId: 'build-maven', url: 'https://githubifc.iad.ca.inet/DevTools/openshift-templates.git'
            }
        }

        stage('login to OCP36') {
            logToOCP(ENVIRONMENT, BASE_PROJECT)
        }

        stage('Process Intact template') {
            dir("templates") {
                sh "oc process -n ${PROJECT} -f intact-ocp-mongo-template.yaml -v PROJECT=${PROJECT} -o yaml > processed.yaml"
                sh 'cat processed.yaml'
                template = readFile 'intact-ocp-template.yaml'
                processed = readFile 'processed.yaml'
            }
        }

        stage('Deploy to OCP') {
            dir("templates") {
                sh "oc apply -n ${PROJECT} -f processed.yaml"
                sh "oc rollout history dc/${REPOSITORY} -n ${PROJECT}"
                // looks at the current deployment history and starts a deploy if it's not already deploying (if status is not Complete or Failed
                sh "if [[ `oc rollout history dc/${REPOSITORY} -n ${PROJECT} | tail -2` =~ Complete|Failed ]]; then oc deploy ${REPOSITORY} -n ${PROJECT} --latest; else echo deployment already on the way;  fi"
            }
        }

        stage('Waiting for deployment') {
            timeout(time: 5, unit: 'MINUTES') {
                String rolloutHistory = ''
                waitUntil {
                    sleep time: 10, unit: 'SECONDS'
                    rolloutHistory = sh script: "oc rollout history dc/${REPOSITORY} -n ${PROJECT} | tail -2", returnStdout: true
                    println('status : ' + rolloutHistory)
                    return rolloutHistory.contains('Complete') || rolloutHistory.contains('Failed')
                }
            }
        }

        stage('Clean up'){
            ws(pwd() + "@tmp") {
                step([$class: 'WsCleanup'])
            }
            ws(pwd() + "@libs") {
                step([$class: 'WsCleanup'])
            }
            ws(pwd() + "@script") {
                step([$class: 'WsCleanup'])
            }
            deleteDir()
        }
    }
}   else {
    currentBuild.displayName = 'REFRESHED CHOICES'
}
void logToOCP(final String OCP_ENV, final String TEAM) {
    url = ClusterInfo.clusterByEnv(OCP_ENV).url
    credentialsId = ClusterInfo.clusterByEnv(OCP_ENV).credentialsIdByTeam(TEAM)
    withCredentials([
            usernamePassword(credentialsId: credentialsId, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
    ]) {
        sh "oc login ${url} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
    }
}

def createParameterScript(value) {
    String returnValue = value

    // We may want to retrieve more specific value from a project
    switch (value) {
        case "appId":
            returnValue = "projects.appId"
            break
        default:
            break
    }

    def script = """import groovy.json.JsonSlurperClassic
	def json = new JsonSlurperClassic().parseText(JSON_FILE)
	return json[TRIBE].${returnValue}
	"""

    return script
}
