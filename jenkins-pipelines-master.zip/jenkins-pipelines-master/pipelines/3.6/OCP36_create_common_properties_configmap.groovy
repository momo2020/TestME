#!Groovy
import intact.cluster.ocp.ClusterInfo
import groovy.json.JsonSlurperClassic
import intact.util.SharedLibraryUtils

def fallbackScript = "return ['ERROR']"
def paths = ["intact/util/ocp/digital/rqq.json",
			 "intact/util/ocp/digital/quoters.json",
			 "intact/util/ocp/digital/ubi.json",
			 "intact/util/ocp/contactpl_36.json"]

// Combine the json files into one big json
def combinedJsonFile = SharedLibraryUtils.combineJson(paths, this)

// Slurp the resulting json enabling access as an object
def json = new JsonSlurperClassic().parseText(combinedJsonFile)

//noinspection GroovyAssignabilityCheck
properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			[$class: 'WHideParameterDefinition', defaultValue: "${combinedJsonFile}", description: 'used to pass down to other pipelines', name: 'JSON_FILE'],
			[
				$class              : 'ChoiceParameter',
				choiceType          : 'PT_SINGLE_SELECT',
				description         : 'Select a tribe in order to filter the applications',
				filterable          : false,
				name                : 'TRIBE',
				randomName          : 'choice-parameter-41234583925954',
				referencedParameters: '',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: "return ''"],
					script        : [classpath: [], sandbox: false, script: "return ['contactpl_36', 'rqq', 'quoters', 'ubi']"]
				]
			],
			[
				$class              : 'CascadeChoiceParameter',
				choiceType          : 'PT_SINGLE_SELECT',
				description         : '',
				filterable          : true,
				name                : 'BASE_PROJECT',
				randomName          : 'choice-parameter-43165844545948',
				referencedParameters: 'TRIBE, JSON_FILE',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
					script        : [classpath: [], sandbox: false, script: createParameterScript("ocp_base_projects")]
				]
			],
			[
				$class              : 'CascadeChoiceParameter',
				choiceType          : 'PT_SINGLE_SELECT',
				description         : '',
				filterable          : true,
				name                : 'ENVIRONMENT',
				randomName          : 'choice-parameter-43255844545948',
				referencedParameters: 'TRIBE, JSON_FILE',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
					script        : [classpath: [], sandbox: false, script: createParameterScript("environments")]
				]
			],
			[
				$class              : 'CascadeChoiceParameter',
				choiceType          : 'PT_SINGLE_SELECT',
				description         : '',
				filterable          : true,
				name                : 'BRANCH',
				randomName          : 'choice-parameter-67545844571153',
				referencedParameters: 'TRIBE, JSON_FILE',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
					script        : [classpath: [], sandbox: false, script: createParameterScript("branches")]
				]
			],
			string(defaultValue: '1.0.1.1', description: '', name: 'COMMON_CONFIGMAP_VERSION'),
		])
])
// Overrides the json object with the correct tribe's json
json = json[TRIBE]

final String PROJECT = "${BASE_PROJECT}-${ENVIRONMENT}${BRANCH.empty ? '' : "-${BRANCH}"}"
final String GROUPID = 'intact.openshift.common'
final String ARTIFACTID = "common-configmap-${BASE_PROJECT}"
final String CONFIGMAPNAME = "configmap-common.properties"
final String TEAM = json.team

if (!ONLY_REFRESH_CHOICES.toBoolean()) {

	node('master') {
			stage("Retrieve properties zip") {

				withCredentials([
					usernamePassword(credentialsId: 'build-maven', passwordVariable: 'NEXUS2_PASSWORD', usernameVariable: 'NEXUS2_USERNAME')
				]) {
					sh script: $/curl -L -o $ARTIFACTID-common-configmap.zip -u ${NEXUS2_USERNAME}:${NEXUS2_PASSWORD.replace('$', '\\$')} "https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/service/local/artifact/maven/redirect?r=public&g=${GROUPID}&a=${ARTIFACTID}&v=${COMMON_CONFIGMAP_VERSION}&e=zip&c=common-configmap"/$
				}

				sh "unzip $ARTIFACTID-common-configmap.zip"
			}

		stage('Create configmap') {
			configMapFile = "${BASE_PROJECT}/${ENVIRONMENT}${BRANCH.empty ? '' : "/${BRANCH}"}/$CONFIGMAPNAME"
			// we add the configMap-common version in the last line in order to retrieve it in the containter-info (in the setenv.sh of the dockerBaseImage)
			sh "echo -e '\r\nCONFIGMAP_COMMON_GAV=$GROUPID:$ARTIFACTID:$COMMON_CONFIGMAP_VERSION' >> $configMapFile"
			logToOCP(ENVIRONMENT, TEAM)
			sh "oc create configmap $CONFIGMAPNAME -n $PROJECT --from-file=$configMapFile --dry-run=true -o yaml > configForApply.yaml"
			sh "oc apply -n ${PROJECT} -f configForApply.yaml"
		}

		stage('Clean up'){
			ws(pwd() + "@tmp") {
				step([$class: 'WsCleanup'])
			}
			ws(pwd() + "@libs") {
				step([$class: 'WsCleanup'])
			}
			ws(pwd() + "@script") {
				step([$class: 'WsCleanup'])
			}
			deleteDir()
		}
	}

} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}

//todo export me as a sharedLibrary?
void logToOCP(final String OCP_ENV, final String TEAM) {
	url = ClusterInfo.clusterByEnv(OCP_ENV).url
	credentialsId = ClusterInfo.clusterByEnv(OCP_ENV).credentialsIdByTeam(TEAM)
	echo "attempting oc login with credentialsID ${credentialsId}"
	withCredentials([
		usernamePassword(credentialsId: credentialsId, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
	]) {
		sh "oc login ${url} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
	}
}

def createParameterScript(value) {
	String returnValue = value

	// We may want to retrieve more specific value from a project
	switch (value) {
		case "appId":
			returnValue = "projects.appId"
			break
		default:
			break
	}

	def script = """import groovy.json.JsonSlurperClassic
	def json = new JsonSlurperClassic().parseText(JSON_FILE)
	return json[TRIBE].${returnValue}
	"""

	return script
}
