import groovy.json.JsonSlurperClassic
import intact.cluster.ocp.ClusterInfo
import intact.util.SharedLibraryUtils

node('master') {
//@See https://githubifc.iad.ca.inet/DevTools/jenkins-pipeline-shared-librairies
    def fallbackScript = "return ['ERROR']"
    def paths = ["intact/util/ocp/digital/rqq.json",
                 "intact/util/ocp/digital/quoters.json",
                 "intact/util/ocp/digital/ubi.json",
                 "intact/util/ocp/contactpl_36.json"]

    // Combine the json files into one big json
    def combinedJsonFile = SharedLibraryUtils.combineJson(paths, this)

    // Slurp the resulting json enabling access as an object
    def json = new JsonSlurperClassic().parseText(combinedJsonFile)

//noinspection GroovyAssignabilityCheck
    properties([
            parameters(
                    [
                            booleanParam(defaultValue: false, description: 'Check this if you only need to refresh the BUILDNAME or other choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
                            [$class: 'WHideParameterDefinition', defaultValue: "${combinedJsonFile}", description: 'used to pass down to other pipelines', name: 'JSON_FILE'],
                            [
                                    $class              : 'ChoiceParameter',
                                    choiceType          : 'PT_SINGLE_SELECT',
                                    description         : 'Select a tribe in order to filter the applications',
                                    filterable          : false,
                                    name                : 'TRIBE',
                                    randomName          : 'choice-parameter-48293583925954',
                                    referencedParameters: '',
                                    script              : [
                                            $class        : 'GroovyScript',
                                            fallbackScript: [classpath: [], sandbox: false, script: "return ''"],
                                            script        : [classpath: [], sandbox: false, script: "return ['contactpl_36', 'rqq', 'quoters', 'ubi']"]
                                    ]
                            ],
                            [
                                    $class              : 'CascadeChoiceParameter',
                                    choiceType          : 'PT_SINGLE_SELECT',
                                    description         : '',
                                    filterable          : true,
                                    name                : 'APP_PARENT',
                                    randomName          : 'choice-parameter-68065844775948',
                                    referencedParameters: 'TRIBE, JSON_FILE',
                                    script              : [
                                            $class        : 'GroovyScript',
                                            fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                            script        : [classpath: [], sandbox: false, script: createParameterScript("appId")]
                                    ]
                            ],
                            [
                                    $class              : 'CascadeChoiceParameter',
                                    choiceType          : 'PT_SINGLE_SELECT',
                                    description         : '',
                                    filterable          : true,
                                    name                : 'BASE_PROJECT',
                                    randomName          : 'choice-parameter-67545844545948',
                                    referencedParameters: 'TRIBE, JSON_FILE',
                                    script              : [
                                            $class        : 'GroovyScript',
                                            fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                            script        : [classpath: [], sandbox: false, script: createParameterScript("ocp_base_projects")]
                                    ]
                            ],
                            [
                                    $class              : 'CascadeChoiceParameter',
                                    choiceType          : 'PT_SINGLE_SELECT',
                                    description         : '',
                                    filterable          : true,
                                    name                : 'ENVIRONMENT',
                                    randomName          : 'choice-parameter-66545844545948',
                                    referencedParameters: 'TRIBE, JSON_FILE',
                                    script              : [
                                            $class        : 'GroovyScript',
                                            fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                            script        : [classpath: [], sandbox: false, script: createParameterScript("environments")]
                                    ]
                            ],
                            [
                                    $class              : 'CascadeChoiceParameter',
                                    choiceType          : 'PT_SINGLE_SELECT',
                                    description         : '',
                                    filterable          : true,
                                    name                : 'BRANCH',
                                    randomName          : 'choice-parameter-67545844570948',
                                    referencedParameters: 'TRIBE, JSON_FILE',
                                    script              : [
                                            $class        : 'GroovyScript',
                                            fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                            script        : [classpath: [], sandbox: false, script: createParameterScript("branches")]
                                    ]
                            ]
                    ])
    ])
    if (!ONLY_REFRESH_CHOICES.toBoolean()) {

        // Overrides the json object with the correct tribe's json
        json = json[TRIBE]
        def project
        final String TEAM = json.team
        String APPLICATION
        String CONFIGMAP_VERSION
        String CONFIGMAP_LONGVERSION
        String LATEST_COMPLETE_DEPLOY_NUMBER
        String PROJECT = "$BASE_PROJECT-$ENVIRONMENT${BRANCH.empty ? '' : "-$BRANCH"}"

        stage("retrieve project from json shared property") {
            project = SharedLibraryUtils.retrieveProjectFromAppId(APP_PARENT, json, this)
            APPLICATION = project.artifactId
        }
        stage('Log to OCP...'){
            logToOCP(ENVIRONMENT, TEAM)
        }
        stage('Retrieve props from latest completed deployment'){
            LATEST_COMPLETE_DEPLOY_NUMBER = getLatestCompletedRcNumber(APPLICATION, PROJECT)
            if(LATEST_COMPLETE_DEPLOY_NUMBER == '0'){
                println(    """
                                ******************************************
                                               !!!ERROR!!!
                                   THERE IS NO VERSION TO ROLLBACK TO
                                               !!!ERROR!!!
                                ******************************************
                            """)
                assert false
            }
            sh "echo LATEST_COMPLETE_DEPLOY_NUMBER = $LATEST_COMPLETE_DEPLOY_NUMBER"
            CONFIGMAP_LONGVERSION = sh script: "oc rollback $APPLICATION -n $PROJECT --to-version=$LATEST_COMPLETE_DEPLOY_NUMBER --dry-run | grep 'CONFIGMAP_LONGVERSION:' | sed 's/CONFIGMAP_LONGVERSION://'", returnStdout: true
            CONFIGMAP_LONGVERSION = CONFIGMAP_LONGVERSION.trim()
            CONFIGMAP_VERSION = CONFIGMAP_LONGVERSION.replaceAll(/(?=-)+-\d+.\d+-\d+$/, "-SNAPSHOT")
            sh "echo CONFIGMAP_VERSION = $CONFIGMAP_VERSION"
            sh "echo CONFIGMAP_LONGVERSION = $CONFIGMAP_LONGVERSION"
        }
        stage('Deploy new props'){
            build job: 'OCP36_create_properties_configmap', parameters: [
                string(name: 'TRIBE', value: TRIBE),
                string(name: 'APP_PARENT', value: APP_PARENT),
                string(name: 'ENVIRONMENT', value: ENVIRONMENT),
                string(name: 'BRANCH', value: BRANCH),
                string(name: 'BASE_PROJECT', value: BASE_PROJECT),
                string(name: 'CONFIGMAP_VERSION', value: CONFIGMAP_VERSION),
                string(name: 'CONFIGMAP_LONGVERSION', value: CONFIGMAP_LONGVERSION)
            ]
        }
        stage('Rollback... and reset triggers'){
            sh "oc rollback $APPLICATION --to-version=$LATEST_COMPLETE_DEPLOY_NUMBER -n $PROJECT | oc set triggers dc/$APPLICATION -n $PROJECT --auto"
        }

        stage('Clean up'){
            ws(pwd() + "@tmp") {
                step([$class: 'WsCleanup'])
            }
            ws(pwd() + "@libs") {
                step([$class: 'WsCleanup'])
            }
            ws(pwd() + "@script") {
                step([$class: 'WsCleanup'])
            }
            deleteDir()
        }

        currentBuild.displayName = "#${BUILD_NUMBER} $APP_PARENT"
    } else {
        currentBuild.displayName = 'REFRESHED CHOICES'
    }
}

void logToOCP(final String OCP_ENV, final String TEAM) {
    url = ClusterInfo.clusterByEnv(OCP_ENV).url
    credentialsId = ClusterInfo.clusterByEnv(OCP_ENV).credentialsIdByTeam(TEAM)
    echo "attempting oc login with credentialsID ${credentialsId}"
    withCredentials([
            usernamePassword(credentialsId: credentialsId, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
    ]) {
        sh "oc login ${url} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
    }
}

def createParameterScript(value) {
    String returnValue = value

    // We may want to retrieve more specific value from a project
    switch (value) {
        case "appId":
            returnValue = "projects.appId"
            break
        default:
            break
    }

    def script = """import groovy.json.JsonSlurperClassic
	def json = new JsonSlurperClassic().parseText(JSON_FILE)
	return json[TRIBE].${returnValue}
	"""

    return script
}

String getLatestCompletedRcNumber(def APPLICATION, def PROJECT) {
    /**
     * Retrieve all rc and grep them with the APPLICATION name
     */
    String appRC = sh script: "oc get rc -o wide -n $PROJECT | grep '$APPLICATION'", returnStdout: true
    String complete
    String running
    int versionRunning
    String[] data = appRC.split('\n')
    List<String> deployment = new ArrayList<String>()
    /**
     * Retrieve all deployment's names from all deployment
     */
    for (String line : data) {
        deployment.add(line.find(/$APPLICATION-[0-9]*/))
    }
    /**
     * Concat all deployment's names into the command
     * to retrieve infos only on our APPLICATION
     */
    def rcjson = sh script: "oc get rc ${deployment.join(' ')} -o json -n $PROJECT", returnStdout: true
    def jsonRC = new JsonSlurperClassic().parseText(rcjson)
    /**
     * Search for the running version of the APPLICATION
     */
    for (def item : jsonRC.items) {
        if (!item.status.replicas.toInteger().equals(0)) {
            running = item.metadata.name
        }
    }
    versionRunning = getVersion(running)
    complete = '0'
    /**
     * Look for deployments completed from the version-1 of the one running to version 0...
     * When it finds a completed, it will immediately return the value of the version
     * If no version completed found, return 0
     */
    for (int versionSearch = versionRunning - 1; versionSearch > 0; versionSearch--) {
        for (def item : jsonRC.items) {
            if (item.metadata.annotations.'openshift.io/deployment.phase'.contains("Complete") && item.metadata.name.contains("$APPLICATION-$versionSearch")) {
                complete = "$versionSearch"
                return complete
            }
        }
    }
    return complete
}
/**
 * Get the number of the running deploy
 * @param running
 * @return
 */
static int getVersion(String running){
    String version = running.find(/\d*$/)
    int versionNumber = version.toInteger()
    return versionNumber
}
