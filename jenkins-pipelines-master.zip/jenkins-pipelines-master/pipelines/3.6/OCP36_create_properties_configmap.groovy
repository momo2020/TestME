#!Groovy
import groovy.json.JsonSlurperClassic
import intact.cluster.ocp.ClusterInfo
import intact.util.SharedLibraryUtils

//@See https://githubifc.iad.ca.inet/DevTools/jenkins-pipeline-shared-librairies
def paths = ["intact/util/ocp/digital/rqq.json",
			 "intact/util/ocp/digital/quoters.json",
			 "intact/util/ocp/digital/ubi.json",
			 "intact/util/ocp/contactpl_36.json"]

// Combine the json files into one big json
def combinedJsonFile = SharedLibraryUtils.combineJson(paths, this)

// Slurp the resulting json enabling access as an object
def json = new JsonSlurperClassic().parseText(combinedJsonFile)

def actionPerformScript = 'return ["<font color=\\"red\\"><b>THIS BUILD WILL CRASH BECAUSE YOU HAVE TO FILL THE PARAMETERS SECTION THAT IS HIDDEN.</b></font>"]'

//noinspection GroovyAssignabilityCheck
properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'Check this if you only need to refresh the BUILDNAME or other choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			[$class: 'WHideParameterDefinition', defaultValue: "${combinedJsonFile}", description: 'used to pass down to other pipelines', name: 'JSON_FILE'],
			[$class: 'WHideParameterDefinition', defaultValue: "rqq", description: 'used to pass down to other pipelines', name: 'TRIBE'],
			[$class: 'WHideParameterDefinition', description: 'used to pass down to other pipelines', name: 'APP_PARENT'],
			[$class: 'WHideParameterDefinition', description: 'used to pass down to other pipelines', name: 'BASE_PROJECT'],
			[$class: 'WHideParameterDefinition', description: 'used to pass down to other pipelines', name: 'ENVIRONMENT'],
			[$class: 'WHideParameterDefinition', description: 'used to pass down to other pipelines', name: 'BRANCH'],
			[$class: 'WHideParameterDefinition', description: 'used to pass down to other pipelines', name: 'CONFIGMAP_VERSION'],
			[$class: 'WHideParameterDefinition', description: 'used to pass down to other pipelines', name: 'CONFIGMAP_LONGVERSION'],
			[
				$class              : 'DynamicReferenceParameter',
				choiceType          : 'ET_FORMATTED_HTML',
				description         : '',
				name                : '',
				omitValueField      : false,
				randomName          : 'choice-parameter-68846872653719',
				referencedParameters: 'APP_PARENT, BASE_PROJECT, ENVIRONMENT, BRANCH, CONFIGMAP_VERSION, CONFIGMAP_LONGVERSION, TRIBE',
				script              : [
					$class: 'GroovyScript',
					script: [classpath: [], sandbox: false, script: actionPerformScript],
				]
			]
		])
])
// Overrides the json object with the correct tribe's json
json = json[TRIBE]

def project // the project in shareLibrary containing all meta info
final String ORGANIZATION // the GitHub organization
final String GROUP_ID    // the groupId of the app
final String APP_DOCKER // the artifactId of the docker-module
final String APPLICATION // the artifactId of the module containing the war
final String PROJECT = "${BASE_PROJECT}-${ENVIRONMENT}${BRANCH.empty ? '' : "-${BRANCH}"}"
final String TEAM = json.team
String CONFIGMAP_FILE

if (!ONLY_REFRESH_CHOICES.toBoolean()) {
	node('master') {
		deleteDir()
		def USER = wrap([$class: 'BuildUser']) {return env.BUILD_USER} // retrieve the user who started the build

		stage("retrieve project from json shared property") {
			project = SharedLibraryUtils.retrieveProjectFromAppId(APP_PARENT, json, this)
		}

		stage('validate inputs') {
			ORGANIZATION = project.gitHubOrgName
			GROUP_ID = project.groupId
			APP_DOCKER = project.dockerId
			APPLICATION = project.artifactId

			SERVICE = APPLICATION.replaceAll('-', '')
			if (SERVICE.length() > 24) {
				SERVICE = SERVICE.substring(0, 24)
			}

			echo """
					ORGANIZATION = $ORGANIZATION
					GROUP_ID = $GROUP_ID
					APPLICATION = $APPLICATION
					APP_DOCKER = $APP_DOCKER
					CONFIGMAP_VERSION = $CONFIGMAP_VERSION
					CONFIGMAP_LONGVERSION = $CONFIGMAP_LONGVERSION
					PROJECT = $PROJECT
				"""
		}

		stage("Retrieve properties zip") {
			withCredentials([
				usernamePassword(credentialsId: 'build-maven', passwordVariable: 'NEXUS2_PASSWORD', usernameVariable: 'NEXUS2_USERNAME')
			]) {
				if (CONFIGMAP_VERSION.contains('SNAPSHOT')) {
					String CONFIGMAP = 'configmap.zip'
					GROUP_ID = GROUP_ID.replace('.', '/')
					String NEXUS_URL_SNAPSHOT = "https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/service/local/repo_groups/public/content/$GROUP_ID/$APP_DOCKER/$CONFIGMAP_VERSION/$APP_DOCKER-$CONFIGMAP_LONGVERSION-$CONFIGMAP"
					sh script: $/curl -L -o $APP_DOCKER-configmap.zip -u ${NEXUS2_USERNAME}:${NEXUS2_PASSWORD.replace('$', '\\$')} $NEXUS_URL_SNAPSHOT/$
				} else {
					sh script: $/curl -L -o $APP_DOCKER-configmap.zip -u ${NEXUS2_USERNAME}:${NEXUS2_PASSWORD.replace('$', '\\$')} "https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/service/local/artifact/maven/redirect?r=public&g=$GROUP_ID&a=$APP_DOCKER&v=$CONFIGMAP_VERSION&e=zip&c=configmap"/$
				}

			}
			sh "unzip $APP_DOCKER-configmap.zip"
		}

		stage('Create configmap') {
			if (fileExists('src/Rules.json')) {
				println("RECETTE 3!!!")

				sh "chmod u+w src"
				dir('src'){
					String rulesJsonPath = "Rules.json"
					File configMapFile = new File("$WORKSPACE/src/tmpConfigmap.properties")
					configMapFile.write(rulesExtractor(BASE_PROJECT, ENVIRONMENT, BRANCH, rulesJsonPath))
					sh "cat $configMapFile >> configmap.properties"
					CONFIGMAP_FILE = "src/configmap.properties"
				}

			} else {
				println("RECETTE 1!!!")

				CONFIGMAP_FILE = "src/configmap/$BASE_PROJECT/${ENVIRONMENT}${BRANCH.empty ? '' : "-${BRANCH}"}/configmap.properties"
				String CONFIGMAP_FILE_ALTERNATIVE_PATH = "src/configmap/${ENVIRONMENT}${BRANCH.empty ? '' : "-${BRANCH}"}/configmap.properties"
				// if the configmap is neither found in the usual path or in the alternate (deprecated) one, we create an empty one
				if (fileExists("$CONFIGMAP_FILE")) {
					sh("cp $CONFIGMAP_FILE configmap.properties")
				} else if (fileExists("$CONFIGMAP_FILE_ALTERNATIVE_PATH")) {
					println("$CONFIGMAP_FILE file is not found, using old path not containing the ocp_project as root")
					println("consider refactoring the source code by moving the properties file in your own ocp_project as root")
					sh("cp $CONFIGMAP_FILE_ALTERNATIVE_PATH configmap.properties")
				} else {
					println("WARNING : configmap.properties not found in $APP_DOCKER-configmap.zip. An empty file will be created")
					sh("touch configmap.properties")
				}
			}

			// we add the configMap longVersion in the last line in order to retrieve it in the containter-info (in the setenv.sh of the dockerBaseImage)
			sh "echo -e '\r\nCONFIGMAP_GAV=$GROUP_ID:$APP_DOCKER:$CONFIGMAP_LONGVERSION' >> $CONFIGMAP_FILE"
			sh "echo -e '\r\nJENKINS_USER=$USER' >> $CONFIGMAP_FILE"

			logToOCP(ENVIRONMENT, TEAM)
			sh "oc create configmap ${APPLICATION}.properties -n $PROJECT --from-file=$CONFIGMAP_FILE --dry-run=true -o yaml > configForApply.yaml"
			sh "oc apply -n $PROJECT -f configForApply.yaml"
		}

		stage('Clean up'){
			ws(pwd() + "@tmp") {
				step([$class: 'WsCleanup'])
			}
			ws(pwd() + "@libs") {
				step([$class: 'WsCleanup'])
			}
			ws(pwd() + "@script") {
				step([$class: 'WsCleanup'])
			}
		}

		currentBuild.displayName = "last image: #$BUILD_NUMBER $APP_PARENT:$CONFIGMAP_VERSION"
	}

} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}

//todo export me as a sharedLibrary?
void logToOCP(final String OCP_ENV, final String TEAM) {
	url = ClusterInfo.clusterByEnv(OCP_ENV).url
	credentialsId = ClusterInfo.clusterByEnv(OCP_ENV).credentialsIdByTeam(TEAM)
	echo "attempting oc login with credentialsID ${credentialsId}"
	withCredentials([
		usernamePassword(credentialsId: credentialsId, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
	]) {
		sh "oc login ${url} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
	}
}

String rulesExtractor(def BASE_PROJECT, def ENVIRONMENT, def BRANCH, String rulesJsonPath){
	String rulesJson = sh script: "cat $rulesJsonPath", returnStdout: true
	def json = new JsonSlurperClassic().parseText(rulesJson)
	def date = new Date()

	String rulesOutpout = "\n#Date: $date\n"
	String PROJECT = "$BASE_PROJECT-$ENVIRONMENT${BRANCH.empty ? '-default' : "-${BRANCH}"}"
	String[] envTab = ["${PROJECT}", "Common-${BASE_PROJECT}", "Common"]
	def rulesMap = [:]

	for(def env : envTab){
		rulesOutpout += "\n#From Instance Rules:$env\n"
		for (def item : json) {
			if (item.Name == env) {
				for (def vars : item.Vars) {
					def key = vars.keySet()[0]
					def value = vars.get(key)
					if (!rulesMap.containsKey(key)) {
						rulesOutpout += "${key} = ${value}\n"
						rulesMap.put(key, value)
					}
				}
			}
		}
	}
	return rulesOutpout
}
