#!Groovy
package pipelines.OCP_build_base_image

import groovy.json.JsonSlurperClassic
import intact.cluster.ocp.ClusterInfo
import intact.util.SharedLibraryUtils
import intact.registry.Registry

//@See https://githubifc.iad.ca.inet/DevTools/jenkins-pipeline-shared-librairies

def fallbackScript = "return ['ERROR']"
def paths = ["intact/util/ocp/digital/rqq.json",
             "intact/util/ocp/digital/quoters.json",
             "intact/util/ocp/digital/ubi.json",
             "intact/util/ocp/contactpl_36.json"]

// Combine the json files into one big json
def combinedJsonFile = SharedLibraryUtils.combineJson(paths, this)

// Slurp the resulting json enabling access as an object
def json = new JsonSlurperClassic().parseText(combinedJsonFile)

//noinspection GroovyAssignabilityCheck
properties([
        parameters(
                [
                        booleanParam(defaultValue: false, description: 'Check this if you only need to refresh the BUILDNAME or other choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
                        booleanParam(defaultValue: false, description: 'Check this if the image is ready to be a golden one.', name: 'GOLDEN'),
                        [
                            $class              : 'ChoiceParameter',
                            choiceType          : 'PT_SINGLE_SELECT',
                            description         : 'Select a tribe in order to filter the applications',
                            filterable          : false,
                            name                : 'TRIBE',
                            randomName          : 'choice-parameter-48293583925954',
                            referencedParameters: '',
                            script              : [
                                $class        : 'GroovyScript',
                                fallbackScript: [classpath: [], sandbox: false, script: "return ''"],
                                script        : [classpath: [], sandbox: false, script: "return ['contactpl_36','rqq', 'quoters', 'ubi']"]
                            ]
                        ],
                        [$class: 'WHideParameterDefinition', defaultValue: "${combinedJsonFile}", description: 'used to pass down to other pipelines', name: 'JSON_FILE'],
                        [$class            : 'ExtensibleChoiceParameterDefinition',
                         choiceListProvider: [$class: 'TextareaChoiceListProvider',
                                              addEditedValue: true,
                                              choiceListText: ['ocp-tomcat8-base',
                                                               'ocp-tomcat8-mq-base',
                                                               'ocp-tomee7-base',
                                                               'ocp-tomee7-mq-base',
                                                               'ocp-tomee7-jre7-base',
                                                               'ocp-tomee7-jre7-mq-base',
                                                               'ocp-tomcat8-base,ocp-tomcat8-mq-base,ocp-tomee7-base,ocp-tomee7-mq-base,ocp-tomee7-jre7-base,ocp-tomee7-jre7-mq-base'].join("\n"),
                                              whenToAdd: 'CompletedStable'],
                         description       : 'The repository for the image to build. It is assumed that there is a folder with named like this repository: devtools.docker.base-images_MASTER_STR > devtools.docker.base-images_CMP > <em>repository</em>\n' +
                                             'To build multiple images at one, seperate the image name with a comma (,)',
                         editable          : true,
                         name              : 'REPOSITORY'
                        ],
                        string(defaultValue: 'master', description: '', name: 'GIT_BRANCH'),
                        string(defaultValue: 'DockerBaseImages', description: '', name: 'ORGANIZATION'),
                        [
                            $class              : 'CascadeChoiceParameter',
                            choiceType          : 'PT_SINGLE_SELECT',
                            description         : '',
                            filterable          : true,
                            name                : 'BASE_PROJECT',
                            randomName          : 'choice-parameter-67545844545948',
                            referencedParameters: 'TRIBE, JSON_FILE',
                            script              : [
                                $class        : 'GroovyScript',
                                fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                script        : [classpath: [], sandbox: false, script: createParameterScript("ocp_base_projects")]
                            ]
                        ],
                        [
                                $class              : 'CascadeChoiceParameter',
                                choiceType          : 'PT_SINGLE_SELECT',
                                description         : '',
                                filterable          : true,
                                name                : 'ENVIRONMENT',
                                randomName          : 'choice-parameter-66545844545948',
                                referencedParameters: 'TRIBE, JSON_FILE',
                                script              : [
                                        $class        : 'GroovyScript',
                                        fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                        script        : [classpath: [], sandbox: false, script: createParameterScript("environments")]
                                ]
                        ],
                        [
                                $class              : 'CascadeChoiceParameter',
                                choiceType          : 'PT_SINGLE_SELECT',
                                description         : '',
                                filterable          : true,
                                name                : 'BRANCH',
                                randomName          : 'choice-parameter-67545844570948',
                                referencedParameters: 'TRIBE, JSON_FILE',
                                script              : [
                                        $class        : 'GroovyScript',
                                        fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                        script        : [classpath: [], sandbox: false, script: createParameterScript("branches")]
                                ]
                        ]
                ]
        )
])
if (!ONLY_REFRESH_CHOICES.toBoolean()) {

    // Overrides the json object with the correct tribe's json
    json = json[TRIBE]

    String TEAM = json.team
    //TODO change the release var when nexus is rdy
    String NEXUS_ENV = 'release'
    String PROJECT = "${BASE_PROJECT}-${ENVIRONMENT}${BRANCH.empty ? '' : "-${BRANCH}"}"
    NEXUS_HOST = Registry.registryByEnv("$NEXUS_ENV").host
    OCP_HOST = Registry.registryByEnv(ENVIRONMENT).host
    DOCKER_RELEASE_PUSH_REGISTRY = Registry.registryByEnv("$NEXUS_ENV")
    DOCKER_RELEASE_PUSH_REGISTRY_CREDENTIALID = DOCKER_RELEASE_PUSH_REGISTRY.credentialsIdByTeam(TEAM)

    node('master') {
        repositories = REPOSITORY.split(',')
        stage('Log to OCP'){
            echo 'login to OCP...'
            logToOCP(ENVIRONMENT, TEAM)
        }

        stage("Build Images") {
            for (int i = 0; i < repositories.length; i++) {
                currentRepository = repositories[i].trim()

                echo """
                        *****************************
                        REPOSITORY $currentRepository
                        *****************************"""
                git branch: GIT_BRANCH, credentialsId: 'build-maven', url: "https://githubifc.iad.ca.inet/${ORGANIZATION}/${currentRepository}.git"

                echo "retrieve DockerFile FROM value"
                dockerFrom = sh script: 'sed -n \'s/^ *FROM *//p\' Dockerfile', returnStdout: true
                dockerFrom = dockerFrom.trim()
                echo "We'll try to pull the image from $dockerFrom"

                echo "retrieve DockerFile's version..."
                version = sh script: 'sed -n  \'s/^LABEL *version *=[ \\t]*"\\(.*\\)"/\\1/p\' Dockerfile', returnStdout: true
                version = version.trim()
                echo "DockerFile version $version"

                def bcParams = []
                bcParams << "-p ORGANIZATION=$ORGANIZATION"
                bcParams << "-p GIT_BRANCH=$GIT_BRANCH"
                bcParams << "-p APPLICATION=$currentRepository"
                bcParams << "-p APP_VERSION=$version"
                bcParams << "-p DOCKER_FROM=$dockerFrom"

                echo 'checking out openshift-template...'
                git branch: 'master', credentialsId: 'build-maven', url: 'https://githubifc.iad.ca.inet/DevTools/openshift-templates.git'

                echo """
                        GIT_BRANCH = $GIT_BRANCH
                        ORGANIZATION = $ORGANIZATION
                        APPLICATION = $currentRepository
                        PROJECT = $PROJECT
                        APP_VERSION=$version
                        SOURCE_IMAGE = docker://$OCP_HOST/$PROJECT/$currentRepository:$version
                        DESTINATION_IMAGE = docker://$NEXUS_HOST/$NEXUS_ENV/$currentRepository:$version
                    """

                echo 'process, apply and build...'
                sh "oc process -f template-bc-baseimage.yaml -o yaml ${bcParams.join(' ')} -n $PROJECT | oc apply -n $PROJECT -f -"
                sh "oc start-build $currentRepository -F -n $PROJECT"

                if(GOLDEN.toBoolean()) {
                    withCredentials([usernamePassword(credentialsId: DOCKER_RELEASE_PUSH_REGISTRY_CREDENTIALID, passwordVariable: 'PROMOTER_PASSWORD', usernameVariable: 'PROMOTER_USERNAME')]) {
			logToOCP(ENVIRONMENT, BASE_PROJECT)
                	sh "oc project $PROJECT"
                        sh "skopeo copy --src-creds=\"\$(oc whoami):\$(oc whoami -t)\" --dest-creds=\"$PROMOTER_USERNAME:${PROMOTER_PASSWORD.replace('$', '\\$')}\" docker://$OCP_HOST/$PROJECT/$currentRepository:$version docker://$NEXUS_HOST/$NEXUS_ENV/$currentRepository:$version"
                    }
                }
                currentBuild.displayName = "last image: #${BUILD_NUMBER} $currentRepository:$version"
            }
        }

        stage('Clean up'){
            ws(pwd() + "@tmp") {
                step([$class: 'WsCleanup'])
            }
            ws(pwd() + "@libs") {
                step([$class: 'WsCleanup'])
            }
            ws(pwd() + "@script") {
                step([$class: 'WsCleanup'])
            }
            deleteDir()
        }

    }
}  else {
    currentBuild.displayName = 'REFRESHED CHOICES'
}

void logToOCP(final String OCP_ENV, final String TEAM) {
    url = ClusterInfo.clusterByEnv(OCP_ENV).url
	credentialsId = ClusterInfo.clusterByEnv(OCP_ENV).credentialsIdByTeam(TEAM)
    withCredentials([
            usernamePassword(credentialsId: credentialsId, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
    ]) {
        sh "oc login ${url} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
    }
}

def createParameterScript(value) {
    String returnValue = value

    // We may want to retrieve more specific value from a project
    switch (value) {
        case "appId":
            returnValue = "projects.appId"
            break
        default:
            break
    }

    def script = """import groovy.json.JsonSlurperClassic
	def json = new JsonSlurperClassic().parseText(JSON_FILE)
	return json[TRIBE].${returnValue}
	"""

    return script
}
