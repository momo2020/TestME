#!Groovy
import groovy.json.JsonBuilder
import groovy.json.JsonSlurperClassic
import intact.cluster.ocp.ClusterInfo
import intact.util.SharedLibraryUtils

node('master'){
    //@See https://githubifc.iad.ca.inet/DevTools/jenkins-pipeline-shared-librairies
    def fallbackScript = "return ['ERROR']"
    def paths = ["intact/util/ocp/digital/rqq.json",
                 "intact/util/ocp/digital/quoters.json",
		 "intact/util/ocp/digital/ubi.json",
                 "intact/util/ocp/contactpl_36.json"]

    // Combine the json files into one big json
    def combinedJsonFile = SharedLibraryUtils.combineJson(paths, this)

    //noinspection GroovyAssignabilityCheck
    properties([
        parameters(
            [
                booleanParam(defaultValue: false, description: 'check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
                [$class: 'WHideParameterDefinition', defaultValue: "${combinedJsonFile}", description: 'used to pass down to other pipelines', name: 'JSON_FILE'],
                [
                        $class              : 'ChoiceParameter',
                        choiceType          : 'PT_SINGLE_SELECT',
                        description         : 'Select a tribe in order to filter the applications',
                        filterable          : false,
                        name                : 'TRIBE',
                        randomName          : 'choice-parameter-48293583925954',
                        referencedParameters: '',
                        script              : [
                                $class        : 'GroovyScript',
                                fallbackScript: [classpath: [], sandbox: false, script: "return ''"],
                                script        : [classpath: [], sandbox: false, script: "return ['contactpl_36', 'rqq', 'quoters', 'ubi']"]
                        ]
                ],
                [
                        $class              : 'CascadeChoiceParameter',
                        choiceType          : 'PT_SINGLE_SELECT',
                        description         : '',
                        filterable          : true,
                        name                : 'BASE_PROJECT',
                        randomName          : 'choice-parameter-67545844545948',
                        referencedParameters: 'TRIBE, JSON_FILE',
                        script              : [
                                $class        : 'GroovyScript',
                                fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                script        : [classpath: [], sandbox: false, script: createParameterScript("ocp_base_projects")]
                        ]
                ],
                [
                        $class              : 'CascadeChoiceParameter',
                        choiceType          : 'PT_SINGLE_SELECT',
                        description         : '',
                        filterable          : true,
                        name                : 'ENVIRONMENT',
                        randomName          : 'choice-parameter-66545844545948',
                        referencedParameters: 'TRIBE, JSON_FILE',
                        script              : [
                                $class        : 'GroovyScript',
                                fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                script        : [classpath: [], sandbox: false, script: createParameterScript("environments")]
                        ]
                ],
                [
                        $class              : 'CascadeChoiceParameter',
                        choiceType          : 'PT_SINGLE_SELECT',
                        description         : '',
                        filterable          : true,
                        name                : 'BRANCH',
                        randomName          : 'choice-parameter-67545844570948',
                        referencedParameters: 'TRIBE, JSON_FILE',
                        script              : [
                                $class        : 'GroovyScript',
                                fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                script        : [classpath: [], sandbox: false, script: createParameterScript("branches")]
                        ]
                ],
            ]
        )
    ])
    if (!ONLY_REFRESH_CHOICES.toBoolean()) {

        final String PROJECT = "$BASE_PROJECT-$ENVIRONMENT${BRANCH.empty ? '' : "-${BRANCH}"}"
        def printMap = [:]
        def deploymentConfigsOrigin
        def podsRunning

        stage("Log to OCP") {
            logToOCP(ENVIRONMENT, BASE_PROJECT)
        }

        stage("Retrieve origin deployment & image") {
            deploymentConfigsOrigin = sh script: "oc get dc -n $PROJECT -o json", returnStdout: true
            podsRunning = sh script: "oc get pods -n $PROJECT -o json --show-all=false", returnStdout: true
            printMap = retrieveHistory(deploymentConfigsOrigin, podsRunning)
        }

        stage("Print what's deployed"){
            printHistory(printMap)
        }

        stage('Clean up'){
            ws(pwd() + "@tmp") {
                step([$class: 'WsCleanup'])
            }
            ws(pwd() + "@libs") {
                step([$class: 'WsCleanup'])
            }
            ws(pwd() + "@script") {
                step([$class: 'WsCleanup'])
            }
            deleteDir()
        }
        currentBuild.displayName = "#$BUILD_NUMBER : $PROJECT"
    } else {
        currentBuild.displayName = 'REFRESHED CHOICES'
    }
}

def retrieveHistory(def deploymentConfigsOrigin, def podsRunning) {

    def jsonDC = new JsonSlurperClassic().parseText(deploymentConfigsOrigin)
    def jsonPods = new JsonSlurperClassic().parseText(podsRunning)
    def templatePods
    def templateDC

    String containerStatus
    String deployName
    String latestVersion
    String appNameVersion
    String[] jsonPodsNames = jsonPods.items.metadata.name

    List<String> uniquePodNames = new ArrayList<String>()
    List<String> uniqueNames = new ArrayList<String>()

    def printMap = [:]
    def printMapRunningLatest = [:]
    def printMapRunningNotLatest = [:]
    def printMapNotRunning = [:]

/**
 * Retrieve the pods running
 */
    for (def name : jsonPodsNames) {
        uniquePodNames.add(name.replaceAll(/-[a-z0-9]*$/, ""))
        uniqueNames.add(name.replaceAll(/-[0-9]*-[a-z0-9]*$/, ""))
    }

    uniquePodNames = uniquePodNames.toUnique()
    uniqueNames = uniqueNames.toUnique()

    for(def podName: uniqueNames){

        for(def item : jsonDC.items){
            if(item.spec.template.metadata.labels.app.equals(podName)){
                templateDC = item
            }
        }

        for(def item : jsonPods.items){
            if(item.metadata.labels.app.equals(podName)){
                templatePods = item
            }
        }

        deployName = templatePods.metadata.labels.deployment //deployment name in the pod
        containerStatus = templatePods.status.containerStatuses.ready.toString() //status representing if the pod is up and running
        latestVersion = templateDC.status.latestVersion //latest version deployed
        appNameVersion = podName.concat("-$latestVersion")

	    if(uniquePodNames.join(",").contains(appNameVersion) && containerStatus.contains('true') && !deployName.toString().contains("-deploy")) {

            podsRunningLatest(latestVersion, deployName, templatePods, templateDC, printMap, podName, printMapRunningLatest)

        } else if(containerStatus.contains('true') && !deployName.toString().contains("-deploy")){

            podsRunningNotLatest(latestVersion, deployName, templatePods, templateDC, printMap, podName, printMapRunningNotLatest)

        } else {

            podsNotYetRunningLatest(latestVersion, printMap, podName, printMapNotRunning)

        }
    }
    return printMap
}

def podsNotYetRunningLatest(def latestVersion,def printMap, def podName, def printMapNotRunning){

    def podsRunningMap = [:]
    podsRunningMap.put("Status", "Deployment $latestVersion not yet successful... Container creating or new deployment...")
    printMapNotRunning.put(podName, podsRunningMap)
    printMap.put("Not ready right now...", printMapNotRunning)
    return printMap
}

def podsRunningLatest(def latestVersion, def deployName, def templatePods, def templateDC, def printMap, def podName, def printMapRunningLatest){
    def envPods = templatePods.spec.containers.env
    def podsRunningMap = [:]
    def replicas = templateDC.spec.replicas
    podsRunningMap.put("LatestVersion", latestVersion)
    podsRunningMap.put("Status", "Deployment $latestVersion successful")
    podsRunningMap.put("ContainerStatus","The version running is $deployName")
    podsRunningMap.put("Replicas", "$replicas")
    /**
     * Retrieve the env variables
     */
    for(def envPod : envPods){
        for(def envVar : envPod){
            if (envVar.name.equals("CONFIGMAP_LONGVERSION")) {
                podsRunningMap.put(envVar.name, envVar.value)
            }
            if (envVar.name.equals("PROJECT_LONGVERSION")) {
                podsRunningMap.put(envVar.name, envVar.value)
            }
        }
    }

    printMapRunningLatest.put(podName, podsRunningMap)
    printMap.put("Running latest", printMapRunningLatest)
    return printMap
}

def podsRunningNotLatest(def latestVersion, def deployName, def templatePods, def templateDC, def printMap, def podName, def printMapRunningNotLatest){
    def podsRunningMap = [:]
    def replicas = templateDC.spec.replicas
    def envPodsLatest = templateDC.spec.template.spec.containers.env
    def envPodsRunning = templatePods.spec.containers.env
    podsRunningMap.put("LatestVersion", latestVersion)
    podsRunningMap.put("Status", "Deployment $latestVersion not successful...")
    podsRunningMap.put("ContainerStatus","The version running is $deployName")
    podsRunningMap.put("Replicas", "$replicas")
    /**
     * Retrieve the env variables from the running version
     */
    for(def envPod : envPodsRunning){
        for(def envVar : envPod){
            if (envVar.name.equals("CONFIGMAP_LONGVERSION")) {
                podsRunningMap.put("CONFIGMAP_LONGVERSION_RUNNING", envVar.value)
            }
            if (envVar.name.equals("PROJECT_LONGVERSION")) {
                podsRunningMap.put("PROJECT_LONGVERSION_RUNNING", envVar.value)
            }
        }
    }
    /**
     * Retrieve the env variables from the latest version
     */
    for(def envPod : envPodsLatest){
        for(def envVar : envPod){
            if (envVar.name.equals("CONFIGMAP_LONGVERSION")) {
                podsRunningMap.put("CONFIGMAP_LONGVERSION_LATEST", envVar.value)
            }
            if (envVar.name.equals("PROJECT_LONGVERSION")) {
                podsRunningMap.put("PROJECT_LONGVERSION_LATEST", envVar.value)
            }
        }
    }
    printMapRunningNotLatest.put(podName, podsRunningMap)
    printMap.put("Running not from latest...", printMapRunningNotLatest)
    return printMap
}

def printHistory(def printMap){
    def jsonBuilder = new JsonBuilder(printMap)
    println(jsonBuilder.toPrettyString())
}

void logToOCP(final String OCP_ENV, final String TEAM) {
    url = ClusterInfo.clusterByEnv(OCP_ENV).url
    credentialsId = ClusterInfo.clusterByEnv(OCP_ENV).credentialsIdByTeam(TEAM)
    echo "attempting oc login with credentialsID ${credentialsId}"
    withCredentials([
            usernamePassword(credentialsId: credentialsId, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
    ]) {
        sh "oc login ${url} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
    }
}

def createParameterScript(value) {
    String returnValue = value

    // We may want to retrieve more specific value from a project
    switch (value) {
        case "appId":
            returnValue = "projects.appId"
            break
        default:
            break
    }

    def script = """import groovy.json.JsonSlurperClassic
	def json = new JsonSlurperClassic().parseText(JSON_FILE)
	return json[TRIBE].${returnValue}
	"""

    return script
}
