#!Groovy
import groovy.json.JsonSlurperClassic
import intact.cluster.ocp.ClusterInfo
import intact.util.SharedLibraryUtils
import intact.util.Utils

node('master') {

//@See https://githubifc.iad.ca.inet/DevTools/jenkins-pipeline-shared-librairies
	def fallbackScript = "return ['ERROR']"
	def paths = ["intact/util/ocp/digital/rqq.json",
				 "intact/util/ocp/digital/quoters.json",
				 "intact/util/ocp/digital/ubi.json",
				 "intact/util/ocp/contactpl_36.json"]

	// Combine the json files into one big json
	def combinedJsonFile = SharedLibraryUtils.combineJson(paths, this)

	// Slurp the resulting json enabling access as an object
	def json = new JsonSlurperClassic().parseText(combinedJsonFile)

//noinspection GroovyAssignabilityCheck
	properties([
		parameters(
			[
				booleanParam(defaultValue: false, description: 'Check this if you only need to refresh the BUILDNAME or other choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
				[$class: 'WHideParameterDefinition', defaultValue: "${combinedJsonFile}", description: 'used to pass down to other pipelines', name: 'JSON_FILE'],
				[
					$class              : 'ChoiceParameter',
					choiceType          : 'PT_SINGLE_SELECT',
					description         : 'Select a tribe in order to filter the applications',
					filterable          : false,
					name                : 'TRIBE',
					randomName          : 'choice-parameter-48293583925954',
					referencedParameters: '',
					script              : [
						$class        : 'GroovyScript',
						fallbackScript: [classpath: [], sandbox: false, script: "return ''"],
						script        : [classpath: [], sandbox: false, script: "return ['contactpl_36', 'rqq', 'quoters', 'ubi']"]
					]
				],
				[
					$class              : 'CascadeChoiceParameter',
					choiceType          : 'PT_SINGLE_SELECT',
					description         : '',
					filterable          : true,
					name                : 'APP_PARENT',
					randomName          : 'choice-parameter-68065844775948',
					referencedParameters: 'TRIBE, JSON_FILE',
					script              : [
						$class        : 'GroovyScript',
						fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
						script        : [classpath: [], sandbox: false, script: createParameterScript("appId")]
					]
				],
				[$class            : 'ExtensibleChoiceParameterDefinition',
				 choiceListProvider: [$class: 'TextareaChoiceListProvider', addEditedValue: true, choiceListText: ['', 'ocp-3.6', 'dev-d16', 'master'].join("\n"), whenToAdd: 'CompletedStable'],
				 description       : 'The git branch to build from (if applicable)',
				 editable          : true,
				 name              : 'GIT_BRANCH'
				],
				[
					$class              : 'CascadeChoiceParameter',
					choiceType          : 'PT_SINGLE_SELECT',
					description         : '',
					filterable          : true,
					name                : 'BASE_PROJECT',
					randomName          : 'choice-parameter-67545844545948',
					referencedParameters: 'TRIBE, JSON_FILE',
					script              : [
						$class        : 'GroovyScript',
						fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
						script        : [classpath: [], sandbox: false, script: createParameterScript("ocp_base_projects")]
					]
				],
				[
					$class              : 'CascadeChoiceParameter',
					choiceType          : 'PT_SINGLE_SELECT',
					description         : '',
					filterable          : true,
					name                : 'ENVIRONMENT',
					randomName          : 'choice-parameter-66545844545948',
					referencedParameters: 'TRIBE, JSON_FILE',
					script              : [
						$class        : 'GroovyScript',
						fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
						script        : [classpath: [], sandbox: false, script: createParameterScript("environments")]
					]
				],
				[
					$class              : 'CascadeChoiceParameter',
					choiceType          : 'PT_SINGLE_SELECT',
					description         : '',
					filterable          : true,
					name                : 'BRANCH',
					randomName          : 'choice-parameter-67545844570948',
					referencedParameters: 'TRIBE, JSON_FILE',
					script              : [
						$class        : 'GroovyScript',
						fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
						script        : [classpath: [], sandbox: false, script: createParameterScript("branches")]
					]
				],
				[
					$class              : 'ChoiceParameter',
					choiceType          : 'PT_SINGLE_SELECT',
					description         : 'Choose your destiny',
					filterable          : false,
					name                : 'DEPLOY',
					randomName          : 'choice-parameter-13456583925954',
					referencedParameters: '',
					script              : [
						$class        : 'GroovyScript',
						fallbackScript: [classpath: [], sandbox: false, script: "return ''"],
						script        : [classpath: [], sandbox: false, script: "return ['BOTH', 'DEPLOY-ONLY', 'PROPS-ONLY']"]
					]
				],
				string(defaultValue: '', description: '', name: 'APP_VERSION'),
				string(defaultValue: '', description: '', name: 'CONFIGMAP_VERSION')
			])
	])

	if (!ONLY_REFRESH_CHOICES.toBoolean()) {
		deleteDir()
		// Overrides the json object with the correct tribe's json
		json = json[TRIBE]

		def project // the project in shareLibrary containing all meta info
		def defaultBuildProject = json.default_build_project
		def dockerFrom
		boolean promote = false
		final String BUILD = 'true'
		final String NO_CACHE = 'true'
		final String TEAM = json.team
		final int MAX_TIMEOUT = 10
		final int POLLING_INTERVAL = 10
		String ORGANIZATION // the GitHub organization
		String GROUP_ID    // the groupId of the app
		String APP_DOCKER // the artifactId of the docker-module
		String APPLICATION // the artifactId of the module containing the war
		String BUILD_NAME // the jenkins buildNuame used to build the war and docker module
		String LIVENESS_PROBE_INITIAL_DELAY
		String READINESS_PROBE_INITIAL_DELAY
		String READINESS_PROBE_URL
		String REPLICAS
		String MEMORY_REQUEST
		String MEMORY_LIMIT
		String CPU_REQUEST
		String CPU_LIMIT
		String CONFIGMAP_LONGVERSION
		String PROJECT_LONGVERSION
		String DESTINATION_ENVIRONMENT
		String DESTINATION_BRANCH
		String DEFAULT_PROJECT = "$defaultBuildProject.base_project-$defaultBuildProject.environment${defaultBuildProject.branch.empty ? '' : "-$defaultBuildProject.branch"}"
		String PROJECT = "$BASE_PROJECT-$ENVIRONMENT${BRANCH.empty ? '' : "-$BRANCH"}"

		if (PROJECT != DEFAULT_PROJECT) {
			sh "echo This build will be promote to $ENVIRONMENT"
			promote = true
			DESTINATION_ENVIRONMENT = ENVIRONMENT
			DESTINATION_BRANCH = BRANCH
			ENVIRONMENT = defaultBuildProject.environment
			BRANCH = defaultBuildProject.branch
			PROJECT = DEFAULT_PROJECT
		}

		stage("retrieve project from json shared property") {
			project = SharedLibraryUtils.retrieveProjectFromAppId(APP_PARENT, json, this)
		}

		stage('validate inputs') {
			ORGANIZATION = project.gitHubOrgName
			GROUP_ID = project.groupId
			APP_DOCKER = project.dockerId
			APPLICATION = project.artifactId
			BUILD_NAME = project.buildName
			REPLICAS = project.replicas.get(BRANCH).get(ENVIRONMENT)
			CONFIGMAP_LONGVERSION = getConfigMapLongVersion(GROUP_ID, APP_DOCKER, CONFIGMAP_VERSION)
			PROJECT_LONGVERSION = getLongVersion(GROUP_ID, APPLICATION, APP_VERSION)
			SERVICE = Utils.applicationToService(APPLICATION)
		}

		if (GIT_BRANCH == null || GIT_BRANCH.isEmpty()) {
			GIT_BRANCH = project.defaultBranch
			println("GIT_BRANCH not specified, defaulting to ${GIT_BRANCH}")
		}

		stage('Pull project from github') {
			withCredentials([
				usernamePassword(credentialsId: 'build-maven', passwordVariable: 'MVN_PASSWORD', usernameVariable: 'MVN_USERNAME')
			]) {
				dir("$APP_PARENT") {
					checkout([$class: 'GitSCM', branches: [[name: "${GIT_BRANCH}"]], userRemoteConfigs: [[credentialsId: 'build-maven', url: "https://githubifc.iad.ca.inet/${ORGANIZATION}/${APP_PARENT}.git"]]])
					// Retrieve FROM value in the dockerfile
					dockerFrom = sh script: "sed -n \'s/^ *FROM *//p\' ${APP_DOCKER}/src/Dockerfile", returnStdout: true
					echo "FROM: $dockerFrom"
					dockerFrom = dockerFrom.trim()
				}
			}
		}

		stage('build from jenkins') {
			// Skip build only if app version, configmap version and deploy BOTH is selected.
			if (isBuildNeeded(APP_VERSION, CONFIGMAP_VERSION, DEPLOY.toString())) {

				String host = "https://prod-jenkins-2020.iad.ca.inet"
				def buildNumber = 0
				String buildUrl = ""
				String option = ""
				String requestUrl = ""

				// Check if we need to build from freestyle or jenkinsfile
				if (!BUILD_NAME.equals("") && !BUILD_NAME.equals(null)) {
					buildUrl = "${host}/job/${BUILD_NAME}"
					option = "/buildWithParameters?GIT_BRANCH=${GIT_BRANCH}"
					echo "BUILD_NAME found in the shared library, we will build with the freestyle build"
				} else {
					buildUrl = "${host}/job/${ORGANIZATION}/job/${APP_PARENT}/job/${GIT_BRANCH}"
					option = "/buildWithParameters?forceDeploy=true"
					echo "BUILD_NAME not found in the shared library, we will try to run from the jenkinsfile build"
				}

				// Set the request url
				requestUrl = buildUrl + option

				withCredentials([
					usernamePassword(credentialsId: 'build-maven', passwordVariable: 'MVN_PASSWORD', usernameVariable: 'MVN_USERNAME')
				]) {
					// Get the next build number before starting the build
					def jsonResponse = sh(
						script: "curl -u ${MVN_USERNAME}:${MVN_PASSWORD.replace('$', '\\$')} '${buildUrl}/api/json?pretty=true'",
						returnStdout: true
					)

					buildNumber = (new JsonSlurperClassic().parseText(jsonResponse)).nextBuildNumber
					echo "BUILD NUMBER = ${buildNumber}"

					// Start the build
					echo "STARTING BUILD"
					sh(
						script: "curl -u ${MVN_USERNAME}:${MVN_PASSWORD.replace('$', '\\$')} -X POST ${requestUrl}",
						returnStdout: true
					)
				}

				// Poll remote build progression
				timeout(time: MAX_TIMEOUT, unit: 'MINUTES') {
					waitUntil {
						sleep time: POLLING_INTERVAL, unit: 'SECONDS'
						String buildStatus = getBuildStatus(buildUrl, buildNumber)
						if (buildStatus != null && !buildStatus.equals("null")) {
							switch (buildStatus) {
								case "SUCCESS":
									echo "BUILD FINISHED WITH STATUS: ${buildStatus}"
									return true
									break
								case "ABORTED":
								case "FAILED":
									echo "BUILD FINISHED WITH STATUS: ${buildStatus}"
									assert false
									break
								default:
									echo "BUILD STATUS = ${buildStatus}"
									break
							}
						}
						return false
					}
				}

				// Fetch app version and config version of the built app
				dir("$APP_PARENT") {
					pom = readMavenPom file: 'pom.xml'
					echo "POM VERSION = ${pom.version}"
				}

				// Update the pipeline values
				APP_VERSION = pom.version
				PROJECT_LONGVERSION = getLongVersion(GROUP_ID, APPLICATION, APP_VERSION)
				CONFIGMAP_VERSION = pom.version
				CONFIGMAP_LONGVERSION = getConfigMapLongVersion(GROUP_ID, APP_DOCKER, CONFIGMAP_VERSION)

				echo """
					UPDATING PIPELINE INFORMATIONS WITH VERSIONS FETCHED FROM REMOTE BUILD.
					APP_VERSION = $APP_VERSION
					PROJECT_LONGVERSION = $PROJECT_LONGVERSION
					CONFIGMAP_VERSION = $CONFIGMAP_VERSION
					CONFIGMAP_LONGVERSION = $CONFIGMAP_LONGVERSION
				"""
			}
		}

		stage('update properties') {
			if (!DEPLOY.toString().equals('DEPLOY-ONLY')) {

				build job: 'OCP36_create_properties_configmap', parameters: [
					string(name: 'TRIBE', value: TRIBE),
					string(name: 'APP_PARENT', value: APP_PARENT),
					string(name: 'ENVIRONMENT', value: ENVIRONMENT),
					string(name: 'BRANCH', value: BRANCH),
					string(name: 'BASE_PROJECT', value: BASE_PROJECT),
					string(name: 'GIT_BRANCH', value: GIT_BRANCH),
					string(name: 'CONFIGMAP_VERSION', value: CONFIGMAP_VERSION),
					string(name: 'CONFIGMAP_LONGVERSION', value: CONFIGMAP_LONGVERSION)
				]
			} else {
				echo 'Skipping updateProperties, but we still have to retrieve the configMapVersion from what is already in Openshift'
				// TODO is the logToOCP always needed?
				logToOCP(ENVIRONMENT, TEAM)
				// TODO Can't this be in sharedLibrary?
				CONFIGMAP_LONGVERSION = sh script: "oc env dc/$APPLICATION --list | grep CONFIGMAP_LONGVERSION | sed 's/CONFIGMAP_LONGVERSION=//'", returnStdout: true
				CONFIGMAP_LONGVERSION = CONFIGMAP_LONGVERSION.trim()
				echo "CONFIGMAP_LONGVERSION = $CONFIGMAP_LONGVERSION"
			}

		}

		stage('retrieving OCP values from configmap') {
			def configMapOut = sh script: "oc get configmap ${APPLICATION}.properties -n $PROJECT -o json", returnStdout: true
			def configMapJson = new JsonSlurperClassic().parseText(configMapOut)
			String configMapData = configMapJson.data.'configmap.properties'
			LIVENESS_PROBE_INITIAL_DELAY = resolveOCPValueForKey('OCP_LIVENESS_PROBE_INITIAL_DELAY', project.livenessProbeInitialDelay, configMapData)
			READINESS_PROBE_INITIAL_DELAY = resolveOCPValueForKey('OCP_READINESS_PROBE_INITIAL_DELAY', project.readinessProbeInitialDelay, configMapData)
			READINESS_PROBE_URL = resolveOCPValueForKey('OCP_READINESS_PROBE_URL', project.readinessProbeUrl, configMapData)
			MEMORY_REQUEST = resolveOCPValueForKey('OCP_MEMORY_REQUEST', json.memory_sizes.get(project.memory_limit_size).get('memoryRequest'), configMapData)
			MEMORY_LIMIT = resolveOCPValueForKey('OCP_MEMORY_LIMIT', json.memory_sizes.get(project.memory_limit_size).get('memoryLimit'), configMapData)
			CPU_REQUEST = resolveOCPValueForKey('OCP_CPU_REQUEST', json.cpu_sizes.get(project.cpu_limit_size).get('cpuRequest'), configMapData)
			CPU_LIMIT = resolveOCPValueForKey('OCP_CPU_LIMIT', json.cpu_sizes.get(project.cpu_limit_size).get('cpuLimit'), configMapData)
		}

		echo """
					ORGANIZATION = $ORGANIZATION
					GROUP_ID = $GROUP_ID
					APP_DOCKER = $APP_DOCKER
					APPLICATION = $APPLICATION
					BUILD_NAME = $BUILD_NAME
					GIT_BRANCH = $GIT_BRANCH
					PROJECT = $PROJECT
					LIVENESS_PROBE_INITIAL_DELAY = $LIVENESS_PROBE_INITIAL_DELAY
					READINESS_PROBE_INITIAL_DELAY = $READINESS_PROBE_INITIAL_DELAY
					READINESS_PROBE_URL = $READINESS_PROBE_URL
					REPLICAS = $REPLICAS
					MEMORY_REQUEST = $MEMORY_REQUEST
					MEMORY_LIMIT = $MEMORY_LIMIT
					CPU_REQUEST = $CPU_REQUEST
					CPU_LIMIT = $CPU_LIMIT
					CONFIGMAP_LONGVERSION = $CONFIGMAP_LONGVERSION
					PROJECT_LONGVERSION = $PROJECT_LONGVERSION
					SERVICE = $SERVICE

				"""

		stage('checking out openshift-template') {
			echo 'checking out openshift-template...'
			git branch: 'master', credentialsId: 'build-maven', url: 'https://githubifc.iad.ca.inet/DevTools/openshift-templates.git'
		}

		stage('create docker image') {
			if (BUILD.toBoolean() && !DEPLOY.toString().equals('PROPS-ONLY')) {
				echo "Build..."

				assert !dockerFrom.isEmpty()

				def bcParams = []
				bcParams << "-p ORGANIZATION=$ORGANIZATION"
				bcParams << "-p GIT_BRANCH=$GIT_BRANCH"
				bcParams << "-p GROUP_ID=$GROUP_ID"
				bcParams << "-p APP_PARENT=$APP_PARENT"
				bcParams << "-p APP_DOCKER=$APP_DOCKER"
				bcParams << "-p APPLICATION=$APPLICATION"
				bcParams << "-p APP_VERSION=$APP_VERSION"
				bcParams << "-p NO_CACHE=$NO_CACHE"
				bcParams << "-p DOCKER_FROM=$dockerFrom"

				sh "oc process -f template-bc.yaml -o yaml ${bcParams.join(' ')} -n $PROJECT | oc apply -n $PROJECT -f -"
				sh "oc start-build $APPLICATION -F -n $PROJECT"
			} else {
				echo "Skip build."
			}
		}

		stage('deploy docker image to OCP') {
			if (!DEPLOY.toString().equals('PROPS-ONLY')) {
				echo "Deploy..."
				clusterDomain = ClusterInfo.clusterByEnv(ENVIRONMENT).domain
				def dcParams = []
				dcParams << "-p CLUSTER_DOMAIN=$clusterDomain"
				dcParams << "-p CONFIGMAP_LONGVERSION=${CONFIGMAP_LONGVERSION.isEmpty() ? 'notApplicable' : CONFIGMAP_LONGVERSION}"
				dcParams << "-p PROJECT_LONGVERSION=${PROJECT_LONGVERSION}"
				dcParams << "-p ENVIRONMENT=$ENVIRONMENT"
				dcParams << "-p APPLICATION=$APPLICATION"
				dcParams << "-p BRANCH=$BRANCH"
				dcParams << "-p SOURCE_PROJECT=$PROJECT"
				dcParams << "-p TARGET_PROJECT=$PROJECT"
				dcParams << "-p TAG_VERSION=$APP_VERSION"
				dcParams << "-p SERVICE=$SERVICE"
				dcParams << "-p LIVENESS_PROBE_INITIAL_DELAY=$LIVENESS_PROBE_INITIAL_DELAY"
				dcParams << "-p READINESS_PROBE_URL=$READINESS_PROBE_URL"
				dcParams << "-p READINESS_PROBE_INITIAL_DELAY=$READINESS_PROBE_INITIAL_DELAY"
				dcParams << "-p REPLICAS=$REPLICAS"
				dcParams << "-p MEMORY_REQUEST=$MEMORY_REQUEST"
				dcParams << "-p MEMORY_LIMIT=$MEMORY_LIMIT"
				dcParams << "-p CPU_REQUEST=$CPU_REQUEST"
				dcParams << "-p CPU_LIMIT=$CPU_LIMIT"
				dcParams << "-p GIT_BRANCH=$GIT_BRANCH"
				sh "oc process -f template-dc.yaml ${dcParams.join(' ')} -o yaml | oc apply -n $PROJECT -f -"

				ifFirstDeploy = sh script: "oc describe dc/$APPLICATION -n $PROJECT | grep 'Latest Version:'", returnStdout: true
				// force a deploy with 'latest' if its the first one
				if (ifFirstDeploy.contains('Not deployed')) {
					sh "oc rollout latest $APPLICATION -n $PROJECT"
				}
				// TODO make deploy more resilient - sometimes it does not work right again
				sh "oc rollout history dc/$APPLICATION -n $PROJECT"
				// looks at the current deployment history and starts a deploy if it's not already deploying (if status is not Complete or Failed)
				sh "if [[ `oc rollout history dc/$APPLICATION -n $PROJECT | tail -2` =~ Complete|Failed ]]; then oc rollout latest $APPLICATION -n $PROJECT; else echo deployment already on the way;  fi"
			} else {
				echo "Skip deploy."
			}
		}

		stage('restarting the pods to update the properties') {
			// restart the pods if only the properties has been updated and update the configMapVersion in the labels
			if (DEPLOY.toString().equals('PROPS-ONLY')) {
				// TODO should we login right from the start?
				logToOCP(ENVIRONMENT, TEAM)
				sh("oc env dc/$APPLICATION CONFIGMAP_LONGVERSION=$CONFIGMAP_LONGVERSION -n $PROJECT")
			}
		}

		stage('calling SOAP UI test') {

		}

		stage('promote if necessary') {
			if (promote) {
				build job: 'OCP36_promote', parameters: [
					string(name: 'TRIBE', value: TRIBE),
					string(name: 'DEPLOYMENT', value: APP_PARENT),
					string(name: 'BASE_PROJECT', value: BASE_PROJECT),
					string(name: 'ORIGIN_ENVIRONMENT', value: ENVIRONMENT),
					string(name: 'ORIGIN_BRANCH', value: BRANCH),
					string(name: 'DESTINATION_ENVIRONMENT', value: DESTINATION_ENVIRONMENT),
					string(name: 'DESTINATION_BRANCH', value: DESTINATION_BRANCH),
					string(name: 'USE_NEXUS', value: 'false'),
					string(name: 'DEPLOY', value: DEPLOY)
				]
			}
		}

		stage('Clean up') {
			ws(pwd() + "@tmp") {
				step([$class: 'WsCleanup'])
			}
			ws(pwd() + "@libs") {
				step([$class: 'WsCleanup'])
			}
			ws(pwd() + "@script") {
				step([$class: 'WsCleanup'])
			}
			deleteDir()
		}

		currentBuild.displayName = "#${BUILD_NUMBER} $APP_PARENT deploy [$DEPLOY] -> $BASE_PROJECT-${DESTINATION_ENVIRONMENT != null ? DESTINATION_ENVIRONMENT : ENVIRONMENT}${BRANCH.empty ? '' : "-$BRANCH"}"
	} else {
		currentBuild.displayName = 'REFRESHED CHOICES'
	}
}

void logToOCP(final String OCP_ENV, final String TEAM) {
	url = ClusterInfo.clusterByEnv(OCP_ENV).url
	credentialsId = ClusterInfo.clusterByEnv(OCP_ENV).credentialsIdByTeam(TEAM)
	echo "attempting oc login with credentialsID ${credentialsId}"
	withCredentials([
		usernamePassword(credentialsId: credentialsId, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
	]) {
		sh "oc login ${url} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
	}
}

def createParameterScript(value) {
	String returnValue = value

	// We may want to retrieve more specific value from a project
	switch (value) {
		case "appId":
			returnValue = "projects.appId"
			break
		default:
			break
	}

	def script = """import groovy.json.JsonSlurperClassic
	def json = new JsonSlurperClassic().parseText(JSON_FILE)
	return json[TRIBE].${returnValue}
	"""

	return script
}

/**
 * retrieves the long snapshot version from nexus using the restAPI
 */
def getLongVersion(String group, String artifact, String version) {
	if (version.contains('SNAPSHOT')) {
		final String repo = 'snapshots'
		final String packageType = 'pom'
		String base = 'https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/service/local/artifact/maven/resolve'
		String request = "${base}?g=${group}&a=${artifact}&v=${version}&r=${repo}&p=${packageType}"
		String tag = '<version>'
		withCredentials([
			usernamePassword(credentialsId: 'build-maven', passwordVariable: 'MVN_PASSWORD', usernameVariable: 'MVN_USERNAME')
		]) {
			def xml = sh(
				script: "curl  -u ${MVN_USERNAME}:${MVN_PASSWORD.replace('$', '\\$')} '${request}' | grep ${tag.replace('<', '\\<').replace('>', '\\>')} | sed -e 's/<[^>]*>//g' ",
				returnStdout: true
			)
			return xml.trim()
		}
	} else {
		return version
	}
}

def getConfigMapLongVersion(def GROUP_ID, def APP_DOCKER, def CONFIGMAP_VERSION) {
	if (CONFIGMAP_VERSION.contains('SNAPSHOT')) {
		def urls
		String longVersion
		GROUP_ID = GROUP_ID.replace('.', '/')
		def URL = "https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/service/local/repo_groups/public/content/$GROUP_ID/$APP_DOCKER/$CONFIGMAP_VERSION/"
		CONFIGMAP_VERSION = CONFIGMAP_VERSION.replace('-SNAPSHOT', '')

		node('master') {
			withCredentials([
				usernamePassword(credentialsId: 'build-maven', passwordVariable: 'MVN_PASSWORD', usernameVariable: 'MVN_USERNAME')
			]) {
				//retrieving all resourceURI from snapshots
				urls = sh(
					script: "curl -s -u ${MVN_USERNAME}:${MVN_PASSWORD.replace('$', '\\$')} '${URL}' | xmllint --xpath '//content/data/content-item/resourceURI' -",
					returnStdout: true
				)
				return urls
			}
			urls = urls.replaceAll("<resourceURI>", "")
			urls = urls.split('</resourceURI>')

			//sort snapshots to retrieve the latest snapshot as a longversion
			longVersion = SharedLibraryUtils.retrieveConfigMapLongVersion(CONFIGMAP_VERSION, urls)
			return longVersion
		}
	} else {
		return CONFIGMAP_VERSION
	}
}

def getBuildStatus(def buildUrl, def buildNumber){
	withCredentials([
		usernamePassword(credentialsId: 'build-maven', passwordVariable: 'MVN_PASSWORD', usernameVariable: 'MVN_USERNAME')
	]) {
		def jsonResponse = sh(
			script: "curl -u ${MVN_USERNAME}:${MVN_PASSWORD.replace('$', '\\$')} '${buildUrl}/${buildNumber}/api/json?pretty=true'",
			returnStdout: true
		)

		def json = new JsonSlurperClassic().parseText(jsonResponse)
		buildStatus = json.result
		if (json.building) {
			echo "The remote build is currently building"
		}
	}
	return buildStatus
}

String resolveOCPValueForKey(String key, def defaultValue, def configMapData) {
	boolean valueFound = false
	String value
	if (configMapData.contains(key)) {
		valueFound = true
		value = SharedLibraryUtils.retrieveValueFromConfigmapData(key, configMapData)
	} else {
		value = defaultValue
	}
	println """
			=== RESOLVING KEY $key ===
			value ${valueFound ? 'found' : 'NOT found'} in configmap
			$key == $value
			"""
	return value
}

boolean isBuildNeeded(String appVersion, String configmapVersion, String deploy){
	if (!appVersion.isEmpty() && !configmapVersion.isEmpty() && deploy == "BOTH" ||
		!appVersion.isEmpty() && deploy == "DEPLOY-ONLY" ||
		!configmapVersion.isEmpty() && deploy == "PROPS-ONLY" ){
		echo "Skipping build..."
		return false
	}
	return true
}