#!Groovy
import groovy.json.JsonBuilder
import groovy.json.JsonSlurperClassic
import intact.cluster.ocp.ClusterInfo
import intact.util.SharedLibraryUtils

node('master') {
    //@See https://githubifc.iad.ca.inet/DevTools/jenkins-pipeline-shared-librairies
    def fallbackScript = "return ['ERROR']"
    def paths = ["intact/util/ocp/digital/rqq.json",
                 "intact/util/ocp/digital/quoters.json",
                 "intact/util/ocp/digital/ubi.json",
                 "intact/util/ocp/contactpl_36.json"]

    // Combine the json files into one big json
    def combinedJsonFile = SharedLibraryUtils.combineJson(paths, this)

    // Slurp the resulting json enabling access as an object
    def json = new JsonSlurperClassic().parseText(combinedJsonFile)
    def json2 = new JsonSlurperClassic().parseText(combinedJsonFile)
    def json3 = new JsonSlurperClassic().parseText(combinedJsonFile)


    //noinspection GroovyAssignabilityCheck
    properties([
            parameters(
                    [
                            booleanParam(defaultValue: false, description: 'check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
                            [$class: 'WHideParameterDefinition', defaultValue: "${combinedJsonFile}", description: 'used to pass down to other pipelines', name: 'JSON_FILE'],
                            [
                                    $class              : 'ChoiceParameter',
                                    choiceType          : 'PT_SINGLE_SELECT',
                                    description         : 'Select a tribe in order to filter the applications',
                                    filterable          : false,
                                    name                : 'TRIBE',
                                    randomName          : 'choice-parameter-48293583925954',
                                    referencedParameters: '',
                                    script              : [
                                            $class        : 'GroovyScript',
                                            fallbackScript: [classpath: [], sandbox: false, script: "return ''"],
                                            script        : [classpath: [], sandbox: false, script: "return ['contactpl_36', 'rqq', 'quoters', 'ubi']"]
                                    ]
                            ],
                            [
                                    $class              : 'CascadeChoiceParameter',
                                    choiceType          : 'PT_SINGLE_SELECT',
                                    description         : '',
                                    filterable          : true,
                                    name                : 'ORIGIN_BASE_PROJECT',
                                    randomName          : 'choice-parameter-67545844545948',
                                    referencedParameters: 'TRIBE, JSON_FILE',
                                    script              : [
                                            $class        : 'GroovyScript',
                                            fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                            script        : [classpath: [], sandbox: false, script: createParameterScript("ocp_base_projects")]
                                    ]
                            ],
                            [
                                    $class              : 'CascadeChoiceParameter',
                                    choiceType          : 'PT_SINGLE_SELECT',
                                    description         : '',
                                    filterable          : true,
                                    name                : 'ORIGIN_ENVIRONMENT',
                                    randomName          : 'choice-parameter-66545844545948',
                                    referencedParameters: 'TRIBE, JSON_FILE',
                                    script              : [
                                            $class        : 'GroovyScript',
                                            fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                            script        : [classpath: [], sandbox: false, script: createParameterScript("environments")]
                                    ]
                            ],
                            [
                                    $class              : 'CascadeChoiceParameter',
                                    choiceType          : 'PT_SINGLE_SELECT',
                                    description         : '',
                                    filterable          : true,
                                    name                : 'ORIGIN_BRANCH',
                                    randomName          : 'choice-parameter-67545844570948',
                                    referencedParameters: 'TRIBE, JSON_FILE',
                                    script              : [
                                            $class        : 'GroovyScript',
                                            fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                            script        : [classpath: [], sandbox: false, script: createParameterScript("branches")]
                                    ]
                            ],
                            [
                                    $class              : 'CascadeChoiceParameter',
                                    choiceType          : 'PT_SINGLE_SELECT',
                                    description         : '',
                                    filterable          : true,
                                    name                : 'COMPARE_BASE_PROJECT',
                                    randomName          : 'choice-parameter-67545844545949',
                                    referencedParameters: 'TRIBE, JSON_FILE',
                                    script              : [
                                            $class        : 'GroovyScript',
                                            fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                            script        : [classpath: [], sandbox: false, script: createParameterScript("ocp_base_projects")]
                                    ]
                            ],
                            [
                                    $class              : 'CascadeChoiceParameter',
                                    choiceType          : 'PT_SINGLE_SELECT',
                                    description         : '',
                                    filterable          : true,
                                    name                : 'COMPARE_ENVIRONMENT',
                                    randomName          : 'choice-parameter-66545844545949',
                                    referencedParameters: 'TRIBE, JSON_FILE',
                                    script              : [
                                            $class        : 'GroovyScript',
                                            fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                            script        : [classpath: [], sandbox: false, script: createParameterScript("environments")]
                                    ]
                            ],
                            [
                                    $class              : 'CascadeChoiceParameter',
                                    choiceType          : 'PT_SINGLE_SELECT',
                                    description         : '',
                                    filterable          : true,
                                    name                : 'COMPARE_BRANCH',
                                    randomName          : 'choice-parameter-67545844570949',
                                    referencedParameters: 'TRIBE, JSON_FILE',
                                    script              : [
                                            $class        : 'GroovyScript',
                                            fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                            script        : [classpath: [], sandbox: false, script: createParameterScript("branches")]
                                    ]
                            ],
                            [
                                    $class              : 'CascadeChoiceParameter',
                                    choiceType          : 'PT_SINGLE_SELECT',
                                    description         : '',
                                    filterable          : true,
                                    name                : 'APP_PARENT',
                                    randomName          : 'choice-parameter-68065844775948',
                                    referencedParameters: 'TRIBE, JSON_FILE',
                                    script              : [
                                            $class        : 'GroovyScript',
                                            fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
                                            script        : [classpath: [], sandbox: false, script: createParameterScript("appId")]
                                    ]
                            ]
                    ]
            )
    ])

    if (!ONLY_REFRESH_CHOICES.toBoolean()) {

        deleteDir()
        json = json[TRIBE]

        final String ORIGIN_PROJECT = "$ORIGIN_BASE_PROJECT-$ORIGIN_ENVIRONMENT${ORIGIN_BRANCH.empty ? '' : "-${ORIGIN_BRANCH}"}"
        final String COMPARE_PROJECT = "$COMPARE_BASE_PROJECT-$COMPARE_ENVIRONMENT${COMPARE_BRANCH.empty ? '' : "-${COMPARE_BRANCH}"}"

        String APPLICATION

        def project
        def dc_origin
        def pods_compare
        def printMap

        stage('LogToOCP...'){
            logToOCP(ORIGIN_ENVIRONMENT, ORIGIN_BASE_PROJECT)
        }

        stage('Retrieve infos on origin project'){
            if(APP_PARENT == 'ALL'){
                dc_origin = sh script: "oc get dc -o json -n $ORIGIN_PROJECT", returnStdout: true
            } else {
                project = SharedLibraryUtils.retrieveProjectFromAppId(APP_PARENT, json, this) // the project in shareLibrary containing all meta info
                APPLICATION = project.artifactId
                dc_origin = sh script: "oc get dc/$APPLICATION -o json -n $ORIGIN_PROJECT", returnStdout: true
            }
        }

        stage('Retrieve infos on compare project'){
            pods_compare = sh script: "oc get pods -o json -n $COMPARE_PROJECT --show-all=false", returnStdout: true
        }

        stage('Compare what\'s deployed'){
            printMap = compare(dc_origin, pods_compare, ORIGIN_PROJECT, COMPARE_PROJECT)
        }

        stage('Print compare what\'s deployed'){
            printCompare(printMap)
        }

        stage('Clean up'){
            ws(pwd() + "@tmp") {
                step([$class: 'WsCleanup'])
            }
            ws(pwd() + "@libs") {
                step([$class: 'WsCleanup'])
            }
            ws(pwd() + "@script") {
                step([$class: 'WsCleanup'])
            }
        }

        currentBuild.displayName = "#$BUILD_NUMBER : $ORIGIN_PROJECT compared to $COMPARE_PROJECT"
    } else {
        currentBuild.displayName = 'REFRESHED CHOICES'
    }
}

def createParameterScript(value) {
    String returnValue = value
    def script

    // We may want to retrieve more specific value from a project
    switch (value) {
        case "appId":
            returnValue = "projects.appId"
            script = """import groovy.json.JsonSlurperClassic
	        def json = new JsonSlurperClassic().parseText(JSON_FILE)
	        List allAndAppID = json[TRIBE].${returnValue}
            allAndAppID.add(0, "ALL")
	        return allAndAppID
	        """
            break
        default:
            script = """import groovy.json.JsonSlurperClassic
	        def json = new JsonSlurperClassic().parseText(JSON_FILE)
	        return json[TRIBE].${returnValue}
	        """
            break
    }
    return script
}

def printCompare(def tmpMap){
    def jBuild = new JsonBuilder(tmpMap)
    println(jBuild.toPrettyString())
}

def compare(def dc_origin, def pods_compare, def ORIGIN_PROJECT, def COMPARE_PROJECT){
    def dc_origin_json = new JsonSlurperClassic().parseText(dc_origin)
    def pods_compare_json = new JsonSlurperClassic().parseText(pods_compare)

    String[] dc_names_tab = dc_origin_json.items.metadata.name
    String[] pods_names_tab = pods_compare_json.items.metadata.name

    List<String> uniquePodNames = new ArrayList<String>()
    List<String> compareNames = new ArrayList<String>()
    List<String> notcompareNames = new ArrayList<String>()

    def templatePods
    def templateDC

    def finalMap = [:]
    def matchMap = [:]
    def diffMap = [:]

    for (def name : pods_names_tab) {
        uniquePodNames.add(name.replaceAll(/-[0-9]*-[a-z0-9]*$/, ""))
    }

    uniquePodNames = uniquePodNames.toUnique()

    for (def namedc : dc_names_tab){
        if (uniquePodNames.contains(namedc)) {
            compareNames.add(namedc)
        }
        else{
            notcompareNames.add(namedc)
        }
    }

    for(def name: compareNames) {
        for (def item : dc_origin_json.items) {
            if (item.spec.template.metadata.labels.app.equals(name)) {
                templateDC = item
            }
        }
        for (def item : pods_compare_json.items) {
            if (item.metadata.labels.app.equals(name)) {
                templatePods = item
            }
        }
        retrieveProps(templateDC, templatePods, matchMap, diffMap, name, ORIGIN_PROJECT, COMPARE_PROJECT)

        finalMap.put('SAME', matchMap)
        finalMap.put('DIFFERENT', diffMap)
    }
    return finalMap
}

void logToOCP(final String OCP_ENV, final String TEAM) {
    url = ClusterInfo.clusterByEnv(OCP_ENV).url
    credentialsId = ClusterInfo.clusterByEnv(OCP_ENV).credentialsIdByTeam(TEAM)
    echo "attempting oc login with credentialsID ${credentialsId}"
    withCredentials([
            usernamePassword(credentialsId: credentialsId, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
    ]) {
        sh "oc login ${url} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
    }
}

void retrieveProps (def templateDC, def templatePods, def matchMap, def diffMap, def name, def ORIGIN_PROJECT, def COMPARE_PROJECT){

    def envDCs = templateDC.spec.template.spec.containers.env
    def envPods = templatePods.spec.containers.env
    def propsPodsMap = [:]
    def propsDcMap = [:]
    def envMap = [:]
    /**
     * Retrieve the env variables from the running version
     */
    for(def envPod : envPods){
        for(def envVar : envPod){
            if (envVar.name.equals("CONFIGMAP_LONGVERSION")) {
                propsPodsMap.put(envVar.name, envVar.value)
            }
            if (envVar.name.equals("PROJECT_LONGVERSION")) {
                propsPodsMap.put(envVar.name, envVar.value)
            }
        }
    }
    envMap.put(COMPARE_PROJECT, propsPodsMap)
    /**
     * Retrieve the env variables from the latest version
     */
    for(def envDc : envDCs){
        for(def envVar : envDc){
            if (envVar.name.equals("CONFIGMAP_LONGVERSION")) {
                propsDcMap.put(envVar.name, envVar.value)
            }
            if (envVar.name.equals("PROJECT_LONGVERSION")) {
                propsDcMap.put(envVar.name, envVar.value)
            }
        }
    }
    envMap.put(ORIGIN_PROJECT, propsDcMap)

    if (propsPodsMap.get("CONFIGMAP_LONGVERSION") == propsDcMap.get("CONFIGMAP_LONGVERSION") && propsPodsMap.get("PROJECT_LONGVERSION") == propsDcMap.get("PROJECT_LONGVERSION")){
        matchMap.put(name, envMap)
    }
    else {
        diffMap.put(name, envMap)
    }
}
