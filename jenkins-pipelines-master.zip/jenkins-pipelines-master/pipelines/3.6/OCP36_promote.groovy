#!Groovy
import groovy.json.JsonSlurperClassic
import intact.cluster.ocp.ClusterInfo
import intact.registry.Registry
import intact.util.SharedLibraryUtils
import intact.util.Utils

//@See https://githubifc.iad.ca.inet/DevTools/jenkins-pipeline-shared-librairies
def fallbackScript = "return ['ERROR']"
def paths = ["intact/util/ocp/digital/rqq.json",
			 "intact/util/ocp/digital/quoters.json",
			 "intact/util/ocp/digital/ubi.json",
			 "intact/util/ocp/contactpl_36.json"]

// Combine the json files into one big json
def combinedJsonFile = SharedLibraryUtils.combineJson(paths, this)

// Slurp the resulting json enabling access as an object
def json = new JsonSlurperClassic().parseText(combinedJsonFile)

//noinspection GroovyAssignabilityCheck
properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'Check this if you only need to refresh the BUILDNAME or other choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			[$class: 'WHideParameterDefinition', defaultValue: "${combinedJsonFile}", description: 'used to pass down to other pipelines', name: 'JSON_FILE'],
			[
				$class              : 'ChoiceParameter',
				choiceType          : 'PT_SINGLE_SELECT',
				description         : 'Select a tribe in order to filter the applications',
				filterable          : false,
				name                : 'TRIBE',
				randomName          : 'choice-parameter-48293583925954',
				referencedParameters: '',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: "return ''"],
					script        : [classpath: [], sandbox: false, script: "return ['contactpl_36', 'rqq', 'quoters', 'ubi']"]
				]
			],
			[
				$class              : 'CascadeChoiceParameter',
				choiceType          : 'PT_SINGLE_SELECT',
				description         : '',
				filterable          : true,
				name                : 'DEPLOYMENT',
				randomName          : 'choice-parameter-68065844775948',
				referencedParameters: 'TRIBE, JSON_FILE',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
					script        : [classpath: [], sandbox: false, script: createParameterScript("appId")]
				]
			],
			[
				$class              : 'CascadeChoiceParameter',
				choiceType          : 'PT_SINGLE_SELECT',
				description         : '',
				filterable          : true,
				name                : 'BASE_PROJECT',
				randomName          : 'choice-parameter-67545844545948',
				referencedParameters: 'TRIBE, JSON_FILE',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
					script        : [classpath: [], sandbox: false, script: createParameterScript("ocp_base_projects")]
				]
			],
			[
				$class              : 'CascadeChoiceParameter',
				choiceType          : 'PT_SINGLE_SELECT',
				description         : '',
				filterable          : true,
				name                : 'ORIGIN_ENVIRONMENT',
				randomName          : 'choice-parameter-66545844545948',
				referencedParameters: 'TRIBE, JSON_FILE',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
					script        : [classpath: [], sandbox: false, script: createParameterScript("environments")]
				]
			],
			[
				$class              : 'CascadeChoiceParameter',
				choiceType          : 'PT_SINGLE_SELECT',
				description         : '',
				filterable          : true,
				name                : 'ORIGIN_BRANCH',
				randomName          : 'choice-parameter-67545844570947',
				referencedParameters: 'TRIBE, JSON_FILE',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
					script        : [classpath: [], sandbox: false, script: createParameterScript("branches")]
				]
			],
			[
				$class              : 'CascadeChoiceParameter',
				choiceType          : 'PT_SINGLE_SELECT',
				description         : '',
				filterable          : true,
				name                : 'DESTINATION_ENVIRONMENT',
				randomName          : 'choice-parameter-66545844545949',
				referencedParameters: 'TRIBE, JSON_FILE',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
					script        : [classpath: [], sandbox: false, script: createParameterScript("environments")]
				]
			],
			[
				$class              : 'CascadeChoiceParameter',
				choiceType          : 'PT_SINGLE_SELECT',
				description         : '',
				filterable          : true,
				name                : 'DESTINATION_BRANCH',
				randomName          : 'choice-parameter-67545844570946',
				referencedParameters: 'TRIBE, JSON_FILE',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: fallbackScript],
					script        : [classpath: [], sandbox: false, script: createParameterScript("branches")]
				]
			],
			[
				$class              : 'ChoiceParameter',
				choiceType          : 'PT_SINGLE_SELECT',
				description         : 'Choose your destiny',
				filterable          : false,
				name                : 'DEPLOY',
				randomName          : 'choice-parameter-1345658395421',
				referencedParameters: '',
				script              : [
					$class        : 'GroovyScript',
					fallbackScript: [classpath: [], sandbox: false, script: "return ''"],
					script        : [classpath: [], sandbox: false, script: "return ['BOTH', 'DEPLOY-ONLY', 'PROPS-ONLY']"]
				]
			]
		]
	)
])

if (!ONLY_REFRESH_CHOICES.toBoolean()) {

	//retrieve the correct json from the merged json
	json = json[TRIBE]

	TEAM = json.team

	//verify if the env are interCluster or intraCluster by comparing url
	boolean useNexus = ClusterInfo.clusterByEnv(ORIGIN_ENVIRONMENT).url != ClusterInfo.clusterByEnv(DESTINATION_ENVIRONMENT).url

	//TODO change the release var when nexus is rdy
	String NEXUS_ENV = 'release'
	NEXUS_HOST = Registry.registryByEnv(NEXUS_ENV).host
	OCP_HOST = Registry.registryByEnv(ORIGIN_ENVIRONMENT).host
	DOCKER_RELEASE_PUSH_REGISTRY = Registry.registryByEnv(NEXUS_ENV)
	DOCKER_RELEASE_PUSH_REGISTRY_CREDENTIALID = DOCKER_RELEASE_PUSH_REGISTRY.credentialsIdByTeam(TEAM)


	node('master') {
		stage("retrieve project from json shared property") {
			project = SharedLibraryUtils.retrieveProjectFromAppId(DEPLOYMENT, json, this)
		}

		stage('validate inputs') {
			ORGANIZATION = project.gitHubOrgName
			ARTIFACT_ID = project.artifactId
			GROUP_ID = project.groupId
			APP_DOCKER = project.dockerId
			REPLICAS = project.replicas.get(ORIGIN_BRANCH).get(ORIGIN_ENVIRONMENT)
		}

		stage("Setup") {
			echo "Setup..."

			originCredentialsId = ClusterInfo.clusterByEnv(ORIGIN_ENVIRONMENT).credentialsIdByTeam(TEAM)
			destinationCredentialsId = ClusterInfo.clusterByEnv(DESTINATION_ENVIRONMENT).credentialsIdByTeam(TEAM)

			echo "originCredentialsId=$originCredentialsId"
			echo "destinationCredentialsId=$destinationCredentialsId"

			// TODO: Use credentialsId for git once ocp-jenkins-np-<team> service account
			// has access to GitHub
			//git credentialsId: originCredentialsId, url: "https://githubifc.iad.ca.inet/Intact/ocp-build-deploy-promote.git"
			git branch: 'master', credentialsId: 'build-maven', url: 'https://githubifc.iad.ca.inet/DevTools/openshift-templates.git'

			PROJECT_ORIGIN = "${BASE_PROJECT}-${ORIGIN_ENVIRONMENT}${ORIGIN_BRANCH.empty ? '' : "-${ORIGIN_BRANCH}"}"
			PROJECT_DESTINATION = "${BASE_PROJECT}-${DESTINATION_ENVIRONMENT}${DESTINATION_BRANCH.empty ? '' : "-${DESTINATION_BRANCH}"}"

			DESTINATION_CLUSTER_DOMAIN = ClusterInfo.clusterByEnv(DESTINATION_ENVIRONMENT).domain
			ORIGIN_CLUSTER_DOMAIN = ClusterInfo.clusterByEnv(ORIGIN_ENVIRONMENT).domain

			logToOCP(ORIGIN_ENVIRONMENT, TEAM)

			dcJSON = sh script: "oc get dc/$ARTIFACT_ID -n ${PROJECT_ORIGIN} -o json", returnStdout: true
			dc = readJSON text: dcJSON

			APPLICATION = "$dc.spec.template.metadata.labels.app"
			TAG_VERSION = "$dc.spec.template.metadata.labels.tagVersion".replaceFirst('-promote.*$', '')
            IMAGE_ID = sh script: "oc get istag/$APPLICATION:$TAG_VERSION -o template --template {{.image.metadata.name}} -n $PROJECT_ORIGIN", returnStdout: true
            CONFIGMAP_LONGVERSION = sh script: "oc env dc/$APPLICATION --list -n $PROJECT_ORIGIN | grep CONFIGMAP_LONGVERSION | sed 's/CONFIGMAP_LONGVERSION=//'", returnStdout: true
            PROJECT_LONGVERSION = sh script: "oc env dc/$APPLICATION --list -n $PROJECT_ORIGIN | grep PROJECT_LONGVERSION | sed 's/PROJECT_LONGVERSION=//'", returnStdout: true
			GIT_BRANCH = sh script: "oc env dc/$APPLICATION --list -n $PROJECT_ORIGIN | grep GIT_BRANCH | sed 's/GIT_BRANCH=//'", returnStdout: true
			GIT_BRANCH = GIT_BRANCH.replace('\n','')
            CONFIGMAP_LONGVERSION = CONFIGMAP_LONGVERSION.replace('\n','')
            PROJECT_LONGVERSION = PROJECT_LONGVERSION.replace('\n','')
			CONFIGMAP_VERSION = SharedLibraryUtils.getShortConfigMapVersion(CONFIGMAP_LONGVERSION)
			TAG_VERSION_PROMOTE = "$TAG_VERSION-to-$DESTINATION_ENVIRONMENT"
			SERVICE = Utils.applicationToService(APPLICATION)
			CURRENT_TAG = "$PROJECT_DESTINATION/$APPLICATION:$TAG_VERSION"
			PROMOTE_TAG = "$PROJECT_ORIGIN/$APPLICATION:$TAG_VERSION_PROMOTE"
			IMAGE = "$PROJECT_ORIGIN/$APPLICATION@$IMAGE_ID"

		}
		currentBuild.displayName = "#${BUILD_NUMBER} [$DEPLOY] ${APPLICATION}/$PROJECT_ORIGIN--->$PROJECT_DESTINATION"

		stage('Create configmap') {
			if (!DEPLOY.toString().equals('DEPLOY-ONLY')) {
				build job: 'OCP36_create_properties_configmap', parameters: [
					string(name: 'TRIBE', value: TRIBE),
					string(name: 'APP_PARENT', value: DEPLOYMENT),
					string(name: 'BASE_PROJECT', value: BASE_PROJECT),
					string(name: 'ENVIRONMENT', value: DESTINATION_ENVIRONMENT),
					string(name: 'BRANCH', value: DESTINATION_BRANCH),
					string(name: 'CONFIGMAP_VERSION', value: CONFIGMAP_VERSION),
					string(name: 'CONFIGMAP_LONGVERSION', value: CONFIGMAP_LONGVERSION)
				]
			} else {
				echo "Skip create configmap"
			}
		}

		stage('retrieving OCP values from configmap') {
			def configMapOut = sh script: "oc get configmap ${APPLICATION}.properties -n $PROJECT_DESTINATION -o json", returnStdout: true
			def configMapJson = new JsonSlurperClassic().parseText(configMapOut)
			String configMapData = configMapJson.data.'configmap.properties'
			LIVENESS_PROBE_INITIAL_DELAY = resolveOCPValueForKey('OCP_LIVENESS_PROBE_INITIAL_DELAY', project.livenessProbeInitialDelay, configMapData)
			READINESS_PROBE_INITIAL_DELAY = resolveOCPValueForKey('OCP_READINESS_PROBE_INITIAL_DELAY', project.readinessProbeInitialDelay, configMapData)
			READINESS_PROBE_URL = resolveOCPValueForKey('OCP_READINESS_PROBE_URL', project.readinessProbeUrl, configMapData)
			MEMORY_REQUEST = resolveOCPValueForKey('OCP_MEMORY_REQUEST', json.memory_sizes.get(project.memory_limit_size).get('memoryRequest'), configMapData)
			MEMORY_LIMIT = resolveOCPValueForKey('OCP_MEMORY_LIMIT', json.memory_sizes.get(project.memory_limit_size).get('memoryLimit'), configMapData)
			CPU_REQUEST = resolveOCPValueForKey('OCP_CPU_REQUEST', json.cpu_sizes.get(project.cpu_limit_size).get('cpuRequest'), configMapData)
			CPU_LIMIT = resolveOCPValueForKey('OCP_CPU_LIMIT', json.cpu_sizes.get(project.cpu_limit_size).get('cpuLimit'), configMapData)
		}

		echo """
					PROJECT_ORIGIN=$PROJECT_ORIGIN
					PROJECT_DESTINATION=$PROJECT_DESTINATION
					DESTINATION_CLUSTER_DOMAIN=$DESTINATION_CLUSTER_DOMAIN
					ORIGIN_CLUSTER_DOMAIN=$ORIGIN_CLUSTER_DOMAIN
					APPLICATION=$APPLICATION
					TAG_VERSION=$TAG_VERSION
					TAG_VERSION_PROMOTE=$TAG_VERSION_PROMOTE
					SERVICE=$SERVICE
					PROMOTE_TAG=$PROMOTE_TAG
					IMAGE_ID=$IMAGE_ID
					IMAGE=$IMAGE
					SERVICE=$SERVICE
					CONFIGMAP_VERSION=$CONFIGMAP_VERSION
					CONFIGMAP_LONGVERSION=$CONFIGMAP_LONGVERSION
					PROJECT_LONGVERSION=$PROJECT_LONGVERSION
					DEPLOY=$DEPLOY
					LIVENESS_PROBE_INITIAL_DELAY = $LIVENESS_PROBE_INITIAL_DELAY
					READINESS_PROBE_INITIAL_DELAY = $READINESS_PROBE_INITIAL_DELAY
					READINESS_PROBE_URL = $READINESS_PROBE_URL
					MEMORY_REQUEST = $MEMORY_REQUEST
					MEMORY_LIMIT = $MEMORY_LIMIT
					CPU_REQUEST = $CPU_REQUEST
					CPU_LIMIT = $CPU_LIMIT
				"""

		stage("Promote") {
			if (!DEPLOY.toString().equals('PROPS-ONLY')) {
				echo "Promoting from $PROJECT_ORIGIN to ${PROJECT_DESTINATION}..."

				IMAGE_ID = sh script: "oc get istag/$APPLICATION:$TAG_VERSION -o template --template {{.image.metadata.name}} -n $PROJECT_ORIGIN", returnStdout: true
				IMAGE = "$PROJECT_ORIGIN/$APPLICATION@$IMAGE_ID"

				sh "oc tag $IMAGE $PROMOTE_TAG -n $PROJECT_ORIGIN"

				// Work in progress for intercluster promote
				if (useNexus) {
					echo "Intercluster promote..."
					withCredentials([usernamePassword(credentialsId: destinationCredentialsId, passwordVariable: 'PROMOTER_PASSWORD', usernameVariable: 'PROMOTER_USERNAME')]) {

						sh "skopeo copy --src-creds=\"\$(oc whoami):\$(oc whoami -t)\" --dest-creds=\"$PROMOTER_USERNAME:${PROMOTER_PASSWORD.replace('$', '\\$')}\" docker://$OCP_HOST/$PROJECT_ORIGIN/$APPLICATION:$TAG_VERSION docker://$NEXUS_HOST/$NEXUS_ENV/$APPLICATION:$TAG_VERSION"
					}
				} else {
					echo "Same cluster promote..."
				}
				logToOCP(DESTINATION_ENVIRONMENT, TEAM)
				clusterDomain = ClusterInfo.clusterByEnv(DESTINATION_ENVIRONMENT).domain
				def dcParams = []
				dcParams << "-p CLUSTER_DOMAIN=$clusterDomain"
				dcParams << "-p CONFIGMAP_LONGVERSION=$CONFIGMAP_LONGVERSION"
				dcParams << "-p PROJECT_LONGVERSION=$PROJECT_LONGVERSION"
				dcParams << "-p APPLICATION=$APPLICATION"
				dcParams << "-p SOURCE_PROJECT=$PROJECT_ORIGIN"
				dcParams << "-p TARGET_PROJECT=$PROJECT_DESTINATION"
				dcParams << "-p ENVIRONMENT=$DESTINATION_ENVIRONMENT"
				dcParams << "-p BRANCH=$DESTINATION_BRANCH"
				dcParams << "-p TAG_VERSION=$TAG_VERSION"
				dcParams << "-p SERVICE=$SERVICE"
				dcParams << "-p LIVENESS_PROBE_INITIAL_DELAY=$LIVENESS_PROBE_INITIAL_DELAY"
				dcParams << "-p READINESS_PROBE_URL=$READINESS_PROBE_URL"
				dcParams << "-p READINESS_PROBE_INITIAL_DELAY=$READINESS_PROBE_INITIAL_DELAY"
				dcParams << "-p REPLICAS=$REPLICAS"
				dcParams << "-p MEMORY_REQUEST=$MEMORY_REQUEST"
				dcParams << "-p MEMORY_LIMIT=$MEMORY_LIMIT"
				dcParams << "-p CPU_REQUEST=$CPU_REQUEST"
				dcParams << "-p CPU_LIMIT=$CPU_LIMIT"
				dcParams << "-p GIT_BRANCH=$GIT_BRANCH"

				sh "oc process -f template-dc.yaml ${dcParams.join(' ')} -o yaml | oc apply -n $PROJECT_DESTINATION -f -"

				ifFirstDeploy = sh script: "oc describe dc/$APPLICATION -n $PROJECT_DESTINATION | grep 'Latest Version:'", returnStdout: true
				// force a deploy with 'latest' if its the first one
				if (ifFirstDeploy.contains('Not deployed')) {
					sh "oc rollout latest $APPLICATION -n $PROJECT_DESTINATION"
				}

				// TODO make deploy more resilient - sometimes it does not work right again
				sh "oc rollout history dc/$APPLICATION -n $PROJECT_DESTINATION"
				// looks at the current deployment history and starts a deploy if it's not already deploying (if status is not Complete or Failed
				sh "if [[ `oc rollout history dc/$APPLICATION -n $PROJECT_DESTINATION | tail -2` =~ Complete|Failed ]]; then oc rollout latest $APPLICATION -n $PROJECT_DESTINATION; else echo deployment already on the way;  fi"
				sh "oc tag $IMAGE $CURRENT_TAG -n $PROJECT_DESTINATION"
			} else {
				echo "Skip promote."
			}
		}

		stage('restarting the pods to update the properties') {
			// restart the pods if only the properties has been updated and update the configMapVersion in the labels
			if (DEPLOY.toString().equals('PROPS-ONLY')) {
				// TODO should we login right from the start?
				logToOCP(DESTINATION_ENVIRONMENT, TEAM)
				sh("oc env dc/$APPLICATION CONFIGMAP_LONGVERSION=$CONFIGMAP_LONGVERSION -n $PROJECT_DESTINATION")
			}
		}

		stage('Clean up') {
			ws(pwd() + "@tmp") {
				step([$class: 'WsCleanup'])
			}
			ws(pwd() + "@libs") {
				step([$class: 'WsCleanup'])
			}
			ws(pwd() + "@script") {
				step([$class: 'WsCleanup'])
			}
			deleteDir()
		}
	}
} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}

void logToOCP(final String OCP_ENV, final String TEAM) {
	url = ClusterInfo.clusterByEnv(OCP_ENV).url
	credentialsId = ClusterInfo.clusterByEnv(OCP_ENV).credentialsIdByTeam(TEAM)
	echo "attempting oc login with credentialsID ${credentialsId}"
	withCredentials([
		usernamePassword(credentialsId: credentialsId, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
	]) {
		sh "oc login ${url} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
	}
}

def createParameterScript(value) {
	String returnValue = value

	// We may want to retrieve more specific value from a project
	switch (value) {
		case "appId":
			returnValue = "projects.appId"
			break
		default:
			break
	}

	def script = """import groovy.json.JsonSlurperClassic
	def json = new JsonSlurperClassic().parseText(JSON_FILE)
	return json[TRIBE].${returnValue}
	"""

	return script
}

String resolveOCPValueForKey(String key, def defaultValue, def configMapData) {
	boolean valueFound = false
	String value
	if (configMapData.contains(key)) {
		valueFound = true
		value = SharedLibraryUtils.retrieveValueFromConfigmapData(key, configMapData)
	} else {
		value = defaultValue
	}
	println """
			=== RESOLVING KEY $key ===
			value ${valueFound ? 'found' : 'NOT found'} in configmap
			$key == $value
			=========================="""
	return value
}
