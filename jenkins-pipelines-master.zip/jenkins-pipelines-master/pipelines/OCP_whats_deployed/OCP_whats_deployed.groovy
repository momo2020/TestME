#!Groovy
import intact.cluster.ocp.Cluster
import groovy.json.JsonSlurperClassic

def jsonFile = libraryResource 'intact/util/ocp/rqq.json'
def json = new JsonSlurperClassic().parseText(jsonFile)

properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			choice(choices: json.ocp_base_projects.join("\n"), description: '', name: 'OCP_BASE_PROJECT'),
			choice(choices: json.environments.join("\n"), description: '', name: 'ORIGIN_ENVIRONMENT'),
			choice(choices: json.branches.join("\n"), description: '', name: 'ORIGIN_BRANCH'),
		])
])

if (!ONLY_REFRESH_CHOICES.toBoolean()) {

	final String OCP_PROJECT = "${OCP_BASE_PROJECT}-${ORIGIN_ENVIRONMENT}${ORIGIN_BRANCH.empty ? '' : "-${ORIGIN_BRANCH}"}"

	originClusterURL = Cluster.clusterByEnv(ORIGIN_ENVIRONMENT).url
	originClusterCredentials = Cluster.clusterByEnv(ORIGIN_ENVIRONMENT).credentialsId

	node('node-2020-linux-prd-004') {
		currentBuild.displayName = "#${BUILD_NUMBER} : ${OCP_PROJECT}"
		deleteDir()
		JAVA_HOME = tool 'ibm-java-linux-1.7-x86_64-71'
		MAVEN_HOME = tool 'maven-3.0.5'
		withEnv([
			"JAVA_HOME=${JAVA_HOME}",
			"MAVEN_HOME=${MAVEN_HOME}",
			"PATH=${JAVA_HOME}/bin:${MAVEN_HOME}/bin:/usr/local/bin:/usr/bin:/bin"
		]) {
			stage("Retrieve origin deployment & image") {
				withCredentials([
					usernamePassword(credentialsId: originClusterCredentials, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
				]) {
					sh "oc login ${originClusterURL} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
				}
				sh "oc project ${OCP_PROJECT}"
				sh "oc get dc -n ${OCP_PROJECT} -o json > deploymentConfigs-${OCP_BASE_PROJECT}-${ORIGIN_ENVIRONMENT}.json"

				String deploymentConfigsOrigin = sh script: "cat deploymentConfigs-${OCP_BASE_PROJECT}-${ORIGIN_ENVIRONMENT}.json", returnStdout: true

				def deploymentConfigsOriginJson = new JsonSlurperClassic().parseText(deploymentConfigsOrigin)

				printHistory(deploymentConfigsOriginJson)
			}
		}
	}

} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}

@NonCPS
def printHistory(json) {
	def jsonBuilder = new groovy.json.JsonBuilder()
	String[] names = json.items.spec.template.metadata.name
	jsonBuilder {
		"${OCP_BASE_PROJECT}-${ORIGIN_ENVIRONMENT}" names.collect { name ->
			def template = json.items.spec.template.findAll { t ->
				t.metadata.name == name
			}
			String groupId = template.metadata.labels.groupId[0]
			String artifactId = template.metadata.labels.artifactId[0]
			String projectVersion = template.metadata.labels.projectVersion[0]
			String GAV = [groupId, artifactId, projectVersion].join(':')
			String projectLongVersion = template.metadata.labels.projectLongVersion[0]
			String configMapLongVersion = template.metadata.labels.configMapLongVersion[0]
			[
				name                : name,
				GAV                 : GAV,
				projectLongVersion  : projectLongVersion,
				configMapLongVersion: configMapLongVersion
			]
		}
	}

	println(jsonBuilder.toPrettyString())
//    String jsonFileName = "${OCP_BASE_PROJECT}-${ORIGIN_ENVIRONMENT}.json"
//    sh "touch jsonFileName"
//    sh "echo ${jsonBuilder.toPrettyString()} > ${jsonFileName}"
//    sh "echo ${jsonFileName}"
//    archiveArtifacts allowEmptyArchive: true, artifacts: jsonFileName
}

