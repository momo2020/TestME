#!Groovy
import intact.cluster.ocp.Cluster
import groovy.json.JsonSlurperClassic

import intact.elasticsearch.Logstash
import intact.elasticsearch.domain.Deployment

properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'check this is you only need to refresh the BUILDNAME or other choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'NAME'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'OCP_BASE_PROJECT'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'ENVIRONMENT'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'BRANCH'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'NODE'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'REPLICAS'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'DEPLOYMENT_STRATEGY'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'READINESS_PROBE_URL'],
			[$class: 'WHideParameterDefinition', defaultValue: 'true', description: '', name: 'RECORD_HISTORY'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'LIVENESS_PROBE_INITIAL_DELAY'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'READINESS_PROBE_INITIAL_DELAY'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'GROUPID'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'ARTIFACTID'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'PROJECT_VERSION'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'CONFIGMAP_VERSION'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'DESCRIPTION'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'BATCH_DESCRIPTION'],
			[$class: 'WHideParameterDefinition', defaultValue: 'branches', description: '', name: 'TEMPLATE_BRANCH'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'JSON_FILE'],
			booleanParam(defaultValue: false, description: 'check this if you do not want to wait for Openshift to deploy the new pod', name: 'SKIP_WAIT_FOR_OCP_DEPLOYMENT')
		])
])

if (!ONLY_REFRESH_CHOICES.toBoolean()) {
	def json = new JsonSlurperClassic().parseText(JSON_FILE)
	TOKENS = NAME.split(':')
	REPOSITORY = TOKENS[0]
	ORIGIN_TAG = TOKENS[1]

	PULL_REGISTRY = "docker-group.iad.ca.inet:8473"
	PUSH_MUTABLE_REGISTRY = "docker-mutable.iad.ca.inet:8463"
	DESTINATION_TAG = ORIGIN_TAG.replaceFirst('-[^-]+$', "-${ENVIRONMENT.toUpperCase()}")
	DESTINATION_TAG += "-${OCP_BASE_PROJECT.toUpperCase()}"
	final String OCP_PROJECT = "${OCP_BASE_PROJECT}-${ENVIRONMENT}${BRANCH.empty ? '' : "-${BRANCH}"}"
	SERVICE = REPOSITORY.replaceAll('-', '')
	if (SERVICE.length() > 24) {
		SERVICE = SERVICE.substring(0, 24)
	}

	openshiftSuffix = Cluster.clusterByEnv(ENVIRONMENT).suffix

	PULL_NAME = "${PULL_REGISTRY}/intact/${NAME}-${OCP_BASE_PROJECT.toUpperCase()}"
	PUSH_MUTABLE_NAME = "${PUSH_MUTABLE_REGISTRY}/intact/${REPOSITORY}:${DESTINATION_TAG}"

	currentBuild.displayName = "#${BUILD_NUMBER} ${NAME} -> ${OCP_PROJECT}"

	project = retrieveProjectFromArtifactId(REPOSITORY, json)

	deploymentStrategy = !DEPLOYMENT_STRATEGY.isEmpty() ? DEPLOYMENT_STRATEGY : project.deployment_strategy
	replicas = !REPLICAS.isEmpty() ? REPLICAS : project.replicas.get(BRANCH).get(ENVIRONMENT)
	livenessProbeInitialDelay = !LIVENESS_PROBE_INITIAL_DELAY.isEmpty() ? LIVENESS_PROBE_INITIAL_DELAY : project.livenessProbeInitialDelay
	readinessProbeUrl = !READINESS_PROBE_URL.isEmpty() ? READINESS_PROBE_URL : project.readinessProbeUrl
	readinessProbeInitialDelay = !READINESS_PROBE_INITIAL_DELAY.isEmpty() ? READINESS_PROBE_INITIAL_DELAY : project.readinessProbeInitialDelay

	groupId = !GROUPID.isEmpty() ? GROUPID : project.groupId
	artifactId = !ARTIFACTID.isEmpty() ? ARTIFACTID : project.artifactId
	dockerId = project.dockerId
	projectVersion = !PROJECT_VERSION.isEmpty() ? PROJECT_VERSION : ORIGIN_TAG
	projectLongVersion = 'unspecified'
	configMapLongVersion = 'unspecified'
	def configMapVersion = !CONFIGMAP_VERSION.isEmpty() ? CONFIGMAP_VERSION : ORIGIN_TAG
	String imageId
	String digestId
	final String ORGANIZATION = json.organization[0].toString()
	String memoryLimit = "Not defined"
	String memoryRequest = "Not defined"
	String cpuLimit = "Not defined"
	String cpuRequest = "Not defined"

	node(NODE) {
		deleteDir()
		JAVA_HOME = tool 'ibm-java-linux-1.7-x86_64-71'
		MAVEN_HOME = tool 'maven-3.0.5'
		withEnv(["JAVA_HOME=${JAVA_HOME}", "MAVEN_HOME=${MAVEN_HOME}", "PATH=${JAVA_HOME}/bin:${MAVEN_HOME}/bin:/usr/local/bin:/usr/bin:/bin"]) {
			wrap([$class: 'BuildUser']) {
				buildUserId = env.BUILD_USER_ID
			}

			stage('retrieve long versions') {
				if (projectVersion.contains('SNAPSHOT')) {
					projectLongVersion = getLongVersion(groupId, artifactId, projectVersion)
				} else {
					projectLongVersion = projectVersion
				}
				if (configMapVersion.contains('SNAPSHOT')) {
					configMapLongVersion = getLongVersion(groupId, dockerId, configMapVersion)
				} else {
					configMapLongVersion = configMapVersion
				}
			}

			stage("Login to OCP") {
				logToOCP(ENVIRONMENT, OCP_PROJECT)
			}

			stage("Load sources") {
				dir("templates") {
					if (hasCommonProperties(OCP_PROJECT)) {
						git branch: 'common-properties', credentialsId: '0afacacb-18d1-4b9a-a0db-d2c44495bae8', url: 'https://githubifc.iad.ca.inet/DevTools/openshift-templates.git'
					} else {
						git branch: TEMPLATE_BRANCH, credentialsId: '0afacacb-18d1-4b9a-a0db-d2c44495bae8', url: 'https://githubifc.iad.ca.inet/DevTools/openshift-templates.git'
					}
				}
			}

			stage("Tag") {
				String digest = sh script: "docker pull ${PULL_NAME}", returnStdout: true

				digest = digest.substring(digest.indexOf("Digest: "))
				digest = digest.substring(0, digest.indexOf('\n'))
				digestId = digest.replace('Digest: ', '')

				sh "docker tag ${PULL_NAME} ${PUSH_MUTABLE_NAME}"
				imageId = sh script: "docker inspect -f '{{.ID}}' ${PUSH_MUTABLE_NAME}", returnStdout: true
				imageId = imageId.replaceFirst('^sha256:', '').trim()
			}

			stage("Push tag") {
				sh "docker push ${PUSH_MUTABLE_NAME}"
				sleep time: 10, unit: 'SECONDS'
			}

			stage("Process Intact template") {
				dir("templates") {
					final String UUID = UUID.randomUUID().toString()
					def templateParameters = []
					templateParameters << "REPOSITORY=${REPOSITORY}"
					templateParameters << "GROUPID=${groupId}"
					templateParameters << "ARTIFACTID=${artifactId}"
					templateParameters << "PROJECT_VERSION=${projectVersion}"
					templateParameters << "CONFIGMAP_VERSION=${configMapVersion}"
					templateParameters << "PROJECT_LONGVERSION=${projectLongVersion}"
					templateParameters << "CONFIGMAP_LONGVERSION=${configMapLongVersion}"
					templateParameters << "TAG=${DESTINATION_TAG}"
					templateParameters << "ENVIRONMENT=${ENVIRONMENT}"
					templateParameters << "BRANCH=${BRANCH}"
					templateParameters << "IMAGE_ID=${imageId}"
					templateParameters << "DIGEST_ID=${digestId}"
					templateParameters << "SERVICE=${SERVICE}"
					templateParameters << "PROJECT=${OCP_PROJECT}"
					templateParameters << "REPLICAS=${replicas}"
					templateParameters << "DEPLOYMENT_STRATEGY=${deploymentStrategy}"
					templateParameters << "LIVENESS_PROBE_INITIAL_DELAY=${livenessProbeInitialDelay}"
					templateParameters << "READINESS_PROBE_URL=${readinessProbeUrl}"
					templateParameters << "READINESS_PROBE_INITIAL_DELAY=${readinessProbeInitialDelay}"
					templateParameters << "OPENSHIFT_SUFFIX=${openshiftSuffix}"
					templateParameters << "UUID=${UUID}"
					templateParameters << "ORGANIZATION=${ORGANIZATION}"

					if (limitWhiteList(OCP_PROJECT)){
						String MEMORY_SIZE = project.memory_limit_size
						if (MEMORY_SIZE == null || !json.memory_sizes.containsKey(MEMORY_SIZE)) {
							println("MEMORY_SIZE ${MEMORY_SIZE} is not valid. will use default memory limits")
							MEMORY_SIZE = 'default'
						}
						memoryRequest = json.memory_sizes.get(MEMORY_SIZE).get("memoryRequest")
						memoryLimit = json.memory_sizes.get(MEMORY_SIZE).get("memoryLimit")
						println("MEMORY_SIZE = ${MEMORY_SIZE}")
						println("memoryRequest is now ${memoryRequest}")
						println("memoryLimit is now ${memoryLimit}")

						String CPU_SIZE = project.cpu_limit_size
						if (CPU_SIZE == null || !json.cpu_sizes.containsKey(CPU_SIZE)) {
							println("CPU_SIZE ${CPU_SIZE} is not valid. will use default cpu limits")
							CPU_SIZE = 'default'
						}
						cpuRequest = json.cpu_sizes.get(CPU_SIZE).get("cpuRequest")
						cpuLimit = json.cpu_sizes.get(CPU_SIZE).get("cpuLimit")
						println("CPU_SIZE = ${CPU_SIZE}")
						println("cpuRequest is now ${cpuRequest}")
						println("cpuLimit is now ${cpuLimit}")

						templateParameters << "MEMORY_REQUEST=${memoryRequest}"
						templateParameters << "MEMORY_LIMIT=${memoryLimit}"
						templateParameters << "CPU_REQUEST=${cpuRequest}"
						templateParameters << "CPU_LIMIT=${cpuLimit}"

						sh "oc process -n ${OCP_PROJECT} -f intact-ocp-docker-template-limits.yaml -v ${templateParameters.join(',')} -o yaml > processed.yaml"  //need to duplicate limits also DB
					} else {
						sh "oc process -n ${OCP_PROJECT} -f intact-ocp-docker-template.yaml -v ${templateParameters.join(',')} -o yaml > processed.yaml"
					}
					sh 'cat processed.yaml'
					template = readFile 'intact-ocp-docker-template.yaml'
					processed = readFile 'processed.yaml'
					stash name: 'processed', includes: 'processed.yaml'
				}
			}

			stage("Deploy to OCP") {
				dir("templates") {
					// To make sure we are still on the appropriate destination project
					logToOCP(ENVIRONMENT, OCP_PROJECT)
					sh "oc apply -n ${OCP_PROJECT} -f processed.yaml"
					sh "oc rollout history dc/${REPOSITORY} -n ${OCP_PROJECT}"
					// looks at the current deployment history and starts a deploy if it's not already deploying (if status is not Complete or Failed
					sh "if [[ `oc rollout history dc/${REPOSITORY} -n ${OCP_PROJECT} | tail -2` =~ Complete|Failed ]]; then oc deploy ${REPOSITORY} --latest -n ${OCP_PROJECT}; else echo deployment already on the way;  fi"
				}
			}

			stage("Record history") {
				String description = DESCRIPTION as String
				String batch_description = BATCH_DESCRIPTION as String
				if (RECORD_HISTORY.contains('true')) {
					logstash = Logstash.instance
					deployment = new Deployment(
						PULL_REGISTRY, PUSH_MUTABLE_REGISTRY,
						ORIGIN_TAG, DESTINATION_TAG, REPOSITORY, imageId, digestId,
						OCP_PROJECT, template, processed, groupId, artifactId,
						projectVersion, projectLongVersion, configMapVersion,
						configMapLongVersion, livenessProbeInitialDelay, readinessProbeUrl,
						readinessProbeInitialDelay, replicas, deploymentStrategy, memoryLimit,
						memoryRequest, cpuLimit, cpuRequest, description, batch_description, env, buildUserId
					)
					logstash.add(deployment)
				} else {
					echo 'skipping record history step'
				}
			}

			stage("Waiting for deployment") {
				if (!SKIP_WAIT_FOR_OCP_DEPLOYMENT.toBoolean()) {
					timeout(time: 10, unit: 'MINUTES') {
						String rolloutHistory = ''
						waitUntil {
							sleep time: 10, unit: 'SECONDS'
							rolloutHistory = sh script: "oc rollout history dc/${REPOSITORY} -n ${OCP_PROJECT} | tail -2", returnStdout: true
							println('status : ' + rolloutHistory)
							return rolloutHistory.contains('Complete') || rolloutHistory.contains('Failed')
						}
					}
				} else {
					echo 'Skipping waiting for deployment'
				}
			}
		}
	}

	node(NODE) {
		stage('write processed.yaml in git') {
			unstash 'processed'
			dir('processed') {
				withCredentials([usernamePassword(credentialsId: '0afacacb-18d1-4b9a-a0db-d2c44495bae8', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
					git branch: 'master', credentialsId: '0afacacb-18d1-4b9a-a0db-d2c44495bae8', url: 'https://githubifc.iad.ca.inet/DevTools/openshift-processed-templates.git'

					String processedPath = "${OCP_BASE_PROJECT}/${ENVIRONMENT}${BRANCH.empty ? '' : "/${BRANCH}"}/${artifactId}/"
					sh "mkdir -p ${processedPath}"
					sh "cp ../processed.yaml ${processedPath}"
					String status = sh script: 'git status', returnStdout: true
					if (!status.contains('nothing to commit')) {
						sh 'git add *'
						sh "git commit -m \'projectVersion : ${projectLongVersion}, configMapVersion : ${configMapLongVersion}\'"
						sh "git push --set-upstream https://${GIT_USERNAME}:${GIT_PASSWORD.replace('$', '\\$')}@githubifc.iad.ca.inet/DevTools/openshift-processed-templates.git master"
					} else {
						echo 'processed.yaml has not changed since last deploy, nothing to commit'
					}
				}
			}
		}
	}
} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}

boolean limitWhiteList(String OCP_PROJECT) {
	def projectsHavingLimits = []
	projectsHavingLimits << "rqq-dev"
	projectsHavingLimits << "rqq-prep"
	projectsHavingLimits << "contactpl-dev-d16"
	projectsHavingLimits << "contactpl-intg-d16"
	projectsHavingLimits << "contactpl-uat-d16"
	projectsHavingLimits << "contactpl-dev-maint"
	projectsHavingLimits << "contactpl-intg-cp"
	projectsHavingLimits << "contactpl-intg-maint"
	projectsHavingLimits << "contactpl-uat-maint"
	projectsHavingLimits << "contactpl-dev-d18"
	projectsHavingLimits << "contactpl-prep"
	projectsHavingLimits << "contactpl-prep-d16"
	projectsHavingLimits << "contactpl-uat-cp"
	projectsHavingLimits << "contactpl-uat-dhtrg"

	return projectsHavingLimits.contains((OCP_PROJECT))
}

def retrieveProjectFromArtifactId(String artifactId, json) {
	def project
	boolean found = false
	for (def p : json.projects) {
		if (p.artifactId.equals(artifactId)) {
			project = p
			found = true
		}
	}
	if (!found) {
		echo "artifact + [${artifactId}] not found in shared library"
		assert false
	}
	return project
}

/**
 * retrieves the long snapshot version from nexus using the restAPI
 */
def getLongVersion(String group, String artifact, String version) {
	final String repo = 'snapshots'
	final String packageType = 'pom'
	String base = 'https://prod-nexus-b2eapp.iad.ca.inet:8443/nexus/service/local/artifact/maven/resolve'
	String request = "${base}?g=${group}&a=${artifact}&v=${version}&r=${repo}&p=${packageType}"
	String tag = '<version>'
	withCredentials([
		usernamePassword(credentialsId: '0afacacb-18d1-4b9a-a0db-d2c44495bae8', passwordVariable: 'MVN_PASSWORD', usernameVariable: 'MVN_USERNAME')
	]) {
		def xml = sh(
			script: "curl  -u ${MVN_USERNAME}:${MVN_PASSWORD.replace('$', '\\$')} '${request}' | grep ${tag.replace('<','\\<').replace('>','\\>')} | sed -e 's/<[^>]*>//g' ",
			returnStdout: true
		)
		xml.trim()
	}
}

void logToOCP(final String OCP_ENV, final String OCP_PROJECT) {
	String ocpClusterURL = Cluster.clusterByEnv(OCP_ENV).url
	String ocpClusterCredentials = Cluster.clusterByEnv(OCP_ENV).credentialsId
	withCredentials([
		usernamePassword(credentialsId: ocpClusterCredentials, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
	]) {
		sh "oc login ${ocpClusterURL} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
		sh "oc project ${OCP_PROJECT}"
	}
}

/**
 * Checks if there is a configmap-common.properties in the ocp project
 */
boolean hasCommonProperties(final String OCP_PROJECT){
	def configMaps = sh script: "oc get configmaps -n ${OCP_PROJECT} ", returnStdout: true
	println("configMaps == ${configMaps}")
	return configMaps.contains('configmap-common.properties')
}
