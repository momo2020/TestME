#!Groovy
package OCP_mass_promote

import groovy.json.JsonSlurperClassic

//@See https://githubifc.iad.ca.inet/DevTools/jenkins-pipeline-shared-librairies
def jsonFile = libraryResource 'intact/util/ocp/contactpl_docker.json'
def jsonContactpl = new JsonSlurperClassic().parseText(jsonFile)

properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'Check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			booleanParam(defaultValue: false, description: 'Check this if you do not want to call the SOAP UI test at the end of the promote', name: 'SKIP_TEST'),
			[$class: 'TextParameterDefinition', defaultValue: getTemplate(), description: '', name: 'JSON'],
		])
])

echo '--------------'
echo 'bf refresh choice'
echo '--------------'

if (!ONLY_REFRESH_CHOICES.toBoolean()) {
	def json = new JsonSlurperClassic().parseText(JSON)
	boolean shouldRunTest = false
	
echo '--------------'
echo 'in refresh choice'
echo '--------------'	

	stage('validate input') {
		echo 'Checking if json is instanceof Map'
		assert json instanceof Map
		echo 'Checking if NODE in json file is empty'
		assert !json.deploymentInfo.NODE.isEmpty(): 'NODE in json file is empty'
		echo 'Checking if Origin OCP is empty'
		assert !json.deploymentInfo.ORIGIN_OCP_BASE_PROJECT.isEmpty(): 'ORIGIN_OCP_BASE_PROJECT in json file is empty'
		echo 'Checking if Destination OCP is empty'
		assert !json.deploymentInfo.DESTINATION_OCP_BASE_PROJECT.isEmpty(): 'DESTINATION_OCP_BASE_PROJECT in json file is empty'
		echo 'Checking if Origin environment is empty'
		assert !json.deploymentInfo.ORIGIN_ENVIRONMENT.isEmpty(): 'ORIGIN_ENVIRONMENT in json file is empty'
		echo 'Checking if Destination environment is empty'
		assert !json.deploymentInfo.DESTINATION_ENVIRONMENT.isEmpty(): 'DESTINATION_ENVIRONMENT in json file is empty'
//		echo 'Checking if projects is instanceof List'
//		assert json.projects instanceof List
	}

    String description = json.deploymentInfo.DESCRIPTION
	if (!description.isEmpty()) {
		currentBuild.displayName = "#${BUILD_NUMBER} " + description
	}

	String NODE = json.deploymentInfo.NODE
	String ORIGIN_OCP_BASE_PROJECT = json.deploymentInfo.ORIGIN_OCP_BASE_PROJECT
	String DESTINATION_OCP_BASE_PROJECT = json.deploymentInfo.DESTINATION_OCP_BASE_PROJECT
	String ORIGIN_ENVIRONMENT = json.deploymentInfo.ORIGIN_ENVIRONMENT
	String DESTINATION_ENVIRONMENT = json.deploymentInfo.DESTINATION_ENVIRONMENT
	String ORIGIN_BRANCH = json.deploymentInfo.ORIGIN_BRANCH
	String DESTINATION_BRANCH = json.deploymentInfo.DESTINATION_BRANCH
	String TEMPLATE_BRANCH = json.deploymentInfo.TEMPLATE_BRANCH
	int THRESHOLD = Integer.parseInt(json.deploymentInfo.THRESHOLD)

	stage('deploy them all') {
		def projects = json.projects
		def batch
		int batchNumber = 1

		while (!projects.isEmpty()) {
            echo 'projects is not empty'
            int projsize = projects.size()


            if (projects.size() > THRESHOLD) {
                echo "projects size is ${projsize} and over threshold which is ${THRESHOLD}"
                if (THRESHOLD == 1) {
                    batch = projects[0]
                }
                batch = projects[0..THRESHOLD - 1]
			} else {
                echo 'projects size under threshold'
				batch = projects
			}

            echo 'projects size doesnt work'

			def builds = [:]

			node(NODE) {
				for (int i = 0; i < batch.size(); i++) {
                    echo 'Start to launch the individual deployments'
					// @ see https://jenkins.io/doc/pipeline/examples/ section : Jobs In Parallel
					def index = i
					String batchDescription = "[${BUILD_NUMBER} : ${batchNumber}]"
					builds["batch${batchNumber} : build${i}"] = {
						DEPLOYMENT = batch[index].DEPLOYMENT
						REPLICAS = batch[index].REPLICAS
						DEPLOYMENT_STRATEGY = batch[index].DEPLOYMENT_STRATEGY
						READINESS_PROBE_URL = batch[index].READINESS_PROBE_URL
						SKIP_UPDATE_PROPERTIES = batch[index].SKIP_UPDATE_PROPERTIES

						build job: 'OCP_46_CONTACTPL_promote', wait: true, parameters: [

							string(name: 'DEPLOYMENT', value: DEPLOYMENT),
							string(name: 'ORIGIN_OCP_BASE_PROJECT', value: ORIGIN_OCP_BASE_PROJECT),
							string(name: 'DESTINATION_OCP_BASE_PROJECT', value: DESTINATION_OCP_BASE_PROJECT),
							string(name: 'ORIGIN_ENVIRONMENT', value: ORIGIN_ENVIRONMENT),
							string(name: 'DESTINATION_ENVIRONMENT', value: DESTINATION_ENVIRONMENT),
							string(name: 'ORIGIN_BRANCH', value: ORIGIN_BRANCH),
							string(name: 'DESTINATION_BRANCH', value: DESTINATION_BRANCH),
							string(name: 'NODE', value: NODE),
							string(name: 'SKIP_UPDATE_PROPERTIES', value: SKIP_UPDATE_PROPERTIES),
							string(name: 'TEMPLATE_BRANCH', value: TEMPLATE_BRANCH),
							string(name: 'REPLICAS', value: REPLICAS),
							string(name: 'DEPLOYMENT_STRATEGY', value: DEPLOYMENT_STRATEGY),
							string(name: 'READINESS_PROBE_URL', value: READINESS_PROBE_URL),
							string(name: 'dummy', value: "${index}"),
							string(name: 'DESCRIPTION', value: description),
							string(name: 'BATCH_DESCRIPTION', value: batchDescription),
							string(name: 'SKIP_WAIT_FOR_OCP_DEPLOYMENT', value: 'true'),
							string(name: 'SKIP_TEST', value: 'true')
						]
					}
					// If one build in the batch needs a test, the soap UI test will be called at the end of this mass job.
//					if (!shouldRunTest) {
//						for (def p : jsonContactpl.projects) {
//							if (p.artifactId.equals(batch[index].DEPLOYMENT)) {
//							echo '--------------'
//							echo ' bf run test'
//							echo '--------------'
//								shouldRunTest = p.launchSoapUITest.toBoolean()
//							echo '--------------'
//							echo ' in run test'
//							echo '--------------'
//
//							}
//						}
//					}
				}
				builds.failFast = false
				parallel builds
			}
			projects = projects.drop(THRESHOLD)
			batchNumber++
		}

//		if (json.soapui_tests) {
//			stage('Calling SOAP UI test') {
//				// check if the SKIP_TEST checkbox is checked
//				echo '--------------'
//				echo ' bf soapui tests'
//				echo '--------------'
//				if (!SKIP_TEST.toBoolean()) {
//				echo '--------------'
//				echo ' in soapui tests'
//				echo '--------------'
//
//					// test is needed if at least one job in the batch is tagged to launch a soap UI test
//					if (shouldRunTest) {
//
//						echo "An application in the batch is tagged to run a soap UI test."
//						// load the environment whitelist
//						def environmentWhitelist = jsonContactpl.soapui_tests.environments
//						echo "The soap UI tests environments found in the shared library = ${environmentWhitelist}"
//
//						if (environmentWhitelist.contains(DESTINATION_ENVIRONMENT)) {
//							echo "${DESTINATION_ENVIRONMENT} environment has been found in the whitelist"
//
//							// fetch the soap UI test in the list
//							String testJob = jsonContactpl.soapui_tests.soapui_test_builds.get(0)
//
//							build job: 'remote_build_SOAPUI_tests', parameters: [
//								string(name: 'REMOTE_JOB_NAME', value: "${testJob}")
//							], wait: false
//						} else {
//							echo "${DESTINATION_ENVIRONMENT} environment is not in the whitelist. Skipping SOAP UI test call"
//						}
//					} else {
//						echo "The applications in this batch doesn't need to run a test. The SOAP UI test will NOT be called."
//					}
//				} else {
//					echo "Skipping SOAP UI test because SKIP_TEST has been checked"
//				}
//			}
//		} else {
//			echo "Skipping SOAP UI test because soapui_tests doesn't exist in the shared library"
//		}
	}
} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}

//NB no space in string definition: "DEPLOYMENT": "contract-locator-service-endpoints" -> OK 
//									"DEPLOYMENT": "contract-locator-service-endpoints "-> Error 
def getTemplate() {
	return '''{
    "deploymentInfo": {
      "ORIGIN_OCP_BASE_PROJECT": "contactpl",
      "ORIGIN_ENVIRONMENT": "intg",
      "ORIGIN_BRANCH": "d17",
      "DESTINATION_OCP_BASE_PROJECT": "contactpl",
      "DESTINATION_ENVIRONMENT": "uat",
      "DESTINATION_BRANCH": "d17",
      "NODE": "mtl2020-docker",
      "DESCRIPTION": "FROMINTGYTOUATY",
      "TEMPLATE_BRANCH": "master",
      "THRESHOLD": "1"
    },
    "projects": [
\t  {
        "DEPLOYMENT": "address-service-endpoints",
        "DEPLOYMENT_STRATEGY": "",
        "REPLICAS": "",
        "MEMORY_LIMIT": "",
        "READINESS_PROBE_URL": "",
        "SKIP_UPDATE_PROPERTIES": "false"
      },
      {
        "DEPLOYMENT": "cdis-endpoints",
        "DEPLOYMENT_STRATEGY": "",
        "REPLICAS": "",
        "MEMORY_LIMIT": "",
        "READINESS_PROBE_URL": "",
        "SKIP_UPDATE_PROPERTIES": "false"
      },      
      {
        "DEPLOYMENT": "contract-analytical-service-endpoints",
        "DEPLOYMENT_STRATEGY": "",
        "REPLICAS": "",
        "MEMORY_LIMIT": "",
        "READINESS_PROBE_URL": "",
        "SKIP_UPDATE_PROPERTIES": "false"
      },
      {
        "DEPLOYMENT": "contract-client-service-endpoints",
        "DEPLOYMENT_STRATEGY": "",
        "REPLICAS": "",
        "MEMORY_LIMIT": "",
        "READINESS_PROBE_URL": "",
        "SKIP_UPDATE_PROPERTIES": "false"
      },
      {
        "DEPLOYMENT": "contract-locator-service-endpoints",
        "DEPLOYMENT_STRATEGY": "",
        "REPLICAS": "",
        "MEMORY_LIMIT": "",
        "READINESS_PROBE_URL": "",
        "SKIP_UPDATE_PROPERTIES": "false"
      },
      {
        "DEPLOYMENT": "contract-ubi-service-endpoints",
        "DEPLOYMENT_STRATEGY": "",
        "REPLICAS": "",
        "MEMORY_LIMIT": "",
        "READINESS_PROBE_URL": "",
        "SKIP_UPDATE_PROPERTIES": "false"
      },
      {
        "DEPLOYMENT": "cvs-endpoints",
        "DEPLOYMENT_STRATEGY": "",
        "REPLICAS": "",
        "MEMORY_LIMIT": "",
        "READINESS_PROBE_URL": "",
        "SKIP_UPDATE_PROPERTIES": "false"
      },
      {
        "DEPLOYMENT": "geographical-info-service-endpoints",
        "DEPLOYMENT_STRATEGY": "",
        "REPLICAS": "",
        "MEMORY_LIMIT": "",
        "READINESS_PROBE_URL": "",
        "SKIP_UPDATE_PROPERTIES": "false"
      },
      {
        "DEPLOYMENT": "message-authority-service-endpoints",
        "DEPLOYMENT_STRATEGY": "",
        "REPLICAS": "",
        "MEMORY_LIMIT": "",
        "READINESS_PROBE_URL": "",
        "SKIP_UPDATE_PROPERTIES": "false"
      },
      {
        "DEPLOYMENT": "product-distribution-service-endpoints",
        "DEPLOYMENT_STRATEGY": "",
        "REPLICAS": "",
        "MEMORY_LIMIT": "",
        "READINESS_PROBE_URL": "",
        "SKIP_UPDATE_PROPERTIES": "false"
      },
      {
        "DEPLOYMENT": "product-service-endpoints",
        "DEPLOYMENT_STRATEGY": "",
        "REPLICAS": "",
        "MEMORY_LIMIT": "",
        "READINESS_PROBE_URL": "",
        "SKIP_UPDATE_PROPERTIES": "false"
      }
    ]
  }
  '''
}
