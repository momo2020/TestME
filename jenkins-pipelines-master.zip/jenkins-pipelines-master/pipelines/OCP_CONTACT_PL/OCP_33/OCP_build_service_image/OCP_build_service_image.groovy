#!Groovy
import groovy.json.JsonSlurperClassic

final String[] sampleGAV = ['intact.soa.utility.address-service:address-service-endpoints:6.2.5.0.0.1.OCP-SNAPSHOT',
							'intact.soa.plpolicy.business.contract-verification-service:cvs-endpoints:6.2.5.0.0.1.OCP-SNAPSHOT',
							'intact.soa.plpolicy.business.contract-verification-service:cvs-webservice:6.2.3.MARS2017.HQQ-SNAPSHOT']

properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),

			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'GAV'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'OCP_BASE_PROJECT'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'NODE'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'JSON_FILE']
		])
])

if (!ONLY_REFRESH_CHOICES.toBoolean()) {
	def json = new JsonSlurperClassic().parseText(JSON_FILE)
	String[] TOKENS = GAV.split(':')
	String POM_GROUPID = TOKENS[0]
	String POM_ARTIFACTID = TOKENS[1]
	String POM_VERSION = TOKENS[2]

	String POM_RELEASEVERSION = POM_VERSION.replaceFirst('-SNAPSHOT$', '')
	String DOCKER_MUTABLE_PUSH_REGISTRY = "docker-mutable.iad.ca.inet:8463"
	def project
	def POM_DOCKERID

	node(NODE) {
		deleteDir()
		JAVA_HOME = tool 'ibm-java-linux-1.7-x86_64-71'
		MAVEN_HOME = tool 'maven-3.0.5'
		withEnv(["JAVA_HOME=${JAVA_HOME}", "MAVEN_HOME=${MAVEN_HOME}", "PATH=${JAVA_HOME}/bin:${MAVEN_HOME}/bin:/usr/local/bin:/usr/bin:/bin"]) {
			stage("retrieve project from json shared property") {
				project = retrieveProjectFromArtifactId(POM_ARTIFACTID, json)
				POM_DOCKERID = project.dockerId
			}

			stage('Prepare environment') {
				SHORT_TAG = "${POM_ARTIFACTID}:${POM_VERSION}-${OCP_BASE_PROJECT.toUpperCase()}"
				echo "POM_GROUPID=${POM_GROUPID}"
				echo "POM_ARTIFACTID=${POM_ARTIFACTID}"
				echo "POM_VERSION=${POM_VERSION}"
				echo "POM_RELEASEVERSION=${POM_RELEASEVERSION}"
				echo "JAVA_HOME=${JAVA_HOME}"
				echo "MAVEN_HOME=${MAVEN_HOME}"
				sh "java -version" // To force jdk download on the node
			}
			stage("Retrieve artifacts") {
				parallel(retrieveWar: {
					sh "mvn org.apache.maven.plugins:maven-dependency-plugin:2.10:copy -Dartifact=${POM_GROUPID}:${POM_ARTIFACTID}:${POM_VERSION}:war -DoutputDirectory=. -s ${MAVEN_SETTINGS} -Dmdep.stripVersion=true -q"
				}, retrieveDockerTgz: {
					sh "mvn org.apache.maven.plugins:maven-dependency-plugin:2.10:copy -Dartifact=${POM_GROUPID}:${POM_DOCKERID}:${POM_VERSION}:tar.gz:image-content -DoutputDirectory=. -s ${MAVEN_SETTINGS} -Dmdep.stripVersion=true -q"
				})
				
				//retrieve war only
				//sh "mvn org.apache.maven.plugins:maven-dependency-plugin:2.10:copy -Dartifact=${POM_GROUPID}:${POM_ARTIFACTID}:${POM_VERSION}:war -DoutputDirectory=. -s ${MAVEN_SETTINGS} -Dmdep.stripVersion=true -q"

			}
			stage("Extract docker content") {
				sh "tar -xzf ${POM_DOCKERID}-image-content.tar.gz --strip 1"
				sh "ls -lh"
			}
			stage("Build image") {
			//	load 'content/common/jenkins-build.properties'

				PUSH_NAME = "${DOCKER_MUTABLE_PUSH_REGISTRY}/intact/${SHORT_TAG}"

				echo "PUSH_NAME=${PUSH_NAME}"
				sh "docker build --pull --build-arg VERSION=${POM_VERSION} -t ${PUSH_NAME} ."
			}
			
			//stage("Build image") {
			//	sh "echo ${POM_VERSION}"
			//	sh "echo ls -lh"
			//}
			
			
			stage("Push image") {
				sh "docker push ${PUSH_NAME}"
				currentBuild.displayName = "#${BUILD_NUMBER} ${PUSH_NAME}"
			}
			
		}
	}
} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}

def retrieveProjectFromArtifactId(String artifactId, json) {
	def project
	boolean found = false
	for (def p : json.projects) {
		if (p.artifactId.equals(artifactId)) {
			project = p
			found = true
		}
	}
	if (!found) {
		echo "artifact + [${artifactId}] not found in shared library"
		assert false
	}
	return project
}
