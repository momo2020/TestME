#!Groovy
import intact.cluster.ocp.Cluster

final String REPOSITORY = 'mongo'
final String OCP_PROJECT = "${OCP_BASE_PROJECT}-${ENVIRONMENT}${BRANCH.empty ? '' : "-${BRANCH}"}"

targetClusterURL = Cluster.clusterByEnv(ENVIRONMENT).url
targetClusterCredentials = Cluster.clusterByEnv(ENVIRONMENT).credentialsId

currentBuild.displayName = "#${BUILD_NUMBER} ${REPOSITORY} -> ${OCP_PROJECT}"

node('linux') {
	deleteDir()
	JAVA_HOME = tool 'ibm-java-linux-1.7-x86_64-71'
	MAVEN_HOME = tool 'maven-3.0.5'
	withEnv(["JAVA_HOME=${JAVA_HOME}", "MAVEN_HOME=${MAVEN_HOME}", "PATH=${JAVA_HOME}/bin:${MAVEN_HOME}/bin:/usr/local/bin:/usr/bin:/bin"]) {
		wrap([$class: 'BuildUser']) {
			buildUserId = env.BUILD_USER_ID
		}

		stage("Load sources") {
			dir("templates") {
				git branch: 'master', credentialsId: '0afacacb-18d1-4b9a-a0db-d2c44495bae8', url: 'https://githubifc.iad.ca.inet/DevTools/openshift-templates.git'
			}
		}

		stage("Login to OCP") {
			withCredentials([usernamePassword(credentialsId: targetClusterCredentials, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')]) {
				sh "oc login ${targetClusterURL} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
				sh "oc project ${OCP_PROJECT}"
			}
		}

		stage("Process Intact template") {
			dir("templates") {
				sh "oc process -n ${OCP_PROJECT} -f intact-ocp-mongo-template.yaml -v PROJECT=${OCP_PROJECT} -o yaml > processed.yaml"
				sh 'cat processed.yaml'
				template = readFile 'intact-ocp-template.yaml'
				processed = readFile 'processed.yaml'
			}
		}

		stage("Deploy to OCP") {
			dir("templates") {
				sh "oc apply -n ${OCP_PROJECT} -f processed.yaml"
				sh "oc rollout history dc/${REPOSITORY} -n ${OCP_PROJECT}"
				// looks at the current deployment history and starts a deploy if it's not already deploying (if status is not Complete or Failed
				sh "if [[ `oc rollout history dc/${REPOSITORY} -n ${OCP_PROJECT} | tail -2` =~ Complete|Failed ]]; then oc deploy ${REPOSITORY} -n ${OCP_PROJECT} --latest; else echo deployment already on the way;  fi"
			}
		}

		stage("Waiting for deployment") {
			if (!SKIP_WAIT_FOR_OCP_DEPLOYMENT.toBoolean()) {
				timeout(time: 5, unit: 'MINUTES') {
					String rolloutHistory = ''
					waitUntil {
						sleep time: 10, unit: 'SECONDS'
						rolloutHistory = sh script: "oc rollout history dc/${REPOSITORY} -n ${OCP_PROJECT} | tail -2", returnStdout: true
						println('status : ' + rolloutHistory)
						return rolloutHistory.contains('Complete') || rolloutHistory.contains('Failed')
					}
				}
			} else {
				echo 'Skipping waiting for deployment'
			}
		}
	}
}
