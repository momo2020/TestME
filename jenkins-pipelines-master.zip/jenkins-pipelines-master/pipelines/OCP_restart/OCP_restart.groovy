#!Groovy
import intact.cluster.ocp.Cluster
import intact.elasticsearch.Logstash
import intact.elasticsearch.domain.Restart
import groovy.json.JsonSlurperClassic

def jsonFile = libraryResource 'intact/util/ocp/rqq.json'
def json = new JsonSlurperClassic().parseText(jsonFile)

properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			[$class            : 'ExtensibleChoiceParameterDefinition',
			 choiceListProvider: [$class: 'TextareaChoiceListProvider', addEditedValue: true, choiceListText: json.projects.artifactId.unique().join("\n"), whenToAdd: 'CompletedStable'],
			 description       : '',
			 editable          : true,
			 name              : 'REPOSITORY'
			],
			choice(choices: json.ocp_base_projects.join("\n"), description: '', name: 'OCP_BASE_PROJECT'),
			choice(choices: json.environments.join("\n"), description: '', name: 'ENVIRONMENT'),
			choice(choices: json.branches.join("\n"), description: '', name: 'BRANCH'),
			choice(choices: json.nodes.join("\n"), description: '', name: 'NODE'),
			booleanParam(defaultValue: true, description: '', name: 'RECORD_HISTORY'),
			booleanParam(defaultValue: false, description: 'check this if you do not want to wait for Openshift to deploy the new pod', name: 'SKIP_WAIT_FOR_OCP_DEPLOYMENT')
		])
])

if (!ONLY_REFRESH_CHOICES.toBoolean()) {

	final String OCP_PROJECT = "${OCP_BASE_PROJECT}-${ENVIRONMENT}${BRANCH.empty ? '' : "-${BRANCH}"}"

	targetClusterURL = Cluster.clusterByEnv(ENVIRONMENT).url
	targetClusterCredentials = Cluster.clusterByEnv(ENVIRONMENT).credentialsId
	currentBuild.displayName = "#${BUILD_NUMBER} ${REPOSITORY} -> ${OCP_PROJECT}"

	node(NODE) {
		stage("Login to OCP") {
			withCredentials([usernamePassword(credentialsId: targetClusterCredentials, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')]) {
				sh "oc login ${targetClusterURL} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
				sh "oc project ${OCP_PROJECT}"
			}
		}

		stage("restarting pod in OCP") {
			sh "oc deploy ${REPOSITORY} --latest -n ${OCP_PROJECT}"
		}

		stage("Record history") {
			if (RECORD_HISTORY.toBoolean()) {
				wrap([$class: 'BuildUser']) {
					buildUserId = env.BUILD_USER_ID
				}
				logstash = Logstash.instance
				restart = new Restart(REPOSITORY, OCP_PROJECT, env, buildUserId)
				logstash.add(restart)
			} else {
				echo 'skipping record history step'
			}
		}

		stage("Waiting for deployment") {
			if (!SKIP_WAIT_FOR_OCP_DEPLOYMENT.toBoolean()) {
				timeout(time: 5, unit: 'MINUTES') {
					String rolloutHistory = ''
					waitUntil {
						println('waiting 10 seconds')
						sleep time: 10, unit: 'SECONDS'
						println('lookingUp deployment status')
						rolloutHistory = sh script: "oc rollout history dc/${REPOSITORY} -n ${OCP_PROJECT} | tail -2", returnStdout: true
						println('status : ' + rolloutHistory)
						return rolloutHistory.contains('Complete') || rolloutHistory.contains('Failed')
					}
				}
			} else {
				echo 'Skipping waiting for deployment'
			}
		}
	}
} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}
