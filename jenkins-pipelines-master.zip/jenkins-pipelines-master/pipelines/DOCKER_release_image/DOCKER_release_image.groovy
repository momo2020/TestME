

node(NODE) {
    stage("Retrieve source image") {

    }
    stage("Tag release image") {

    }
    stage("Push release image") {

    }
}