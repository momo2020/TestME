#!Groovy
import intact.cluster.ocp.Cluster

properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'GAV'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'OCP_BASE_PROJECT'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'ENVIRONMENT'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'BRANCH'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'NODE'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'POM_DOCKERID']
		])
])

if (!ONLY_REFRESH_CHOICES.toBoolean()) {

	OCP_PROJECT = "${OCP_BASE_PROJECT}-${ENVIRONMENT}${BRANCH.empty ? '' : "-${BRANCH}"}"
	TOKENS = GAV.split(':')
	POM_GROUPID = TOKENS[0]
	POM_ARTIFACTID = TOKENS[1]
	POM_VERSION = TOKENS[2]
	dockerGroup = "docker-group.iad.ca.inet:8473"

	currentBuild.displayName = "#${BUILD_NUMBER} ${POM_ARTIFACTID}:${POM_VERSION} -> ${OCP_PROJECT}"

	targetClusterURL = Cluster.clusterByEnv(ENVIRONMENT).url
	targetClusterCredentials = Cluster.clusterByEnv(ENVIRONMENT).credentialsId
	def project

	node(NODE) {
		deleteDir()
		JAVA_HOME = tool 'ibm-java-linux-1.7-x86_64-71'
		MAVEN_HOME = tool 'maven-3.0.5'
		withEnv(["JAVA_HOME=${JAVA_HOME}", "MAVEN_HOME=${MAVEN_HOME}", "PATH=${JAVA_HOME}/bin:${MAVEN_HOME}/bin:/usr/local/bin:/usr/bin:/bin"]) {

			stage('Prepare environment') {
				sh "java -version" // To force jdk download on the node
			}
			stage("Retrieve properties zip") {
				sh "mvn org.apache.maven.plugins:maven-dependency-plugin:2.10:copy -Dartifact=${POM_GROUPID}:${POM_DOCKERID}:${POM_VERSION}:zip:configmap -DoutputDirectory=. -s ${MAVEN_SETTINGS} -Dmdep.stripVersion=true -q"
				sh "unzip ${POM_DOCKERID}-configmap.zip"
			}
		}
		stage('Create configmap') {
			final String configMapName = "${POM_ARTIFACTID}.properties"
			final String configMapFile = "src/configmap/${OCP_BASE_PROJECT}/${ENVIRONMENT}${BRANCH.empty ? '' : "-${BRANCH}"}/configmap.properties"
			final String configMapFileAlternatePath = "src/configmap/${ENVIRONMENT}${BRANCH.empty ? '' : "-${BRANCH}"}/configmap.properties"

			// if the configmap is neither found in the usual path or in the alternate (deprecated) one, we create an empty one
			if (fileExists("${configMapFile}")) {
				sh("cp ${configMapFile} configmap.properties")
			} else if (fileExists("${configMapFileAlternatePath}")) {
				println("${configMapFile} file is not found, using old path not containing the ocp_project as root")
				println("consider refactoring the source code by moving the properties file in your own ocp_project as root")
				sh("cp ${configMapFileAlternatePath} configmap.properties")
			} else {
				println("WARNING : configmap.properties not found in ${POM_DOCKERID}-configmap.zip. An empty file will be created")
				sh("touch configmap.properties")
			}
			// we add the configMap version in the last line in order to retrieve it in the containter-info (in the setenv.sh of the dockerBaseImage)
			sh "echo -e '\r\nCONFIGMAP_GAV=${POM_GROUPID}:${POM_DOCKERID}:${POM_VERSION}' >> configmap.properties"
			withCredentials([usernamePassword(credentialsId: targetClusterCredentials, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')]) {
				sh "oc login ${targetClusterURL} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
			}
			sh "oc project ${OCP_PROJECT}"
			sh "oc create configmap ${configMapName} -n ${OCP_PROJECT} --from-file=configmap.properties --dry-run=true -o yaml > configForApply.yaml"
			sh "oc apply -n ${OCP_PROJECT} -f configForApply.yaml"
			sh "cat configForApply.yaml"
		}
	}
} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}
