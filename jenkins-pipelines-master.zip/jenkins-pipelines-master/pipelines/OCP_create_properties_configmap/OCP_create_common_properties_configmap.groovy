#!Groovy
import intact.cluster.ocp.Cluster
import groovy.json.JsonSlurperClassic

def jsonFile = libraryResource 'intact/util/ocp/rqq.json'
def json = new JsonSlurperClassic().parseText(jsonFile)

properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			choice(choices: json.ocp_base_projects.join("\n"), description: '', name: 'OCP_BASE_PROJECT'),
			choice(choices: json.environments.join("\n"), description: '', name: 'ENVIRONMENT'),
			choice(choices: json.branches.join("\n"), description: '', name: 'BRANCH'),
			string(defaultValue: '0.0.1-SNAPSHOT', description: '', name: 'COMMON_CONFIGMAP_VERSION'),
			string(defaultValue: 'node-2020-linux-lab-002', description: '', name: 'NODE'),
		])
])

if (!ONLY_REFRESH_CHOICES.toBoolean()) {

	OCP_PROJECT = "${OCP_BASE_PROJECT}-${ENVIRONMENT}${BRANCH.empty ? '' : "-${BRANCH}"}"
	final String GAV = "intact.openshift.common:common-configmap-${OCP_BASE_PROJECT}:${COMMON_CONFIGMAP_VERSION}"
	POM_GROUPID = 'intact.openshift.common'
	POM_ARTIFACTID = "common-configmap-${OCP_BASE_PROJECT}"
	POM_VERSION = "${COMMON_CONFIGMAP_VERSION}"
	dockerGroup = "docker-group.iad.ca.inet:8473"

	currentBuild.displayName = "#${BUILD_NUMBER} ${POM_ARTIFACTID}:${POM_VERSION} -> ${OCP_PROJECT}"

	targetClusterURL = Cluster.clusterByEnv(ENVIRONMENT).url
	targetClusterCredentials = Cluster.clusterByEnv(ENVIRONMENT).credentialsId
	def project

	node(NODE) {
		deleteDir()
		JAVA_HOME = tool 'ibm-java-linux-1.7-x86_64-71'
		MAVEN_HOME = tool 'maven-3.0.5'
		withEnv(["JAVA_HOME=${JAVA_HOME}", "MAVEN_HOME=${MAVEN_HOME}", "PATH=${JAVA_HOME}/bin:${MAVEN_HOME}/bin:/usr/local/bin:/usr/bin:/bin"]) {

			stage('Prepare environment') {
				sh "java -version" // To force jdk download on the node
			}
			stage("Retrieve properties zip") {
				sh "mvn org.apache.maven.plugins:maven-dependency-plugin:2.10:copy -Dartifact=${POM_GROUPID}:${POM_ARTIFACTID}:${POM_VERSION}:zip:common-configmap -DoutputDirectory=. -s ${MAVEN_SETTINGS} -Dmdep.stripVersion=true -q"
				sh "unzip ${POM_ARTIFACTID}-common-configmap.zip"
			}
		}
		stage('Create configmap') {
			configMapName = "configmap-common.properties"
			configMapFile = "${OCP_BASE_PROJECT}/${ENVIRONMENT}${BRANCH.empty ? '' : "/${BRANCH}"}/configmap-common.properties"
			println("configMapFile == ${configMapFile}")
			// we add the configMap-common version in the last line in order to retrieve it in the containter-info (in the setenv.sh of the dockerBaseImage)
			sh "echo -e '\r\nCONFIGMAP_COMMON_GAV=${POM_GROUPID}:${POM_ARTIFACTID}:${POM_VERSION}' >> ${OCP_BASE_PROJECT}/${ENVIRONMENT}${BRANCH.empty ? '' : "/${BRANCH}"}/configmap-common.properties"
			withCredentials([usernamePassword(credentialsId: targetClusterCredentials, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')]) {
				sh "oc login ${targetClusterURL} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
			}
			sh "oc project ${OCP_PROJECT}"
			sh "oc create configmap ${configMapName} -n ${OCP_PROJECT} --from-file=${configMapFile} --dry-run=true -o yaml > configForApply.yaml"
			sh "oc apply -n ${OCP_PROJECT} -f configForApply.yaml"
			sh "cat configForApply.yaml"
		}
	}
} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}
