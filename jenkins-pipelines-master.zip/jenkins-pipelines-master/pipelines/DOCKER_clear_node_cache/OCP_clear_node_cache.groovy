#!Groovy
def nodes = 'node-2020-linux-lab-002,node-2020-linux-lab-001'

properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			[$class            : 'ExtensibleChoiceParameterDefinition',
			 choiceListProvider: [$class: 'TextareaChoiceListProvider', addEditedValue: true, choiceListText: nodes, whenToAdd: 'CompletedStable'],
			 description       : '',
			 editable          : true,
			 name              : 'NODE'
			]
		]),
	pipelineTriggers([
		cron('H 0 * * *')
	])
])

if (!ONLY_REFRESH_CHOICES.toBoolean()) {

	for (def currentNode : NODE.tokenize(',')) {
		node(currentNode) {
			echo "PROCESSING ${currentNode}"
			stage("Remove all docker container") {
				def result = sh(script: "docker ps -f \'status=exited\' -qa", returnStdout: true)

				//Removing duplicates from the list
				def containerTable = result.tokenize('\n').unique()
				echo "${containerTable.size()} CONTAINERS FOUND IN CACHE"

				if (containerTable.size() > 0) {
					sh(script: "docker rm -vf ${containerTable.join(' ')}", returnStatus: true)
					echo "DELETE COMPLETED!"
				} else {
					echo 'Skipping remove all docker container stage because "docker ps -f \'status=exited\' -qa" didn\'t return anything'
				}
			}

			stage("Remove all docker images in cache") {
				def images = sh(script: "docker images -qa", returnStdout: true)

				//Removing duplicates from the list
				def imagesTable = images.tokenize('\n').unique()
				echo "${imagesTable.size()} IMAGES FOUND IN CACHE"
				//echo "Images: ${imagesTable.join(' ')}"

				if (imagesTable.size() > 0) {
					// returnStatus: true is needed to bypass 'Error response from daemon: No such image'
					sh(script: "docker rmi -f ${imagesTable.join(' ')}", returnStatus: true)
					echo "DELETE COMPLETED!"
				} else {
					echo 'Skipping images deletion because "docker images -qa" didn\'t return anything'
				}
			}
		}
	}
	currentBuild.displayName = "#${BUILD_NUMBER} cache cleared"
} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}
