#!Groovy
import intact.cluster.ocp.Cluster
import groovy.json.JsonSlurperClassic

import intact.elasticsearch.Logstash
import intact.elasticsearch.domain.Promotion

def jsonFile = libraryResource 'intact/util/ocp/rqq.json'
def json = new JsonSlurperClassic().parseText(jsonFile)

PULL_REGISTRY = "docker-groupe.iad.ca.inet:8473"
PUSH_REGISTRY = "docker-mutable.iad.ca.inet:8463"

properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			[$class            : 'ExtensibleChoiceParameterDefinition',
			 choiceListProvider: [$class: 'TextareaChoiceListProvider', addEditedValue: true, choiceListText: json.projects.artifactId.unique().join("\n"), whenToAdd: 'CompletedStable'],
			 description       : '',
			 editable          : true,
			 name              : 'DEPLOYMENT'
			],
			choice(choices: json.ocp_base_projects.join("\n"), description: '', name: 'ORIGIN_OCP_BASE_PROJECT'),
			choice(choices: json.environments.join("\n"), description: '', name: 'ORIGIN_ENVIRONMENT'),
			choice(choices: json.branches.join("\n"), description: '', name: 'ORIGIN_BRANCH'),
			choice(choices: json.ocp_base_projects.join("\n"), description: '', name: 'DESTINATION_OCP_BASE_PROJECT'),
			choice(choices: json.environments.join("\n"), description: '', name: 'DESTINATION_ENVIRONMENT'),
			choice(choices: json.branches.join("\n"), description: '', name: 'DESTINATION_BRANCH'),
			choice(choices: json.nodes.join("\n"), description: '', name: 'NODE'),
			booleanParam(defaultValue: false, description: 'check this is you want to SKIP the update the configurations files and SKIP update the configMap in ocp as well', name: 'SKIP_UPDATE_PROPERTIES'),
			string(defaultValue: '', description: '', name: 'REPLICAS'),
			booleanParam(defaultValue: true, description: '', name: 'RECORD_HISTORY'),
			booleanParam(defaultValue: false, description: 'check this if you do not want to wait for Openshift to deploy the new pod', name: 'SKIP_WAIT_FOR_OCP_DEPLOYMENT'),
			booleanParam(defaultValue: false, description: 'check this if you do not want to call the SOAP UI test at the end of the promote', name: 'SKIP_TEST'),
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'DEPLOYMENT_STRATEGY'],
			[$class: 'WHideParameterDefinition', defaultValue: 'master', description: '', name: 'TEMPLATE_BRANCH'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'READINESS_PROBE_URL'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'READINESS_PROBE_INITIAL_DELAY'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'LIVENESS_PROBE_INITIAL_DELAY'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'BATCH_DESCRIPTION'],
			[$class: 'WHideParameterDefinition', defaultValue: '', description: '', name: 'DESCRIPTION']
		])
])


final String OCP_PROJECT_ORIGIN = "${ORIGIN_OCP_BASE_PROJECT}-${ORIGIN_ENVIRONMENT}${ORIGIN_BRANCH.empty ? '' : "-${ORIGIN_BRANCH}"}"
final String OCP_PROJECT_DESTINATION = "${DESTINATION_OCP_BASE_PROJECT}-${DESTINATION_ENVIRONMENT}${DESTINATION_BRANCH.empty ? '' : "-${DESTINATION_BRANCH}"}"

destinationOpenshiftSuffix = Cluster.clusterByEnv(DESTINATION_ENVIRONMENT).suffix

project = retrieveProjectFromArtifactId(DEPLOYMENT, json)

deploymentStrategy = !DEPLOYMENT_STRATEGY.isEmpty() ? DEPLOYMENT_STRATEGY : project.deployment_strategy
replicas = !REPLICAS.isEmpty() ? REPLICAS : project.replicas.get(DESTINATION_BRANCH).get(DESTINATION_ENVIRONMENT)
livenessProbeInitialDelay = !LIVENESS_PROBE_INITIAL_DELAY.isEmpty() ? LIVENESS_PROBE_INITIAL_DELAY : project.livenessProbeInitialDelay
readinessProbeUrl = !READINESS_PROBE_URL.isEmpty() ? READINESS_PROBE_URL : project.readinessProbeUrl
readinessProbeInitialDelay = !READINESS_PROBE_INITIAL_DELAY.isEmpty() ? READINESS_PROBE_INITIAL_DELAY : project.readinessProbeInitialDelay
groupId = project.groupId
artifactId = project.artifactId
def projectVersion
def configMapVersion
artifactType = project.artifactType
String imageId
String digestId
final String ORGANIZATION = json.organization[0].toString()

String memoryLimit = "Not defined"
String memoryRequest = "Not defined"
String cpuLimit = "Not defined"
String cpuRequest = "Not defined"

if (!ONLY_REFRESH_CHOICES.toBoolean()) {
	node(NODE) {
		currentBuild.displayName = "#${BUILD_NUMBER} ${BATCH_DESCRIPTION} ${DEPLOYMENT} : ${OCP_PROJECT_ORIGIN} -> ${OCP_PROJECT_DESTINATION}"
		deleteDir()
		JAVA_HOME = tool 'ibm-java-linux-1.7-x86_64-71'
		MAVEN_HOME = tool 'maven-3.0.5'
		withEnv([
			"JAVA_HOME=${JAVA_HOME}",
			"MAVEN_HOME=${MAVEN_HOME}",
			"PATH=${JAVA_HOME}/bin:${MAVEN_HOME}/bin:/usr/local/bin:/usr/bin:/bin"
		]) {
			wrap([$class: 'BuildUser']) { buildUserId = env.BUILD_USER_ID }
			stage('checking user permission') {
				if (json.security.integrator) {
					// Check if the user has permission to deploy into the protected environment
					if (json.security.protected_env.contains(DESTINATION_ENVIRONMENT) && !json.security.integrator.contains(buildUserId)) {
						echo "The current user ${buildUserId} cannot deploy in ${DESTINATION_ENVIRONMENT}"
						echo "This event has been logged into the system. For more information, please contact an integrator."
						echo "Contact list:\n${json.security.integrator.join('\n')}"
						assert false
					} else {
						echo "Access granted, welcome ${buildUserId}! You can deploy in ${DESTINATION_ENVIRONMENT}"
					}
				} else {
					echo "Skipping permission check: No security value in the shared libraries"
					assert false
				}
			}

			stage("Retrieve origin deployment & image") {
				logToOCP(ORIGIN_ENVIRONMENT, OCP_PROJECT_ORIGIN)
				projectVersion = retrieveOCPLabelFromDeploymentConfig('projectVersion', artifactId, OCP_PROJECT_ORIGIN)
				projectLongVersion = retrieveOCPLabelFromDeploymentConfig('projectLongVersion', artifactId, OCP_PROJECT_ORIGIN)
				configMapVersion = retrieveOCPLabelFromDeploymentConfig('configMapVersion', artifactId, OCP_PROJECT_ORIGIN)
				configMapLongVersion = retrieveOCPLabelFromDeploymentConfig('configMapLongVersion', artifactId, OCP_PROJECT_ORIGIN)

				out = sh script: "oc get dc/${DEPLOYMENT} -n ${OCP_PROJECT_ORIGIN} -o yaml | grep image: | sed 's/^.\\+image: *//' | sed 's/ \\+//'", returnStdout: true

				originImage = out.replace("\n", "").replace("\r", "")
				originImageName = originImage.replaceFirst("^[^/]+/", "")
				repository = originImageName.replaceFirst(":.+", "").replaceFirst('^intact/', '')
				service = repository.replaceAll('-', '')
				if (service.length() > 24) {
					service = service.substring(0, 24)
				}
				originTag = originImageName.replaceFirst("[^:]+:", "")
				baseTag = originTag.replaceFirst("-.+\$", "")
				destinationTag = "${baseTag}-${DESTINATION_ENVIRONMENT.toUpperCase()}-${DESTINATION_OCP_BASE_PROJECT.toUpperCase()}"
				destinationImage = "${PUSH_REGISTRY}/intact/${repository}:${destinationTag}"
			}

			stage("deploy properties") {
				if (!SKIP_UPDATE_PROPERTIES.toBoolean()) {
					groupId = project.groupId
					artifactId = project.artifactId
					artifactType = project.artifactType
					dockerId = project.dockerId
					def GAV = [
						groupId,
						artifactId,
						configMapLongVersion,
						artifactType
					].join(':')
					build job: 'OCP_014_create_properties_configmap', parameters: [
						string(name: 'GAV', value: GAV),
						string(name: 'OCP_BASE_PROJECT', value: DESTINATION_OCP_BASE_PROJECT),
						string(name: 'ENVIRONMENT', value: DESTINATION_ENVIRONMENT),
						string(name: 'BRANCH', value: DESTINATION_BRANCH),
						string(name: 'NODE', value: NODE),
						string(name: 'POM_DOCKERID', value: dockerId)
					]
				} else {
					echo 'Skipping updateProperties, but we still have to retrieve the configMapVersion from what is already in Openshift'
					logToOCP(DESTINATION_ENVIRONMENT, OCP_PROJECT_DESTINATION)
					configMapVersion = retrieveOCPLabelFromDeploymentConfig('configMapVersion', artifactId, OCP_PROJECT_DESTINATION)
					configMapLongVersion = retrieveOCPLabelFromDeploymentConfig('configMapLongVersion', artifactId, OCP_PROJECT_DESTINATION)
				}
			}

			stage("Tag") {
				String digest = sh script: "docker pull ${originImage}", returnStdout: true

				digest = digest.substring(digest.indexOf("Digest: "))
				digest = digest.substring(0, digest.indexOf('\n'))
				digestId = digest.replace('Digest: ', '')

				sh "docker tag ${originImage} ${destinationImage}"
				imageId = sh script: "docker inspect -f '{{.ID}}' ${destinationImage}", returnStdout: true
				imageId = imageId.replaceFirst('^sha256:', '').trim()
			}

			stage("Push destination image") {
				sh "docker push ${destinationImage}"
				sleep time: 10, unit: 'SECONDS'
			}

			stage("Process Intact Template") {
				dir("templates") {
					final String UUID = UUID.randomUUID().toString()
					def templateParameters = []
					templateParameters << "REPOSITORY=${repository}"
					templateParameters << "GROUPID=${groupId}"
					templateParameters << "ARTIFACTID=${artifactId}"
					templateParameters << "PROJECT_VERSION=${projectVersion}"
					templateParameters << "CONFIGMAP_VERSION=${configMapVersion}"
					templateParameters << "PROJECT_LONGVERSION=${projectLongVersion}"
					templateParameters << "CONFIGMAP_LONGVERSION=${configMapLongVersion}"
					templateParameters << "TAG=${destinationTag}"
					templateParameters << "ENVIRONMENT=${DESTINATION_ENVIRONMENT}"
					templateParameters << "BRANCH=${DESTINATION_BRANCH}"
					templateParameters << "IMAGE_ID=${imageId}"
					templateParameters << "DIGEST_ID=${digestId}"
					templateParameters << "SERVICE=${service}"
					templateParameters << "PROJECT=${OCP_PROJECT_DESTINATION}"
					templateParameters << "REPLICAS=${replicas}"
					templateParameters << "DEPLOYMENT_STRATEGY=${deploymentStrategy}"
					templateParameters << "LIVENESS_PROBE_INITIAL_DELAY=${livenessProbeInitialDelay}"
					templateParameters << "READINESS_PROBE_URL=${readinessProbeUrl}"
					templateParameters << "READINESS_PROBE_INITIAL_DELAY=${readinessProbeInitialDelay}"
					templateParameters << "OPENSHIFT_SUFFIX=${destinationOpenshiftSuffix}"
					templateParameters << "UUID=${UUID}"
					templateParameters << "ORGANIZATION=${ORGANIZATION}"

					if (hasCommonProperties(OCP_PROJECT_DESTINATION)) {
						git branch: 'common-properties', credentialsId: '0afacacb-18d1-4b9a-a0db-d2c44495bae8', url: 'https://githubifc.iad.ca.inet/DevTools/openshift-templates.git'
					} else {
						git branch: TEMPLATE_BRANCH, credentialsId: '0afacacb-18d1-4b9a-a0db-d2c44495bae8', url: 'https://githubifc.iad.ca.inet/DevTools/openshift-templates.git'
					}
					// TODO this is temporary and soooo ugly, until we have podLimit in each environment
					if (limitWhiteList(OCP_PROJECT_DESTINATION)){
						String MEMORY_SIZE = project.memory_limit_size
						if (MEMORY_SIZE == null || !json.memory_sizes.containsKey(MEMORY_SIZE)) {
							println("MEMORY_SIZE ${MEMORY_SIZE} is not valid. will use default memory limits")
							MEMORY_SIZE = 'default'
						}
						memoryRequest = json.memory_sizes.get(MEMORY_SIZE).get("memoryRequest")
						memoryLimit = json.memory_sizes.get(MEMORY_SIZE).get("memoryLimit")
						println("MEMORY_SIZE = ${MEMORY_SIZE}")
						println("memoryRequest is now ${memoryRequest}")
						println("memoryLimit is now ${memoryLimit}")

						String CPU_SIZE = project.cpu_limit_size
						if (CPU_SIZE == null || !json.cpu_sizes.containsKey(CPU_SIZE)) {
							println("CPU_SIZE ${CPU_SIZE} is not valid. will use default cpu limits")
							CPU_SIZE = 'default'
						}
						cpuRequest = json.cpu_sizes.get(CPU_SIZE).get("cpuRequest")
						cpuLimit = json.cpu_sizes.get(CPU_SIZE).get("cpuLimit")
						println("CPU_SIZE = ${CPU_SIZE}")
						println("cpuRequest is now ${cpuRequest}")
						println("cpuLimit is now ${cpuLimit}")

						templateParameters << "MEMORY_REQUEST=${memoryRequest}"
						templateParameters << "MEMORY_LIMIT=${memoryLimit}"
						templateParameters << "CPU_REQUEST=${cpuRequest}"
						templateParameters << "CPU_LIMIT=${cpuLimit}"

						sh "oc process -n ${OCP_PROJECT_DESTINATION} -f intact-ocp-template-limits.yaml -v ${templateParameters.join(',')} -o yaml > processed.yaml"
					} else {
						sh "oc process -n ${OCP_PROJECT_DESTINATION} -f intact-ocp-template.yaml -v ${templateParameters.join(',')} -o yaml > processed.yaml"
					}
					sh 'cat processed.yaml'
					template = readFile 'intact-ocp-template.yaml'
					processed = readFile 'processed.yaml'
					stash name: 'processed', includes: 'processed.yaml'
				}
			}

			stage("Deploy to OCP") {
				dir("templates") {
					logToOCP(DESTINATION_ENVIRONMENT, OCP_PROJECT_DESTINATION)
					sh "oc apply -n ${OCP_PROJECT_DESTINATION} -f processed.yaml"
					sh "oc rollout history dc/${repository} -n ${OCP_PROJECT_DESTINATION}"
					// looks at the current deployment history and starts a deploy if it's not already deploying (if status is not Complete or Failed
					sh "if [[ `oc rollout history dc/${repository} -n ${OCP_PROJECT_DESTINATION} | tail -2` =~ Complete|Failed ]]; then oc deploy ${repository} --latest -n ${OCP_PROJECT_DESTINATION}; else echo deployment already on the way;  fi"
				}
			}

			stage("Record history") {
				String description = DESCRIPTION as String
				String batch_description = BATCH_DESCRIPTION as String
				if (RECORD_HISTORY.toBoolean()) {
					logstash = Logstash.instance
					promotion = new Promotion(
						PULL_REGISTRY, PUSH_REGISTRY, originTag, destinationTag,
						repository, imageId, digestId, OCP_PROJECT_ORIGIN, OCP_PROJECT_DESTINATION,
						template, processed, groupId, artifactId, projectVersion,
						projectLongVersion, configMapVersion, configMapLongVersion,
						livenessProbeInitialDelay, readinessProbeUrl,
						readinessProbeInitialDelay, replicas, deploymentStrategy,
						memoryLimit, memoryRequest, cpuLimit, cpuRequest, description, batch_description, env, buildUserId
					)
					logstash.add(promotion)
				} else {
					echo 'skipping record history step'
				}
			}

			stage("Waiting for deployment") {
				if (!SKIP_WAIT_FOR_OCP_DEPLOYMENT.toBoolean()) {
					timeout(time: 10, unit: 'MINUTES') {
						String rolloutHistory = ''
						waitUntil {
							sleep time: 10, unit: 'SECONDS'
							rolloutHistory = sh script: "oc rollout history dc/${repository} -n ${OCP_PROJECT_DESTINATION} | tail -2", returnStdout: true
							println('status : ' + rolloutHistory)
							return rolloutHistory.contains('Complete') || rolloutHistory.contains('Failed')
						}
					}
				} else {
					echo 'Skipping waiting for deployment'
				}
			}
		}
	}

	node(NODE) {
		stage('write processed.yaml in git') {
			unstash 'processed'
			dir('processed') {
				withCredentials([usernamePassword(credentialsId: '0afacacb-18d1-4b9a-a0db-d2c44495bae8', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
					git branch: 'master', credentialsId: '0afacacb-18d1-4b9a-a0db-d2c44495bae8', url: 'https://githubifc.iad.ca.inet/DevTools/openshift-processed-templates.git'
					String processedPath = "${DESTINATION_OCP_BASE_PROJECT}/${DESTINATION_ENVIRONMENT}${DESTINATION_BRANCH.empty ? '' : "/${DESTINATION_BRANCH}"}/${artifactId}/"
					sh "mkdir -p ${processedPath}"
					sh "cp ../processed.yaml ${processedPath}"
					String status = sh script: 'git status', returnStdout: true
					if (!status.contains('nothing to commit')) {
						sh 'git add *'
						sh "git commit -m \'projectVersion : ${projectLongVersion}, configMapVersion : ${configMapLongVersion}\'"
						sh "git push --set-upstream https://${GIT_USERNAME}:${GIT_PASSWORD.replace('$', '\\$')}@githubifc.iad.ca.inet/DevTools/openshift-processed-templates.git master"
					} else {
						echo 'processed.yaml has not changed since last deploy, nothing to commit'
					}
				}
			}
		}
		if (json.soapui_tests) {
			stage('calling SOAP UI test') {
				// check if the SKIP_TEST checkbox is checked
				if (!SKIP_TEST.toBoolean()) {
					// load the environment whitelist
					def environmentWhitelist = json.soapui_tests.environments

					// fetch the soap UI test in the list
					String testJob = json.soapui_tests.soapui_test_builds.get(0)

					// check if the project needs to be tested
					boolean launchSoapUITest = project.launchSoapUITest.toBoolean()

					if (launchSoapUITest) {
						String environment = DESTINATION_ENVIRONMENT
						echo "The soap UI tests environments found in the shared library = ${environmentWhitelist}"
						if (environmentWhitelist.contains(environment)) {
							echo "DESTINATION_ENVIRONMENT ${environment} has been found in the whitelist" // DEBUG

							// May or may not be relevant anymore
							if (DESTINATION_ENVIRONMENT.equals('uat')) {
								environment = DESTINATION_ENVIRONMENT.capitalize()
							}
							echo "${DEPLOYMENT} is tagged to run a test and ${environment} was found in the whitelist. We will now make an asynchronous call to the test build"
							build job: 'remote_build_SOAPUI_tests', parameters: [
								string(name: 'REMOTE_JOB_NAME', value: "${testJob}")
							], wait: false
						} else {
							echo "${environment} environment is not in the whitelist. Skipping SOAP UI test call"
						}
					} else {
						echo "Skipping SOAP UI test because ${DEPLOYMENT} isn't tagged to run a test"
					}
				} else {
					echo "Skipping SOAP UI test because SKIP_TEST has been checked"
				}
			}
		} else {
			echo "Skipping SOAP UI test because soapui_tests doesn't exist in the shared library"
		}
	}
} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}

boolean limitWhiteList(String OCP_PROJECT_DESTINATION) {
	def projectsHavingLimits = []
	projectsHavingLimits << "rqq-dev"
	projectsHavingLimits << "rqq-intg"
	projectsHavingLimits << "rqq-intg-bacon"
	projectsHavingLimits << "rqq-uat"
	projectsHavingLimits << "rqq-prep"
	projectsHavingLimits << "contactpl-dev-d16"
	projectsHavingLimits << "contactpl-intg-d16"
	projectsHavingLimits << "contactpl-uat-d16"
	projectsHavingLimits << "contactpl-dev-maint"
	projectsHavingLimits << "contactpl-intg-maint"
	projectsHavingLimits << "contactpl-uat-maint"
	projectsHavingLimits << "contactpl-dev-d18"
	projectsHavingLimits << "contactpl-prep"
	projectsHavingLimits << "contactpl-prep-d16"
	projectsHavingLimits << "contactpl-uat-dhtrg"
	projectsHavingLimits << "contactpl-dev-wa"
	projectsHavingLimits << "contactpl-intg-wa"
	projectsHavingLimits << "contactpl-uat-wa"

	return projectsHavingLimits.contains((OCP_PROJECT_DESTINATION))
}

def retrieveProjectFromArtifactId(String artifactId, json) {
	def project
	boolean found = false
	for (def p : json.projects) {
		if (p.artifactId.equals(artifactId)) {
			project = p
			found = true
		}
	}
	if (!found) {
		echo "artifact + [${artifactId}] not found in shared library"
		assert false
	}
	return project
}

String retrieveOCPLabelFromDeploymentConfig(
	final String LABEL_NAME, final String DEPLOYMENT, final String OCP_PROJECT) {
	sh "if [[ `oc get dc/${DEPLOYMENT} -n ${OCP_PROJECT} | tail -1 | cut -f 1 -d ' ' ` == '${DEPLOYMENT}' ]]; then echo FOUND; else echo Deployment ${DEPLOYMENT} not found in ocp project; exit 1;  fi"
	String labelValue = sh script: "oc get dc/${DEPLOYMENT} -n ${OCP_PROJECT} -o yaml | grep ${LABEL_NAME}: | sed 's/.*${LABEL_NAME}://'", returnStdout: true
	labelValue.trim()
}

void logToOCP(final String OCP_ENV, final String OCP_PROJECT) {
	String ocpClusterURL = Cluster.clusterByEnv(OCP_ENV).url
	String ocpClusterCredentials = Cluster.clusterByEnv(OCP_ENV).credentialsId
	withCredentials([
		usernamePassword(credentialsId: ocpClusterCredentials, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
	]) {
		sh "oc login ${ocpClusterURL} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
		sh "oc project ${OCP_PROJECT}"
	}
}

/**
 * Checks if there is a configmap-common.properties in the ocp project
 */
boolean hasCommonProperties(final String OCP_PROJECT){
	def configMaps = sh script: "oc get configmaps -n ${OCP_PROJECT} ", returnStdout: true
	println("configMaps == ${configMaps}")
	return configMaps.contains('configmap-common.properties')
}
