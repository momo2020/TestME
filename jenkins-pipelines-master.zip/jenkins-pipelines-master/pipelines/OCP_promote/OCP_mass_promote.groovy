#!Groovy
package OCP_build_create_deploy

import groovy.json.JsonSlurperClassic

//@See https://githubifc.iad.ca.inet/DevTools/jenkins-pipeline-shared-librairies
def jsonFile = libraryResource 'intact/util/ocp/rqq.json'
def jsonRqq = new JsonSlurperClassic().parseText(jsonFile)

properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'Check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			booleanParam(defaultValue: false, description: 'Check this if you do not want to call the SOAP UI test at the end of the promote', name: 'SKIP_TEST'),
			[$class: 'TextParameterDefinition', defaultValue: getTemplate(), description: '', name: 'JSON'],
			[$class: 'WHideParameterDefinition', defaultValue: 'mtl2020-docker', description: '', name: 'NODE'],
			[$class: 'WHideParameterDefinition', defaultValue: 'master', description: '', name: 'TEMPLATE_BRANCH']
		])
])

if (!ONLY_REFRESH_CHOICES.toBoolean()) {
	def json = new JsonSlurperClassic().parseText(JSON)
	boolean shouldRunTest = false
	stage('validate input') {
		assert json instanceof Map
		assert !json.deploymentInfo.ORIGIN_OCP_BASE_PROJECT.isEmpty(): 'ORIGIN_OCP_BASE_PROJECT in json file is empty'
		assert !json.deploymentInfo.DESTINATION_OCP_BASE_PROJECT.isEmpty(): 'DESTINATION_OCP_BASE_PROJECT in json file is empty'
		assert !json.deploymentInfo.ORIGIN_ENVIRONMENT.isEmpty(): 'ORIGIN_ENVIRONMENT in json file is empty'
		assert !json.deploymentInfo.DESTINATION_ENVIRONMENT.isEmpty(): 'DESTINATION_ENVIRONMENT in json file is empty'
		assert json.projects instanceof List
	}

	String description = json.deploymentInfo.DESCRIPTION
	if (!description.isEmpty()) {
		currentBuild.displayName = "#${BUILD_NUMBER} " + description
	}

	String ORIGIN_OCP_BASE_PROJECT = json.deploymentInfo.ORIGIN_OCP_BASE_PROJECT
	String DESTINATION_OCP_BASE_PROJECT = json.deploymentInfo.DESTINATION_OCP_BASE_PROJECT
	String ORIGIN_ENVIRONMENT = json.deploymentInfo.ORIGIN_ENVIRONMENT
	String DESTINATION_ENVIRONMENT = json.deploymentInfo.DESTINATION_ENVIRONMENT
	String ORIGIN_BRANCH = json.deploymentInfo.ORIGIN_BRANCH
	String DESTINATION_BRANCH = json.deploymentInfo.DESTINATION_BRANCH
	int THRESHOLD = Integer.parseInt(json.deploymentInfo.THRESHOLD)

	stage('deploy them all') {
		def projects = json.projects
		def batch
		int batchNumber = 1
		while (!projects.isEmpty()) {
			if (projects.size() > THRESHOLD) {
				batch = projects[0..THRESHOLD - 1]
			} else {
				batch = projects
			}

			def builds = [:]
			node(NODE) {
				for (int i = 0; i < batch.size(); i++) {
					// @ see https://jenkins.io/doc/pipeline/examples/ section : Jobs In Parallel
					def index = i
					String batchDescription = "[${BUILD_NUMBER} : ${batchNumber}]"
					builds["batch${batchNumber} : build${i}"] = {
						DEPLOYMENT = batch[index].DEPLOYMENT
						REPLICAS = batch[index].REPLICAS
						DEPLOYMENT_STRATEGY = batch[index].DEPLOYMENT_STRATEGY
						READINESS_PROBE_URL = batch[index].READINESS_PROBE_URL
						SKIP_UPDATE_PROPERTIES = batch[index].SKIP_UPDATE_PROPERTIES

						build job: 'OCP_40_HQQ_promote', wait: true, parameters: [

							string(name: 'DEPLOYMENT', value: DEPLOYMENT),
							string(name: 'ORIGIN_OCP_BASE_PROJECT', value: ORIGIN_OCP_BASE_PROJECT),
							string(name: 'DESTINATION_OCP_BASE_PROJECT', value: DESTINATION_OCP_BASE_PROJECT),
							string(name: 'ORIGIN_ENVIRONMENT', value: ORIGIN_ENVIRONMENT),
							string(name: 'DESTINATION_ENVIRONMENT', value: DESTINATION_ENVIRONMENT),
							string(name: 'ORIGIN_BRANCH', value: ORIGIN_BRANCH),
							string(name: 'DESTINATION_BRANCH', value: DESTINATION_BRANCH),
							string(name: 'NODE', value: NODE),
							string(name: 'SKIP_UPDATE_PROPERTIES', value: SKIP_UPDATE_PROPERTIES),
							string(name: 'TEMPLATE_BRANCH', value: TEMPLATE_BRANCH),
							string(name: 'REPLICAS', value: REPLICAS),
							string(name: 'DEPLOYMENT_STRATEGY', value: DEPLOYMENT_STRATEGY),
							string(name: 'READINESS_PROBE_URL', value: READINESS_PROBE_URL),
							string(name: 'dummy', value: "${index}"),
							string(name: 'DESCRIPTION', value: description),
							string(name: 'BATCH_DESCRIPTION', value: batchDescription),
							string(name: 'SKIP_WAIT_FOR_OCP_DEPLOYMENT', value: 'true'),
							string(name: 'SKIP_TEST', value: 'true')
						]
					}
					// If one build in the batch needs a test, the soap UI test will be called at the end of this mass job.
					if (!shouldRunTest) {
						for (def p : jsonRqq.projects) {
							if (p.artifactId.equals(batch[index].DEPLOYMENT)) {
								shouldRunTest = p.launchSoapUITest.toBoolean()
							}
						}
					}
				}
				builds.failFast = false
				parallel builds
			}
			projects = projects.drop(THRESHOLD)
			batchNumber++
		}
		if (json.soapui_tests) {
			stage('Calling SOAP UI test') {
				// check if the SKIP_TEST checkbox is checked
				if (!SKIP_TEST.toBoolean()) {

					// test is needed if at least one job in the batch is tagged to launch a soap UI test
					if (shouldRunTest) {

						echo "An application in the batch is tagged to run a soap UI test."
						// load the environment whitelist
						def environmentWhitelist = jsonRqq.soapui_tests.environments
						echo "The soap UI tests environments found in the shared library = ${environmentWhitelist}"

						if (environmentWhitelist.contains(DESTINATION_ENVIRONMENT)) {
							echo "${DESTINATION_ENVIRONMENT} environment has been found in the whitelist"

							// fetch the soap UI test in the list
							String testJob = jsonRqq.soapui_tests.soapui_test_builds.get(0)

							build job: 'remote_build_SOAPUI_tests', parameters: [
								string(name: 'REMOTE_JOB_NAME', value: "${testJob}")
							], wait: false
						} else {
							echo "${DESTINATION_ENVIRONMENT} environment is not in the whitelist. Skipping SOAP UI test call"
						}
					} else {
						echo "The applications in this batch doesn't need to run a test. The SOAP UI test will NOT be called."
					}
				} else {
					echo "Skipping SOAP UI test because SKIP_TEST has been checked"
				}
			}
		} else {
			echo "Skipping SOAP UI test because soapui_tests doesn't exist in the shared library"
		}
	}
} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}

def getTemplate() {
	def templateAsJson = libraryResource 'intact/util/ocp/templates/rqq/massPromote.json'
	return templateAsJson.toString()
}
