#!Groovy
import intact.cluster.ocp.Cluster
import groovy.json.JsonSlurperClassic

def jsonFile = libraryResource 'intact/util/ocp/rqq.json'
def json = new JsonSlurperClassic().parseText(jsonFile)

properties([
	parameters(
		[
			booleanParam(defaultValue: false, description: 'check this is you only need to refresh the choices of the pipeline after a change in the source control.', name: 'ONLY_REFRESH_CHOICES'),
			choice(choices: json.ocp_base_projects.join("\n"), description: '', name: 'ORIGIN_BASE_PROJECT'),
			choice(choices: json.environments.join("\n"), description: '', name: 'ORIGIN_ENVIRONMENT'),
			choice(choices: json.branches.join("\n"), description: '', name: 'ORIGIN_BRANCH'),
			choice(choices: json.ocp_base_projects.join("\n"), description: '', name: 'COMPARE_BASE_PROJECT'),
			choice(choices: json.environments.join("\n"), description: '', name: 'COMPARE_ENVIRONMENT'),
			choice(choices: json.branches.join("\n"), description: '', name: 'COMPARE_BRANCH'),
			booleanParam(defaultValue: true, description: '', name: 'CHECK_GAV'),
			booleanParam(defaultValue: true, description: '', name: 'CHECK_PROJECT_LONG_VERSION'),
			booleanParam(defaultValue: true, description: '', name: 'CHECK_CONFIG_MAP_LONG_VERSION'),
			booleanParam(defaultValue: true, description: '', name: 'SHOW_DIFF'),
			booleanParam(defaultValue: true, description: '', name: 'SHOW_FULL_INFO')
		])
])

if (!ONLY_REFRESH_CHOICES.toBoolean()) {
	final String OCP_PROJECT = "${ORIGIN_BASE_PROJECT}-${ORIGIN_ENVIRONMENT}${ORIGIN_BRANCH.empty ? '' : "-${ORIGIN_BRANCH}"}"
	final String OCP_PROJECT_COMPARE = "${COMPARE_BASE_PROJECT}-${COMPARE_ENVIRONMENT}${COMPARE_BRANCH.empty ? '' : "-${COMPARE_BRANCH}"}"
	ORIGIN_CLUSTER_URL = Cluster.clusterByEnv(ORIGIN_ENVIRONMENT).url
	ORIGIN_CLUSTER_CREDENTIALS = Cluster.clusterByEnv(ORIGIN_ENVIRONMENT).credentialsId
	COMPARE_CLUSTER_URL = Cluster.clusterByEnv(COMPARE_ENVIRONMENT).url
	COMPARE_CLUSTER_CREDENTIALS = Cluster.clusterByEnv(COMPARE_ENVIRONMENT).credentialsId
	BUILD_DISPLAY_NAME = "#${BUILD_NUMBER} : Compare ${OCP_PROJECT} with ${OCP_PROJECT_COMPARE}"
	JAVA_HOME_VERSION = 'ibm-java-linux-1.7-x86_64-71'
	MAVEN_HOME_VERSION = 'maven-3.0.5'

	node('node-2020-linux-prd-004') {
		currentBuild.displayName = BUILD_DISPLAY_NAME
		// Delete all artifacts
		deleteDir()
		JAVA_HOME = tool JAVA_HOME_VERSION
		MAVEN_HOME = tool MAVEN_HOME_VERSION
		withEnv([
			"JAVA_HOME=${JAVA_HOME}",
			"MAVEN_HOME=${MAVEN_HOME}",
			"PATH=${JAVA_HOME}/bin:${MAVEN_HOME}/bin:/usr/local/bin:/usr/bin:/bin"
		]) {
			stage("Retrieve origin deployment & image") {
				logToOCP(ORIGIN_CLUSTER_URL, ORIGIN_CLUSTER_CREDENTIALS, OCP_PROJECT)
				def deploymentConfigsOriginJson = getDc(ORIGIN_ENVIRONMENT, OCP_PROJECT)
				logToOCP(COMPARE_CLUSTER_URL, COMPARE_CLUSTER_CREDENTIALS, OCP_PROJECT_COMPARE)
				def deploymentConfigsCompareJson = getDc(COMPARE_ENVIRONMENT, OCP_PROJECT_COMPARE)
				compareHistory(deploymentConfigsOriginJson, deploymentConfigsCompareJson, OCP_PROJECT, OCP_PROJECT_COMPARE)
			}
		}
	}
} else {
	currentBuild.displayName = 'REFRESHED CHOICES'
}

def getDc(environment, project) {
	sh "oc get dc -n ${project} -o json > deploymentConfigs-${ORIGIN_BASE_PROJECT}-${environment}.json"

	String deploymentConfigs = sh script: "cat deploymentConfigs-${ORIGIN_BASE_PROJECT}-${environment}.json", returnStdout: true
	def deploymentConfigsJson = new JsonSlurperClassic().parseText(deploymentConfigs)

	return deploymentConfigsJson
}

void logToOCP(clusterUrl, clusterCredentials, ocpProject) {
	withCredentials([
		usernamePassword(credentialsId: clusterCredentials, passwordVariable: 'OCP_PASSWORD', usernameVariable: 'OCP_USERNAME')
	]) {
		sh "oc login ${clusterUrl} -u ${OCP_USERNAME} -p ${OCP_PASSWORD.replace('$', '\\$')}"
	}
	sh "oc project ${ocpProject}"
}

@NonCPS
def compareHistory(leftJson, rightJson, OCP_PROJECT, OCP_PROJECT_COMPARE) {
	def compareArray = []
	def matchCount = 0
	def diffCount = 0
	def diffApps = []
	def matchApps = []
	def compareDiffArray = []

	//Get names from json
	String[] leftNames = leftJson.items.spec.template.metadata.name
	String[] rightNames = rightJson.items.spec.template.metadata.name

	def leftNamesArray = []
	leftNames.each {
		leftNamesArray.add(it)
	}

	def rightNamesArray = []
	rightNames.each {
		rightNamesArray.add(it)
	}

	// Find common applications
	def common = findNames(leftNamesArray, rightNamesArray, "common")

	// Find applications only in left
	def onlyLeft = findNames(leftNamesArray, rightNamesArray, "onlyLeft")

	// Find applications only in right
	def onlyRight = findNames(leftNamesArray, rightNamesArray, "onlyRight")

	// extract common applications from left and right
	def leftJsonExtract = extractFromJson(common, leftJson)
	def rightJsonExtract = extractFromJson(common, rightJson)

	// Generates differences and show all common apps info
	for (def left in leftJsonExtract) {
		def leftName = left.getAt("name")
		def leftGav = left.getAt("GAV")
		def leftProjectLongVersion = left.getAt("projectLongVersion")
		def leftConfigMapLongVersion = left.getAt("configMapLongVersion")

		for (def right in rightJsonExtract) {
			def rightName = right.getAt("name")
			def rightGav = right.getAt("GAV")
			def rightProjectLongVersion = right.getAt("projectLongVersion")
			def rightConfigMapLongVersion = right.getAt("configMapLongVersion")

			if (leftName == rightName) {
				def nameMatch = match(leftName, rightName)
				def gavMatch = match(leftGav, rightGav)
				def projectMatch = match(leftProjectLongVersion, rightProjectLongVersion)
				def configMap = match(leftConfigMapLongVersion, rightConfigMapLongVersion)

				// count match and diff
				if (nameMatch == "MATCH" && gavMatch == "MATCH" && projectMatch == "MATCH" && configMap == "MATCH") {
					matchApps.add(leftName)
					matchCount++
				} else {
					def diffAppsInfo = []

					// Find differences
					if (gavMatch == "DIFFERENT" && CHECK_GAV.toBoolean()) {
						diffAppsInfo.add(["${OCP_PROJECT}_GAV": "${leftGav}", "${OCP_PROJECT_COMPARE}_GAV": "${rightGav}"])
					}
					if (projectMatch == "DIFFERENT" && CHECK_PROJECT_LONG_VERSION.toBoolean()) {
						diffAppsInfo.add(["${OCP_PROJECT}_projectLongVersion": "${leftProjectLongVersion}", "${OCP_PROJECT_COMPARE}_projectLongVersion": "${rightProjectLongVersion}"])
					}
					if (configMap == "DIFFERENT" && CHECK_CONFIG_MAP_LONG_VERSION.toBoolean()) {
						diffAppsInfo.add(["${OCP_PROJECT}_configMapLongVersion": "${leftConfigMapLongVersion}", "${OCP_PROJECT_COMPARE}_configMapLongVersion": "${rightConfigMapLongVersion}"])
					}

					if (diffAppsInfo.size() != 0) {
						compareDiffArray.add("${leftName}": diffAppsInfo)
					}
					// Add app name and count
					diffApps.add(leftName)
					diffCount++
				}

				def temp = ["${OCP_PROJECT}_name"        : leftName,
							"${OCP_PROJECT_COMPARE}_name": rightName,
							resultName                   : nameMatch]

				if (CHECK_GAV.toBoolean()) {
					temp += ["${OCP_PROJECT}_GAV"        : leftGav,
							 "${OCP_PROJECT_COMPARE}_GAV": rightGav,
							 resultGav                   : gavMatch]
				}
				if (CHECK_PROJECT_LONG_VERSION.toBoolean()) {
					temp += ["${OCP_PROJECT}_projectLongVersion"        : leftProjectLongVersion,
							 "${OCP_PROJECT_COMPARE}_projectLongVersion": rightProjectLongVersion,
							 resultProjectLongVersion                   : projectMatch]
				}
				if (CHECK_CONFIG_MAP_LONG_VERSION.toBoolean()) {
					temp += ["${OCP_PROJECT}_configMapLongVersion"        : leftConfigMapLongVersion,
							 "${OCP_PROJECT_COMPARE}_configMapLongVersion": rightConfigMapLongVersion,
							 resultConfigMapLongVersion                   : configMap]
				}

				// Add common application info into the array
				compareArray.add(temp)
			}
		}
	}

	// build final json
	def jsonAll = new groovy.json.JsonBuilder(compareArray)
	def jsonDiff = new groovy.json.JsonBuilder(compareDiffArray)

	// Extract unique applications
	def leftOnlyJsonExtract = extractFromJson(onlyLeft, leftJson)
	def rightOnlyJsonExtract = extractFromJson(onlyRight, rightJson)

	// Prepare result output
	def result
	result = "ORIGIN contains " + leftNamesArray.size() + " applications\n" +
		"COMPARE contains " + rightNamesArray.size() + " applications\n" +
		"ORIGIN only ${onlyLeft}\n" +
		"COMPARE only ${onlyRight}\n" +
		matchCount + " MATCH FOUND in " + matchApps + "\n" +
		diffCount + " DIFF FOUND in " + diffApps + "\n"

	if (SHOW_DIFF.toBoolean()) {
		result += "DIFFERENCES " + jsonDiff.toPrettyString()
	}

	if (SHOW_FULL_INFO.toBoolean()) {
		result += "\nFULL INFO " + jsonAll.toPrettyString()
	}

	// Print results for unique applications in ORIGIN and COMPARE
	if (leftOnlyJsonExtract) {
		def jsonLeft = new groovy.json.JsonBuilder(leftOnlyJsonExtract)
		println("Applications in ORIGIN only\n" + jsonLeft.toPrettyString())
	}

	if (rightOnlyJsonExtract) {
		def jsonRight = new groovy.json.JsonBuilder(rightOnlyJsonExtract)
		println("Applications in COMPARE only\n" + jsonRight.toPrettyString())
	}

	generateArtifact(result)
}

def generateArtifact(result) {
	String jsonFileName = "compare_${ORIGIN_BASE_PROJECT}-${ORIGIN_ENVIRONMENT}-${COMPARE_BASE_PROJECT}-${COMPARE_ENVIRONMENT}.json"
	sh "printf '${result}' > ${jsonFileName}"
	archiveArtifacts allowEmptyArchive: true, artifacts: jsonFileName
}

// Check string match
@NonCPS
def match(left, right) {
	if (left == right) {
		return "MATCH"
	} else {
		return "DIFFERENT"
	}
}

@NonCPS
def extractFromJson(names, json) {
	def result = names.collect { name ->
		def template = json.items.spec.template.findAll { t ->
			t.metadata.name == name
		}
		String groupId = template.metadata.labels.groupId[0]
		String artifactId = template.metadata.labels.artifactId[0]
		String projectVersion = template.metadata.labels.projectVersion[0]
		String GAV = [groupId, artifactId, projectVersion].join(':')
		String projectLongVersion = template.metadata.labels.projectLongVersion[0]
		String configMapLongVersion = template.metadata.labels.configMapLongVersion[0]
		[
			name                : name,
			GAV                 : GAV,
			projectLongVersion  : projectLongVersion,
			configMapLongVersion: configMapLongVersion
		]
	}
	return result
}

@NonCPS
def findNames(left, right, param) {
	// find common
	def common = left.intersect(right)

	// find diff
	def onlyLeft = (left - common)
	def onlyRight = (right - common)

	// return the parameter specified
	switch (param) {
		case "common":
			return common
			break

		case "onlyLeft":
			return onlyLeft
			break

		case "onlyRight":
			return onlyRight
			break
		default:
			return common
			break
	}
}
