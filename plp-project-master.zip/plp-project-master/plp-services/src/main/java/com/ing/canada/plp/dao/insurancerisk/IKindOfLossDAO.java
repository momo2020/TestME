package com.ing.canada.plp.dao.insurancerisk;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.insurancerisk.KindOfLoss;

/**
 * The Interface IKindOfLossDAO.
 */
public interface IKindOfLossDAO extends IBaseDAO<KindOfLoss> {
	// NOOP
}
