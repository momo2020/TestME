package com.ing.canada.plp.dao.businesstransaction;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.businesstransaction.TransactionalMessage;

/**
 * The Interface ITransactionalMessageDAO.
 */
public interface ITransactionalMessageDAO extends IBaseDAO<TransactionalMessage> {
	// noop
}
