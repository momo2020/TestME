/**
 * 
 */
package com.ing.canada.plp.dao.interceptor;

import java.io.Serializable;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.CallbackException;
import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

import com.ing.canada.plp.annotation.CaseSensitive;

/**
 * @author plafleur
 * 
 */
public class UppercaseStringInterceptor extends EmptyInterceptor {

	/**
	 * the serial version UID.
	 */
	private static final long serialVersionUID = -7506089813125093077L;

	private static final Log log = LogFactory.getLog(UppercaseStringInterceptor.class);

	/**
	 * This method transforms every string of an object to uppercase before creating it in the database. Both the data
	 * sent to the statement and the in memory entity are modified.
	 * 
	 * @see org.hibernate.EmptyInterceptor#onSave(java.lang.Object, java.io.Serializable, java.lang.Object[],
	 *      java.lang.String[], org.hibernate.type.Type[])
	 */
	@Override
	public boolean onSave(Object entity, Serializable id, Object[] currentState, String[] propertyNames, Type[] types)
			throws CallbackException {

		boolean updated = super.onSave(entity, id, currentState, propertyNames, types);

		if (transformStringsToUppercase(entity, id, currentState, propertyNames, types)) {
			updated = true;
		}

		// tells hibernate if we modified at least one property
		return updated; 

	}

	/**
	 * This method transforms every string of an object to uppercase before updating it's database representation. Both
	 * the data sent to the statement and the in memory entity are modified.
	 * 
	 * @see org.hibernate.EmptyInterceptor#onFlushDirty(java.lang.Object, java.io.Serializable, java.lang.Object[],
	 *      java.lang.Object[], java.lang.String[], org.hibernate.type.Type[])
	 */
	@Override
	public boolean onFlushDirty(Object entity, Serializable id, Object[] currentState, Object[] originalState,
			String[] propertyNames, Type[] types) {

		boolean updated = super.onFlushDirty(entity, id, currentState, originalState, propertyNames, types);

		if (transformStringsToUppercase(entity, id, currentState, propertyNames, types)) {
			updated = true;
		}

		// tells hibernate if we modified at least one property
		return updated; 

	}

	/**
	 * 
	 * @param entity then entity being persisted
	 * @param id the database id of the entity
	 * @param currentState the values being persisted to the database
	 * @param propertyNames the name of attributes
	 * @param types the types of values being persisted
	 * @return true if at least one attribute was uppercased, false otherwise
	 */
	private boolean transformStringsToUppercase(Object entity, Serializable id, Object[] currentState,
			String[] propertyNames, Type[] types) throws CallbackException {

		boolean transformedAtLeastOneString = false;

		for (int i = 0; i < types.length; ++i) {

			if (types[i].getReturnedClass() == String.class) {

				String string = (String) currentState[i];

				if (string != null) {

					// begin check if field must keep the his case
					boolean needCaseModification = true;
					Field field = findFieldInClass(entity.getClass(), propertyNames[i]);
					Annotation annotation = field.getAnnotation(CaseSensitive.class);
					needCaseModification = annotation == null;
					// end

					if (needCaseModification) {
						String upper = string.toUpperCase();

						if (log.isDebugEnabled()) {
							log.debug("transforming " + propertyNames[i] + " property to uppercase: " + upper);
						}

						currentState[i] = upper;
						transformedAtLeastOneString = true;
					}
				}

			}

		}

		return transformedAtLeastOneString;

	}

	/**
	 * 
	 * @param entity
	 * @param propertyName
	 * @return
	 * @throws CallbackException
	 */
	private Field findFieldInClass(Class<?> entityClass, String propertyName) throws CallbackException {
		Field field = null;
		try {
			field = entityClass.getDeclaredField(propertyName);
		} catch (SecurityException e) {
			throw new CallbackException(e);
		} catch (NoSuchFieldException e) {
			// try to found the property in the parent class
			Class<?> superClass = entityClass.getSuperclass();
			if (!superClass.equals(Object.class)) {
				return findFieldInClass(superClass, propertyName);
			}
			throw new CallbackException(e);
		}
		return field;

	}
}
