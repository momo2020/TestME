package com.ing.canada.plp.dao.coverage;

import java.util.List;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.coverage.CoverageOption;

public interface ICoverageOptionDAO extends IBaseDAO<CoverageOption> {

	/**
	 * Find the list of coverage options associated to an insurance Risk
	 * 
	 * @param insuranceRiskId
	 *            The insurance risk Id
	 * @return list of coverage options.
	 */
	List<CoverageOption> findCoverageOptionsByRisk(Long insuranceRiskId) throws Exception;
	
	/**
	 * Save a coverage option.
	 * 
	 * @param coverageOption {@link CoverageOption}
	 * @return The saved coverage option {@link CoverageOption}
	 * @throws Exception
	 */
	CoverageOption save(CoverageOption coverageOption) throws Exception;
}
