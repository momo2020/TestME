package com.ing.canada.plp.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseRepositoryDAO;
import com.ing.canada.plp.domain.ManufacturingContext;
import com.ing.canada.plp.domain.enums.DistributionChannelCodeEnum;
import com.ing.canada.plp.domain.enums.InsuranceBusinessCodeEnum;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;

/**
 * The Class ManufacturingContextDAO.
 */
@Repository
public class ManufacturingContextDAO extends BaseRepositoryDAO<ManufacturingContext> implements
		IManufacturingContextDAO {

	private static final Log log = LogFactory.getLog(ManufacturingContextDAO.class);

	/** The Constant DISTRIBUTION_CHANNEL_CODE. */
	public static final String DISTRIBUTION_CHANNEL_CODE = "distributionChannel";

	/** The Constant INSURANCE_BUSINESS_CODE. */
	public static final String INSURANCE_BUSINESS_CODE = "insuranceBusiness";

	/** The Constant PROVINCE_CODE. */
	public static final String PROVINCE_CODE = "province";

	/** The Constant MANUFACTURER_COMPANY_CODE. */
	public static final String MANUFACTURER_COMPANY_CODE = "manufacturerCompany";

	/**
	 * @see com.ing.canada.plp.dao.IManufacturingContextDAO#findByDistributionChannelCode(com.ing.canada.plp.domain.enums.DistributionChannelCodeEnum)
	 */
	@Override
	public List<ManufacturingContext> findByDistributionChannelCode(DistributionChannelCodeEnum distributionChannelCode) {
		return findByProperty(DISTRIBUTION_CHANNEL_CODE, distributionChannelCode);
	}

	@Override
	public ManufacturingContext find(ManufacturingContext context) {
		Session session = (Session) this.entityManager.getDelegate();
		Criteria criteria = session.createCriteria(ManufacturingContext.class);

		criteria.add(Restrictions.eq(DISTRIBUTION_CHANNEL_CODE, context.getDistributionChannel()));
		criteria.add(Restrictions.eq(INSURANCE_BUSINESS_CODE, context.getInsuranceBusiness()));
		criteria.add(Restrictions.eq(PROVINCE_CODE, context.getProvince()));
		criteria.add(Restrictions.eq(MANUFACTURER_COMPANY_CODE, context.getManufacturerCompany()));

		return (ManufacturingContext) criteria.uniqueResult();
	}

	/**
	 * @see com.ing.canada.plp.dao.IManufacturingContextDAO#findByInsuranceBusinessCode(com.ing.canada.plp.domain.enums.InsuranceBusinessCodeEnum)
	 */
	@Override
	public List<ManufacturingContext> findByInsuranceBusinessCode(InsuranceBusinessCodeEnum insuranceBusinessCode) {
		return findByProperty(INSURANCE_BUSINESS_CODE, insuranceBusinessCode);
	}

	/**
	 * @see com.ing.canada.plp.dao.IManufacturingContextDAO#findByProvinceCode(com.ing.canada.plp.domain.enums.ProvinceCodeEnum)
	 */
	@Override
	public List<ManufacturingContext> findByProvinceCode(ProvinceCodeEnum provinceCode) {
		return findByProperty(PROVINCE_CODE, provinceCode);
	}

	/**
	 * @see com.ing.canada.plp.dao.IManufacturingContextDAO#findByManufacturerCompanyCode(com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum)
	 */
	@Override
	public List<ManufacturingContext> findByManufacturerCompanyCode(ManufacturerCompanyCodeEnum manufacturerCompanyCode) {
		return findByProperty(MANUFACTURER_COMPANY_CODE, manufacturerCompanyCode);
	}

	/**
	 * @see com.ing.canada.plp.dao.IManufacturingContextDAO#findOrCreateByExample(com.ing.canada.plp.domain.ManufacturingContext)
	 */
	@Override
	public ManufacturingContext findOrCreateByExample(ManufacturingContext ctx) {

		if (ctx.getProvince() == null) {
			throw new IllegalArgumentException("province must be initialized");
		}
		if (ctx.getDistributionChannel() == null) {
			throw new IllegalArgumentException("distributionChannel must be initialized");
		}
		if (ctx.getInsuranceBusiness() == null) {
			throw new IllegalArgumentException("insuranceBusiness must be initialized");
		}
		if (ctx.getManufacturerCompany() == null) {
			throw new IllegalArgumentException("manufacturerCompany must be initialized");
		}

		Session session = (Session) this.entityManager.getDelegate();

		Example example = Example.create(ctx);

		example.excludeNone();

		example.excludeProperty("auditTrail");

		ManufacturingContext found = (ManufacturingContext) session.createCriteria(getEntityClass()).add(example)
				.uniqueResult();
		if (found != null) {
			log.info("found an existing manufacturing context, will reuse it");
			return found;
		}

		log.info("persisting a new manufacturing context");
		return persist(ctx);

	}

	/**
	 * Gets the exclude properties.
	 * 
	 * @return the exclude properties
	 * 
	 * @see com.ing.canada.plp.dao.base.BaseRepositoryDAO#getExcludeProperties()
	 */
	@Override
	protected String[] getExcludeProperties() {

		return new String[] { "auditTrail" };
	}

}
