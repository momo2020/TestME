package com.ing.canada.plp.dao.insurancerisk;

import java.util.List;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.insurancerisk.Claim;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Interface IClaimDAO.
 */
public interface IClaimDAO extends IBaseDAO<Claim> {

	/**
	 * This method must return all claims associated to the PolicyVersion, 
	 * the one of the Party or of the InsuranceRisk. 
	 * The claim should not be present more than once in the list.
	 * 
	 * @param policyVersion
	 * @return
	 */
	List<Claim> findAllClaimsByPolicyVersion(PolicyVersion policyVersion);

}
