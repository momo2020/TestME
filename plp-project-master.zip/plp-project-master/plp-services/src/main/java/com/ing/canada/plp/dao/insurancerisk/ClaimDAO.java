package com.ing.canada.plp.dao.insurancerisk;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.insurancerisk.Claim;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Class ClaimDAO.
 */
@Repository
public class ClaimDAO extends BaseDAO<Claim> implements IClaimDAO {

	/**
	 * {@inheritDoc}
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<Claim> findAllClaimsByPolicyVersion(PolicyVersion aPolicyVersion) {

		Session session = (Session) this.entityManager.getDelegate();

		// First, get all claims based attached directly to the policy version
		Criteria claimCriteria = session.createCriteria(Claim.class);
		claimCriteria.add(Restrictions.eq("policyVersion", aPolicyVersion));
		List<Claim> policyClaimList = claimCriteria.list();
		// Then get all the claims on the insurance risks
		claimCriteria = session.createCriteria(Claim.class);
		claimCriteria.createCriteria("insuranceRisk").add(Restrictions.eq("policyVersion", aPolicyVersion));
		List<Claim> insuranceRiskClaimList = claimCriteria.list();
		// Finally get all the claims on the parties
		claimCriteria = session.createCriteria(Claim.class);
		claimCriteria.createCriteria("party").add(Restrictions.eq("policyVersion", aPolicyVersion));
		List<Claim> partyClaimList = claimCriteria.list();
		// Add the 3 list to a Set so they will be distinct
		Set<Claim> claimSet = new HashSet<Claim>();
		claimSet.addAll(policyClaimList);
		claimSet.addAll(insuranceRiskClaimList);
		claimSet.addAll(partyClaimList);

		return new ArrayList<Claim>(claimSet);
	}
}
