/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.insuranceriskoffer;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlInOutParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.dao.insuranceriskoffer.util.CloneOfferStoredProcedure;
import com.ing.canada.plp.domain.enums.InternalTechnicalOfferTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer;

/**
 * The Class InsuranceRiskOfferDAO.
 * 
 * @author pmdroz
 */
@Repository
public class InsuranceRiskOfferDAO extends BaseDAO<InsuranceRiskOffer> implements IInsuranceRiskOfferDAO {

	@Autowired
	@Qualifier("jdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	public InsuranceRiskOfferDAO() {
		super();
	}

	public final JdbcTemplate getJdbcTemplate() {
		return this.jdbcTemplate;
	}

	public final void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	/**
	 * @see com.ing.canada.plp.dao.insuranceriskoffer.IInsuranceRiskOfferDAO#cloneForKanetix(com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer)
	 */
	@Override
	public Long cloneForKanetix(InsuranceRiskOffer aRiskOffer) throws SQLException {

		CloneStoredProcedure cloneSP = new CloneStoredProcedure(this.jdbcTemplate);

		this.log.info("Executing call to stored procedure: " + cloneSP.getSql());
		Map<?, ?> result = cloneSP.execute(aRiskOffer.getId());

		return (Long) result.get(CloneStoredProcedure.RISK_OFFER_ID_PARAM);
	}

	/**
	 * @see com.ing.canada.plp.dao.insuranceriskoffer.IInsuranceRiskOfferDAO#findByInternalOfferType(com.ing.canada.plp.domain.insurancerisk.InsuranceRisk,
	 *      com.ing.canada.plp.domain.enums.InternalTechnicalOfferTypeCodeEnum)
	 */
	@Override
	public InsuranceRiskOffer findByInternalOfferType(InsuranceRisk aRisk, InternalTechnicalOfferTypeCodeEnum anInternal) {

		Query query = this.entityManager
				.createNamedQuery("InsuranceRiskOffer.findInsuranceRiskOfferByInternalOfferType");
		query.setParameter("insuranceRiskId", aRisk.getId());
		query.setParameter("internalOfferType", anInternal);

		try {
			return (InsuranceRiskOffer) query.getSingleResult();
		} catch (NoResultException nrex) {
			this.log.trace("No results found !");
		}
		return null;
	}

	@Override
	public void cloneOffer(InsuranceRiskOffer source, InsuranceRiskOffer destination) throws SQLException {

		try {
			CloneOfferStoredProcedure storedProc = new CloneOfferStoredProcedure(this.getJdbcTemplate());
			storedProc.execute(source, destination);
			
		} catch (DataAccessException dae) {
			throw new SQLException(dae);
		}

	}

	/**
	 * The Class CloneStoredProcedure encapsulates the call to the clone stored
	 * proc.
	 */
	public class CloneStoredProcedure extends StoredProcedure {
		private static final String STORED_PROC_NAME = "plpadmin.clone_offer.clone_market_offer";

		private static final String RISK_OFFER_ID_PARAM = "insuranceRiskOfferId";

		public CloneStoredProcedure(JdbcTemplate jdbcTemplateToSet) {
			super(jdbcTemplateToSet, STORED_PROC_NAME);
			declareParameter(new SqlInOutParameter(RISK_OFFER_ID_PARAM, Types.BIGINT));
		}

		public Map<?, ?> execute(Long insuranceRiskOfferId) {

			Map<String, Object> inputs = new HashMap<String, Object>();
			inputs.put(RISK_OFFER_ID_PARAM, insuranceRiskOfferId);

			return super.execute(inputs);
		}
	}
}
