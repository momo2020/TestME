package com.ing.canada.plp.dao.base;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * The Interface IBaseDAO.
 */
public interface IBaseDAO<E extends BaseEntity> {

	/**
	 * Returns a query defined in an entity class.
	 * 
	 * @param queryName
	 * @return a jpa query
	 */
	Query createNamedQuery(String queryName);
	
	/**
	 * Persist.
	 * 
	 * @param newEntity the new entity
	 * 
	 * @return the e
	 */
	E persist(E newEntity);

	/**
	 * Delete.
	 * 
	 * @param id the id
	 * 
	 * @return the e
	 */
	E delete(long id);

	/**
	 * Delete.
	 * 
	 * @param entity the entity
	 * 
	 * @return the e
	 */
	E delete(E entity);

	/**
	 * Refresh.
	 * 
	 * @param entity the entity
	 * 
	 * @return the e
	 */
	E refresh(E entity);

	/**
	 * Find all.
	 * 
	 * @return the list< e>
	 */
	List<E> findAll();

	/**
	 * Find by id.
	 * 
	 * @param id the id
	 * 
	 * @return the e
	 */
	E findById(long id);

	/**
	 * Find by property.
	 * 
	 * @param propertyName the property name
	 * @param value the value
	 * 
	 * @return the list< e>
	 */
	List<E> findByProperty(String propertyName, Object value);

	/**
	 * Gets the sequence value.
	 * 
	 * @param sequenceName the sequence name
	 * 
	 * @return the sequence value
	 */
	BigDecimal getSequenceValue(String sequenceName);

	/**
	 * Flush an entity from the entity manager Level 1 cache. The entity becomes in detached state and is not
	 * managed/monitored by the JPA entity manager anymore. If you modify this object after the eviction and want to
	 * update the database, you have to explicitely call update().
	 * 
	 * @param entity the entity to be flushed
	 */
	void evict(E entity);
	
	void clear();

	/**
	 * Synchronize all pending operations to the database.
	 */
	void flush();
	
	public EntityManager getEntityManager ();
}
