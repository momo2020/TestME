package com.ing.canada.plp.dao.driver;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.driver.Conviction;

/**
 * The Class ConvictionDAO.
 */
@Repository
public class ConvictionDAO extends BaseDAO<Conviction> implements IConvictionDAO {
	// NOOP
}
