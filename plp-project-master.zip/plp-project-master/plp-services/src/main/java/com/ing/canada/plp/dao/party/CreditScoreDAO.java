package com.ing.canada.plp.dao.party;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.party.CreditScore;

/**
 * The Class CreditScoreDAO.
 */
@Repository
public class CreditScoreDAO extends BaseDAO<CreditScore> implements ICreditScoreDAO {
	// NOOP
}
