/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.businesstransaction;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseRepositoryDAO;
import com.ing.canada.plp.domain.businesstransaction.MessageRepositoryEntry;

/**
 * The Class MessageRepositoryEntryDAO.
 * 
 * @author bcampeau
 */
@Repository
public class MessageRepositoryEntryDAO extends BaseRepositoryDAO<MessageRepositoryEntry> implements
		IMessageRepositoryEntryDAO {

	@Override
	public MessageRepositoryEntry findByMessageId(String messageId) {

		Session session = (Session) this.entityManager.getDelegate();

		// get the last coverageRepositoryEntry matching the give coverageCode
		Criteria messageRepositoryEntryCriteria = session.createCriteria(MessageRepositoryEntry.class).add(
				Restrictions.eq("messageNumber", messageId)).addOrder(Order.desc("id")).setMaxResults(1);

		return (MessageRepositoryEntry) messageRepositoryEntryCriteria.uniqueResult();
	}
}
