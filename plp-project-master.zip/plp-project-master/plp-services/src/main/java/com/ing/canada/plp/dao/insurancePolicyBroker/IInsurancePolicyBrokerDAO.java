package com.ing.canada.plp.dao.insurancePolicyBroker;

import java.util.List;

import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;
import com.ing.canada.plp.report.insurancePolicy.InsurancePolicyBrokerInfo;
import com.ing.canada.plp.report.insurancePolicy.criteria.QuoteSearchCriteria;

public interface IInsurancePolicyBrokerDAO {

	/**
	 * Gets the insurance policy broker list.
	 * The returned object is a Map with com.ing.canada.plp.report.insurancePolicy.InsurancePolicyBrokerInfo as key
	 * and a Collection of com.ing.canada.plp.report.insurancePolicy.InsurancePolicyNoteInfo as value
	 *	 
	 * @param availableMasters :  the available masters list
	 * @param aNbrOfDayLeft
	 * @param aProvinceCode
	 * @param aSubBrokerCompanyNumber
	 * @param aManufacturerCompanyCode
	 * @param adminRole : the admin role
	 * @return
	 */
	List<InsurancePolicyBrokerInfo> getInsurancePolicyBrokerList(List<String> availableMasters, Integer aNbrOfDayLeft, ProvinceCodeEnum aProvinceCode, String aSubBrokerCompanyNumber, ManufacturerCompanyCodeEnum aManufacturerCompanyCode,  boolean adminRole, int maxRow);

	
	/**
	 * Gets the insurance policy broker list.  
	 * The returned object is a Map with com.ing.canada.plp.report.insurancePolicy.InsurancePolicyBrokerInfo as key 
	 * and a Collection of com.ing.canada.plp.report.insurancePolicy.InsurancePolicyNoteInfo as value
	 *  	 
	 * @param aSearchCriteria
	 * @param aProvinceCode
	 * @param aSubBrokerCompanyNumber
	 * @param aManufacturerCompanyCode
	 * @return the insurance policy broker list
	 */
	List<InsurancePolicyBrokerInfo> getInsurancePolicyBrokerListSP(QuoteSearchCriteria aSearchCriteria, ProvinceCodeEnum aProvinceCode, String aSubBrokerCompanyNumber, ManufacturerCompanyCodeEnum aManufacturerCompanyCode);
	

}
