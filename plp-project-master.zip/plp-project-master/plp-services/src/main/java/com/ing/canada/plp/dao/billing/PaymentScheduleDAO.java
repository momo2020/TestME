package com.ing.canada.plp.dao.billing;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.billing.PaymentSchedule;

/**
 * The Class PaymentScheduleDAO.
 */
@Repository
public class PaymentScheduleDAO extends BaseDAO<PaymentSchedule> implements IPaymentScheduleDAO {
	// noop
}
