/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.coverage;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.time.DateUtils;
import org.hibernate.Criteria;
import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseRepositoryDAO;
import com.ing.canada.plp.domain.coverage.CoverageRepositoryEntry;
import com.ing.canada.plp.domain.enums.CoverageGroupCodeEnum;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;

/**
 * The Class CoverageRepositoryEntryDAO.
 */
@Repository
public class CoverageRepositoryEntryDAO extends BaseRepositoryDAO<CoverageRepositoryEntry> implements
		ICoverageRepositoryEntryDAO {

	/**
	 * @see com.ing.canada.plp.dao.base.BaseRepositoryDAO#getExcludeProperties()
	 */
	@Override
	protected String[] getExcludeProperties() {
		return new String[] { "id", "expiryDate", "effectiveDate" };
	}
	
	
	@Override
	public CoverageRepositoryEntry findActiveCoverageRepositoryEntryByCoverageCodeAndManufacturerCompany(String coverageCode,
			ProvinceCodeEnum provinceCode, ManufacturerCompanyCodeEnum aCompany) {

		Session session = (Session) this.entityManager.getDelegate();

		// get the last coverageRepositoryEntry matching the give coverageCode
		Criteria coverageRepositoryEntryCriteria = session.createCriteria(CoverageRepositoryEntry.class)
			.add(Restrictions.eq("coverageCode", coverageCode))
			.add(Restrictions.eq("province", provinceCode))
			.add(Restrictions.eq("manufacturerCompanyCode", aCompany))		
			.setFlushMode(FlushMode.MANUAL).setMaxResults(1);

		// get an active (unexpired) coverage
		coverageRepositoryEntryCriteria.add(Restrictions.gt("expiryDate", Calendar.getInstance().getTime()));
		
		return (CoverageRepositoryEntry) coverageRepositoryEntryCriteria.uniqueResult();
	}

	
	@Override
	public CoverageRepositoryEntry findCoverageRepositoryEntryByCoverageCodeAndManufacturerCompany(String coverageCode,
			ProvinceCodeEnum provinceCode, ManufacturerCompanyCodeEnum aCompany, Date effectiveDate) {

		Session session = (Session) this.entityManager.getDelegate();

		// get the last coverageRepositoryEntry matching the give coverageCode
		Criteria coverageRepositoryEntryCriteria = session.createCriteria(CoverageRepositoryEntry.class)
			.add(Restrictions.eq("coverageCode", coverageCode))
			.add(Restrictions.eq("province", provinceCode))
			.add(Restrictions.eq("manufacturerCompanyCode", aCompany))		
			.setFlushMode(FlushMode.MANUAL).setMaxResults(1);

		if (effectiveDate != null) {
			coverageRepositoryEntryCriteria.add(Restrictions.eq("effectiveDate", effectiveDate));
		}
		
		return (CoverageRepositoryEntry) coverageRepositoryEntryCriteria.uniqueResult();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<CoverageRepositoryEntry> findCoverageRepositoryEntryByManufacturerCompanyAndProvince(
			ProvinceCodeEnum provinceCode, ManufacturerCompanyCodeEnum aCompany) {

		Session session = (Session) this.entityManager.getDelegate();

		// get the last coverageRepositoryEntry matching the give coverageCode
		List<CoverageRepositoryEntry> entries = session.getNamedQuery(
				"CoverageRepositoryEntry.findByManufacturerCompanyCodeAndProvince")
				.setParameter("provinceCode", provinceCode)
				.setParameter("company", aCompany)
			.setFlushMode(FlushMode.MANUAL)
			.list();

	
		return entries;
	}
		

	/**
	 * @see com.ing.canada.plp.dao.coverage.ICoverageRepositoryEntryDAO#findByProvinceCodeAndRatingDate(
	 * 			com.ing.canada.plp.domain.enums.ProvinceCodeEnum, java.util.Date)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Map<String, CoverageRepositoryEntry> findByProvinceCodeAndRatingDate(ProvinceCodeEnum provinceCode, 
																		ManufacturerCompanyCodeEnum aCompany, Date ratingDate) {

		Session session = (Session) this.entityManager.getDelegate();

		Date truncDate = DateUtils.truncate(ratingDate, Calendar.DAY_OF_MONTH);
		List<CoverageRepositoryEntry> entries = session.getNamedQuery(
				"CoverageRepositoryEntry.findByManufacturerCompanyCodeAndProvinceAndRatingDate")
				.setParameter("provinceCode", provinceCode)
				.setDate("ratingDate", truncDate)
				.setParameter("company", aCompany)
				.setParameterList("coverageGroupCodeList", CoverageGroupCodeEnum.values())
				.setFlushMode(FlushMode.MANUAL)
				.list();
		
		Map<String, CoverageRepositoryEntry> map = new HashMap<String, CoverageRepositoryEntry>(entries.size());
		for(CoverageRepositoryEntry entry : entries){
			map.put(entry.getCoverageCode(), entry);
		}
		
		return map;
		
	}
	
	
	/**
	 * @see com.ing.canada.plp.dao.coverage.ICoverageRepositoryEntryDAO#findByCoverageCodeAndProvinceCodeAndRatingDate(java.lang.String,
	 *      com.ing.canada.plp.domain.enums.ProvinceCodeEnum, java.util.Date)
	 */
	@Override
	public CoverageRepositoryEntry findByCoverageCodeAndProvinceCodeAndRatingDate(String coverageCode,
			ProvinceCodeEnum provinceCode, ManufacturerCompanyCodeEnum aCompany, Date ratingDate) {

		Session session = (Session) this.entityManager.getDelegate();

		// get the last coverageRepositoryEntry matching the give coverageCode
		if ( ratingDate == null ) {
			ratingDate = new Date();
		}
		Date truncDate = DateUtils.truncate(ratingDate, Calendar.DAY_OF_MONTH);
		return (CoverageRepositoryEntry) session.getNamedQuery("CoverageRepositoryEntry.findByCoverageCodeProvinceAndRatingDate")
				.setString("coverageCode", coverageCode)
				.setParameter("company", aCompany)
				.setParameter("provinceCode", provinceCode)
				.setDate("ratingDate", truncDate)
				.setFlushMode(FlushMode.MANUAL)
				.setMaxResults(1)
				.uniqueResult();

	}	

}
