package com.ing.canada.plp.dao.insuranceriskoffer;

import java.util.List;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.insuranceriskoffer.RatingRiskOffer;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Interface IRatingRiskOfferDAO.
 */
public interface IRatingRiskOfferDAO extends IBaseDAO<RatingRiskOffer> {
	
	List<RatingRiskOffer> findAllRatingRiskOffersByPolicyVersion(PolicyVersion aPolicyVersion);
}
