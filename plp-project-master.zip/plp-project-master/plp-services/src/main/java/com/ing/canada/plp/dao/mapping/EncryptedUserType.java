/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.mapping;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.StringType;
import org.hibernate.usertype.UserType;

import com.ing.canada.plp.crypto.IIngCipher;
import com.ing.canada.plp.stereotype.ApplicationContextHolder;

/**
 * @author plafleur
 * 
 * This class performs the conversion from a unencrypted string to encrypted base 64 data and vice versa. These
 * operations are called automatically by hibernate as objects are read and written from/to the database.
 */
public class EncryptedUserType implements UserType {

	private static final Log log = LogFactory.getLog(EncryptedUserType.class);

	private StringType type = StringType.INSTANCE;

	// To be retested if we ever use this part of the code
	// need to be implemented. perhaps??
	private IIngCipher cipher = null;

	/**
	 * Creates an encrypted user type. It tries to obtain the encryption service from spring.
	 * 
	 * @exception IllegalStateException thrown if the service is not defined in spring or the application context is not
	 *                available
	 */
	public EncryptedUserType() {

		// ApplicationContext context = ApplicationContextHolder.getApplicationContext();
		// this.cipher = (IIngCipher) context.getBean("cipher");
		//
		// if (this.cipher == null) {
		// throw new IllegalStateException("the cypher utility object is required");
		// }

	}

	/**
	 * The cipher object can not be instantiated in the setParameterValues method. Hibernate initialize the current
	 * class during the spring injection process. At this point the context in the applicationContextHolder have not
	 * bean initialize by spring.
	 * 
	 * There GenericUnumUserType is manage like a singleton in hibernate so I think it's ok to keep the cipher as a
	 * singleton as well.
	 * 
	 * @return
	 */
	private IIngCipher getEncrypter() {
		if (this.cipher == null) {
			this.cipher = (IIngCipher) ApplicationContextHolder.getBean("plp-ingAesCipher");
		}
		return this.cipher;
	}

	/**
	 * {@inheritDoc}
	 */
	public Object nullSafeGet(ResultSet rs, String[] names, SessionImplementor session, Object owner) throws HibernateException, SQLException {

		Object encryptedValue = this.type.get(rs, names[0], session);

		if (encryptedValue == null) {
			if (log.isDebugEnabled()) {
				log.debug("null value retrieved from the datbase, no decryption will occur");
			}
			return null;
		}

		try {

			String decryptToString = this.getEncrypter().decryptToString((String) encryptedValue);
			return decryptToString;

		} catch (Exception e) {
			throw new HibernateException("database value cannot be decrypted and/or be read from the result set: "
					+ encryptedValue, e);
		}

	}

	/**
	 * {@inheritDoc}
	 */
	public void nullSafeSet(PreparedStatement ps, Object unencryptedValue, int index, SessionImplementor session) throws HibernateException,
			SQLException {

		try {

			if (unencryptedValue == null) {

				if (log.isDebugEnabled()) {
					log.debug("binding null to parameter: " + index);
				}
				ps.setNull(index, this.type.sqlType());

			} else {

				this.type.set(ps, this.getEncrypter().encryptString((String) unencryptedValue), index, session);

			}

		} catch (Exception e) {
			throw new HibernateException("string cannot be encrypted and/or be written to the statement:", e);
		}

	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object assemble(Serializable cached, Object owner) throws HibernateException {
		return cached;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object deepCopy(Object object) throws HibernateException {
		return object;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Serializable disassemble(Object object) throws HibernateException {
		return (Serializable) object;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object o1, Object o2) throws HibernateException {
		return (o1 == o2) || (o1 != null && o1.equals(o2));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode(Object x) throws HibernateException {
		return x.hashCode();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object replace(Object original, Object target, Object owner) throws HibernateException {
		return original;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Class<?> returnedClass() {
		return this.type.getReturnedClass();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int[] sqlTypes() {
		return new int[] { this.type.sqlType() };
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isMutable() {
		return this.type.isMutable();
	}
}
