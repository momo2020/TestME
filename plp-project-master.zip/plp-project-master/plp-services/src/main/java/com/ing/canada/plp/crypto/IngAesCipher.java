/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.crypto;

import java.security.Key;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * Utility class to encrypt and decrypt strings or byte arrays of arbitrary length. AES symetric cryptography is used,
 * with CBC mode. Encrypted data is a string in base 64 format. A text string is converted to and from byte array using
 * the <a href="http://en.wikipedia.org/wiki/UTF-8">UTF8 encoding</a>. Therefore, US-ASCII characters (digits and
 * letters without accents) will take one byte while other Latin and diacrytic characters will take 2 bytes. It requires
 * a 128, 192 or 256 bit key in capi-services.properties. Key greater than 128 bits requires the "unlimited jurisdiction
 * policy files": local_policy.jar and US_export_policy.jar. They are available from <a
 * href="http://2w234f1:8080/xwiki/bin/view/Projets/">our Wiki</a> or <a
 * href="http://www-128.ibm.com/developerworks/java/jdk/security/50">IBM developerWorks</a>. <br>
 * Note that encrypting or decrypting <code>null</code> will return <code>null</code>.<br>
 * <b>Encrypted data length:</b> <br>
 * <code>encryptedBytes = ceiling((decryptedBytes + 1) / 16) * 16</code> <br>
 * <b>Examples of decrypted length and matching encrypted lengths:</b> <br>
 * <code>
 * Decrypted String   Decrypted Bytes   Encrypted Bytes   Encrypted Base 64 String
 *       0                    0                 16                   24
 *       1                   1-2                16                   24
 *       7                   7-14               16                   24
 *       8                   8-16              16-32                24-44
 *       9                   9-18              16-32                24-44
 *      15                  15-30              16-32                24-44
 *      16                  16-32              32-48                44-64
 *      17                  17-34              32-48                44-64
 *      23                  23-46              32-48                44-64
 *      24                  24-48              32-64                44-88
 *      25                  25-50              32-64                44-88
 *      31                  31-62              32-64                44-88
 *      32                  32-64              48-80                64-108
 *      33                  33-66              48-80                64-108
 * </code>
 * 
 * @author Simon Legault
 */
@Component
public class IngAesCipher implements IIngCipher {
    
    /** Character encoding used when converting the original text to bytes and the decrypted bytes to text. */
    private static final String CHARACTER_ENCODING = "UTF8";
    
    /** Encryption algorithm. */
    private static final String ALGORITHM = "AES";
    
    /** Transformation: encryption algorithm/mode/padding. */
    private static final String TRANSFORMATION = ALGORITHM + "/CBC/PKCS5Padding";
    
    /** Data used as the initialization vector: random, arbitrary 16-byte sequence. */
    private static byte[] INITIALIZATION_VECTOR = { (byte) 0xE4, (byte) 0x8C, (byte) 0x59, (byte) 0xA5, (byte) 0x7B,
            (byte) 0x18, (byte) 0xF2, (byte) 0x7D, (byte) 0x73, (byte) 0x9B, (byte) 0x21, (byte) 0x59, (byte) 0x7F,
            (byte) 0x4E, (byte) 0x16, (byte) 0xCF };
    
    /** Initialization vector. Used by CBC mode in the first block. */
    private static final AlgorithmParameterSpec initializationVector = new IvParameterSpec(INITIALIZATION_VECTOR);
    
    private static final int MIN_KEY_BIT_LENTGTH = 128;
    
    private static final int MED_KEY_BIT_LENTGTH = 192;
    
    private static final int MAX_KEY_BIT_LENTGTH = 256;
    
    private static final int MIN_KEY_HEXA_LENTGTH = MIN_KEY_BIT_LENTGTH / 4;
    
    /** Hexadecimal representation of the key. */
    @Autowired
    @Qualifier("cipherKey")
    private String cipherKey;
    
    /**
     * Creates the Cipher required to encrypt or decrypt data.
     * 
     * @param mode Either <code>Cipher.DECRYPT_MODE</code> or <code>Cipher.ENCRYPT_MODE</code>.
     * @return New and initialized Cipher, ready to use.
     * @throws Exception
     */
    private Cipher createCipher(int mode) throws Exception {
        if (this.cipherKey == null || this.cipherKey.length() < MIN_KEY_HEXA_LENTGTH) {
            throw new Exception("IngAesCipher.key not set or smaller than " + MIN_KEY_HEXA_LENTGTH
                    + " hexadecimal characters.");
        }
        // Computes the maximum key length, in bits.
        int hexaKeyBitLength = this.cipherKey.length() * 4;
        int keyBitLength;
        if (hexaKeyBitLength >= MAX_KEY_BIT_LENTGTH) {
            keyBitLength = MAX_KEY_BIT_LENTGTH;
        } else if (hexaKeyBitLength >= MED_KEY_BIT_LENTGTH) {
            keyBitLength = MED_KEY_BIT_LENTGTH;
        } else {
            keyBitLength = MIN_KEY_BIT_LENTGTH;
        }
        byte[] key = hexaToBytes(this.cipherKey);
        // Note: truncates the key to keyBitLength bits.
        Key keySpec = new SecretKeySpec(key, 0, keyBitLength / 8, ALGORITHM);
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        
        cipher.init(mode, keySpec, initializationVector);
        return cipher;
    }
    
    /**
     * Decodes <code>hexaString</code> hexadecimal string into a byte array. <code>hexaString</code>'s last
     * character will be ignored if <code>hexaString</code>'s length is odd.
     * 
     * @param hexaString Hexadecimal string to be converted to byte array.
     * @return A byte array that is the binary equivalent to <code>hexaString</code>.
     * @throws Exception
     */
    private static byte[] hexaToBytes(String hexaString) throws Exception {
        byte[] decodedBytes = new byte[hexaString.length() / 2];
        for (int i = 0; i < decodedBytes.length; i++) {
            int index = i + i;
            decodedBytes[i] = (byte) Integer.parseInt(hexaString.substring(index, index + 2), 16);
        }
        return decodedBytes;
    }
    
    /** {@inheritDoc} */
    @Override
	public byte[] decrypt(String encryptedString) throws Exception {
        byte[] decryptedBytes = null;
        if (encryptedString != null) {
            byte[] encryptedBytes = Base64Helper.base64ToBytes(encryptedString);
            decryptedBytes = createCipher(Cipher.DECRYPT_MODE).doFinal(encryptedBytes);
        }
        return decryptedBytes;
    }
    
    /** {@inheritDoc} */
    @Override
	public String decryptToString(String encryptedString) throws Exception {
        String decryptedString = null;
        if (encryptedString != null) {
            byte[] decryptedBytes = decrypt(encryptedString);
            decryptedString = new String(decryptedBytes, CHARACTER_ENCODING);
        }
        return decryptedString;
    }
    
    /** {@inheritDoc} */
    @Override
	public String encrypt(byte[] decryptedBytes) throws Exception {
        String encryptedString = null;
        if (decryptedBytes != null) {
            byte[] encryptedBytes = createCipher(Cipher.ENCRYPT_MODE).doFinal(decryptedBytes);
            encryptedString = Base64Helper.bytesToBase64(encryptedBytes);
        }
        return encryptedString;
    }
    
    /** {@inheritDoc} */
    @Override
	public String encryptString(String decryptedString) throws Exception {
        String encryptedString = null;
        if (decryptedString != null) {
            encryptedString = encrypt(decryptedString.getBytes(CHARACTER_ENCODING));
        }
        return encryptedString;
    }
}
