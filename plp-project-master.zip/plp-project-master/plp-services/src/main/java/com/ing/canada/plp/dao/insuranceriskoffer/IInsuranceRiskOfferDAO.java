/*
 * Important notice: This software is the sole property of Intact insurance Inc. and
 * cannot be distributed and/or copied without the written permission of Intact insurance
 * Inc.
 *
 * Copyright (c) 2009, Intact insurance Inc., All rights reserved.
 */
package com.ing.canada.plp.dao.insuranceriskoffer;

import java.sql.SQLException;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.enums.InternalTechnicalOfferTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer;

/**
 * The Interface IInsuranceRiskOfferDAO.
 */
public interface IInsuranceRiskOfferDAO extends IBaseDAO<InsuranceRiskOffer> {

	/**
	 * Finds the insurance risk offer associated to the insurance risk and of the given internal offer type
	 * 
	 * @param aRisk Insurance risk
	 * @param anInternal internal offer type
	 * @return Insurance risk offer.
	 */
	public InsuranceRiskOffer findByInternalOfferType(InsuranceRisk aRisk, InternalTechnicalOfferTypeCodeEnum anInternal);

	/**
	 * Clone for kanetix.
	 * 
	 * @param anInsuranceRiskOffer the insurance risk offer
	 * 
	 * @return the ID of the insurance risk offer of type M
	 * 
	 * @throws SQLException the clone exception
	 */
	public Long cloneForKanetix(InsuranceRiskOffer anInsuranceRiskOffer) throws SQLException;
	
	
	public void cloneOffer(InsuranceRiskOffer source, InsuranceRiskOffer destination) throws SQLException;

}
