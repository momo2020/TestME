package com.ing.canada.plp.dao.party;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.party.Address;

/**
 * The Interface IAddressDAO.
 */
public interface IAddressDAO extends IBaseDAO<Address> {
	// NOOP
}
