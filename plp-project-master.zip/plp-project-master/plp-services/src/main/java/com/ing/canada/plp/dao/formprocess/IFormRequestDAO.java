package com.ing.canada.plp.dao.formprocess;

import java.util.Date;
import java.util.List;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.formprocess.FormRequest;

public interface IFormRequestDAO extends IBaseDAO<FormRequest>{
	public List<FormRequest> getRepport(String formName, Date startDate, Date endDate);
}
