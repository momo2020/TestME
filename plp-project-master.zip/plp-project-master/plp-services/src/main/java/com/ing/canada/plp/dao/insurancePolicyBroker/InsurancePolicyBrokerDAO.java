package com.ing.canada.plp.dao.insurancePolicyBroker;

import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import oracle.jdbc.OracleTypes;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ing.canada.plp.dao.IManufacturingContextDAO;
import com.ing.canada.plp.domain.ManufacturingContext;
import com.ing.canada.plp.domain.enums.DistributionChannelCodeEnum;
import com.ing.canada.plp.domain.enums.InsuranceBusinessCodeEnum;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;
import com.ing.canada.plp.domain.enums.UserActivityTypeCodeEnum;
import com.ing.canada.plp.mapper.InsurancePolicyBrokerInfoSPMapper;
import com.ing.canada.plp.report.insurancePolicy.InsurancePolicyBrokerInfo;
import com.ing.canada.plp.report.insurancePolicy.InsurancePolicyNoteInfo;
import com.ing.canada.plp.report.insurancePolicy.criteria.QuoteSearchCriteria;

/**
 * The Class InsurancePolicyBrokerDAO.
 */
@Repository
public class InsurancePolicyBrokerDAO implements IInsurancePolicyBrokerDAO {

	/** The Constant log. */
	private static final Log log = LogFactory.getLog(InsurancePolicyBrokerDAO.class);

	/**
	 * The JPA entity manager.
	 */
	@PersistenceContext(unitName = "plpolicy_persistence_unit")
	protected EntityManager entityManager;

	/** The jdbc template. */
	@Autowired
	@Qualifier("jdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	/** The manufacturing context dao. */
	@Autowired
	private IManufacturingContextDAO manufacturingContextDAO;

	/*
	 * (non-Javadoc)
	 * 
	 * BR5828 - Items Displayed per Regional Access
	 * 
	 * @see
	 * com.ing.canada.plp.dao.insurancePolicyBroker.IInsurancePolicyBrokerDAO
	 * #getInsurancePolicyBrokerList()
	 */
	@Override
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<InsurancePolicyBrokerInfo> getInsurancePolicyBrokerList(List<String> availableMasters, Integer aNbrOfDayLeft, ProvinceCodeEnum aProvinceCode,
			String aSubBrokerCompanyNumber, ManufacturerCompanyCodeEnum aManufacturerCompanyCode, boolean adminRole, int maxRow) {

		ManufacturingContext manufacturerContext = new ManufacturingContext();
		manufacturerContext.setDistributionChannel(DistributionChannelCodeEnum.THROUGH_BROKERS);
		manufacturerContext.setInsuranceBusiness(InsuranceBusinessCodeEnum.REGULAR);
		manufacturerContext.setProvince(aProvinceCode);
		manufacturerContext.setManufacturerCompany(aManufacturerCompanyCode);

		ManufacturingContext result = this.manufacturingContextDAO.getByAllProperties(manufacturerContext);

		Session session = (Session) this.entityManager.getDelegate();
		org.hibernate.Query query;
		if (adminRole) {
			query = session.getNamedQuery("getInsurancePolicyBrokerListForAllMasters");
			query.setParameter("nbrOfDaysLeft", aNbrOfDayLeft);
			query.setParameter("provinceCd", aProvinceCode.getCode());
			query.setParameter("subBrokerCompanyNbr", aSubBrokerCompanyNumber);
			query.setParameter("manufacturerCompanyID", result.getId());
		} else {
			query = session.getNamedQuery("getInsurancePolicyBrokerListForParamMasters");
			query.setParameterList("masters", availableMasters);
			query.setParameter("provinceCd", aProvinceCode.getCode());
			query.setParameter("nbrOfDaysLeft", aNbrOfDayLeft);
			query.setParameter("subBrokerCompanyNbr", aSubBrokerCompanyNumber);
			query.setParameter("manufacturerCompanyID", result.getId());
		}

		query.setParameter("maxRow", maxRow);
		return mapInsurancePolicyPolicyBrokerList(query.list());
	}

	/**
	 * Map insurance policy policy broker list.
	 * 
	 * @param result
	 *            the result
	 * 
	 * @return the list< insurance policy broker info>
	 */
	private List<InsurancePolicyBrokerInfo> mapInsurancePolicyPolicyBrokerList(List<Object[]> result) {
		List<InsurancePolicyBrokerInfo> list = new ArrayList<InsurancePolicyBrokerInfo>();
		InsurancePolicyBrokerInfo info;
		InsurancePolicyNoteInfo noteInfo;
		for (Object[] res : result) {
			info = (InsurancePolicyBrokerInfo) res[0];
			noteInfo = (InsurancePolicyNoteInfo) res[1];
			if (!list.contains(info)) {
				list.add(info);
			}
			if (noteInfo != null) {
				if (UserActivityTypeCodeEnum.ADD_NOTE.equals(noteInfo.getUserActivityType())) {
					info.setLastFollowupNote(noteInfo);
				} else {
					info.setLastActivityNote(noteInfo);
				}
			}
		}
		return list;
	}

	/**
	 * The Class InsurancePolicyBrokerProcedure encapsulates the call to
	 * "PLPADMIN.SEARCH_QUOTE.SEARCH_QUOTE_BROKER" stored proc. BR5828 - Items
	 * Displayed per Regional Access BR5594 Search Quotes - Value to use when
	 * default value is selected BR5592 Search Quotes - Accessible Owners:
	 * BR5175 When selected, only return quotes with the corresponding Client
	 * Contact status. BR5384 When selected, only return quotes with the
	 * corresponding quote source. 1. Intact Web Site: Quotes initiated from the
	 * Intact Insurance web site. 2. Broker Web Site: Quotes initiated from the
	 * web site of a participating broker. 3. Both: Quote ini: BR5177 When
	 * selected, only return quotes with the corresponding Quote Status.:
	 * 
	 */
	public class InsurancePolicyBrokerProcedure extends StoredProcedure {
		private static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
		
		private static final String STORED_PROC_NAME = "plpadmin.search_quote.search_quote_broker";

		private static final String INSURANCE_POLICY_BROKER_INFO_LIST = "iPolicyBrokerInfosCursor";
		
		private static final String SELECTED_MASTER_IN_PARAM = "t_selected_master";

		private static final String SELECTED_POINT_OF_SALE_IN_PARAM = "t_selected_point_of_sale";

		private static final String QUOTE_REF_NUMBER_IN_PARAM = "t_quote_ref_number";

		private static final String QUOTE_REF_LEGACY_NUMBER_IN_PARAM = "t_quote_ref_legacy_number";

		private static final String POSTAL_CODE_IN_PARAM = "t_postal_code";

		private static final String TELEPHONE_IN_PARAM = "t_telephone";

		private static final String LASTNAME_IN_PARAM = "t_last_name";

		private static final String FIRSTNAME_IN_PARAM = "t_first_name";

		private static final String LAST_UPDATE_FROM_IN_PARAM = "t_last_update_from";

		private static final String LAST_UPDATE_TO_IN_PARAM = "t_last_update_to";

		private static final String EMAIL_IN_PARAM = "t_email";

		private static final String SELECTED_CLIENT_FOLLOWUPS_IN_PARAM = "t_selected_client_followUp";

		private static final String SELECTED_QUOTE_STATUS_IN_PARAM = "t_selected_quote_status";

		private static final String SELECTED_QUOTE_SOURCE_IN_PARAM = "t_external_system_origin";

		private static final String USER_ACCOUNT_ID_PARAM = "t_user";

		private static final String PROVINCE_PARAM = "t_province";

		private static final String MANUFACTURER_COMPANY_PARAM = "t_manuf_company";

		private static final String SUBBROKER_COMPANY_NBR_PARAM = "t_sub_company_nbr";

		private static final String CREATION_DATE_FROM_IN_PARAM = "t_creation_date_from";

		private static final String CREATION_DATE_TO_IN_PARAM = "t_creation_date_to";
		
		private static final String CANCELED_BROKERS_IN_PARAM = " t_cancelled_broker";

		private static final String NEW_BROKER_QUOTE_IN_PARAM = " t_token_ind";

		private static final String UNSTRUCTUREDNAME_IN_PARAM = "t_unstructured_name";
		
		private static final String LINE_OF_BUSINESS_PARAM = "t_line_of_business_cd";
		
		private static final String INACTIVE_POS_ONLY_IN_PARAM = " t_inactive_pos_only";

		/**
		 * Methods allows to init the store procedure - call the stored
		 * procedure - declares the input parameter - declares resulSet objects
		 * 
		 * @param jdbcTemplateToSet
		 */
		
		public InsurancePolicyBrokerProcedure(JdbcTemplate jdbcTemplateToSet) {
			super(jdbcTemplateToSet, STORED_PROC_NAME);

			// SqlOutParameter DECLARES an out parameter to be used in the
			// stored procedure call
			// IMPORTANT: To prevent compilation issue always declare output
			// parameter first
			declareParameter(new SqlOutParameter(INSURANCE_POLICY_BROKER_INFO_LIST, OracleTypes.CURSOR, new InsurancePolicyBrokerInfoSPMapper()));

			// SqlParameter declares an in parameter
			declareParameter(new SqlParameter(SELECTED_MASTER_IN_PARAM, Types.VARCHAR));
			declareParameter(new SqlParameter(SELECTED_POINT_OF_SALE_IN_PARAM, Types.VARCHAR));

			declareParameter(new SqlParameter(QUOTE_REF_NUMBER_IN_PARAM, Types.VARCHAR));
			declareParameter(new SqlParameter(QUOTE_REF_LEGACY_NUMBER_IN_PARAM, Types.VARCHAR));

			declareParameter(new SqlParameter(POSTAL_CODE_IN_PARAM, Types.VARCHAR));
			declareParameter(new SqlParameter(TELEPHONE_IN_PARAM, Types.VARCHAR));

			declareParameter(new SqlParameter(LASTNAME_IN_PARAM, Types.VARCHAR));
			declareParameter(new SqlParameter(FIRSTNAME_IN_PARAM, Types.VARCHAR));

			declareParameter(new SqlParameter(LAST_UPDATE_FROM_IN_PARAM, Types.VARCHAR));
			declareParameter(new SqlParameter(LAST_UPDATE_TO_IN_PARAM, Types.VARCHAR));

			declareParameter(new SqlParameter(EMAIL_IN_PARAM, Types.VARCHAR));

			declareParameter(new SqlParameter(SELECTED_CLIENT_FOLLOWUPS_IN_PARAM, Types.VARCHAR));

			declareParameter(new SqlParameter(SELECTED_QUOTE_STATUS_IN_PARAM, Types.VARCHAR));
			declareParameter(new SqlParameter(SELECTED_QUOTE_SOURCE_IN_PARAM, Types.VARCHAR));

			declareParameter(new SqlParameter(USER_ACCOUNT_ID_PARAM, Types.VARCHAR));

			declareParameter(new SqlParameter(PROVINCE_PARAM, Types.VARCHAR));
			declareParameter(new SqlParameter(MANUFACTURER_COMPANY_PARAM, Types.VARCHAR));
			declareParameter(new SqlParameter(SUBBROKER_COMPANY_NBR_PARAM, Types.VARCHAR));

			declareParameter(new SqlParameter(CREATION_DATE_FROM_IN_PARAM, Types.VARCHAR));
			declareParameter(new SqlParameter(CREATION_DATE_TO_IN_PARAM, Types.VARCHAR));
			
			declareParameter(new SqlParameter(CANCELED_BROKERS_IN_PARAM, Types.VARCHAR));

			declareParameter(new SqlParameter(NEW_BROKER_QUOTE_IN_PARAM, Types.VARCHAR));

			declareParameter(new SqlParameter(UNSTRUCTUREDNAME_IN_PARAM, Types.VARCHAR));
			
			declareParameter(new SqlParameter(LINE_OF_BUSINESS_PARAM, Types.VARCHAR));
			
			declareParameter(new SqlParameter(INACTIVE_POS_ONLY_IN_PARAM, Types.VARCHAR));

			compile();
		}

		/**
		 * Executes the SP by passing the parameters values
		 * 
		 * BR5828 - Items Displayed per Regional Access BR5594 Search Quotes -
		 * Value to use when default value is selected BR5592 Search Quotes -
		 * Accessible Owners: BR5175 When selected, only return quotes with the
		 * corresponding Client Contact status. BR5384 When selected, only
		 * return quotes with the corresponding quote source. 1. Intact Web
		 * Site: Quotes initiated from the Intact Insurance web site. 2. Broker
		 * Web Site: Quotes initiated from the web site of a participating
		 * broker. 3. Both: Quote ini: BR5177 When selected, only return quotes
		 * with the corresponding Quote Status.:
		 * 
		 * @param theSearchCriteria
		 * @param aProvinceCode
		 * @param aSubBrokerCompanyNumber
		 * @param aManufacturerCompanyCode
		 * @return
		 */
		private Map<String, Object> execute(QuoteSearchCriteria theSearchCriteria, ProvinceCodeEnum aProvinceCode, String aSubBrokerCompanyNumber,
				ManufacturerCompanyCodeEnum aManufacturerCompanyCode) {

			Map<String, Object> inputs = new HashMap<String, Object>();

			inputs.put(SELECTED_MASTER_IN_PARAM, theSearchCriteria.getSelectedMaster());
			inputs.put(SELECTED_POINT_OF_SALE_IN_PARAM, theSearchCriteria.getSelectedPointOfSale());

			inputs.put(QUOTE_REF_NUMBER_IN_PARAM, !theSearchCriteria.isAgreementLegacyNumber() && theSearchCriteria.getAgreementNumber() != null ? theSearchCriteria.getAgreementNumber().toUpperCase() : null);
			inputs.put(QUOTE_REF_LEGACY_NUMBER_IN_PARAM, theSearchCriteria.isAgreementLegacyNumber() && theSearchCriteria.getAgreementNumber() != null ? theSearchCriteria.getAgreementNumber().toUpperCase() : null);

			inputs.put(POSTAL_CODE_IN_PARAM, theSearchCriteria.getPostalCode() != null ? theSearchCriteria.getPostalCode().toUpperCase() : null);
			inputs.put(TELEPHONE_IN_PARAM, StringUtils.isBlank(theSearchCriteria.getTelephone()) ? null : theSearchCriteria.getTelephone());

			inputs.put(LASTNAME_IN_PARAM, theSearchCriteria.getLastName());
			inputs.put(FIRSTNAME_IN_PARAM, theSearchCriteria.getFirstName());

			inputs.put(LAST_UPDATE_FROM_IN_PARAM, theSearchCriteria.getFrom() != null ? this.getDateFormatYYYYMMDD(theSearchCriteria.getFrom()) : null);
			inputs.put(LAST_UPDATE_TO_IN_PARAM, theSearchCriteria.getTo() != null ? this.getDateFormatYYYYMMDD(theSearchCriteria.getTo()) : null);

			inputs.put(EMAIL_IN_PARAM, theSearchCriteria.getEmail());

			inputs.put(SELECTED_CLIENT_FOLLOWUPS_IN_PARAM, theSearchCriteria.getSelectedClientFollowUp());

			inputs.put(SELECTED_QUOTE_STATUS_IN_PARAM, theSearchCriteria.getSelectedQuoteStatus());

			inputs.put(SELECTED_QUOTE_SOURCE_IN_PARAM, theSearchCriteria.getSelectedQuoteSource());

			inputs.put(USER_ACCOUNT_ID_PARAM, theSearchCriteria.getUserId());

			inputs.put(PROVINCE_PARAM, aProvinceCode.getCode());

			inputs.put(MANUFACTURER_COMPANY_PARAM, aManufacturerCompanyCode.getCode());

			inputs.put(SUBBROKER_COMPANY_NBR_PARAM, aSubBrokerCompanyNumber);

			inputs.put(CREATION_DATE_FROM_IN_PARAM,
					theSearchCriteria.getCreationDateFrom() != null ? this.getDateFormatYYYYMMDD(theSearchCriteria.getCreationDateFrom()) : null);

			inputs.put(CREATION_DATE_TO_IN_PARAM,
					theSearchCriteria.getCreationDateTo() != null ? this.getDateFormatYYYYMMDD(theSearchCriteria.getCreationDateTo()) : null);

			inputs.put(CANCELED_BROKERS_IN_PARAM, theSearchCriteria.isClosedBrokerQuotes() ? true : null);

			inputs.put(NEW_BROKER_QUOTE_IN_PARAM, theSearchCriteria.isNewBrokerQuotes() ? "Y" : null);

			inputs.put(UNSTRUCTUREDNAME_IN_PARAM, theSearchCriteria.getBusinessName());
			
			inputs.put(LINE_OF_BUSINESS_PARAM, theSearchCriteria.getLineOfBusiness());
			
			inputs.put(INACTIVE_POS_ONLY_IN_PARAM, theSearchCriteria.isInactivePOSOnly() ? "Y" : null);

			return super.execute(inputs);
		}

		/**
		 * Format a Date according to given Format YYYY-MM-dd
		 * 
		 * @param aDateToFormat
		 *            the date to format
		 * @return Date in String format YYYY-MM-dd
		 */
		private String getDateFormatYYYYMMDD(Date aDateToFormat) {
			final DateFormat formatter = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
			return formatter.format(aDateToFormat);
		}
	}

	/**
	 * (non-Javadoc)
	 * 
	 * BR5828 - Items Displayed per Regional Access
	 * 
	 * @see com.ing.canada.plp.dao.insurancePolicyBroker.IInsurancePolicyBrokerDAO#getInsurancePolicyBrokerListSP(com.ing.canada.plp.report.insurancePolicy.criteria.QuoteSearchCriteria,
	 *      com.ing.canada.plp.domain.enums.ProvinceCodeEnum, java.lang.String,
	 *      com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<InsurancePolicyBrokerInfo> getInsurancePolicyBrokerListSP(QuoteSearchCriteria theSearchCriteria, ProvinceCodeEnum aProvinceCode,
			String aSubBrokerCompanyNumber, ManufacturerCompanyCodeEnum aManufacturerCompanyCode) {

		InsurancePolicyBrokerProcedure anInsurancePolicyBrokerProcedure = new InsurancePolicyBrokerProcedure(this.jdbcTemplate);

		log.info("Executing call to stored procedure: " + anInsurancePolicyBrokerProcedure.getSql());
		Map<String, Object> result = anInsurancePolicyBrokerProcedure.execute(theSearchCriteria, aProvinceCode, aSubBrokerCompanyNumber,
				aManufacturerCompanyCode);

		return (List<InsurancePolicyBrokerInfo>) result.get(InsurancePolicyBrokerProcedure.INSURANCE_POLICY_BROKER_INFO_LIST);
	}
	
	
}
