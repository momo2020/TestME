package com.ing.canada.plp.dao.insurancerisk;

import java.util.List;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.insurancerisk.AdditionalInterestRole;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Interface IAdditionalInterestRoleDAO.
 */
public interface IAdditionalInterestRoleDAO extends IBaseDAO<AdditionalInterestRole> {

	/**
	 * This method must return all claims associated to the PolicyVersion, 
	 * the one of the Party or of the InsuranceRisk. 
	 * The claim should not be present more than once in the list.
	 * 
	 * @param policyVersion
	 * @return
	 */
	List<AdditionalInterestRole> findAllAdditionalInterestByPolicyVersion(PolicyVersion policyVersion);
}
