package com.ing.canada.plp.dao.formprocess;

import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.formprocess.FormRequest;
@Repository
public class FormRequestDAO extends BaseDAO<FormRequest> implements IFormRequestDAO {

	@Override
	@SuppressWarnings("unchecked")
	public List<FormRequest> getRepport(String formName, Date startDate, Date endDate) {
		Session session = (Session) this.entityManager.getDelegate();
		List<FormRequest> it = session
				.createQuery(
						"select formRequest from Form as form join form.formRequests as formRequest where form.name = :formName" +
						" AND formRequest.auditTrail.createTimestamp BETWEEN  :startDate AND :endDate")
				.setParameter("startDate", startDate).setParameter("endDate", endDate)
				.setString("formName", formName)
				.list();
		return it;
	}
}
