package com.ing.canada.plp.dao.insurancerisk;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.insurancerisk.Trailer;

/**
 * The Interface ITrailerDAO.
 */
public interface ITrailerDAO extends IBaseDAO<Trailer> {
	// NOOP
}
