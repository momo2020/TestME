package com.ing.canada.plp.dao.insuranceriskoffer;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.insuranceriskoffer.SubCoveragePremiumOffer;

/**
 * The Class SubCoveragePremiumOfferDAO.
 */
@Repository
public class SubCoveragePremiumOfferDAO extends BaseDAO<SubCoveragePremiumOffer> implements ISubCoveragePremiumOfferDAO {
	// NOOP
}
