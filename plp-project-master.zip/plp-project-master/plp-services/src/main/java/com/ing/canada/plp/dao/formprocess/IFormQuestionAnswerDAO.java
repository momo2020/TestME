package com.ing.canada.plp.dao.formprocess;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.formprocess.FormQuestionAnswer;

public interface IFormQuestionAnswerDAO extends IBaseDAO<FormQuestionAnswer>{

}
