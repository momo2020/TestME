/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.insurancepolicy;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.enums.AgreementTypeCodeEnum;
import com.ing.canada.plp.domain.insurancepolicy.InsurancePolicy;

/**
 * The Class InsurancePolicyDAO.
 */
@Repository
public class InsurancePolicyDAO extends BaseDAO<InsurancePolicy> implements IInsurancePolicyDAO {

	/**
	 * Find an insurancepolicy by agreement number.
	 * 
	 * @param agreementNumber the agreement number
	 * 
	 * @return the insurance policy
	 */
	@Override
	public InsurancePolicy findByAgreementNumber(String agreementNumber) {

		Session session = (Session) this.entityManager.getDelegate();
		return (InsurancePolicy) session.createCriteria(InsurancePolicy.class).add(
				Restrictions.eq("agreementNumber", agreementNumber)).addOrder(Order.desc("auditTrail.createTimestamp"))
				.setMaxResults(1).uniqueResult();
	}

	/**
	 * Find all the Insurance policies for a specific CIF ID and agreement type.
	 * 
	 * @param cifId the cif id
	 * @param agreementTypeCode the agreement type code
	 * 
	 * @return the list< insurance policy>
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<InsurancePolicy> findAllInsurancePolicyForCifId(Long cifId, AgreementTypeCodeEnum agreementTypeCode) {

		List<InsurancePolicy> listInsurancePolicy = null;
		try {
			Query query = this.entityManager.createNamedQuery("InsurancePolicy.findAllInsurancePolicyForCifId");
			query.setParameter("agreementTypeCode", agreementTypeCode);
			query.setParameter("cifId", cifId);
			listInsurancePolicy = query.getResultList();
		} catch (NoResultException nex) {
			listInsurancePolicy = new ArrayList<InsurancePolicy>();
		}
		return listInsurancePolicy;
	}

	/**
	 * Find all the Insurance policies for a specific TAM UniqueID.
	 * 
	 * @param tamUniqueId
	 * 
	 * @return the list< insurance policy>
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<InsurancePolicy> findAllForTamUniqueId(Long tamUniqueId) {

		Session session = (Session) this.entityManager.getDelegate();
		return session.createCriteria(InsurancePolicy.class)
					.add(Restrictions.eq("tamUniqueId", tamUniqueId)).addOrder(Order.desc("auditTrail.createTimestamp"))
					.list();
		
	}
	
	/**
	 * Find the last Insurance policies for a specific TAM UniqueID.
	 * 
	 * @param tamUniqueId
	 * 
	 * @return the insurance policy
	 */
	@Override
	public InsurancePolicy findLastForTamUniqueId(Long tamUniqueId) {

		Session session = (Session) this.entityManager.getDelegate();
		return (InsurancePolicy)session.createCriteria(InsurancePolicy.class)
					.add(Restrictions.eq("tamUniqueId", tamUniqueId))
					.addOrder(Order.desc("id"))
					.setMaxResults(1).uniqueResult();
					
		
	}
	
	/**
	 * Find the last Insurance policies for a specific email.
	 * 
	 * @param email
	 * 
	 * @return the insurance policy
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<InsurancePolicy>  findAllForEmail(String email) {

		List<InsurancePolicy> listInsurancePolicy = null;
		try {
			Query query = this.entityManager.createNamedQuery("InsurancePolicy.findAllInsurancePolicyForEmail");
			query.setParameter("email", email);
			listInsurancePolicy = query.getResultList();
		} catch (NoResultException nex) {
			listInsurancePolicy = new ArrayList<InsurancePolicy>();
		}
		return listInsurancePolicy;
		
	}
	
	/**
	 * @see com.ing.canada.plp.dao.insurancepolicy.IInsurancePolicyDAO#findRatedPolicies(java.util.Date)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<InsurancePolicy> findRatedPolicies(Date dateToTest) {
		List<InsurancePolicy> listInsurancePolicy = null;
		try {
			Query query = this.entityManager.createNamedQuery("InsurancePolicy.findRatedPolicies");
			query.setParameter("dateToTest", dateToTest);
			query.setParameter("quotation", com.ing.canada.plp.domain.enums.AgreementTypeCodeEnum.QUOTATION);
			query.setParameter("bind",
					com.ing.canada.plp.domain.enums.TransactionStatusCodeEnum.BIND_IN_PROGRESS_BUT_NOT_CONFIRM);
			query.setParameter("offer", com.ing.canada.plp.domain.enums.TransactionStatusCodeEnum.GET_OFFER);
			query.setParameter("submitted",
					com.ing.canada.plp.domain.enums.TransactionStatusCodeEnum.SUBMITTED_BY_THE_REQUESTER);
			query.setParameter("interventionWithPremium",
					com.ing.canada.plp.domain.enums.TransactionStatusCodeEnum.INTERVENTION_REQUIRED_PREMIUM_AVAILABLE);
			listInsurancePolicy = query.getResultList();
		} catch (NoResultException nex) {
			listInsurancePolicy = new ArrayList<InsurancePolicy>();
		}
		return listInsurancePolicy;
	}
	
	/**
	 * Find all unexpired insurance policy for a tam unique id.
	 * 
	 * @param tamUniqueId the tam unique id
	 * 
	 * @return the list< insurance policy>
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<InsurancePolicy> findAllUnexpiredInsurancePolicyForTamUniqueId(Long tamUniqueId) {

		List<InsurancePolicy> listInsurancePolicy = null;
		try {
			Query query = this.entityManager.createNamedQuery("InsurancePolicy.findAllUnexpiredInsurancePolicyForTamUniqueId");
			query.setParameter("tamUniqueId", tamUniqueId);
			listInsurancePolicy = query.getResultList();
		} catch (NoResultException nex) {
			listInsurancePolicy = new ArrayList<InsurancePolicy>();
		}
		return listInsurancePolicy;
	}
	
	/**
	 * Find all unexpired insurance policy for a tam unique id in BROKER SCENARIO.
	 * 
	 * @param tamUniqueId the tam unique id
	 * @param insurancePolicyId the insurance policy id
	 * 
	 * @return the list< insurance policy>
	 */
	@SuppressWarnings("unchecked")
	public List<InsurancePolicy> findAllUnexpiredInsurancePolicyForTamUniqueIdAndInsurancePolicyId(Long tamUniqueId, Long insurancePolicyId) {

		List<InsurancePolicy> listInsurancePolicy = null;
		try {
			Query query = this.entityManager.createNamedQuery("InsurancePolicy.findAllUnexpiredInsurancePolicyForTamUniqueIdAndInsurancePolicyId");
			query.setParameter("tamUniqueId", tamUniqueId);
			query.setParameter("insurancePolicyId", insurancePolicyId);
			listInsurancePolicy = query.getResultList();
		} catch (NoResultException nex) {
			listInsurancePolicy = new ArrayList<InsurancePolicy>();
		}
		return listInsurancePolicy;
	}
	
	/**
	 * Find all unexpired insurance policy for a email address.
	 * 
	 * @param anEmail the email address
	 * 
	 * @see com.ing.canada.plp.dao.insurancepolicy.IInsurancePolicyDAO#findAllUnexpiredInsurancePolicyForEmail(java.lang.String)
	 * @return the list< insurance policy>
	 */	
	@Override
	@SuppressWarnings("unchecked")
	public List<InsurancePolicy> findAllUnexpiredInsurancePolicyForEmail(String anEmail) {

		List<InsurancePolicy> listInsurancePolicy = null;
		try {
			Query query = this.entityManager.createNamedQuery("InsurancePolicy.findAllUnexpiredInsurancePolicyForEmail");
			query.setParameter("email", anEmail);
			listInsurancePolicy = query.getResultList();
		} catch (NoResultException nex) {
			listInsurancePolicy = new ArrayList<InsurancePolicy>();
		}
		return listInsurancePolicy;
	}
	
	/**
	 * Find all unexpired insurance policy for an email address and insurance policy id in BROKER SCENARIO.
	 * 
	 * @param anEmail the email address	 
	 * @param insurancePolicyId the insurance policy id	 
	 * 	
	 * @see com.ing.canada.plp.dao.insurancepolicy.IInsurancePolicyDAO#findAllUnexpiredInsurancePolicy(java.lang.String, java.lang.Long)
	 * @return the list< insurance policy>
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<InsurancePolicy> findAllUnexpiredInsurancePolicy(String anEmail, Long insurancePolicyId) {

		List<InsurancePolicy> listInsurancePolicy = null;
		try {
			Query query = this.entityManager.createNamedQuery("InsurancePolicy.findAllUnexpiredInsurancePolicy");
			query.setParameter("email", anEmail);
			query.setParameter("listMasterOwnerNbr", findAllMasterOwnerNbr(insurancePolicyId));
			listInsurancePolicy = query.getResultList();
		} catch (NoResultException nex) {
			listInsurancePolicy = new ArrayList<InsurancePolicy>();
		}
		return listInsurancePolicy;
	}
	
	/**
	 * Find all master Owner nbr for a specific Insurance Policy Id
	 *
	 * @param insurancePolicyId the insurance policy id  *   * @return Formatted String
	 */
	@SuppressWarnings("unchecked")
	private String findAllMasterOwnerNbr(Long insurancePolicyId) {
		// Get list of all unique masterOwnerNbr
		StringBuilder sb = new StringBuilder("");
		sb.append(" SELECT DISTINCT bri_1.master_owner_nbr " );
		sb.append("   FROM plpadmin.sub_broker_assignment sba_1,");
		sb.append("        cifadmin.sub_brokers sb_1,");
		sb.append("        cifadmin.broker_infos bri_1");
		sb.append("  WHERE bri_1.subroker_nbr = sb_1.sub_broker_number");
		sb.append("    AND sb_1.sub_broker = sba_1.cif_sub_broker_id");
		sb.append("    AND sba_1.insurance_policy_id = :insurancePolicyId");
		
		Query query = this.entityManager.createNativeQuery(sb.toString());
		
		query.setParameter("insurancePolicyId", insurancePolicyId);
		List<String> results = query.getResultList();
		String str = "";
		Iterator<String> iterator = results.iterator();
		while (iterator.hasNext()) {
			if (StringUtils.isNotEmpty(str)) {
				str += ",";
			}
			str += "'" + iterator.next().toString() + "'";
		}
		
		return str;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public InsurancePolicy findByAgreementLegacyNumber(String agreementLegacyNumber) {
		Session session = (Session) this.entityManager.getDelegate();
		return (InsurancePolicy) session.createCriteria(InsurancePolicy.class).add(
				Restrictions.eq("agreementLegacyNumber", agreementLegacyNumber)).addOrder(Order.desc("auditTrail.createTimestamp"))
				.setMaxResults(1).uniqueResult();
	}
	
	/**
	 * Find Insurance Policy by given id.
	 * 
	 * @param aInsurancePolicyId
	 *            the Insurance Policy Id
	 * 
	 * @return the Insurance Policy
	 * 
	 */
	@Override
	public InsurancePolicy findInsurancePolicyById(Long aInsurancePolicyId) {

		if (aInsurancePolicyId == null) {
			throw new IllegalArgumentException("insurance policy id is mandatory");
		}

		Session session = (Session) this.entityManager.getDelegate();
		org.hibernate.Query query = session.getNamedQuery("InsurancePolicy.findInsurancePolicyById");
		query.setParameter("insurancePolicyId", aInsurancePolicyId);
		InsurancePolicy insurancePolicy = (InsurancePolicy) query.uniqueResult();
		return insurancePolicy;
	}
	
	
	/**
	 * @see com.ing.canada.plp.dao.insurancepolicy.IInsurancePolicyDAO#findRatedPolicies(java.util.Date)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<InsurancePolicy> findAllInsurancePolicyForRetrieveWEBBK(String lastName, String anEmail, Date birthDate, String masterOwnerNbr) {
		List<InsurancePolicy> listInsurancePolicy = null;
		try {
			Query query = this.entityManager.createNamedQuery("InsurancePolicy.findAllInsurancePolicyForRetrieveWEBBK");
			query.setParameter("lastName", lastName);
			query.setParameter("email", anEmail);
			query.setParameter("birthDate", birthDate);
			query.setParameter("masterOwnerNbr", masterOwnerNbr);
			listInsurancePolicy = query.getResultList();
		} catch (NoResultException nex) {
			listInsurancePolicy = new ArrayList<InsurancePolicy>();
		}
		return listInsurancePolicy;
	}
	
	/**
	 * @see com.ing.canada.plp.dao.insurancepolicy.IInsurancePolicyDAO#findRatedPolicies(java.util.Date)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<InsurancePolicy> findAllInsurancePolicyForRetrieveIntact(String lastName, String anEmail, Date birthDate) {
		List<InsurancePolicy> listInsurancePolicy = null;
		try {
			Query query = this.entityManager.createNamedQuery("InsurancePolicy.findAllInsurancePolicyForRetrieveINTACT");
			query.setParameter("lastName", lastName);
			query.setParameter("email", anEmail);
			query.setParameter("birthDate", birthDate);
			listInsurancePolicy = query.getResultList();
		} catch (NoResultException nex) {
			listInsurancePolicy = new ArrayList<InsurancePolicy>();
		}
		return listInsurancePolicy;
	}
	
	
	/**
	 *
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<InsurancePolicy> findAllInsurancePolicyForEmailWEBBK(String anEmail, String masterOwnerNbr) {
		List<InsurancePolicy> listInsurancePolicy = null;
		try {
			Query query = this.entityManager.createNamedQuery("InsurancePolicy.findAllInsurancePolicyForEmailWEBBK");
			query.setParameter("email", anEmail);
			query.setParameter("masterOwnerNbr", masterOwnerNbr);
			listInsurancePolicy = query.getResultList();
		} catch (NoResultException nex) {
			listInsurancePolicy = new ArrayList<InsurancePolicy>();
		}
		return listInsurancePolicy;
	}
	
	/**
	 *
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<InsurancePolicy> findAllInsurancePolicyForEmailIntact(String anEmail) {
		List<InsurancePolicy> listInsurancePolicy = null;
		try {
			Query query = this.entityManager.createNamedQuery("InsurancePolicy.findAllInsurancePolicyForEmailINTACT");
			query.setParameter("email", anEmail);
			listInsurancePolicy = query.getResultList();
		} catch (NoResultException nex) {
			listInsurancePolicy = new ArrayList<InsurancePolicy>();
		}
		return listInsurancePolicy;
	}
	
	
	
}
