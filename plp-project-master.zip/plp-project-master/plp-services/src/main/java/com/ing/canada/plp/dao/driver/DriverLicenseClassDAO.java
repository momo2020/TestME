package com.ing.canada.plp.dao.driver;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.driver.DriverLicenseClass;

/**
 * The Class DriverLicenseClassDAO.
 */
@Repository
public class DriverLicenseClassDAO extends BaseDAO<DriverLicenseClass> implements IDriverLicenseClassDAO {
	// NOOP
}
