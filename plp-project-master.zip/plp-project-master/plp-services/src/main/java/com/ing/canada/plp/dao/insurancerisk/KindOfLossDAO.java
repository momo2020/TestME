package com.ing.canada.plp.dao.insurancerisk;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.insurancerisk.KindOfLoss;

/**
 * The Class KindOfLossDAO.
 */
@Repository
public class KindOfLossDAO extends BaseDAO<KindOfLoss> implements IKindOfLossDAO {
	// NOOP
}
