package com.ing.canada.plp.dao.businesstransaction;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.businesstransaction.TransactionalMessageElement;

/**
 * The Class TransactionalMessageElementDAO.
 */
@Repository
public class TransactionalMessageElementDAO extends BaseDAO<TransactionalMessageElement> implements ITransactionalMessageElementDAO {

	// noop
}
