/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance
* Copyright (c) 2010, Intact Insurance, All rights reserved.<br>
*/
package com.ing.canada.plp.dao.insuranceriskoffer;

import java.util.List;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.enums.EndorsementCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.CoveragePremiumOffer;

/**
 * The Interface ICoveragePremiumOfferDAO.
 */
public interface ICoveragePremiumOfferDAO extends IBaseDAO<CoveragePremiumOffer> {
	
	
	/**
	 * Gets the coverage premium offers.
	 * 
	 * @param aInsuranceRiskOfferId the a insurance risk offer id
	 * @param aRatingRiskOfferId the a rating risk offer id
	 * 
	 * @return the coverage premium offers
	 */
	List<CoveragePremiumOffer> getCoveragePremiumOffers(Long aInsuranceRiskOfferId, Long aRatingRiskOfferId);
	
	/**
	 * Return the list of non basic coverage associated to the insurance risk offer
	 * @param aInsuranceRiskOfferId
	 * @param aRatingRiskOfferId
	 * @return
	 */
	List<CoveragePremiumOffer> getNonBasicCoveragePremiumOffer(Long aInsuranceRiskOfferId, Long aRatingRiskOfferId);
	
	/**
	 * Return the list of Selected basic coverage associated to the insurance risk offer
	 * @param aInsuranceRiskOfferId
	 * @param aRatingRiskOfferId
	 * @return
	 */
	List<CoveragePremiumOffer> getSelectedBasicCoveragePremiumOffer(Long aInsuranceRiskOfferId, Long aRatingRiskOfferId);
	
	
	List<CoveragePremiumOffer> getSpecificSelectedNonBasicCoveragePremiumOffer(Long aInsuranceRiskOfferId, Long aRatingRiskOfferId, EndorsementCodeEnum codeEnum);

	/**
	 * Gets the coverage premium offers on policy offer rating.
	 * 
	 * @param aPolicyOfferRatingId the a policy offer rating id
	 * 
	 * @return the coverage premium offers on policy offer rating
	 */
	List<CoveragePremiumOffer> getCoveragePremiumOffersOnPolicyOfferRating(Long aPolicyOfferRatingId);

}
