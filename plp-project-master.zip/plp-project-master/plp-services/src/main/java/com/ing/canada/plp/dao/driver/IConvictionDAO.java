package com.ing.canada.plp.dao.driver;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.driver.Conviction;

/**
 * The Interface IConvictionDAO.
 */
public interface IConvictionDAO extends IBaseDAO<Conviction> {
	// NOOP
}
