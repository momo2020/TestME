package com.ing.canada.plp.dao.base;

import com.ing.canada.plp.domain.usertype.BaseEntity;


/**
 * The Interface IBaseEntityDAO.
 * @author R�gis Brochu
 */
public interface IBaseEntityDAO extends IBaseDAO<BaseEntity> {


	/** 
	 * 
	 * @param aClzz
	 * @param id
	 * @return
	 */
	BaseEntity findEntityById(Class<?> aClzz, Long id);
	
}
