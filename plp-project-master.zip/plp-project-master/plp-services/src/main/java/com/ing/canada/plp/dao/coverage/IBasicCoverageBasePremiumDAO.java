/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance 
* Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
*/
package com.ing.canada.plp.dao.coverage;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.coverage.BasicCoverageBasePremium;

/**
 * The Interface IBasicCoverageBasePremiumDAO.
 */
public interface IBasicCoverageBasePremiumDAO extends IBaseDAO<BasicCoverageBasePremium> {
	// NOOP
}
