package com.ing.canada.plp.dao.insuranceriskoffer;

import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.dao.base.BaseEntityDAO;
import com.ing.canada.plp.domain.insuranceriskoffer.RatingRiskOffer;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Class RatingRiskOfferDAO.
 */
@Repository
public class RatingRiskOfferDAO extends BaseDAO<RatingRiskOffer> implements IRatingRiskOfferDAO {

	/** The logger. */
	protected final Log log = LogFactory.getLog(BaseEntityDAO.class);
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<RatingRiskOffer> findAllRatingRiskOffersByPolicyVersion(PolicyVersion aPolicyVersion) {

		Query query = this.entityManager.createNamedQuery("RatingRiskOffer.findAllRatingRiskOffers");
		query.setParameter("policyVersion", aPolicyVersion);

		try {
			return query.getResultList();
		} catch (NoResultException nrex) {
			this.log.trace("<NoResultException>" + nrex);			
		}
		return null;
	}
}
