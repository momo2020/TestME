/*
 * Important notice: This software is the sole property of Intact insurance Inc. and
 * cannot be distributed and/or copied without the written permission of Intact insurance
 * Inc.
 *
 * Copyright (c) 2009, Intact insurance Inc., All rights reserved.
 */
package com.ing.canada.plp.dao.diagnostics;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.diagnostics.DiagnosticAutomatedAdvice;

/**
 * The Class DiagnosticAutomatedAdviceDAO.
 */
@Repository
public class DiagnosticAutomatedAdviceDAO extends BaseDAO<DiagnosticAutomatedAdvice> implements IDiagnosticAutomatedAdviceDAO {
	// NOOP
}
