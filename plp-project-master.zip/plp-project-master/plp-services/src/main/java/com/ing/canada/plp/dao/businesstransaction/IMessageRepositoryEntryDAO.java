package com.ing.canada.plp.dao.businesstransaction;

import com.ing.canada.plp.dao.base.IBaseRepositoryDAO;
import com.ing.canada.plp.domain.businesstransaction.MessageRepositoryEntry;

/**
 * The Interface IMessageRepositoryEntryDAO.
 */
public interface IMessageRepositoryEntryDAO extends IBaseRepositoryDAO<MessageRepositoryEntry> {
	
	
	MessageRepositoryEntry findByMessageId(String messageId);
}
