package com.ing.canada.plp.dao.insurancerisk;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Interface IInsuranceRiskDAO.
 */
public interface IInsuranceRiskDAO extends IBaseDAO<InsuranceRisk> {

	/**
	 * Find by sequence.
	 * 
	 * @param aPolicyVersion the a policy version
	 * @param aSequence the a sequence
	 * 
	 * @return the insurance risk
	 */
	InsuranceRisk findBySequence(PolicyVersion aPolicyVersion, Short aSequence);
}
