/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.businesstransaction;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.transform.DistinctRootEntityResultTransformer;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.DriverInfo;
import com.ing.canada.plp.domain.VehicleInfo;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransaction;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransactionSubActivity;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransactionSubActivityComplementInfo;
import com.ing.canada.plp.domain.enums.BusinessTransactionSubActivityCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * The Class BusinessTransactionSubActivityDAO.
 */
@Repository
public class BusinessTransactionSubActivityDAO extends BaseDAO<BusinessTransactionSubActivity> implements
		IBusinessTransactionSubActivityDAO {

	/**
	 * @see com.ing.canada.plp.dao.businesstransaction.IBusinessTransactionSubActivityDAO#findDateOfFirstTransactionSubActivity(java.lang.Long,
	 *      com.ing.canada.plp.domain.enums.BusinessTransactionSubActivityCodeEnum)
	 */
	@Override
	public Date findDateOfFirstTransactionSubActivity(Long businessTransactionId,
			BusinessTransactionSubActivityCodeEnum subActivityCode) {

		Query query = this.entityManager
				.createNamedQuery("BusinessTransactionSubActivity.findDateOfFirstTransactionSubActivity");
		query.setParameter("businessTransactionId", businessTransactionId);
		query.setParameter("businessTrxSubActivityCode", subActivityCode);

		try {
			return (Date) query.getSingleResult();
		} catch (NoResultException nrex) {
			this.log.info("No business transaction sub-activity with code [" + subActivityCode
					+ "] was found for business transaction id [" + businessTransactionId + "]");
		}

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public BusinessTransactionSubActivityComplementInfo findLastSubActivityComplementInfo(Long activityId) {

		Query q = this.entityManager
				.createNamedQuery("BusinessTransactionSubActivity.findLastSubActivityComplementInfo");
		q.setParameter("businessTransactionActivityId", activityId);

		try {
			return (BusinessTransactionSubActivityComplementInfo) q.getSingleResult();
		} catch (NoResultException e) {
			this.log
					.info("No complement info in the list of business transaction sub-activities for business transaction activity id ["
							+ activityId + "]");
		}

		return null;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<BusinessTransactionSubActivity> retrieveAllSubActivityForPolicyVersion(BusinessTransaction businessTransaction) {

		Query q = this.entityManager
				.createNamedQuery("BusinessTransactionSubActivity.retrieveAllSubActivityForPolicyVersion");
		q.setParameter("businessTransaction", businessTransaction);

		try {
			return q.getResultList();
		} catch (NoResultException e) {
			this.log.info("No business sub activities under business trasaction id[" + businessTransaction.getId()
					+ "]");
		}

		return new ArrayList<BusinessTransactionSubActivity>();
	}

	@Override
	public long countNumberOfModifyCoverageUnderInsuranceOffer(InsuranceRiskOffer offer) {

		Query q = this.entityManager
				.createNamedQuery("BusinessTransactionSubActivity.countNumberOfSubActivityUnderInsuranceOffer");
		q.setParameter("insuranceRiskOffer", offer);
		try {
			return (Long) q.getSingleResult();
		} catch (NoResultException e) {
			this.log.info("Error in Query BusinessTransactionSubActivity.countNumberOfSubActivityUnderInsuranceOffer");
		}

		return 0L;
	}
	
	/**
	 * @see com.ing.canada.plp.dao.businesstransaction.IBusinessTransactionSubActivityDAO#findLastSubActivity(Long))
	 */
	@Override
	@SuppressWarnings("deprecation")
	public BusinessTransactionSubActivity findLastSubActivity(Long businessTrxId) {
		Session session = (Session) this.entityManager.getDelegate();
		org.hibernate.Query q = session.getNamedQuery("BusinessTransactionSubActivity.findLastSubActivity");
		// filters duplicates
		q.setResultTransformer(DistinctRootEntityResultTransformer.INSTANCE);
		q.setParameter("businessTrxId", businessTrxId);		
		
		BusinessTransactionSubActivity last = (BusinessTransactionSubActivity) q.uniqueResult();
		
		return last;
	}
	
	
	
	@Override
	@SuppressWarnings("unchecked")
	public List<BusinessTransactionSubActivity> findAllSubActivityWithCodeAndReferenceId(
			BusinessTransactionSubActivityCodeEnum anActivityCode, BaseEntity anEntity) {
		List<BusinessTransactionSubActivity> businessTransactionSubActivities = new ArrayList<BusinessTransactionSubActivity>();
		Query q = this.entityManager
				.createNamedQuery("BusinessTransactionSubActivity.findAllSubActivityWithCodeAndReferenceId");
		q.setParameter("rootReferenceId", anEntity.getId());
		q.setParameter("subActivityCode", anActivityCode);

		businessTransactionSubActivities = q.getResultList();

		return businessTransactionSubActivities;	
	}
	
	
	
	/**
	 * 
	 * @see com.ing.canada.plp.dao.businesstransaction.IBusinessTransactionSubActivityDAO#findLastSubActivityWithCode(java.lang.Long, com.ing.canada.plp.domain.enums.BusinessTransactionSubActivityCodeEnum[])
	 */
	@Override
	public BusinessTransactionSubActivity findLastSubActivityWithCode(Long businessTrxId, BusinessTransactionSubActivityCodeEnum... subActivityCodes) {
		Session session = (Session) this.entityManager.getDelegate();
		org.hibernate.Query q = session.getNamedQuery("BusinessTransactionSubActivity.findLastSubActivityWithCode");
		// filters duplicates
		q.setResultTransformer(DistinctRootEntityResultTransformer.INSTANCE); 
		q.setParameterList("subActivityCodeList", subActivityCodes);
		q.setParameter("businessTrxId", businessTrxId);		
		
		BusinessTransactionSubActivity last = (BusinessTransactionSubActivity) q.uniqueResult();
		
		return last;
	}

	@Override
	public VehicleInfo findInfoForCoverageRootReference(Long rootReferenceId) {
		Session session = (Session) this.entityManager.getDelegate();
		org.hibernate.Query q = session.getNamedQuery("BusinessTransactionSubActivity.findInfoForCoverageRootReference");
		q.setParameter("rootReferenceId", rootReferenceId);		
		
		VehicleInfo vehicle = (VehicleInfo) q.uniqueResult();
		
		return vehicle;
	}

	@Override
	public DriverInfo findInfoForDriverRootReference(Long rootReferenceId) {
		Session session = (Session) this.entityManager.getDelegate();
		org.hibernate.Query q = session.getNamedQuery("BusinessTransactionSubActivity.findInfoForDriverRootReference");
		q.setParameter("rootReferenceId", rootReferenceId);		
		
		DriverInfo driver = (DriverInfo) q.uniqueResult();
		
		return driver;
	}

	@Override
	public VehicleInfo findInfoForVehicleRootReference(Long rootReferenceId) {
		Session session = (Session) this.entityManager.getDelegate();
		org.hibernate.Query q = session.getNamedQuery("BusinessTransactionSubActivity.findInfoForVehicleRootReference");
		q.setParameter("rootReferenceId", rootReferenceId);		
		
		VehicleInfo vehicle = (VehicleInfo) q.uniqueResult();
		
		return vehicle;
	}
	
	
}
