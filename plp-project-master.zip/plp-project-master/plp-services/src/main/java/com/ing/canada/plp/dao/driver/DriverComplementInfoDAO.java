package com.ing.canada.plp.dao.driver;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.DistinctRootEntityResultTransformer;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.driver.DriverComplementInfo;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Class DriverComplementInfoDAO.
 */
@Repository
public class DriverComplementInfoDAO extends BaseDAO<DriverComplementInfo> implements IDriverComplementInfoDAO {

	/**
	 * Find by sequence.
	 * 
	 * @param aPolicyVersion the a policy version
	 * @param aSequence the a sequence
	 * 
	 * @return the driver complement info
	 * 
	 * @see com.ing.canada.plp.dao.driver.IDriverComplementInfoDAO#findBySequence(com.ing.canada.plp.domain.policyversion.PolicyVersion,
	 *      java.lang.Integer)
	 */
	@Override
	public DriverComplementInfo findBySequence(PolicyVersion aPolicyVersion, Integer aSequence) {
		Session session = (Session) this.entityManager.getDelegate();

		Criteria driverComplementCriteria = session.createCriteria(DriverComplementInfo.class);
		driverComplementCriteria.add(Restrictions.eq("driverSequence", aSequence))
			.createCriteria("party")
			 // to avoid duplicate load of DriverComplementInfo (eager in Party)
				.setFetchMode("driveComplementInfo", FetchMode.SELECT)
				.add(Restrictions.eq("policyVersion", aPolicyVersion));

		return (DriverComplementInfo) driverComplementCriteria.uniqueResult();
	}

	/**
	 * Returns all driver complement info attached to this policy version. We use the relation to the party to get the
	 * information.
	 * 
	 * @param aPolicyVersion
	 * @return
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<DriverComplementInfo> findAllByPolicyVersion(PolicyVersion aPolicyVersion) {
		Session session = (Session) this.entityManager.getDelegate();

		Criteria criteria = session.createCriteria(DriverComplementInfo.class);
		criteria.createCriteria("party")
		// to avoid duplicate load of DriverComplementInfo (eager in Party)
			.setFetchMode("driveComplementInfo", FetchMode.SELECT) 
			.add(Restrictions.eq("policyVersion", aPolicyVersion));

		criteria.setResultTransformer(DistinctRootEntityResultTransformer.INSTANCE);

		return criteria.list();
	}

}
