package com.ing.canada.plp.dao.coverage;

import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.DistinctRootEntityResultTransformer;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.coverage.Coverage;
import com.ing.canada.plp.domain.enums.InternalTechnicalOfferTypeCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.CoverageOffer;
import com.ing.canada.plp.domain.insuranceriskoffer.PolicyOfferRating;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Class CoverageDAO.
 */
@Repository
public class CoverageDAO extends BaseDAO<Coverage> implements ICoverageDAO {

	/**
	 * {@inheritDoc}
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<Coverage> findAllCoveragesByPolicyVersion(PolicyVersion aPolicyVersion) {

		Session session = (Session) this.entityManager.getDelegate();

		Criteria coverageCriteria = session.createCriteria(Coverage.class);
		coverageCriteria.createCriteria("insuranceRisk").add(Restrictions.eq("policyVersion", aPolicyVersion));

		coverageCriteria.setResultTransformer(DistinctRootEntityResultTransformer.INSTANCE);

		return coverageCriteria.list();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<CoverageOffer> findAllCoverageOffersByPolicyVersion(PolicyVersion aPolicyVersion) {

		Query query = this.entityManager.createNamedQuery("CoverageOffer.findAllSelectedCoverageOffers");
		query.setParameter("policyVersion", aPolicyVersion);

		try {
			return query.getResultList();
		} catch (NoResultException nrex) {
			this.log.debug("no record returnd by the query, no result exception is handled gracefully");
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<CoverageOffer> findAllCoverageOffersByPolicyVersionAndInternalOfferType(PolicyVersion aPolicyVersion,
			InternalTechnicalOfferTypeCodeEnum anInternal) {
		Query query = this.entityManager
				.createNamedQuery("CoverageOffer.findAllSelectedCoverageOffersForInternalOfferType");
		query.setParameter("policyVersion", aPolicyVersion);
		query.setParameter("internalOfferType", anInternal);

		try {
			return query.getResultList();
		} catch (NoResultException nrex) {
			this.log.trace("No results found !");
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<CoverageOffer> findAllCoverageOffersByPolicyOfferRatingAndCoverageGroup(PolicyOfferRating aPlOffer,
			String aCode) {
		Query query = this.entityManager
				.createNamedQuery("CoverageOffer.findAllCoverageOffersByPolicyOfferRatingAndCoverageGroup");
		query.setParameter("por", aPlOffer);
		query.setParameter("cd", aCode);

		try {
			return query.getResultList();
		} catch (NoResultException nrex) {
			this.log.debug("no record returnd by the query, no result exception is handled gracefully");
		} catch (Exception ex) {
			this.log.debug("************************************ aCode "+aCode);
			this.log.debug(ex);
		}
		return null;
	}
}
