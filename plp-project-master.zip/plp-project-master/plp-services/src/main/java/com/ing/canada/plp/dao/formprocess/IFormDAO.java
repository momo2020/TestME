package com.ing.canada.plp.dao.formprocess;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.formprocess.Form;

public interface IFormDAO extends IBaseDAO<Form>{

}
