/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.businesstransaction;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransactionSubActivityComplementInfo;

/**
 * The Class BusinessTransactionSubActivityComplementInfoDao.
 */
@Repository
public class BusinessTransactionSubActivityComplementInfoDAO extends
		BaseDAO<BusinessTransactionSubActivityComplementInfo> implements
		IBusinessTransactionSubActivityComplementInfoDAO {
	// NOOP
}
