package com.ing.canada.plp.dao.coverage;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.coverage.CoveragePremium;

/**
 * The Interface ICoveragePremiumDAO.
 */
public interface ICoveragePremiumDAO extends IBaseDAO<CoveragePremium> {
	// NOOP
}
