package com.ing.canada.plp.dao;

import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.NoResultException;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.IPRestriction;
import com.ing.canada.plp.domain.enums.IPRestrictionTypeCodeEnum;

/**
 * The Class IPRestrictionDAO.
 */
@Repository
public class IPRestrictionDAO extends BaseDAO<IPRestriction> implements IIPRestrictionDAO {

	

	/** The jdbc template. */
	@Autowired
	@Qualifier("jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	/** The Constant IP NUMBER. */
	public static final String IP_NUMBER = "ipNumber";
	public static final String RESTRICTION_CODE = "restrictionTypeCode";
	
	/**
	 * 
	 */
	@Override
	public List<IPRestriction> findByIPNumber(String ipNumber) {
		return findByProperty(IP_NUMBER, ipNumber);
	}

	@Override
	@SuppressWarnings("unchecked")
	public IPRestriction getEffectiveRestrictionForIP(String ipNumber) {
		
		List<IPRestriction> listRestrictions = null;
		try {
			Session session = (Session) this.entityManager.getDelegate();

			org.hibernate.Query query = session.getNamedQuery("IPRestriction.getEffectiveRestrictionForIP");
			query.setParameter("ipNumber", ipNumber);

			listRestrictions = query.list();

		} catch (NoResultException nex) {
			return null;
		}
		return (listRestrictions.size()>0 ? listRestrictions.get(0) : null);
		
	}

	/**
	 * {inheritDoc}
	 */
	@Override
	@SuppressWarnings("unchecked")
	public IPRestriction getEffectiveRestrictionForIP(String ipNumber, IPRestrictionTypeCodeEnum restrictionCode) {
		
		List<IPRestriction> listRestrictions = null;
		try {
			Session session = (Session) this.entityManager.getDelegate();

			org.hibernate.Query query = session.getNamedQuery("IPRestriction.getEffectiveRestrictionForIPAndCode");
			query.setParameter("ipNumber", ipNumber);
			query.setParameter("restrictionCode", restrictionCode);
			
			String sql= query.getQueryString();

			listRestrictions = query.list();

		} catch (NoResultException nex) {
			return null;
		}
		return (listRestrictions.size()>0 ? listRestrictions.get(0) : null);
	}

	
	/**
	 * The Class ReassignSubBrokerIntactStoredProcedure encapsulates the call to the clone stored
	 * proc.
	 */
	public class ReassignSubBrokerIntactStoredProcedure extends StoredProcedure {
		private static final String STORED_PROC_NAME = "plpadmin.soa_reassign_sub_bkr_intact";
		private static final String IP_NBR_PARAM = "pi_ip_nbr";
		private static final String SUB_BROKER_PARAM = "pi_sub_broker_number";
		private static final String NBR_REASSIGN_PARAM = "po_nb_reassigned";


		public ReassignSubBrokerIntactStoredProcedure(JdbcTemplate jdbcTemplateToSet) {
			super(jdbcTemplateToSet, STORED_PROC_NAME);
			declareParameter(new SqlParameter(IP_NBR_PARAM, Types.VARCHAR));
			declareParameter(new SqlParameter(SUB_BROKER_PARAM,Types.VARCHAR));
			declareParameter(new SqlOutParameter(NBR_REASSIGN_PARAM, Types.BIGINT));
		}

		public Long execute(String ipNumber, String subBrokerNumber) {

			Map<String, Object> inputs = new HashMap<String, Object>();
			inputs.put(IP_NBR_PARAM, ipNumber);
			inputs.put(SUB_BROKER_PARAM, subBrokerNumber);

			Map<String, Object> result =  super.execute(inputs);
			
			return (Long)result.get(NBR_REASSIGN_PARAM);
		}
	}
	
	@Override
	public Long reassignSubBroker(String ipNumber, String subBrokerNumber) {

		ReassignSubBrokerIntactStoredProcedure reassignStoredProcedure = new ReassignSubBrokerIntactStoredProcedure(jdbcTemplate);
		Long spResult = reassignStoredProcedure.execute(ipNumber, subBrokerNumber);
		return spResult;
	}


}
