package com.ing.canada.plp.dao.coverage;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.coverage.SubCoveragePremium;

/**
 * The Interface ISubCoveragePremiumDAO.
 */
public interface ISubCoveragePremiumDAO extends IBaseDAO<SubCoveragePremium> {
	// NOOP
}
