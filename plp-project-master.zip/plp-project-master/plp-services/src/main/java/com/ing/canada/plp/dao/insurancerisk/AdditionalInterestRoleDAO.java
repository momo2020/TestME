package com.ing.canada.plp.dao.insurancerisk;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.DistinctRootEntityResultTransformer;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.insurancerisk.AdditionalInterestRole;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Class AdditionalInterestRoleDAO.
 */
@Repository
public class AdditionalInterestRoleDAO extends BaseDAO<AdditionalInterestRole> implements IAdditionalInterestRoleDAO {

	
	/**
	 * 
	 * {@inheritDoc}
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<AdditionalInterestRole> findAllAdditionalInterestByPolicyVersion(PolicyVersion aPolicyVersion) {

		Session session = (Session) this.entityManager.getDelegate();

		Criteria ratingRiskCriteria = session.createCriteria(AdditionalInterestRole.class);
		ratingRiskCriteria.createCriteria("vehicle").createCriteria("insuranceRisk").add(Restrictions.eq("policyVersion", aPolicyVersion));

		ratingRiskCriteria.setResultTransformer(DistinctRootEntityResultTransformer.INSTANCE);

		return ratingRiskCriteria.list();
	}
}
