package com.ing.canada.plp.dao.driver;

import java.util.List;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.driver.DriverComplementInfo;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Interface IDriverComplementInfoDAO.
 */
public interface IDriverComplementInfoDAO extends IBaseDAO<DriverComplementInfo> {

	/**
	 * This method returns the DriverComplementInfo of a PolicyVersion having a particular sequence number.<br>
	 * It returns NULL if no vehicle exists.
	 * 
	 * @param aPolicyVersion the a policy version
	 * @param aSequence the a sequence
	 * 
	 * @return the driver complement info
	 */
	DriverComplementInfo findBySequence(PolicyVersion aPolicyVersion, Integer aSequence);
	
	
	/**
	 * Returns all driver complement info attached to this policy version. 
	 * We use the relation to the party to get the information.
	 * 
	 * @param aPolicyVersion
	 * @return
	 */
	List<DriverComplementInfo> findAllByPolicyVersion(PolicyVersion aPolicyVersion);

}
