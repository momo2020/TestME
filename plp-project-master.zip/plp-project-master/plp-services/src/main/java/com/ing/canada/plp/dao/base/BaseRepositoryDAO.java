/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.base;

import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.criterion.Example;

import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * Base dao for repository entry.
 * 
 * @author fsimard
 * @param <E> Entity
 */
public abstract class BaseRepositoryDAO<E extends BaseEntity> extends BaseDAO<E> implements IBaseRepositoryDAO<E> {

	/**
	 * Get the list of fields to exclude from search by example.
	 * 
	 * @return list of fields to exclude
	 */
	protected String[] getExcludeProperties() {
		return new String[] {};
	}

	/**
	 * Gets the by all properties.
	 * 
	 * @param aEntity the a entity
	 * 
	 * @return the by all properties
	 * 
	 * @see com.ing.canada.plp.dao.base.IBaseRepositoryDAO#getByAllProperties(com.ing.canada.plp.domain.usertype.BaseEntity)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public E getByAllProperties(E aEntity) {

		Session session = (Session) this.entityManager.getDelegate();

		Example example = Example.create(aEntity);

		example.excludeNone();
		
		for (String excludeProperty : getExcludeProperties()) {
			example.excludeProperty(excludeProperty);
		}

		E result = (E) session.createCriteria(getEntityClass()).add(example).setFlushMode(FlushMode.MANUAL)
				.uniqueResult();

		return result;
	}

}
