package com.ing.canada.plp.dao.party;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.party.Consent;

/**
 * The Class ConsentDAO.
 */
@Repository
public class ConsentDAO extends BaseDAO<Consent> implements IConsentDAO {
	// NOOP
}
