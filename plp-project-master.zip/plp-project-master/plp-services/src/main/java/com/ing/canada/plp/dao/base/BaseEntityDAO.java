/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.base;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * entities.
 * 
 * Transaction control of the save(), update() and delete() operations can directly support Spring container-managed
 * transactions or they can be augmented to handle user-managed Spring transactions. Each of these methods provides
 * additional information for how to configure it for the desired type of transaction control.
 * 
 * @see com.ing.canada.plp.domain.party.MunicipalityRepositoryEntry
 * @author Patrick Lafleur
 */
@Repository
public class BaseEntityDAO extends BaseDAO<BaseEntity> implements IBaseEntityDAO {

	/**
	 * @see com.ing.canada.plp.dao.base.IBaseEntityDAO#findEntityById(java.lang.Class, java.lang.Long)
	 */
	@Override
	public BaseEntity findEntityById(Class<?> aClzz, Long id) {

		// plafleur - previously, a Criteria was used to generate a finder by id. Why find() wasn't used in the first place?
    	return (BaseEntity) this.entityManager.find(aClzz, id);
    	
	}

}
