package com.ing.canada.plp.dao.businesstransaction;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransactionSubActivityComplementInfo;

/**
 * The Interface IBusinessTransactionSubActivityComplementInfoDao.
 */
public interface IBusinessTransactionSubActivityComplementInfoDAO extends
		IBaseDAO<BusinessTransactionSubActivityComplementInfo> {
	// NOOP
}
