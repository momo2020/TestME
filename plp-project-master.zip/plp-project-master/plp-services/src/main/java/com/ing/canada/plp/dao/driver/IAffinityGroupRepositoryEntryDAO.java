/**
 * 
 */
package com.ing.canada.plp.dao.driver;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.driver.AffinityGroupRepositoryEntry;

/**
 * @author ub8169
 *
 */
public interface IAffinityGroupRepositoryEntryDAO extends IBaseDAO<AffinityGroupRepositoryEntry>{
	// noop
}
