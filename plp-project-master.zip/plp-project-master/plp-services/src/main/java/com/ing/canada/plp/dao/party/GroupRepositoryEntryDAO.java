/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2017, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.party;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.hibernate.FlushMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.IManufacturingContextDAO;
import com.ing.canada.plp.dao.base.BaseRepositoryDAO;
import com.ing.canada.plp.domain.BusinessContext;
import com.ing.canada.plp.domain.ManufacturingContext;
import com.ing.canada.plp.domain.enums.PartyGroupTypeCodeEnum;
import com.ing.canada.plp.domain.enums.PartySubGroupTypeCodeEnum;
import com.ing.canada.plp.domain.party.GroupRepositoryEntry;
import com.ing.canada.plp.domain.policyversion.DirectChanDistRepEntry;

/**
 * The Class GroupRepositoryEntryDAO.
 */
@Repository
public class GroupRepositoryEntryDAO extends BaseRepositoryDAO<GroupRepositoryEntry> implements
		IGroupRepositoryEntryDAO {

	@Inject
	private IManufacturingContextDAO contextDAO = null;

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String[] getExcludeProperties() {
		return new String[] { "id", "expiryDate", "effectiveDate" };
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public GroupRepositoryEntry findGroupRepositoryEntry(PartyGroupTypeCodeEnum partyGroupType, String partyGroupCode,
			PartySubGroupTypeCodeEnum partySubGroupType, String partySubGroupCode,
			ManufacturingContext manufacturingContext, DirectChanDistRepEntry directChanDistRepEntry)
			throws IllegalArgumentException {

		Session session = (Session) this.entityManager.getDelegate();

		if (partyGroupType == null || StringUtils.isBlank(partyGroupCode) || partySubGroupType == null
				|| StringUtils.isBlank(partySubGroupCode)) {
			throw new IllegalArgumentException("Arguments cannot be null for findGroupRepositoryEntry");
		}

		Object result = session.getNamedQuery("GroupRepositoryEntry.findGroupRepositoryEntry")
				.setParameter("partyGroupType", partyGroupType).setParameter("partyGroupCode", partyGroupCode)
				.setParameter("partySubGroupType", partySubGroupType)
				.setParameter("partySubGroupCode", partySubGroupCode)
				.setParameter("manufacturingContext", manufacturingContext)
				.setParameter("directChanDistRepEntry", directChanDistRepEntry).setFlushMode(FlushMode.MANUAL)
				.setMaxResults(1).uniqueResult();

		return (result == null) ? null : (GroupRepositoryEntry) result;

	}

	@Override
	public GroupRepositoryEntry findGroupRepositoryEntry(PartyGroupTypeCodeEnum partyGroupType, String partyGroupCode,
			PartySubGroupTypeCodeEnum partySubGroupType, String partySubGroupCode,
			ManufacturingContext manufacturingContext, String insuredGroup,
			DirectChanDistRepEntry directChanDistRepEntry) throws IllegalArgumentException {

		Session session = (Session) this.entityManager.getDelegate();

		Object result = session.getNamedQuery("GroupRepositoryEntry.findForInsuredGroup")
				.setParameter("partyGroupType", partyGroupType).setParameter("partyGroupCode", partyGroupCode)
				.setParameter("insuredGroup", insuredGroup).setParameter("partySubGroupType", partySubGroupType)
				.setParameter("partySubGroupCode", partySubGroupCode)
				.setParameter("manufacturingContext", manufacturingContext)
				.setParameter("directChanDistRepEntry", directChanDistRepEntry).setFlushMode(FlushMode.MANUAL)
				.setMaxResults(1).uniqueResult();

		return (result == null) ? null : (GroupRepositoryEntry) result;

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<GroupRepositoryEntry> findGroupRepositoryEntry(BusinessContext businessContext,
			PartyGroupTypeCodeEnum partyGroupTypeCode) throws IllegalArgumentException {

		Session session = (Session) this.entityManager.getDelegate();

		ManufacturingContext manufacturingContext = businessContext.getManufacturingContext();

		if (manufacturingContext.getId() == null) {
			manufacturingContext = this.getContextDAO().getByAllProperties(manufacturingContext);
		}

		Query result = session.getNamedQuery("GroupRepositoryEntry.findGroupRepositoryEntryByPartyGroupType")
				.setParameter("partyGroupType", partyGroupTypeCode)
				.setParameter("manufacturingContext", manufacturingContext)
				.setParameter("distributor", businessContext.getDistributor());
		return (List<GroupRepositoryEntry>) result.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<GroupRepositoryEntry> findGroups(BusinessContext businessContext, String partyGroupCode)
			throws IllegalArgumentException {
		Session session = (Session) this.entityManager.getDelegate();

		ManufacturingContext manufacturingContext = businessContext.getManufacturingContext();

		if (manufacturingContext.getId() == null) {
			manufacturingContext = this.getContextDAO().getByAllProperties(manufacturingContext);
		}

		Query result = session.getNamedQuery("GroupRepositoryEntry.findGroupRepositoryEntryByPartyGroupCode")
				.setParameter("partyGroupCode", partyGroupCode)
				.setParameter("manufacturingContext", manufacturingContext)
				.setParameter("distributor", businessContext.getDistributor());
		return mapResult(result.list());
	}

	@Override
	public GroupRepositoryEntry findGroup(BusinessContext businessContext, String subPartyGroupCode)
			throws IllegalArgumentException {

		GroupRepositoryEntry group = null;
		Session session = (Session) this.entityManager.getDelegate();

		ManufacturingContext manufacturingContext = businessContext.getManufacturingContext();

		if (manufacturingContext.getId() == null) {
			manufacturingContext = this.getContextDAO().getByAllProperties(manufacturingContext);
		}

		Query result = session.getNamedQuery("GroupRepositoryEntry.findOccupation")
				.setParameter("subPartyGroupCode", subPartyGroupCode)
				.setParameter("partyGroupType", PartyGroupTypeCodeEnum.DOMAIN)
				.setParameter("manufacturingContext", manufacturingContext)
				.setParameter("distributor", businessContext.getDistributor());
		List<GroupRepositoryEntry> list = result.list();

		if (!list.isEmpty()) {
			group = list.get(0);
		}

		return group;

	}

	private List<GroupRepositoryEntry> mapResult(List<Object[]> greList) {
		List<GroupRepositoryEntry> result = new ArrayList<GroupRepositoryEntry>();
		GroupRepositoryEntry gre = null;

		for (Object[] row : greList) {
			gre = this.map(row);

			if (gre != null) {
				result.add(gre);
			}
		}
		return result;
	}

	protected GroupRepositoryEntry map(Object[] row) {
		GroupRepositoryEntry gre = new GroupRepositoryEntry();
		if (row == null || row[0] == null)
			return null;
		gre.setPartySubGroupCode((String) row[0]);
		gre.setPartyGroupDescriptionFrench((String) row[1]);
		gre.setPartyGroupDescriptionEnglish((String) row[2]);

		return gre;
	}

	public IManufacturingContextDAO getContextDAO() {
		return contextDAO;
	}

	public void setContextDAO(IManufacturingContextDAO contextDAO) {
		this.contextDAO = contextDAO;
	}

}
