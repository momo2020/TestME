package com.ing.canada.plp.dao.mapping;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.AbstractSingleColumnStandardBasicType;
import org.hibernate.type.TypeFactory;
import org.hibernate.type.TypeResolver;
import org.hibernate.usertype.ParameterizedType;
import org.hibernate.usertype.UserType;

import com.ing.canada.plp.crypto.IIngCipher;
import com.ing.canada.plp.stereotype.ApplicationContextHolder;

/**
 * The Class GenericEnumUserType.
 */
@SuppressWarnings("all")
public class GenericEnumUserType implements UserType, ParameterizedType {

	private static final Log log = LogFactory.getLog(GenericEnumUserType.class);

	/** The Constant DEFAULT_IDENTIFIER_METHOD_NAME. */
	private static final String DEFAULT_IDENTIFIER_METHOD_NAME = "getCode";

	/** The Constant DEFAULT_VALUE_OF_METHOD_NAME. */
	private static final String DEFAULT_VALUE_OF_METHOD_NAME = "valueOfCode";

	/** The enum class. */
	private Class<? extends Enum> enumClass;

	/** The identifier type. */
	private Class<?> identifierType;

	/** The identifier method. */
	private Method identifierMethod;

	/** The value of method. */
	private Method valueOfMethod;

	/** The type. */
	private AbstractSingleColumnStandardBasicType type;

	/** The sql types. */
	private int[] sqlTypes;

	/** encryption needed */
	private boolean encryptedNeeded;

	/** encryption service */
	private IIngCipher cipher;

	/**
	 * @see org.hibernate.usertype.ParameterizedType#setParameterValues(java.util.Properties)
	 */
	public void setParameterValues(Properties parameters) {
		String encryptedValue = parameters.getProperty("encrypted");
		this.encryptedNeeded = encryptedValue != null && "true".equals(encryptedValue);

		String enumClassName = parameters.getProperty("enumClass");
		try {
			this.enumClass = Class.forName(enumClassName).asSubclass(Enum.class);
		} catch (ClassNotFoundException cfne) {
			throw new HibernateException("Enum " + enumClassName + " class not found", cfne);
		}

		String identifierMethodName = parameters.getProperty("identifierMethod", DEFAULT_IDENTIFIER_METHOD_NAME);
		if (log.isDebugEnabled()) {
			log.debug("identifier method for enum " + this.enumClass.getSimpleName() + " is " + identifierMethodName);
		}

		try {
			this.identifierMethod = this.enumClass.getMethod(identifierMethodName, new Class[0]);
			this.identifierType = this.identifierMethod.getReturnType();
		} catch (Exception e) {
			throw new HibernateException("Failed to obtain identifier method", e);
		}
		
		TypeResolver tr = new TypeResolver();
		type = (AbstractSingleColumnStandardBasicType)tr.basic( identifierType.getName() );

		if (this.type == null) {
			throw new HibernateException("Unsupported identifier type " + this.identifierType.getName());
		}

		this.sqlTypes = new int[] { this.type.sqlType() };

		String valueOfMethodName = parameters.getProperty("valueOfMethod", DEFAULT_VALUE_OF_METHOD_NAME);
		if (log.isDebugEnabled()) {
		 log.debug("valueOf method for enum " + this.enumClass.getSimpleName() + " is " + valueOfMethodName);
		}

		try {
			this.valueOfMethod = this.enumClass.getMethod(valueOfMethodName, new Class[] { this.identifierType });
		} catch (Exception e) {
			throw new HibernateException("Failed to obtain valueOf method", e);
		}
	}

	/**
	 * @see org.hibernate.usertype.UserType#returnedClass()
	 */
	public Class returnedClass() {
		return this.enumClass;
	}

	/**
	 * @see org.hibernate.usertype.UserType#nullSafeGet(java.sql.ResultSet, java.lang.String[], java.lang.Object)
	 */
	public Object nullSafeGet(ResultSet rs, String[] names, SessionImplementor session, Object owner) throws HibernateException, SQLException {

		Object identifier = this.type.get(rs, names[0], session);

		if (identifier == null) {
			return null;
		}

		try {
			if (this.encryptedNeeded && identifier instanceof String) {
				identifier = getEncrypter().decryptToString((String) identifier);
			}

			Object value = this.valueOfMethod.invoke(this.enumClass, new Object[] { identifier });
			return value;
		} catch (Exception e) {
			throw new HibernateException("Error invoking '" + this.valueOfMethod.getName() + "' method of '"
					+ this.enumClass + "' with value: " + identifier, e);
		}
	}

	/**
	 * @see org.hibernate.usertype.UserType#nullSafeSet(java.sql.PreparedStatement, java.lang.Object, int)
	 */
	public void nullSafeSet(PreparedStatement st, Object value, int index, SessionImplementor session) throws HibernateException, SQLException {

		try {
			if (value == null) {
				st.setNull(index, this.type.sqlType());
			} else {
				Object identifier = this.identifierMethod.invoke(value, new Object[0]);
				if (this.encryptedNeeded && identifier instanceof String) {
					identifier = getEncrypter().encryptString((String) identifier);
				}
				this.type.set(st, identifier, index, session);
			}
		} catch (Exception e) {
			throw new HibernateException("Error invoking '" + this.identifierMethod.getName() + "' of '"
					+ this.enumClass + "'", e);
		}
	}

	/**
	 * The cipher object can not be instantiated in the setParameterValues method. Hibernate initialize the current
	 * class during the spring injection process. At this point the context in the applicationContextHolder have not
	 * bean initialize by spring.
	 * 
	 * There GenericUnumUserType is manage like a singleton in hibernate so I think it's ok to keep the cipher as a
	 * singleton as well.
	 * 
	 * @return
	 */
	private IIngCipher getEncrypter() {
		if (this.cipher == null) {
			this.cipher = (IIngCipher) ApplicationContextHolder.getBean("plp-ingAesCipher");
		}
		return cipher;
	}

	/**
	 * @see org.hibernate.usertype.UserType#sqlTypes()
	 */
	public int[] sqlTypes() {
		return this.sqlTypes;
	}

	/**
	 * @see org.hibernate.usertype.UserType#assemble(java.io.Serializable, java.lang.Object)
	 */
	public Object assemble(Serializable cached, Object owner) throws HibernateException {
		return cached;
	}

	/**
	 * @see org.hibernate.usertype.UserType#deepCopy(java.lang.Object)
	 */
	public Object deepCopy(Object value) throws HibernateException {
		return value;
	}

	/**
	 * @see org.hibernate.usertype.UserType#disassemble(java.lang.Object)
	 */
	public Serializable disassemble(Object value) throws HibernateException {
		return (Serializable) value;
	}

	/**
	 * @see org.hibernate.usertype.UserType#equals(java.lang.Object, java.lang.Object)
	 */
	public boolean equals(Object x, Object y) throws HibernateException {
		return x == y;
	}

	/**
	 * @see org.hibernate.usertype.UserType#hashCode(java.lang.Object)
	 */
	public int hashCode(Object x) throws HibernateException {
		return x.hashCode();
	}

	/**
	 * @see org.hibernate.usertype.UserType#isMutable()
	 */
	public boolean isMutable() {
		return false;
	}

	/**
	 * @see org.hibernate.usertype.UserType#replace(java.lang.Object, java.lang.Object, java.lang.Object)
	 */
	public Object replace(Object original, Object target, Object owner) throws HibernateException {
		return original;
	}
}
