package com.ing.canada.plp.dao.insurancerisk;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Class InsuranceRiskDAO.
 */
@Repository
public class InsuranceRiskDAO extends BaseDAO<InsuranceRisk> implements IInsuranceRiskDAO {

	/**
	 * @see com.ing.canada.plp.dao.insurancerisk.IInsuranceRiskDAO#findBySequence(com.ing.canada.plp.domain.policyversion.PolicyVersion,
	 *      java.lang.Short)
	 */
	@Override
	public InsuranceRisk findBySequence(PolicyVersion aPolicyVersion, Short aSequence) {

		Session session = (Session) this.entityManager.getDelegate();

		Criteria criteria = session.createCriteria(InsuranceRisk.class);
		criteria.add(Restrictions.eq("policyVersion", aPolicyVersion)).add(
				Restrictions.eq("insuranceRiskSequence", aSequence));

		return (InsuranceRisk) criteria.uniqueResult();
	}
	
}
