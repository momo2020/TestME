/**
 * 
 */
package com.ing.canada.plp.dao.interceptor;

/**
 * @author plafleur
 * 
 */
public final class RequestDirtyObjectsFlag {

	static final ThreadLocal<Boolean> flags = new ThreadLocal<Boolean>();

	/**
	 * Utility classes doesn't have a public constructor
	 */
	private RequestDirtyObjectsFlag() {
		// no-op
	}

	public static void setDirty(boolean isDirty) {
		flags.set(isDirty);
	}

	public static boolean isDirty() {
		Boolean value = flags.get();
		return value != null && value.booleanValue();
	}

	public static void reset() {
		flags.set(false);
	}

}
