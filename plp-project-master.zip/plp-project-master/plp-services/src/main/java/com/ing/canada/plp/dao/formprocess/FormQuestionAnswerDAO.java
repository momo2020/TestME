package com.ing.canada.plp.dao.formprocess;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.formprocess.FormQuestionAnswer;
@Repository
public class FormQuestionAnswerDAO extends BaseDAO<FormQuestionAnswer> implements IFormQuestionAnswerDAO {

}
