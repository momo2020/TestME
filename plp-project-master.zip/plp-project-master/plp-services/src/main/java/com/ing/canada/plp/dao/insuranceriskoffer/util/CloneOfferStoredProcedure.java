package com.ing.canada.plp.dao.insuranceriskoffer.util;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlInOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer;
 
public class CloneOfferStoredProcedure extends StoredProcedure {
	private static final String STORED_PROC_NAME = "plpadmin.clone_to_custom.clone_Insurance_risk_offer";

	protected static final String RISK_OFFER_ID_PARAM_SOURCE = "p_insurance_risk_id_f";
	protected static final String RISK_OFFER_ID_PARAM_DESTINATION = "p_insurance_risk_id_c";

	public CloneOfferStoredProcedure(JdbcTemplate jdbcTemplateToSet) {
		super(jdbcTemplateToSet, STORED_PROC_NAME);
		this.declareParameter(new SqlInOutParameter(
				CloneOfferStoredProcedure.RISK_OFFER_ID_PARAM_SOURCE,
				Types.BIGINT));
		this.declareParameter(new SqlInOutParameter(
				CloneOfferStoredProcedure.RISK_OFFER_ID_PARAM_DESTINATION,
				Types.BIGINT));
	}

	public Map<String, Object> execute(InsuranceRiskOffer source,
			InsuranceRiskOffer destination) {

		Map<String, Object> inputs = new HashMap<String, Object>();
		inputs.put(CloneOfferStoredProcedure.RISK_OFFER_ID_PARAM_SOURCE,
				source.getId());
		inputs.put(CloneOfferStoredProcedure.RISK_OFFER_ID_PARAM_DESTINATION,
				destination.getId());

		return super.execute(inputs);
	}
}
