package com.ing.canada.plp.dao.coverage;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.coverage.SubCoveragePremium;

/**
 * The Class SubCoveragePremiumDAO.
 */
@Repository
public class SubCoveragePremiumDAO extends BaseDAO<SubCoveragePremium> implements ISubCoveragePremiumDAO {
	// NOOP
}
