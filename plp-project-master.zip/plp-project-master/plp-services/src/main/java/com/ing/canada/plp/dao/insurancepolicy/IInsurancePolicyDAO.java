package com.ing.canada.plp.dao.insurancepolicy;

import java.util.Date;
import java.util.List;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.enums.AgreementTypeCodeEnum;
import com.ing.canada.plp.domain.insurancepolicy.InsurancePolicy;

/**
 * The Interface IInsurancePolicyDAO.
 */
public interface IInsurancePolicyDAO extends IBaseDAO<InsurancePolicy> {
	/**
	 * Find an insurancepolicy by agreement number.
	 * 
	 * @param agreementNumber the agreement number
	 * 
	 * @return the insurance policy
	 */
	InsurancePolicy findByAgreementNumber(String agreementNumber);

	/**
	 * Find an insurancepolicy by agreement Legacy number.
	 * 
	 * @param agreementLegacyNumber the agreement Legacy number
	 * 
	 * @return the insurance policy
	 */
	InsurancePolicy findByAgreementLegacyNumber(String agreementLegacyNumber);

	/**
	 * Find all the Insurance policies for a specific CIF ID and agreement type.
	 * 
	 * @param cifId the cif id
	 * @param agreementTypeCode the agreement type code
	 * 
	 * @return the list< insurance policy>
	 */
	List<InsurancePolicy> findAllInsurancePolicyForCifId(Long cifId, AgreementTypeCodeEnum agreementTypeCode);

	/**
	 * Find all the Insurance policies for a specific tamUniqueId.
	 * 
	 * @param tamUniqueId
	 * 
	 * @return the list< insurance policy>
	 */
	List<InsurancePolicy> findAllForTamUniqueId(Long tamUniqueId);

	/**
	 * Find the last Insurance policies for a specific tamUniqueId.
	 * 
	 * @param tamUniqueId
	 * 
	 * @return the insurance policy
	 */
	InsurancePolicy findLastForTamUniqueId(Long tamUniqueId);
	
	/**
	 * Find the last Insurance policies for a specific email.
	 * 
	 * @param email
	 * 
	 * @return the insurance policy
	 */
	List<InsurancePolicy> findAllForEmail(String email);

	/**
	 * Find all the Insurance policies that are rated for a certain date
	 * 
	 * @param dateToTest
	 * 
	 * @return list of insurance policies
	 */
	List<InsurancePolicy> findRatedPolicies(Date dateToTest);

	/**
	 * Find all unexpired insurance policy for a tam unique id.
	 * 
	 * @param tamUniqueId the tam unique id
	 * 
	 * @return the list< insurance policy>
	 */
	List<InsurancePolicy> findAllUnexpiredInsurancePolicyForTamUniqueId(Long tamUniqueId);

	/**
	 * Find all unexpired insurance policy for a tam unique id.
	 * 
	 * @param anEmail the email address
	 * @return the list< insurance policy>
	 */
	List<InsurancePolicy> findAllUnexpiredInsurancePolicyForEmail(String anEmail);

	/**
	 * Find Broker case: all unexpired insurance policy for a tam unique id.
	 * 
	 * @param anEmail
	 * @param insurancePolicyId
	 * @return the list< insurance policy>
	 */
	List<InsurancePolicy> findAllUnexpiredInsurancePolicy(String anEmail, Long insurancePolicyId);

	/**
	 * Find Insurance Policy by given id.
	 * 
	 * @param aInsurancePolicyId
	 *            the Insurance Policy Id
	 * 
	 * @return the Insurance Policy
	 * 
	 */
	InsurancePolicy findInsurancePolicyById(Long aInsurancePolicyId);
	
	/**
	 * Find Broker case: all insurance policy for last name, email, birth date and sub broker
	 * 
	 * @param anEmail
	 * @param insurancePolicyId
	 * @return the list< insurance policy>
	 */
	List<InsurancePolicy> findAllInsurancePolicyForRetrieveWEBBK(String lastName, String anEmail, Date birthDate, String masterOwnerNbr);
	
	/**
	 * Find Broker case: all insurance policy for last name, email, birth date and sub broker
	 * 
	 * @param anEmail
	 * @param insurancePolicyId
	 * @return the list< insurance policy>
	 */
	List<InsurancePolicy> findAllInsurancePolicyForRetrieveIntact(String lastName, String anEmail, Date birthDate);
	
	/**
	 * Find Broker case: all insurance policy for email and sub broker
	 * 
	 * @param anEmail
	 * @param insurancePolicyId
	 * @return the list< insurance policy>
	 */
	List<InsurancePolicy> findAllInsurancePolicyForEmailWEBBK(String anEmail, String masterOwnerNbr);
	
	/**
	 * Find Intact case: all insurance policy for  email  and sub broker
	 * 
	 * @param anEmail
	 * @param insurancePolicyId
	 * @return the list< insurance policy>
	 */
	List<InsurancePolicy> findAllInsurancePolicyForEmailIntact(String anEmail);
}
