package com.ing.canada.plp.dao.coverage;

import java.util.List;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.coverage.Coverage;
import com.ing.canada.plp.domain.enums.InternalTechnicalOfferTypeCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.CoverageOffer;
import com.ing.canada.plp.domain.insuranceriskoffer.PolicyOfferRating;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Interface ICoverageDAO.
 */
public interface ICoverageDAO extends IBaseDAO<Coverage> {

	/**
	 * This method returns all coverage of the policy version from all insurance risks.
	 * 
	 * @param policyVersion
	 * @return list of coverages 
	 */
	List<Coverage> findAllCoveragesByPolicyVersion(PolicyVersion policyVersion);

	/**
	 * This method returns all selected coverage offers of all selected offers of all insurance risk of the policy
	 * version.
	 * 
	 * @param policyVersion
	 * @return list of coverages offer
	 */
	List<CoverageOffer> findAllCoverageOffersByPolicyVersion(PolicyVersion policyVersion);

	List<CoverageOffer> findAllCoverageOffersByPolicyOfferRatingAndCoverageGroup(PolicyOfferRating plOffer, String group);

	
	/** Finds all the coverages offers for a policy version that is linked to an insurance risk 
	 * offer which the internal offer type is given in parameter. 
	 * This method is mostly used in the policy version compare service. 
	 * 
	 * @param policyVersion policy version  
	 * @param anInternal Internal offer type 
	 * @return list of coverages offer
	 */
	List<CoverageOffer> findAllCoverageOffersByPolicyVersionAndInternalOfferType(PolicyVersion policyVersion, 
			InternalTechnicalOfferTypeCodeEnum anInternal);

	

}
