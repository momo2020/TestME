package com.ing.canada.plp.dao.businesstransaction;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransaction;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransactionActivity;
import com.ing.canada.plp.domain.enums.BusinessTransactionActivityCodeEnum;
import com.ing.canada.plp.domain.enums.BusinessTransactionSubActivityCodeEnum;

/**
 * The Class BusinessTransactionActivityDAO.
 */
@Repository
public class BusinessTransactionActivityDAO extends BaseDAO<BusinessTransactionActivity> implements
		IBusinessTransactionActivityDAO {

	/**
	 * @inheritDoc
	 */
	@Override
	public BusinessTransactionActivity findLastUploadNotCancelled(BusinessTransaction businessTransaction) {

		Query query = this.entityManager.createNamedQuery("BusinessTransactionActivity.findLastUploadNotCancelled");
		query.setParameter("businessTransactionId", businessTransaction.getId());
		query.setParameter("uploadActivityCode", BusinessTransactionActivityCodeEnum.VERSION_UPLOADED_IN_LEGACY);
		query.setParameter("cancelledActivityCode",
				BusinessTransactionActivityCodeEnum.VERSION_UPLOADED_IN_LEGACY_CANCELLED);

		BusinessTransactionActivity activity = null;

		try {
			activity = (BusinessTransactionActivity) query.getSingleResult();
		} catch (NoResultException nrex) {
            if (this.log.isDebugEnabled()) {
            	this.log.debug("No UPLOAD BusinessTransactionActivity found for businessTransaction : [" + businessTransaction.getId() + "]");
            }
		}
		return activity;
	}

	/**
	 * @inherit
	 * @see com.ing.canada.plp.dao.businesstransaction.IBusinessTransactionActivityDAO#findLastBusinessTransactionActivity(com.ing.canada.plp.domain.businesstransaction.BusinessTransaction)
	 */
	@Override
	public BusinessTransactionActivity findLastBusinessTransactionActivity(BusinessTransaction businessTransaction) {
		return this.findLastBusinessTransactionActivity(businessTransaction.getId());
	}

	/**
	 * @inheritDoc
	 */
	@Override
	public BusinessTransactionActivity findLastBusinessTransactionActivity(Long businessTransactionId) {

		Query query = this.entityManager
				.createNamedQuery("BusinessTransactionActivity.findLastBusinessTransactionActivity");
		query.setParameter("businessTransactionId", businessTransactionId);

		BusinessTransactionActivity activity = null;

		try {
			activity = (BusinessTransactionActivity) query.getSingleResult();
		} catch (NoResultException nrex) {			
            if (this.log.isDebugEnabled()) {
            	this.log.debug("No BusinessTransactionActivity found for businessTransactionId : [" + businessTransactionId + "]");
            }
		}
		return activity;
	}

	/**
	 * @inheritDoc
	 */
	@Override
	public BusinessTransactionActivity findIQPBusinessTransactionActivity(String agreementNumber) {

		Query query = this.entityManager
				.createNamedQuery("BusinessTransactionActivity.findIQPBusinessTransactionActivityForInsurancePolicy");
		query.setParameter("agreementNumber", agreementNumber);

		BusinessTransactionActivity activity = null;

		try {
			activity = (BusinessTransactionActivity) query.getSingleResult();
		} catch (NoResultException nrex) {			
            if (this.log.isDebugEnabled()) {
            	this.log.debug("No BusinessTransactionActivity found for the agreement : [" + agreementNumber + "]");
            }
		}
		return activity;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public long countComplementInfosBySubActivityCodeAndAttributeValue(Long businessTransactionActivityId,
			BusinessTransactionSubActivityCodeEnum subActivityCode, String complementInfoAttributeValue) {

		Query query = this.entityManager
				.createNamedQuery("BusinessTransactionActivity.countComplementInfosBySubActivityCodeAndAttributeValue");
		query.setParameter("businessTransactionActivityId", businessTransactionActivityId);
		query.setParameter("subActivityCode", subActivityCode);
		query.setParameter("attributeValue", complementInfoAttributeValue);

		return (Long) query.getSingleResult();
	}
}
