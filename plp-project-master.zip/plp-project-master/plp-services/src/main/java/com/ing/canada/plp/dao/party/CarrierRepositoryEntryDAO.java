/**
 * 
 */
package com.ing.canada.plp.dao.party;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.party.CarrierRepositoryEntry;

/**
 * @author ub8169
 *
 */
@Repository
public class CarrierRepositoryEntryDAO extends BaseDAO<CarrierRepositoryEntry> implements ICarrierRepositoryEntryDAO{
	// noop
}
