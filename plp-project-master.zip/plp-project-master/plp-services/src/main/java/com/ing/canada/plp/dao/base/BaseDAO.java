/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2017, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.base;

import java.lang.annotation.Annotation;
import java.lang.reflect.ParameterizedType;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

import com.ing.canada.plp.domain.usertype.AuditTrail;
import com.ing.canada.plp.domain.usertype.Auditable;
import com.ing.canada.plp.domain.usertype.BaseEntity;
import com.ing.canada.plp.helper.EncoderHelper;

/**
 * entities.
 *
 * Transaction control of the save(), update() and delete() operations can directly support Spring container-managed
 * transactions or they can be augmented to handle user-managed Spring transactions. Each of these methods provides
 * additional information for how to configure it for the desired type of transaction control.
 *
 * @see com.ing.canada.plp.domain.party.MunicipalityRepositoryEntry
 * @author Patrick Lafleur
 */
public class BaseDAO<E extends BaseEntity> implements IBaseDAO<E> {

	/** The logger. */
	protected final Log log = LogFactory.getLog(this.getClass());
	
	/** The em. */
	@PersistenceContext(unitName = "plpolicy_persistence_unit")
	protected EntityManager entityManager;

	/** Class of the entity */
	private Class<E> entityClass = null;

	/** entity name may be != class name */
	private String entityName = null;

	@Autowired
	@Qualifier("entityManagerFactory")
	private LocalContainerEntityManagerFactoryBean entityManagerFactoryBean;

	@Autowired
	private EncoderHelper encoderHelper;
	
	/**
	 * Instantiates a new base dao.
	 */
	@SuppressWarnings("unchecked")
	public BaseDAO() {

		this.setEntityClass((Class<E>) ((ParameterizedType) this.getClass().getGenericSuperclass()).getActualTypeArguments()[0]);

		for (Annotation annotation : this.entityClass.getAnnotations()) {
			if (annotation instanceof Entity) {
				this.setEntityName(((Entity) annotation).name());
			}
		}

		if (StringUtils.isEmpty(this.entityName)) {
			this.setEntityName(this.entityClass.getSimpleName());
		}

	}

	@Override
	public Query createNamedQuery(String queryName) {
		return this.entityManager.createNamedQuery(queryName);
	}

	/**
	 * Gets the entity name.
	 *
	 * @return the entity name
	 */
	public String getEntityName() {
		return this.entityName;
	}

	/**
	 * Sets the entity name.
	 *
	 * @param aEntityName the new entity name
	 */
	protected void setEntityName(String aEntityName) {
		this.entityName = aEntityName;
	}

	/**
	 * Gets the entity class.
	 *
	 * @return the entity class
	 */
	public Class<E> getEntityClass() {
		return this.entityClass;
	}

	/**
	 * Sets the entity class.
	 *
	 * @param clazz the new entity class
	 */
	protected void setEntityClass(Class<E> clazz) {
		this.entityClass = clazz;
	}

	@Override
	public EntityManager getEntityManager() {
		return this.entityManager;
	}

	protected CriteriaBuilder getCriteriaBuilder() {
		return this.entityManager.getCriteriaBuilder();
	}

	/**
	 * Synchronize all pending operations to the database.
	 */
	@Override
	public void flush() {
		this.entityManager.flush();
	}

	/**
	 * Perform an initial save of a previously unsaved entity. All subsequent persist actions of this entity should use
	 * the #update() method. This operation must be performed within the a database transaction context for the entity's
	 * data to be permanently saved to the persistence store, i.e., database. This method uses the
	 * {@link javax.persistence.EntityManager#persist(Object) EntityManager#persist} operation.
	 * <p>
	 *
	 * @param entity Account entity to persist
	 *
	 * @return the E
	 *
	 * @throws RuntimeException when the operation fails
	 */
	@Override
	@SuppressWarnings("all")
	public E persist(E entity) {

		if (this.log.isDebugEnabled()) {
			this.log.debug(ESAPI.encoder().encodeForHTML("about to persist a " + this.getEntityName() + "entity: " + entity));
		}

		if (entity instanceof Auditable) {
			Auditable auditable = entity;
			if (auditable.getAuditTrail() == null) {
				if (this.log.isDebugEnabled()) {
					this.log.debug("  initializing the entity audit trail because it is currently null");
				}
				auditable.setAuditTrail(new AuditTrail());
			}
		}

		if (entity.getId() != null && !this.entityManager.contains(entity)) {
			this.entityManager.merge(entity);
		} else {
			this.entityManager.persist(entity);
		}

		if (this.log.isDebugEnabled()) {
			this.log.debug("persisted an " + this.getEntityName() + " instance");
		}

		return entity;

	}

	/**
	 * Refreshes an entity from the database.
	 *
	 * @param entity entity to refresh
	 *
	 * @return the E
	 *
	 * @throws RuntimeException when the operation fails
	 */
	@Override
	public E refresh(E entity) {

		if (this.log.isDebugEnabled()) {
			this.log.debug("refreshing an " + this.getEntityName() + " instance: " + entity);
		}

		this.entityManager.refresh(entity);

		return entity;

	}

	/**
	 * Delete a persistent entity by its 'id' property.
	 *
	 * This operation must be performed within the a database transaction context for the entity's data to be
	 * permanently deleted from the persistence store, i.e., database. This method uses the
	 * {@link javax.persistence.EntityManager#remove(Object) EntityManager#delete} operation.
	 * <p>
	 *
	 * @param id the id
	 *
	 * @return the E
	 *
	 * @throws RuntimeException when the operation fails
	 */
	@Override
	@SuppressWarnings("boxing")
	public E delete(long id) {

		E entity = this.entityManager.getReference(this.getEntityClass(), id);

		if (entity == null) {
			throw new IllegalStateException("the " + this.getEntityName() + " entity with id " + id + " cannot be found, therefore it cannot be deleted.");
		}

		this.delete(entity);
		return entity;
	}

	/**
	 * Deletes a persistent entity by its reference. The entity must be loaded first.
	 *
	 * This operation must be performed within the a database transaction context for the entity's data to be
	 * permanently deleted from the persistence store, i.e., database. This method uses the
	 * {@link javax.persistence.EntityManager#remove(Object) EntityManager#delete} operation.
	 * <p>
	 *
	 * @param entity entity to delete
	 *
	 * @return the E
	 *
	 * @throws RuntimeException when the operation fails
	 */
	@Override
	public E delete(E entity) {

		if (this.log.isInfoEnabled()) {
			this.log.info("deleting an " + this.getEntityName() + " entity: " + entity);
		}

		this.entityManager.remove(entity);

		return entity;

	}

	/**
	 * Finds an entity by its identifier.
	 *
	 * @param id the identifier value
	 *
	 * @return E the entity corresponding to the identifier, null if none is found
	 */
	@Override
	@SuppressWarnings("boxing")
	public E findById(long id) {
		return this.entityManager.find(this.getEntityClass(), id);
	}

	/**
	 * Flush an entity from the entity manager Level 1 cache. The entity becomes in a detached state and is not
	 * managed/monitored by the JPA entity manager anymore. If you modify this object after the eviction and want to
	 * update the database, you will have to call update() explicitely.
	 *
	 * @param entity the entity to be flushed
	 */
	@Override
	public void evict(E entity) {
		((Session) this.entityManager.getDelegate()).evict(entity);
	}

	@Override
	public void clear() {
		((Session) this.entityManager.getDelegate()).clear();
	}

	/**
	 * Find all entities with a specific property value.
	 *
	 * @param value the property value to match
	 * @param property the property
	 *
	 * @return List<E> found by the query
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<E> findByProperty(String property, final Object value) {

		if (this.log.isInfoEnabled()) {
			this.log.info(String.format(("finding %s instance with property: %s, value: " + value), this.getEntityName(), property));
		}
		// final String queryString = "select model from " + this.getEntityName() + " model where model." + property +
		// "= :value";

		// Query query = this.entityManager.createQuery(queryString);
		// query.setParameter("value", value);
		// return query.getResultList();

		Session session = (Session) this.entityManager.getDelegate();
		Criteria criteria = session.createCriteria(this.entityClass);
		criteria.add(Restrictions.eq(property, value));

		return criteria.list();

	}

	/**
	 * Find all entities without discrimination.
	 *
	 * @return List<E> of all entities
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<E> findAll() {
		Session session = (Session) this.entityManager.getDelegate();
		return session.createCriteria(this.entityClass).list();
	}

	/**
	 * gets the name of the schema represented by this persistence layer
	 *
	 * @return String
	 */
	public String getSchemaName() {
		return this.entityManagerFactoryBean.getPersistenceUnitInfo().getProperties().getProperty("hibernate.default_schema");
	}

	/**
	 * Gets the sequence value.
	 *
	 * @param sequenceName the sequence name
	 * @return the sequence value
	 */
	@Override
	public BigDecimal getSequenceValue(String sequenceName) {

		// Security Check, escape sequenceName
		sequenceName = this.encoderHelper.encodeSql(sequenceName);
		
		if (this.log.isInfoEnabled()) {
			this.log.info(String.format("retrieving %s sequence value", sequenceName));
		}

		String query = String.format("select %s.%s.NEXTVAL from DUAL", this.getSchemaName(), sequenceName);
		return (BigDecimal) this.entityManager.createNativeQuery(query).getResultList().get(0);
	}


}
