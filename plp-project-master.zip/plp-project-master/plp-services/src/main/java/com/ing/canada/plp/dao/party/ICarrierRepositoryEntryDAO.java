/**
 * 
 */
package com.ing.canada.plp.dao.party;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.party.CarrierRepositoryEntry;

/**
 * @author ub8169
 *
 */
public interface ICarrierRepositoryEntryDAO extends IBaseDAO<CarrierRepositoryEntry>{
	// noop
}
