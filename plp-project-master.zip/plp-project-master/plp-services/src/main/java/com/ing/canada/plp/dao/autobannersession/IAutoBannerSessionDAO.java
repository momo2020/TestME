package com.ing.canada.plp.dao.autobannersession;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.autobannersession.AutoBannerSession;

/**
 * @author xpham
 *
 */
@Repository
public interface IAutoBannerSessionDAO extends IBaseDAO<AutoBannerSession> {
	// Nothing to implements
}
