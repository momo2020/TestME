package com.ing.canada.plp.dao.insuranceriskoffer;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.insuranceriskoffer.CoverageOffer;

/**
 * The Class CoverageOfferDAO.
 */
@Repository
public class CoverageOfferDAO extends BaseDAO<CoverageOffer> implements ICoverageOfferDAO {
	// Nothing to implements
}
