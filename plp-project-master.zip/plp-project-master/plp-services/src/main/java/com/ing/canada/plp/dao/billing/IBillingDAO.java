package com.ing.canada.plp.dao.billing;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.billing.Billing;

/**
 * The Interface IBillingDAO.
 */
public interface IBillingDAO extends IBaseDAO<Billing> {
	// NOOP
}
