/*
 * Important notice: This software is the sole property of Intact insurance Inc. and
 * cannot be distributed and/or copied without the written permission of Intact insurance
 * Inc.
 *
 * Copyright (c) 2009, Intact insurance Inc., All rights reserved.
 */
package com.ing.canada.plp.dao.diagnostics;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.diagnostics.DiagnosticAutomatedAdviceRepositoryEntry;
import com.ing.canada.plp.domain.enums.DiagnosticsAdviceTypeCodeEnum;

/**
 * The Interface IDiagnosticAutomatedAdviceRepositoryEntryDAO.
 */

public interface IDiagnosticAutomatedAdviceRepositoryEntryDAO extends IBaseDAO<DiagnosticAutomatedAdviceRepositoryEntry> {

	/** Find the corresponding advice repository entry fo the advice code and advice type. 
	 * 
	 * @param aAdviceCode Advice code
	 * @param aAdviceType Advice type
	 * @return Diagnostic Advice repository entry
	 */
	DiagnosticAutomatedAdviceRepositoryEntry findByAdviceCodeAndAdviceType(String aAdviceCode, 
			DiagnosticsAdviceTypeCodeEnum aAdviceType,
			Boolean aAdviceGroupedInd, 
			Boolean aAdviceDisplayInd, 
			Boolean aAdviceSelectableInd);

}
	
	
