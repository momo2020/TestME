package com.ing.canada.plp.dao.insurancerisk;

import java.util.List;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.enums.RatingFactorCalculationMethodEnum;
import com.ing.canada.plp.domain.enums.RatingFactorTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.MultiplicativeRatingFactorFromNonBasicCoverage;

/**
 * The Class RatingRiskDAO.
 */
@Repository
public class MultiplicativeRatingFactorFromNonBasicCoverageDAO extends BaseDAO<MultiplicativeRatingFactorFromNonBasicCoverage> implements IMultiplicativeRatingFactorFromNonBasicCoverageDAO {
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<MultiplicativeRatingFactorFromNonBasicCoverage> getEndorsementFactors(Long ratingRiskId, 
			RatingFactorCalculationMethodEnum calculationMethodEnum,
			RatingFactorTypeCodeEnum factorTypeCodeEnum,
			String endorsementCode) {

		Session session = (Session) this.entityManager.getDelegate();
		org.hibernate.Query query = session.getNamedQuery("MultiplicativeRatingFactorFromNonBasicCoverage.getEndorsementFactor");
		query.setParameter("condition", endorsementCode);
		query.setParameter("ratingFactorCalculationMethod", calculationMethodEnum);
		query.setParameter("ratingFactorType", factorTypeCodeEnum);
		query.setParameter("ratingRisk", ratingRiskId);
	
		return query.list();

	}

}
