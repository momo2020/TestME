/*
 * Important notice: This software is the sole property of Intact insurance Inc. and
 * cannot be distributed and/or copied without the written permission of Intact insurance
 * Inc.
 *
 * Copyright (c) 2009, Intact insurance Inc., All rights reserved.
 */
package com.ing.canada.plp.dao.diagnostics;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.diagnostics.DiagnosticAutomatedAdviceRepositoryEntry;
import com.ing.canada.plp.domain.enums.DiagnosticsAdviceTypeCodeEnum;

/**
 * The Class DiagnosticAutomatedAdviceRepositoryEntryDAO.
 */

@Repository
public class DiagnosticAutomatedAdviceRepositoryEntryDAO extends BaseDAO<DiagnosticAutomatedAdviceRepositoryEntry> implements IDiagnosticAutomatedAdviceRepositoryEntryDAO {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public DiagnosticAutomatedAdviceRepositoryEntry findByAdviceCodeAndAdviceType(String aAdviceCode, 
			DiagnosticsAdviceTypeCodeEnum aAdviceType,
			Boolean aAdviceGroupedInd, 
			Boolean aAdviceDisplayInd, 
			Boolean aAdviceSelectableInd) {
		Session session = (Session) this.entityManager.getDelegate();

		// get the last coverageRepositoryEntry matching the give coverageCode
		Criteria diagnosticRepositoryEntryCriteria = session.createCriteria(DiagnosticAutomatedAdviceRepositoryEntry.class)
													.add(Restrictions.eq("adviceCode", aAdviceCode))
													.add(Restrictions.eq("adviceType", aAdviceType))
													.add(Restrictions.eq("adviceGroupedInd", aAdviceGroupedInd))
													.add(Restrictions.eq("adviceDisplayInd", aAdviceDisplayInd))
													.add(Restrictions.eq("adviceSelectableInd", aAdviceSelectableInd))
													.setMaxResults(1);

		return (DiagnosticAutomatedAdviceRepositoryEntry) diagnosticRepositoryEntryCriteria.uniqueResult();
	}
	// NOOP
}
