package com.ing.canada.plp.dao.insurancerisk;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.enums.BasicCoverageCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.MultiplicativeRatingFactorFromBasicCoverage;
import com.ing.canada.plp.domain.insurancerisk.RatingRisk;

/**
 * The Interface IRatingRiskDAO.
 */
public interface IMultiplicativeRatingFactorFromBasicCoverageDAO extends IBaseDAO<MultiplicativeRatingFactorFromBasicCoverage> {

	/**
	 * Return the basic coverage factor associated to the param
	 * @param ratingRisk
	 * @param basicCoverageCode
	 * @param limitOfInsuranceAmount
	 * @param deductibleAmount
	 * @param limitMedicalExpensesPerPersonAmount
	 * @param limitMutilationDeathIndemnityAmount
	 * @param weeklyBenefitsAmount
	 * @return
	 */
	MultiplicativeRatingFactorFromBasicCoverage getBasicCoverageFactors(
			RatingRisk ratingRisk,
			BasicCoverageCodeEnum basicCoverageCode,
			Integer limitOfInsuranceAmount,
			Integer deductibleAmount,
			Integer limitMedicalExpensesPerPersonAmount,
			Integer limitMutilationDeathIndemnityAmount,
			Integer weeklyBenefitsAmount);
}
