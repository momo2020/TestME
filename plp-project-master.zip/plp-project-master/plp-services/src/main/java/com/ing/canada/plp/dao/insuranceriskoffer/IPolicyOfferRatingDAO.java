/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.insuranceriskoffer;

import java.sql.SQLException;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.enums.InternalTechnicalOfferTypeCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.PolicyOfferRating;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Interface IPolicyOfferRatingDAO.
 * 
 * @author strichar
 */
public interface IPolicyOfferRatingDAO extends IBaseDAO<PolicyOfferRating> {

	/**
	 * Gets the latest policy offer rating for a policyversion.
	 * 
	 * @param aPolicyVersion the a policy version
	 * 
	 * @return the latest
	 */
	PolicyOfferRating getLatest(PolicyVersion aPolicyVersion);

	/**
	 * Clones a the policy offer rating and its peripheral objects. 
	 * Most objects in the graph are deep copied. Some objects like
	 * repository entries are NOT cloned, the existing reference is kept (shallow copy). 
	 * 
	 * @param aPolicyVersion the policy version to be cloned
	 * @return the cloned policy offer rating 
	 * @throws com.ing.canada.plp.exception.CloneException something bad really occured
	 */
	Long clone(PolicyVersion anOffer) throws SQLException;
	
	
	/** Clones the policy offer rating graph and the associated diagnostics advices 
	 * 
	 * @param anOffer Policy offer rating used as source for the clone procedure
	 * @param anInternal Internal offer type code that we need to put on the cloned insurance risk 
	 *                  offer. 
	 * @return Id of the cloned policy offer rating 
	 * 
	 * @throws SQLException
	 */
	Long cloneOfferAndDiagnostics(PolicyOfferRating anOffer, InternalTechnicalOfferTypeCodeEnum anInternal) throws SQLException;
	
}
