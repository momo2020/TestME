package com.ing.canada.plp.dao.businesstransaction;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransaction;

/**
 * The Interface IBusinessTransactionDAO.
 */
public interface IBusinessTransactionDAO extends IBaseDAO<BusinessTransaction> {
	// NOOP
}
