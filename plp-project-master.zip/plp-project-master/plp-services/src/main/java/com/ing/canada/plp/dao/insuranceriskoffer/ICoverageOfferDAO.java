package com.ing.canada.plp.dao.insuranceriskoffer;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.insuranceriskoffer.CoverageOffer;

/**
 * Defines a CoverageOfferDAO.
 */
public interface ICoverageOfferDAO extends IBaseDAO<CoverageOffer> {
	// Nothing to implements
}
