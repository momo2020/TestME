/**
 * 
 */
package com.ing.canada.plp.dao.autobannersession;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.autobannersession.AutoBannerSession;

/**
 * @author xpham
 *
 */
@Repository
public class AutoBannerSessionDao extends BaseDAO<AutoBannerSession> implements IAutoBannerSessionDAO {
	// noop
}
