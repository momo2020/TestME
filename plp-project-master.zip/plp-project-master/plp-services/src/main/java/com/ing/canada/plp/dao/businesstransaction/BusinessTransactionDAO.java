package com.ing.canada.plp.dao.businesstransaction;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransaction;

/**
 * The Class BusinessTransactionDAO.
 */
@Repository
public class BusinessTransactionDAO extends BaseDAO<BusinessTransaction> implements IBusinessTransactionDAO {
	// NOOP
}
