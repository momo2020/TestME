/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2010, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.billing;

import java.util.List;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.billing.CreditCardTransLog;

/**
 * @author mblouin The Interface ICreditCardTransLog
 */
public interface ICreditCardTransLogDAO extends IBaseDAO<CreditCardTransLog> {

	List<CreditCardTransLog> findCreditCardTransLogByUpperId(String tokenID);
}
