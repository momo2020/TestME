package com.ing.canada.plp.dao.businesstransaction;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.businesstransaction.TransactionalMessageElement;

/**
 * The Interface ITransactionalMessageElementDAO.
 */
public interface ITransactionalMessageElementDAO extends IBaseDAO<TransactionalMessageElement> {
	// noop
}
