/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2010, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.billing;

import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.billing.CreditCardTransLog;

/**
 * @author mblouin
 * 
 */
@Repository
public class CreditCardTransLogDAO extends BaseDAO<CreditCardTransLog> implements ICreditCardTransLogDAO {

	@Override
	@SuppressWarnings("unchecked")
	public List<CreditCardTransLog> findCreditCardTransLogByUpperId(String tokenId) {
		Query query = this.entityManager.createNamedQuery("CreditCardTransLog.findCreditCardTransLogByUpperId");

		query.setParameter("tokenId", tokenId);

		try {
			return query.getResultList();
		} catch (NoResultException nrex) {
			this.log.debug("no record returnd by the query, no result exception is handled gracefully");
		}
		return null;
	}
}
