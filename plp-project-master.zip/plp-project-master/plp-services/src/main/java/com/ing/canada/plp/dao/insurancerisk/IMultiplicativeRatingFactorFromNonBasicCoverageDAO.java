package com.ing.canada.plp.dao.insurancerisk;

import java.util.List;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.enums.RatingFactorCalculationMethodEnum;
import com.ing.canada.plp.domain.enums.RatingFactorTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.MultiplicativeRatingFactorFromNonBasicCoverage;

/**
 * The Interface IRatingRiskDAO.
 */
public interface IMultiplicativeRatingFactorFromNonBasicCoverageDAO extends IBaseDAO<MultiplicativeRatingFactorFromNonBasicCoverage> {
	/**
	 * Retrieve a list of multiplicative factor base on parameter.
	 * @param ratingRiskId
	 * @param calculationMethodEnum
	 * @param factorTypeCodeEnum
	 * @param endorsementCode
	 * @return
	 */
	List<MultiplicativeRatingFactorFromNonBasicCoverage> getEndorsementFactors(Long ratingRiskId, 
			RatingFactorCalculationMethodEnum calculationMethodEnum,
			RatingFactorTypeCodeEnum factorTypeCodeEnum,
			String endorsementCode);
}
