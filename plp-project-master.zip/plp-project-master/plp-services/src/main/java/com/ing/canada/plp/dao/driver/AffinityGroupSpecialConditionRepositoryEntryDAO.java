/**
 * 
 */
package com.ing.canada.plp.dao.driver;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.driver.AffinityGroupSpecialConditionRepositoryEntry;

/**
 * @author ub8169
 *
 */
@Repository
public class AffinityGroupSpecialConditionRepositoryEntryDAO extends BaseDAO<AffinityGroupSpecialConditionRepositoryEntry> implements IAffinityGroupSpecialConditionRepositoryEntryDAO{
	// noop

}
