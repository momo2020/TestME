/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.coverage;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.ing.canada.plp.dao.base.IBaseRepositoryDAO;
import com.ing.canada.plp.domain.coverage.CoverageRepositoryEntry;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;

/**
 * The Interface ICoverageRepositoryEntryDAO.
 */
public interface ICoverageRepositoryEntryDAO extends IBaseRepositoryDAO<CoverageRepositoryEntry> {

	/**
	 * This method returns an active CoverageRepositoryEntry for a given CoverageCode, province, company
	 * 
	 * @param coverageCode the coverage code
	 * @param provinceCode the province code
	 * 
	 * @return the coverage repository entry
	 */
	CoverageRepositoryEntry findActiveCoverageRepositoryEntryByCoverageCodeAndManufacturerCompany(String coverageCode,
			ProvinceCodeEnum provinceCode, ManufacturerCompanyCodeEnum aCompany);
	
	
	/**
	 * This method returns a CoverageRepositoryEntry for a given CoverageCode, province and effective date.
	 * 
	 * @param coverageCode the coverage code
	 * @param provinceCode the province code
	 * @param effectiveDate the effective date
	 * 
	 * @return the coverage repository entry
	 */
	CoverageRepositoryEntry findCoverageRepositoryEntryByCoverageCodeAndManufacturerCompany(String coverageCode,
			ProvinceCodeEnum provinceCode, ManufacturerCompanyCodeEnum aCompany, Date effectiveDate);
	
	/**
	 * Find all coverage repository entries by province code and rating date, indexed by coverage code.
	 * 
	 * @param provinceCode the province code
	 * @param ratingDate the rating date
	 * 
	 * @return the map<String, CoverageRepositoryEntry>
	 */
	Map<String, CoverageRepositoryEntry> findByProvinceCodeAndRatingDate(ProvinceCodeEnum provinceCode, 
				ManufacturerCompanyCodeEnum aCompany, Date ratingDate);
	
	
	/**
	 * Find all coverage repository entries by province code and rating date, indexed by coverage code.
	 * 
	 * @param provinceCode the province code
	 * @param ratingDate the rating date
	 * 
	 * @return the map<String, CoverageRepositoryEntry>
	 */
	CoverageRepositoryEntry findByCoverageCodeAndProvinceCodeAndRatingDate(String coverageCode,
			ProvinceCodeEnum provinceCode, ManufacturerCompanyCodeEnum aCompany, Date ratingDate);


	/**
	 * Find all coverage repository entries by province code and company.
	 * 
	 * @param provinceCode the province code
	 * @param ratingDate the rating date
	 * 
	 * @return the map<String, CoverageRepositoryEntry>
	 */
	List<CoverageRepositoryEntry>  findCoverageRepositoryEntryByManufacturerCompanyAndProvince(
			ProvinceCodeEnum provinceCode,
			ManufacturerCompanyCodeEnum aCompany);

}
