/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance
* Copyright (c) 2010, Intact Insurance, All rights reserved.<br>
*/
package com.ing.canada.plp.dao.insuranceriskoffer;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.enums.BasicCoverageCodeEnum;
import com.ing.canada.plp.domain.enums.EndorsementCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.CoveragePremiumOffer;

/**
 * The Class CoveragePremiumOfferDAO.
 */
@Repository
public class CoveragePremiumOfferDAO extends BaseDAO<CoveragePremiumOffer> implements ICoveragePremiumOfferDAO {
	
	@Override
	@SuppressWarnings("unchecked")
	public List<CoveragePremiumOffer> getCoveragePremiumOffersOnPolicyOfferRating(Long aPolicyOfferRatingId) {
		
		javax.persistence.Query query = this.entityManager.createNamedQuery("CoveragePremium.getCoveragePremiumOffersOnPolicyOfferRating");
		query.setParameter("policyOfferRatingId", aPolicyOfferRatingId);
		return query.getResultList();
		
	}
	
	/* (non-Javadoc)
	 * @see com.ing.canada.plp.dao.insuranceriskoffer.ICoveragePremiumOfferDAO#getCoveragePremiumOffers(java.lang.Long, java.lang.Long)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<CoveragePremiumOffer> getCoveragePremiumOffers(Long aInsuranceRiskOfferId, Long aRatingRiskOfferId) {

		javax.persistence.Query query = this.entityManager.createNamedQuery("CoveragePremium.getCoveragePremiumOffers");
		query.setParameter("insuranceOfferId", aInsuranceRiskOfferId);
		query.setParameter("ratingRiskOfferId", aRatingRiskOfferId);
		
		return query.getResultList();
		
	}
	
	/**
	 * Gets the non basic coverage premium offer.
	 * 
	 * @param aInsuranceRiskOfferId the a insurance risk offer id
	 * @param aRatingRiskOfferId the a rating risk offer id
	 * 
	 * @return the non basic coverage premium offer
	 * 
	 * @see com.ing.canada.plp.dao.insuranceriskoffer.ICoveragePremiumOfferDAO#getNonBasicCoveragePremiumOffer(Long aInsuranceRiskOfferId)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<CoveragePremiumOffer> getNonBasicCoveragePremiumOffer(Long aInsuranceRiskOfferId, Long aRatingRiskOfferId) {

		List<CoveragePremiumOffer> listCoveragePremiumOffer = null;
		try {
			Session session = (Session) this.entityManager.getDelegate();
			org.hibernate.Query query = session.getNamedQuery("CoveragePremium.getCoveragePremiumOfferNotInList");
			query.setParameter("insuranceOfferId", aInsuranceRiskOfferId);
			query.setParameter("ratingRiskOfferId", aRatingRiskOfferId);
			ArrayList<String> coverageCodes = new ArrayList<String>();
			for(BasicCoverageCodeEnum code : BasicCoverageCodeEnum.values()){
				coverageCodes.add(code.getCode());
			}
			query.setParameterList("coverageCodeEnum", coverageCodes);
			listCoveragePremiumOffer = query.list();
		} catch (NoResultException nex) {
			listCoveragePremiumOffer = new ArrayList<CoveragePremiumOffer>();
		}
		return listCoveragePremiumOffer;
	}
	
	/**
	 * Gets the selected basic coverage premium offer.
	 * 
	 * @param aInsuranceRiskOfferId the a insurance risk offer id
	 * @param aRatingRiskOfferId the a rating risk offer id
	 * 
	 * @return the selected basic coverage premium offer
	 * 
	 * @see com.ing.canada.plp.dao.insuranceriskoffer.ICoveragePremiumOfferDAO#getSelectedBasicCoveragePremiumOffer(Long aInsuranceRiskOfferId)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<CoveragePremiumOffer> getSelectedBasicCoveragePremiumOffer(Long aInsuranceRiskOfferId, Long aRatingRiskOfferId) {

		List<CoveragePremiumOffer> listCoveragePremiumOffer = null;
		try {
			Session session = (Session) this.entityManager.getDelegate();
			org.hibernate.Query query = session.getNamedQuery("CoveragePremium.getSelectedCoveragePremiumOfferInList");
			query.setParameter("insuranceOfferId", aInsuranceRiskOfferId);
			query.setParameter("ratingRiskOfferId", aRatingRiskOfferId);
			ArrayList<String> coverageCodes = new ArrayList<String>();
			for(BasicCoverageCodeEnum code : BasicCoverageCodeEnum.values()){
				coverageCodes.add(code.getCode());
			}
			query.setParameterList("coverageCodeEnum", coverageCodes);
			listCoveragePremiumOffer = query.list();
		} catch (NoResultException nex) {
			listCoveragePremiumOffer = new ArrayList<CoveragePremiumOffer>();
		}
		return listCoveragePremiumOffer;
	}
	
	/* (non-Javadoc)
	 * @see com.ing.canada.plp.dao.insuranceriskoffer.ICoveragePremiumOfferDAO#getSpecificSelectedNonBasicCoveragePremiumOffer(java.lang.Long, java.lang.Long, com.ing.canada.plp.domain.enums.EndorsementCodeEnum)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<CoveragePremiumOffer> getSpecificSelectedNonBasicCoveragePremiumOffer(Long aInsuranceRiskOfferId, Long aRatingRiskOfferId, EndorsementCodeEnum codeEnum) {
		List<CoveragePremiumOffer> listCoveragePremiumOffer = null;
		try {
			Session session = (Session) this.entityManager.getDelegate();
			org.hibernate.Query query = session.getNamedQuery("CoveragePremium.getSelectedCoveragePremiumOfferInList");
			query.setParameter("insuranceOfferId", aInsuranceRiskOfferId);
			query.setParameter("ratingRiskOfferId", aRatingRiskOfferId);
			ArrayList<String> coverageCodes = new ArrayList<String>();
			coverageCodes.add(codeEnum.getCode());
			query.setParameterList("coverageCodeEnum", coverageCodes);
			listCoveragePremiumOffer = query.list();
		} catch (NoResultException nex) {
			listCoveragePremiumOffer = new ArrayList<CoveragePremiumOffer>();
		}
		return listCoveragePremiumOffer;
	}
}
