package com.ing.canada.plp.dao.insurancerisk;

import java.util.List;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.insurancerisk.RatingRisk;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Interface IRatingRiskDAO.
 */
public interface IRatingRiskDAO extends IBaseDAO<RatingRisk> {
	
	List<RatingRisk> findRatingRiskByPolicyVersion(PolicyVersion aPolicyVersion);
}
