package com.ing.canada.plp.dao.billing;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.billing.Billing;

/**
 * The Class BillingDAO.
 */
@Repository
public class BillingDAO extends BaseDAO<Billing> implements IBillingDAO {
	// NOOP
}
