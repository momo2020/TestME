package com.ing.canada.plp.dao.billing;

import java.util.Date;
import java.util.List;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.billing.Account;
import com.ing.canada.plp.domain.enums.BillingPlanCodeEnum;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;

/**
 * The Interface IAccountDAO.
 */
public interface IAccountDAO extends IBaseDAO<Account> {
	
	List<Account> findAccount(final BillingPlanCodeEnum billingPlan, final List<ManufacturerCompanyCodeEnum> manufactuterCompany, final Date fromDate, final Date toDate) throws Exception;
}
