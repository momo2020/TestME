package com.ing.canada.plp.dao.driver;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.driver.DriverLicenseClass;

/**
 * The Interface IDriverLicenseClassDAO.
 */
public interface IDriverLicenseClassDAO extends IBaseDAO<DriverLicenseClass> {
	// NOOP
}
