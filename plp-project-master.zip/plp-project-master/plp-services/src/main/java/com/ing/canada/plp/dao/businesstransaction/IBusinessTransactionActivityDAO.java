package com.ing.canada.plp.dao.businesstransaction;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransaction;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransactionActivity;
import com.ing.canada.plp.domain.enums.BusinessTransactionSubActivityCodeEnum;

/**
 * The Interface IBusinessTransactionActivityDAO.
 */
public interface IBusinessTransactionActivityDAO extends IBaseDAO<BusinessTransactionActivity> {

	/**
	 * This method return the last upload transaction activity if the upload has not been cancelled.
	 * 
	 * @param businessTransaction
	 * @return
	 */
	BusinessTransactionActivity findLastUploadNotCancelled(BusinessTransaction businessTransaction);

	/**
	 * Returns the last transaction activity associated with a business transaction.
	 * 
	 * @param businessTransaction
	 * @return the <tt>BusinessTransactionActivity</tt>
	 */
	BusinessTransactionActivity findLastBusinessTransactionActivity(BusinessTransaction businessTransaction);

	/**
	 * Returns the last transaction activity associated with a business transaction.
	 * 
	 * @param businessTransactionId
	 * @return
	 */
	BusinessTransactionActivity findLastBusinessTransactionActivity(Long businessTransactionId);

	/**
	 * Found the BusinessTransactionActivity with businessTransactionActivityCode to IQP for an InsurancePolicy.
	 * 
	 * @param agreementNumber
	 * @return the BusinessTransactionActivity
	 */
	BusinessTransactionActivity findIQPBusinessTransactionActivity(String agreementNumber);

	/**
	 * Returns the number of sub-activity complement info entries for a business transaction activity, associated to the
	 * specified <tt>subActivityCode</tt> and having the specified <tt>complementInfoAttributeValue</tt>.
	 * 
	 * @param activityId the ID of the bunsiness transaction activity
	 * @param subActivityCode <tt>BusinessTransactionSubActivityCodeEnum</tt> value to filter results by
	 * @param complementInfoAttributeValue attribute value in <tt>BusinessTransactionSubActivityComplementInfo</tt> to
	 *            filter results by
	 * @return
	 */
	long countComplementInfosBySubActivityCodeAndAttributeValue(Long activityId,
			BusinessTransactionSubActivityCodeEnum subActivityCode, String complementInfoAttributeValue);
}
