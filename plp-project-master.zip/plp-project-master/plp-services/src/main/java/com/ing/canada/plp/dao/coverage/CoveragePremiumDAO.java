package com.ing.canada.plp.dao.coverage;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.coverage.CoveragePremium;

/**
 * The Class CoveragePremiumDAO.
 */
@Repository
public class CoveragePremiumDAO extends BaseDAO<CoveragePremium> implements ICoveragePremiumDAO {
	// NOOP
}
