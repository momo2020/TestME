/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.base;

import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * This interface is a specialization of the IBaseDao interface.<br>
 * It adds functionalities required by all Repositories Dao.
 * 
 * @author fsimard
 */
public interface IBaseRepositoryDAO<E extends BaseEntity> extends IBaseDAO<E> {

	/**
	 * This method returns a repository entity based on all properties of the entity.<br>
	 * This is used to find an existing entity from a specific version from the database.<br>
	 * Some systems like Classic do not maintain an historic.<br>
	 * So we absolutely need to make sure we are dealing with the same version of an entity before deciding to reuse it.
	 * 
	 * @param entity the entity
	 * 
	 * @return the by all properties
	 */
	E getByAllProperties(E entity);
}
