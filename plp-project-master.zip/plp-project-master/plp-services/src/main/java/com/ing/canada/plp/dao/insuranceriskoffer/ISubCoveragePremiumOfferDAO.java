package com.ing.canada.plp.dao.insuranceriskoffer;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.insuranceriskoffer.SubCoveragePremiumOffer;

/**
 * The Interface ISubCoveragePremiumOfferDAO.
 */
public interface ISubCoveragePremiumOfferDAO extends IBaseDAO<SubCoveragePremiumOffer> {
	// NOOP
}
