package com.ing.canada.plp.dao.businesstransaction;

import java.util.Date;
import java.util.List;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.DriverInfo;
import com.ing.canada.plp.domain.VehicleInfo;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransaction;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransactionSubActivity;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransactionSubActivityComplementInfo;
import com.ing.canada.plp.domain.enums.BusinessTransactionSubActivityCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * The Interface IBusinessTransactionSubActivityComplementInfoDao.
 */
public interface IBusinessTransactionSubActivityDAO extends IBaseDAO<BusinessTransactionSubActivity> {

	/**
	 * <p>
	 * Returns the date of the last transaction sub-activity associated with a policy change business transaction.
	 * </p>
	 * 
	 * @param businessTransactionId the ID of the policy change business transaction
	 * @param subActivityCode the sub-activity code we're interested in
	 * @return the <tt>Date</tt> object representing the most recent sub-activity operation; if the sub-activity was
	 *         never executed, a <tt>null</tt> value is returned
	 * 
	 */
	Date findDateOfFirstTransactionSubActivity(Long businessTransactionId,
			BusinessTransactionSubActivityCodeEnum subActivityCode);

	/**
	 * <p>
	 * Returns the last sub-activity complement info instance in the list associated with the given business transaction
	 * activity.
	 * </p>
	 * 
	 * @param activityId the ID of the <tt>BusinessTransactionActivity</tt> for which we search for the last
	 *            complement info
	 * @return the most recent <tt>BusinessTransactionSubActivityComplementInfo</tt>
	 */
	BusinessTransactionSubActivityComplementInfo findLastSubActivityComplementInfo(Long activityId);

	/**
	 * <p>
	 * Return the list of sub-Activities that can be found under a business transaction
	 * 
	 * @param businessTransaction
	 * @return the list of sub activities found under the business transaction
	 */
	List<BusinessTransactionSubActivity> retrieveAllSubActivityForPolicyVersion(BusinessTransaction businessTransaction);

	/**
	 * Count the number of business sub activity of the type Modify coverage is logged for a specific risk offer
	 * 
	 * @param offer
	 * @return the count
	 */
	long countNumberOfModifyCoverageUnderInsuranceOffer(InsuranceRiskOffer offer);

	/**
	 * Returns the most recent <tt>BusinessTransactionSubActivity</tt> filtered by the given <tt>businessTrxId</tt>
	 * 
	 * @param businessTrxId the business transaction defining the scope of the search
	 * @return the business transaction sub-activity
	 */
	BusinessTransactionSubActivity findLastSubActivity(Long businessTrxId);

	/**
	 * Returns the most recent <tt>BusinessTransactionSubActivity</tt> filtered by the given <tt>businessTrxId</tt>
	 * and by the values in <tt>subActivityCodes</tt>.
	 * 
	 * @param businessTrxId the business transaction defining the scope of the search
	 * @param subActivityCodes filter results where <tt>BUSINESS_TRX_SUB_ACTIVITY_CD</tt> is in
	 *            <tt>subActivityCodes</tt>
	 * @return the business transaction sub-activity
	 */
	BusinessTransactionSubActivity findLastSubActivityWithCode(Long businessTrxId,
			BusinessTransactionSubActivityCodeEnum... subActivityCodes);

	List<BusinessTransactionSubActivity> findAllSubActivityWithCodeAndReferenceId(
			BusinessTransactionSubActivityCodeEnum anActivityCode, BaseEntity anEntity);
	
	VehicleInfo findInfoForVehicleRootReference(Long rootReferenceId);

	DriverInfo findInfoForDriverRootReference(Long rootReferenceId);

	VehicleInfo findInfoForCoverageRootReference(Long rootReferenceId);

}
