package com.ing.canada.plp.dao.billing;

import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.billing.Account;
import com.ing.canada.plp.domain.enums.BillingPlanCodeEnum;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;

/**
 * The Class AccountDAO.
 */
@Repository
public class AccountDAO extends BaseDAO<Account> implements IAccountDAO {
	
	private static final Log LOGGER = LogFactory.getLog(AccountDAO.class);
	
	@Override
	@SuppressWarnings("unchecked")
	public List<Account> findAccount(final BillingPlanCodeEnum billingPlan, final List<ManufacturerCompanyCodeEnum> manufactuterCompany, final Date fromDate, final Date toDate) throws Exception {
		try {
			StringBuilder hqlQuery = new StringBuilder("select acc from PolicyVersion as pv ");
			hqlQuery.append(" join pv.insurancePolicy as ip");
			hqlQuery.append(" join ip.manufacturingContext as mc");
			hqlQuery.append(" join pv.billing as b");
			hqlQuery.append(" join b.account as acc");
			hqlQuery.append(" where b.billingPlan =:billingPlan");
			hqlQuery.append(" and mc.manufacturerCompany in (:manufactuterCompany)");
			
			if (fromDate != null) {
				hqlQuery.append(" and acc.auditTrail.createTimestamp >= (:fromDate)");
			}
			
			if (toDate != null) {
				hqlQuery.append(" and acc.auditTrail.createTimestamp < (:toDate)");
			}
			
			hqlQuery.append(" order by acc.auditTrail.createTimestamp desc");
			
			Query q = entityManager.createQuery(hqlQuery.toString());
			q.setParameter("billingPlan", billingPlan);
			q.setParameter("manufactuterCompany", manufactuterCompany);
			
			if (fromDate != null) {
				q.setParameter("fromDate", fromDate);
			}
			
			if (toDate != null) {
				q.setParameter("toDate", toDate);
			}
			return q.getResultList();
		} catch (Exception ex) {
			LOGGER.error("Exception occurred while fetching bank account details !!", ex);
			
			throw ex;
		}
	}
}
