package com.ing.canada.plp.dao.insurancerisk;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.insurancerisk.CommercialUsage;

public interface ICommercialUsageDAO extends IBaseDAO<CommercialUsage> {

}
