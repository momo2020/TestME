/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.dao.insuranceriskoffer;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlInOutParameter;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.enums.InternalTechnicalOfferTypeCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.PolicyOfferRating;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Class PolicyOfferRatingDAO.
 * 
 * @author strichar
 */
@Repository
public class PolicyOfferRatingDAO extends BaseDAO<PolicyOfferRating> implements IPolicyOfferRatingDAO {

	@Autowired
	@Qualifier("jdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public PolicyOfferRating getLatest(PolicyVersion aPolicyVersion) {

		Query query = this.entityManager.createNamedQuery("PolicyOfferRating.getLatest");
		query.setParameter("policyVersion", aPolicyVersion);
		try {
			return (PolicyOfferRating) query.getSingleResult();
		} catch (NoResultException exception) {
			return null;
		}
	}

	/**
	 * {@inheritDoc}
	 */

	@Override
	public Long clone(PolicyVersion policyVersion) throws SQLException {

		CloneStoredProcedure cloneSP = new CloneStoredProcedure(this.jdbcTemplate);

		this.log.info("Executing call to stored procedure: " + cloneSP.getSql());
		Map<?, ?> result = cloneSP.execute(policyVersion.getId());

		Long policyId =  (Long) result.get(CloneStoredProcedure.POLICY_OFFER_PARAM);
		
		this.getEntityManager().refresh(policyVersion);
		
		return policyId;
	}

	/**
	 * The Class CloneStoredProcedure encapsulates the call to the clone stored proc.
	 */
	public class CloneStoredProcedure extends StoredProcedure {
		private static final String STORED_PROC_NAME = "plpadmin.clone_util.clone_policy_offers";

		private static final String POLICY_VERSION_PARAM = "policyVersion";

		private static final String POLICY_OFFER_PARAM = "policyOffer";

		public CloneStoredProcedure(JdbcTemplate jdbcTemplateToSet) {
			super(jdbcTemplateToSet, STORED_PROC_NAME);
			declareParameter(new SqlParameter(POLICY_VERSION_PARAM, Types.BIGINT));
			declareParameter(new SqlOutParameter(POLICY_OFFER_PARAM, Types.BIGINT));
		}
		
		public Map<?, ?> execute(Long policyVersionId) {

			Map<String, Object> inputs = new HashMap<String, Object>();
			inputs.put(POLICY_VERSION_PARAM, policyVersionId);

			return super.execute(inputs);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Long cloneOfferAndDiagnostics(PolicyOfferRating anOffer, InternalTechnicalOfferTypeCodeEnum anInternal)
			throws SQLException {

		CloneOfferAndDiagnosticsStoredProcedure cloneSP = new CloneOfferAndDiagnosticsStoredProcedure(this.jdbcTemplate);

		this.log.info("Executing call to stored procedure: " + cloneSP.getSql());
		Map<?, ?> result = cloneSP.execute(anOffer.getId(), anInternal);
		Long id = (Long) result.get(CloneOfferAndDiagnosticsStoredProcedure.POLICY_OFFER_RATING_PARAM);
		return id;
	}

	/**
	 * The Class CloneOfferAndDiagnosticsStoredProcedure encapsulates the call to the diagnostics clone procedure.
	 */
	public class CloneOfferAndDiagnosticsStoredProcedure extends StoredProcedure {

		private static final String STORED_PROC_NAME = "plpadmin.clone_offer.clone_policy_offer";

		private static final String POLICY_OFFER_RATING_PARAM = "p_Policy_offer_rating_id";

		private static final String INTERNAL_OFFER_TYPE_PARAM = "p_vInternal_tech_offer_type_cd";

		private static final String CLONE_DIAGNOSTICS_IND = "p_vClone_diagnostics_ind";

		public CloneOfferAndDiagnosticsStoredProcedure(JdbcTemplate jdbcTemplateToSet) {
			super(jdbcTemplateToSet, STORED_PROC_NAME);
			declareParameter(new SqlInOutParameter(POLICY_OFFER_RATING_PARAM, Types.BIGINT));
			declareParameter(new SqlParameter(INTERNAL_OFFER_TYPE_PARAM, Types.VARCHAR));
			declareParameter(new SqlParameter(CLONE_DIAGNOSTICS_IND, Types.VARCHAR));
		}

		public Map<?, ?> execute(Long policyOfferRatingId, InternalTechnicalOfferTypeCodeEnum anInternal) {

			Map<String, Object> inputs = new HashMap<String, Object>();
			inputs.put(POLICY_OFFER_RATING_PARAM, policyOfferRatingId);
			inputs.put(INTERNAL_OFFER_TYPE_PARAM, anInternal.getCode());
			inputs.put(CLONE_DIAGNOSTICS_IND, 'Y');

			return super.execute(inputs);
		}
		
	}	
}
