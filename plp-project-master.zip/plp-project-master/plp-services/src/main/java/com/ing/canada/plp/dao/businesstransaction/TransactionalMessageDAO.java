package com.ing.canada.plp.dao.businesstransaction;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.businesstransaction.TransactionalMessage;

/**
 * The Class TransactionalMessageDAO.
 */
@Repository
public class TransactionalMessageDAO extends BaseDAO<TransactionalMessage> implements ITransactionalMessageDAO {
	// noop
}
