package com.ing.canada.plp.dao.billing;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.billing.PaymentSchedule;

/**
 * The Interface IPaymentScheduleDAO.
 */
public interface IPaymentScheduleDAO extends IBaseDAO<PaymentSchedule> {
	// noop
}
