package com.ing.canada.plp.dao;

import java.util.List;

import com.ing.canada.plp.dao.base.IBaseDAO;
import com.ing.canada.plp.domain.IPRestriction;
import com.ing.canada.plp.domain.enums.IPRestrictionTypeCodeEnum;

/**
 * The Interface IManufacturingContextDAO.
 */
public interface IIPRestrictionDAO extends IBaseDAO<IPRestriction> {


	List<IPRestriction> findByIPNumber(String ipNumber);
	
	IPRestriction getEffectiveRestrictionForIP(String ipNumber);
	
	IPRestriction getEffectiveRestrictionForIP(String ipNumber, IPRestrictionTypeCodeEnum restrictionCode);

	public Long reassignSubBroker(String ipNumber, String subBrokerNumber);
}
