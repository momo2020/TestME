package com.ing.canada.plp.dao;

import java.util.List;

import com.ing.canada.plp.dao.base.IBaseRepositoryDAO;
import com.ing.canada.plp.domain.ManufacturingContext;
import com.ing.canada.plp.domain.enums.DistributionChannelCodeEnum;
import com.ing.canada.plp.domain.enums.InsuranceBusinessCodeEnum;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;

/**
 * The Interface IManufacturingContextDAO.
 */
public interface IManufacturingContextDAO extends IBaseRepositoryDAO<ManufacturingContext> {
	
	ManufacturingContext find(ManufacturingContext context);

	ManufacturingContext findOrCreateByExample(ManufacturingContext context);

	List<ManufacturingContext> findByDistributionChannelCode(DistributionChannelCodeEnum distributionChannelCode);

	List<ManufacturingContext> findByInsuranceBusinessCode(InsuranceBusinessCodeEnum insuranceBusinessCode);

	List<ManufacturingContext> findByProvinceCode(ProvinceCodeEnum provinceCode);

	List<ManufacturingContext> findByManufacturerCompanyCode(ManufacturerCompanyCodeEnum manufacturerCompanyCode);

}
