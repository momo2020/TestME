package com.ing.canada.plp.dao.insurancerisk;

import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.insurancerisk.CommercialUsage;

@Repository
public class CommercialUsageDAO extends BaseDAO<CommercialUsage> implements ICommercialUsageDAO {
	
	
}
