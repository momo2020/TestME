package com.ing.canada.plp.dao.insurancerisk;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.enums.BasicCoverageCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.MultiplicativeRatingFactorFromBasicCoverage;
import com.ing.canada.plp.domain.insurancerisk.RatingRisk;

/**
 * The Class RatingRiskDAO.
 */
@Repository
public class MultiplicativeRatingFactorFromBasicCoverageDAO extends BaseDAO<MultiplicativeRatingFactorFromBasicCoverage> implements IMultiplicativeRatingFactorFromBasicCoverageDAO {
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public MultiplicativeRatingFactorFromBasicCoverage getBasicCoverageFactors(
			RatingRisk ratingRisk, BasicCoverageCodeEnum basicCoverageCode, 
			Integer limitOfInsuranceAmount, 
			Integer deductibleAmount, 
			Integer limitMedicalExpensesPerPersonAmount, 
			Integer limitMutilationDeathIndemnityAmount, 
			Integer weeklyBenefitsAmount) {
		
		
		Session session = (Session) this.entityManager.getDelegate();

		Criteria criteria = session.createCriteria(MultiplicativeRatingFactorFromBasicCoverage.class).setMaxResults(1);

		criteria.add(Restrictions.eq("basicCoverageCode", basicCoverageCode));
		criteria.add(Restrictions.eq("ratingRisk", ratingRisk));
		
		if ( limitOfInsuranceAmount != null ) {
			criteria.add(Restrictions.eq("limitOfInsuranceAmount", limitOfInsuranceAmount.longValue()));
		}else{
			criteria.add(Restrictions.isNull("limitOfInsuranceAmount"));
		}
		if ( deductibleAmount != null ) {
			criteria.add(Restrictions.eq("deductibleAmount", deductibleAmount.longValue()));
		}else{
			criteria.add(Restrictions.isNull("deductibleAmount"));
		}
		if ( limitMedicalExpensesPerPersonAmount != null ) {
			criteria.add(Restrictions.eq("limitMedicalExpensesPerPersonAmount", limitMedicalExpensesPerPersonAmount.longValue()));
		}else{
			criteria.add(Restrictions.isNull("limitMedicalExpensesPerPersonAmount"));
		}
		if ( limitMutilationDeathIndemnityAmount != null ) {
			criteria.add(Restrictions.eq("limitMutilationDeathIndemnityAmount", limitMutilationDeathIndemnityAmount.longValue()));
		}else{
			criteria.add(Restrictions.isNull("limitMutilationDeathIndemnityAmount"));
		}
		if ( weeklyBenefitsAmount != null ) {
			criteria.add(Restrictions.eq("weeklyBenefitsAmount", weeklyBenefitsAmount.longValue()));
		}else{
			criteria.add(Restrictions.isNull("weeklyBenefitsAmount"));
		}
		
		
		return (MultiplicativeRatingFactorFromBasicCoverage) criteria.uniqueResult();
		
		
		
		/* 
		MultiplicativeRatingFactorFromBasicCoverage basicCoverageFactor = null;
		try {
			Query query = this.entityManager.createNamedQuery("MultiplicativeRatingFactorBasicCoverage.getBasicCoverageFactor");
			Long limitOfInsuranceLong = limitOfInsuranceAmount != null? limitOfInsuranceAmount.longValue() : null;
			Long deductibleAmountLong = deductibleAmount != null? deductibleAmount.longValue() : null;
			Long limitMedicalExpensesPerPersonAmountLong = limitMedicalExpensesPerPersonAmount != null? limitMedicalExpensesPerPersonAmount.longValue() : null;
			Long limitMutilationDeathIndemnityAmountLong = limitMutilationDeathIndemnityAmount != null? limitMutilationDeathIndemnityAmount.longValue() : null;
			Long weeklyBenefitsAmountLong = weeklyBenefitsAmount != null? weeklyBenefitsAmount.longValue() : null;
			
			query.setParameter("coverageCode", basicCoverageCode);
			query.setParameter("ratingRisk", ratingRisk);
			query.setParameter("limitOfInsuranceAmount", limitOfInsuranceLong);
			query.setParameter("deductibleAmount", deductibleAmountLong);
			query.setParameter("limitMedicalExpensesPerPersonAmount", limitMedicalExpensesPerPersonAmountLong);
			query.setParameter("limitMutilationDeathIndemnityAmount", limitMutilationDeathIndemnityAmountLong);
			query.setParameter("weeklyBenefitsAmount", weeklyBenefitsAmountLong);
			
			basicCoverageFactor = (MultiplicativeRatingFactorFromBasicCoverage)query.getSingleResult();
		} catch (NoResultException nex) {
			return null;
		}
		return basicCoverageFactor;
*/
	}

}
