package com.ing.canada.plp.dao.coverage;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.DistinctRootEntityResultTransformer;
import org.springframework.stereotype.Repository;

import com.ing.canada.plp.dao.base.BaseDAO;
import com.ing.canada.plp.domain.coverage.CoverageOption;

@Repository
public class CoverageOptionDAO extends BaseDAO<CoverageOption> implements ICoverageOptionDAO {
	
	protected static final Log log = LogFactory.getLog(CoverageOptionDAO.class);

	@SuppressWarnings("unchecked")
	@Override
	public List<CoverageOption> findCoverageOptionsByRisk(Long insuranceRiskId) throws Exception {
		List<CoverageOption> listCoverageOption = null;
		try {
			if (insuranceRiskId != null) {
				Session session = (Session) this.entityManager.getDelegate();
				Criteria criteria = session.createCriteria(CoverageOption.class);
				criteria.add(Restrictions.eq("insuranceRisk.id", insuranceRiskId));
				criteria.setResultTransformer(DistinctRootEntityResultTransformer.INSTANCE);
				listCoverageOption = criteria.list();
			}
		} catch (Exception ex) {
			log.error("Exception occurred while fetching the coverage option by insurance risk !!", ex);
			throw ex;
		}
		return listCoverageOption;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public CoverageOption save(CoverageOption coverageOption) throws Exception {
		CoverageOption savedCoverageOption = null;
		try {
			if (coverageOption != null) {
				savedCoverageOption = super.persist(coverageOption);
			}
		} catch (Exception ex) {
			log.error("Exception occurred while saving coverage options !!!", ex);
			throw ex;
		}
		return savedCoverageOption;
	}
}
