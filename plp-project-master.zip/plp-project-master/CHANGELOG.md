# Changelog
## [Unreleased]

## [2.2.0.6] - 2017-12-08
### Added: Global Change 4.2.2 - Changes for VICC rate bridge for Intact Ontario 
- New field Vehicle.vehicleRateGroupByValueInd
- New field VehicleDetailSpecificationRepositoryEntry.rateGroupAccidentBenefitVicc
- New field VehicleDetailSpecificationRepositoryEntry.rateGroupCollisionVicc
- New field VehicleDetailSpecificationRepositoryEntry.rateGroupComprehensiveVicc
- New field VehicleDetailSpecificationRepositoryEntry.rateGroupLiabilityPropertyDamageVicc

### Changed
- Replace deprecated @Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN) with orphanRemoval=true in Vehicle class 

[Unreleased]: https://githubifc.iad.ca.inet/Intact/plp-project/compare/plp-project-2.2.0.6...HEAD
[2.2.0.6]: https://githubifc.iad.ca.inet/Intact/plp-project/compare/plp-project-2.2.0.4...plp-project-2.2.0.6
