/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum BrokerAuthEndorsementCodeEnum.
 */
public enum BrokerAuthEndorsementCodeEnum {

	NOT_ALLOWED("0"),
	ALLOWED_FOR_ADDITION_ONLY("1"),
	ALLOWED_FOR_ADDITION_AND_DELETION("2"),
	ALLOWED_FOR_DELETION_ONLY("3");

	/** The Constant log. */

	/**
	 * Instantiates a new additional interest type code enum.
	 * 
	 * @param aCode the code
	 */
	private BrokerAuthEndorsementCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the additional interest type code enum
	 */
	public static BrokerAuthEndorsementCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (BrokerAuthEndorsementCodeEnum v : values()) {
			if (v.code.equals(value)) {			
				return v;
			}

		}

		throw new IllegalArgumentException("no value found for code: " + value);

	}

}
