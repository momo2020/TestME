package com.ing.canada.plp.lock;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Repository
// We want the bean factory to create a new instance every time. If the system wishes
// to keep a manager for every user/http session it will have to manage it by code. I
// would have liked to use session=scope here, but Spring does not permit it as PLP
// is a pure backend project.
@Scope(value = "prototype")
public class InsurancePolicyLockManager {

	private static final Log log = LogFactory.getLog(InsurancePolicyLockManager.class);

	private boolean enabled;

	private Set<InsurancePolicyLockToken> lockTokens = new HashSet<InsurancePolicyLockToken>();

	private boolean endOfConversation = false;

	private boolean upgradeLocksAtEndOfConversation = true;

	private boolean keepLocksAtEndOfConversation = false;

	/**
	 * Returns the list of object groups currently locked.
	 * 
	 * @return a set of locks
	 */
	public Set<InsurancePolicyLockToken> getLocks() {
		return Collections.unmodifiableSet(this.lockTokens);
	}

	public void setEnabled(boolean isEnabled) {
		this.enabled = isEnabled;
	}

	public boolean isEnabled() {
		return this.enabled;
	}

	public void checkVersions(EntityManager anEntityManager) {
		checkVersions((Session) anEntityManager.getDelegate());
	}

	public void checkVersions(Session aSession) {

		if (isEnabled()) {

			for (InsurancePolicyLockToken lockToken : this.getLocks()) {

				InsurancePolicyLockable lockable = (InsurancePolicyLockable) aSession.load(lockToken.getEntityClass(),
						lockToken.getId());

				InsurancePolicyLockToken previousToken = lockable.getInsurancePolicyLockToken();
				InsurancePolicyLockToken currentToken = lockToken;

				if (!previousToken.isSameVersion(currentToken)) {
					throw new OptimisticLockingFailureException(
							"\n The group lockable object could not be acquired, the version has changed since the lock was acquired!  \n\n"

							+ " Current entity " + currentToken.getEntityClass() + " is locked! \n\n"

							+ "\t - previous locked token id = " + previousToken.getId() + "\n"
									+ "\t - previous locked token version = " + previousToken.getVersion() + "\n\n"

									+ "\t - current locked token id = " + currentToken.getId() + "\n"
									+ "\t - current locked token version = " + currentToken.getVersion() + "\n\n");
				}

			}

		}

	}

	@Transactional(propagation = Propagation.MANDATORY)
	public void upgradeVersions(EntityManager anEntityManager) {
		upgradeVersions((Session) anEntityManager.getDelegate());
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public void upgradeVersions(Session aSession) {

		if (isEnabled()) {

			if (log.isDebugEnabled()) {
				log.debug("upgrading version attribute of " + this.lockTokens.size() + " locked entities");
			}

			Set<InsurancePolicyLockable> lockables = new HashSet<InsurancePolicyLockable>(this.lockTokens.size());

			for (InsurancePolicyLockToken token : this.lockTokens) {

				if (log.isDebugEnabled()) {
					log.debug("upgrading the version attribute of " + token);
				}
				InsurancePolicyLockable lockable = (InsurancePolicyLockable) aSession.load(token.getEntityClass(),
						token.getId());

				if (aSession.getCurrentLockMode(lockable).equals(LockMode.NONE)) {
					// forces the version attribute to be updated
					aSession.lock(lockable, LockMode.FORCE);

					log.trace(" OPTIMISTIC LOCK : add lock on lockable " + lockable);
				}

				// keeps a reference on the locked entity. We will use that reference
				lockables.add(lockable);
				log.trace(" OPTIMISTIC LOCK : actual locked entity " + lockable);
				// later to refresh the lock's version (we don't refresh in this loop as it could cause
				// concurrent modification exception on the collection as we iterate and remove/insert items).

			}

			// Okay we finished iterating on the this.lockTokens collection, we can now refresh the versions.
			for (InsurancePolicyLockable lockable : lockables) {
				if (log.isDebugEnabled()) {
					log.debug("upgraded to version: " + lockable.getInsurancePolicyLockToken().getVersion());
				}
				refresh(lockable);
			}

		}

	}

	public boolean isLocked(InsurancePolicyLockable lockable) {
		boolean result = this.lockTokens.contains(lockable.getInsurancePolicyLockToken());
		return result;
	}

	public void refreshAll() {
		Set<InsurancePolicyLockToken> temp = new HashSet<InsurancePolicyLockToken>(this.lockTokens);
		for (InsurancePolicyLockToken t : temp) {
			this.refresh(t);
		}
	}

	/**
	 * Refreshes the version of a InsurancePolicyLockable object.
	 * 
	 * @param lockable the object whose lock must be refreshed
	 */
	public void refresh(InsurancePolicyLockable lockable) {

		if (isEnabled()) {
			// we have to remove the existing lock
			this.lockTokens.remove(lockable.getInsurancePolicyLockToken());
			// and reacquire the lock with the current version
			acquire(lockable);
		}

	}

	private InsurancePolicyLockToken refresh(InsurancePolicyLockToken token) {

		if (this.isEnabled()) {
			this.lockTokens.remove(token);
			return this.acquire(token);
		}

		return token;
	}

	/**
	 * Acquires a new lock for the group of object the lockable is part of.
	 * 
	 * @param lockable the object group to be locked
	 * @return a token containing the lock information
	 */
	public InsurancePolicyLockToken acquire(InsurancePolicyLockable lockable) {
		return this.acquire(lockable.getInsurancePolicyLockToken());
	}

	public InsurancePolicyLockToken acquire(InsurancePolicyLockToken token) {

		InsurancePolicyLockToken clone = new InsurancePolicyLockToken(token);

		log.trace(" OPTIMISTIC LOCK : acquiring a lock on " + clone);

		if (log.isDebugEnabled()) {
			log.debug("acquiring a lock on : " + clone);
		}

		if (isEnabled()) {
			// stores a copy of the lock, so the original lock can be modified without
			this.lockTokens.add(clone);
			// touching the manager's lock
		}

		if (log.isDebugEnabled()) {
			log.debug("lock acquired on " + token + ", " + this.lockTokens.size() + " total");
		}

		return clone;
	}

	/**
	 * Releases a lock for the group of object the lockable is part of.
	 * 
	 * @param lockable the object to be released
	 */
	public void release(InsurancePolicyLockable lockable) {

		// if (isEnabled()) {
		//
		// if(log.isInfoEnabled()){
		// log.debug("releasing lock on the following object: " + lockable.getInsurancePolicyLockToken());
		// }
		//
		// this.lockTokens.remove(lockable.getInsurancePolicyLockToken());
		//
		// }

	}

	/**
	 * Releases all locks for all object groups currently locked.
	 */
	public void releaseAll() {

		if (isEnabled()) {

			if (log.isInfoEnabled()) {
				log.debug("releasing locks on all (" + this.lockTokens.size() + ") objects:");
				for (InsurancePolicyLockToken t : this.lockTokens) {
					log.debug(" " + t);
				}
			}

			this.lockTokens.clear();

		}

	}

	/**
	 * @return the endOfConversation
	 */
	public boolean isEndOfConversation() {
		return this.endOfConversation;
	}

	public void startNewConversation() {
		if (log.isDebugEnabled()) {
			log.debug("a new conversation is about to start, releasing all acquired group locks");
		}

		// do we need to keep the locks?
		if (!isKeepLocksAtEndOfConversation()) {
			// if not, release them
			this.releaseAll();
		}

		// a new conversation starts here
		this.setEndOfConversation(false);
		// when the new conversation ends, the locks should be released
		this.setKeepLocksAtEndOfConversation(false);

	}

	/**
	 * @param newEndOfConversation the endOfConversation to set
	 */
	public void setEndOfConversation(boolean newEndOfConversation) {
		this.endOfConversation = newEndOfConversation;
	}

	/**
	 * @return the upgradeLocksAtEndOfConversation
	 */
	public boolean isUpgradeLocksAtEndOfConversation() {
		return this.upgradeLocksAtEndOfConversation;
	}

	/**
	 * @param isUpgradeLocksAtEndOfConversation the upgradeLocksAtEndOfConversation to set
	 */
	public void setUpgradeLocksAtEndOfConversation(boolean isUpgradeLocksAtEndOfConversation) {
		this.upgradeLocksAtEndOfConversation = isUpgradeLocksAtEndOfConversation;
	}

	/**
	 * @return the keepLocksAtEndOfConversation
	 */
	public boolean isKeepLocksAtEndOfConversation() {
		return this.keepLocksAtEndOfConversation;
	}

	/**
	 * @param aKeepLocksAtEndOfConversation the keepLocksAtEndOfConversation to set
	 */
	public void setKeepLocksAtEndOfConversation(boolean aKeepLocksAtEndOfConversation) {
		this.keepLocksAtEndOfConversation = aKeepLocksAtEndOfConversation;
	}

}
