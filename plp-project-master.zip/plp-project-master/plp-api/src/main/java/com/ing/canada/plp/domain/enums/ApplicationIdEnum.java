/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum ApplicationIdEnum.
 */
public enum ApplicationIdEnum {

	BELAIR_BACK_OFFICE("BBO"), 
	BELAIR_WEB_AUTO_QUOTE("BWAQ"), 
	BELAIR_WEB_POLICY_CHANGE("BWPC"), 
	BELAIR_WEB_PORTEFOLIO("BWPF"),
	CUSTOMER_RELATIONSHIP_MANAGEMENT("CRM"),
	CLASSIQUE_AUTOMOBILE("CLA1"), 
	GUIDEWIRE_BILLING_CENTER("GWBC"),
	KANETIX("KANE"), 
	KANETIX_MARKET_PLACE("KMKP"), 
	WEB_PAYMENT_APPLICATION("WCCT");

	/**
	 * Instantiates a new application id enum.
	 * 
	 * @param aCode the a code
	 */
	private ApplicationIdEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the application id enum
	 */
	public static ApplicationIdEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (ApplicationIdEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
