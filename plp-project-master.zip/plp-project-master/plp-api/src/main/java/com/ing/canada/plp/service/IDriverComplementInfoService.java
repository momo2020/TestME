/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.domain.driver.DriverComplementInfo;
import com.ing.canada.plp.domain.party.Party;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * This interface exposes services required to manage DriverComplementInfo related entities.
 * 
 * @author fsimard
 */
public interface IDriverComplementInfoService extends ICRUDService<DriverComplementInfo> {

	/**
	 * This method returns the DriverComplementInfo of a PolicyVersion having a particular sequence number.<br>
	 * It returns NULL if no vehicle exists.
	 * 
	 * @param policyVersion the policy version
	 * @param sequence the sequence
	 * 
	 * @return the driver complement info
	 */
	DriverComplementInfo findBySequence(PolicyVersion policyVersion, Integer sequence);

	/**
	 * Returns all driver complement info attached to this policy version. 
	 * We use the relation to the party to get the information.
	 * 
	 * @param policyVersion
	 * @return
	 */
	List<DriverComplementInfo> findAllByPolicyVersion(PolicyVersion policyVersion);
	
	/**
	 * Remove driver
	 * @param aPolicyVersion
	 * @param driver
	 */
	public void removeDriver(PolicyVersion aPolicyVersion, Party driver);
	
	public void resetDriverSequences(PolicyVersion policyVersion);
}
