/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.List;
import java.util.Set;

import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.party.Party;
import com.ing.canada.plp.domain.party.PartyRoleInRisk;
import com.ing.canada.plp.domain.party.Phone;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * This interface exposes services required to manage Party related entities.
 * 
 * @author fsimard
 */
public interface IPartyService extends ICRUDService<Party> {

	/**
	 * This method returns the list of PartyRoleInRisk associated with a vehicle.<br>
	 * We use the PolicyVersion and the sequenceNumber of the vehicle.
	 * 
	 * @param policyVersion The policy version.
	 * @param sequence The sequence.
	 * 
	 * @return A list of object type {@link PartyRoleInRisk}
	 */
	List<PartyRoleInRisk> findPartyRoleInRiskByVehicleSequence(PolicyVersion policyVersion, Short sequence);

	/**
	 * This method persist the newly created Party entity and dependent entities.<br>
	 * This service tries to reuse existing MunicipalityDetailSpecification as much as possible.<br>
	 * If the repository instance attached to the party address is new (no primary key) the service must look for a
	 * corresponding entity in the repository.<br>
	 * If an entity exists it must reused it and associate it to the party address.<br>
	 * Otherwise it must save the new MunicipalityDetailSpecification entities and dependencies.<br>
	 * The same logic must be applied to the GroupRepositoryEntry attached to the PartyGroup.
	 * 
	 * @param entity the entity
	 * 
	 * @return the party
	 * 
	 * @see com.ing.canada.plp.service.IBaseService#persist(com.ing.canada.plp.domain.usertype.BaseEntity)
	 */
	@Override
	Party persist(Party entity);

	/**
	 * This method returns the list of PartyRoleInRisk associated with the policy version.<br>
	 * 
	 * @param aPolicyVersion the a policy version
	 * 
	 * @return A list of object type {@link PartyRoleInRisk}
	 */
	List<PartyRoleInRisk> findPartyRoleInRiskByPolicyVersion(PolicyVersion aPolicyVersion);

	Party findPartyByNameAndAddress(String firstName, String lastName, String postalCode, String civicNumber,
			ManufacturerCompanyCodeEnum[] manufCodeList);

	/**
	 * Used by CRM to update the CIF_CLIENT_ID in PARTY
	 * on the Move Products module
	 * 
	 * @param fromClient
	 * @param toClient
	 * @param movedProductsList
	 */
	void changeCifClientId(
			Long fromClient, 
			Long toClient,
			List<String> movedProductsList
		);
	
	public void deletePhone (Phone phone);

	
	Set<Phone> findPartyPhoneNumbers(long partyId);
}
