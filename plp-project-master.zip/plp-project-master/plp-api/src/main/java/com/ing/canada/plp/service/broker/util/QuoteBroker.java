package com.ing.canada.plp.service.broker.util;

import com.ing.canada.plp.domain.enums.LineOfBusinessCodeEnum;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;

public class QuoteBroker {

	private ManufacturerCompanyCodeEnum company = null;
	private String user = null;
	private String application = null;
	private LineOfBusinessCodeEnum lineOfBusiness = null;
	private String webAccessType = null;

	public ManufacturerCompanyCodeEnum getCompany() {
		return company;
	}

	public void setCompany(ManufacturerCompanyCodeEnum company) {
		this.company = company;
	}

	public String getUser() {
		return this.user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public LineOfBusinessCodeEnum getLineOfBusiness() {
		return this.lineOfBusiness;
	}

	public void setLineOfBusiness(LineOfBusinessCodeEnum lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getApplication() {
		return this.application;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public String getWebAccessType() {
		return this.webAccessType;
	}

	public void setWebAccessType(String webAccessType) {
		this.webAccessType = webAccessType;
	}

	@Override
	public String toString() {
		return "[company=" + this.getCompany() + ", user=" + this.getUser() + ", line of business="
				+ this.getLineOfBusiness() + ", application=" + this.getApplication() + ", web access type="
				+ this.getWebAccessType() + "]";
	}

}
