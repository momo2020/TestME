/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import java.util.Date;
import java.util.Set;

import com.ing.canada.plp.domain.coverage.BaseCoverage;
import com.ing.canada.plp.domain.diagnostics.DiagnosticAutomatedAdvice;
import com.ing.canada.plp.domain.enums.BasicCoverageCodeEnum;
import com.ing.canada.plp.domain.enums.CoverageGroupCodeEnum;
import com.ing.canada.plp.domain.enums.CoverageSelectedTypeCodeEnum;
import com.ing.canada.plp.domain.enums.CoverageTypeCodeEnum;
import com.ing.canada.plp.domain.enums.DiagnosticsAdviceTypeCodeEnum;
import com.ing.canada.plp.domain.enums.EndorsementCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Interface ICoverageHelper.
 */
public interface ICoverageHelper {

	/**
	 * Gets the endorsement.
	 * 
	 * @param aCoverageGroupCodeEnum the a endorsement group code enum
	 * @param aCoverageSet the a coverage set
	 * 
	 * @return the endorsement
	 */
	Set<BaseCoverage> getEndorsements(Set<? extends BaseCoverage> aCoverageSet,
			CoverageGroupCodeEnum aCoverageGroupCodeEnum);

	Set<BaseCoverage> getEndorsements(Set<? extends BaseCoverage> aCoverages, CoverageTypeCodeEnum aCodeEnum);
	
	Set<BaseCoverage> getEndorsements(Set<? extends BaseCoverage> aCoverages, EndorsementCodeEnum aEndorsementCodeEnum);

	/**
	 * Gets the endorsement.
	 * 
	 * @param aCoverageGroupCodeEnum the a endorsement group code enum
	 * @param aCoverageSet the a coverage set
	 * 
	 * @return the endorsement
	 */
	Set<BaseCoverage> getEndorsements(Set<? extends BaseCoverage> aCoverageSet,
			BasicCoverageCodeEnum aCoverageGroupCodeEnum);

	/**
	 * Gets the endorsement eligible.
	 * 
	 * @param aCoverageSet the coverage set
	 * @param aEndorsementCodeEnums the endorsement code enums
	 * @return the endorsement better candidate
	 */
	BaseCoverage getEndorsementEligible(Set<? extends BaseCoverage> aCoverageSet,
			EndorsementCodeEnum... aEndorsementCodeEnums);

	/**
	 * Gets the endorsement.
	 * 
	 * @param aCoverageGroupCodeEnum the a endorsement group code enum
	 * @param aCoverageSet the a coverage set
	 * 
	 * @return the endorsement
	 */

	BaseCoverage getEndorsement(Set<? extends BaseCoverage> aCoverageSet, CoverageGroupCodeEnum aCoverageGroupCodeEnum);

	/**
	 * Gets the selected endorsement.
	 * 
	 * @param aCoverageSet the a coverage set
	 * @param aCoverageGroupCodeEnum the a coverage group code enum
	 * 
	 * @return the selected endorsement
	 */
	BaseCoverage getSelectedEndorsement(Set<? extends BaseCoverage> aCoverageSet,
			CoverageGroupCodeEnum aCoverageGroupCodeEnum);

	BaseCoverage getSelectedEndorsement(Set<? extends BaseCoverage> aCoverageSet,
			BasicCoverageCodeEnum aCoverageGroupCodeEnum);

	/**
	 * Gets the selected endorsements.
	 * 
	 * @param aCoverageSet the a coverage set
	 * @param aCodeEnum the coverage type code enum
	 * 
	 * @return the selected endorsement
	 */
	Set<BaseCoverage> getSelectedEndorsements(Set<? extends BaseCoverage> aCoverageSet, CoverageTypeCodeEnum aCodeEnum);

	BaseCoverage getSelectedEndorsement(Set<? extends BaseCoverage> aCoverageSet,
			EndorsementCodeEnum aCoverageGroupCodeEnum);

	/**
	 * Determine if an endorsement is selected.
	 * 
	 * @param aCoverageSet the a coverage set
	 * @param aCoverageGroupCodeEnum the a coverage group code enum
	 * 
	 * @return Indicates if an endorsement is selected
	 */
	boolean isSelectedEndorsement(Set<? extends BaseCoverage> aCoverageSet, EndorsementCodeEnum aEndorsementCodeEnum);

	/**
	 * Determine if an endorsement is selected.
	 * 
	 * @param aCoverageSet the a coverage set
	 * @param aCoverageGroupCodeEnum the a coverage group code enum
	 * 
	 * @return Indicates if an endorsement is selected
	 */
	boolean isSelectedEndorsement(Set<? extends BaseCoverage> aCoverageSet, CoverageGroupCodeEnum aCoverageGroupCodeEnum);

	/**
	 * Determine if an endorsement selection type.
	 * 
	 * @param aCoverageSet the a coverage set
	 * @param aCoverageGroupCodeEnum the a coverage group code enum
	 * 
	 * @return selection type
	 */
	CoverageSelectedTypeCodeEnum getSelectedTypeEndorsement(Set<? extends BaseCoverage> aCoverageSet, CoverageGroupCodeEnum aCoverageGroupCodeEnum);

	/**
	 * Determine if an endorsement is selectable.
	 * 
	 * @param aCoverageSet the a coverage set
	 * @param aCoverageGroupCodeEnum the a coverage group code enum
	 * 
	 * @return Indicates if an endorsement is selectable
	 */
	boolean isSelectableEndorsement(Set<? extends BaseCoverage> aCoverageSet, CoverageGroupCodeEnum aCoverageGroupCodeEnum);

	/**
	 * Checks if endorsement is present.
	 * 
	 * @param aEndorsementCodeEnum the a endorsement code enum
	 * @param aCoverageSet the a coverage set
	 * 
	 * @return true, if successful
	 */
	BaseCoverage getEndorsement(Set<? extends BaseCoverage> aCoverageSet, EndorsementCodeEnum aEndorsementCodeEnum);

	/**
	 * Gets the endorsement.
	 * 
	 * @param aCoverageOfferSet the a coverage offer set
	 * @param aCoverageCodeEnum the a coverage code enum
	 * 
	 * @return the endorsement
	 */
	BaseCoverage getEndorsement(Set<? extends BaseCoverage> aCoverageOfferSet, BasicCoverageCodeEnum aCoverageCodeEnum);

	/**
	 * Resets the selected indicator to false on all endorsements of a certain coverage group on a custom offer.
	 * 
	 * @param customOffer an offer of OfferTypeCodeEnum.CUSTOM (otherwise an IllegalArgumentException is raised).
	 * @param coverageGroup
	 * @return the sets of coverage
	 */
	Set<BaseCoverage> resetEndorsementsSelectedIndicator(InsuranceRiskOffer customOffer,
			CoverageGroupCodeEnum coverageGroup);
	
	Set<BaseCoverage> resetEndorsementsSelectedIndicator(InsuranceRiskOffer customOffer,
			EndorsementCodeEnum aEndorsementCodeEnum);

	/**
	 * Resets the selected indicator to false on all endorsements of a certain basic coverage code on a custom offer.
	 * 
	 * @param customOffer an offer of OfferTypeCodeEnum.CUSTOM (otherwise an IllegalArgumentException is raised).
	 * @param coverageGroup
	 * @return the sets of coverage
	 */
	Set<BaseCoverage> resetEndorsementsSelectedIndicator(InsuranceRiskOffer aCustomOffer,
			BasicCoverageCodeEnum aBasicCoverage);

	/**
	 * Get all diagnostic advices of a certain insurance risk (all offers).
	 * 
	 * @param aInsuranceRisk
	 * @param adviceCode
	 * @return the sets of automated diagnostic advices.
	 */
	Set<DiagnosticAutomatedAdvice> getSavings(InsuranceRisk aInsuranceRisk, DiagnosticsAdviceTypeCodeEnum adviceCode);

	/**
	 * Apply current saving of a certain insurance risk (all offers).
	 */
	void applySaving(Set<DiagnosticAutomatedAdvice> aAdvices);

	/**
	 * Resets the selected indicator to false on an endorsement of a certain code on a custom offer.
	 * 
	 * @param customOffer an offer of OfferTypeCodeEnum.CUSTOM (otherwise an IllegalArgumentException is raised).
	 * @param endorsementCode
	 * @return the endorsement
	 */
	BaseCoverage resetEndorsementSelectedIndicator(InsuranceRiskOffer customOffer, EndorsementCodeEnum endorsementCode);

	/**
	 * Sets the selected indicator on the endorsement having his limit of insurance matching the aLimitOfInsurance
	 * parameter.
	 * 
	 * @param aEndorsements
	 * @param aLimitOfInsurance
	 */
	void markAsSelectedMatchingLimitOfInsurance(Set<BaseCoverage> aEndorsements, Integer aLimitOfInsurance);

	/**
	 * Sets the selected indicator on the endorsement having his deductible amount matching the aDeductibleAmount
	 * parameter.
	 * 
	 * @param aEndorsements
	 * @param aDeductibleAmount
	 */
	void markAsSelectedMatchingDeductibleAmount(Set<BaseCoverage> aEndorsements, Integer aDeductibleAmount);

	/**
	 * Checks if is zero deductible for Ontario.<br/>
	 * The BR supporting this is : <br/>
	 * BR904 - Display 0$ deductible offer <br/>
	 * 
	 * Qc only : <br/>
	 * Display only for PPV and show value "Included" when collision and comprehensive (or specified perils) are 0, or
	 * when collision is not covered and comprehensive (or specified perils) is 0. <br/>
	 * Otherwise display the value "Excluded".
	 * 
	 * Ont only: <br/>
	 * Display only for PPV and show value "Included" when at least 1 coverage (all perils, or collision, or
	 * comprehensive or specified perils) 0. <br/>
	 * Otherwise Display the value "Excluded".
	 * 
	 * Verify if is zero deductible for Quebec. <br/>
	 * The BR supporting this is : <br/>
	 * BR904 - Display 0$ deductible offer <br/>
	 * 
	 * Qc only : <br/>
	 * Display only for PPV and show value "Included" when collision and comprehensive (or specified perils) are 0, or
	 * when collision is not covered and comprehensive (or specified perils) is 0. <br/>
	 * otherwise display the value "Excluded"
	 * 
	 * Ont only: <br/>
	 * Display only for PPV and show value "Included" when at least 1 coverage (all perils, or collision, or
	 * comprehensive or specified perils) 0. <br/>
	 * Otherwise Display the value "Excluded". Checks if is crash proof.
	 * 
	 * @param aCoverageSet the a coverage set
	 * @param aInsuranceRisk the a insurance risk
	 * @param dateToCompare the date to compare
	 * 
	 * @return true, if is crash proof
	 */
	boolean isCrashProof(InsuranceRisk aInsuranceRisk, Set<? extends BaseCoverage> aCoverageSet, Date dateToCompare);

	boolean isCrashProof(InsuranceRisk aInsuranceRisk, Set<? extends BaseCoverage> aCoverageSet, Date dateToCompare,
			ProvinceCodeEnum aProvince);

	/**
	 * Checks if is crash proof open road.
	 * 
	 * @param aCoverageSet the a coverage set
	 * @param aInsuranceRisk the a insurance risk
	 * @param dateToCompare the date to compare
	 * 
	 * @return true, if is crash proof open road
	 */
	boolean isCrashProofOpenRoad(InsuranceRisk aInsuranceRisk, Set<? extends BaseCoverage> aCoverageSet,
			Date dateToCompare);

	boolean isCrashProofOpenRoad(InsuranceRisk aInsuranceRisk, Set<? extends BaseCoverage> aCoverageSet,
			Date dateToCompare, ProvinceCodeEnum aProvince);

	/**
	 * Checks if is super coverage.
	 * 
	 * @param aCoverageSet the a coverage set
	 * @param aInsuranceRisk the a insurance risk
	 * @param dateToCompare the date to compare
	 * 
	 * @return true, if is super coverage
	 */
	boolean isSuperCoverage(InsuranceRisk aInsuranceRisk, Set<? extends BaseCoverage> aCoverageSet, Date dateToCompare);

	boolean isSuperCoverage(InsuranceRisk aInsuranceRisk, Set<? extends BaseCoverage> aCoverageSet, Date dateToCompare,
			ProvinceCodeEnum aProvince);

	/**
	 * Checks if is super coverage open road.
	 * 
	 * @param aCoverageSet the a coverage set
	 * @param aInsuranceRisk the a insurance risk
	 * @param dateToCompare the date to compare
	 * 
	 * @return true, if is super coverage open road
	 */
	boolean isSuperCoverageOpenRoad(InsuranceRisk aInsuranceRisk, Set<? extends BaseCoverage> aCoverageSet,
			Date dateToCompare);

	boolean isSuperCoverageOpenRoad(InsuranceRisk aInsuranceRisk, Set<? extends BaseCoverage> aCoverageSet,
			Date dateToCompare, ProvinceCodeEnum aProvince);

	/**
	 * Checks if new crash proof open road is selected.
	 * 
	 * @param aCoverageSet the a coverage set
	 * @param aInsuranceRisk the a insurance risk
	 * 
	 * @return true, if new crash proof open road is selected
	 */
	boolean isNewCrashProofOpenRoadSelected(InsuranceRisk aInsuranceRisk, Set<? extends BaseCoverage> aCoverageSet);
	
	/**
	 * Checks if new crash proof selected.
	 * 
	 * @param aCoverageSet the a coverage set
	 * @param aInsuranceRisk the a insurance risk
	 * 
	 * @return true, if new crash proof open road is selected
	 */
	boolean isNewCrashProofSelected(InsuranceRisk aInsuranceRisk, Set<? extends BaseCoverage> aCoverageSet);

	/**
	 * Checks if the endorsement given in parameter is present in the list of coverages.
	 * 
	 * @param aCoverages ilst of coverages.
	 * @param aCode endorsement code
	 * 
	 * @return true, if the endorsment is present
	 */
	boolean isEndorsementPresent(Set<? extends BaseCoverage> aCoverages, EndorsementCodeEnum aCode);

	/**
	 * Checks if is coverage selected and covered.
	 * 
	 * @param coverage the coverage
	 * 
	 * @return true, if is coverage selected and covered
	 */
	boolean isCoverageCovered(BaseCoverage coverage);

	/**
	 * Gets the diagnostic advices.
	 * 
	 * @param aDiagnosticAutomatedAdvices the list of diagnostic automated advices
	 * @param aDiagnosticsAdviceTypeCodeEnum the diagnostic advice type code enum
	 * 
	 * @return the endorsement
	 */
	Set<DiagnosticAutomatedAdvice> getDiagnosticAutomatedAdvices(
			Set<DiagnosticAutomatedAdvice> aDiagnosticAutomatedAdvices,
			DiagnosticsAdviceTypeCodeEnum aDiagnosticsAdviceTypeCodeEnum);

	/**
	 * Gets the diagnostic advice.
	 * 
	 * @param aDiagnosticAutomatedAdvices the list of diagnostic automated advices
	 * @param aDiagnosticsAdviceTypeCodeEnum the diagnostic advice type code enum
	 * 
	 * @return the endorsement
	 */
	DiagnosticAutomatedAdvice getDiagnosticAutomatedAdvice(Set<DiagnosticAutomatedAdvice> aDiagnosticAutomatedAdvices,
			DiagnosticsAdviceTypeCodeEnum aDiagnosticsAdviceTypeCodeEnum);

	/**
	 * !!! The verified eligibility is the UBI driver-specific eligibility
	 * 
	 * @param insuranceRiskOffer
	 * @return
	 */
	boolean verifyUbiDriverEligibility(InsuranceRiskOffer insuranceRiskOffer);

	/**
	 * Check if at least one "driver" is eligible to UBI (The verified eligibility is the UBI driver-specific
	 * eligibility)
	 * 
	 * @param pv
	 * @return
	 */
	boolean verifyIfThereIsAtLeastOneDriverEligibleToUbi(PolicyVersion pv);

	/**
	 * 
	 * @param pv
	 * @return
	 */
	boolean verifyIfThereIsAtLeastOneDriverHasSelectedUbi(PolicyVersion pv);
	
	/**
	 * Check if the following alarm endorsements are present : V03
	 * @param insuranceRisk
	 * @return
	 */
	boolean isAlarmEndorsementPresent(InsuranceRisk insuranceRisk);
	
	/**
	 * Check if the following tracking endorsements are present : V10
	 * @param insuranceRisk
	 * @return
	 */
	boolean isTrackingEndorsementPresent(InsuranceRisk insuranceRisk);
	
	/**
	 * Check if the following Engraving endorsements are present : V04
	 * @param insuranceRisk
	 * @return
	 */
	boolean isEngravingEndorsementPresent(InsuranceRisk insuranceRisk);
	
	/**
	 * Check if the following anti-thefts endorsements are present : V01, V02, V05, V06, V07, V08, V09
	 * @param insuranceRisk
	 * @return
	 */
	boolean isOtherAntiTheftEndorsementPresent(InsuranceRisk insuranceRisk);
	
	/**
	 * Check if the following winter tyre endorsements are present : WTD, WIO, WIN
	 * @param insuranceRisk
	 * @return
	 */
	boolean isWinterTyreEndorsementPresent(InsuranceRisk insuranceRisk);

}
