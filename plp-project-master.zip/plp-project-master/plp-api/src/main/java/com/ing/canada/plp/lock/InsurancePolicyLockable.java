package com.ing.canada.plp.lock;

public interface InsurancePolicyLockable {

	InsurancePolicyLockToken getInsurancePolicyLockToken();

}
