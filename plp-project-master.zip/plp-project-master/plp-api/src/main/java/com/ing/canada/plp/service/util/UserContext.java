package com.ing.canada.plp.service.util;

import com.ing.canada.plp.domain.BusinessContext;

public class UserContext {

	private String userId = null;
	private BusinessContext businessContext = null;

	public UserContext() {
	}

	public UserContext(String userId) {
		this();
		this.setUserId(userId);
	}

	public BusinessContext getBusinessContext() {
		return this.businessContext;
	}

	public void setBusinessContext(BusinessContext businessContext) {
		this.businessContext = businessContext;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String toString() {
		return "[user id=" + this.getUserId() + ", business context=" + this.getBusinessContext() + "]";
	}

}
