package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum ApplicationModeEnum.
 */
public enum ApplicationModeEnum {

	REGULAR_QUOTE("R"),
	QUICK_QUOTE("Q");

	/** The code. */
	private String code = null;
	
	private ApplicationModeEnum(String aCode){
		this.code = aCode;
	}

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the quote code enum
	 */
	public static ApplicationModeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (ApplicationModeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
