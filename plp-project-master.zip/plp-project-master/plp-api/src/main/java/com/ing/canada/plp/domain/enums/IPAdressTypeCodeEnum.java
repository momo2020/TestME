package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

public enum IPAdressTypeCodeEnum {

	STANDARD("STD"), 
	XFORWARD("XFWD");
	
	/**
	 * Instantiates a new transaction code enum.
	 * 
	 * @param aCode the a code
	 */
	private IPAdressTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the transaction code enum
	 */
	public static IPAdressTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (IPAdressTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
	
}
