package com.ing.canada.plp.domain.coverage;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.enums.CoverageSelectedTypeCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

@XmlAccessorType(XmlAccessType.PROPERTY)
@MappedSuperclass
public abstract class BaseCoverage extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The coverage repository entry. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "COVERAGE_REPOSITORY_ENTRY_ID", nullable = false, updatable = true)
	protected CoverageRepositoryEntry coverageRepositoryEntry;

	/** The coverage description. */
	@Column(name = "COVERAGE_DESC", length = 65)
	protected String coverageDescription;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", length = 7)
	protected Date effectiveDate;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	protected Date expiryDate;

	/** The rating date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "RATING_DT", length = 7)
	protected Date ratingDate;

	/** The coverage hidden. */
	@Column(name = "COVERAGE_HIDDEN_IND", length = 1)
	@Type(type = "yes_no")
	protected Boolean coverageHiddenIndicator;

	/** The coverage selectable. */
	@Column(name = "COVERAGE_SELECTABLE_IND", length = 1)
	@Type(type = "yes_no")
	protected Boolean coverageSelectableIndicator;

	/** The coverage selected. */
	@Column(name = "COVERAGE_SELECTED_IND", length = 1)
	@Type(type = "yes_no")
	protected Boolean coverageSelectedIndicator;

	/** The coverage selected type. */
	@Column(name = "COVERAGE_SELECTED_TYPE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.CoverageSelectedTypeCodeEnum") })
	protected CoverageSelectedTypeCodeEnum coverageSelectedType = null;

	/** The coverage eligible. */
	@Column(name = "COVERAGE_ELIGIBLE_IND", length = 1)
	@Type(type = "yes_no")
	protected Boolean coverageEligibleIndicator;

	/** The deductible amount. */
	@Column(name = "DEDUCTIBLE_AMT", precision = 9, scale = 0)
	protected Integer deductibleAmount;

	/** The reduced deductible amount. */
	@Column(name = "REDUCED_DEDUCTIBLE_AMT", precision = 9, scale = 0)
	protected Integer reducedDeductibleAmount;

	/** The insurance limit amount. */
	@Column(name = "LIMIT_OF_INSURANCE_AMT", precision = 9, scale = 0)
	protected Integer limitOfInsurance;

	/** The medical expenses limit per person. */
	@Column(name = "LMT_MED_EXPENSES_PER_PRSN_AMT", precision = 8, scale = 0)
	protected Integer limitMedicalExpensePerPerson;

	/** The mutilation and death indemnity limit. */
	@Column(name = "LMT_MUTLTN_DEATH_INDEMNITY_AMT", precision = 8, scale = 0)
	protected Integer limitMutilationDeathIndemnity;

	/** The weekly benefits. */
	@Column(name = "WEEKLY_BENEFITS_AMT", precision = 9, scale = 0)
	protected Integer weeklyBenefits;

	/** The vehicle rate group adjustment. */
	@Column(name = "VEH_RATE_GROUP_ADJUSTMENT_QTY", precision = 2, scale = 0)
	protected Byte vehicleRateGroupAdjustment;

	/**
	 * @return the coverageDescription
	 */
	public String getCoverageDescription() {
		return this.coverageDescription;
	}

	/**
	 * @param aCoverageDescription the coverageDescription to set
	 */
	public void setCoverageDescription(String aCoverageDescription) {
		this.coverageDescription = aCoverageDescription;
	}

	/**
	 * @return the coverageEligibleIndicator
	 */
	public Boolean getCoverageEligibleIndicator() {
		return this.coverageEligibleIndicator;
	}

	/**
	 * @param aCoverageEligibleIndicator the coverageEligibleIndicator to set
	 */
	public void setCoverageEligibleIndicator(Boolean aCoverageEligibleIndicator) {
		this.coverageEligibleIndicator = aCoverageEligibleIndicator;
	}

	/**
	 * @return the coverageHiddenIndicator
	 */
	public Boolean getCoverageHiddenIndicator() {
		return this.coverageHiddenIndicator;
	}

	/**
	 * @param aCoverageHiddenIndicator the coverageHiddenIndicator to set
	 */
	public void setCoverageHiddenIndicator(Boolean aCoverageHiddenIndicator) {
		this.coverageHiddenIndicator = aCoverageHiddenIndicator;
	}

	/**
	 * @return the coverageRepositoryEntry
	 */
	public CoverageRepositoryEntry getCoverageRepositoryEntry() {
		return this.coverageRepositoryEntry;
	}

	/**
	 * @param aCoverageRepositoryEntry the coverageRepositoryEntry to set
	 */
	public void setCoverageRepositoryEntry(CoverageRepositoryEntry aCoverageRepositoryEntry) {
		this.coverageRepositoryEntry = aCoverageRepositoryEntry;
	}

	/**
	 * @return the coverageSelectableIndicator
	 */
	public Boolean getCoverageSelectableIndicator() {
		return this.coverageSelectableIndicator;
	}

	/**
	 * @param aCoverageSelectableIndicator the coverageSelectableIndicator to set
	 */
	public void setCoverageSelectableIndicator(Boolean aCoverageSelectableIndicator) {
		this.coverageSelectableIndicator = aCoverageSelectableIndicator;
	}

	/**
	 * @return the coverageSelectedIndicator
	 */
	public Boolean getCoverageSelectedIndicator() {
		return this.coverageSelectedIndicator;
	}

	/**
	 * @param aCoverageSelectedIndicator the coverageSelectedIndicator to set
	 */
	public void setCoverageSelectedIndicator(Boolean aCoverageSelectedIndicator) {
		this.coverageSelectedIndicator = aCoverageSelectedIndicator;
	}

	/**
	 * @return the coverageSelectedType
	 */
	public CoverageSelectedTypeCodeEnum getCoverageSelectedType() {
		return this.coverageSelectedType;
	}

	/**
	 * @param aCoverageSelectedType the coverageSelectedType to set
	 */
	public void setCoverageSelectedType(CoverageSelectedTypeCodeEnum aCoverageSelectedType) {
		this.coverageSelectedType = aCoverageSelectedType;
	}

	/**
	 * @return the deductibleAmount
	 */
	public Integer getDeductibleAmount() {
		return this.deductibleAmount;
	}

	/**
	 * @param aDeductibleAmount the deductibleAmount to set
	 */
	public void setDeductibleAmount(Integer aDeductibleAmount) {
		this.deductibleAmount = aDeductibleAmount;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * @param anEffectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date anEffectiveDate) {
		this.effectiveDate = anEffectiveDate;
	}

	/**
	 * @return the expiryDate
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * @param anExpiryDate the expiryDate to set
	 */
	public void setExpiryDate(Date anExpiryDate) {
		this.expiryDate = anExpiryDate;
	}

	/**
	 * @return the limitMedicalExpensePerPerson
	 */
	public Integer getLimitMedicalExpensePerPerson() {
		return this.limitMedicalExpensePerPerson;
	}

	/**
	 * @param aLimitMedicalExpensePerPerson the limitMedicalExpensePerPerson to set
	 */
	public void setLimitMedicalExpensePerPerson(Integer aLimitMedicalExpensePerPerson) {
		this.limitMedicalExpensePerPerson = aLimitMedicalExpensePerPerson;
	}

	/**
	 * @return the limitMutilationDeathIndemnity
	 */
	public Integer getLimitMutilationDeathIndemnity() {
		return this.limitMutilationDeathIndemnity;
	}

	/**
	 * @param aLimitMutilationDeathIndemnity the limitMutilationDeathIndemnity to set
	 */
	public void setLimitMutilationDeathIndemnity(Integer aLimitMutilationDeathIndemnity) {
		this.limitMutilationDeathIndemnity = aLimitMutilationDeathIndemnity;
	}

	/**
	 * @return the limitOfInsurance
	 */
	public Integer getLimitOfInsurance() {
		return this.limitOfInsurance;
	}

	/**
	 * @param aLimitOfInsurance the limitOfInsurance to set
	 */
	public void setLimitOfInsurance(Integer aLimitOfInsurance) {
		this.limitOfInsurance = aLimitOfInsurance;
	}

	/**
	 * @return the ratingDate
	 */
	public Date getRatingDate() {
		return this.ratingDate;
	}

	/**
	 * @param aRatingDate the ratingDate to set
	 */
	public void setRatingDate(Date aRatingDate) {
		this.ratingDate = aRatingDate;
	}

	/**
	 * @return the reducedDeductibleAmount
	 */
	public Integer getReducedDeductibleAmount() {
		return this.reducedDeductibleAmount;
	}

	/**
	 * @param aReducedDeductibleAmount the reducedDeductibleAmount to set
	 */
	public void setReducedDeductibleAmount(Integer aReducedDeductibleAmount) {
		this.reducedDeductibleAmount = aReducedDeductibleAmount;
	}

	/**
	 * @return the vehicleRateGroupAdjustment
	 */
	public Byte getVehicleRateGroupAdjustment() {
		return this.vehicleRateGroupAdjustment;
	}

	/**
	 * @param aVehicleRateGroupAdjustment the vehicleRateGroupAdjustment to set
	 */
	public void setVehicleRateGroupAdjustment(Byte aVehicleRateGroupAdjustment) {
		this.vehicleRateGroupAdjustment = aVehicleRateGroupAdjustment;
	}

	/**
	 * @return the weeklyBenefits
	 */
	public Integer getWeeklyBenefits() {
		return this.weeklyBenefits;
	}

	/**
	 * @param aWeeklyBenefits the weeklyBenefits to set
	 */
	public void setWeeklyBenefits(Integer aWeeklyBenefits) {
		this.weeklyBenefits = aWeeklyBenefits;
	}

}
