/**
 * 
 */
package com.ing.canada.plp.helper;

import com.ing.canada.plp.domain.partnership.Partnership;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * @author hbacourt
 * 
 */
public interface IPartnershipSegmentHelper {

	/**
	 * Returns the String representing the partnership group number and promotion source if they exist for the
	 * policyversion. ex: {"TYPE_A.SEGMENT1","TYPE_A.SEGMENT2","TYPE_B.SEGMENT1"}
	 * 
	 * @param policyVersion {@link PolicyVersion}
	 * @return the String representing the partnership segment names
	 */
	String getPartnershipSegmentNames(PolicyVersion policyVersion);

	/**
	 * Returns the String representing the partnership group number and promotion source from the Partnership. ex:
	 * {"TYPE_A.SEGMENT1","TYPE_A.SEGMENT2","TYPE_B.SEGMENT1"}
	 * 
	 * @param policyVersion {@link Partnership}
	 * @return the String representing the partnership segment names
	 */
	String getPartnershipSegmentNames(Partnership partnership);
	
	/**
	 * Returns the current partnership of a policyVersion
	 * @param policyVersion the policy containing the partnership
	 * @return The current partnership or null if none found
	 */
	Partnership findCurrentPartnership(PolicyVersion policyVersion);

	String getPartnershipCode(PolicyVersion policyVersion);
}
