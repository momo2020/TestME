/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.party;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.PhoneTypeCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * Phone entity.
 * 
 * @author Patrick Lafleur
 * 
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "PHONE", uniqueConstraints = {})
public class Phone extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "PHONE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "PhoneSequence")
	@SequenceGenerator(name = "PhoneSequence", sequenceName = "PHONE_SEQ", allocationSize = 5)
	private Long id;

	/** The party. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "PARTY_ID", nullable = false, updatable = true)
	private Party party;

	/** The phoneType. */
	@Column(name = "PHONE_TYPE_CD", length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PhoneTypeCodeEnum") })
	private PhoneTypeCodeEnum phoneType;

	/** The area code. */
	@Column(name = "AREA_CODE_NBR", length = 3)
	private String phoneAreaCode;

	/** The phoneNumber. */
	@Column(name = "PHONE_NBR", nullable = false, length = 7)
	private String phoneNumber;

	/** The phoneExtension. */
	@Column(name = "EXTENSION_NBR", length = 6)
	private String phoneExtension;

	/** The preferred indicator. */
	@Column(name = "PREFERRED_PHONE_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean preferredIndicator;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", length = 7)
	private Date effectiveDate;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;

	/** The original scenario phone. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_PHONE_ID", insertable = false, updatable = false)
	private Phone originalScenarioPhone;

	/**
	 * Instantiates a new phone.
	 */
	public Phone() {
		// noarg constructor
	}

	/**
	 * Instantiates a new phone.
	 * 
	 * @param aParty the a party
	 * @param anAreaCodeNumber the area code phoneNumber
	 * @param aPhoneNumber the phone phoneNumber
	 */
	public Phone(Party aParty, String anAreaCodeNumber, String aPhoneNumber) {
		setParty(aParty);
		setPhoneAreaCode(anAreaCodeNumber);
		setPhoneNumber(aPhoneNumber);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the party.
	 * 
	 * @return the party
	 */
	@XmlTransient // parent
	public Party getParty() {
		return this.party;
	}

	/**
	 * Sets the party.
	 * 
	 * @param aParty the new party
	 */
	public void setParty(Party aParty) {
		AssociationsHelper.updateOneToManyFields(aParty, "phones", this, "party");
	}

	/**
	 * Gets the phoneType.
	 * 
	 * @return the phoneType
	 */
	public PhoneTypeCodeEnum getPhoneType() {
		return this.phoneType;
	}

	/**
	 * Sets the phoneType.
	 * 
	 * @param phoneTypeCode the new phoneType
	 */
	public void setPhoneType(PhoneTypeCodeEnum phoneTypeCode) {
		this.phoneType = phoneTypeCode;
	}

	/**
	 * Gets the area code.
	 * 
	 * @return the area code
	 */
	public String getPhoneAreaCode() {
		return this.phoneAreaCode;
	}

	/**
	 * Sets the area code.
	 * 
	 * @param areaCodeNumber the new area code
	 */
	public void setPhoneAreaCode(String areaCodeNumber) {
		this.phoneAreaCode = areaCodeNumber;
	}

	/**
	 * Gets the phoneNumber.
	 * 
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return this.phoneNumber;
	}

	/**
	 * Sets the phoneNumber.
	 * 
	 * @param aPhoneNumber the new phoneNumber
	 */
	public void setPhoneNumber(String aPhoneNumber) {
		this.phoneNumber = aPhoneNumber;
	}

	/**
	 * Gets the phoneExtension.
	 * 
	 * @return the phoneExtension
	 */
	public String getPhoneExtension() {
		return this.phoneExtension;
	}

	/**
	 * Sets the phoneExtension.
	 * 
	 * @param extensionNumber the new phoneExtension
	 */
	public void setPhoneExtension(String extensionNumber) {
		this.phoneExtension = extensionNumber;
	}

	/**
	 * Gets the preferred indicator.
	 * 
	 * @return the preferred indicator
	 */
	public Boolean getPreferredIndicator() {
		return this.preferredIndicator;
	}

	/**
	 * Sets the preferred indicator.
	 * 
	 * @param preferredPhoneIndicator the new preferred indicator
	 */
	public void setPreferredIndicator(Boolean preferredPhoneIndicator) {
		this.preferredIndicator = preferredPhoneIndicator;
	}

	/**
	 * Gets the effective date.
	 * 
	 * @return the effective date
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * Sets the effective date.
	 * 
	 * @param aEffectiveDate the new effective date
	 */
	public void setEffectiveDate(Date aEffectiveDate) {
		this.effectiveDate = aEffectiveDate;
	}

	/**
	 * Gets the expiry date.
	 * 
	 * @return the expiry date
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * Sets the expiry date.
	 * 
	 * @param aExpiryDate the new expiry date
	 */
	public void setExpiryDate(Date aExpiryDate) {
		this.expiryDate = aExpiryDate;
	}

	/**
	 * Gets the original scenario phone.
	 * 
	 * @return the original scenario phone
	 */
	public Phone getOriginalScenarioPhone() {
		return this.originalScenarioPhone;
	}

	/**
	 * Sets the original scenario phone. Even if it is public, there updatable property is set to false and
	 * modifications will fail. It is public only to allow unit testing.
	 * 
	 * @param anOriginalScenarioPhone the new original scenario phone
	 */
	public void setOriginalScenarioPhone(Phone anOriginalScenarioPhone) {
		this.originalScenarioPhone = anOriginalScenarioPhone;
	}

}
