/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum CoverageTypeCodeEnum.
 */
public enum CoverageTypeCodeEnum {

	/** ACCIDENT BENEFITS */
	ACCIDENT_BENEFITS("AB"),

	/** AUTOMOBILE LIABILITY BODILY INJURY */
	AUTOMOBILE_LIABILITY_BODILY_INJURY("AL"),

	/** OPTIONAL ACCIDENT BENEFITS */
	OPTIONAL_ACCIDENT_BENEFITS("AO"),

	/** ALL PERILS */
	ALL_PERILS("AP"),

	/** ADDITIONAL LIVING EXPENSES */
	ADDITIONAL_LIVING_EXPENSES("AX"),

	/** BUILDING */
	BUILDING("BG"),

	/** COLLISION */
	COLLISION("CO"),

	/** COMPREHENSIVE */
	COMPREHENSIVE("CP"),

	/** DIRECT COMPENSATION PROPERTY DAMAGE */
	DIRECT_COMPENSATION_PROPERTY_DAMAGE("DC"),

	/** DETACHED PRIVATE STRUCTURES */
	DETACHED_PRIVATE_STRUCTURES("DP"),

	/** DISCOUNT SURCHARGE */
	DISCOUNT_SURCHARGE("DS"),

	/** EXTENDED LIABILITY */
	EXTENDED_LIABILITY("EL"),

	/** ENDORSEMENT */
	ENDORSEMENT("EN"),

	/** LEGAL LIABILITY */
	LEGAL_LIABILITY("LL"),

	/** OTHER */
	OTHER("OT"),

	/** AUTOMOBILE LIABILITY PROPERTY DAMAGE */
	AUTOMOBILE_LIABILITY_PROPERTY_DAMAGE("PD"),

	/** PERSONAL PROPERTY */
	PERSONAL_PROPERTY("PP"),

	/** SCHEDULEED ARTICLES */
	SCHEDULED_ARTICLES("SA"),

	/** SINGLE LIMITS */
	SINGLE_LIMIT("SL"),

	/** SPECIFIED PERILS */
	SPECIFIED_PERILS("SP"),

	/** UNSINSURED AUTOMOBILE */
	UNINSURED_AUTOMOBILE("UA"),

	/** UMBRELLA */
	UMBRELLA("UM");

	/** Set of type codes for coverages that are deductible. */
	private static final Set<CoverageTypeCodeEnum> DEDUCTIBLE_COVERAGES = new HashSet<CoverageTypeCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			add(CoverageTypeCodeEnum.COLLISION);
			add(CoverageTypeCodeEnum.COMPREHENSIVE);
		}
	};

	/**
	 * Indicates if this type of coverage is deductible.
	 * 
	 * @return true if deductible, false otherwise
	 */
	public boolean isDeductible() {
		return DEDUCTIBLE_COVERAGES.contains(this);
	}

	/**
	 * Gets the deductible coverage list.
	 * 
	 * @return the deductible coverage list
	 */
	public static Set<CoverageTypeCodeEnum> getDeductibleCoverageList() {
		return Collections.unmodifiableSet(DEDUCTIBLE_COVERAGES);
	}

	/** Set of type codes for coverages that are a limit of insurance. */
	private static final Set<CoverageTypeCodeEnum> LIMIT_OF_INSURANCE_COVERAGES = new HashSet<CoverageTypeCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			add(CoverageTypeCodeEnum.AUTOMOBILE_LIABILITY_BODILY_INJURY);
			add(CoverageTypeCodeEnum.AUTOMOBILE_LIABILITY_PROPERTY_DAMAGE);
			add(CoverageTypeCodeEnum.EXTENDED_LIABILITY);
			add(CoverageTypeCodeEnum.LEGAL_LIABILITY);
		}
	};

	/**
	 * Indicates if a this type of coverage has a limit of insurance.
	 * 
	 * @return true if the coverage has a limit, false otherwise
	 */
	public boolean isLimitOfInsurance() {
		return LIMIT_OF_INSURANCE_COVERAGES.contains(this);
	}

	/**
	 * Gets the limit of insurance coverage list.
	 * 
	 * @return the limit of insurance coverage list
	 */
	public static Set<CoverageTypeCodeEnum> getLimitOfInsuranceCoverageList() {
		return Collections.unmodifiableSet(LIMIT_OF_INSURANCE_COVERAGES);
	}

	/**
	 * Instantiates a new coverage type code enum.
	 * 
	 * @param aCode the a code
	 */
	private CoverageTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the coverage type code enum
	 */
	public static CoverageTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (CoverageTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}

}
