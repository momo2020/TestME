/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.party;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * CarrierRepositoryEntry entity.
 * 
 * @author ub8169
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "CARRIER_REP_ENTRY", uniqueConstraints = {})
@NamedQueries( {
		@NamedQuery(name = "CarrierRepositoryEntry.getCarrierRepositoryEntrySortedFrench", query = "from CarrierRepositoryEntry cre where cre.effectiveDate <= current_date() and (cre.expiryDate >= current_date() or cre.expiryDate is null) and cre.id.provinceCd = :provinceCd order by cre.orderItemNumberFrench"),
		@NamedQuery(name = "CarrierRepositoryEntry.getCarrierRepositoryEntrySortedFrench.manufacturer", query = "from CarrierRepositoryEntry cre where cre.effectiveDate <= current_date() and (cre.expiryDate >= current_date() or cre.expiryDate is null) and cre.id.provinceCd = :provinceCd and cre.id.manufacturerCompanyCode = :manufacturerCompanyCode order by cre.orderItemNumberFrench"),
		@NamedQuery(name = "CarrierRepositoryEntry.getCarrierRepositoryEntrySortedEnglish", query = "from CarrierRepositoryEntry cre where cre.effectiveDate <= current_date() and (cre.expiryDate >= current_date() or cre.expiryDate is null) and cre.id.provinceCd = :provinceCd order by cre.orderItemNumberEnglish"),
		@NamedQuery(name = "CarrierRepositoryEntry.getCarrierRepositoryEntrySortedEnglish.manufacturer", query = "from CarrierRepositoryEntry cre where cre.effectiveDate <= current_date() and (cre.expiryDate >= current_date() or cre.expiryDate is null) and cre.id.provinceCd = :provinceCd and cre.id.manufacturerCompanyCode = :manufacturerCompanyCode order by cre.orderItemNumberEnglish"),
		@NamedQuery(name = "CarrierRepositoryEntry.getCarrierRepositoryEntryByCarrierNameFrench", query = "from CarrierRepositoryEntry cre where cre.carrierNameFrench = :carrierName and cre.id.provinceCd = :provinceCd"),
		@NamedQuery(name = "CarrierRepositoryEntry.getCarrierRepositoryEntryByCarrierNameFrench.manufacturer", query = "from CarrierRepositoryEntry cre where cre.carrierNameFrench = :carrierName and cre.id.provinceCd = :provinceCd and cre.id.manufacturerCompanyCode = :manufacturerCompanyCode"),
		@NamedQuery(name = "CarrierRepositoryEntry.getCarrierRepositoryEntryByCarrierNameEnglish", query = "from CarrierRepositoryEntry cre where cre.carrierNameEnglish = :carrierName and cre.id.provinceCd = :provinceCd"),
		@NamedQuery(name = "CarrierRepositoryEntry.getCarrierRepositoryEntryByCarrierNameEnglish.manufacturer", query = "from CarrierRepositoryEntry cre where cre.carrierNameEnglish = :carrierName and cre.id.provinceCd = :provinceCd and cre.id.manufacturerCompanyCode = :manufacturerCompanyCode"),
		@NamedQuery(name = "CarrierRepositoryEntry.getCarrierRepositoryEntryByCarrierCode", query = "from CarrierRepositoryEntry cre where cre.id.carrierCd = :carrierCd"),
		@NamedQuery(name = "CarrierRepositoryEntry.getCarrierRepositoryEntryById", query = "from CarrierRepositoryEntry cre where cre.id.carrierCd = :carrierCd and cre.id.provinceCd = :provinceCd and cre.id.manufacturerCompanyCode = :manufacturerCompanyCode") ,
		@NamedQuery(name = "CarrierRepositoryEntry.getCarrierRepositoryEntryByCarrierCode.manufacturer", query = "from CarrierRepositoryEntry cre where cre.id.carrierCd = :carrierCd and cre.id.provinceCd = :provinceCd and cre.id.manufacturerCompanyCode = :manufacturerCompanyCode")})

public class CarrierRepositoryEntry extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@EmbeddedId
	private CarrierRepositoryEntryId id;

	/** The carrier name english. */
	@Column(name = "CARRIER_NAME_ENG_TXT", nullable = false, length = 50)
	private String carrierNameEnglish;

	/** The carrier name french. */
	@Column(name = "CARRIER_NAME_FRE_TXT", nullable = false, length = 50)
	private String carrierNameFrench;

	/** The order item number english. */
	@Column(name = "ORDER_ITEM_ENG_NBR", nullable = false, precision = 4, scale = 0)
	private Long orderItemNumberEnglish;

	/** The order item number french. */
	@Column(name = "ORDER_ITEM_FRE_NBR", nullable = false, precision = 4, scale = 0)
	private Long orderItemNumberFrench;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", nullable = false, length = 7)
	private Date effectiveDate;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;

	/** The legacy carrier code. */
	@Column(name = "LEGACY_CARRIER_CD", length = 6)
	private String legacyCarrierCode;

	/** The manufacturer code. */
	@Column(name = "MANUFACTURER_COMPANY_CD", length = 1, insertable = false, updatable = false)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum") })
	private ManufacturerCompanyCodeEnum manufacturerCompanyCode = null;

	/**
	 * default constructor
	 */
	public CarrierRepositoryEntry() {
		// noarg constructor
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */	
	@Override
	public CarrierRepositoryEntryId getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object anId) {
		this.id = (CarrierRepositoryEntryId) anId;
	}

	/**
	 * @return the carrierNameEnglish
	 */
	public String getCarrierNameEnglish() {
		return this.carrierNameEnglish;
	}

	/**
	 * @param aCarrierNameEnglish the carrierNameEnglish to set
	 */
	public void setCarrierNameEnglish(String aCarrierNameEnglish) {
		this.carrierNameEnglish = aCarrierNameEnglish;
	}

	/**
	 * @return the carrierNameFrench
	 */
	public String getCarrierNameFrench() {
		return this.carrierNameFrench;
	}

	/**
	 * @param aCarrierNameFrench the carrierNameFrench to set
	 */
	public void setCarrierNameFrench(String aCarrierNameFrench) {
		this.carrierNameFrench = aCarrierNameFrench;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date anEffectiveDate) {
		this.effectiveDate = anEffectiveDate;
	}

	/**
	 * @return the expiryDate
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * @param expiryDate the expiryDate to set
	 */
	public void setExpiryDate(Date anExpiryDate) {
		this.expiryDate = anExpiryDate;
	}

	/**
	 * @return the orderItemNumberEnglish
	 */
	public Long getOrderItemNumberEnglish() {
		return this.orderItemNumberEnglish;
	}

	/**
	 * @param orderItemNumberEnglish the orderItemNumberEnglish to set
	 */
	public void setOrderItemNumberEnglish(Long anOrderItemNumberEnglish) {
		this.orderItemNumberEnglish = anOrderItemNumberEnglish;
	}

	/**
	 * @return the orderItemNumberFrench
	 */
	public Long getOrderItemNumberFrench() {
		return this.orderItemNumberFrench;
	}

	/**
	 * @param orderItemNumberFrench the orderItemNumberFrench to set
	 */
	public void setOrderItemNumberFrench(Long anOrderItemNumberFrench) {
		this.orderItemNumberFrench = anOrderItemNumberFrench;
	}

	/**
	 * Gets the legacy carrier code.
	 * 
	 * @return the legacy carrier code
	 */
	public String getLegacyCarrierCode() {
		return this.legacyCarrierCode;
	}

	/**
	 * Sets the legacy carrier code.
	 * 
	 * @param aLegacyCarrierCode the new legacy carrier code
	 */
	public void setLegacyCarrierCode(String aLegacyCarrierCode) {
		this.legacyCarrierCode = aLegacyCarrierCode;
	}

	/**
	 * Gets the manufacturer company code.
	 * 
	 * @return the manufacturer company code
	 */
	public ManufacturerCompanyCodeEnum getManufacturerCompanyCode() {
		return this.manufacturerCompanyCode;
	}

	/**
	 * Sets the manufacturer company code.
	 * 
	 * @param aManufacturerCompanyCode the new manufacturer company code
	 */
	public void setManufacturerCompanyCode(ManufacturerCompanyCodeEnum aManufacturerCompanyCode) {
		this.manufacturerCompanyCode = aManufacturerCompanyCode;
	}
}
