/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum CreditScoreTypeCodeEnum.
 */
public enum CreditScoreTypeCodeEnum {

	// The client gave his consent
	WITH_CONSENT("CO"),

	// The client refused to consent or called back to cancel his previous consentment
	WITHOUT_CONSENT("NC"),

	// The client reiterated his consent
	WITH_CONSENT_AT_THE_REINSTATEMENT("RE");

	/**
	 * Instantiates a new credit score type code enum.
	 * 
	 * @param aCode the a code
	 */
	private CreditScoreTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the credit score type code enum
	 */
	public static CreditScoreTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (CreditScoreTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
