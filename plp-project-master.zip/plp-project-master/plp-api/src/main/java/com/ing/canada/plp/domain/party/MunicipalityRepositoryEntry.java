/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.party;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.enums.CountryCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * MunicipalityRepositoryEntry entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "MUNICIPALITY_RPSTRY_ENTRY", uniqueConstraints = {})
public class MunicipalityRepositoryEntry extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "MUNICIPALITY_RPSTRY_ENTRY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "MunicipalityRepositoryEntrySequence")
	@SequenceGenerator(name = "MunicipalityRepositoryEntrySequence", sequenceName = "MUNICIPALITY_RPSTRY_ENTRY_SEQ", allocationSize = 5)
	private Long id;

	/** The municipality. */
	@Column(name = "MUNICIPALITY_TXT", length = 32)
	private String municipality;

	/** The municipal code. */
	@Column(name = "MUNICIPAL_CD", nullable = false, length = 6)
	private String municipalCode;

	/** The municipality status. */
	@Column(name = "MUNICIPALITY_STATUS_CD", length = 2)
	private String municipalityStatus;

	/** The province. */
	@Column(name = "PROVINCE_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ProvinceCodeEnum") })
	private ProvinceCodeEnum province;

	/** The country. */
	@Column(name = "COUNTRY_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.CountryCodeEnum") })
	private CountryCodeEnum country;

	/**
	 * Instantiates a new municipality repository entry.
	 */
	public MunicipalityRepositoryEntry() {
		// noarg constructor
	}

	/**
	 * Instantiates a new municipality repository entry.
	 * 
	 * @param aMunicipalCode the a municipal code
	 */
	public MunicipalityRepositoryEntry(String aMunicipalCode) {
		setMunicipalCode(aMunicipalCode);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the municipality.
	 * 
	 * @return the municipality
	 */
	public String getMunicipality() {
		return this.municipality;
	}

	/**
	 * Sets the municipality.
	 * 
	 * @param aMunicipality the new municipality
	 */
	public void setMunicipality(String aMunicipality) {
		this.municipality = aMunicipality;
	}

	/**
	 * Gets the municipal code.
	 * 
	 * @return the municipal code
	 */
	public String getMunicipalCode() {
		return this.municipalCode;
	}

	/**
	 * Sets the municipal code.
	 * 
	 * @param aMunicipalCode the new municipal code
	 */
	public void setMunicipalCode(String aMunicipalCode) {
		this.municipalCode = aMunicipalCode;
	}

	/**
	 * Gets the municipality status.
	 * 
	 * @return the municipality status
	 */
	public String getMunicipalityStatus() {
		return this.municipalityStatus;
	}

	/**
	 * Sets the municipality status.
	 * 
	 * @param aMmunicipalityStatusCode the a mmunicipality status code
	 */
	public void setMunicipalityStatus(String aMmunicipalityStatusCode) {
		this.municipalityStatus = aMmunicipalityStatusCode;
	}

	/**
	 * Gets the province.
	 * 
	 * @return the province
	 */
	public ProvinceCodeEnum getProvince() {
		return this.province;
	}

	/**
	 * Sets the province.
	 * 
	 * @param provinceCode the new province
	 */
	public void setProvince(ProvinceCodeEnum provinceCode) {
		this.province = provinceCode;
	}

	/**
	 * Gets the country.
	 * 
	 * @return the country
	 */
	public CountryCodeEnum getCountry() {
		return this.country;
	}

	/**
	 * Sets the country.
	 * 
	 * @param countryCode the new country
	 */
	public void setCountry(CountryCodeEnum countryCode) {
		this.country = countryCode;
	}

}
