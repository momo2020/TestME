/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insurancerisk;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.RatingFactorCalculationMethodEnum;
import com.ing.canada.plp.domain.enums.RatingFactorTypeCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * MultiplicativeRatingFactorFromNonBasicCoverage entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
// @Table(name = "MLT_RAT_FCT_FROM_NON_B_COV", uniqueConstraints = { @UniqueConstraint(columnNames = { "RATING_RISK_ID" }) })
@Table(name = "MLT_RAT_FCT_FROM_NON_B_COV")
@NamedQueries( { @NamedQuery(name = "MultiplicativeRatingFactorFromNonBasicCoverage.getEndorsementFactor", query = "from MultiplicativeRatingFactorFromNonBasicCoverage mrfnbc where mrfnbc.condition = :condition and mrfnbc.ratingFactorCalculationMethod = :ratingFactorCalculationMethod and mrfnbc.ratingFactorType = :ratingFactorType and mrfnbc.ratingRisk.id = :ratingRisk") })
public class MultiplicativeRatingFactorFromNonBasicCoverage extends BaseEntity {

	private static final long serialVersionUID = 1L;

	// Fields
	/** The id. */
	@Id
	@Column(name = "MLT_RAT_FCT_FROM_NON_B_COV_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "MultiplicativeRatingFactorFromNonBasicCoverageSequence")
	@SequenceGenerator(name = "MultiplicativeRatingFactorFromNonBasicCoverageSequence", sequenceName = "MLT_RAT_FCT_FROM_NON_B_COV_SEQ", allocationSize = 5)
	private Long id;

	/** The rating risk. */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "RATING_RISK_ID", nullable = false)
	private RatingRisk ratingRisk;

	/** The condition type. */
	@Column(name = "CONDITION_TYPE_CD", nullable = false, length = 5)
	private String conditionType;

	/** The condition. */
	@Column(name = "CONDITION_CD", nullable = false, length = 4)
	private String condition;

	/** The rating factor apply cond. */
	@Column(name = "RATING_FACTOR_APPLY_COND_CD", nullable = false, length = 25)
	private String ratingFactorApplyCondition;

	/** The multiplicative rating factor liability bodily injury. */
	@Column(name = "ML_RT_FCT_LBLTY_BDLY_INJRY_QTY", precision = 10, scale = 4)
	private Double liabilityBodilyInjuryFactor;

	/** The multiplicative rating factor liability property damage. */
	@Column(name = "ML_RT_FCT_LBLTY_PRPTY_DMD_QTY", precision = 10, scale = 4)
	private Double liabilityPropertyDamageFactor;

	/** The multiplicative rating factor accident benefit. */
	@Column(name = "ML_RT_FCT_ACDNT_BNFT__QTY", precision = 10, scale = 4)
	private Double accidentBenefitFactor;

	/** The multiplicative rating factor all perils. */
	@Column(name = "ML_RT_FCT_ALL_PERILS_QTY", precision = 10, scale = 4)
	private Double allPerilsFactor;

	/** The multiplicative rating factor collision. */
	@Column(name = "ML_RT_FCT_COLLISION_QTY", precision = 10, scale = 4)
	private Double collisionFactor;

	/** The multiplicative rating factor comprehensive. */
	@Column(name = "ML_RT_FCT_COMPREHENSIVE_QTY", precision = 10, scale = 4)
	private Double comprehensiveFactor;

	/** The multiplicative rating factor specified perils. */
	@Column(name = "ML_RT_FCT_SPECIFIED_PERILS_QTY", precision = 10, scale = 4)
	private Double specifiedPerilsFactor;

	/** The multiplicative rating factor liability. */
	@Column(name = "ML_RT_FCT_LBLTY_QTY", precision = 10, scale = 4)
	private Double liabilityFactor;

	/** The multiplicative rating factor medical expenses. */
	@Column(name = "ML_RT_FCT_MEDICAL_EXPENSES_QTY", precision = 10, scale = 4)
	private Double medicalExpensesFactor;

	/** The multiplicative rating factor total disability. */
	@Column(name = "ML_RT_FCT_TOTAL_DISABILITY_QTY", precision = 10, scale = 4)
	private Double totalDisabilityFactor;

	/** The fixed amount. */
	@Column(name = "FIXED_AMT", precision = 5, scale = 0)
	private Long fixedAmount;

	@Column(name = "RATING_FACTOR_TYPE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.RatingFactorTypeCodeEnum") })
	private RatingFactorTypeCodeEnum ratingFactorType;

	@Column(name = "METHOD_OF_CALCULATION_CD", length = 5)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.RatingFactorCalculationMethodEnum") })
	private RatingFactorCalculationMethodEnum ratingFactorCalculationMethod;

	/**
	 * default constructor.
	 */
	public MultiplicativeRatingFactorFromNonBasicCoverage() {
		// Nothing to do
	}

	/**
	 * minimal constructor.
	 * 
	 * @param mltRatFctFromNonBCovId the mlt rat fct from non b cov id
	 * @param aRatingRisk the rating risk
	 * @param conditionTypeCd the condition type cd
	 * @param conditionCd the condition cd
	 * @param ratingFactorApplyCond the rating factor apply cond cd
	 */
	public MultiplicativeRatingFactorFromNonBasicCoverage(Long mltRatFctFromNonBCovId, RatingRisk aRatingRisk,
			String conditionTypeCd, String conditionCd, String ratingFactorApplyCond) {
		this.id = mltRatFctFromNonBCovId;
		this.ratingRisk = aRatingRisk;
		this.conditionType = conditionTypeCd;
		this.condition = conditionCd;
		this.ratingFactorApplyCondition = ratingFactorApplyCond;
	}

	/**
	 * full constructor.
	 * 
	 * @param mltRatFctFromNonBCovId the mlt rat fct from non b cov id
	 * @param aRatingRisk the rating risk
	 * @param conditionTypeCd the condition type cd
	 * @param conditionCd the condition cd
	 * @param ratingFactorApplyCond the rating factor apply cond cd
	 * @param mlRtFctLbltyBdlyInjryQty the ml rt fct lblty bdly injry qty
	 * @param mlRtFctLbltyPrptyDmdQty the ml rt fct lblty prpty dmd qty
	 * @param mlRtFctAcdntBnftQty the ml rt fct acdnt bnft qty
	 * @param mlRtFctAllPerilsQty the ml rt fct all perils qty
	 * @param mlRtFctCollisionQty the ml rt fct collision qty
	 * @param mlRtFctComprehensiveQty the ml rt fct comprehensive qty
	 * @param mlRtFctSpecifiedPerilsQty the ml rt fct specified perils qty
	 * @param mlRtFctLbltyQty the ml rt fct lblty qty
	 * @param mlRtFctMedicalExpensesQty the ml rt fct medical expenses qty
	 * @param mlRtFctTotalDisabilityQty the ml rt fct total disability qty
	 */
	public MultiplicativeRatingFactorFromNonBasicCoverage(Long mltRatFctFromNonBCovId, RatingRisk aRatingRisk,
			String conditionTypeCd, String conditionCd, String ratingFactorApplyCond, Double mlRtFctLbltyBdlyInjryQty,
			Double mlRtFctLbltyPrptyDmdQty, Double mlRtFctAcdntBnftQty, Double mlRtFctAllPerilsQty,
			Double mlRtFctCollisionQty, Double mlRtFctComprehensiveQty, Double mlRtFctSpecifiedPerilsQty,
			Double mlRtFctLbltyQty, Double mlRtFctMedicalExpensesQty, Double mlRtFctTotalDisabilityQty) {
		this.id = mltRatFctFromNonBCovId;
		this.ratingRisk = aRatingRisk;
		this.conditionType = conditionTypeCd;
		this.condition = conditionCd;
		this.ratingFactorApplyCondition = ratingFactorApplyCond;
		this.liabilityBodilyInjuryFactor = mlRtFctLbltyBdlyInjryQty;
		this.liabilityPropertyDamageFactor = mlRtFctLbltyPrptyDmdQty;
		this.accidentBenefitFactor = mlRtFctAcdntBnftQty;
		this.allPerilsFactor = mlRtFctAllPerilsQty;
		this.collisionFactor = mlRtFctCollisionQty;
		this.comprehensiveFactor = mlRtFctComprehensiveQty;
		this.specifiedPerilsFactor = mlRtFctSpecifiedPerilsQty;
		this.liabilityFactor = mlRtFctLbltyQty;
		this.medicalExpensesFactor = mlRtFctMedicalExpensesQty;
		this.totalDisabilityFactor = mlRtFctTotalDisabilityQty;
	}

	// Property accessors
	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object mltRatFctFromNonBCovId) {
		this.id = (Long) mltRatFctFromNonBCovId;
	}

	/**
	 * Gets the rating risk.
	 * 
	 * @return the rating risk
	 */
	@XmlTransient // parent
	public RatingRisk getRatingRisk() {
		return this.ratingRisk;
	}

	/**
	 * Sets the rating risk.
	 * 
	 * @param aRatingRisk the new rating risk
	 */
	public void setRatingRisk(RatingRisk aRatingRisk) {
		AssociationsHelper.updateOneToManyFields(aRatingRisk, "multiplicativeRatingFactorFromNonBasicCoverages", this, "ratingRisk");
	}

	/**
	 * Gets the condition type.
	 * 
	 * @return the condition type
	 */
	public String getConditionType() {
		return this.conditionType;
	}

	/**
	 * Sets the condition type cd.
	 * 
	 * @param conditionTypeCd the new condition type cd
	 */
	public void setConditionType(String conditionTypeCd) {
		this.conditionType = conditionTypeCd;
	}

	/**
	 * Gets the condition.
	 * 
	 * @return the condition
	 */
	public String getCondition() {
		return this.condition;
	}

	/**
	 * Sets the condition.
	 * 
	 * @param conditionCd the new condition
	 */
	public void setCondition(String conditionCd) {
		this.condition = conditionCd;
	}

	/**
	 * Gets the rating factor apply condition.
	 * 
	 * @return the rating factor apply condition
	 */
	public String getRatingFactorApplyCondition() {
		return this.ratingFactorApplyCondition;
	}

	/**
	 * Sets the rating factor apply condition.
	 * 
	 * @param ratingFactorApplyCond the new rating factor apply condition
	 */
	public void setRatingFactorApplyCondition(String ratingFactorApplyCond) {
		this.ratingFactorApplyCondition = ratingFactorApplyCond;
	}

	/**
	 * Gets the multiplicative rating factor liability bodily injury.
	 * 
	 * @return the multiplicative rating factor liability bodily injury
	 */
	public Double getLiabilityBodilyInjuryFactor() {
		return this.liabilityBodilyInjuryFactor;
	}

	/**
	 * Sets the multiplicative rating factor liability bodily injury.
	 * 
	 * @param mlRtFctLbltyBdlyInjryQty the new multiplicative rating factor liability bodily injury
	 */
	public void setLiabilityBodilyInjuryFactor(Double mlRtFctLbltyBdlyInjryQty) {
		this.liabilityBodilyInjuryFactor = mlRtFctLbltyBdlyInjryQty;
	}

	/**
	 * Gets the multiplicative rating factor liability property damage.
	 * 
	 * @return the multiplicative rating factor liability property damage
	 */
	public Double getLiabilityPropertyDamageFactor() {
		return this.liabilityPropertyDamageFactor;
	}

	/**
	 * Sets the multiplicative rating factor liability property damage.
	 * 
	 * @param mlRtFctLbltyPrptyDmdQty the new multiplicative rating factor liability property damage
	 */
	public void setLiabilityPropertyDamageFactor(Double mlRtFctLbltyPrptyDmdQty) {
		this.liabilityPropertyDamageFactor = mlRtFctLbltyPrptyDmdQty;
	}

	/**
	 * Gets the multiplicative rating factor accident benefit.
	 * 
	 * @return the multiplicative rating factor accident benefit
	 */
	public Double getAccidentBenefitFactor() {
		return this.accidentBenefitFactor;
	}

	/**
	 * Sets the multiplicative rating factor accident benefit.
	 * 
	 * @param mlRtFctAcdntBnftQty the new multiplicative rating factor accident benefit
	 */
	public void setAccidentBenefitFactor(Double mlRtFctAcdntBnftQty) {
		this.accidentBenefitFactor = mlRtFctAcdntBnftQty;
	}

	/**
	 * Gets the multiplicative rating factor all perils.
	 * 
	 * @return the multiplicative rating factor all perils
	 */
	public Double getAllPerilsFactor() {
		return this.allPerilsFactor;
	}

	/**
	 * Sets the multiplicative rating factor all perils.
	 * 
	 * @param mlRtFctAllPerilsQty the new multiplicative rating factor all perils
	 */
	public void setAllPerilsFactor(Double mlRtFctAllPerilsQty) {
		this.allPerilsFactor = mlRtFctAllPerilsQty;
	}

	/**
	 * Gets the multiplicative rating factor collision.
	 * 
	 * @return the multiplicative rating factor collision
	 */
	public Double getCollisionFactor() {
		return this.collisionFactor;
	}

	/**
	 * Sets the multiplicative rating factor collision.
	 * 
	 * @param mlRtFctCollisionQty the new multiplicative rating factor collision
	 */
	public void setCollisionFactor(Double mlRtFctCollisionQty) {
		this.collisionFactor = mlRtFctCollisionQty;
	}

	/**
	 * Gets the multiplicative rating factor comprehensive.
	 * 
	 * @return the multiplicative rating factor comprehensive
	 */
	public Double getComprehensiveFactor() {
		return this.comprehensiveFactor;
	}

	/**
	 * Sets the multiplicative rating factor comprehensive.
	 * 
	 * @param mlRtFctComprehensiveQty the new multiplicative rating factor comprehensive
	 */
	public void setComprehensiveFactor(Double mlRtFctComprehensiveQty) {
		this.comprehensiveFactor = mlRtFctComprehensiveQty;
	}

	/**
	 * Gets the multiplicative rating factor specified perils.
	 * 
	 * @return the multiplicative rating factor specified perils
	 */
	public Double getSpecifiedPerilsFactor() {
		return this.specifiedPerilsFactor;
	}

	/**
	 * Sets the multiplicative rating factor specified perils.
	 * 
	 * @param mlRtFctSpecifiedPerilsQty the new multiplicative rating factor specified perils
	 */
	public void setSpecifiedPerilsFactor(Double mlRtFctSpecifiedPerilsQty) {
		this.specifiedPerilsFactor = mlRtFctSpecifiedPerilsQty;
	}

	/**
	 * Gets the multiplicative rating factor liability.
	 * 
	 * @return the multiplicative rating factor liability
	 */
	public Double getLiabilityFactor() {
		return this.liabilityFactor;
	}

	/**
	 * Sets the multiplicative rating factor liability.
	 * 
	 * @param mlRtFctLbltyQty the new multiplicative rating factor liability
	 */
	public void setLiabilityFactor(Double mlRtFctLbltyQty) {
		this.liabilityFactor = mlRtFctLbltyQty;
	}

	/**
	 * Gets the multiplicative rating factor medical expenses.
	 * 
	 * @return the multiplicative rating factor medical expenses
	 */
	public Double getMedicalExpensesFactor() {
		return this.medicalExpensesFactor;
	}

	/**
	 * Sets the multiplicative rating factor medical expenses.
	 * 
	 * @param mlRtFctMedicalExpensesQty the new multiplicative rating factor medical expenses
	 */
	public void setMedicalExpensesFactor(Double mlRtFctMedicalExpensesQty) {
		this.medicalExpensesFactor = mlRtFctMedicalExpensesQty;
	}

	/**
	 * Gets the multiplicative rating factor total disability.
	 * 
	 * @return the multiplicative rating factor total disability
	 */
	public Double getTotalDisabilityFactor() {
		return this.totalDisabilityFactor;
	}

	/**
	 * Sets the multiplicative rating factor total disability.
	 * 
	 * @param mlRtFctTotalDisabilityQty the new multiplicative rating factor total disability
	 */
	public void setTotalDisabilityFactor(Double mlRtFctTotalDisabilityQty) {
		this.totalDisabilityFactor = mlRtFctTotalDisabilityQty;
	}

	/**
	 * @return the fixedAmount
	 */
	public Long getFixedAmount() {
		return this.fixedAmount;
	}

	/**
	 * @param aFixedAmount the fixedAmount to set
	 */
	public void setFixedAmount(Long aFixedAmount) {
		this.fixedAmount = aFixedAmount;
	}

	/**
	 * @return the ratingFactoryType
	 */
	public RatingFactorTypeCodeEnum getRatingFactorType() {
		return this.ratingFactorType;
	}

	/**
	 * @param aRatingFactorType the rating factor type to set
	 */
	public void setRatingFactorType(RatingFactorTypeCodeEnum aRatingFactorType) {
		this.ratingFactorType = aRatingFactorType;
	}

	/**
	 * @return the ratingFactoryCalculationMethod
	 */
	public RatingFactorCalculationMethodEnum getRatingFactorCalculationMethod() {
		return this.ratingFactorCalculationMethod;
	}

	/**
	 * @param aRatingFactorCalculationMethod the rating factor calculation method to set
	 */
	public void setRatingFactorCalculationMethod(RatingFactorCalculationMethodEnum aRatingFactorCalculationMethod) {
		this.ratingFactorCalculationMethod = aRatingFactorCalculationMethod;
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
