package com.ing.canada.plp.exception;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

public class PolicyChangeServiceException extends Exception {

	private static final long serialVersionUID = 7585258243292507361L;

	public static final String PARAM_POLICY_NULL = "param.policy.policy.null";

	public static final String PARAM_COVERAGE_CHANGE_NULL = "param.policy.coverage.change.null";

	public static final String PARAM_COVERAGE_CHANGE_CODE_NULL = "param.policy.coverage.change.code.null";

	public static final String EXEC_ADD_COVERAGE_ERROR = "exec.policy.add.coverage.error";
	
	public static final String EXEC_REMOVE_COVERAGE_ERROR = "exec.policy.remove.coverage.error";
	
	public static final String EXEC_UPDATE_COVERAGE_ERROR =  "exec.policy.update.coverage.error";

	private static Map<String, String> messages = null;
	
	private String code = null;

	public PolicyChangeServiceException(String exceptionCode, Object... parameters) {
		this(exceptionCode, null, parameters);
	}

	public PolicyChangeServiceException(String exceptionCode, Throwable cause, Object... parameters) {
		this(PolicyChangeServiceException.getMessage(exceptionCode, parameters), cause);
		this.setCode(exceptionCode);
	}

	public PolicyChangeServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public static Map<String, String> getMessages() {
		return PolicyChangeServiceException.messages;
	}

	public static void setMessages(Map<String, String> messages) {
		PolicyChangeServiceException.messages = messages;
	}

	protected static String getMessage(String exceptionCode, Object... parameters) {

		if (PolicyChangeServiceException.getMessages() == null) {
			PolicyChangeServiceException.initMessages();
		}

		String messageFormat = PolicyChangeServiceException.getMessages().get(exceptionCode);
		
		if (messageFormat == null) {
			PolicyChangeServiceException.getMessages().get(exceptionCode);
		}

		return MessageFormat.format(messageFormat, parameters);
	}

	protected static synchronized void initMessages() {

		Map<String, String> messages = new HashMap<String, String>();
		
		messages.put(EXEC_UPDATE_COVERAGE_ERROR, "An error occured while updating a coverage to the policy change using the policy {1} and the coverage change {2}.  The cause is {0}.");
		messages.put(EXEC_REMOVE_COVERAGE_ERROR, "An error occured while updating a coverage to the policy change using the policy {1} and the coverage change {2}.  The cause is {0}.");
		messages.put(EXEC_ADD_COVERAGE_ERROR, "An error occured while updating a coverage to the policy change using the policy {1} and the coverage change {2}.  The cause is {0}.");

		PolicyChangeServiceException.setMessages(messages);
	}

}
