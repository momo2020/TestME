/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum TrainingTerminatedSinceCodeEnum.
 * 
 * @author plafleur
 */
public enum TrainingTerminatedSinceCodeEnum {

	LESS_THAN_ONE_YEAR("00"), ONE_YEAR_BUT_LESS_THAN_TWO("01"), TWO_YEARS_BUT_LESS_THAN_THREE("02"), THREE_YEARS("03"), MORE_THAN_THREE_YEARS(
			"90");

	/**
	 * Instantiates a new training terminated since code enum.
	 * 
	 * @param aCode the a code
	 */
	private TrainingTerminatedSinceCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the training terminated since code enum
	 */
	public static TrainingTerminatedSinceCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (TrainingTerminatedSinceCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}

}
