package com.ing.canada.plp.domain.billing;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.annotation.CaseSensitive;
import com.ing.canada.plp.domain.enums.ApplicationIdEnum;
import com.ing.canada.plp.domain.enums.BillingPlanCodeEnum;
import com.ing.canada.plp.domain.enums.CreditCardTransactionStatusCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;


@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "CREDIT_CARD_TRANS_LOG", uniqueConstraints = {})
@NamedQueries({@NamedQuery(name = "CreditCardTransLog.findCreditCardTransLogByUpperId", query = "from CreditCardTransLog cclog where upper(cclog.tokenId) = upper(:tokenId)")})
public class CreditCardTransLog extends BaseEntity  {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CREDIT_CARD_TRANS_LOG_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "CreditCardTransLogSequence")
	@SequenceGenerator(name = "CreditCardTransLogSequence", sequenceName = "CREDIT_CARD_TRANS_LOG_SEQ", allocationSize = 5)
	private Long id;

	/** The Moneris store id **/
	@Column(name = "STORE_ID", nullable = false, length = 15)
	private String storeId;
	
	/** The Moneris token id **/
	@Column(name = "TOKEN_ID", nullable = false, length = 25)
	@CaseSensitive
	private String tokenId;
	
	/** The Billing plan code **/
	@Column(name = "BILLING_PLAN_CD", nullable = false, length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.BillingPlanCodeEnum") })
	private BillingPlanCodeEnum billingPlanCode;
	
	/** The agreemetn number of the policy related to this CC info **/
	@Column(name = "AGREEMENT_NBR", nullable = false, length = 35)
	private String agreementNbr;
	
	/** The application id where this CC info is bind to **/
	@Column(name = "APPLICATION_ID", nullable = false, length = 4)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ApplicationIdEnum") })
	private ApplicationIdEnum applicationCode;
	
	/** The TransactionStatus code of this Credit Card in moneris **/
	@Column(name = "CREDIT_CARD_TRANS_STATUS_CD", nullable = false, length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.CreditCardTransactionStatusCodeEnum") })
	private CreditCardTransactionStatusCodeEnum creditCardTrxStatusCode;
	
	/** The last update timestamp. */
	@Column(name = "LAST_UPD_CRD_CARD_TR_STATUS_TS", nullable = false, length = 11)
	private Timestamp lastUpdateTimestamp;	

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}
	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	public String getAgreementNbr() {
		return this.agreementNbr;
	}

	public void setAgreementNbr(String aAgreementNbr) {
		this.agreementNbr = aAgreementNbr;
	}

	public ApplicationIdEnum getApplicationCode() {
		return this.applicationCode;
	}

	public void setApplicationCode(ApplicationIdEnum aApplicationCode) {
		this.applicationCode = aApplicationCode;
	}

	public BillingPlanCodeEnum getBillingPlanCode() {
		return this.billingPlanCode;
	}

	public void setBillingPlanCode(BillingPlanCodeEnum aBillingPlanCode) {
		this.billingPlanCode = aBillingPlanCode;
	}

	public CreditCardTransactionStatusCodeEnum getCreditCardTrxStatusCode() {
		return this.creditCardTrxStatusCode;
	}

	public void setCreditCardTrxStatusCode(
			CreditCardTransactionStatusCodeEnum aCreditCardTrxStatusCode) {
		this.creditCardTrxStatusCode = aCreditCardTrxStatusCode;
	}

	public Timestamp getLastUpdateTimestamp() {
		return this.lastUpdateTimestamp;
	}

	public void setLastUpdateTimestamp(Timestamp aLastUpdateTimestamp) {
		this.lastUpdateTimestamp = aLastUpdateTimestamp;
	}

	public String getStoreId() {
		return this.storeId;
	}

	public void setStoreId(String aStoreId) {
		this.storeId = aStoreId;
	}

	public String getTokenId() {
		return this.tokenId;
	}

	public void setTokenId(String aTokenId) {
		this.tokenId = aTokenId;
	}
	
	
	
	

}
