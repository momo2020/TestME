/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.helper;

import java.util.Collection;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * @author plafleur
 * 
 */
public final class BaseEntityHelper {

	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(BaseEntityHelper.class);

	private BaseEntityHelper() {
		// noop
	}

	/**
	 * Finds the entity with the most recent create timestamp.
	 * @param entities entities to search. 
	 * @return the last created entity.
	 */
	public static BaseEntity findMostRecentCreateTimestamp(Collection<? extends BaseEntity> entities) {
		TreeSet<BaseEntity> sortedEntities = new TreeSet<BaseEntity>(BaseEntity.CREATE_TIMESTAMP_DESC_COMPARATOR);
		sortedEntities.addAll(entities);
		return getFirst(sortedEntities);
	}

	/**
	 * Find the entity with the oldest create timestamp
	 * @param entities the entities to search. 
	 * @return the oldest created entity.
	 */
	public static BaseEntity findOldestCreateTimestamp(Collection<? extends BaseEntity> entities) {
		TreeSet<BaseEntity> sortedEntities = new TreeSet<BaseEntity>(BaseEntity.CREATE_TIMESTAMP_ASC_COMPARATOR);
		sortedEntities.addAll(entities);
		return getFirst(sortedEntities);
	}

	/**
	 * Returns the first base entity of a set (in the sort order if the set has a comparator).
	 * 
	 * @param entities
	 * @return the first element of the set
	 */
	private static BaseEntity getFirst(Set<BaseEntity> entities) {
		return entities.iterator().next();
	}

}
