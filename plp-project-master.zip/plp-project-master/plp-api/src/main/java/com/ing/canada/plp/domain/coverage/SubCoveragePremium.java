/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.coverage;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.BasicCoverageCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * SubCoveragePremium entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "SUB_COVERAGE_PREMIUM", uniqueConstraints = {})
public class SubCoveragePremium extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "SUB_COVERAGE_PREMIUM_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "SubCoveragePremiumSequence")
	@SequenceGenerator(name = "SubCoveragePremiumSequence", sequenceName = "SUB_COVERAGE_PREMIUM_SEQ", allocationSize = 5)
	private Long id;

	/** The coverage premium. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "COVERAGE_PREMIUM_ID", nullable = false, updatable = true)
	private CoveragePremium coveragePremium;

	/** The additional coverage percentage. */
	@Column(name = "ADDITIONAL_COVERAGE_PCT", precision = 5)
	private BigDecimal additionalCoveragePercentage;

	/** The annual premium amount. */
	@Column(name = "ANNUAL_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer annualPremium;

	/** The full term premium amount. */
	@Column(name = "FULL_TERM_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer fullTermPremium;

	/** The additional return premium amount. */
	@Column(name = "ADDITIONAL_RETURN_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer additionalReturnPremium;

	/** The basic coverage code. */
	@Column(name = "BASIC_COVERAGE_CD", nullable = false, length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.BasicCoverageCodeEnum") })
	private BasicCoverageCodeEnum basicCoverageCode;

	/**
	 * Instantiates a new sub coverage premium.
	 */
	public SubCoveragePremium() {
		// noarg constructor
	}

	/**
	 * Instantiates a new sub coverage premium.
	 * 
	 * @param aCoveragePremium the a coverage premium
	 * @param aBasicCoverageCode the a basic coverage code
	 */
	public SubCoveragePremium(CoveragePremium aCoveragePremium, BasicCoverageCodeEnum aBasicCoverageCode) {
		setCoveragePremium(aCoveragePremium);
		setBasicCoverageCode(aBasicCoverageCode);
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the coverage premium.
	 * 
	 * @return the coverage premium
	 */
	@XmlTransient
	public CoveragePremium getCoveragePremium() {
		return this.coveragePremium;
	}

	/**
	 * Sets the coverage premium.
	 * 
	 * @param aCoveragePremium the new coverage premium
	 */
	public void setCoveragePremium(CoveragePremium aCoveragePremium) {
		AssociationsHelper.updateOneToManyFields(aCoveragePremium, "subCoveragePremiums", this, "coveragePremium");
	}

	/**
	 * Gets the additional coverage percentage.
	 * 
	 * @return the additional coverage percentage
	 */
	public BigDecimal getAdditionalCoveragePercentage() {
		return this.additionalCoveragePercentage;
	}

	/**
	 * Sets the additional coverage percentage.
	 * 
	 * @param aAdditionalCoveragePercentage the new additional coverage percentage
	 */
	public void setAdditionalCoveragePercentage(BigDecimal aAdditionalCoveragePercentage) {
		this.additionalCoveragePercentage = aAdditionalCoveragePercentage;
	}

	/**
	 * Gets the annual premium amount.
	 * 
	 * @return the annual premium amount
	 */
	public Integer getAnnualPremium() {
		return this.annualPremium;
	}

	/**
	 * Sets the annual premium amount.
	 * 
	 * @param aAnnualPremiumAmount the new annual premium amount
	 */
	public void setAnnualPremium(Integer aAnnualPremiumAmount) {
		this.annualPremium = aAnnualPremiumAmount;
	}

	/**
	 * Gets the full term premium amount.
	 * 
	 * @return the full term premium amount
	 */
	public Integer getFullTermPremium() {
		return this.fullTermPremium;
	}

	/**
	 * Sets the full term premium amount.
	 * 
	 * @param aFullTermPremiumAmount the new full term premium amount
	 */
	public void setFullTermPremium(Integer aFullTermPremiumAmount) {
		this.fullTermPremium = aFullTermPremiumAmount;
	}

	/**
	 * Gets the additional return premium amount.
	 * 
	 * @return the additional return premium amount
	 */
	public Integer getAdditionalReturnPremium() {
		return this.additionalReturnPremium;
	}

	/**
	 * Sets the additional return premium amount.
	 * 
	 * @param aAdditionalReturnPremiumAmount the new additional return premium amount
	 */
	public void setAdditionalReturnPremium(Integer aAdditionalReturnPremiumAmount) {
		this.additionalReturnPremium = aAdditionalReturnPremiumAmount;
	}

	/**
	 * Gets the basic coverage code.
	 * 
	 * @return the basic coverage code
	 */
	public BasicCoverageCodeEnum getBasicCoverageCode() {
		return this.basicCoverageCode;
	}

	/**
	 * Sets the basic coverage code.
	 * 
	 * @param aBasicCoverageCode the new basic coverage code
	 */
	public void setBasicCoverageCode(BasicCoverageCodeEnum aBasicCoverageCode) {
		this.basicCoverageCode = aBasicCoverageCode;
	}

}
