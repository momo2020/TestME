package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

public enum TypeOfResidenceEnum {

	HOME("HO"), CONDO("CO"), TENANT("TN");

	/**
	 * Instantiates a new unit type code enum.
	 * 
	 * @param aCode the a code
	 */
	private TypeOfResidenceEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the unit type code enum
	 */
	public static TypeOfResidenceEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (TypeOfResidenceEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);
	}	

}
