/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum NumberStabilityMonthsCodeEnum.
 */
public enum NumberStabilityMonthsCodeEnum {

	/** Less than 6 */
	LESS_THAN_SIX("000"),

	/** Between 6 and 24 */
	BETWEEN_SIX_AND_TWENTYFOUR("006"),

	TWENTYFOUR_OR_MORE("024"),

    // Use for Intact
	/** Less than 1 */
	LESS_THAN_ONE("I00"),

	/** Between 1 and 2 */
	BETWEEN_ONE_AND_TWO("I12"),

	/** Between 2 and 3 */
	BETWEEN_TWO_AND_THREE("I24"),

	/** Between 3 and 4 */
	BETWEEN_THREE_AND_FOUR("I36"),

	/** Between 4 and 5 */
	BETWEEN_FOUR_AND_FIVE("I48"),

	/** 5 or more */
	FIVE_OR_MORE("I60"),

	/** Between 5 and 6 */
	BETWEEN_FIVE_AND_SIX("A60"),

	/** Between 6 and 7 */
	BETWEEN_SIX_AND_SEVEN("A72"),

	/** Between 7 and 8 */
	BETWEEN_SEVEN_AND_EIGHT("A84"),

	/** Between 8 and 9 */
	BETWEEN_EIGHT_AND_NINE("A96"),

	/** Between 9 and 10 */
	BETWEEN_NINE_AND_TEN("108"),

	/** 10 or more */
	TEN_OR_MORE("120");

	/**
	 * Instantiates a new vehicle category code enum.
	 * 
	 * @param aCode the a code
	 */
	private NumberStabilityMonthsCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the vehicle category code enum
	 */
	public static NumberStabilityMonthsCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (NumberStabilityMonthsCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}

	/**
	 * Get the equivalent number of stability months for a {@link NumberStabilityMonthsCodeEnum}
	 * for AutoQuoters
	 *
	 * @param nbStabilityMonth {@link NumberStabilityMonthsCodeEnum}
	 * @return the corresponding numerical value
	 */
	public static int getNumberStabilityMonths(final NumberStabilityMonthsCodeEnum nbStabilityMonth) {
		int value;
		switch (nbStabilityMonth) {
		case LESS_THAN_ONE:
			/* less than one returning 5 is not an eror.
			 * This is currently the minimum logical value accepted. */
		case LESS_THAN_SIX:
			value = 5;
			break;
		case BETWEEN_SIX_AND_TWENTYFOUR:
			value = 9;
			break;
		case TWENTYFOUR_OR_MORE:
			value = 54;
			break;
		case BETWEEN_ONE_AND_TWO:
			value = 18;
			break;
		case BETWEEN_TWO_AND_THREE:
			value = 30;
			break;
		case BETWEEN_THREE_AND_FOUR:
			value = 42;
			break;
		case BETWEEN_FOUR_AND_FIVE:
			value = 54;
			break;
		case FIVE_OR_MORE:
			value = 66;
			break;
		default:
			value = 0;
		}
		return value;
	}

}
