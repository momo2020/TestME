/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum OtherProvinceOfUseCodeEnum.
 */
public enum OtherProvinceOfUseCodeEnum {

	ALBERTA("AB"), BRITISH_COLUMBIA("BC"), MANITOBA("MB"), NEW_BRUNSWICK("NB"), NEWFOUNDLAND_AND_LABRADOR("NL"), NOVA_SCOTIA(
			"NS"), ONTARIO("ON"), PRINCE_EDWARD_ISLAND("PE"), QUEBEC("QC"), SASKATCHEWAN("SK"), NORTHWEST_TERRITORIES(
			"NT"), YUKON("YT"), NUNAVUT("NU"), OTHER("OT"), USA("US"), EUROPE("EC");

	/**
	 * Instantiates a new other province of use code enum.
	 * 
	 * @param aCode the a code
	 */
	private OtherProvinceOfUseCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the other province of use code enum
	 */
	public static OtherProvinceOfUseCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (OtherProvinceOfUseCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
