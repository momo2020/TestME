/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum TransactionStatusCodeEnum.
 * 
 * Modifications: May 1st, 2008: added the ABEND constant
 */
public enum TransactionStatusCodeEnum {

	SUSPENDED("S"),
	ABEND("Z"),
	GET_OFFER("X"),
	BIND_IN_PROGRESS_BUT_NOT_CONFIRM("Y"),
	SUBMITTED_BY_THE_REQUESTER("W"),
	DECLINED_BY_COMPANY("D"), 
	ACCEPTED_BY_NONE_QA_AGENT("V"), 
	ACCEPTED("A"),
	INTERVENTION_REQUIRED_NO_PREMIUM_AVAILABLE("I"),
	
	TO_BE_CONFIRMED_BY_REQUESTER("C"), 		 
	INTERVENTION_REQUIRED_PREMIUM_AVAILABLE("J"),
	REFUSED_BY_CLIENT("R");
 
	
	

	/**
	 * Instantiates a new transaction status code enum.
	 * 
	 * @param aCode the a code
	 */
	private TransactionStatusCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the transaction status code enum
	 */
	public static TransactionStatusCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (TransactionStatusCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
