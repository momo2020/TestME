/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum ConditionTypeCodeEnum.
 */
public enum ConditionTypeCodeEnum {

	/** The ENDORSEMENT. */
	ENDORSEMENT("EN"),
	/** The GROUP. */
	GROUP("GR"),
	/** Basic coverage condition type. */
	BASIC_COVERAGE("BC"),
	/** The GRID condition type. */
	GRID("GRD"),
	/** The additinnal premium condition type*/
	SU("SU"),
	/** The TC condition type. */
	TC("TC"),
	/** The WEB condition type. */
	WEB("WEB"),
	/** The DLT condition type. */
	DLT("DLT"),
	/** The A Premium condition type. */
	PRA("PRA"),
	/** The Vehicle Rebate */
	VEHICLE_REBATE("VR");
	
	

	/**
	 * Instantiates a new client eligibility level code enum.
	 * 
	 * @param aCode
	 *            the a code
	 */
	private ConditionTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value
	 *            the value
	 * 
	 * @return the client eligibility level code enum
	 */
	public static ConditionTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (ConditionTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: "
				+ value);

	}
}
