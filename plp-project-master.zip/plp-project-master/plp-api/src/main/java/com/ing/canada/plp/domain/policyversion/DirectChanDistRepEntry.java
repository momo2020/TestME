/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2017, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.policyversion;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.enums.DistributorCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * Direct Channel Distributor Repository Entry.<br>
 * This is used to identify the ditributor in the context of "Direct Sale". <br>
 *
 * @author <a href="mailto:pascal.meunier@intact.net">Pascal Meunier</a>
 *
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "DIRECT_CHAN_DIST_REP_ENTRY",
	   uniqueConstraints = { @UniqueConstraint(columnNames = { "DIRECT_CHAN_DIST_CD" }) }
)
@NamedQueries({
	@NamedQuery(
		name = "DirectChanDistRepEntry.findByCode",
		query = "from DirectChanDistRepEntry dcdre where code = :code and effectiveDate IS NOT NULL "
	),
})
public class DirectChanDistRepEntry extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "DIRECT_CHAN_DIST_REP_ENTRY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "DirectChanDistRepEntrySeq")
	@SequenceGenerator(name = "DirectChanDistRepEntrySeq", sequenceName = "DIRECT_CHAN_DIST_REP_ENTRY_SEQ", allocationSize = 5)
	private Long id;

	/** The party group type. */
	@Column(name = "DIRECT_CHAN_DIST_CD", length = 10)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType",
		  parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.DistributorCodeEnum") } )
	private DistributorCodeEnum code;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", length = 7)
	private Date effectiveDate;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;


	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object getId() {
		return this.id;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setId(Object id) {
		this.id = (Long) id;
	}

	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public DistributorCodeEnum getCode() {
		return this.code;
	}

	public Date getExpiryDate() {
		return this.expiryDate;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setCode(DistributorCodeEnum code) {
		this.code = code;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

}
