/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved. 
 */
package com.ing.canada.plp.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author mblouin Use with UppercaseStringInterceptor, when present on a property, the field will conserve his Case in
 *         the DB.
 * 
 * Ex : (with CaseSensitive) fFiSdE -> fFiSdE (no CaseSensitive) fFiSdE -> FFISDE
 * 
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface CaseSensitive {
	// Nothing to implements
}
