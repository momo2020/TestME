/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.usertype;

/**
 * The Interface Auditable.
 */
public interface Auditable {

	/**
	 * Gets the audit trail.
	 * 
	 * @return the audit trail
	 */
	AuditTrail getAuditTrail();

	/**
	 * Sets the audit trail.
	 * 
	 * @param trail the new audit trail
	 */
	void setAuditTrail(AuditTrail trail);

}
