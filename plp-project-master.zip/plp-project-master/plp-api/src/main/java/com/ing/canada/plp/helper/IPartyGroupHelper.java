/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import java.util.Set;

import com.ing.canada.plp.domain.driver.AffinityGroupRepositoryEntry;
import com.ing.canada.plp.domain.enums.GroupRepositoryEntryEnum;
import com.ing.canada.plp.domain.enums.PartyGroupTypeCodeEnum;
import com.ing.canada.plp.domain.party.Party;
import com.ing.canada.plp.domain.party.PartyGroup;
import com.ing.canada.plp.domain.policyversion.PolicyHolder;

/**
 * The Interface IPartyGroupHelper.
 *
 * @author strichar
 */
public interface IPartyGroupHelper {

	/**
	 * gets a party group.
	 *
	 * @param groupCode the group code
	 * @param aParty the a party
	 *
	 * @return true, if successful
	 */
	PartyGroup getPartyGroup(Party aParty, String groupCode);


	/**
	 * Scans all the parties in list to see if one of them
	 * has the group matching de code.
	 *
	 * @param aParties
	 * @param aGroupCode
	 * @return
	 */
	boolean isPartyGroupPresent(Set<Party> aParties, GroupRepositoryEntryEnum group);


	PartyGroup getPartyGroup(Party aParty, PartyGroupTypeCodeEnum aGroupType);

	/**
	 * Gets the party group for principal insured.
	 *
	 * @param groupCode the group code
	 * @param policyHolderSet the policy holder set
	 *
	 * @return the party group for principal insured
	 */
	PartyGroup getPartyGroupForPrincipalInsured(Set<PolicyHolder> policyHolderSet, String groupCode);


	/**
	 * Look for an affinity group repository entry linked to a specific party group by party group type.
	 *
	 * @param party {@link Party}
	 * @param partyGroupTypeCode {@link PartyGroupTypeCodeEnum}
	 * @return {@link AffinityGroupRepositoryEntry} when found, null otherwise
	 */
	AffinityGroupRepositoryEntry findAffinityGroupRepositoryEntry(final Party party, final PartyGroupTypeCodeEnum partyGroupTypeCode);
}
