/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum DrivingRecordCodeEnum.
 */
public enum DrivingRecordCodeEnum {

	DRIVING_RECORD_ZERO("00"), DRIVING_RECORD_ONE("01"), DRIVING_RECORD_TWO("02"), DRIVING_RECORD_THREE("03"), DRIVING_RECORD_FOUR(
			"04"), DRIVING_RECORD_FIVE("05"), DRIVING_RECORD_SIX("06"), DRIVING_RECORD_SEVEN("07"), DRIVING_RECORD_NINE(
			"09"), DRIVING_RECORD_TEN("10");

	/**
	 * Instantiates a new driving record code enum.
	 * 
	 * @param aCode the a code
	 */
	private DrivingRecordCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the driving record code enum
	 */
	public static DrivingRecordCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (DrivingRecordCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
