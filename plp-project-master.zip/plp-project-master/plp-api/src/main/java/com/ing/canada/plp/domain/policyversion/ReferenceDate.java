/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.policyversion;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * ReferenceDate entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "REFERENCE_DATE", uniqueConstraints = { @UniqueConstraint(columnNames = { "POLICY_VERSION_ID" }) })
public class ReferenceDate extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	// Fields
	/** The id. */
	@Id
	@GeneratedValue(generator = "policyVersionForeignGenerator")
	@org.hibernate.annotations.GenericGenerator(name = "policyVersionForeignGenerator", strategy = "foreign", parameters = @Parameter(name = "property", value = "policyVersion"))
	@Column(name = "POLICY_VERSION_ID")
	private Long id = null;

	/** The policy version. */
	@OneToOne(cascade = {}, fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn(name = "POLICY_VERSION_ID")
	private PolicyVersion policyVersion;

	/** The claim reference date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "CLAIM_REF_DT", length = 7)
	private Date claimReferenceDate;

	/** The credit score reference date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "CREDIT_SCORE_REF_DT", length = 7)
	private Date creditScoreReferenceDate;

	/** The driver age reference date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "DRIVER_AGE_REF_DT", length = 7)
	private Date driverAgeReferenceDate;

	/** The license obtained period reference date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "LICENSE_OBTAINED_PERIOD_REF_DT", length = 7)
	private Date licenseObtainedPeriodReferenceDate;

	/** The vehicle age reference date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "VEHICLE_AGE_REF_DT", length = 7)
	private Date vehicleAgeReferenceDate;

	/** The transaction creation reference date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "TRX_CREATION_REF_DT", length = 7)
	private Date transactionCreationReferenceDate;

	/** The transaction first rating reference date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "TRX_FIRST_RATING_REF_DT", length = 7)
	private Date transactionFirstRatingReferenceDate;

	/**
	 * default constructor.
	 */
	public ReferenceDate() {
		// Nothing to do
	}

	/**
	 * minimal constructor.
	 * 
	 * @param policyVersionToSet the policy version
	 */
	public ReferenceDate(PolicyVersion policyVersionToSet) {
		setPolicyVersion(policyVersionToSet);
	}

	/**
	 * full constructor.
	 * 
	 * @param policyVersionId the policy version id
	 * @param aPolicyVersion the policy version
	 * @param claimRefDt the claim ref dt
	 * @param creditScoreRefDt the credit score ref dt
	 * @param driverAgeRefDt the driver age ref dt
	 * @param licenseObtainedPeriodRefDt the license obtained period ref dt
	 * @param vehicleAgeRefDt the vehicle age ref dt
	 * @param trxCreationRefDt the trx creation ref dt
	 * @param trxFirstRatingRefDt the trx first rating ref dt
	 */
	public ReferenceDate(Long policyVersionId, PolicyVersion aPolicyVersion, Date claimRefDt, Date creditScoreRefDt,
			Date driverAgeRefDt, Date licenseObtainedPeriodRefDt, Date vehicleAgeRefDt, Date trxCreationRefDt,
			Date trxFirstRatingRefDt) {
		this.policyVersion = aPolicyVersion;
		this.claimReferenceDate = claimRefDt;
		this.creditScoreReferenceDate = creditScoreRefDt;
		this.driverAgeReferenceDate = driverAgeRefDt;
		this.licenseObtainedPeriodReferenceDate = licenseObtainedPeriodRefDt;
		this.vehicleAgeReferenceDate = vehicleAgeRefDt;
		this.transactionCreationReferenceDate = trxCreationRefDt;
		this.transactionFirstRatingReferenceDate = trxFirstRatingRefDt;
	}

	// Property accessors
	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object policyVersionId) {
		this.id = (Long) policyVersionId;
	}

	/**
	 * Gets the policy version.
	 * 
	 * @return the policy version
	 */
	@XmlTransient // parent
	public PolicyVersion getPolicyVersion() {
		return this.policyVersion;
	}

	/**
	 * Sets the policy version.
	 * 
	 * @param aPolicyVersion the new policy version
	 */
	public void setPolicyVersion(PolicyVersion aPolicyVersion) {
		AssociationsHelper.updateOneToOneFields(aPolicyVersion, PolicyVersion.class, "referenceDate", this,
				ReferenceDate.class, "policyVersion");
	}

	/**
	 * Gets the claim reference date.
	 * 
	 * @return the claim reference date
	 */
	public Date getClaimReferenceDate() {
		return this.claimReferenceDate;
	}

	/**
	 * Sets the claim reference date.
	 * 
	 * @param claimRefDt the new claim reference date
	 */
	public void setClaimReferenceDate(Date claimRefDt) {
		this.claimReferenceDate = claimRefDt;
	}

	/**
	 * Gets the credit score reference date.
	 * 
	 * @return the credit score reference date
	 */
	public Date getCreditScoreReferenceDate() {
		return this.creditScoreReferenceDate;
	}

	/**
	 * Sets the credit score reference date.
	 * 
	 * @param creditScoreRefDt the new credit score reference date
	 */
	public void setCreditScoreReferenceDate(Date creditScoreRefDt) {
		this.creditScoreReferenceDate = creditScoreRefDt;
	}

	/**
	 * Gets the driver age reference date.
	 * 
	 * @return the driver age reference date
	 */
	public Date getDriverAgeReferenceDate() {
		return this.driverAgeReferenceDate;
	}

	/**
	 * Sets the driver age reference date.
	 * 
	 * @param driverAgeRefDt the new driver age reference date
	 */
	public void setDriverAgeReferenceDate(Date driverAgeRefDt) {
		this.driverAgeReferenceDate = driverAgeRefDt;
	}

	/**
	 * Gets the license obtained period reference date.
	 * 
	 * @return the license obtained period reference date
	 */
	public Date getLicenseObtainedPeriodReferenceDate() {
		return this.licenseObtainedPeriodReferenceDate;
	}

	/**
	 * Sets the license obtained period reference date.
	 * 
	 * @param licenseObtainedPeriodRefDt the new license obtained period reference date
	 */
	public void setLicenseObtainedPeriodReferenceDate(Date licenseObtainedPeriodRefDt) {
		this.licenseObtainedPeriodReferenceDate = licenseObtainedPeriodRefDt;
	}

	/**
	 * Gets the vehicle age reference date.
	 * 
	 * @return the vehicle age reference date
	 */
	public Date getVehicleAgeReferenceDate() {
		return this.vehicleAgeReferenceDate;
	}

	/**
	 * Sets the vehicle age reference date.
	 * 
	 * @param vehicleAgeRefDt the new vehicle age reference date
	 */
	public void setVehicleAgeReferenceDate(Date vehicleAgeRefDt) {
		this.vehicleAgeReferenceDate = vehicleAgeRefDt;
	}

	/**
	 * Gets the transaction creation reference date.
	 * 
	 * @return the transaction creation reference date
	 */
	public Date getTransactionCreationReferenceDate() {
		return this.transactionCreationReferenceDate;
	}

	/**
	 * Sets the transaction creation reference date.
	 * 
	 * @param trxCreationRefDt the new transaction creation reference date
	 */
	public void setTransactionCreationReferenceDate(Date trxCreationRefDt) {
		this.transactionCreationReferenceDate = trxCreationRefDt;
	}

	/**
	 * Gets the transaction first rating reference date.
	 * 
	 * @return the transaction first rating reference date
	 */
	public Date getTransactionFirstRatingReferenceDate() {
		return this.transactionFirstRatingReferenceDate;
	}

	/**
	 * Sets the transaction first rating reference date.
	 * 
	 * @param trxFirstRatingRefDt the new transaction first rating reference date
	 */
	public void setTransactionFirstRatingReferenceDate(Date trxFirstRatingRefDt) {
		this.transactionFirstRatingReferenceDate = trxFirstRatingRefDt;
	}

}
