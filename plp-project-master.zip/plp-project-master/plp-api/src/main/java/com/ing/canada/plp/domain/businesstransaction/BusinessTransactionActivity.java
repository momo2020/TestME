/**
\ * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.businesstransaction;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.ApplicationIdEnum;
import com.ing.canada.plp.domain.enums.BusinessTransactionActivityCodeEnum;
import com.ing.canada.plp.domain.enums.UserTypeCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * BusinessTransactionActivity entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "BUSINESS_TRX_ACTIVITY", uniqueConstraints = {})
@NamedQueries( {
		@NamedQuery(name = "BusinessTransactionActivity.findLastUploadNotCancelled", query = "select a from BusinessTransactionActivity a where a.businessTransaction.id = :businessTransactionId and a.businessTransactionActivityCode = :uploadActivityCode and a.auditTrail.createTimestamp = (select max(a2.auditTrail.createTimestamp) from BusinessTransactionActivity a2 where a2.businessTransactionActivityCode = :uploadActivityCode and a2.businessTransaction.id = :businessTransactionId) and not exists (select a3 from BusinessTransactionActivity a3 where a3.businessTransaction.id = :businessTransactionId and a3.auditTrail.createTimestamp > a.auditTrail.createTimestamp and a3.businessTransactionActivityCode = :cancelledActivityCode)"),
		@NamedQuery(name = "BusinessTransactionActivity.findLastBusinessTransactionActivity", query = "from BusinessTransactionActivity bta where bta.businessTransaction.id = :businessTransactionId and bta.auditTrail.createTimestamp = (select max(bta2.auditTrail.createTimestamp) from BusinessTransactionActivity bta2 where bta2.businessTransaction.id = :businessTransactionId)"),
		@NamedQuery(name = "BusinessTransactionActivity.countComplementInfosBySubActivityCodeAndAttributeValue", query = "select count(ci) from BusinessTransactionActivity bta join bta.businessTransactionSubActivities btsa join btsa.businessTransactionSubActivityComplementInfos ci where bta.id = :businessTransactionActivityId and btsa.subActivityCode = :subActivityCode and ci.attributeValue = :attributeValue"),
		@NamedQuery(name = "BusinessTransactionActivity.findIQPBusinessTransactionActivityForInsurancePolicy", query = "select bta from BusinessTransactionActivity bta inner join bta.businessTransaction as bt inner join bt.policyVersion as pv inner join pv.insurancePolicy as ip where bta.businessTransactionActivityCode = 'IQP' and ip.agreementNumber = :agreementNumber") })
public class BusinessTransactionActivity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "BUSINESS_TRX_ACTIVITY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "BusinessTransactionActivitySequence")
	@SequenceGenerator(name = "BusinessTransactionActivitySequence", sequenceName = "BUSINESS_TRX_ACTIVITY_SEQ", allocationSize = 5)
	protected Long id;

	/** The business transaction. */
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "BUSINESS_TRANSACTION_ID", nullable = false, updatable = true)
	protected BusinessTransaction businessTransaction;

	/** The user type. */
	@Column(name = "USER_TYPE_CD", nullable = false, length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.UserTypeCodeEnum") })
	protected UserTypeCodeEnum userType;

	/**
	 * The user id. To clear up any more confusion, the value that goes in this field is as follows: For a client: it is
	 * the client number (not the CIF ID). For an agent: it is the CRM user id of the agent.
	 */
	@Column(name = "USER_ID", nullable = true, length = 65)
	protected String userId;

	/** The mainframe user id. */
	@Column(name = "MAINFRAME_USER_ID", length = 8)
	protected String mainframeUserId;

	/** The application identification. */
	@Column(name = "APPLICATION_ID", nullable = false, length = 4)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ApplicationIdEnum") })
	protected ApplicationIdEnum applicationIdentification;

	/** The business transaction activity code. */
	@Column(name = "BSNS_TRX_ACTIVITY_CD", nullable = false, length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.BusinessTransactionActivityCodeEnum") })
	protected BusinessTransactionActivityCodeEnum businessTransactionActivityCode;

	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "businessTransactionActivity")
	private Set<BusinessTransactionSubActivity> businessTransactionSubActivities = new HashSet<BusinessTransactionSubActivity>();

	/**
	 * Instantiates a new business transaction activity.
	 */
	public BusinessTransactionActivity() {
		// noarg constructor
	}

	/**
	 * Instantiates a new business transaction activity.
	 * 
	 * @param aBusinessTransaction the a business transaction
	 * @param userTypeCode the user type code
	 * @param bsnsTrxActivityCode the bsns trx activity code
	 * @param anApplicationId the an application id
	 */
	public BusinessTransactionActivity(BusinessTransaction aBusinessTransaction, UserTypeCodeEnum userTypeCode,
			ApplicationIdEnum anApplicationId, BusinessTransactionActivityCodeEnum bsnsTrxActivityCode) {
		setBusinessTransaction(aBusinessTransaction);
		setUserType(userTypeCode);
		setApplicationIdentification(anApplicationId);
		setBusinessTransactionActivityCode(bsnsTrxActivityCode);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the business transaction.
	 * 
	 * @return the business transaction
	 */
	@XmlTransient // parent
	public BusinessTransaction getBusinessTransaction() {
		return this.businessTransaction;
	}

	/**
	 * Sets the business transaction.
	 * 
	 * @param aBusinessTransaction the new business transaction
	 */
	public void setBusinessTransaction(BusinessTransaction aBusinessTransaction) {
		AssociationsHelper.updateOneToManyFields(aBusinessTransaction, "businessTransactionActivities", this,
				"businessTransaction");
	}

	/**
	 * Gets the user type.
	 * 
	 * @return the user type
	 */
	public UserTypeCodeEnum getUserType() {
		return this.userType;
	}

	/**
	 * Sets the user type code.
	 * 
	 * @param userTypeCode the new user type code
	 */
	public void setUserType(UserTypeCodeEnum userTypeCode) {
		this.userType = userTypeCode;
	}

	/**
	 * Gets the user id.
	 * 
	 * @return the user id
	 */
	public String getUserId() {
		return this.userId;
	}

	/**
	 * Sets the user id.
	 * 
	 * @param aUserId the new user id
	 */
	public void setUserId(String aUserId) {
		this.userId = aUserId;
	}

	/**
	 * Gets the mainframe user id.
	 * 
	 * @return the mainframe user id
	 */
	public String getMainframeUserId() {
		return this.mainframeUserId;
	}

	/**
	 * Sets the mainframe user id.
	 * 
	 * @param aMainframeUserId the new mainframe user id
	 */
	public void setMainframeUserId(String aMainframeUserId) {
		this.mainframeUserId = aMainframeUserId;
	}

	/**
	 * Gets the application identification.
	 * 
	 * @return the application identification
	 */
	public ApplicationIdEnum getApplicationIdentification() {
		return this.applicationIdentification;
	}

	/**
	 * Sets the application identification.
	 * 
	 * @param applicationId the new application identification
	 */
	public void setApplicationIdentification(ApplicationIdEnum applicationId) {
		this.applicationIdentification = applicationId;
	}

	/**
	 * Gets the business transaction activity code.
	 * 
	 * @return the business transaction activity code
	 */
	public BusinessTransactionActivityCodeEnum getBusinessTransactionActivityCode() {
		return this.businessTransactionActivityCode;
	}

	/**
	 * Sets the business transaction activity code.
	 * 
	 * @param bsnsTrxActivityCode the new business transaction activity code
	 */
	public void setBusinessTransactionActivityCode(BusinessTransactionActivityCodeEnum bsnsTrxActivityCode) {
		this.businessTransactionActivityCode = bsnsTrxActivityCode;
	}

	/**
	 * Gets the business transaction sub activities.
	 * 
	 * @return business transaction sub activities.
	 */
	@XmlElementWrapper(name="businessTransactionSubActivities")
	@XmlElement(name="businessTransactionSubActivitY")
	public Set<BusinessTransactionSubActivity> getBusinessTransactionSubActivities() {
		return Collections.unmodifiableSet(this.businessTransactionSubActivities);
	}

	/**
	 * Sets the business transaction sub activities.
	 * 
	 * @param aBusinessTransactionSubActivities business transaction sub activities to set
	 */
	protected void setBusinessTransactionSubActivities(
			Set<BusinessTransactionSubActivity> aBusinessTransactionSubActivities) {
		this.businessTransactionSubActivities = aBusinessTransactionSubActivities;
	}

	/**
	 * @see AssociationsHelper#updateOneToManyFields(Object, String, Object, String)
	 * @param btsa
	 */
	public void addBusinessTransactionSubActivity(BusinessTransactionSubActivity btsa) {
		AssociationsHelper.updateOneToManyFields(this, "businessTransactionSubActivities", btsa,
				"businessTransactionActivity");
	}

	/**
	 * @see AssociationsHelper#updateOneToManyFields(Object, String, Object, String)
	 * @param btsa
	 */
	public void removeBusinessTransactionSubActivity(BusinessTransactionSubActivity btsa) {
		AssociationsHelper.updateOneToManyFields(null, "businessTransactionSubActivities", btsa,
				"businessTransactionActivity");
	}

}
