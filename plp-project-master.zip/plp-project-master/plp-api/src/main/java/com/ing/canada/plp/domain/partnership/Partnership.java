package com.ing.canada.plp.domain.partnership;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.annotation.CaseSensitive;
import com.ing.canada.plp.domain.enums.PartnershipCodeEnum;
import com.ing.canada.plp.domain.party.Party;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;
import com.ing.canada.plp.domain.usertype.BaseEntity;

@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "PARTNERSHIP")
public class Partnership extends BaseEntity {
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "PARTNERSHIP_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "PartnershipSequence")
	@SequenceGenerator(name = "PartnershipSequence", sequenceName = "PARTNERSHIP_SEQ", allocationSize = 5)
	private Long id;

	/** The advisor of the partnership. */
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn(name = "ADVISOR_PARTY_ID")
	private Party advisor;

	@Column(name = "PARTNERSHIP_CD", length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PartnershipCodeEnum") })
	private PartnershipCodeEnum partnershipCode;

	/** The partnership group */
	@Column(name = "GROUP_NBR", length = 10)
	private String groupNumber;

	/** The partnership subgroup */
	@Column(name = "SUBGROUP_NBR", length = 20)
	private String subgroupNumber;

	/** The promotion source */
	@Column(name = "PROMO_SOURCE_NBR", length = 5)
	private String promotionSource;

	/** The workitem number (references the partner's db) */
	@Column(name = "PARTNER_WORKITEM_NBR", length = 20)
	private String partnerWorkitemNumber;

	/** The client number (references the partner's db) */
	@Column(name = "PARTNER_CLIENT_NBR", length = 20)
	private String partnerClientNumber;

	/** The group policy number (references the partner's db) */
	@Column(name = "PARTNER_GROUP_POLICY_NBR", length = 20)
	private String partnerGroupPolicyNumber;

	/** The comment (provided by the partner) */
	@Column(name = "PARTNER_COMMENT_TXT", length = 250)
	private String partnerComment;

	/** The advisor number */
	@Column(name = "ADVISOR_NBR", length = 20)
	private String advisorNumber;

	/** Financial service consultant */
	@Column(name = "FIN_SERVICE_CONSULTANT_NBR", length = 20)
	private String financialServiceConsultant;

	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "POLICY_VERSION_ID")
	private PolicyVersion policyVersion;

	@Column(name = "PARTNER_CAMPAIGN_NBR", length = 20)
	private String partnerCampaignNumber;

	@Column(name = "PARTNER_URL_REQUEST_TXT", length = 500)
	@CaseSensitive
	private String partnerUrlRequestText;

	@Column(name = "ADVISOR_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean advisorIndicator;

	public Partnership() {
		super();
	}

	@Override
	public Long getId() {
		return this.id;
	}

	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	public Party getAdvisor() {
		return this.advisor;
	}

	public void setAdvisor(Party advisor) {
		this.advisor = advisor;
	}

	public PartnershipCodeEnum getPartnershipCode() {
		return this.partnershipCode;
	}

	public void setPartnershipCode(PartnershipCodeEnum partnershipCode) {
		this.partnershipCode = partnershipCode;
	}

	public String getGroupNumber() {
		return this.groupNumber;
	}

	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	public String getSubgroupNumber() {
		return this.subgroupNumber;
	}

	public void setSubgroupNumber(String subgroupNumber) {
		this.subgroupNumber = subgroupNumber;
	}

	public String getPromotionSource() {
		return this.promotionSource;
	}

	public void setPromotionSource(String promotionSource) {
		this.promotionSource = promotionSource;
	}

	public String getPartnerWorkitemNumber() {
		return this.partnerWorkitemNumber;
	}

	public void setPartnerWorkitemNumber(String partnerWorkitemNumber) {
		this.partnerWorkitemNumber = partnerWorkitemNumber;
	}

	public String getPartnerClientNumber() {
		return this.partnerClientNumber;
	}

	public void setPartnerClientNumber(String partnerClientNumber) {
		this.partnerClientNumber = partnerClientNumber;
	}

	public String getPartnerGroupPolicyNumber() {
		return this.partnerGroupPolicyNumber;
	}

	public void setPartnerGroupPolicyNumber(String partnerGroupPolicyNumber) {
		this.partnerGroupPolicyNumber = partnerGroupPolicyNumber;
	}

	public String getPartnerComment() {
		return this.partnerComment;
	}

	public void setPartnerComment(String partnerComment) {
		this.partnerComment = partnerComment;
	}

	public String getAdvisorNumber() {
		return this.advisorNumber;
	}

	public void setAdvisorNumber(String advisorNumber) {
		this.advisorNumber = advisorNumber;
	}

	public String getFinancialServiceConsultant() {
		return this.financialServiceConsultant;
	}

	public void setFinancialServiceConsultant(String financialServiceConsultant) {
		this.financialServiceConsultant = financialServiceConsultant;
	}

	@XmlTransient // parent
	public PolicyVersion getPolicyVersion() {
		return this.policyVersion;
	}

	public void setPolicyVersion(PolicyVersion policyVersion) {
		this.policyVersion = policyVersion;
	}

	public String getPartnerCampaignNumber() {
		return this.partnerCampaignNumber;
	}

	public void setPartnerCampaignNumber(String partnerCampaignNumber) {
		this.partnerCampaignNumber = partnerCampaignNumber;
	}

	public String getPartnerUrlRequestText() {
		return this.partnerUrlRequestText;
	}

	public void setPartnerUrlRequestText(String partnerUrlRequestText) {
		this.partnerUrlRequestText = partnerUrlRequestText;
	}

	public Boolean getAdvisorIndicator() {
		return this.advisorIndicator;
	}

	public void setAdvisorIndicator(Boolean advisorIndicator) {
		this.advisorIndicator = advisorIndicator;
	}
}
