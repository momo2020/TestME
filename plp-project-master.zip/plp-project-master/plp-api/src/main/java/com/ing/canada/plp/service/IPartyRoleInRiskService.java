/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.party.PartyRoleInRisk;

/**
 * This interface exposes services required to manage Party related entities.
 * 
 * @author fsimard
 */
public interface IPartyRoleInRiskService extends ICRUDService<PartyRoleInRisk> {
	// no-op - All operations are in the parent class
}
