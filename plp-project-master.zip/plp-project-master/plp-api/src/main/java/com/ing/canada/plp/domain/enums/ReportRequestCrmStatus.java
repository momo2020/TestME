package com.ing.canada.plp.domain.enums;

import static org.apache.commons.lang.StringUtils.isEmpty;

public enum ReportRequestCrmStatus {
	
	RETRIEVED("party_task_document.status.retrieved"),
	NOT_RETRIEVED("party_task_document.status.not_retrieved"),
	NOT_CALLED("party_task_document.status.not_called"),
	ERROR("party_task_document.status.error");
	
	
	private String code;
	
	
	private ReportRequestCrmStatus(final String code){
		this.code = code;
	}
	
	public String getCode() {
		return code;
	}


	public void setCode(final String code) {
		this.code = code;
	}
	
	
	public static ReportRequestCrmStatus valueOfCode(final String code) {

		if (isEmpty(code))
			return null;

		for (ReportRequestCrmStatus c : values()) {
			if (c.code.equals(code)) {
				return (c);
			}

		}

		throw new IllegalArgumentException("RequestStatus enum code=" + code + " does not exist");

	}

}
