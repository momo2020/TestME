/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum RiskSubTypeCodeEnum.
 */
public enum RiskSubTypeCodeEnum {
	
	ANTIQUE_AUTOMOBILE("ANT"), 
	ALL_TERRAIN_VEHICLE("ATV"),
	PERSONAL_BOAT("BOA"), 
	CABIN_HOME_TRAILER("CAB"), 
	CLASSIC_AUTOMOBILE("CLA"), 
	CAMPING_UNIT("CMP"), 
	COMMERCIAL_TRAILER("CMT"), 
	COMMERCIAL_VEHICLE("COA"), 
	CONDO("CON"), 
	COMPREHENSIVE_PERSONAL_LIABILITY("CPL"), 
	FIRE_AND_EXTENDED_COVERAGE_WITH_BURGLAR("FEB"), 
	FIRE_AND_EXTENDED_COVERAGE("FEC"), 
	TRAVELWELL("GRT"), 
	HOMEOWNER("HOM"), 
	MOTORCYCLE("MCY"), 
	MOTORHOME("MHO"), 
	MOPED("MOP"), 
	PUBLIC_VEHICLE("PUB"), 
	PERSONAL_UMBRELLA("PUM"), 
	PRIVATE_PASSENGER_AUTO("PPA"), 
	PROPERTY_TRAILERS("PTR"), 
	RECREATIONAL_VEHICLE("REA"), 
	BC_RECREATIONAL_VEHICLE("REC"), 
	SNOWMOBILE("SNO"), 
	TENT_TRAILER("TEN"),
	TENANT("TNT"), 
	UNKNOWN_RISK_SUBTYPE("UNK"), 
	UTILITY_TRAILER("UTI");
	
	/**
	 * Instantiates a new risk type code enum.
	 * 
	 * @param aCode the a code
	 */
	private RiskSubTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the risk type code enum
	 */
	public static RiskSubTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (RiskSubTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
