/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insurancerisk;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.AdditionalInterestTypeCodeEnum;
import com.ing.canada.plp.domain.enums.LanguageCodeEnum;
import com.ing.canada.plp.domain.party.Address;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * AdditionalInterestRole entity.
 *
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "ADDL_INTEREST_REP_ENTRY", uniqueConstraints = {})
public class AdditionalInterestRepositoryEntry extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "ADDL_INTEREST_REP_ENTRY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "AdditionalInterestRepositoryEntrySequence")
	@SequenceGenerator(name = "AdditionalInterestRepositoryEntrySequence", sequenceName = "ADDL_INTEREST_REP_ENTRY_SEQ", allocationSize = 5)
	private Long id;

	/** The additional interest type. Should only be LIENHOLDER("I") and LESSOR("L") are the only valid values */
	@Column(name = "ADDITIONAL_INTEREST_TYPE_CD", nullable = false, length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.AdditionalInterestTypeCodeEnum") })
	private AdditionalInterestTypeCodeEnum additionalInterestType;

	/** The french name. */
	@Column(name = "NAME_FRE_TXT", length = 50)
	private String nameFrench;

	/** The english name. */
	@Column(name = "NAME_ENG_TXT", length = 50)
	private String nameEnglish;

	/** The addresses. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER, mappedBy = "additionalInterestRepositoryEntry")
	private Set<Address> addresses = new HashSet<Address>(0);

	/** The additional interest repository manufacturing contexts. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "additionalInterestRepositoryEntry")
	private Set<AdditionalInterestRepositoryManufacturingContext> additionalInterestRepositoryManufacturingContexts = new HashSet<AdditionalInterestRepositoryManufacturingContext>(
			0);

	/**
	 * Instantiates a new additional interest role.
	 */
	public AdditionalInterestRepositoryEntry() {
	}

	/**
	 * Gets the additional interest type.
	 *
	 * @return the additional interest type
	 */
	public AdditionalInterestTypeCodeEnum getAdditionalInterestType() {
		return this.additionalInterestType;
	}

	/**
	 * Sets the additional interest type.
	 *
	 * @param aAdditionalInterestType the new additional interest type
	 */
	public void setAdditionalInterestType(AdditionalInterestTypeCodeEnum aAdditionalInterestType) {
		this.additionalInterestType = aAdditionalInterestType;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the name english.
	 *
	 * @return the name english
	 */
	public String getNameEnglish() {
		return this.nameEnglish;
	}

	/**
	 * Sets the name english.
	 *
	 * @param aNameEnglish the new name english
	 */
	public void setNameEnglish(String name) {
		this.nameEnglish = name;
	}

	/**
	 * Gets the name french.
	 *
	 * @return the name french
	 */
	public String getNameFrench() {
		return this.nameFrench;
	}

	/**
	 * Sets the name french.
	 *
	 * @param aNameFrench the new name french
	 */
	public void setNameFrench(String name) {
		this.nameFrench = name;
	}

	/**
	 * Gets the addresses.
	 *
	 * @return the addresses
	 */
	@XmlElementWrapper(name = "addresses")
	@XmlElement(name = "address")
	public Set<Address> getAddresses() {
		return Collections.unmodifiableSet(this.addresses);
	}

	/**
	 * Sets the addresses.
	 *
	 * @param aAddresses the new addresses
	 */
	protected void setAddresses(Set<Address> aAddresses) {
		this.addresses = aAddresses;
	}

	/**
	 * Adds the address.
	 *
	 * @param address the address
	 */
	public void addAddress(com.ing.canada.plp.domain.party.Address address) {
		AssociationsHelper.updateOneToManyFields(this, "addresses", address, "additionalInterestRepositoryEntry");
	}

	/**
	 * Removes the address.
	 *
	 * @param address the address
	 */
	public void removeAddress(com.ing.canada.plp.domain.party.Address address) {
		AssociationsHelper.updateOneToManyFields(null, "addresses", address, "additionalInterestRepositoryEntry");
	}

	/**
	 * Gets the additional interest repository manufacturing contexts.
	 *
	 * @return the additional interest repository manufacturing contexts
	 */
	@XmlElementWrapper(name = "additionalInterestRepositoryManufacturingContexts")
	@XmlElement(name = "additionalInterestRepositoryManufacturingContext")
	public Set<AdditionalInterestRepositoryManufacturingContext> getAdditionalInterestRepositoryManufacturingContexts() {
		return Collections.unmodifiableSet(this.additionalInterestRepositoryManufacturingContexts);
	}

	/**
	 * Sets the additional interest repository manufacturing contexts.
	 *
	 * @param aAdditionalInterestRepositoryManufacturingContexts the new additional interest repository manufacturing
	 *            contexts
	 */
	protected void setAdditionalInterestRepositoryManufacturingContexts(
			Set<AdditionalInterestRepositoryManufacturingContext> aAdditionalInterestRepositoryManufacturingContexts) {
		this.additionalInterestRepositoryManufacturingContexts = aAdditionalInterestRepositoryManufacturingContexts;
	}

	/**
	 * Adds the additional interest repository manufacturing contexts.
	 *
	 * @param aAdditionalInterestRepositoryManufacturingContext the a additional interest repository manufacturing
	 *            context
	 */
	public void addAdditionalInterestRepositoryManufacturingContexts(
			AdditionalInterestRepositoryManufacturingContext aAdditionalInterestRepositoryManufacturingContext) {
		AssociationsHelper.updateOneToManyFields(this, "additionalInterestRepositoryManufacturingContexts",
				aAdditionalInterestRepositoryManufacturingContext, "additionalInterestRepositoryEntry");
	}

	/**
	 * Removes the additional interest repository manufacturing contexts.
	 *
	 * @param aAdditionalInterestRepositoryManufacturingContext the a additional interest repository manufacturing
	 *            context
	 */
	public void removeAdditionalInterestRepositoryManufacturingContexts(
			AdditionalInterestRepositoryManufacturingContext aAdditionalInterestRepositoryManufacturingContext) {
		AssociationsHelper.updateOneToManyFields(null, "additionalInterestRepositoryManufacturingContexts",
				aAdditionalInterestRepositoryManufacturingContext, "additionalInterestRepositoryEntry");
	}

	public String getName(LanguageCodeEnum language) {
		return LanguageCodeEnum.ENGLISH.equals(language) ? this.getNameEnglish() : this.getNameFrench();
	}
}
