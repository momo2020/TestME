/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum CoverageSelectedTypeCodeEnum.
 */
public enum CoverageSelectedTypeCodeEnum {

	COVERAGE_HAS_BEEN_SELECTED_BY_THE_AGENT("A"), 
	COVERAGE_HAS_BEEN_DESELECTED_BY_THE_AGENT("B"), 
	COVERAGE_HAS_BEEN_SELECTED_BY_THE_CLIENT("C"), 
	COVERAGE_HAS_BEEN_DESELECTED_BY_THE_CLIENT("D"), 
	COVERAGE_HAS_BEEN_ADDED_BY_THE_SYSTEM("S"), 
	COVERAGE_HAS_BEEN_SELECTED_BY_THE_DIAGNOSTIC("Z");

	/**
	 * Instantiates a new coverage selected type code enum.
	 * 
	 * @param aCode the a code
	 */
	private CoverageSelectedTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the coverage selected type code enum
	 */
	public static CoverageSelectedTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (CoverageSelectedTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
