package com.ing.canada.plp.report;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.enums.AssignmentOriginatorTypeCodeEnum;
import com.ing.canada.plp.domain.enums.AssignmentReasonCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

@Entity
public class SubBrokerAssignmentInfo extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	private Long id;

	/** the row number */
	private Integer rowNumber;

	private Date effectiveDate;

	private String newBrokerName;

	private String oldBrokerName;

	private String clientFullName;

	// The assignment reason code.
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.AssignmentOriginatorTypeCodeEnum") })
	private AssignmentOriginatorTypeCodeEnum assignmentOriginatorType;

	// The assignment reason code.
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.AssignmentReasonCodeEnum") })
	private AssignmentReasonCodeEnum assignmentReason;

	private String newBrokerCity;

	private String oldBrokerCity;

	private String assignorUserId;
	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the assignment originator type
	 * 
	 * @return (assignmentOriginatorType) the assignment originator type
	 */
	public AssignmentOriginatorTypeCodeEnum getAssignmentOriginatorType() {
		return this.assignmentOriginatorType;
	}

	/**
	 * Sets the assignment originator type
	 * 
	 * @param assigmnentOriginatorType assignment originator type to set
	 */
	public void setAssignmentOriginatorType(AssignmentOriginatorTypeCodeEnum assigmnentOriginatorType) {
		this.assignmentOriginatorType = assigmnentOriginatorType;
	}

	/**
	 * Gets the assignment reason code enum
	 * 
	 * @return (AssignmentReasonCodeEnum) Assignment reason code enum
	 */
	public AssignmentReasonCodeEnum getAssignmentReason() {
		return this.assignmentReason;
	}

	/**
	 * Sets the assignment reason code enum
	 * 
	 * @param anAssigmnentReason the assignment reason code enum to set
	 */
	public void setAssignmentReason(AssignmentReasonCodeEnum anAssigmnentReason) {
		this.assignmentReason = anAssigmnentReason;
	}

	/**
	 * @return {@link #effectiveDate}
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * @param anEffectiveDate
	 */
	public void setEffectiveDate(Date anEffectiveDate) {
		this.effectiveDate = anEffectiveDate;
	}

	/**
	 * Gets the new broker name
	 * 
	 * @return (String) the new broker name
	 */
	public String getNewBrokerName() {
		return this.newBrokerName;
	}

	/**
	 * Sets the new broker name
	 * 
	 * @param aNewBrokerName the new broker name
	 */
	public void setNewBrokerName(String aNewBrokerName) {
		this.newBrokerName = aNewBrokerName;
	}

	/**
	 * Gets the former broker name
	 * 
	 * @return (String) the former broker name
	 */
	public String getOldBrokerName() {
		return this.oldBrokerName;
	}

	/**
	 * Sets the the former broker name
	 * 
	 * @param anOldbrokerName the former broker name to set
	 */
	public void setOldBrokerName(String anOldbrokerName) {
		this.oldBrokerName = anOldbrokerName;
	}

	/**
	 * Gets the client full name return (String) the client full name
	 * @return {@link #clientFullName}
	 */
	public String getClientFullName() {
		return this.clientFullName;
	}

	/**
	 * Sets the client full name
	 * 
	 * @param aClientFullName the client full name to set
	 */
	public void setClientFullName(String aClientFullName) {
		this.clientFullName = aClientFullName;
	}

	/**
	 * Gets the row number
	 * 
	 * @return (Intger) row number
	 */
	public Integer getRowNumber() {
		return this.rowNumber;
	}

	/**
	 * Sets the row number
	 * 
	 * @param aRowNumber the row number to set
	 */
	public void setRowNumber(Integer aRowNumber) {
		this.rowNumber = aRowNumber;
	}

	/**
	 * @return {@link #newBrokerCity}
	 */
	public String getNewBrokerCity() {
		return this.newBrokerCity;
	}

	/**
	 * @param aNewBrokerCity {@link #newBrokerCity}
	 */
	public void setNewBrokerCity(String aNewBrokerCity) {
		this.newBrokerCity = aNewBrokerCity;
	}

	/**
	 * @return {@link #oldBrokerCity}
	 */
	public String getOldBrokerCity() {
		return this.oldBrokerCity;
	}

	/**
	 * @param anOldBrokerCity {@link #oldBrokerCity}
	 */
	public void setOldBrokerCity(String anOldBrokerCity) {
		this.oldBrokerCity = anOldBrokerCity;
	}

	/**
	 * @return {@link #assignorUserId}
	 */
	public String getAssignorUserId() {
		return this.assignorUserId;
	}

	/**
	 * @param aAssignorUserId {@link #assignorUserId}
	 */
	public void setAssignorUserId(String aAssignorUserId) {
		this.assignorUserId = aAssignorUserId;
	}
	
}
