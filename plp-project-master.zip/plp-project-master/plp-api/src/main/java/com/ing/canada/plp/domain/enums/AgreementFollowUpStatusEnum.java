package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum AgreementFollowUpStatusEnum.
 */
public enum AgreementFollowUpStatusEnum {

	NOT_CONTACTED("NOT_CONT"), 
	CONTACTED_FOLLOWUP_REQUIRED("CONT_BUT_FLW"), 
	CONTACTED_NO_FOLLOWUP_REQUIRED("CONT_BUT_NO_FLW"),
	NOT_CONTACTED_NO_FOLLOWUP_REQUIRED("NOT_CONT_NO_FLW"),
	CALLBACK_REQUESTED("CUST_CALLBK_REQ"),
	DUPLICATE_FAKE("DISCARD");

	/** The code. */
	private String code = null;
	
	private AgreementFollowUpStatusEnum(String aCode){
		this.code = aCode;
	}


	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the agreement follow up status enum
	 */
	public static AgreementFollowUpStatusEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (AgreementFollowUpStatusEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
