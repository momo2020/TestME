/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum RatingFactorApplyConditionCodeEnum.
 */
public enum RatingFactorApplyConditionCodeEnum {

	/**
	 * rating factor percentage apply when the condition code exist in the policy (the endorsement or group exist in the
	 * policy)
	 */
	APPLY_WHEN_CONDITION_CODE_EXISTS("Y"),

	/**
	 * rating factor percentage apply when the condition code not exist in the policy (the endorsement or group not
	 * exist in the policy).
	 */
	APPLY_WHEN_CONDITION_CODE_DOES_NOT_EXISTS("N");

	/**
	 * Instantiates a new underwriting message status code enum.
	 * 
	 * @param aCode the a code
	 */
	private RatingFactorApplyConditionCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the underwriting message status code enum
	 */
	public static RatingFactorApplyConditionCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (RatingFactorApplyConditionCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
