package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.enums.ReportRequestCrmStatus;
import com.ing.canada.plp.domain.party.PartyTaskDocument;

public interface IPartyTaskDocumentService {
	
	PartyTaskDocument getPartyTaskDocumentWithPartyId(Long partyId);
	
	ReportRequestCrmStatus getReportStatusWithPartyId(Long partyId);
	
}
