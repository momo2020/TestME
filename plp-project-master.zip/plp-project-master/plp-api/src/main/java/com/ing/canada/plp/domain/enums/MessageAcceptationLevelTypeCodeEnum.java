/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum MessageAcceptationLevelTypeCodeEnum.
 */
public enum MessageAcceptationLevelTypeCodeEnum {

	AUTOMATICALLY_ACCEPTED_BY_THE_SYSTEM_NOT_AT_THE_BIND_STAGE("A"), AUTOMATICALLY_ACCEPTED_BY_THE_SYSTEM_AT_THE_BIND_STAGE(
			"R"), WILL_APPEAR_AT_QUOTE_STAGE("Q"), WILL_APPEAR_AT_BIND_STAGE_ONLY("B");

	/**
	 * Instantiates a new message acceptation level type code enum.
	 * 
	 * @param aCode the a code
	 */
	private MessageAcceptationLevelTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the message acceptation level type code enum
	 */
	public static MessageAcceptationLevelTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (MessageAcceptationLevelTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
