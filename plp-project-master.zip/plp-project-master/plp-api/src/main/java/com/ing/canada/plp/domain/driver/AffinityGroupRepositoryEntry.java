/**
 * 
 */
package com.ing.canada.plp.domain.driver;

import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * AffGrRepEntry entity.
 * 
 * @author ub8169
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "AFF_GR_REP_ENTRY")
public class AffinityGroupRepositoryEntry extends BaseEntity {

	// Fields
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "AFF_GR_REP_ENTRY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "AffinityGroupRepositoryEntrySequence")
	@SequenceGenerator(name = "AffinityGroupRepositoryEntrySequence", sequenceName = "AFF_GR_REP_ENTRY_SEQ", allocationSize = 5)
	private Long id;

	@Column(name = "AFFINITY_GROUP_CD", length = 20)
	private String affinityGroupCode;

	@Column(name = "AFFINITY_GROUP_ENG_DESC", length = 100)
	private String affinityGroupEnglishDescription;

	@Column(name = "AFFINITY_GROUP_FRE_DESC", length = 100)
	private String affinityGroupFrenchDescription;

	@Column(name = "AFFINITY_GROUP_INTERNAL_CD", length = 5)
	private String affinityGroupInternalCd;

	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", length = 7)
	private Date effectiveDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;

	/** The insurance risks. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "affinityGroupRepositoryEntry")
	@OrderBy("affinityGroupSpecialConditionCode ASC")
	private Set<AffinityGroupSpecialConditionRepositoryEntry> affinityGroupSpecialConditionRepositoryEntries = new HashSet<AffinityGroupSpecialConditionRepositoryEntry>(0);

	/** default constructor */
	public AffinityGroupRepositoryEntry() {
		// Nothing to do
	}

	/**
	 * @return the affinityGroupSpecialConditionRepositoryEntries
	 */
	@XmlElementWrapper(name="affinityGroupSpecialConditionRepositoryEntries")
	@XmlElement(name="affinityGroupSpecialConditionRepositoryEntry")
	public Set<AffinityGroupSpecialConditionRepositoryEntry> getAffinityGroupSpecialConditionRepositoryEntries() {
		return Collections.unmodifiableSet(this.affinityGroupSpecialConditionRepositoryEntries);
	}

	/**
	 * @param aAffinityGroupSpecialConditionRepositoryEntries the affinityGroupSpecialConditionRepositoryEntries to set
	 */
	public void setAffinityGroupSpecialConditionRepositoryEntries(
			Set<AffinityGroupSpecialConditionRepositoryEntry> aAffinityGroupSpecialConditionRepositoryEntries) {
		this.affinityGroupSpecialConditionRepositoryEntries = aAffinityGroupSpecialConditionRepositoryEntries;
	}

	/**
	 * Adds the AffinityGroupSpecialConditionRepositoryEntry.
	 * 
	 * @param aAffinityGroupSpecialConditionRepositoryEntry
	 */
	public void addAffinityGroupSpecialConditionRepositoryEntry(
			AffinityGroupSpecialConditionRepositoryEntry aAffinityGroupSpecialConditionRepositoryEntry) {
		AssociationsHelper.updateOneToManyFields(this, "affinityGroupSpecialConditionRepositoryEntries",
				aAffinityGroupSpecialConditionRepositoryEntry, "affinityGroupRepositoryEntry");
	}

	/**
	 * Removes the AffinityGroupSpecialConditionRepositoryEntry.
	 * 
	 * @param aAffinityGroupSpecialConditionRepositoryEntry
	 */
	public void removeAffinityGroupSpecialConditionRepositoryEntry(
			AffinityGroupSpecialConditionRepositoryEntry aAffinityGroupSpecialConditionRepositoryEntry) {
		AssociationsHelper.updateOneToManyFields(null, "affinityGroupSpecialConditionRepositoryEntries",
				aAffinityGroupSpecialConditionRepositoryEntry, "affinityGroupRepositoryEntry");
	}

	/**
	 * @return the affinityGroupCode
	 */
	public String getAffinityGroupCode() {
		return this.affinityGroupCode;
	}

	/**
	 * @param anAffinityGroupCode the affinityGroupCode to set
	 */
	public void setAffinityGroupCode(String anAffinityGroupCode) {
		this.affinityGroupCode = anAffinityGroupCode;
	}

	/**
	 * @return the affinityGroupEnglishDescription
	 */
	public String getAffinityGroupEnglishDescription() {
		return this.affinityGroupEnglishDescription;
	}

	/**
	 * @param anAffinityGroupEnglishDescription the affinityGroupEnglishDescription to set
	 */
	public void setAffinityGroupEnglishDescription(String anAffinityGroupEnglishDescription) {
		this.affinityGroupEnglishDescription = anAffinityGroupEnglishDescription;
	}

	/**
	 * @return the affinityGroupFrenchDescription
	 */
	public String getAffinityGroupFrenchDescription() {
		return this.affinityGroupFrenchDescription;
	}

	/**
	 * @param anAffinityGroupFrenchDescription the affinityGroupFrenchDescription to set
	 */
	public void setAffinityGroupFrenchDescription(String anAffinityGroupFrenchDescription) {
		this.affinityGroupFrenchDescription = anAffinityGroupFrenchDescription;
	}

	/**
	 * @return the affinityGroupInternalCd
	 */
	public String getAffinityGroupInternalCd() {
		return this.affinityGroupInternalCd;
	}

	/**
	 * @param anAffinityGroupInternalCd the affinityGroupInternalCd to set
	 */
	public void setAffinityGroupInternalCd(String anAffinityGroupInternalCd) {
		this.affinityGroupInternalCd = anAffinityGroupInternalCd;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * @param anEffectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date anEffectiveDate) {
		this.effectiveDate = anEffectiveDate;
	}

	/**
	 * @return the expiryDate
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * @param anExpiryDate the expiryDate to set
	 */
	public void setExpiryDate(Date anExpiryDate) {
		this.expiryDate = anExpiryDate;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object anId) {
		this.id = (Long) anId;
	}
}
