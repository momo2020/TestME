/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum ClaimLossDateCodeEnum.
 * 
 * @author plafleur
 */
public enum ClaimLossDateCodeEnum {

	LESS_THAN_ONE_YEAR("00"),
    ONE_YEAR_BUT_LESS_THAN_TWO("01"),
    TWO_YEARS_BUT_LESS_THAN_THREE("02"),
    THREE_YEARS_BUT_LESS_THAN_FOUR("03"),
    FOUR_YEARS_BUT_LESS_THAN_FIVE("04"),
    FIVE_YEARS_BUT_LESS_THAN_SIX("05"),
    SIX_YEARS_BUT_LESS_THAN_SEVEN("06"),
    SEVEN_YEARS_OR_MORE("07");

	/**
	 * Instantiates a new claim loss date code enum.
	 * 
	 * @param aCode the a code
	 */
	private ClaimLossDateCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value coming from the database
	 * 
	 * @return the corresponding claim loss date code enum
	 */
	public static ClaimLossDateCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (ClaimLossDateCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}

}
