/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum RelationshipToNamedInsuredCodeEnum.
 */
public enum RelationshipToNamedInsuredCodeEnum {

	INSURED("A"), //
	LESSOR("B"), //
	SPOUSE("C"), //
	CHILD("E"), //
	BROTHER_SISTER("F"), //
	MOTHER_FATHER("M"), //
	EMPLOYEE("T"), //
	OTHER_RELATIVE("P"), //
	ROOMATE("L"), //
	OTHER("X"), //
	CAA_MEMBER("Z"); //

	/**
	 * Instantiates a new relationship to named insured code enum.
	 * 
	 * @param aCode the a code
	 */
	private RelationshipToNamedInsuredCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the relationship to named insured code enum
	 */
	public static RelationshipToNamedInsuredCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (RelationshipToNamedInsuredCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
