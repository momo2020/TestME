/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * This interface exposes services required to manage InsuranceRisk related entities.
 * 
 * @author fsimard
 */
public interface IInsuranceRiskService extends ICRUDService<InsuranceRisk> {

	/**
	 * This method returns the InsuranceRisk of a PolicyVersion having a particular sequence number.<br>
	 * It returns NULL if no insuranceRisk exists.
	 * 
	 * @param policyVersion the policy version
	 * @param sequence the sequence
	 * 
	 * @return the insurance risk
	 */
	InsuranceRisk findBySequence(PolicyVersion policyVersion, Short sequence);
}
