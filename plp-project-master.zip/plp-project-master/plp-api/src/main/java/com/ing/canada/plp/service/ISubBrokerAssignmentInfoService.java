package com.ing.canada.plp.service;

import java.util.Date;
import java.util.List;

import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;
import com.ing.canada.plp.report.SubBrokerAssignmentInfo;

public interface ISubBrokerAssignmentInfoService{
		
	/**
	 * This method returns all the sub broker assignment to a Broker.
	 * BR5828  Items Displayed per Regional Access
	 * 
	 * @param aDateFrom
	 * @param aDateTo
	 * @return
	 */
	List<SubBrokerAssignmentInfo> getAllSubBrokerAssignmentsSP(Date aDateFrom, Date aDateTo,
			 ProvinceCodeEnum aProvinceCode, String aSubBrokerCompanyNumber,
			ManufacturerCompanyCodeEnum aManufacturerCompanyCode);

}
