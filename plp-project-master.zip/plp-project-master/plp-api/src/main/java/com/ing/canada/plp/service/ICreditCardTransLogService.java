/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2010, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.domain.billing.CreditCardTransLog;

/**
 * This interface exposes services required to manage CreditCardTransLog related entities.
 * 
 * @author mblouin
 * 
 */
public interface ICreditCardTransLogService extends ICRUDService<CreditCardTransLog> {
	List<CreditCardTransLog> findCreditCardTransLogByUpperId(String tokenID);
}
