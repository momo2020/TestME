/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum RatingRiskTypeCodeEnum.
 */
public enum RatingFactorCalculationMethodEnum {

	BASE_PREMIUM_FACTOR("BP"),
	CODING_GROUP_FACTOR("CGF"),
	FIXED_CODING_GROUP_FACTOR("FCGF"),
	ADDITIVE_ENDORSEMENT_FACTOR("AEF"),
	FIXED_ADDITIVE_ENDORSEMENT_FACTOR("FAEF"),
	ADDITIVE_ENDORSEMENT_DEVIATED_FACTOR("AEDF"),
	FIXED_ADDITIVE_ENDORSEMENT_DEVIATED_FACTOR("FAEDF"),
	FINAL_ADJUSTMENT_FACTOR("FAF"),
	FINAL_ADJUSTMENT_DEVIATED_FACTOR("FADF"),
	ROAD_BLOCK_MINIMUM_PREMIUM("RB");

	/**
	 * Instantiates a new rating risk type code enum.
	 * 
	 * @param aCode the a code
	 */
	private RatingFactorCalculationMethodEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the rating risk type code enum
	 */
	public static RatingFactorCalculationMethodEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (RatingFactorCalculationMethodEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
