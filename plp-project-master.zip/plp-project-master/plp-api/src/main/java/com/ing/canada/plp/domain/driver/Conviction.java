/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.driver;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.ConvictionDateCodeEnum;
import com.ing.canada.plp.domain.enums.ConvictionTypeCodeEnum;
import com.ing.canada.plp.domain.enums.ConvictionTypeRspCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * Conviction entity.
 * 
 * @author Patrick Lafleur
 * 
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "CONVICTION", uniqueConstraints = {})
public class Conviction extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "CONVICTION_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "ConvictionSequence")
	@SequenceGenerator(name = "ConvictionSequence", sequenceName = "CONVICTION_SEQ", allocationSize = 5)
	private Long id;

	/** The driver complement info. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "PARTY_ID", nullable = false, updatable = true)
	private DriverComplementInfo driverComplementInfo;

	/** The conviction seq. */
	@Column(name = "CONVICTION_SEQ", nullable = false, precision = 4, scale = 0)
	private short convictionSequence;

	/** The conviction code. */
	@Column(name = "CONVICTION_CD", nullable = false, length = 5)
	private String convictionCode;

	/** The conviction type code. */
	@Column(name = "CONVICTION_TYPE_CD", nullable = true, length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ConvictionTypeCodeEnum") })
	private ConvictionTypeCodeEnum convictionType;

	/** The conviction type rsp code. */
	@Column(name = "CONVICTION_TYPE_RSP_CD", length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ConvictionTypeRspCodeEnum") })
	private ConvictionTypeRspCodeEnum convictionTypeRsp;

	/** The creation timestamp. */
	@Column(name = "CREATION_TS", nullable = false, length = 11)
	private Date creationDate;

	/** The conviction date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "CONVICTION_DT", length = 7)
	private Date convictionDate;

	/** The suspension end date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "SUSPENSION_END_DT", length = 7)
	private Date suspensionEndDate;

	/** The conviction chargeability indicator. */
	@Column(name = "CONVICTION_CHARGEABILITY_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean convictionChargeabilityIndicator;

	/** The original scenario conviction. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_CONVICTION_ID", insertable = false, updatable = false)
	private Conviction originalScenarioConviction;

	/** The insurance risk. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_RISK_ID", updatable = true)
	private InsuranceRisk insuranceRisk;

	/** The conviction type code. */
	@Column(name = "CONVICTION_TYPE_GRID_CD", nullable = true, length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ConvictionTypeCodeEnum") })
	private ConvictionTypeCodeEnum convictionTypeGrid;

	/** The conviction date code. */
	@Column(name = "CONVICTION_DT_CD", nullable = true, length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ConvictionDateCodeEnum") })
	private ConvictionDateCodeEnum convictionDateCode;

	/**
	 * Instantiates a new conviction.
	 */
	public Conviction() {
		// noarg constructor
	}

	/**
	 * Instantiates a new conviction.
	 * 
	 * @param aDriverComplementInfo the a driver complement info
	 * @param aConvictionSequence the a conviction sequence
	 * @param aConvictionCode the a conviction code
	 * @param aConvictionTypeCode the a conviction type code
	 * @param aCreationTimestamp the a creation timestamp
	 */
	public Conviction(DriverComplementInfo aDriverComplementInfo, short aConvictionSequence, String aConvictionCode,
			ConvictionTypeCodeEnum aConvictionTypeCode, Date aCreationTimestamp) {
		setDriverComplementInfo(aDriverComplementInfo);
		setConvictionSequence(aConvictionSequence);
		setConvictionCode(aConvictionCode);
		setConvictionType(aConvictionTypeCode);
		setCreationDate(aCreationTimestamp);
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the driver complement info.
	 * 
	 * @return the driver complement info
	 */
	@XmlTransient // parent
	public DriverComplementInfo getDriverComplementInfo() {
		return this.driverComplementInfo;
	}

	/**
	 * Sets the driver complement info.
	 * 
	 * @param aDriverComplementInfo the new driver complement info
	 */
	public void setDriverComplementInfo(DriverComplementInfo aDriverComplementInfo) {
		AssociationsHelper.updateOneToManyFields(aDriverComplementInfo, "convictions", this, "driverComplementInfo");
	}

	/**
	 * Gets the conviction sequence.
	 * 
	 * @return the conviction sequence
	 */
	public short getConvictionSequence() {
		return this.convictionSequence;
	}

	/**
	 * Sets the conviction sequence.
	 * 
	 * @param convictionSeq the new conviction sequence
	 */
	public void setConvictionSequence(short convictionSeq) {
		this.convictionSequence = convictionSeq;
	}

	/**
	 * Gets the conviction code.
	 * 
	 * @return the conviction code
	 */
	public String getConvictionCode() {
		return this.convictionCode;
	}

	/**
	 * Sets the conviction code.
	 * 
	 * @param aConvictionCode the new conviction code
	 */
	public void setConvictionCode(String aConvictionCode) {
		this.convictionCode = aConvictionCode;
	}

	/**
	 * Gets the conviction type code.
	 * 
	 * @return the conviction type code
	 */
	public ConvictionTypeCodeEnum getConvictionType() {
		return this.convictionType;
	}

	/**
	 * Sets the conviction type.
	 * 
	 * @param aConvictionTypeCode the new conviction type
	 */
	public void setConvictionType(ConvictionTypeCodeEnum aConvictionTypeCode) {
		this.convictionType = aConvictionTypeCode;
	}

	/**
	 * Gets the conviction type rsp.
	 * 
	 * @return the conviction type rsp
	 */
	public ConvictionTypeRspCodeEnum getConvictionTypeRsp() {
		return this.convictionTypeRsp;
	}

	/**
	 * Sets the conviction type rsp.
	 * 
	 * @param aConvictionTypeRspCode the new conviction type rsp
	 */
	public void setConvictionTypeRsp(ConvictionTypeRspCodeEnum aConvictionTypeRspCode) {
		this.convictionTypeRsp = aConvictionTypeRspCode;
	}

	/**
	 * Gets the creation date.
	 * 
	 * @return the creation date
	 */
	public Date getCreationDate() {
		return this.creationDate;
	}

	/**
	 * Sets the creation timestamp.
	 * 
	 * @param aCreationTimestamp the new creation timestamp
	 */
	public void setCreationDate(Date aCreationTimestamp) {
		this.creationDate = aCreationTimestamp;
	}

	/**
	 * Gets the conviction date.
	 * 
	 * @return the conviction date
	 */
	public Date getConvictionDate() {
		return this.convictionDate;
	}

	/**
	 * Sets the conviction date.
	 * 
	 * @param aConvictionDate the new conviction date
	 */
	public void setConvictionDate(Date aConvictionDate) {
		this.convictionDate = aConvictionDate;
	}

	/**
	 * Gets the suspension end date.
	 * 
	 * @return the suspension end date
	 */
	public Date getSuspensionEndDate() {
		return this.suspensionEndDate;
	}

	/**
	 * Sets the suspension end date.
	 * 
	 * @param aSuspensionEndDate the new suspension end date
	 */
	public void setSuspensionEndDate(Date aSuspensionEndDate) {
		this.suspensionEndDate = aSuspensionEndDate;
	}

	/**
	 * Gets the conviction chargeability indicator.
	 * 
	 * @return the conviction chargeability indicator
	 */
	public Boolean getConvictionChargeabilityIndicator() {
		return this.convictionChargeabilityIndicator;
	}

	/**
	 * Sets the conviction chargeability indicator.
	 * 
	 * @param aConvictionChargeabilityIndicator the new conviction chargeability indicator
	 */
	public void setConvictionChargeabilityIndicator(Boolean aConvictionChargeabilityIndicator) {
		this.convictionChargeabilityIndicator = aConvictionChargeabilityIndicator;
	}

	/**
	 * Gets the original scenario conviction.
	 * 
	 * @return the original scenario conviction
	 */
	@XmlTransient // reference source
	public Conviction getOriginalScenarioConviction() {
		return this.originalScenarioConviction;
	}

	/**
	 * Sets the original scenario conviction.
	 * 
	 * @param aOriginalScenarioConviction the new original scenario conviction
	 */
	protected void setOriginalScenarioConviction(Conviction anOriginalScenarioConviction) {
		this.originalScenarioConviction = anOriginalScenarioConviction;
	}

	/**
	 * Gets the insurance risk.
	 * 
	 * @return the insurance risk
	 */
	@XmlTransient // parent
	public InsuranceRisk getInsuranceRisk() {
		return this.insuranceRisk;
	}

	/**
	 * Sets the insurance risk.
	 * 
	 * @param aInsuranceRisk the new insurance risk
	 */
	public void setInsuranceRisk(InsuranceRisk aInsuranceRisk) {
		AssociationsHelper.updateOneToManyFields(aInsuranceRisk, "convictions", this, "insuranceRisk");
	}

	/**
	 * Gets the conviction type grid code.
	 * 
	 * @return the conviction type grid code
	 */
	public ConvictionTypeCodeEnum getConvictionTypeGrid() {
		return this.convictionTypeGrid;
	}

	/**
	 * Sets the conviction grid type.
	 * 
	 * @param aConvictionTypeCode the new conviction grid type
	 */
	public void setConvictionGridType(ConvictionTypeCodeEnum aConvictionTypeGrid) {
		this.convictionTypeGrid = aConvictionTypeGrid;
	}

	/**
	 * Sets the conviction date code.
	 * 
	 * @param aConvictionDateCode the new conviction date code
	 */
	public void setConvictionDateCode(ConvictionDateCodeEnum aConvictionDateCode) {
		this.convictionDateCode = aConvictionDateCode;
	}

	/**
	 * Gets the conviction date code.
	 * 
	 * @return the conviction date code
	 */
	public ConvictionDateCodeEnum getConvictionDateCode() {
		return this.convictionDateCode;
	}
}
