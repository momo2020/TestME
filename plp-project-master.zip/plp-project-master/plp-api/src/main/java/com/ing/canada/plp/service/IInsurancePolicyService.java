/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */

package com.ing.canada.plp.service;

import java.util.Date;
import java.util.List;

import com.ing.canada.plp.domain.enums.AgreementTypeCodeEnum;
import com.ing.canada.plp.domain.enums.ApplicationModeEnum;
import com.ing.canada.plp.domain.enums.LineOfBusinessCodeEnum;
import com.ing.canada.plp.domain.insurancepolicy.InsurancePolicy;
import com.ing.canada.plp.domain.policyemailtoken.PolicyEmailToken;

/**
 * This interface exposes services required to manage InsurancePolicy related entities.
 * 
 * @author fsimard
 */
public interface IInsurancePolicyService extends ICRUDService<InsurancePolicy> {

	/**
	 * Generate quotation number.
	 * 
	 * @return the string
	 */
	String generateQuotationNumber();

	/**
	 * Generate quotation number based on the applicationModeEnum.
	 * 
	 * @return the string
	 */
	String generateQuotationNumber(ApplicationModeEnum applicationMode);
	
	/**
	 * Generate quotation number based on the applicationModeEnum.
	 * 
	 * @return the string
	 */
	String generateQuotationNumber(ApplicationModeEnum applicationMode, LineOfBusinessCodeEnum lineOfBusinessCodeEnum);
	
	/**
	 * Generate a quotation universal Unique Identifier
	 *
	 * @param applicationMode {@link ApplicationModeEnum}
	 * @return the generated quotation universally Unique IDentifier (UUID)
	 */
	String generateUUID(ApplicationModeEnum applicationMode, LineOfBusinessCodeEnum lineOfBusinessCodeEnum);

	/**
	 * Find an insurancepolicy by agreement number.
	 * 
	 * @param agreementNumber the agreement number
	 * 
	 * @return the insurance policy
	 */
	InsurancePolicy findByAgreementNumber(String agreementNumber);

	/**
	 * Find all insurance policy for a given cif id and an agreement code.
	 * 
	 * @param cifId the cif id
	 * @param agreementTypeCode the agreement type code
	 * 
	 * @return the list< insurance policy>
	 */
	List<InsurancePolicy> findAllInsurancePolicyForCifId(Long cifId, AgreementTypeCodeEnum agreementTypeCode);

	/**
	 * Find all insurance policy for a given tamUniqueId.
	 * 
	 * @param tamUniqueId
	 * 
	 * @return the list< insurance policy>
	 */
	List<InsurancePolicy> findAllForTamUniqueId(Long tamUniqueId);

	/**
	 * Find all unexpired insurance policy for tam unique id.
	 * 
	 * @param tamUniqueId the tam unique id
	 * 
	 * @return the list< insurance policy>
	 */
	List<InsurancePolicy> findAllUnexpiredInsurancePolicyForTamUniqueId(Long tamUniqueId);

	/**
	 * Find last insurance policy for a given tamUniqueId.
	 * 
	 * @param tamUniqueId
	 * 
	 * @return the insurance policy
	 */
	InsurancePolicy findLastForTamUniqueId(Long tamUniqueId);

	/**
	 * Find all the Insurance policies that are rated for a certain date
	 * 
	 * @param dateToTest
	 * 
	 * @return list of insurance policies
	 */
	List<InsurancePolicy> findRatedPolicies(Date dateToTest);

	/**
	 * Find BROKER : all unexpired insurance policy for email address.
	 *
	 * @param anEmail
	 * @param insurancePolicyId
	 * @return the list< insurance policy>
	 */
	List<InsurancePolicy> findAllUnexpiredInsurancePolicy(String anEmail, Long insurancePolicyId);

	/**
	 * Find ADMIN: all unexpired insurance policy for email address.
	 * 
	 * @param anEmail the email address
	 * 
	 * @return the list< insurance policy>
	 */
	List<InsurancePolicy> findAllUnexpiredInsurancePolicyForEmail(String anEmail);

	/**
	 * Find an insurancepolicy by agreement legacy number.
	 * 
	 * @param agreementLegacyNumber the agreement legacy number
	 * 
	 * @return the insurance policy
	 */
	InsurancePolicy findByAgreementLegacyNumber(String agreementLegacyNumber);

	public List<InsurancePolicy> findAllInsurancePolicyForRetrieveWEBBK(String lastName, String anEmail,
			Date birthDate, String subBrokerId);
	
	public List<InsurancePolicy> findAllInsurancePolicyForRetrieveIntact(String lastName, String anEmail, Date birthDate);
	
	public List<InsurancePolicy> findAllInsurancePolicyForEmailWEBBK(String anEmail, String subBrokerId);
	
	public List<InsurancePolicy> findAllInsurancePolicyForEmailIntact(String anEmail);
	
	public List<InsurancePolicy>  findAllForEmail(String email);
	
	public void addPolicyEmailToken(InsurancePolicy ip, PolicyEmailToken aToken);
	
}
