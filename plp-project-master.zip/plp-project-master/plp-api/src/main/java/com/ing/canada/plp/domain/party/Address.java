/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.party;

import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.ActionTakenCodeEnum;
import com.ing.canada.plp.domain.enums.AddressDeliveryModeCodeEnum;
import com.ing.canada.plp.domain.enums.AddressTypeCodeEnum;
import com.ing.canada.plp.domain.enums.AddressUsageCodeEnum;
import com.ing.canada.plp.domain.enums.CountryCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;
import com.ing.canada.plp.domain.enums.UnitTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.AdditionalInterestRepositoryEntry;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * Address entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "ADDRESS", uniqueConstraints = {})
public class Address extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "ADDRESS_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "AddressSequence")
	@SequenceGenerator(name = "AddressSequence", sequenceName = "ADDRESS_SEQ", allocationSize = 5)
	private Long id;

	/** The party. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "PARTY_ID", updatable = true)
	private Party party;

	/** The additional interest repository entry. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ADDL_INTEREST_REP_ENTRY_ID", updatable = true)
	private AdditionalInterestRepositoryEntry additionalInterestRepositoryEntry;

	/** The municipality detail spec. */
	@ManyToOne(cascade = { CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name = "MUNICIPALITY_DETAIL_SPEC_ID", updatable = true)
	private MunicipalityDetailSpecification municipalityDetailSpecification;

	/** The addressType. */
	@Column(name = "ADDRESS_TYPE_CD", length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.AddressTypeCodeEnum") })
	private AddressTypeCodeEnum addressType;

	/** The addressUsage. */
	@Column(name = "ADDRESS_USAGE_CD", length = 4)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.AddressUsageCodeEnum") })
	private AddressUsageCodeEnum addressUsage;

	/** The unit addressType. */
	@Column(name = "UNIT_TYPE_CD", length = 10)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.UnitTypeCodeEnum") })
	private UnitTypeCodeEnum unitType;

	/** The unit number. */
	@Column(name = "UNIT_NBR", length = 10)
	private String unitNumber;

	/** The civic number. */
	@Column(name = "CIVIC_NBR", length = 10)
	private String civicNumber;

	/** The street name. */
	@Column(name = "STREET_NAME_TXT", length = 100)
	private String streetName;

	/** The municipality. */
	@Column(name = "MUNICIPALITY_TXT", length = 32)
	private String municipality;

	/** The unformatted address1. */
	@Column(name = "UNFORMATTED_ADDRESS1_TXT", length = 40)
	private String unformattedAddress1;

	/** The unformatted address2. */
	@Column(name = "UNFORMATTED_ADDRESS2_TXT", length = 40)
	private String unformattedAddress2;

	/** The unformatted address3. */
	@Column(name = "UNFORMATTED_ADDRESS3_TXT", length = 40)
	private String unformattedAddress3;

	/** The postal code. */
	@Column(name = "POSTAL_CD", length = 6)
	private String postalCode;

	/** The province. */
	@Column(name = "PROVINCE_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ProvinceCodeEnum") })
	private ProvinceCodeEnum province;

	/** The country. */
	@Column(name = "COUNTRY_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.CountryCodeEnum") })
	private CountryCodeEnum country;

	/** The postal code prohibited. */
	@Column(name = "PROHIBITED_POSTAL_CODE_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean prohibitedPostalCodeIndicator;

	/** The municipal system code. */
	@Column(name = "MUNICIPAL_SYS_CD", length = 6)
	private String municipalSystemCode = null;

	/** The municipal modification code. */
	@Column(name = "MUNICIPAL_MOD_CD", length = 6)
	private String municipalModificationCode = null;

	/** The municipal code. */
	@Column(name = "MUNICIPAL_CD", length = 6)
	private String municipalCode = null;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", length = 7)
	private Date effectiveDate;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;

	/** The insurance risks. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "address")
	private Set<InsuranceRisk> insuranceRisks = new HashSet<InsuranceRisk>(0);

	/** The original scenario address. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_ADDRESS_ID", insertable = false, updatable = false)
	private Address originalScenarioAddress;

	/** The action taken. */
	@Column(name = "ACTION_TAKEN_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ActionTakenCodeEnum") })
	private ActionTakenCodeEnum actionTaken = null;

	/** The road block indicator. */
	@Column(name = "ROAD_BLOCK_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean roadBlockIndicator;

	@Column(name = "ADDRESS_DELIVERY_MODE_CD", length = 6)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.AddressDeliveryModeCodeEnum") })
	private AddressDeliveryModeCodeEnum addressDeleveryModeCode = null;

	@Column(name = "ADDRESS_DELIVERY_MODE_NBR", length = 10)
	private String addressDeleveryModeNumber = null;

	/**
	 * Instantiates a new address.
	 */
	public Address() {
		// noarg constructor
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the party.
	 * 
	 * @return the party
	 */
	@XmlTransient // parent
	public Party getParty() {
		return this.party;
	}

	/**
	 * Sets the party.
	 * 
	 * @param aParty the new party
	 */
	public void setParty(Party aParty) {
		AssociationsHelper.updateOneToManyFields(aParty, "addresses", this, "party");
	}

	/**
	 * Gets the municipality detail spec.
	 * 
	 * @return the municipality detail spec
	 */
	public MunicipalityDetailSpecification getMunicipalityDetailSpecification() {
		return this.municipalityDetailSpecification;
	}

	/**
	 * Sets the municipality detail specification.
	 * 
	 * @param aMunicipalityDetailSpecification the new municipality detail specification
	 */
	public void setMunicipalityDetailSpecification(MunicipalityDetailSpecification aMunicipalityDetailSpecification) {
		this.municipalityDetailSpecification = aMunicipalityDetailSpecification;
	}

	/**
	 * Gets the addressType.
	 * 
	 * @return the addressType
	 */
	public AddressTypeCodeEnum getAddressType() {
		return this.addressType;
	}

	/**
	 * Sets the address addressType code.
	 * 
	 * @param aAddressType the new address addressType code
	 */
	public void setAddressType(AddressTypeCodeEnum aAddressType) {
		this.addressType = aAddressType;
	}

	/**
	 * Gets the addressUsage.
	 * 
	 * @return the addressUsage
	 */
	public AddressUsageCodeEnum getAddressUsage() {
		return this.addressUsage;
	}

	/**
	 * Sets the address addressUsage code.
	 * 
	 * @param aAddressUsage the new address addressUsage code
	 */
	public void setAddressUsage(AddressUsageCodeEnum aAddressUsage) {
		this.addressUsage = aAddressUsage;
	}

	/**
	 * Gets the unit addressType.
	 * 
	 * @return the unit addressType
	 */
	public UnitTypeCodeEnum getUnitType() {
		return this.unitType;
	}

	/**
	 * Sets the unit addressType code.
	 * 
	 * @param aUnitType the new unit addressType code
	 */
	public void setUnitType(UnitTypeCodeEnum aUnitType) {
		this.unitType = aUnitType;
	}

	/**
	 * Gets the unit number.
	 * 
	 * @return the unit number
	 */
	public String getUnitNumber() {
		return this.unitNumber;
	}

	/**
	 * Sets the unit number.
	 * 
	 * @param aUnitNumber the new unit number
	 */
	public void setUnitNumber(String aUnitNumber) {
		this.unitNumber = aUnitNumber;
	}

	/**
	 * Gets the civic number.
	 * 
	 * @return the civic number
	 */
	public String getCivicNumber() {
		return this.civicNumber;
	}

	/**
	 * Sets the civic number.
	 * 
	 * @param aCivicNumber the new civic number
	 */
	public void setCivicNumber(String aCivicNumber) {
		this.civicNumber = aCivicNumber;
	}

	/**
	 * Gets the street name.
	 * 
	 * @return the street name
	 */
	public String getStreetName() {
		return this.streetName;
	}

	/**
	 * Sets the street name.
	 * 
	 * @param aStreetName the new street name
	 */
	public void setStreetName(String aStreetName) {
		this.streetName = aStreetName;
	}

	/**
	 * Gets the municipality.
	 * 
	 * @return the municipality
	 */
	public String getMunicipality() {
		return this.municipality;
	}

	/**
	 * Sets the municipality.
	 * 
	 * @param aMunicipality the new municipality
	 */
	public void setMunicipality(String aMunicipality) {
		this.municipality = aMunicipality;
	}

	/**
	 * Gets the unformatted address1.
	 * 
	 * @return the unformatted address1
	 */
	public String getUnformattedAddress1() {
		return this.unformattedAddress1;
	}

	/**
	 * Sets the unformatted address1.
	 * 
	 * @param aUnformattedAddress1 the new unformatted address1
	 */
	public void setUnformattedAddress1(String aUnformattedAddress1) {
		this.unformattedAddress1 = aUnformattedAddress1;
	}

	/**
	 * Gets the unformatted address2.
	 * 
	 * @return the unformatted address2
	 */
	public String getUnformattedAddress2() {
		return this.unformattedAddress2;
	}

	/**
	 * Sets the unformatted address2.
	 * 
	 * @param aUnformattedAddress2 the new unformatted address2
	 */
	public void setUnformattedAddress2(String aUnformattedAddress2) {
		this.unformattedAddress2 = aUnformattedAddress2;
	}

	/**
	 * Gets the unformatted address3.
	 * 
	 * @return the unformatted address3
	 */
	public String getUnformattedAddress3() {
		return this.unformattedAddress3;
	}

	/**
	 * Sets the unformatted address3.
	 * 
	 * @param aUnformattedAddress3 the new unformatted address3
	 */
	public void setUnformattedAddress3(String aUnformattedAddress3) {
		this.unformattedAddress3 = aUnformattedAddress3;
	}

	/**
	 * Gets the postal code.
	 * 
	 * @return the postal code
	 */
	public String getPostalCode() {
		return this.postalCode;
	}

	/**
	 * Sets the postal code.
	 * 
	 * @param aPostalCode the new postal code
	 */
	public void setPostalCode(String aPostalCode) {
		this.postalCode = aPostalCode;
	}

	/**
	 * Gets the province.
	 * 
	 * @return the province
	 */
	public ProvinceCodeEnum getProvince() {
		return this.province;
	}

	/**
	 * Sets the province code.
	 * 
	 * @param aProvince the new province code
	 */
	public void setProvince(ProvinceCodeEnum aProvince) {
		this.province = aProvince;
	}

	/**
	 * Gets the country.
	 * 
	 * @return the country
	 */
	public CountryCodeEnum getCountry() {
		return this.country;
	}

	/**
	 * Sets the country code.
	 * 
	 * @param aCountry the new country code
	 */
	public void setCountry(CountryCodeEnum aCountry) {
		this.country = aCountry;
	}

	/**
	 * Gets the prohibited postal code indicator.
	 * 
	 * @return the prohibited postal code indicator
	 */
	public Boolean getProhibitedPostalCodeIndicator() {
		return this.prohibitedPostalCodeIndicator;
	}

	/**
	 * Sets the prohibited postal code indicator.
	 * 
	 * @param aProhibitedPostalCodeIndicator the new prohibited postal code indicator
	 */
	public void setProhibitedPostalCodeIndicator(Boolean aProhibitedPostalCodeIndicator) {
		this.prohibitedPostalCodeIndicator = aProhibitedPostalCodeIndicator;
	}

	/**
	 * Gets the effective date.
	 * 
	 * @return the effective date
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * Sets the effective date.
	 * 
	 * @param aEffectiveDate the new effective date
	 */
	public void setEffectiveDate(Date aEffectiveDate) {
		this.effectiveDate = aEffectiveDate;
	}

	/**
	 * Gets the expiry date.
	 * 
	 * @return the expiry date
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * Sets the expiry date.
	 * 
	 * @param aExpiryDate the new expiry date
	 */
	public void setExpiryDate(Date aExpiryDate) {
		this.expiryDate = aExpiryDate;
	}

	/**
	 * Gets the insurance risks.
	 * 
	 * @return the insurance risks
	 */
	@XmlTransient // parent
	public Set<InsuranceRisk> getInsuranceRisks() {
		return Collections.unmodifiableSet(this.insuranceRisks);
	}

	/**
	 * Sets the insurance risks.
	 * 
	 * @param aInsuranceRisks the new insurance risks
	 */
	protected void setInsuranceRisks(Set<InsuranceRisk> aInsuranceRisks) {
		this.insuranceRisks = aInsuranceRisks;
	}

	/**
	 * Adds the insurance risk.
	 * 
	 * @param ir the ir
	 */
	public void addInsuranceRisk(com.ing.canada.plp.domain.insurancerisk.InsuranceRisk ir) {
		AssociationsHelper.updateOneToManyFields(this, "insuranceRisks", ir, "address");
	}

	/**
	 * Removes the insurance risk.
	 * 
	 * @param ir the ir
	 */
	public void removeInsuranceRisk(com.ing.canada.plp.domain.insurancerisk.InsuranceRisk ir) {
		AssociationsHelper.updateOneToManyFields(null, "insuranceRisks", ir, "address");
	}

	/**
	 * Gets the municipal system code.
	 * 
	 * @return the municipalSystemCode
	 */
	public String getMunicipalSystemCode() {
		return this.municipalSystemCode;
	}

	/**
	 * Sets the municipal system code.
	 * 
	 * @param aMunicipalSystemCode the municipalSystemCode to set
	 */
	public void setMunicipalSystemCode(String aMunicipalSystemCode) {
		this.municipalSystemCode = aMunicipalSystemCode;
	}

	/**
	 * Gets the municipal modification code.
	 * 
	 * @return the municipalModificationCode
	 */
	public String getMunicipalModificationCode() {
		return this.municipalModificationCode;
	}

	/**
	 * Sets the municipal modification code.
	 * 
	 * @param aMunicipalModificationCode the municipalModificationCode to set
	 */
	public void setMunicipalModificationCode(String aMunicipalModificationCode) {
		this.municipalModificationCode = aMunicipalModificationCode;
	}

	/**
	 * Gets the municipal code.
	 * 
	 * @return the municipalCode
	 */
	public String getMunicipalCode() {
		return this.municipalCode;
	}

	/**
	 * Sets the municipal code.
	 * 
	 * @param aMunicipalCode the municipalCode to set
	 */
	public void setMunicipalCode(String aMunicipalCode) {
		this.municipalCode = aMunicipalCode;
	}

	/**
	 * Gets the original scenario address.
	 * 
	 * @return the original scenario address
	 */
	@XmlTransient // reference source
	public Address getOriginalScenarioAddress() {
		return this.originalScenarioAddress;
	}

	/**
	 * Sets the original scenario address. Even if it is public, there updatable property is set to false and
	 * modifications will fail. It is public only to allow unit testing.
	 * 
	 * @param anOriginalScenarioAddress the new original scenario address
	 */
	public void setOriginalScenarioAddress(Address anOriginalScenarioAddress) {
		this.originalScenarioAddress = anOriginalScenarioAddress;
	}

	/**
	 * Gets the action taken.
	 * 
	 * @return the action taken
	 */
	public ActionTakenCodeEnum getActionTaken() {
		return this.actionTaken;
	}

	/**
	 * Sets the action taken.
	 * 
	 * @param anActionTaken the new action taken
	 */
	public void setActionTaken(ActionTakenCodeEnum anActionTaken) {
		this.actionTaken = anActionTaken;
	}

	/**
	 * Gets the road block indicator.
	 * 
	 * @return the road block indicator
	 */
	public Boolean getRoadBlockIndicator() {
		return this.roadBlockIndicator;
	}

	/**
	 * Sets the road block indicator.
	 * 
	 * @param aRoadBlockIndicator the new road block indicator
	 */
	public void setRoadBlockIndicator(Boolean aRoadBlockIndicator) {
		this.roadBlockIndicator = aRoadBlockIndicator;
	}

	/**
	 * Gets the additional interest repository entry.
	 * 
	 * @return the additional interest repository entry
	 */
	public AdditionalInterestRepositoryEntry getAdditionalInterestRepositoryEntry() {
		return this.additionalInterestRepositoryEntry;
	}

	/**
	 * Sets the additional interest repository entry.
	 * 
	 * @param aAdditionalInterestRepositoryEntry the new additional interest repository entry
	 */
	public void setAdditionalInterestRepositoryEntry(
			AdditionalInterestRepositoryEntry aAdditionalInterestRepositoryEntry) {
		AssociationsHelper.updateOneToManyFields(aAdditionalInterestRepositoryEntry, "addresses", this,
				"additionalInterestRepositoryEntry");
	}

	/**
	 * @return the adress delevery mode code (PO box or null)
	 */
	public AddressDeliveryModeCodeEnum getAddressDeleveryModeCode() {
		return this.addressDeleveryModeCode;
	}

	/**
	 * @param addressDeleveryModeCode
	 */
	public void setAddressDeleveryModeCode(AddressDeliveryModeCodeEnum addressDeleveryModeCode) {
		this.addressDeleveryModeCode = addressDeleveryModeCode;
	}

	/**
	 * @return the PO box number
	 */
	public String getAddressDeleveryModeNumber() {
		return this.addressDeleveryModeNumber;
	}

	/**
	 * @param addressDeleveryModeNumber
	 */
	public void setAddressDeleveryModeNumber(String addressDeleveryModeNumber) {
		this.addressDeleveryModeNumber = addressDeleveryModeNumber;
	}

}
