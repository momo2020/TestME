/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum ManifacturerCompanyCodeEnum.
 */
public enum ManufacturerCompanyCodeEnum {
	ING_WELLINGTON_RUNOFF("1"),

	ING_WESTERN_FACILITY("2"),

	ING_WESTERN_REGION("3"),

	ING_NOVEX("4"),

	TRAFALGAR("5"),

	ING_CENTRAL_ATLANTIC_REGION("6"),

	ING_SPECIALTY_LINES("8"),

	ING_NORDIC_RUNOFF("9"),

	NORDIC_ONTARIO_ATLANTIC_FACILITY("G"),

	INTACT_QUEBEC_REGION("A"),

	BELAIRDIRECT("B"),

	NORDIC_BELAIR("R"),

	GREY_POWER("P");

	/**
	 * Instantiates a new manufacturer company code enum.
	 * 
	 * @param aCode the a code
	 */
	private ManufacturerCompanyCodeEnum(String code) {
		this.code = code;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the manufaturer company code enum
	 */
	public static ManufacturerCompanyCodeEnum valueOfCode(String value) {
		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (ManufacturerCompanyCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}
		throw new IllegalArgumentException("no enum value found for code: " + value);
	}
}
