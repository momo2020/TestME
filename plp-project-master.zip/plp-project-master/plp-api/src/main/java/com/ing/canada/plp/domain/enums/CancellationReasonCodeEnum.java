/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum CancellationReasonCodeEnum.
 * 
 * @author sduchesn
 */
public enum CancellationReasonCodeEnum {
	
	TERM_EXTENSION("3", "3"), 
	TERM_EXTENSION_REVERSAL("4", "4"),
	NON_PAYMENT("A", "2"),
	OTHER_NON_PAYMENT("A", "A"),	
	RISK_STORED_OR_PLACED_IN_STORAGE("B", "B"),
	RISK_STORED_OR_PLACED_IN_STORAGE_RENEWAL("BR", "Q"),
	BETTER_RATES("C", "C"),
	BETTER_RATES_RENEWAL("CR", "N"),
	POOR_SALES_OR_CLAIMS_SERVICE("D", "D"),
	POOR_SALES_OR_CLAIMS_SERVICE_RENEWAL("DR", "O"),
	IMPOSSIBLE_TO_REACH("E", "T"),
	DEATH("F", "F"),
	UNABLE_TO_OBTAIN("G", "G"),
	RISK_AGGRAVATION("H", "1"),
	OTHER_RISK_AGGRAVATION("H", "H"),	
	MOVED ("I", "I"),
	MOVED_RENEWAL ("IR", "U"), 
	TOTAL_LOSS("J", "J"),
	TOTAL_LOSS_RENEWAL("JR", "V"),
	RISK_SOLD_BELAIR_INSURED("K", "K"),
	RISK_NOT_INSPECTED("L", "L"),
	INSURED_CITED_REASON("M", "M"),
	NOT_REQUIRED("N", "E"),
	OTHER_REASON("O", ""),
	OTHER_REASON_RENEWAL("OR", "R"),
	COMPANY_CITED_REASON("P", "P"),
	NO_CASH_ON_HAND("S", "S"),
	FLAT_CANCELLATION_FOR_NON_PAYMENT("V", "W"),
	NON_RENEWAL_BY_COMPANY("X", "X"),
	MISREPRESENTATION("Y", "Y"),
	REJECTED_DUE_TO_CMF_MVR_REPORT("Z", "Z");
	
	
	/** The PLP code (EIS Intact harmonis�). */
	private String plpCode = null;
	
	/** The Classic code (FM Fichier ma�tre) */
	private String classicCode = null;

	/**
	 * Instantiates a cancellation reason code enum.
	 *
	 * @param aPlpCode the a plp code
	 * @param aClassicCode the a classic code
	 */
	private CancellationReasonCodeEnum(String aPlpCode, String aClassicCode) {
		this.plpCode = aPlpCode;
		this.classicCode = aClassicCode;
	}

	/**
	 * Gets the PLP code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.plpCode;
	}

	/**
	 * Gets the Classic code.
	 * 
	 * @return the code
	 */
	public String getClassicCode() {
		return this.classicCode;
	}	

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the cancellation reason code enum
	 */
	public static CancellationReasonCodeEnum valueOfCode(String plpValue) {

		if (StringUtils.isEmpty(plpValue)) {
			return null;
		}

		for (CancellationReasonCodeEnum v : values()) {
			if (v.plpCode.equals(plpValue)) {
				return v;
			}

		}
		throw new IllegalArgumentException("no enum value found for plp code: " + plpValue);
	}
	
	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the cancellation reason code enum
	 */
	public static CancellationReasonCodeEnum classicValueOfCode(String classicValue) {

		if (StringUtils.isEmpty(classicValue)) {
			return null;
		}

		for (CancellationReasonCodeEnum v : values()) {
			if (v.classicCode.equals(classicValue)) {
				return v;
			}
		}
		throw new IllegalArgumentException("no enum value found for classic code: " + classicValue);
	}	
}
