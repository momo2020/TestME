/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */

package com.ing.canada.plp.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.ing.canada.plp.domain.coverage.Coverage;
import com.ing.canada.plp.domain.coverage.CoverageRepositoryEntry;
import com.ing.canada.plp.domain.enums.InternalTechnicalOfferTypeCodeEnum;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.CoverageOffer;
import com.ing.canada.plp.domain.insuranceriskoffer.PolicyOfferRating;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * This interface exposes services required to manage Coverage related entities.
 * 
 * @author fsimard
 */
public interface ICoverageService extends ICRUDService<Coverage> {

	/**
	 * This method returns all coverage of the policy version from all insurance risks.
	 * 
	 * @param policyVersion the policy version
	 * 
	 * @return the list< coverage>
	 */
	List<Coverage> findAllCoveragesByPolicyVersion(PolicyVersion policyVersion);

	/**
	 * This method returns all selected coverage offers of all selected offers of all insurance risk of the policy
	 * version.
	 * 
	 * @param policyVersion the policy version
	 * 
	 * @return the list< coverage offer>
	 */
	List<CoverageOffer> findAllCoverageOffersByPolicyVersion(PolicyVersion policyVersion);

	List<CoverageOffer> findAllCoverageOffersByPolicyOfferRatingAndCoverageGroup(PolicyOfferRating plOffer, String aCode);


	/**
	 * Finds all the coverages offers for a policy version that is linked to an insurance risk offer which the internal
	 * offer type is given in parameter. This method is mostly used in the policy version compare service.
	 * 
	 * @param policyVersion policy version
	 * @param anInternal Internal offer type
	 * @return list of coverages offer
	 */
	List<CoverageOffer> findAllCoverageOffersByPolicyVersionAndInternalOfferType(PolicyVersion policyVersion,
			InternalTechnicalOfferTypeCodeEnum anInternal);
	
	
	/**
	 * This method returns a currently active (non-expired) CoverageRepositoryEntry to use given a coverageCode. 
	 * This is used mainly by the Pega coverage update servlet.
	 * 
	 * @param coverageCode the coverage code
	 * @param provinceCode the province code
	 * @param manufacturerCompanyCodeEnum the company code
	 * 
	 * @return the coverage repository entry
	 */
	CoverageRepositoryEntry findActiveCoverageRepositoryEntryByCoverageCodeAndManufacturerCompany(String coverageCode,
				ProvinceCodeEnum provinceCode, ManufacturerCompanyCodeEnum aCompany);
	
	
	/**
	 * This method returns the proper CoverageRepositoryEntry to use given a coverageCode. This is used mainly by the
	 * data mediator to find the proper coverage repository entry when converting new coverages from the SOM.
	 * 
	 * @param coverageCode the coverage code
	 * @param provinceCode the province code
	 * @param effectiveDate the effective date
	 * 
	 * @return the coverage repository entry
	 */
	CoverageRepositoryEntry findCoverageRepositoryEntryByCoverageCodeAndManufacturerCompany(String coverageCode,
			ProvinceCodeEnum provinceCode, ManufacturerCompanyCodeEnum aCompany, Date effectiveDate);
	
	/**
	 * This method persiste a CoverageRepositoryEntry in the db. If the forcePersist parameter is set to true, it wont
	 * check if the entry already exists in the database
	 * 
	 * @param coverageRepositoryEntry the coverage repository entry
	 * @param forcePersist the force persist flag
	 * 
	 * @return the coverage repository entry
	 */
	CoverageRepositoryEntry persist(CoverageRepositoryEntry coverageRepositoryEntry, boolean forcePersist);

	/**
	 * Find coverage repository entry by coverage code and province code and rating date.
	 * 
	 * @param aProvinceCode the a province code
	 * @param aRatingDate the a rating date
	 * 
	 * @return the map< string, coverage repository entry>
	 */
	Map<String, CoverageRepositoryEntry> findCoverageRepositoryEntriesByProvinceCodeAndRatingDate(
			ProvinceCodeEnum aProvinceCode, ManufacturerCompanyCodeEnum aCompany, Date aRatingDate);

	

	/**
	 * Find coverage repository entry by coverage code and province code and rating date.
	 * 
	 * @param aProvinceCode the a province code
	 * @param aRatingDate the a rating date
	 * 
	 * @return the map< string, coverage repository entry>
	 */
	CoverageRepositoryEntry findCoverageRepositoryEntriesByProvinceCodeAndRatingDate(String coverageCode,
			ProvinceCodeEnum aProvinceCode, ManufacturerCompanyCodeEnum aCompany, Date aRatingDate);

	/**
	 * Find coverage repository entry by province code and company code.
	 * 
	 * @param aProvinceCode the a province code
	 * @param aCompany the a company code
	 * 
	 * @return the List<coverage repository entry>
	 */
	List<CoverageRepositoryEntry> findCoverageRepositoryEntryByManufacturerCompanyAndProvince(
			ProvinceCodeEnum provinceCode, ManufacturerCompanyCodeEnum aCompany);
}
