/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insuranceriskoffer;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.businesstransaction.TransactionalMessage;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * The Class PolicyOfferRating.
 * 
 * @author strichar
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "POLICY_OFFER_RATING", uniqueConstraints = {})
@NamedQueries({ @NamedQuery(name = "PolicyOfferRating.getLatest", query = "SELECT por FROM com.ing.canada.plp.domain.insuranceriskoffer.PolicyOfferRating por "
		+ "WHERE por.policyVersion = :policyVersion and por.id = "
		+ "(SELECT max(por.id) FROM com.ing.canada.plp.domain.insuranceriskoffer.PolicyOfferRating por "
		+ " join por.insuranceRisksOffers iro "
		+ " WHERE iro.internalTechnicalOfferType is null and por.policyVersion = :policyVersion )") })
public class PolicyOfferRating extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "POLICY_OFFER_RATING_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "PollicyOfferRatingSequence")
	@SequenceGenerator(name = "PollicyOfferRatingSequence", sequenceName = "POLICY_OFFER_RATING_SEQ", allocationSize = 5)
	private Long id;

	/** The insurance policy. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "POLICY_VERSION_ID", nullable = false, updatable = true)
	private PolicyVersion policyVersion;

	/** The policy offer rating. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "policyOfferRating")
	@OrderBy("id ASC")
	private Set<TransactionalMessage> transactionalMessages = new HashSet<TransactionalMessage>(0);

	/** The insurance risks offers. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER, mappedBy = "policyOfferRating")
	private Set<InsuranceRiskOffer> insuranceRisksOffers = new HashSet<InsuranceRiskOffer>(0);

	/** The annual premium. */
	@Column(name = "ANNUAL_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer annualPremium;

	/** The full term premium. */
	@Column(name = "FULL_TERM_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer fullTermPremium;

	/** The full term premium taxable. */
	@Column(name = "FULL_TERM_PREMIUM_TAXABLE_AMT", precision = 9, scale = 0)
	private Integer fullTermPremiumTaxable;

	/** The additional return premium. */
	@Column(name = "ADDITIONAL_RETURN_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer additionalReturnPremium;

	/** The add return premium taxable. */
	@Column(name = "ADD_RETURN_PREMIUM_TAXABLE_AMT", precision = 9, scale = 0)
	private Integer additionalReturnPremiumTaxable;

	/** The loyalty discount. */
	@Column(name = "INTERNAL_BILLING_CAA_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean internalBillingCAAIndicator;

	/** The road block indicator. */
	@Column(name = "ROAD_BLOCK_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean roadBlockIndicator;

	/** The add return premium taxable. */
	@Column(name = "INT_IF_MONTHLY_PAYMENT_PCT", precision = 5, scale = 2)
	private Double intIfMonthlyPaymentPct;
	
	@Transient
	private Map<Short, InsuranceRiskOffer> risks = null;

	/** Empty constructor */
	public PolicyOfferRating() {
		// Nothing to do
	}

	/** Minimal constructor */
	public PolicyOfferRating(PolicyVersion aPolicyVersion) {
		setPolicyVersion(aPolicyVersion);
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	@XmlAttribute(name = "id", required = true)
	public Long getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the policy version.
	 * 
	 * @return the policy version
	 */
	@XmlTransient // parent
	public PolicyVersion getPolicyVersion() {
		return this.policyVersion;
	}

	/**
	 * Sets the policy version.
	 * 
	 * @param aPolicyVersion the new policy version
	 */
	public void setPolicyVersion(PolicyVersion aPolicyVersion) {
		AssociationsHelper.updateOneToManyFields(aPolicyVersion, "policyOfferRatings", this, "policyVersion");
	}

	/**
	 * Gets the transactional messages.
	 * 
	 * @return the transactional messages
	 */
	@XmlElementWrapper(name="transactionalMessages")
	@XmlElement(name="transactionalMessage")
	public Set<TransactionalMessage> getTransactionalMessages() {
		return this.transactionalMessages;
	}

	/**
	 * Sets the transactional messages.
	 * 
	 * @param aTransactionalMessages the new transactional messages
	 */
	protected void setTransactionalMessages(Set<TransactionalMessage> aTransactionalMessages) {
		this.transactionalMessages = aTransactionalMessages;
	}

	/**
	 * Adds the transactional message.
	 * 
	 * @param aTransactionalMessage the a transactional message
	 */
	public void addTransactionalMessage(TransactionalMessage aTransactionalMessage) {
		AssociationsHelper.updateOneToManyFields(this, "transactionalMessages", aTransactionalMessage,
				"policyOfferRating");
	}

	/**
	 * Adds the transactional message.
	 * 
	 * @param aTransactionalMessage the a transactional message
	 */
	public void removeTransactionalMessage(TransactionalMessage aTransactionalMessage) {
		AssociationsHelper.updateOneToManyFields(null, "transactionalMessages", aTransactionalMessage,
				"policyOfferRating");
	}

	/**
	 * Gets the insurance risks.
	 * 
	 * @return the insurance risks
	 */
	@XmlElementWrapper(name="insuranceRisksOffers")
	@XmlElement(name="insuranceRisksOffer")
	public Set<InsuranceRiskOffer> getInsuranceRisksOffers() {
		return Collections.unmodifiableSet(this.insuranceRisksOffers);
	}

	/**
	 * Sets the insurance risks.
	 * 
	 * @param aInsuranceRisks the new insurance risks
	 */
	protected void setInsuranceRisksOffers(Set<InsuranceRiskOffer> aInsuranceRisks) {
		this.insuranceRisksOffers = aInsuranceRisks;
	}

	/**
	 * Adds the insurance risk.
	 * 
	 * @param insuranceRisk the insurance risk
	 */
	public void addInsuranceRiskOffer(InsuranceRiskOffer insuranceRisk) {
		AssociationsHelper.updateOneToManyFields(this, "insuranceRisksOffers", insuranceRisk, "policyOfferRating");
	}

	/**
	 * Removes the insurance risk.
	 * 
	 * @param insuranceRisk the insurance risk
	 */
	public void removeInsuranceRiskOfferOffer(InsuranceRiskOffer insuranceRisk) {
		AssociationsHelper.updateOneToManyFields(null, "insuranceRisksOffers", insuranceRisk, "policyOfferRating");
	}

	/**
	 * Gets the annual premium.
	 * 
	 * @return the annual premium
	 */
	public Integer getAnnualPremium() {
		return this.annualPremium;
	}

	/**
	 * Sets the annual premium.
	 * 
	 * @param annualPremiumAmount the new annual premium
	 */
	public void setAnnualPremium(Integer annualPremiumAmount) {
		this.annualPremium = annualPremiumAmount;
	}
	
	public Double getRoundedMonthlyPremium() {

		Double premium = null;

		if (this.getAnnualPremium() != null) {
			premium = new Double(this.getAnnualPremium()) / this.getPolicyVersion().getPolicyTermInMonths().getCode();
			premium = Math.round(premium * 100.0) / 100.0;
		}

		return premium;
	}

	/**
	 * Gets the full term premium.
	 * 
	 * @return the full term premium
	 */
	public Integer getFullTermPremium() {
		return this.fullTermPremium;
	}

	/**
	 * Sets the full term premium.
	 * 
	 * @param fullTermPremiumAmount the new full term premium
	 */
	public void setFullTermPremium(Integer fullTermPremiumAmount) {
		this.fullTermPremium = fullTermPremiumAmount;
	}

	/**
	 * Gets the full term premium taxable.
	 * 
	 * @return the full term premium taxable
	 */
	public Integer getFullTermPremiumTaxable() {
		return this.fullTermPremiumTaxable;
	}

	/**
	 * Sets the full term premium taxable.
	 * 
	 * @param fullTermPremiumTaxableAmount the new full term premium taxable
	 */
	public void setFullTermPremiumTaxable(Integer fullTermPremiumTaxableAmount) {
		this.fullTermPremiumTaxable = fullTermPremiumTaxableAmount;
	}

	/**
	 * Gets the additional return premium.
	 * 
	 * @return the additional return premium
	 */
	public Integer getAdditionalReturnPremium() {
		return this.additionalReturnPremium;
	}

	/**
	 * Sets the additional return premium.
	 * 
	 * @param additionalReturnPremiumAmount the new additional return premium
	 */
	public void setAdditionalReturnPremium(Integer additionalReturnPremiumAmount) {
		this.additionalReturnPremium = additionalReturnPremiumAmount;
	}

	/**
	 * Gets the adds the return premium taxable.
	 * 
	 * @return the adds the return premium taxable
	 */
	public Integer getAdditionalReturnPremiumTaxable() {
		return this.additionalReturnPremiumTaxable;
	}

	/**
	 * Sets the adds the return premium taxable.
	 * 
	 * @param addReturnPremiumTaxableAmount the new adds the return premium taxable
	 */
	public void setAdditionalReturnPremiumTaxable(Integer addReturnPremiumTaxableAmount) {
		this.additionalReturnPremiumTaxable = addReturnPremiumTaxableAmount;
	}

	/**
	 * Gets the internal billing caa indicator.
	 * 
	 * @return the internal billing caa indicator
	 */
	public Boolean getInternalBillingCAAIndicator() {
		return this.internalBillingCAAIndicator;
	}

	/**
	 * Sets the internal billing caa indicator.
	 * 
	 * @param aInternalBillingCAAIndicator the new internal billing caa indicator
	 */
	public void setInternalBillingCAAIndicator(Boolean aInternalBillingCAAIndicator) {
		this.internalBillingCAAIndicator = aInternalBillingCAAIndicator;
	}

	/**
	 * Gets the road block indicator.
	 * 
	 * @return the road block indicator
	 */
	public Boolean getRoadBlockIndicator() {
		return this.roadBlockIndicator;
	}

	/**
	 * Sets the road block indicator.
	 * 
	 * @param isRoadBlockIndicator the new road block indicator
	 */
	public void setRoadBlockIndicator(Boolean isRoadBlockIndicator) {
		this.roadBlockIndicator = isRoadBlockIndicator;
	}

	@Override
	public String toString() {
		return new StringBuilder("id: ").append(this.getId()).append(", ts: ")
				.append(this.getAuditTrail().getCreateTimestamp()).toString();
	}

	public Double getIntIfMonthlyPaymentPct() {
		return this.intIfMonthlyPaymentPct;
	}

	public void setIntIfMonthlyPaymentPct(Double intIfMonthlyPaymentPct) {
		this.intIfMonthlyPaymentPct = intIfMonthlyPaymentPct;
	}
	
	public InsuranceRiskOffer getRiskOffer(short riskSequence) {
		if (this.risks == null) {
			Map<Short, InsuranceRiskOffer> newRisks = new HashMap<Short, InsuranceRiskOffer>();
			
			for (InsuranceRiskOffer risk : this.getInsuranceRisksOffers()) {
				newRisks.put(risk.getInsuranceRisk().getInsuranceRiskSequence(), risk);
			}
			
			this.risks = newRisks;
		}
		
		return this.risks.get(riskSequence);
	}
}
