/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.billing;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.BillingMethodCodeEnum;
import com.ing.canada.plp.domain.enums.BillingPlanCodeEnum;
import com.ing.canada.plp.domain.enums.MethodOfPaymentCodeEnum;
import com.ing.canada.plp.domain.enums.PaymentPlanCodeEnum;
import com.ing.canada.plp.domain.party.PartyGroup;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * Billing entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "BILLING", uniqueConstraints = {})
public class Billing extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@GeneratedValue(generator = "policyVersionForeignGenerator")
	@org.hibernate.annotations.GenericGenerator(name = "policyVersionForeignGenerator", strategy = "foreign", parameters = @Parameter(name = "property", value = "policyVersion"))
	@Column(name = "POLICY_VERSION_ID")
	private Long id = null;

	/** The policy version. */
	@OneToOne(cascade = {}, fetch = FetchType.LAZY, mappedBy = "billing")
	private PolicyVersion policyVersion;

	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "PARTY_GR_SALARY_DEDUCTION_ID")
	private PartyGroup partyGroupSalaryDeduction;

	/** The account. */
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "ACCOUNT_ID", updatable = true)
	private Account account;

	/** The billing method. */
	@Column(name = "BILLING_METHOD_CD", nullable = false, length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.BillingMethodCodeEnum") })
	private BillingMethodCodeEnum billingMethod;

	/** The billing plan. */
	@Column(name = "BILLING_PLAN_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.BillingPlanCodeEnum") })
	private BillingPlanCodeEnum billingPlan;

	/** The payment method. */
	@Column(name = "METHOD_OF_PAYMENT_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.MethodOfPaymentCodeEnum") })
	private MethodOfPaymentCodeEnum methodOfPayment;

	/** The payment installments number. */
	@Column(name = "NBR_OF_PAYMENT_INSTLM_QTY", precision = 2, scale = 0)
	private Byte numberOfPaymentInstallments;

	/** The payment plan. */
	@Column(name = "PAYMENT_PLAN_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PaymentPlanCodeEnum") })
	private PaymentPlanCodeEnum paymentPlan;

	/** The service charge. */
	@Column(name = "SERVICE_CHARGE_AMT", precision = 11)
	private BigDecimal serviceCharge;

	/** The provincial sales tax. */
	@Column(name = "PROVINCIAL_SALES_TAX_AMT", precision = 11)
	private BigDecimal provincialSalesTax;

	/** The payment deposit. */
	@Column(name = "PAYMENT_DEPOSIT_AMT", precision = 11)
	private BigDecimal paymentDeposit;

	/** The remaining payment amount. */
	@Column(name = "REMAINING_PAYMENT_AMT", precision = 11)
	private BigDecimal remainingPaymentAmount;

	/** The payment day. */
	@Column(name = "DAY_OF_PAYMENT_NBR", length = 2)
	private String dayOfPayment;

	/** The payment schedules. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "billing")
	//Modified by wguandiq (28/10/2010) - PM5158: AQ issue:displaying the subsequent monthly payment incorrectly
	@OrderBy("systemDateTime, paymentScheduleSequence ASC")
	private Set<PaymentSchedule> paymentSchedules = new HashSet<PaymentSchedule>(0);

	/**
	 * Instantiates a new billing.
	 */
	public Billing() {
		// noarg constructor
	}

	/**
	 * Instantiates a new billing.
	 * 
	 * @param aPolicyVersion the a policy version
	 * @param billingMethodCode the billing method code
	 */
	public Billing(PolicyVersion aPolicyVersion, BillingMethodCodeEnum billingMethodCode) {
		setPolicyVersion(aPolicyVersion);
		setBillingMethod(billingMethodCode);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the policy version.
	 * 
	 * @return the policy version
	 */
	@XmlTransient // parent
	public PolicyVersion getPolicyVersion() {
		return this.policyVersion;
	}

	/**
	 * Sets the policy version.
	 * 
	 * @param aPolicyVersion the new policy version
	 */
	public void setPolicyVersion(PolicyVersion aPolicyVersion) {
		AssociationsHelper.updateOneToOneFields(aPolicyVersion, PolicyVersion.class, "billing", this, Billing.class,
				"policyVersion");
	}

	/**
	 * Gets the account.
	 * 
	 * @return the account
	 */
	public Account getAccount() {
		return this.account;
	}

	/**
	 * Sets the account.
	 * 
	 * @param aAccount the new account
	 */
	public void setAccount(Account aAccount) {
		AssociationsHelper.updateOneToManyFields(aAccount, "billings", this, "account");
	}

	/**
	 * Gets the billing method.
	 * 
	 * @return the billing method
	 */
	public BillingMethodCodeEnum getBillingMethod() {
		return this.billingMethod;
	}

	/**
	 * Sets the billing method.
	 * 
	 * @param billingMethodCode the new billing method
	 */
	public void setBillingMethod(BillingMethodCodeEnum billingMethodCode) {
		this.billingMethod = billingMethodCode;
	}

	/**
	 * Gets the billing plan.
	 * 
	 * @return the billing plan
	 */
	public BillingPlanCodeEnum getBillingPlan() {
		return this.billingPlan;
	}

	/**
	 * Sets the billing plan.
	 * 
	 * @param billingPlanCode the new billing plan
	 */
	public void setBillingPlan(BillingPlanCodeEnum billingPlanCode) {
		this.billingPlan = billingPlanCode;
	}

	/**
	 * Gets the payment method.
	 * 
	 * @return the payment method
	 */
	public MethodOfPaymentCodeEnum getMethodOfPayment() {
		return this.methodOfPayment;
	}

	/**
	 * Sets the payment method.
	 * 
	 * @param methodOfPaymentCode the new payment method
	 */
	public void setMethodOfPayment(MethodOfPaymentCodeEnum methodOfPaymentCode) {
		this.methodOfPayment = methodOfPaymentCode;
	}

	/**
	 * Gets the payment installments number.
	 * 
	 * @return the payment installments number
	 */
	public Byte getNumberOfPaymentInstallments() {
		return this.numberOfPaymentInstallments;
	}

	/**
	 * Sets the payment installments number.
	 * 
	 * @param nbrOfPaymentInstlm the new payment installments number
	 */
	public void setNumberOfPaymentInstallments(Byte nbrOfPaymentInstlm) {
		this.numberOfPaymentInstallments = nbrOfPaymentInstlm;
	}

	/**
	 * Gets the payment plan.
	 * 
	 * @return the payment plan
	 */
	public PaymentPlanCodeEnum getPaymentPlan() {
		return this.paymentPlan;
	}

	/**
	 * Sets the payment plan.
	 * 
	 * @param paymentPlanCode the new payment plan
	 */
	public void setPaymentPlan(PaymentPlanCodeEnum paymentPlanCode) {
		this.paymentPlan = paymentPlanCode;
	}

	/**
	 * Gets the service charge.
	 * 
	 * @return the service charge
	 */
	public BigDecimal getServiceCharge() {
		return this.serviceCharge;
	}

	/**
	 * Sets the service charge.
	 * 
	 * @param serviceChargeAmount the new service charge
	 */
	public void setServiceCharge(BigDecimal serviceChargeAmount) {
		this.serviceCharge = serviceChargeAmount;
	}

	/**
	 * Gets the provincial sales tax.
	 * 
	 * @return the provincial sales tax
	 */
	public BigDecimal getProvincialSalesTax() {
		return this.provincialSalesTax;
	}

	/**
	 * Sets the provincial sales tax.
	 * 
	 * @param provincialSalesTaxAmount the new provincial sales tax
	 */
	public void setProvincialSalesTax(BigDecimal provincialSalesTaxAmount) {
		this.provincialSalesTax = provincialSalesTaxAmount;
	}

	/**
	 * Gets the payment deposit.
	 * 
	 * @return the payment deposit
	 */
	public BigDecimal getPaymentDeposit() {
		return this.paymentDeposit;
	}

	/**
	 * Sets the payment deposit.
	 * 
	 * @param paymentDepositAmount the new payment deposit
	 */
	public void setPaymentDeposit(BigDecimal paymentDepositAmount) {
		this.paymentDeposit = paymentDepositAmount;
	}

	/**
	 * Gets the remaining payment amount.
	 * 
	 * @return the remaining payment amount
	 */
	public BigDecimal getRemainingPaymentAmount() {
		return this.remainingPaymentAmount;
	}

	/**
	 * Sets the remaining payment amount.
	 * 
	 * @param aRemainingPaymentAmount the new remaining payment amount
	 */
	public void setRemainingPaymentAmount(BigDecimal aRemainingPaymentAmount) {
		this.remainingPaymentAmount = aRemainingPaymentAmount;
	}

	/**
	 * Gets the payment day.
	 * 
	 * @return the payment day
	 */
	public String getDayOfPayment() {
		return this.dayOfPayment;
	}

	/**
	 * Sets the payment day.
	 * 
	 * @param dayOfPaymentNumber the new payment day
	 */
	public void setDayOfPayment(String dayOfPaymentNumber) {
		this.dayOfPayment = dayOfPaymentNumber;
	}

	/**
	 * Gets the payment schedules.
	 * 
	 * @return the payment schedules
	 */
	@XmlElementWrapper(name="paymentSchedules")
	@XmlElement(name="paymentSchedule")
	public Set<PaymentSchedule> getPaymentSchedules() {
		return Collections.unmodifiableSet(this.paymentSchedules);
	}

	/**
	 * Sets the payment schedules.
	 * 
	 * @param aPaymentSchedules the new payment schedules
	 */
	protected void setPaymentSchedules(Set<PaymentSchedule> aPaymentSchedules) {
		this.paymentSchedules = aPaymentSchedules;
	}

	/**
	 * Adds the payment schedule.
	 * 
	 * @param schedule the schedule
	 */
	public void addPaymentSchedule(com.ing.canada.plp.domain.billing.PaymentSchedule schedule) {
		AssociationsHelper.updateOneToManyFields(this, "paymentSchedules", schedule, "billing");
	}

	/**
	 * Removes the payment schedule.
	 * 
	 * @param schedule the schedule
	 */
	public void removePaymentSchedule(com.ing.canada.plp.domain.billing.PaymentSchedule schedule) {
		AssociationsHelper.updateOneToManyFields(null, "paymentSchedules", schedule, "billing");
	}

	/**
	 * Gets the first payment schedule.
	 * 
	 * @return the first payment schedule
	 */
	public PaymentSchedule getFirstPaymentSchedule() {

		if (this.paymentSchedules.size() > 0) {
			return this.paymentSchedules.iterator().next();
		}
		return null;
	}

	/**
	 * @return the partyGroupSalaryDeduction
	 */
	public PartyGroup getPartyGroupSalaryDeduction() {
		return this.partyGroupSalaryDeduction;
	}

	/**
	 * @param aPartyGroupSalaryDeduction the partyGroupSalaryDeduction to set
	 */
	public void setPartyGroupSalaryDeduction(PartyGroup aPartyGroupSalaryDeduction) {
		this.partyGroupSalaryDeduction = aPartyGroupSalaryDeduction;
	}

}
