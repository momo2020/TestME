package com.ing.canada.plp.domain.enums;

import static org.apache.commons.lang.StringUtils.isEmpty;



public enum ReportRequestStatus {
	
	RECEIVED("4"),
	NOT_FOUND("5"),
	ERROR("7");
	
	
	private String code;
	
	
	private ReportRequestStatus(final String code){
		this.code = code;
	}


	public String getCode() {
		return code;
	}


	public void setCode(final String code) {
		this.code = code;
	}
	
	
	public static ReportRequestStatus valueOfCode(final String code) {

		if (isEmpty(code))
			return null;

		for (ReportRequestStatus c : values()) {
			if (c.code.equals(code)) {
				return (c);
			}

		}

		throw new IllegalArgumentException("ReportRequestStatus enum code=" + code + " does not exist");

	}
	
	
}
