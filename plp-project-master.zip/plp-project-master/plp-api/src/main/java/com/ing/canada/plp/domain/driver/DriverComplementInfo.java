/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.driver;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.ActionTakenCodeEnum;
import com.ing.canada.plp.domain.enums.DriverLicenseTypeCodeEnum;
import com.ing.canada.plp.domain.enums.InsuredWithCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.LicenseJurisdictionCodeEnum;
import com.ing.canada.plp.domain.enums.MvrSaaqAuthorizationCodeEnum;
import com.ing.canada.plp.domain.enums.PriorGridLevelClientCodeEnum;
import com.ing.canada.plp.domain.enums.RelationshipToNamedInsuredCodeEnum;
import com.ing.canada.plp.domain.enums.TrainingTerminatedSinceCodeEnum;
import com.ing.canada.plp.domain.enums.UBIDiscountCriteriaEnum;
import com.ing.canada.plp.domain.enums.UBIStatusCodeEnum;
import com.ing.canada.plp.domain.party.Party;
import com.ing.canada.plp.domain.policyversion.RelatedInsurancePolicy;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * DriverComplementInfo entity.
 * 
 * @author Patrick Lafleur
 * 
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "DRIVER_COMPLEMENT_INFO", uniqueConstraints = {})
public class DriverComplementInfo extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(DriverComplementInfo.class);

	/** The id. */
	@Id
	@GeneratedValue(generator = "partyForeignGenerator")
	@org.hibernate.annotations.GenericGenerator(name = "partyForeignGenerator", strategy = "foreign", parameters = @Parameter(name = "property", value = "party"))
	@Column(name = "PARTY_ID")
	private Long id;

	/** The party. */
	@OneToOne(cascade = {}, fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn(name = "PARTY_ID")
	private Party party;

	/** The related insurance policy. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "RELATED_INSURANCE_POLICY_ID", updatable = true)
	private RelatedInsurancePolicy relatedInsurancePolicy;

	/** The driver sequence. */
	@Column(name = "DRIVER_SEQ", nullable = false, precision = 5, scale = 0)
	private int driverSequence;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", length = 7)
	private Date effectiveDate;

	/** The date of last request to mvrsaaq. */
	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_REQUEST_TO_MVRSAAQ_DT", length = 7)
	private Date dateOfLastRequestToMvrSaaq;

	/** The submit request to mvrsaaq. */
	@Column(name = "SUBMIT_REQUEST_TO_MVRSAAQ_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean submitRequestToMvrSaaq;

	/** The relationship to named insured. */
	@Column(name = "RELATIONSHIP_TO_NAMED_INSD_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.RelationshipToNamedInsuredCodeEnum") })
	private RelationshipToNamedInsuredCodeEnum relationshipToNamedInsured = null;

	/** The resides with parent. */
	@Column(name = "RESIDE_WITH_PARENTS_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean residesWithParentsIndicator;

	/** The driver training indicator. */
	@Column(name = "DRIVER_TRAINING_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean driverTrainingIndicator;

	/** The training school name. */
	@Column(name = "TRAINING_SCHOOL_NAME_TXT", length = 50)
	private String trainingSchoolName;

	/** The training certificate number. */
	@Column(name = "TRAINING_CERTIFICATE_NBR", length = 20)
	private String trainingCertificateNumber;

	/** The training terminated since code. */
	@Column(name = "TRAINING_TERMINATED_SINCE_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.TrainingTerminatedSinceCodeEnum") })
	private TrainingTerminatedSinceCodeEnum trainingTerminatedSinceCode = null;

	/** The driver license type. */
	@Column(name = "DRIVER_LICENSE_TYPE_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.DriverLicenseTypeCodeEnum") })
	private DriverLicenseTypeCodeEnum driverLicenseType = null;

	/** The license jurisdiction. */
	@Column(name = "LICENSE_JURISDICTION_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.LicenseJurisdictionCodeEnum") })
	private LicenseJurisdictionCodeEnum licenseJurisdiction = null;

	/** The license number. */
	@Column(name = "LICENSE_NBR", length = 30)
	private String licenseNumber;

	/** The date driver license obtained. */
	@Temporal(TemporalType.DATE)
	@Column(name = "DRVR_LICENSE_OBTAINED_DT", length = 7)
	private Date dateDriverLicenseObtained;

	/** The age drvr license obtained. */
	@Column(name = "AGE_DRVR_LICENSE_OBTAINED_QTY", precision = 2, scale = 0)
	private Byte ageDriverLicenseObtained;

	/** The obtained g2 or g class in last12 months. */
	@Column(name = "OBT_G2_OR_G_CLASS_12_MTH_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean obtainedG2OrGClassInLast12MonthsIndicator;

	/** insured With Company Ind */
	@Column(name = "INSURED_WITH_COMPANY_IND")
	@Type(type = "yes_no")
	private Boolean insuredWithCompanyIndicator;


	/** insured with company cdoe */
	@Column(name = "INSURED_WITH_COMPANY_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.InsuredWithCompanyCodeEnum") })
	private InsuredWithCompanyCodeEnum insuredWithCompanyCode;

	/** The date insured with company. */
	@Temporal(TemporalType.DATE)
	@Column(name = "INSURED_WITH_COMPANY_DT", length = 7)
	private Date insuredWithCompanyDate;

	/** The school distance in kilometers. */
	@Column(name = "NBR_KM_TO_GO_TO_SCHOOL_QTY", precision = 3, scale = 0)
	private Short schoolDistanceInKilometers;

	/** The school more than100 kms from parent residence. */
	@Column(name = "SCHOOL_MORE_100KMS_PAR_RES_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean schoolMoreThan100KmsFromParentResidence;

	/** The number ofmonths annually studying away. */
	@Column(name = "NBR_MONTHS_ANLY_STDY_AWAY_QTY", precision = 2, scale = 0)
	private Byte numberOfmonthsAnnuallyStudyingAway;

	/** The mvr saaq authorization code. */
	@Column(name = "MVR_SAAQ_AUTHORIZATION_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.MvrSaaqAuthorizationCodeEnum") })
	private MvrSaaqAuthorizationCodeEnum mvrSaaqAuthorizationCode = null;

	/** The number of minor convictions3 years. */
	@Column(name = "NBR_MINOR_CNVCTN_3YRS_QTY", precision = 2, scale = 0)
	private Byte numberOfMinorConvictions3Years;

	/** The number of major convictions3 years. */
	@Column(name = "NBR_MAJOR_CNVCTN_3YRS_QTY", precision = 2, scale = 0)
	private Byte numberOfMajorConvictions3Years;

	/** The number of severe convictions3 years. */
	@Column(name = "NBR_SEVERE_CNVCTN_3YRS_QTY", precision = 3, scale = 0)
	private Short numberOfSevereConvictions3Years;

	/** The license suspended or cancelled. */
	@Column(name = "LIC_SUSPENSION_OR_CNCLTN_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean licenseSuspensionOrCancellationIndicator;

	/** The parent insured with company. */
	@Column(name = "PARENTS_INSRD_WITH_COMPANY_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean parentsInsuredWithCompanyIndicator;

	@Column(name = "RELEVANT_CLAIM_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean relevantClaimIndicator;

	/** The convictions. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "driverComplementInfo", orphanRemoval = true)
	private Set<Conviction> convictions = new HashSet<Conviction>(0);

	/** The driver license classes. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "driverComplementInfo", orphanRemoval = true)
	private Set<DriverLicenseClass> driverLicenseClasses = new HashSet<DriverLicenseClass>(0);

	/** The original scenario party. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_PARTY_ID", insertable = false, updatable = false)
	private DriverComplementInfo originalScenarioDriverComplementInfo;

	/** The has held full term auto insurance indicator. */
	@Column(name = "HAS_HELD_FULL_TRM_AUTO_INS_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean hasHeldFullTermAutoInsuranceIndicator;

	/** The action taken. */
	@Column(name = "ACTION_TAKEN_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ActionTakenCodeEnum") })
	private ActionTakenCodeEnum actionTaken = null;

	/** The Grid Level qty. */
	@Column(name = "GRID_LEVEL_QTY", precision = 3, scale = 0)
	private Short gridLevelQty = null;

	/** The Prior Grid Level qty. */
	@Column(name = "PRIOR_GRID_LEVEL_QTY", precision = 3, scale = 0)
	private Short priorGridLevelQty = null;

	/** The Prior Grid Level code enter by the client */
	@Column(name = "PRIOR_GRID_LEVEL_CLIENT_CD", length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PriorGridLevelClientCodeEnum") })
	private PriorGridLevelClientCodeEnum priorGridLevelClient = null;

	/** The date Grid level was calculated. */
	@Temporal(TemporalType.DATE)
	@Column(name = "GRID_LEVEL_DT", length = 7)
	private Date gridLevelDate;

	/** interruption in the continuous insurance */
	@Column(name = "INS_INTER_IN_LAST_PERIOD_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean insuranceInterruptionInLastPeriodIndicator;

	/** driving during weekend only */
	@Column(name = "DRIVING_DURING_WKEND_ONLY_IND")
	@Type(type = "yes_no")
	private Boolean drivingWeekendOnlyIndicator;

	/** The continuously insured since date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "CONTINUOUSLY_INSURED_SINCE_DT")
	private Date continuouslyInsuredSinceDate;

	/** Indicator if is living with the named insured party **/
	@Column(name = "RESIDE_WITH_NAMED_INSD_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean resideWithNamedInsdIndicator;

	/** Indicate if the client is interested to the UBI program **/
	@Column(name = "INTERESTED_BY_UBI_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean interestedByUBIIndicator;

	/** The status of the UBI program */
	@Column(name = "UBI_STATUS_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.UBIStatusCodeEnum") })
	private UBIStatusCodeEnum UBIStatusCode = null;
	
	/** The number of convictions for 5 years. Entered by the client. */
	@Column(name = "NBR_CNVCTN_5YRS_QTY", precision = 2, scale = 0)
	private Byte numberOfConvictions5Years;
	
	/** The number of penalty points for 5 years. Entered by the client. */
	@Column(name = "NBR_PENALTY_POINTS_5YRS_QTY", precision = 2, scale = 0)
	private Byte numberOfPenaltyPoints5Years;
	
	/** The system UBI discount percentage of the driver */
	@Column(name = "UBI_DISCOUNT_SYS_PCT", precision = 2, scale = 0)
	private Short UBIDiscountSystemPct = null;
	
	/** The user entered UBI discount percentage of the driver */
	@Column(name = "UBI_DISCOUNT_MOD_PCT", precision = 2, scale = 0)
	private Short UBIDiscountModifiedPct = null;
	
	/** The "used" UBI discount percentage of the driver */
	@Column(name = "UBI_DISCOUNT_PCT", precision = 2, scale = 0)
	private Short UBIDiscountPercentage = null;
	
	/** The ubi discount criteria. */
	@Column(name = "UBI_DEVICE_DSCNT_CRITERIA_CD", length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.UBIDiscountCriteriaEnum") })
	private UBIDiscountCriteriaEnum UBIDiscountCriteriaCode = null;
	
	/**
	 * Instantiates a new driver complement info.
	 */
	public DriverComplementInfo() {
		// noarg constructor
	}

	/**
	 * Instantiates a new driver complement info.
	 * 
	 * @param aParty the a party
	 * @param aDriverSeq the a driver seq
	 */
	public DriverComplementInfo(Party aParty, int aDriverSeq) {
		this.setParty(aParty);
		this.setDriverSequence(aDriverSeq);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param partyId the party id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object partyId) {
		this.id = (Long) partyId;
	}

	/**
	 * Gets the party.
	 * 
	 * @return the party
	 */
	@XmlTransient // parent
	public Party getParty() {
		return this.party;
	}

	/**
	 * Sets the party.
	 * 
	 * @param aParty the new party
	 */
	public void setParty(Party aParty) {
		AssociationsHelper.updateOneToOneFields(aParty, Party.class, "driverComplementInfo", this,
				DriverComplementInfo.class, "party");
	}

	/**
	 * Gets the related insurance policy.
	 * 
	 * @return the related insurance policy
	 */
	public RelatedInsurancePolicy getRelatedInsurancePolicy() {
		return this.relatedInsurancePolicy;
	}

	/**
	 * Sets the related insurance policy.
	 * 
	 * @param aRelatedInsurancePolicy the new related insurance policy
	 */
	public void setRelatedInsurancePolicy(RelatedInsurancePolicy aRelatedInsurancePolicy) {
		AssociationsHelper.updateOneToManyFields(aRelatedInsurancePolicy, "driverComplementInfos", this,
				"relatedInsurancePolicy");
	}

	/**
	 * Gets the driver sequence.
	 * 
	 * @return the driver sequence
	 */
	public int getDriverSequence() {
		return this.driverSequence;
	}

	/**
	 * Sets the driver sequence.
	 * 
	 * @param driverSeq the new driver sequence
	 */
	public void setDriverSequence(int driverSeq) {
		this.driverSequence = driverSeq;
	}

	/**
	 * Gets the effective date.
	 * 
	 * @return the effective date
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * Sets the effective date.
	 * 
	 * @param aEffectiveDate the new effective date
	 */
	public void setEffectiveDate(Date aEffectiveDate) {
		this.effectiveDate = aEffectiveDate;
	}

	/**
	 * Gets the date of last request to mvrsaaq.
	 * 
	 * @return the date of last request to mvrsaaq
	 */
	public Date getDateOfLastRequestToMvrSaaq() {
		return this.dateOfLastRequestToMvrSaaq;
	}

	/**
	 * Sets the date of last request to mvrsaaq.
	 * 
	 * @param lastRequestToMvrsaaqDate the new date of last request to mvrsaaq
	 */
	public void setDateOfLastRequestToMvrSaaq(Date lastRequestToMvrsaaqDate) {
		this.dateOfLastRequestToMvrSaaq = lastRequestToMvrsaaqDate;
	}

	/**
	 * Gets the submit request to mvrsaaq.
	 * 
	 * @return the submit request to mvrsaaq
	 */
	public Boolean getSubmitRequestToMvrSaaq() {
		return this.submitRequestToMvrSaaq;
	}

	/**
	 * Sets the submit request to mvrsaaq.
	 * 
	 * @param submitRequestToMvrsaaqIndicator the new submit request to mvrsaaq
	 */
	public void setSubmitRequestToMvrSaaq(Boolean submitRequestToMvrsaaqIndicator) {
		this.submitRequestToMvrSaaq = submitRequestToMvrsaaqIndicator;
	}

	/**
	 * Gets the relationship to named insured.
	 * 
	 * @return the relationship to named insured
	 */
	public RelationshipToNamedInsuredCodeEnum getRelationshipToNamedInsured() {
		return this.relationshipToNamedInsured;
	}

	/**
	 * Sets the relationship to named insured.
	 * 
	 * @param relationshipToNamedInsdCode the new relationship to named insured
	 */
	public void setRelationshipToNamedInsured(RelationshipToNamedInsuredCodeEnum relationshipToNamedInsdCode) {
		this.relationshipToNamedInsured = relationshipToNamedInsdCode;
	}

	/**
	 * Gets the resides with parent.
	 * 
	 * @return the resides with parent
	 */
	public Boolean getResidesWithParentsIndicator() {
		return this.residesWithParentsIndicator;
	}

	/**
	 * Sets the resides with parent.
	 * 
	 * @param resideWithParentsIndicator the new resides with parent
	 */
	public void setResidesWithParentsIndicator(Boolean resideWithParentsIndicator) {
		this.residesWithParentsIndicator = resideWithParentsIndicator;
	}

	/**
	 * Gets the driver training indicator.
	 * 
	 * @return the driver training indicator
	 */
	public Boolean getDriverTrainingIndicator() {
		return this.driverTrainingIndicator;
	}

	/**
	 * Sets the driver training indicator.
	 * 
	 * @param aDriverTrainingIndicator the new driver training indicator
	 */
	public void setDriverTrainingIndicator(Boolean aDriverTrainingIndicator) {
		this.driverTrainingIndicator = aDriverTrainingIndicator;
	}

	/**
	 * Gets the training school name.
	 * 
	 * @return the training school name
	 */
	public String getTrainingSchoolName() {
		return this.trainingSchoolName;
	}

	/**
	 * Sets the training school name.
	 * 
	 * @param aTrainingSchoolName the new training school name
	 */
	public void setTrainingSchoolName(String aTrainingSchoolName) {
		this.trainingSchoolName = aTrainingSchoolName;
	}

	/**
	 * Gets the training certificate number.
	 * 
	 * @return the training certificate number
	 */
	public String getTrainingCertificateNumber() {
		return this.trainingCertificateNumber;
	}

	/**
	 * Sets the training certificate number.
	 * 
	 * @param aTrainingCertificateNumber the new training certificate number
	 */
	public void setTrainingCertificateNumber(String aTrainingCertificateNumber) {
		this.trainingCertificateNumber = aTrainingCertificateNumber;
	}

	/**
	 * Gets the driver license type.
	 * 
	 * @return the driver license type
	 */
	public DriverLicenseTypeCodeEnum getDriverLicenseType() {
		return this.driverLicenseType;
	}
	
	public DriverLicenseClass getLicenceClass() {
		
		DriverLicenseClass driverLicence = null;
		
		if (this.getDriverLicenseClasses() != null) {
			for (DriverLicenseClass licence : this.getDriverLicenseClasses()) {
				driverLicence = licence;
			}
		}
		
		return driverLicence;
	}

	/**
	 * Sets the driver license type.
	 * 
	 * @param driverLicenseTypeCode the new driver license type
	 */
	public void setDriverLicenseType(DriverLicenseTypeCodeEnum driverLicenseTypeCode) {
		this.driverLicenseType = driverLicenseTypeCode;
	}

	/**
	 * Gets the license jurisdiction.
	 * 
	 * @return the license jurisdiction
	 */
	public LicenseJurisdictionCodeEnum getLicenseJurisdiction() {
		return this.licenseJurisdiction;
	}

	/**
	 * Sets the license jurisdiction.
	 * 
	 * @param licenseJurisdictionCode the new license jurisdiction
	 */
	public void setLicenseJurisdiction(LicenseJurisdictionCodeEnum licenseJurisdictionCode) {
		this.licenseJurisdiction = licenseJurisdictionCode;
	}

	/**
	 * Gets the license number.
	 * 
	 * @return the license number
	 */
	public String getLicenseNumber() {
		return this.licenseNumber;
	}

	/**
	 * Sets the license number.
	 * 
	 * @param aLicenseNumber the new license number
	 */
	public void setLicenseNumber(String aLicenseNumber) {
		this.licenseNumber = aLicenseNumber;
	}

	/**
	 * Gets the date driver license obtained.
	 * 
	 * @return the date driver license obtained
	 */
	public Date getDateDriverLicenseObtained() {
		return this.dateDriverLicenseObtained;
	}

	/**
	 * Sets the date driver license obtained.
	 * 
	 * @param drvrLicenseObtainedDate the new date driver license obtained
	 */
	public void setDateDriverLicenseObtained(Date drvrLicenseObtainedDate) {
		this.dateDriverLicenseObtained = drvrLicenseObtainedDate;
	}

	/**
	 * Gets the age drvr license obtained.
	 * 
	 * @return the age drvr license obtained
	 */
	public Byte getAgeDriverLicenseObtained() {
		return this.ageDriverLicenseObtained;
	}

	/**
	 * Sets the age drvr license obtained.
	 * 
	 * @param aAgeDrvrLicenseObtained the new age drvr license obtained
	 */
	public void setAgeDriverLicenseObtained(Byte aAgeDrvrLicenseObtained) {
		this.ageDriverLicenseObtained = aAgeDrvrLicenseObtained;
	}

	/**
	 * Gets the obtained g2 or g class in last12 months.
	 * 
	 * @return the obtained g2 or g class in last12 months
	 */
	public Boolean getObtainedG2OrGClassInLast12MonthsIndicator() {
		return this.obtainedG2OrGClassInLast12MonthsIndicator;
	}

	/**
	 * Sets the obtained g2 or g class in last12 months.
	 * 
	 * @param obtG2OrGClass12MthIndicator the new obtained g2 or g class in last12 months
	 */
	public void setObtainedG2OrGClassInLast12MonthsIndicator(Boolean obtG2OrGClass12MthIndicator) {
		this.obtainedG2OrGClassInLast12MonthsIndicator = obtG2OrGClass12MthIndicator;
	}

	/**
	 * Gets the number of year insured with the company.
	 * 
	 * @return the insured with company code in number of year
	 */
	public InsuredWithCompanyCodeEnum getInsuredWithCompanyCode() {
		return this.insuredWithCompanyCode;
	}

	/**
	 * Sets the number of year insured with the company
	 * 
	 * @param aInsuredWithCompanyCode {@link #insuredWithCompanyCode}
	 */
	public void setInsuredWithCompanyCode(InsuredWithCompanyCodeEnum aInsuredWithCompanyCode) {
		this.insuredWithCompanyCode = aInsuredWithCompanyCode;
	}

	/**
	 * Gets the insured with company indicator
	 * 
	 * @return Insured with company indicator
	 */
	public Boolean getInsuredWithCompanyIndicator() {
		return this.insuredWithCompanyIndicator;
	}

	/**
	 * Sets the insured with company indicator
	 * 
	 * @param aInsuredWithCompanyIndicator {@link #insuredWithCompanyIndicator}
	 */
	public void setInsuredWithCompanyIndicator(Boolean aInsuredWithCompanyIndicator) {
		this.insuredWithCompanyIndicator = aInsuredWithCompanyIndicator;
	}

	/**
	 * Gets the date insured with company.
	 * 
	 * @return the date insured with company
	 */
	public Date getInsuredWithCompanyDate() {
		return this.insuredWithCompanyDate;
	}

	/**
	 * Sets the date insured with company.
	 * 
	 * @param anInsuredWithCompanyDate the new date insured with company
	 */
	public void setInsuredWithCompanyDate(Date anInsuredWithCompanyDate) {
		this.insuredWithCompanyDate = anInsuredWithCompanyDate;
	}

	/**
	 * Gets the school distance in kilometers.
	 * 
	 * @return the school distance in kilometers
	 */
	public Short getSchoolDistanceInKilometers() {
		return this.schoolDistanceInKilometers;
	}

	/**
	 * Sets the school distance in kilometers.
	 * 
	 * @param nbrKmToGoToSchool the new school distance in kilometers
	 */
	public void setSchoolDistanceInKilometers(Short nbrKmToGoToSchool) {
		this.schoolDistanceInKilometers = nbrKmToGoToSchool;
	}

	/**
	 * Gets the school more than100 kms from parent residence.
	 * 
	 * @return the school more than100 kms from parent residence
	 */
	public Boolean getSchoolMoreThan100KmsFromParentResidence() {
		return this.schoolMoreThan100KmsFromParentResidence;
	}

	/**
	 * Sets the school more than100 kms from parent residence.
	 * 
	 * @param schoolMore100kmsParResIndicator the new school more than100 kms from parent residence
	 */
	public void setSchoolMoreThan100KmsFromParentResidence(Boolean schoolMore100kmsParResIndicator) {
		this.schoolMoreThan100KmsFromParentResidence = schoolMore100kmsParResIndicator;
	}

	/**
	 * Gets the number ofmonths annually studying away.
	 * 
	 * @return the number ofmonths annually studying away
	 */
	public Byte getNumberOfmonthsAnnuallyStudyingAway() {
		return this.numberOfmonthsAnnuallyStudyingAway;
	}

	/**
	 * Sets the number ofmonths annually studying away.
	 * 
	 * @param nbrMonthsAnlyStdyAway the new number ofmonths annually studying away
	 */
	public void setNumberOfmonthsAnnuallyStudyingAway(Byte nbrMonthsAnlyStdyAway) {
		this.numberOfmonthsAnnuallyStudyingAway = nbrMonthsAnlyStdyAway;
	}

	/**
	 * Gets the mvr saaq authorization code.
	 * 
	 * @return the mvr saaq authorization code
	 */
	public MvrSaaqAuthorizationCodeEnum getMvrSaaqAuthorizationCode() {
		return this.mvrSaaqAuthorizationCode;
	}

	/**
	 * Sets the mvr saaq authorization code.
	 * 
	 * @param aMvrSaaqAuthorizationCode the new mvr saaq authorization code
	 */
	public void setMvrSaaqAuthorizationCode(MvrSaaqAuthorizationCodeEnum aMvrSaaqAuthorizationCode) {
		this.mvrSaaqAuthorizationCode = aMvrSaaqAuthorizationCode;
	}

	/**
	 * Gets the number of minor convictions3 years.
	 * 
	 * @return the number of minor convictions3 years
	 */
	public Byte getNumberOfMinorConvictions3Years() {
		return this.numberOfMinorConvictions3Years;
	}

	/**
	 * Sets the number of minor convictions3 years.
	 * 
	 * @param nbrMinorCnvctn3yrs the new number of minor convictions3 years
	 */
	public void setNumberOfMinorConvictions3Years(Byte nbrMinorCnvctn3yrs) {
		this.numberOfMinorConvictions3Years = nbrMinorCnvctn3yrs;
	}

	/**
	 * Gets the number of major convictions3 years.
	 * 
	 * @return the number of major convictions3 years
	 */
	public Byte getNumberOfMajorConvictions3Years() {
		return this.numberOfMajorConvictions3Years;
	}

	/**
	 * Sets the number of major convictions3 years.
	 * 
	 * @param nbrMajorCnvctn3yrs the new number of major convictions3 years
	 */
	public void setNumberOfMajorConvictions3Years(Byte nbrMajorCnvctn3yrs) {
		this.numberOfMajorConvictions3Years = nbrMajorCnvctn3yrs;
	}

	/**
	 * Gets the number of severe convictions3 years.
	 * 
	 * @return the number of severe convictions3 years
	 */
	public Short getNumberOfSevereConvictions3Years() {
		return this.numberOfSevereConvictions3Years;
	}

	/**
	 * Sets the number of severe convictions3 years.
	 * 
	 * @param nbrSevereCnvctn3yrs the new number of severe convictions3 years
	 */
	public void setNumberOfSevereConvictions3Years(Short nbrSevereCnvctn3yrs) {
		this.numberOfSevereConvictions3Years = nbrSevereCnvctn3yrs;
	}

	/**
	 * Gets the license suspended or cancelled.
	 * 
	 * @return the license suspended or cancelled
	 */
	public Boolean getLicenseSuspensionOrCancellationIndicator() {
		return this.licenseSuspensionOrCancellationIndicator;
	}

	/**
	 * Sets the license suspended or cancelled.
	 * 
	 * @param licSuspensionOrCncltnIndicator the new license suspended or cancelled
	 */
	public void setLicenseSuspensionOrCancellationIndicator(Boolean licSuspensionOrCncltnIndicator) {
		this.licenseSuspensionOrCancellationIndicator = licSuspensionOrCncltnIndicator;
	}

	/**
	 * Gets the parent insured with company.
	 * 
	 * @return the parent insured with company
	 */
	public Boolean getParentsInsuredWithCompanyIndicator() {
		return this.parentsInsuredWithCompanyIndicator;
	}

	/**
	 * Sets the parent insured with company.
	 * 
	 * @param parentsInsrdWithCompanyIndicator the new parent insured with company
	 */
	public void setParentsInsuredWithCompanyIndicator(Boolean parentsInsrdWithCompanyIndicator) {
		this.parentsInsuredWithCompanyIndicator = parentsInsrdWithCompanyIndicator;
	}

	/**
	 * Gets the convictions.
	 * 
	 * @return the convictions
	 */
	@XmlElementWrapper(name="convictions")
	@XmlElement(name="conviction")
	public Set<Conviction> getConvictions() {
		return this.convictions;
	}

	/**
	 * Sets the convictions.
	 * 
	 * @param aConvictions the new convictions
	 */
	protected void setConvictions(Set<Conviction> aConvictions) {
		this.convictions = aConvictions;
	}

	/**
	 * Adds the conviction.
	 * 
	 * @param conviction the conviction
	 */
	public void addConviction(com.ing.canada.plp.domain.driver.Conviction conviction) {
		AssociationsHelper.updateOneToManyFields(this, "convictions", conviction, "driverComplementInfo");
	}

	/**
	 * Removes the conviction.
	 * 
	 * @param conviction the conviction
	 */
	public void removeConviction(com.ing.canada.plp.domain.driver.Conviction conviction) {
		AssociationsHelper.updateOneToManyFields(null, "convictions", conviction, "driverComplementInfo");
	}

	/**
	 * Clears the convictions collection and detaches them from this DriverComplementInfo (on both side of the
	 * relationship).
	 */
	public void clearConvictions() {
		for (Conviction conviction : new HashSet<Conviction>(this.convictions)) {
			this.removeConviction(conviction);
		}
	}

	/**
	 * Gets the driver license classes.
	 * 
	 * @return the driver license classes
	 */
	@XmlElementWrapper(name="driverLicenseClasses")
	@XmlElement(name="driverLicenseClass")
	public Set<DriverLicenseClass> getDriverLicenseClasses() {
		return this.driverLicenseClasses;
	}

	/**
	 * Sets the driver license classes.
	 * 
	 * @param aDriverLicenseClasses the new driver license classes
	 */
	protected void setDriverLicenseClasses(Set<DriverLicenseClass> aDriverLicenseClasses) {
		this.driverLicenseClasses = aDriverLicenseClasses;
	}

	/**
	 * Adds the driver license class.
	 * 
	 * @param driverLicenseClass the driver license class
	 */
	public void addDriverLicenseClass(com.ing.canada.plp.domain.driver.DriverLicenseClass driverLicenseClass) {
		AssociationsHelper.updateOneToManyFields(this, "driverLicenseClasses", driverLicenseClass,
				"driverComplementInfo");
	}

	/**
	 * Removes the driver license class.
	 * 
	 * @param driverLicenseClass the driver license class
	 */
	public void removeDriverLicenseClass(com.ing.canada.plp.domain.driver.DriverLicenseClass driverLicenseClass) {
		AssociationsHelper.updateOneToManyFields(null, "driverLicenseClasses", driverLicenseClass,
				"driverComplementInfo");
	}

	/**
	 * Gets the training terminated since code.
	 * 
	 * @return the trainingTerminatedSinceCode
	 */
	public TrainingTerminatedSinceCodeEnum getTrainingTerminatedSinceCode() {
		return this.trainingTerminatedSinceCode;
	}

	/**
	 * Sets the training terminated since code.
	 * 
	 * @param aTrainingTerminatedSinceCode the trainingTerminatedSinceCode to set
	 */
	public void setTrainingTerminatedSinceCode(TrainingTerminatedSinceCodeEnum aTrainingTerminatedSinceCode) {
		this.trainingTerminatedSinceCode = aTrainingTerminatedSinceCode;
	}

	/**
	 * Gets the original scenario driver complement info.
	 * 
	 * @return the original scenario driver complement info
	 */
	@XmlTransient // reference source
	public DriverComplementInfo getOriginalScenarioDriverComplementInfo() {
		return this.originalScenarioDriverComplementInfo;
	}

	/**
	 * Sets the original scenario party.
	 * 
	 * @param anOriginalScenarioDriverComplementInfo the new original scenario driver complement info
	 */
	public void setOriginalScenarioDriverComplementInfo(DriverComplementInfo anOriginalScenarioDriverComplementInfo) {
		this.originalScenarioDriverComplementInfo = anOriginalScenarioDriverComplementInfo;
	}

	/**
	 * Gets the checks for held full term auto insurance indicator.
	 * 
	 * @return the checks for held full term auto insurance indicator
	 */
	public Boolean getHasHeldFullTermAutoInsuranceIndicator() {
		return this.hasHeldFullTermAutoInsuranceIndicator;
	}

	/**
	 * Sets the checks for held full term auto insurance indicator.
	 * 
	 * @param isHeldFullTermAutoInsuranceIndicator the new checks for held full term auto insurance indicator
	 */
	public void setHasHeldFullTermAutoInsuranceIndicator(Boolean isHeldFullTermAutoInsuranceIndicator) {
		this.hasHeldFullTermAutoInsuranceIndicator = isHeldFullTermAutoInsuranceIndicator;
	}

	/**
	 * Gets the action taken.
	 * 
	 * @return the action taken
	 */
	public ActionTakenCodeEnum getActionTaken() {
		return this.actionTaken;
	}

	/**
	 * Sets the action taken.
	 * 
	 * @param anActionTaken the new action taken
	 */
	public void setActionTaken(ActionTakenCodeEnum anActionTaken) {
		this.actionTaken = anActionTaken;
	}

	/**
	 * @return the relevantClaimIndicator
	 */
	public Boolean getRelevantClaimIndicator() {
		return this.relevantClaimIndicator;
	}

	/**
	 * @param aRelevantClaimIndicator the relevantClaimIndicator to set
	 */
	public void setRelevantClaimIndicator(Boolean aRelevantClaimIndicator) {
		this.relevantClaimIndicator = aRelevantClaimIndicator;
	}

	/**
	 * get the INS_INTER_IN_LAST_PERIOD_IND value
	 * 
	 * @return {@link #insuranceInterruptionInLastPeriodIndicator}
	 */
	public Boolean getInsuranceInterruptionInLastPeriodIndicator() {
		return this.insuranceInterruptionInLastPeriodIndicator;
	}

	/**
	 * set the INS_INTER_IN_LAST_PERIOD_IND value
	 * 
	 * @param aInsuranceInterruptionInLastPeriodIndicator {@link #insuranceInterruptionInLastPeriodIndicator}
	 */
	public void setInsuranceInterruptionInLastPeriodIndicator(Boolean aInsuranceInterruptionInLastPeriodIndicator) {
		this.insuranceInterruptionInLastPeriodIndicator = aInsuranceInterruptionInLastPeriodIndicator;
	}

	/**
	 * @return {@link #gridLevelQty}
	 */
	public Short getGridLevelQty() {
		return this.gridLevelQty;
	}

	/**
	 * @param aGridLevelQty {@link #gridLevelQty}
	 */
	public void setGridLevelQty(Short aGridLevelQty) {
		this.gridLevelQty = aGridLevelQty;
	}

	/**
	 * @return {@link #gridLevelDate}
	 */
	public Date getGridLevelDate() {
		return this.gridLevelDate;
	}

	/**
	 * @param aGridLevelDate {@link #gridLevelDate}
	 */
	public void setGridLevelDate(Date aGridLevelDate) {
		this.gridLevelDate = aGridLevelDate;
	}

	/**
	 * @return {@link #priorGridLevelQty}
	 */
	public Short getPriorGridLevelQty() {
		return this.priorGridLevelQty;
	}

	/**
	 * @param aPriorGridLevelQty {@link #priorGridLevelQty}
	 */
	public void setPriorGridLevelQty(Short aPriorGridLevelQty) {
		this.priorGridLevelQty = aPriorGridLevelQty;
	}

	/**
	 * get the priorGridLevelClient
	 * 
	 * @return {@link #priorGridLevelClient}
	 */
	public PriorGridLevelClientCodeEnum getPriorGridLevelClient() {
		return this.priorGridLevelClient;
	}

	/**
	 * set the priorGridLevelClient
	 * 
	 * @param aPriorGridLevelClient
	 */
	public void setPriorGridLevelClient(PriorGridLevelClientCodeEnum aPriorGridLevelClient) {
		this.priorGridLevelClient = aPriorGridLevelClient;
	}

	/**
	 * @return the drivingWeekendOnlyIndicator
	 */
	public Boolean getDrivingWeekendOnlyIndicator() {
		return this.drivingWeekendOnlyIndicator;
	}

	/**
	 * @param aDrivingWeekendOnlyIndicator the drivingWeekendOnlyIndicator to set
	 */
	public void setDrivingWeekendOnlyIndicator(Boolean aDrivingWeekendOnlyIndicator) {
		this.drivingWeekendOnlyIndicator = aDrivingWeekendOnlyIndicator;
	}

	/**
	 * Clears the driver License class collection and detaches them from this DriverComplementInfo (on both side of the
	 * relationship).
	 */
	public void clearDriverLicenseClass() {

		Set<DriverLicenseClass> temp = new HashSet<DriverLicenseClass>(this.driverLicenseClasses);

		for (DriverLicenseClass driverLicenseClass : temp) {
			this.removeDriverLicenseClass(driverLicenseClass);
		}
	}

	/**
	 * Gets the continuously insured since date.
	 * 
	 * @return the continuously insured since date
	 */
	public Date getContinuouslyInsuredSinceDate() {
		return this.continuouslyInsuredSinceDate;
	}

	/**
	 * Sets the continuously insured since date.
	 * 
	 * @param continuouslyInsuredSinceDate the new continuously insured since date
	 */
	public void setContinuouslyInsuredSinceDate(Date continuouslyInsuredSinceDate) {
		this.continuouslyInsuredSinceDate = continuouslyInsuredSinceDate;
	}

	/**
	 * get the UBI_STATUS_CD value
	 * 
	 * @return {@link #UBIStatusCode}
	 */
	public UBIStatusCodeEnum getUBIStatusCode() {
		return this.UBIStatusCode;
	}

	/**
	 * set the INTERESTED_BY_UBI_IND value
	 * 
	 * @param aUBIStatusCode {@link #UBIStatusCode}
	 */
	public void setUBIStatusCode(UBIStatusCodeEnum aUBIStatusCode) {
		this.UBIStatusCode = aUBIStatusCode;
	}

	/**
	 * get the INTERESTED_BY_UBI_IND value
	 * 
	 * @return {@link #interestedByUBIIndicator}
	 */
	public Boolean getInterestedByUBIIndicator() {
		return this.interestedByUBIIndicator;
	}

	/**
	 * set the INTERESTED_BY_UBI_IND value
	 * 
	 * @param aInterestedByUBIIndicator {@link #interestedByUBIIndicator}
	 */
	public void setInterestedByUBIIndicator(Boolean aInterestedByUBIIndicator) {
		this.interestedByUBIIndicator = aInterestedByUBIIndicator;
	}

	/**
	 * @return the resideWithNamedInsdIndicator
	 */
	public Boolean getResideWithNamedInsdIndicator() {
		return this.resideWithNamedInsdIndicator;
	}

	/**
	 * @param resideWithNamedInsdIndicator the resideWithNamedInsdIndicator to set
	 */
	public void setResideWithNamedInsdIndicator(final Boolean resideWithNamedInsdIndicator) {
		this.resideWithNamedInsdIndicator = resideWithNamedInsdIndicator;
	}

	public Byte getNumberOfConvictions5Years() {
		return this.numberOfConvictions5Years;
	}

	public void setNumberOfConvictions5Years(final Byte numberOfConvictions5Years) {
		this.numberOfConvictions5Years = numberOfConvictions5Years;
	}

	public Byte getNumberOfPenaltyPoints5Years() {
		return this.numberOfPenaltyPoints5Years;
	}

	public void setNumberOfPenaltyPoints5Years(final Byte numberOfPenaltyPoints5Years) {
		this.numberOfPenaltyPoints5Years = numberOfPenaltyPoints5Years;
	}

	public Short getUBIDiscountSystemPct() {
		return this.UBIDiscountSystemPct;
	}

	public void setUBIDiscountSystemPct(Short uBIDiscountSystemPct) {
		this.UBIDiscountSystemPct = uBIDiscountSystemPct;
	}

	public Short getUBIDiscountModifiedPct() {
		return this.UBIDiscountModifiedPct;
	}

	public void setUBIDiscountModifiedPct(Short uBIDiscountModifiedPct) {
		this.UBIDiscountModifiedPct = uBIDiscountModifiedPct;
	}

	public Short getUBIDiscountPercentage() {
		return this.UBIDiscountPercentage;
	}

	public void setUBIDiscountPercentage(Short uBIDiscountPercentage) {
		this.UBIDiscountPercentage = uBIDiscountPercentage;
	}

	public UBIDiscountCriteriaEnum getUbiDiscountCriteriaCode() {
		return this.UBIDiscountCriteriaCode;
	}

	public void setUbiDiscountCriteriaCode(UBIDiscountCriteriaEnum ubiDiscountCriteriaCode) {
		this.UBIDiscountCriteriaCode = ubiDiscountCriteriaCode;
	}
}
