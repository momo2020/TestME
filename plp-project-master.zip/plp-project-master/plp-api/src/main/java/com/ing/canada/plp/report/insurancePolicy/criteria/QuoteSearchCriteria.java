package com.ing.canada.plp.report.insurancePolicy.criteria;

import java.io.Serializable;
import java.util.Date;

/**
 * Quote Search Criteria class.
 * 
 * @author devs
 *
 */
public class QuoteSearchCriteria implements Serializable {

	private static final long serialVersionUID = 7127790293555202224L;

	private String agreementNumber;

	private boolean agreementLegacyNumber;

	private String postalCode;

	private String phoneNumberPrefix;

	private String phoneNumberSuffix;

	private String phoneAreaCode;

	private String lastName;

	private String firstName;

	private String businessName;

	private String email;

	private Date from;

	private Date to;

	private String selectedMaster;

	private String selectedDefaultMaster;

	private String selectedPointOfSale;

	private String selectedClientFollowUp;

	private String selectedQuoteStatus;

	private String selectedQuoteSource;

	private String userId;

	private Date creationDateFrom;

	private Date creationDateTo;

	private boolean closedBrokerQuotes = false;
	
	private boolean newBrokerQuotes = false;
	
	private String lineOfBusiness;

	private boolean inactivePOSOnly = false;
	
	/**
	 * Gets the agreement number
	 * 
	 * @return String
	 */
	public String getAgreementNumber() {
		return this.agreementNumber;
	}

	/**
	 * Sets the agreement number
	 * 
	 * @param anAgreementNumber the agreementNumber to set
	 */
	public void setAgreementNumber(String anAgreementNumber) {
		this.agreementNumber = anAgreementNumber;
	}

	/**
	 * Gets the email return String
	 * @return {@link #email}
	 */
	public String getEmail() {
		return this.email;
	}

	/**
	 * Sets the email
	 * 
	 * @param anEmail the email to set
	 */
	public void setEmail(String anEmail) {
		this.email = anEmail;
	}

	/**
	 * Gets the first name
	 * 
	 * @return String
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 * Sets the first name
	 * 
	 * @param aFirstName the firstName to set
	 */
	public void setFirstName(String aFirstName) {
		this.firstName = aFirstName;
	}

	/**
	 * Gets the Last update from
	 * 
	 * @return Date
	 */
	public Date getFrom() {
		return this.from;
	}

	/**
	 * Sets the Last update from
	 * 
	 * @param aFrom the from to set
	 */
	public void setFrom(Date aFrom) {
		this.from = aFrom;
	}

	/**
	 * Gets the last name
	 * 
	 * @return String
	 */
	public String getLastName() {
		return this.lastName;
	}

	/**
	 * Sets the last name
	 * 
	 * @param aLastName the lastName to set
	 */
	public void setLastName(String aLastName) {
		this.lastName = aLastName;
	}

	/**
	 * Gets the business name
	 * 
	 * @return String
	 */
	public String getBusinessName() {
		return this.businessName;
	}

	/**
	 * Sets the business name
	 * 
	 * @param aBusinessName the businessName to set
	 */
	public void setBusinessName(String aBusinessName) {
		this.businessName = aBusinessName;
	}

	/**
	 * Gets the postal code
	 * 
	 * @return String
	 */
	public String getPostalCode() {
		return this.postalCode;
	}

	/**
	 * Sets the postal code
	 * 
	 * @param aPostalCode the postalCode to set
	 */
	public void setPostalCode(String aPostalCode) {
		this.postalCode = aPostalCode;
	}

	/**
	 * Gets the selected client follow-up
	 * 
	 * @return String
	 */
	public String getSelectedClientFollowUp() {
		return this.selectedClientFollowUp;
	}

	/**
	 * Sets the selected client follow-up
	 * 
	 * @param aSelectedClientFollowUp the new selected client followUp to set
	 */
	public void setSelectedClientFollowUp(String aSelectedClientFollowUp) {
		this.selectedClientFollowUp = aSelectedClientFollowUp;
	}

	/**
	 * Gets the selected Quoted Status
	 * 
	 * @return String
	 */
	public String getSelectedQuoteStatus() {
		return this.selectedQuoteStatus;
	}

	/**
	 * Sets the selected Quoted Status
	 * 
	 * @param aSelectedQuoteStatus the selectedQuoteStatus to set
	 */
	public void setSelectedQuoteStatus(String aSelectedQuoteStatus) {
		this.selectedQuoteStatus = aSelectedQuoteStatus;
	}

	/**
	 * Gets the telephone
	 * 
	 * @return String
	 */
	public String getTelephone() {
		return (this.getPhoneAreaCode() != null ? this.getPhoneAreaCode() : "")
				.concat((this.getPhoneNumberPrefix() != null ? this.getPhoneNumberPrefix() : "")).concat(
						(this.getPhoneNumberSuffix() != null ? this.getPhoneNumberSuffix() : ""));
	}

	/**
	 * @return {@link #phoneNumberPrefix}
	 */
	public String getPhoneNumberPrefix() {
		return this.phoneNumberPrefix;
	}

	/**
	 * @param phoneNumberPrefix {@link #phoneNumberPrefix}
	 */
	public void setPhoneNumberPrefix(String phoneNumberPrefix) {
		this.phoneNumberPrefix = phoneNumberPrefix;
	}

	/**
	 * @return {@link #phoneNumberSuffix}
	 */
	public String getPhoneNumberSuffix() {
		return this.phoneNumberSuffix;
	}

	/**
	 * @param phoneNumberSuffix
	 */
	public void setPhoneNumberSuffix(String phoneNumberSuffix) {
		this.phoneNumberSuffix = phoneNumberSuffix;
	}

	/**
	 * @return {@link #phoneAreaCode}
	 */
	public String getPhoneAreaCode() {
		return this.phoneAreaCode;
	}

	/**
	 * @param phoneAreaCode {@link #phoneAreaCode}
	 */
	public void setPhoneAreaCode(String phoneAreaCode) {
		this.phoneAreaCode = phoneAreaCode;
	}

	/**
	 * Gets the last update to.
	 * 
	 * @return Date 
	 */
	public Date getTo() {
		return this.to;
	}

	/**
	 * Sets the last update to
	 * 
	 * @param aTo the to to set
	 */
	public void setTo(Date aTo) {
		this.to = aTo;
	}

	/**
	 * @return {@link #agreementLegacyNumber}
	 */
	public boolean isAgreementLegacyNumber() {
		return this.agreementLegacyNumber;
	}

	/**
	 * @param anAgreementLegacyNumber {@link #agreementLegacyNumber}
	 */
	public void setAgreementLegacyNumber(boolean anAgreementLegacyNumber) {
		this.agreementLegacyNumber = anAgreementLegacyNumber;
	}

	/**
	 * Gets the selected Master
	 * 
	 * @return String
	 */
	public String getSelectedMaster() {
		return this.selectedMaster;
	}

	/**
	 * Sets the selected Master
	 * 
	 * @param aSelectedMaster the selectedMaster to set
	 */
	public void setSelectedMaster(String aSelectedMaster) {
		this.selectedMaster = aSelectedMaster;
	}

	/**
	 * @return {@link #selectedDefaultMaster}
	 */
	public String getSelectedDefaultMaster() {
		return this.selectedDefaultMaster;
	}

	/**
	 * @param selectedDefaultMaster {@link #selectedDefaultMaster}
	 */
	public void setSelectedDefaultMaster(String selectedDefaultMaster) {
		this.selectedDefaultMaster = selectedDefaultMaster;
	}

	/**
	 * Gets the selected Point Of Sale
	 * 
	 * @return {@link #selectedPointOfSale}
	 */
	public String getSelectedPointOfSale() {
		return this.selectedPointOfSale;
	}

	/**
	 * Sets the selected Point Of Sale
	 * 
	 * @param aSelectedPointOfSale the selectedPointOfSale
	 */
	public void setSelectedPointOfSale(String aSelectedPointOfSale) {
		this.selectedPointOfSale = aSelectedPointOfSale;
	}

	/**
	 * Gets the selected quote source
	 * 
	 * @return the selected quote source
	 */
	public String getSelectedQuoteSource() {
		return this.selectedQuoteSource;
	}

	/**
	 * Sets the selected quote source
	 * 
	 * @param selectedQuoteOrigin the selected quote source to set
	 */
	public void setSelectedQuoteSource(String selectedQuoteSource) {
		this.selectedQuoteSource = selectedQuoteSource;
	}

	/**
	 * Gets the user account id
	 * 
	 * @return the user account id
	 */
	public String getUserId() {
		return this.userId;
	}

	/**
	 * Sets the user account id
	 * 
	 * @param aUserId the the user account id to set
	 */
	public void setUserId(String aUserId) {
		this.userId = aUserId;
	}

	/**
	 * Gets the creation date from
	 * 
	 * @return {@link #creationDateFrom}
	 */
	public Date getCreationDateFrom() {
		return this.creationDateFrom;
	}

	/**
	 * Sets the creation date from
	 * 
	 * @param aFrom the {@link #creationDateFrom} to set
	 */
	public void setCreationDateFrom(Date aFrom) {
		this.creationDateFrom = aFrom;
	}

	/**
	 * Gets the creation date to
	 * 
	 * @return Date {@link #creationDateTo}
	 */
	public Date getCreationDateTo() {
		return this.creationDateTo;
	}

	/**
	 * Sets the creation date to
	 * 
	 * @param aTo the {@link #creationDateTo} to set
	 */
	public void setCreationDateTo(Date aTo) {
		this.creationDateTo = aTo;
	}

	/**
	 * @return {@link #closedBrokerQuotes}
	 */
	public boolean isClosedBrokerQuotes() {
		return this.closedBrokerQuotes;
	}

	/**
	 * @param closedBrokerQuotes {@link #closedBrokerQuotes}
	 */
	public void setClosedBrokerQuotes(boolean closedBrokerQuotes) {
		this.closedBrokerQuotes = closedBrokerQuotes;
	}	
	
	/**
	 * @return {@link #newBrokerQuotes}
	 */
	public boolean isNewBrokerQuotes() {
		return newBrokerQuotes;
	}

	/**
	 * @param newBrokerQuotes {@link #newBrokerQuotes}
	 */	
	public void setNewBrokerQuotes(boolean newBrokerQuotes) {
		this.newBrokerQuotes = newBrokerQuotes;
	}
	
	/**
	 * @return {@link #lineOfBusiness}
	 */
	public String getLineOfBusiness() {
		return lineOfBusiness;
	}
	
	/**
	 * @param lineOfBusiness The line(s) of business
	 */
	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}
	
	/**
	 * Gets the inactive POS only flag
	 * 
	 * @return boolean {@link #inactivePOSOnly}
	 */
	public boolean isInactivePOSOnly() {
		return inactivePOSOnly;
	}

	/**
	 * Sets the inactive POS only flag
	 * 
	 * @param The {@link #inactivePOSOnly} to set
	 */
	public void setInactivePOSOnly(boolean inactivePOSOnly) {
		this.inactivePOSOnly = inactivePOSOnly;
	}

	@Override
	public String toString() {
		return new StringBuilder("[agreement number=").append(getAgreementNumber())
					    .append(", email=").append(getEmail())
					    .append(", first name=").append(getFirstName())
					    .append(", from=").append(getFrom())
					    .append(", last name=").append(getLastName())
					    .append(", postal code=").append(getPostalCode())
					    .append(", client follow up=").append(getSelectedClientFollowUp())
					    .append(", quote status=").append(getSelectedQuoteStatus())
					    .append(", telephone=").append(getTelephone())
					    .append(", phone number prefix=").append(getPhoneNumberPrefix())
					    .append(", phone number suffix=").append(getPhoneNumberSuffix())
					    .append(", phone area code=").append(getPhoneAreaCode())
					    .append(", to=").append(getTo())
					    .append(", agreement legacy number=").append(isAgreementLegacyNumber())
					    .append(", selected master=").append(getSelectedMaster())
					    .append(", default master=").append(getSelectedDefaultMaster())
					    .append(", point of sale=").append(getSelectedPointOfSale())
					    .append(", quote origin=").append(getSelectedQuoteSource())
					    .append(", user=").append(getUserId())
					    .append(", creation date from=").append(getCreationDateFrom())
					    .append(", creation to date=").append(getCreationDateTo())
					    .append(", closed quotes=").append(isClosedBrokerQuotes())
					    .append(", new quotes=").append(isNewBrokerQuotes())
					    .append(", business name (unstructured name)=").append(getBusinessName())
					    .append(", line(s) of business=").append(getLineOfBusiness())
					    .append(", inactive POS only=").append(isInactivePOSOnly())
					    .append("]").toString();
	}

}
