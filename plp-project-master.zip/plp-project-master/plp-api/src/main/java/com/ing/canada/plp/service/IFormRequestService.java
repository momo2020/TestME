package com.ing.canada.plp.service;

import java.util.Date;
import java.util.List;

import com.ing.canada.plp.domain.formprocess.FormRequest;

public interface IFormRequestService extends ICRUDService<FormRequest>  {
	public List<String[]>  getForm(String formName, String[] orderedFieldList,Date startDate, Date endDate);
}
