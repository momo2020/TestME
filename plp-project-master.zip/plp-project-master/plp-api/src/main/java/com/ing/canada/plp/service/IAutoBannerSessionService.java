/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.autobannersession.AutoBannerSession;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;


/**
 * This interface exposes services required to manage AutoBannerSessionId
 * @author xpham
 *
 */
public interface IAutoBannerSessionService extends ICRUDService<AutoBannerSession> {

	public static final String BEAN_NAME = "autoBannerSessionService";
	
	/**
	 * @param policyVersion
	 */
	AutoBannerSession pushAutoBannerSessionId();
	
	/**
	 * @param autoBannerSession
	 * @param policyVersion
	 */
	void pushAutoPolicyVersionId(String autoBannerSessionId, PolicyVersion policyVersion) throws IllegalArgumentException;
	
	/**
	 * @param autoBannerSession
	 * @throws IllegalArgumentException
	 */
	void destroyAutoBannerSession(AutoBannerSession autoBannerSession) throws IllegalArgumentException;
	
}
