/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum UseOfVehicleCodeEnum.
 */
public enum UseOfVehicleCodeEnum {

	PLEASURE("P"), 
	PLEASURE_AND_BUSINESS_INCLUDING_DELIVERY("D"), 
	PLEASURE_AND_BUSINESS_INCLUDING_MEAL_DELIVERY("M"), 
	BUSINESS_OR_PLEASURE_AND_BUSINESS_EXCLUDING_DELIVERY("E"), 
	BUSINESS("B"), 
	RECREATIONAL("R"), 
	NON_COMMERCIAL_TRAILER("T"), 
	FARMING("F"), 
	FARMING_AND_BUSINESS("G"), 
	CLERGY("V"), 
	OTHER("O"), 
	COMMUTING("W"), 
	DRIVING_SCHOOL("H"), 
	OFF_ROAD_MOTORCYCLE("J"), 
	TOURING_MOTORCYCLE("U");

	/**
	 * Instantiates a new use of vehicle code enum.
	 * 
	 * @param aCode the a code
	 */
	private UseOfVehicleCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the use of vehicle code enum
	 */
	public static UseOfVehicleCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (UseOfVehicleCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
