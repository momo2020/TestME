/**
< * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.party;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.driver.DriverComplementInfo;
import com.ing.canada.plp.domain.enums.ActionTakenCodeEnum;
import com.ing.canada.plp.domain.enums.AddressTypeCodeEnum;
import com.ing.canada.plp.domain.enums.ClientEligibilityLevelCodeEnum;
import com.ing.canada.plp.domain.enums.LanguageCodeEnum;
import com.ing.canada.plp.domain.enums.MaritalStatusCodeEnum;
import com.ing.canada.plp.domain.enums.PartyGroupTypeCodeEnum;
import com.ing.canada.plp.domain.enums.PartyStudentGrade;
import com.ing.canada.plp.domain.enums.PartyTypeCodeEnum;
import com.ing.canada.plp.domain.enums.PolicyHolderTypeCodeEnum;
import com.ing.canada.plp.domain.enums.SexCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.AdditionalInterestRole;
import com.ing.canada.plp.domain.insurancerisk.Claim;
import com.ing.canada.plp.domain.policyversion.PolicyHolder;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;
import com.ing.canada.plp.domain.policyversion.PriorCarrierPolicyInfo;
import com.ing.canada.plp.domain.usertype.BaseEntity;
import com.ing.canada.plp.roadblock.Roadblockable;

/**
 * Party entity.
 *
 * @author Patrick Lafleur
 *
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "PARTY", uniqueConstraints = {})
public class Party extends BaseEntity implements Roadblockable {

	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(Party.class);

	/** The id. */
	@Id
	@Column(name = "PARTY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "PartySequence")
	@SequenceGenerator(name = "PartySequence", sequenceName = "PARTY_SEQ", allocationSize = 5)
	private Long id;

	/** The policy version. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "POLICY_VERSION_ID", nullable = false, updatable = true)
	protected PolicyVersion policyVersion;

	/** The party type. */
	@Column(name = "PARTY_TYPE_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PartyTypeCodeEnum") })
	private PartyTypeCodeEnum partyType;

	/** The language of communication. */
	@Column(name = "LANGUAGE_OF_COMMUNICATION_CD", length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.LanguageCodeEnum") })
	private LanguageCodeEnum languageOfCommunication;

	/** The date of last move. */
	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_MOVE_DT", length = 7)
	private Date dateOfLastMove;

	/** The holder of diploma from canadian university. */
	@Column(name = "HOLDER_DIPLOMA_CDN_UNVRSTY_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean holderOfDiplomaFromCanadianUniversity;

	/** The currently studying in canadian college or university. */
	@Column(name = "CUR_STDY_CDN_COLLG_UNVRSTY_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean currentlyStudyingInCanadianCollegeOrUniversity;

	/** The name ofuniversity or college currently studying. */
	@Column(name = "UNVRSTY_COLLEGE_CUR_STUDY_TXT", length = 50)
	private String universityOrCollegeCurrentlyStudying;

	/** The student number. */
	@Column(name = "STUDENT_NBR", length = 20)
	private String studentNumber;

	/** The social insurance number. */
	@Column(name = "SOCIAL_INSURANCE_NBR", length = 64)
	@Type(type = "com.ing.canada.plp.dao.mapping.EncryptedUserType")
	private String socialInsuranceNumber;

	/** The sex. */
	@Column(name = "SEX_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.SexCodeEnum") })
	private SexCodeEnum sex;

	/** The marital status. */
	@Column(name = "MARITAL_STATUS_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.MaritalStatusCodeEnum") })
	private MaritalStatusCodeEnum maritalStatus;

	/** The birth date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "BIRTH_DT", length = 7)
	private Date birthDate;

	/** The disability description. */
	@Column(name = "DISABILITY_DESC", length = 40)
	private String disabilityDescription;

	/** The disability date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "DISABILITY_DT", length = 7)
	private Date disabilityDate;

	/** The retired indicator. */
	@Column(name = "RETIRED_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean retiredIndicator;

	/** The first name. */
	@Column(name = "FIRST_NAME_TXT", length = 32)
	private String firstName;

	/** The last name. */
	@Column(name = "LAST_NAME_TXT", length = 32)
	private String lastName;

	/** The middle name. */
	@Column(name = "MIDDLE_NAME_TXT", length = 32)
	private String middleName;

	/** The suffix name. */
	@Column(name = "SUFFIX_NAME_TXT", length = 2)
	private String suffixName;

	/** The unstructured name. */
	@Column(name = "UNSTRUCTURED_NAME_TXT", length = 120)
	private String unstructuredName;

	/** The client eligibility level. */
	@Column(name = "CLIENT_ELIGIBILITY_LEVEL_CD", length = 15)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ClientEligibilityLevelCodeEnum") })
	private ClientEligibilityLevelCodeEnum clientEligibilityLevel;

	/** The credit score client eligibility indicator. */
	@Column(name = "CREDIT_SCR_CLIENT_ELGBLTY_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean creditScoreClientEligibilityIndicator;

	/** The additional interest sequence. */
	@Column(name = "ADDITIONAL_INTEREST_SEQ", precision = 4, scale = 0)
	private Short additionalInterestSequence;

	/** The ing staff indicator. */
	@Column(name = "ING_STAFF_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean ingStaffIndicator;

	/** The employee number. */
	@Column(name = "EMPLOYEE_NBR", length = 8)
	private String employeeNumber;

	/** The cif client id. */
	@Column(name = "CIF_CLIENT_ID", precision = 12, scale = 0)
	private Long cifClientId;

	/** The occupation code. */
	@Column(name = "OCCUPATION_CD", length = 3)
	private String occupationCode;

	/** The email. */
	@Column(name = "EMAIL_ADDRESS_TXT", length = 79)
	private String emailAddress;

	/**
	 * The criminal record indicator
	 */
	@Column(name = "CRIMINAL_RECORD_IND")
	@Type(type = "yes_no")
	private Boolean criminalRecordIndicator;

	/** The consents. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "party", orphanRemoval=true)
	@OrderBy("id ASC")
	private Set<Consent> consents = new HashSet<Consent>(0);

	/** The claims. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "party", orphanRemoval=true)
	@OrderBy("claimOrdering ASC")
	private Set<Claim> claims = new HashSet<Claim>(0);

	/** The additional interest roles. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "party")
	private Set<AdditionalInterestRole> additionalInterestRoles = new HashSet<AdditionalInterestRole>(0);

	/** The party groups. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "party", orphanRemoval=true)
	private Set<PartyGroup> partyGroups = new HashSet<PartyGroup>(0);

	/** The credit scores. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "party")
	private Set<CreditScore> creditScores = new HashSet<CreditScore>(0);

	/** The party role in risks. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "party")
	private Set<PartyRoleInRisk> partyRoleInRisks = new HashSet<PartyRoleInRisk>(0);

	/** The addresses. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "party")
	private Set<Address> addresses = new HashSet<Address>(0);

	/** The driver complement info. */
	@OneToOne(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER, mappedBy = "party")
	@Fetch(FetchMode.JOIN)
	private DriverComplementInfo driverComplementInfo = null;

	/** The phones. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "party")
	private Set<Phone> phones = new HashSet<Phone>(0);

	/** The policy holders. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "party")
	private Set<PolicyHolder> policyHolders = new HashSet<PolicyHolder>(0);

	/** The original scenario party. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_PARTY_ID", insertable = false, updatable = false)
	private Party originalScenarioParty;

	/** The action taken. */
	@Column(name = "ACTION_TAKEN_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ActionTakenCodeEnum") })
	private ActionTakenCodeEnum actionTaken = null;

	/** The road block indicator. */
	@Column(name = "ROAD_BLOCK_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean roadBlockIndicator;

	/** The prior carrier policy infos. */
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "PRIOR_CARRIER_POLICY_INFO_ID")
	private PriorCarrierPolicyInfo priorCarrierPolicyInfo;

	/** The Student grade. */
	@Column(name = "STUDENT_GRADE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PartyStudentGrade") })
	private PartyStudentGrade studentGrade;

	/** The Residence Occupancy */
	@Column(name = "RESIDENCE_OCCUPANCY_CD", length = 2)
	private String residenceOccupancy;

	/** Already insured in Canada indicator. */
	@Column(name = "ALREADY_INSURED_IN_CANADA_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean alreadyInsuredInCanadaInd;

	/** The outstanding premium owed to any insurer indicator. */
	@Column(name = "OUTSTD_PRM_OWED_TO_ANY_INS_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean outstandingPremiumInd;

	/** The additional interest sequence. */
	@Column(name = "AGE_FIRST_INSRD_AUTO_IN_CA_QTY", precision = 3, scale = 0)
	private Short ageFirstInsured;

	/** The national bank client indicator. */
	@Column(name = "NATIONAL_BANK_CLIENT_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean nationalBankClientInd;
	
	/** The web Msg Id. */
	@Column(name = "WEB_MSG_ID", precision = 3)
	private Integer webMsgId;

	/** (4.1.8) Number of payments with insufficient funds the client made with Intact since insured with the company. */
	@Column(name = "NBR_OF_INSUF_FUNDS_TO_DATE_QTY", precision = 3)
	private Integer numberOfInsufficientFundsToDate;
	
	/** The party relation to. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "partyTo", orphanRemoval=true)
	private Set<PartyRelation> partyRelationTo = new HashSet<PartyRelation>(0);
	
	/** The party relation from. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "partyFrom", orphanRemoval=true)
	private Set<PartyRelation> partyRelationFrom = new HashSet<PartyRelation>(0);

	@Transient
	private Map<AddressTypeCodeEnum, Address> addressTypes = null;

	@Transient
	private Map<PartyGroupTypeCodeEnum, GroupRepositoryEntry> groupTypes = null;

	@Transient
	private Map<PolicyHolderTypeCodeEnum, PolicyHolder> holderTypes = null;

	/**
	 * Instantiates a new party.
	 */
	public Party() {
		// no arg constructor
	}

	/**
	 * @return {@link #residenceOccupancy}
	 */
	public String getResidenceOccupancy() {
		return this.residenceOccupancy;
	}

	/**
	 * @param residenceOccupancy {@link #residenceOccupancy}
	 */
	public void setResidenceOccupancy(String residenceOccupancy) {
		this.residenceOccupancy = residenceOccupancy;
	}

	/**
	 * Instantiates a new party.
	 *
	 * @param aPolicyVersion the a policy version
	 */
	public Party(final PolicyVersion aPolicyVersion) {
		this.setPolicyVersion(aPolicyVersion);
	}

	@Override
	public void markAsRoadblocked() {
		this.setRoadBlockIndicator(Boolean.TRUE);
	}

	@Override
	public void clearRoadblock() {
		this.setRoadBlockIndicator(null);
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 *
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param aId the a id
	 *
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(final Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the policy version.
	 *
	 * @return the policy version
	 */
	@XmlTransient
	// parent
	public PolicyVersion getPolicyVersion() {
		return this.policyVersion;
	}

	/**
	 * Sets the policy version.
	 *
	 * @param aPolicyVersion1 the new policy version
	 */
	public void setPolicyVersion(final PolicyVersion aPolicyVersion1) {
		AssociationsHelper.updateOneToManyFields(aPolicyVersion1, "parties", this, "policyVersion");
	}

	/**
	 * Gets the party type.
	 *
	 * @return the party type
	 */
	public PartyTypeCodeEnum getPartyType() {
		return this.partyType;
	}

	/**
	 * Sets the party type.
	 *
	 * @param partyTypeCode the new party type
	 */
	public void setPartyType(final PartyTypeCodeEnum partyTypeCode) {
		this.partyType = partyTypeCode;
	}

	/**
	 * Gets the language of communication.
	 *
	 * @return the language of communication
	 */
	public LanguageCodeEnum getLanguageOfCommunication() {
		return this.languageOfCommunication;
	}

	/**
	 * Sets the language of communication code.
	 *
	 * @param languageOfCommunicationCode the new language of communication code
	 */
	public void setLanguageOfCommunication(final LanguageCodeEnum languageOfCommunicationCode) {
		this.languageOfCommunication = languageOfCommunicationCode;
	}

	/**
	 * Gets the date of last move.
	 *
	 * @return the date of last move
	 */
	public Date getDateOfLastMove() {
		return this.dateOfLastMove;
	}

	/**
	 * Sets the date of last move.
	 *
	 * @param lastMoveDate the new date of last move
	 */
	public void setDateOfLastMove(final Date lastMoveDate) {
		this.dateOfLastMove = lastMoveDate;
	}

	/**
	 * Gets the holder of diploma from canadian university.
	 *
	 * @return the holder of diploma from canadian university
	 */
	public Boolean getHolderOfDiplomaFromCanadianUniversity() {
		return this.holderOfDiplomaFromCanadianUniversity;
	}

	/**
	 * Sets the holder of diploma from canadian university.
	 *
	 * @param holderDiplomaCdnUnvrstyIndicator the new holder of diploma from canadian university
	 */
	public void setHolderOfDiplomaFromCanadianUniversity(final Boolean holderDiplomaCdnUnvrstyIndicator) {
		this.holderOfDiplomaFromCanadianUniversity = holderDiplomaCdnUnvrstyIndicator;
	}

	/**
	 * Gets the currently studying in canadian college or university.
	 *
	 * @return the currently studying in canadian college or university
	 */
	public Boolean getCurrentlyStudyingInCanadianCollegeOrUniversity() {
		return this.currentlyStudyingInCanadianCollegeOrUniversity;
	}

	/**
	 * Sets the currently studying in canadian college or university.
	 *
	 * @param curStdyCdnCollgUnvrstyIndicator the new currently studying in canadian college or university
	 */
	public void setCurrentlyStudyingInCanadianCollegeOrUniversity(final Boolean curStdyCdnCollgUnvrstyIndicator) {
		this.currentlyStudyingInCanadianCollegeOrUniversity = curStdyCdnCollgUnvrstyIndicator;
	}

	/**
	 * Gets the name ofuniversity or college currently studying.
	 *
	 * @return the name ofuniversity or college currently studying
	 */
	public String getUniversityOrCollegeCurrentlyStudying() {
		return this.universityOrCollegeCurrentlyStudying;
	}

	/**
	 * Sets the name ofuniversity or college currently studying.
	 *
	 * @param unvrstyCollegeCurStudy the new name ofuniversity or college currently studying
	 */
	public void setUniversityOrCollegeCurrentlyStudying(final String unvrstyCollegeCurStudy) {
		this.universityOrCollegeCurrentlyStudying = unvrstyCollegeCurStudy;
	}

	/**
	 * Gets the student number.
	 *
	 * @return the student number
	 */
	public String getStudentNumber() {
		return this.studentNumber;
	}

	/**
	 * Sets the student number.
	 *
	 * @param aStudentNumber the new student number
	 */
	public void setStudentNumber(final String aStudentNumber) {
		this.studentNumber = aStudentNumber;
	}

	/**
	 * Gets the social insurance number.
	 *
	 * @return the social insurance number
	 */
	public String getSocialInsuranceNumber() {
		return this.socialInsuranceNumber;
	}

	/**
	 * Sets the social insurance number.
	 *
	 * @param aSocialInsuranceNumber the new social insurance number
	 */
	public void setSocialInsuranceNumber(final String aSocialInsuranceNumber) {
		this.socialInsuranceNumber = aSocialInsuranceNumber;
	}

	/**
	 * Gets the sex.
	 *
	 * @return the sex
	 */
	public SexCodeEnum getSex() {
		return this.sex;
	}

	/**
	 * Sets the sex.
	 *
	 * @param sexCode the new sex
	 */
	public void setSex(final SexCodeEnum sexCode) {
		this.sex = sexCode;
	}

	/**
	 * Gets the marital status.
	 *
	 * @return the marital status
	 */
	public MaritalStatusCodeEnum getMaritalStatus() {
		return this.maritalStatus;
	}

	/**
	 * Sets the marital status.
	 *
	 * @param maritalStatusCode the new marital status
	 */
	public void setMaritalStatus(final MaritalStatusCodeEnum maritalStatusCode) {
		this.maritalStatus = maritalStatusCode;
	}

	/**
	 * Gets the birth date.
	 *
	 * @return the birth date
	 */
	public Date getBirthDate() {
		return this.birthDate;
	}

	/**
	 * Sets the birth date.
	 *
	 * @param aBirthDate the new birth date
	 */
	public void setBirthDate(final Date aBirthDate) {
		this.birthDate = aBirthDate;
	}

	/**
	 * Gets the disability description.
	 *
	 * @return the disability description
	 */
	public String getDisabilityDescription() {
		return this.disabilityDescription;
	}

	/**
	 * Sets the disability description.
	 *
	 * @param disabilityDesc the new disability description
	 */
	public void setDisabilityDescription(final String disabilityDesc) {
		this.disabilityDescription = disabilityDesc;
	}

	/**
	 * Gets the disability date.
	 *
	 * @return the disability date
	 */
	public Date getDisabilityDate() {
		return this.disabilityDate;
	}

	/**
	 * Sets the disability date.
	 *
	 * @param aDisabilityDate the new disability date
	 */
	public void setDisabilityDate(final Date aDisabilityDate) {
		this.disabilityDate = aDisabilityDate;
	}

	/**
	 * Gets the retired indicator.
	 *
	 * @return the retired indicator
	 */
	public Boolean getRetiredIndicator() {
		return this.retiredIndicator;
	}

	/**
	 * Sets the retired indicator.
	 *
	 * @param aRetiredIndicator the new retired indicator
	 */
	public void setRetiredIndicator(final Boolean aRetiredIndicator) {
		this.retiredIndicator = aRetiredIndicator;
	}

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 * Gets short first name
	 *
	 * @return the short first name
	 */
	public String getShortFirstName() {
		return getShortVersionName(this.firstName);
	}

	/**
	 * Sets the first name.
	 *
	 * @param aFirstName the new first name
	 */
	public void setFirstName(final String aFirstName) {
		this.firstName = aFirstName;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return this.lastName;
	}

	/**
	 * Gets short last name
	 *
	 * @return the short last name
	 */
	public String getShortLastName() {
		return getShortVersionName(this.lastName);
	}

	/**
	 * Sets the last name.
	 *
	 * @param aLastName the new last name
	 */
	public void setLastName(final String aLastName) {
		this.lastName = aLastName;
	}

	/**
	 * Gets short complete name
	 *
	 * @return the short complete name
	 */
	public String getShortCompleteName() {
		return String.format("%s %s", this.getShortFirstName(), this.getShortLastName());
	}

	/**
	 * Gets the middle name.
	 *
	 * @return the middle name
	 */
	public String getMiddleName() {
		return this.middleName;
	}

	/**
	 * Sets the middle name.
	 *
	 * @param aMiddleName the new middle name
	 */
	public void setMiddleName(final String aMiddleName) {
		this.middleName = aMiddleName;
	}

	/**
	 * Gets the suffix name.
	 *
	 * @return the suffix name
	 */
	public String getSuffixName() {
		return this.suffixName;
	}

	/**
	 * Sets the suffix name.
	 *
	 * @param aSuffixName the new suffix name
	 */
	public void setSuffixName(final String aSuffixName) {
		this.suffixName = aSuffixName;
	}

	/**
	 * Gets the unstructured name.
	 *
	 * @return the unstructured name
	 */
	public String getUnstructuredName() {
		return this.unstructuredName;
	}

	/**
	 * Sets the unstructured name.
	 *
	 * @param aUnstructuredName the new unstructured name
	 */
	public void setUnstructuredName(final String aUnstructuredName) {
		this.unstructuredName = aUnstructuredName;
	}

	/**
	 * Gets the client eligibility level.
	 *
	 * @return the client eligibility level
	 */
	public ClientEligibilityLevelCodeEnum getClientEligibilityLevel() {
		return this.clientEligibilityLevel;
	}

	/**
	 * Sets the client eligibility level.
	 *
	 * @param clientEligibilityLevelCode the new client eligibility level
	 */
	public void setClientEligibilityLevel(final ClientEligibilityLevelCodeEnum clientEligibilityLevelCode) {
		this.clientEligibilityLevel = clientEligibilityLevelCode;
	}

	/**
	 * Gets the credit score client eligibility indicator.
	 *
	 * @return the credit score client eligibility indicator
	 */
	public Boolean getCreditScoreClientEligibilityIndicator() {
		return this.creditScoreClientEligibilityIndicator;
	}

	/**
	 * Sets the credit score client eligibility indicator.
	 *
	 * @param creditScrClientElgbltyIndicator the new credit score client eligibility indicator
	 */
	public void setCreditScoreClientEligibilityIndicator(final Boolean creditScrClientElgbltyIndicator) {
		this.creditScoreClientEligibilityIndicator = creditScrClientElgbltyIndicator;
	}

	/**
	 * Gets the additional interest sequence.
	 *
	 * @return the additional interest sequence
	 */
	public Short getAdditionalInterestSequence() {
		return this.additionalInterestSequence;
	}

	/**
	 * Sets the additional interest sequence.
	 *
	 * @param additionalInterestSeq the new additional interest sequence
	 */
	public void setAdditionalInterestSequence(final Short additionalInterestSeq) {
		this.additionalInterestSequence = additionalInterestSeq;
	}

	/**
	 * Gets the ing staff indicator.
	 *
	 * @return the ing staff indicator
	 */
	public Boolean getIngStaffIndicator() {
		return this.ingStaffIndicator;
	}

	/**
	 * Sets the ing staff indicator.
	 *
	 * @param aIngStaffIndicator the new ing staff indicator
	 */
	public void setIngStaffIndicator(final Boolean aIngStaffIndicator) {
		this.ingStaffIndicator = aIngStaffIndicator;
	}

	/**
	 * Gets the employee number.
	 *
	 * @return the employee number
	 */
	public String getEmployeeNumber() {
		return this.employeeNumber;
	}

	/**
	 * Sets the employee number.
	 *
	 * @param aEmployeeNumber the new employee number
	 */
	public void setEmployeeNumber(final String aEmployeeNumber) {
		this.employeeNumber = aEmployeeNumber;
	}

	/**
	 * Gets the cif client id.
	 *
	 * @return the cif client id
	 */
	public Long getCifClientId() {
		return this.cifClientId;
	}

	/**
	 * Sets the cif client id.
	 *
	 * @param aCifClientId the new cif client id
	 */
	public void setCifClientId(final Long aCifClientId) {
		this.cifClientId = aCifClientId;
	}

	/**
	 * Gets the consents.
	 *
	 * @return the consents
	 */
	@XmlElementWrapper(name = "consents")
	@XmlElement(name = "consent")
	public Set<Consent> getConsents() {
		return Collections.unmodifiableSet(this.consents);
	}

	/**
	 * Sets the consents.
	 *
	 * @param aConsents the new consents
	 */
	protected void setConsents(final Set<Consent> aConsents) {
		this.consents = aConsents;
	}

	/**
	 * Adds the consent.
	 *
	 * @param consent the consent
	 */
	public void addConsent(final com.ing.canada.plp.domain.party.Consent consent) {
		AssociationsHelper.updateOneToManyFields(this, "consents", consent, "party");
	}

	/**
	 * Removes the consent.
	 *
	 * @param consent the consent
	 */
	public void removeConsent(final com.ing.canada.plp.domain.party.Consent consent) {
		AssociationsHelper.updateOneToManyFields(null, "consents", consent, "party");
	}

	/**
	 * Gets the claims.
	 *
	 * @return the claims
	 */
	@XmlElementWrapper(name = "claims")
	@XmlElement(name = "claim")
	public Set<Claim> getClaims() {
		return Collections.unmodifiableSet(this.claims);
	}

	/**
	 * Sets the claims.
	 *
	 * @param aClaims the new claims
	 */
	protected void setClaims(final Set<Claim> aClaims) {
		this.claims = aClaims;
	}

	/**
	 * Adds the claim.
	 *
	 * @param claim the claim
	 */
	public void addClaim(final com.ing.canada.plp.domain.insurancerisk.Claim claim) {
		AssociationsHelper.updateOneToManyFields(this, "claims", claim, "party");
	}

	/**
	 * Removes the claim.
	 *
	 * @param claim the claim
	 */
	public void removeClaim(final com.ing.canada.plp.domain.insurancerisk.Claim claim) {
		AssociationsHelper.updateOneToManyFields(null, "claims", claim, "party");
	}

	/**
	 * Clears the claims collection and detaches them from this Party (on both side of the relationship).
	 */
	public void clearClaims() {

		Set<Claim> temp = new HashSet<Claim>(this.claims);

		for (Claim claim : temp) {
			this.removeClaim(claim);
		}

	}

	/**
	 * Gets the additional interest roles.
	 *
	 * @return the additional interest roles
	 */
	@XmlElementWrapper(name = "additionalInterestRoles")
	@XmlElement(name = "additionalInterestRole")
	public Set<AdditionalInterestRole> getAdditionalInterestRoles() {
		return Collections.unmodifiableSet(this.additionalInterestRoles);
	}

	/**
	 * Sets the additional interest roles.
	 *
	 * @param aAdditionalInterestRoles the new additional interest roles
	 */
	protected void setAdditionalInterestRoles(final Set<AdditionalInterestRole> aAdditionalInterestRoles) {
		this.additionalInterestRoles = aAdditionalInterestRoles;
	}

	/**
	 * Adds the additional interest role.
	 *
	 * @param additionalInterestRole the additional interest role
	 */
	public void addAdditionalInterestRole(final AdditionalInterestRole additionalInterestRole) {
		AssociationsHelper.updateOneToManyFields(this, "additionalInterestRoles", additionalInterestRole, "party");
	}

	/**
	 * Removes the additional interest role.
	 *
	 * @param additionalInterestRole the additional interest role
	 */
	public void removeAdditionalInterestRole(final AdditionalInterestRole additionalInterestRole) {
		AssociationsHelper.updateOneToManyFields(null, "additionalInterestRoles", additionalInterestRole, "party");
	}

	/**
	 * Gets the party groups.
	 *
	 * @return the party groups
	 */
	@XmlElementWrapper(name = "partyGroups")
	@XmlElement(name = "partyGroup")
	public Set<PartyGroup> getPartyGroups() {
		return Collections.unmodifiableSet(this.partyGroups);
	}

	/**
	 * Sets the party groups.
	 *
	 * @param aPartyGroups the new party groups
	 */
	protected void setPartyGroups(final Set<PartyGroup> aPartyGroups) {
		this.partyGroups = aPartyGroups;
		this.groupTypes = null;
	}

	/**
	 * Adds the party group.
	 *
	 * @param pg the pg
	 */
	public void addPartyGroup(final com.ing.canada.plp.domain.party.PartyGroup pg) {
		AssociationsHelper.updateOneToManyFields(this, "partyGroups", pg, "party");
		this.groupTypes = null;
	}

	/**
	 * Removes the party group.
	 *
	 * @param pg the pg
	 */
	public void removePartyGroup(final com.ing.canada.plp.domain.party.PartyGroup pg) {
		AssociationsHelper.updateOneToManyFields(null, "partyGroups", pg, "party");
		this.groupTypes = null;
	}

	/**
	 * Gets the credit scores.
	 *
	 * @return the credit scores
	 */
	@XmlElementWrapper(name = "creditScores")
	@XmlElement(name = "creditScore")
	public Set<CreditScore> getCreditScores() {
		return Collections.unmodifiableSet(this.creditScores);
	}

	/**
	 * Sets the credit scores.
	 *
	 * @param aCreditScores the new credit scores
	 */
	protected void setCreditScores(final Set<CreditScore> aCreditScores) {
		this.creditScores = aCreditScores;
	}

	/**
	 * Adds the credit score.
	 *
	 * @param score the score
	 */
	public void addCreditScore(final com.ing.canada.plp.domain.party.CreditScore score) {
		AssociationsHelper.updateOneToManyFields(this, "creditScores", score, "party");
	}

	/**
	 * Removes the credit score.
	 *
	 * @param score the score
	 */
	public void removeCreditScore(final com.ing.canada.plp.domain.party.CreditScore score) {
		AssociationsHelper.updateOneToManyFields(null, "creditScores", score, "party");
	}

	/**
	 * Gets the party role in risks.
	 *
	 * @return the party role in risks
	 */
	@XmlElementWrapper(name = "partyRoleInRisks")
	@XmlElement(name = "partyRoleInRisk")
	public Set<PartyRoleInRisk> getPartyRoleInRisks() {
		return Collections.unmodifiableSet(this.partyRoleInRisks);
	}

	/**
	 * Sets the party role in risks.
	 *
	 * @param aPartyRoleInRisks the new party role in risks
	 */
	protected void setPartyRoleInRisks(final Set<PartyRoleInRisk> aPartyRoleInRisks) {
		this.partyRoleInRisks = aPartyRoleInRisks;
	}

	/**
	 * Adds the party role in risk.
	 *
	 * @param pr the pr
	 */
	public void addPartyRoleInRisk(final com.ing.canada.plp.domain.party.PartyRoleInRisk pr) {
		AssociationsHelper.updateOneToManyFields(this, "partyRoleInRisks", pr, "party");
	}

	/**
	 * Removes the party role in risk.
	 *
	 * @param pr the pr
	 */
	public void removePartyRoleInRisk(final com.ing.canada.plp.domain.party.PartyRoleInRisk pr) {
		AssociationsHelper.updateOneToManyFields(null, "partyRoleInRisks", pr, "party");
	}

	/**
	 * Gets the addresses.
	 *
	 * @return the addresses
	 */
	@XmlElementWrapper(name = "addresses")
	@XmlElement(name = "address")
	public Set<Address> getAddresses() {
		return Collections.unmodifiableSet(this.addresses);
	}

	/**
	 * Sets the addresses.
	 *
	 * @param aAddresses the new addresses
	 */
	protected void setAddresses(final Set<Address> aAddresses) {
		this.addresses = aAddresses;
		this.addressTypes = null;
	}

	/**
	 * Adds the address.
	 *
	 * @param address the address
	 */
	public void addAddress(final com.ing.canada.plp.domain.party.Address address) {
		AssociationsHelper.updateOneToManyFields(this, "addresses", address, "party");
		this.addressTypes = null;
	}

	/**
	 * Removes the address.
	 *
	 * @param address the address
	 */
	public void removeAddress(final com.ing.canada.plp.domain.party.Address address) {
		AssociationsHelper.updateOneToManyFields(null, "addresses", address, "party");
		this.addressTypes = null;
	}

	/**
	 * Gets the driver complement info.
	 *
	 * @return the driver complement info
	 */
	public DriverComplementInfo getDriverComplementInfo() {
		return this.driverComplementInfo;
	}

	/**
	 * Sets the driver complement info.
	 *
	 * @param aDriverComplementInfo the new driver complement info
	 */
	public void setDriverComplementInfo(final DriverComplementInfo aDriverComplementInfo) {
		AssociationsHelper.updateOneToOneFields(this, Party.class, "driverComplementInfo", aDriverComplementInfo,
				DriverComplementInfo.class, "party");
	}

	/**
	 * Gets the phones.
	 *
	 * @return the phones
	 */
	@XmlElementWrapper(name = "phones")
	@XmlElement(name = "phone")
	public Set<Phone> getPhones() {
		return this.phones;
	}

	/**
	 * Sets the phones.
	 *
	 * @param aPhones the new phones
	 */
	protected void setPhones(final Set<Phone> aPhones) {
		this.phones = aPhones;
	}

	/**
	 * Adds the phone.
	 *
	 * @param phone the phone
	 */
	public void addPhone(final com.ing.canada.plp.domain.party.Phone phone) {
		AssociationsHelper.updateOneToManyFields(this, "phones", phone, "party");
	}

	/**
	 * Removes the phone.
	 *
	 * @param phone the phone
	 */
	public void removePhone(final com.ing.canada.plp.domain.party.Phone phone) {
		AssociationsHelper.updateOneToManyFields(null, "phones", phone, "party");
	}

	/**
	 * Gets the policy holders.
	 *
	 * @return the policy holders
	 */
	@XmlElementWrapper(name = "policyHolders")
	@XmlElement(name = "policyHolder")
	public Set<PolicyHolder> getPolicyHolders() {
		return Collections.unmodifiableSet(this.policyHolders);
	}

	/**
	 * Sets the policy holders.
	 *
	 * @param aPolicyHolders the new policy holders
	 */
	protected void setPolicyHolders(final Set<PolicyHolder> aPolicyHolders) {
		this.policyHolders = aPolicyHolders;
		this.holderTypes = null;
	}

	/**
	 * Adds the policy holder.
	 *
	 * @param policyHolder the policy holder
	 */
	public void addPolicyHolder(final com.ing.canada.plp.domain.policyversion.PolicyHolder policyHolder) {
		AssociationsHelper.updateOneToManyFields(this, "policyHolders", policyHolder, "party");
		this.holderTypes = null;
	}

	/**
	 * Removes the policy holder.
	 *
	 * @param policyHolder the policy holder
	 */
	public void removePolicyHolder(final com.ing.canada.plp.domain.policyversion.PolicyHolder policyHolder) {
		AssociationsHelper.updateOneToManyFields(null, "policyHolders", policyHolder, "party");
		this.holderTypes = null;
	}

	/**
	 * Gets the original scenario party.
	 *
	 * @return the original scenario party
	 */
	@XmlTransient
	// reference source
	public Party getOriginalScenarioParty() {
		return this.originalScenarioParty;
	}

	/**
	 * Sets the original scenario party.
	 *
	 * @param anOriginalScenarioParty the new original scenario party
	 */
	public void setOriginalScenarioParty(final Party anOriginalScenarioParty) {
		this.originalScenarioParty = anOriginalScenarioParty;
	}

	/**
	 * Gets the action taken.
	 *
	 * @return the action taken
	 */
	public ActionTakenCodeEnum getActionTaken() {
		return this.actionTaken;
	}

	/**
	 * Sets the action taken.
	 *
	 * @param anActionTaken the new action taken
	 */
	public void setActionTaken(final ActionTakenCodeEnum anActionTaken) {
		this.actionTaken = anActionTaken;
	}

	/**
	 * Gets the occupation code.
	 *
	 * @return the occupation code
	 */
	public String getOccupationCode() {
		return this.occupationCode;
	}

	/**
	 * Sets the occupation code.
	 *
	 * @param anOccupationCode the new occupation code
	 */
	public void setOccupationCode(final String anOccupationCode) {
		this.occupationCode = anOccupationCode;
	}

	/**
	 * Gets the road block indicator.
	 *
	 * @return the road block indicator
	 */
	public Boolean getRoadBlockIndicator() {
		return this.roadBlockIndicator;
	}

	/**
	 * Sets the road block indicator.
	 *
	 * @param aRoadBlockIndicator the new road block indicator
	 */
	public void setRoadBlockIndicator(final Boolean aRoadBlockIndicator) {
		this.roadBlockIndicator = aRoadBlockIndicator;
	}

	/**
	 * Gets the prior carrier policy infos.
	 *
	 * @return the prior carrier policy info
	 */
	public PriorCarrierPolicyInfo getPriorCarrierPolicyInfo() {
		return this.priorCarrierPolicyInfo;
	}

	/**
	 * Sets the prior carrier policy info.
	 *
	 * @param aPriorCarrierPolicyInfo the new prior carrier policy info
	 */
	public void setPriorCarrierPolicyInfo(final PriorCarrierPolicyInfo aPriorCarrierPolicyInfo) {
		AssociationsHelper.updateOneToManyFields(aPriorCarrierPolicyInfo, "parties", this, "priorCarrierPolicyInfo");
	}

	/**
	 * @return {@link #emailAddress}
	 */
	public String getEmailAddress() {
		return this.emailAddress;
	}

	/**
	 * @param anEmailAddress {@link #emailAddress}
	 */
	public void setEmailAddress(final String anEmailAddress) {
		this.emailAddress = anEmailAddress;
	}

	/**
	 * @return true when party is principal driver
	 */
	public boolean isPrincipalDriver() {
		Set<PartyRoleInRisk> partyRoles = this.getPartyRoleInRisks();
		if (partyRoles != null) {
			for (PartyRoleInRisk partyRoleInRisk : partyRoles) {
				if (partyRoleInRisk.isPrincipalDriver()) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * @return {@link #studentGrade}
	 */
	public PartyStudentGrade getStudentGrade() {
		return this.studentGrade;
	}

	/**
	 * @param studentGrade {@link #studentGrade}
	 */
	public void setStudentGrade(PartyStudentGrade studentGrade) {
		this.studentGrade = studentGrade;
	}

	/**
	 * @param alreadyInsuredInCanadaInd the outstandingPremiumIndicatory to set
	 */
	public void setAlreadyInsuredInCanadaInd(Boolean alreadyInsuredInCanadaInd) {
		this.alreadyInsuredInCanadaInd = alreadyInsuredInCanadaInd;
	}

	/**
	 * @return the outstandingPremiumIndicatory
	 */
	public Boolean getAlreadyInsuredInCanadaInd() {
		return this.alreadyInsuredInCanadaInd;
	}

	/**
	 * @param outstandingPremiumIndicatory the outstandingPremiumIndicatory to set
	 */
	public void setOutstandingPremiumInd(Boolean outstandingPremiumIndicatory) {
		this.outstandingPremiumInd = outstandingPremiumIndicatory;
	}

	/**
	 * @return the outstandingPremiumIndicatory
	 */
	public Boolean getOutstandingPremiumInd() {
		return this.outstandingPremiumInd;
	}

	/**
	 * Gets the age first insured
	 *
	 * @return the age first insured
	 */
	public Short getAgeFirstInsured() {
		return this.ageFirstInsured;
	}

	/**
	 * Sets the age first insured.
	 *
	 * @param ageFirstInsured age first insured
	 */
	public void setAgeFirstInsured(final Short ageFirstInsured) {
		this.ageFirstInsured = ageFirstInsured;
	}

	/**
	 * Verifies the length of name is bigger then 25 and fixes it to 25 to fix display issues.
	 *
	 * @param name the name
	 * @return the short version name
	 */
	private static String getShortVersionName(String name) {
		String shortName = name;
		if (StringUtils.isNotEmpty(name) && name.length() > 25) {
			shortName = new StringBuilder(name.substring(0, 25)).append("...").toString();
		}
		return shortName;
	}

	/**
	 * @return {@link #criminalRecordIndicator}
	 */
	public Boolean getCriminalRecordIndicator() {
		return this.criminalRecordIndicator;
	}

	/**
	 * @param criminalRecordIndicator {@link #criminalRecordIndicator}
	 */
	public void setCriminalRecordIndicator(Boolean criminalRecordIndicator) {
		this.criminalRecordIndicator = criminalRecordIndicator;
	}

	public Address getAddress(AddressTypeCodeEnum addressType) {
		Address newAddress = null;
		if (this.addressTypes == null) {
			Map<AddressTypeCodeEnum, Address> newAddresses = new HashMap<AddressTypeCodeEnum, Address>();
			if (this.getAddresses() != null) {
				for (Address address : this.getAddresses()) {
					Address oldAddress = newAddresses.put(address.getAddressType(), address);
					if (oldAddress != null && oldAddress.getExpiryDate() == null
							&& oldAddress.getAddressUsage() == null) {
						newAddresses.put(address.getAddressType(), oldAddress);
					}
				}
			}
			this.addressTypes = newAddresses;
		}
		newAddress = this.addressTypes.get(addressType);
		return newAddress;
	}

	public GroupRepositoryEntry getGroup(PartyGroupTypeCodeEnum groupType) {
		if (this.groupTypes == null) {
			Map<PartyGroupTypeCodeEnum, GroupRepositoryEntry> newGroupTypes = new HashMap<PartyGroupTypeCodeEnum, GroupRepositoryEntry>();
			if (this.getPartyGroups() != null) {
				for (PartyGroup partyGroup : this.getPartyGroups()) {
					GroupRepositoryEntry repositoryEntry = partyGroup.getGroupRepositoryEntry();
					if (repositoryEntry != null) {
						newGroupTypes.put(repositoryEntry.getPartyGroupType(), repositoryEntry);
					}
				}
			}
			this.groupTypes = newGroupTypes;
		}
		return this.groupTypes.get(groupType);
	}

	public PolicyHolder getPolicyHolder(PolicyHolderTypeCodeEnum holderType) {
		if (this.holderTypes == null) {
			Map<PolicyHolderTypeCodeEnum, PolicyHolder> newHolderTypes = new HashMap<PolicyHolderTypeCodeEnum, PolicyHolder>();
			if (this.getPolicyHolders() != null) {
				for (PolicyHolder holder : this.getPolicyHolders()) {
					newHolderTypes.put(holder.getPolicyHolderType(), holder);
				}
			}
			this.holderTypes = newHolderTypes;
		}
		return this.holderTypes.get(holderType);
	}

	public Boolean getNationalBankClientInd() {
		return this.nationalBankClientInd;
	}

	public void setNationalBankClientInd(Boolean nationalBankClientInd) {
		this.nationalBankClientInd = nationalBankClientInd;
	}
	
	/**
	 * @return the webMsgId
	 */
	public Integer getWebMsgId() {
		return this.webMsgId;
	}

	/**
	 * @param webMsgId the webMsgId to set
	 */
	public void setWebMsgId(Integer webMsgId) {
		this.webMsgId = webMsgId;
	}
	
	/**
	 * @return the partyRelationTo
	 */
	@XmlTransient
	public Set<PartyRelation> getPartyRelationTo() {
		return this.partyRelationTo;
	}

	/**
	 * @param partyRelationTo the partyRelationTo to set
	 */
	public void setPartyRelationTo(Set<PartyRelation> partyRelationTo) {
		this.partyRelationTo = partyRelationTo;
	}

	/**
	 * @return the partyRelationFrom
	 */
	@XmlTransient
	public Set<PartyRelation> getPartyRelationFrom() {
		return this.partyRelationFrom;
	}

	/**
	 * @param partyRelationFrom the partyRelationFrom to set
	 */
	public void setPartyRelationFrom(Set<PartyRelation> partyRelationFrom) {
		this.partyRelationFrom = partyRelationFrom;
	}

	public Integer getNumberOfInsufficientFundsToDate() {
		return this.numberOfInsufficientFundsToDate;
	}

	public void setNumberOfInsufficientFundsToDate(Integer numberOfInsufficientFundsToDate) {
		this.numberOfInsufficientFundsToDate = numberOfInsufficientFundsToDate;
	}

}
