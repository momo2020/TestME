/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum AddressTypeCodeEnum.
 */
public enum AddressTypeCodeEnum {

	RESIDENTIAL_ADDRESS("RES"), COMMERCIAL_ADDRESS("BUS"), ADVISOR_ADDRESS("ADV");


	/**
	 * Instantiates a new address type code enum.
	 * 
	 * @param aCode the a code
	 */
	private AddressTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the address type code enum
	 */
	public static AddressTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (AddressTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
