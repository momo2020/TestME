/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insurancerisk;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.BasicCoverageCodeEnum;
import com.ing.canada.plp.domain.enums.RatingFactorCalculationMethodEnum;
import com.ing.canada.plp.domain.enums.RatingFactorTypeCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * MultiplicativeRatingFactorFromBasicCoverage entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY) 
@Entity
// @Table(name = "MLT_RAT_FCT_FROM_B_COV", uniqueConstraints = { @UniqueConstraint(columnNames = { "RATING_RISK_ID" }) })
@Table(name = "MLT_RAT_FCT_FROM_B_COV")
@NamedQueries( { @NamedQuery(name = "MultiplicativeRatingFactorBasicCoverage.getBasicCoverageFactor", query = "from MultiplicativeRatingFactorFromBasicCoverage mrfbc where mrfbc.basicCoverageCode = :coverageCode and mrfbc.limitOfInsuranceAmount = :limitOfInsuranceAmount and mrfbc.deductibleAmount = :deductibleAmount and mrfbc.limitMedicalExpensesPerPersonAmount = :limitMedicalExpensesPerPersonAmount and mrfbc.limitMutilationDeathIndemnityAmount = :limitMutilationDeathIndemnityAmount and mrfbc.weeklyBenefitsAmount = :weeklyBenefitsAmount and mrfbc.ratingRisk = :ratingRisk") })
public class MultiplicativeRatingFactorFromBasicCoverage extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	// Fields
	/** The id. */
	@Id
	@Column(name = "MLT_RAT_FCT_FROM_B_COV_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "MultiplicativeRatingFactorFromBasicCoverageSequence")
	@SequenceGenerator(name = "MultiplicativeRatingFactorFromBasicCoverageSequence", sequenceName = "MLT_RAT_FCT_FROM_B_COV_SEQ", allocationSize = 5)
	private Long id;

	/** The rating risk. */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "RATING_RISK_ID", nullable = false)
	private RatingRisk ratingRisk;

	/** The basic coverage code. */
	@Column(name = "BASIC_COVERAGE_CD", nullable = false, length = 4)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.BasicCoverageCodeEnum") })
	private BasicCoverageCodeEnum basicCoverageCode;

	/** The limit of insurance amount. */
	@Column(name = "LIMIT_OF_INSURANCE_AMT", precision = 9, scale = 0)
	private Long limitOfInsuranceAmount;

	/** The deductible amount. */
	@Column(name = "DEDUCTIBLE_AMT", precision = 9, scale = 0)
	private Long deductibleAmount;

	/** The limit medical expenses per person amount. */
	@Column(name = "LMT_MED_EXPENSES_PER_PRSN_AMT", precision = 8, scale = 0)
	private Long limitMedicalExpensesPerPersonAmount;

	/** The limit mutilation death indemnity amount. */
	@Column(name = "LMT_MUTLTN_DEATH_INDEMNITY_AMT", precision = 8, scale = 0)
	private Long limitMutilationDeathIndemnityAmount;

	/** The weekly benefits amount. */
	@Column(name = "WEEKLY_BENEFITS_AMT", precision = 9, scale = 0)
	private Long weeklyBenefitsAmount;

	/** The multiplicative rating factor. */
	@Column(name = "MULT_RATING_FACTOR_QTY", nullable = false, precision = 10, scale = 4)
	private Double multiplicativeRatingFactor;
	
	/** The condition type. */
	@Column(name = "CONDITION_TYPE_CD", nullable = false, length = 5)
	private String conditionType;
	
	/** The rating factor type. */
	@Column(name = "RATING_FACTOR_TYPE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.RatingFactorTypeCodeEnum") })
	private RatingFactorTypeCodeEnum ratingFactorType;

	/** The maximum premium variation allow with factor. */
	@Column(name = "MAX_PRM_VAR_ALLOW_W_RT_FCT_AMT", precision = 10, scale = 4)
	private Double maximumPremiumVariationAllowWithFactor;

	/** The rating factor calculation method. */
	@Column(name = "METHOD_OF_CALCULATION_CD", length = 5)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.RatingFactorCalculationMethodEnum") })
	private RatingFactorCalculationMethodEnum ratingFactorCalculationMethod;

	/** The rating factor apply cond. */
	@Column(name = "RATING_FACTOR_APPLY_COND_CD", nullable = true, length = 25)
	private String ratingFactorApplyCondition;


	/**
	 * default constructor.
	 */
	public MultiplicativeRatingFactorFromBasicCoverage() {
		// Nothing to do
	}

	/**
	 * minimal constructor.
	 * 
	 * @param mltRatFctFromBCovId the mlt rat fct from b cov id
	 * @param aRatingRisk the rating risk
	 * @param basicCoverageCd the basic coverage cd
	 * @param multRatingFactorQty the mult rating factor qty
	 */
	public MultiplicativeRatingFactorFromBasicCoverage(Long mltRatFctFromBCovId, RatingRisk aRatingRisk,
			BasicCoverageCodeEnum basicCoverageCd, Double multRatingFactorQty) {
		this.id = mltRatFctFromBCovId;
		this.ratingRisk = aRatingRisk;
		this.basicCoverageCode = basicCoverageCd;
		this.multiplicativeRatingFactor = multRatingFactorQty;
	}

	/**
	 * full constructor.
	 * 
	 * @param mltRatFctFromBCovId the mlt rat fct from b cov id
	 * @param aRatingRisk the rating risk
	 * @param basicCoverageCd the basic coverage cd
	 * @param limitOfInsuranceAmt the limit of insurance amt
	 * @param deductibleAmt the deductible amt
	 * @param lmtMedExpensesPerPrsnAmt the lmt med expenses per prsn amt
	 * @param lmtMutltnDeathIndemnityAmt the lmt mutltn death indemnity amt
	 * @param weeklyBenefitsAmt the weekly benefits amt
	 * @param multRatingFactorQty the mult rating factor qty
	 */
	public MultiplicativeRatingFactorFromBasicCoverage(Long mltRatFctFromBCovId, RatingRisk aRatingRisk,
			BasicCoverageCodeEnum basicCoverageCd, Long limitOfInsuranceAmt, Long deductibleAmt,
			Long lmtMedExpensesPerPrsnAmt, Long lmtMutltnDeathIndemnityAmt, Long weeklyBenefitsAmt,
			Double multRatingFactorQty) {
		this.id = mltRatFctFromBCovId;
		this.ratingRisk = aRatingRisk;
		this.basicCoverageCode = basicCoverageCd;
		this.limitOfInsuranceAmount = limitOfInsuranceAmt;
		this.deductibleAmount = deductibleAmt;
		this.limitMedicalExpensesPerPersonAmount = lmtMedExpensesPerPrsnAmt;
		this.limitMutilationDeathIndemnityAmount = lmtMutltnDeathIndemnityAmt;
		this.weeklyBenefitsAmount = weeklyBenefitsAmt;
		this.multiplicativeRatingFactor = multRatingFactorQty;
	}

	// Property accessors
	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object mltRatFctFromBCovId) {
		this.id = (Long) mltRatFctFromBCovId;
	}

	/**
	 * Gets the rating risk.
	 * 
	 * @return the rating risk
	 */
	@XmlTransient // parent 
	public RatingRisk getRatingRisk() {
		return this.ratingRisk;
	}

	/**
	 * Sets the rating risk.
	 * 
	 * @param aRatingRisk the new rating risk
	 */
	public void setRatingRisk(RatingRisk aRatingRisk) {
		AssociationsHelper.updateOneToManyFields(aRatingRisk, "multiplicativeRatingFactorFromBasicCoverages", this, "ratingRisk");
	}

	/**
	 * Gets the basic coverage code.
	 * 
	 * @return the basic coverage code
	 */
	public BasicCoverageCodeEnum getBasicCoverageCode() {
		return this.basicCoverageCode;
	}

	/**
	 * Sets the basic coverage cd.
	 * 
	 * @param basicCoverageCd the new basic coverage cd
	 */
	public void setBasicCoverageCd(BasicCoverageCodeEnum basicCoverageCd) {
		this.basicCoverageCode = basicCoverageCd;
	}

	/**
	 * Gets the limit of insurance amount.
	 * 
	 * @return the limit of insurance amount
	 */
	public Long getLimitOfInsuranceAmount() {
		return this.limitOfInsuranceAmount;
	}

	/**
	 * Sets the limit of insurance amount.
	 * 
	 * @param limitOfInsuranceAmt the new limit of insurance amount
	 */
	public void setLimitOfInsuranceAmount(Long limitOfInsuranceAmt) {
		this.limitOfInsuranceAmount = limitOfInsuranceAmt;
	}

	/**
	 * Gets the deductible amount.
	 * 
	 * @return the deductible amount
	 */
	public Long getDeductibleAmount() {
		return this.deductibleAmount;
	}

	/**
	 * Sets the deductible amount.
	 * 
	 * @param deductibleAmt the new deductible amount
	 */
	public void setDeductibleAmount(Long deductibleAmt) {
		this.deductibleAmount = deductibleAmt;
	}

	/**
	 * Gets the limit medical expenses per person amount.
	 * 
	 * @return the limit medical expenses per person amount
	 */
	public Long getLimitMedicalExpensesPerPersonAmount() {
		return this.limitMedicalExpensesPerPersonAmount;
	}

	/**
	 * Sets the limit medical expenses per person amount.
	 * 
	 * @param lmtMedExpensesPerPrsnAmt the new limit medical expenses per person amount
	 */
	public void setLimitMedicalExpensesPerPersonAmount(Long lmtMedExpensesPerPrsnAmt) {
		this.limitMedicalExpensesPerPersonAmount = lmtMedExpensesPerPrsnAmt;
	}

	/**
	 * Gets the limit mutilation death indemnity amount.
	 * 
	 * @return the limit mutilation death indemnity amount
	 */
	public Long getLimitMutilationDeathIndemnityAmount() {
		return this.limitMutilationDeathIndemnityAmount;
	}

	/**
	 * Sets the limit mutilation death indemnity amount.
	 * 
	 * @param lmtMutltnDeathIndemnityAmt the new limit mutilation death indemnity amount
	 */
	public void setLimitMutilationDeathIndemnityAmount(Long lmtMutltnDeathIndemnityAmt) {
		this.limitMutilationDeathIndemnityAmount = lmtMutltnDeathIndemnityAmt;
	}

	/**
	 * Gets the weekly benefits amount.
	 * 
	 * @return the weekly benefits amount
	 */
	public Long getWeeklyBenefitsAmount() {
		return this.weeklyBenefitsAmount;
	}

	/**
	 * Sets the weekly benefits amount.
	 * 
	 * @param weeklyBenefitsAmt the new weekly benefits amount
	 */
	public void setWeeklyBenefitsAmount(Long weeklyBenefitsAmt) {
		this.weeklyBenefitsAmount = weeklyBenefitsAmt;
	}

	/**
	 * Gets the multiplicative rating factor.
	 * 
	 * @return the multiplicative rating factor
	 */
	public Double getMultiplicativeRatingFactor() {
		return this.multiplicativeRatingFactor;
	}

	/**
	 * Sets the multiplicative rating factor.
	 * 
	 * @param multRatingFactorQty the new multiplicative rating factor
	 */
	public void setMultiplicativeRatingFactor(Double multRatingFactorQty) {
		this.multiplicativeRatingFactor = multRatingFactorQty;
	}
	
	/** {@inheritDoc} */
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	/**
	 * Gets the condition type.
	 * 
	 * @return the condition type
	 */
	public String getConditionType() {
		return this.conditionType;
	}

	/**
	 * Sets the condition type cd.
	 * 
	 * @param conditionTypeCd the new condition type cd
	 */
	public void setConditionType(String conditionTypeCd) {
		this.conditionType = conditionTypeCd;
	}

	/**
	 * Gets the maximum premium variation allow with factor.
	 * 
	 * @return the maximum premium variation allow with factor
	 */
	public Double getMaximumPremiumVariationAllowWithFactor() {
		return this.maximumPremiumVariationAllowWithFactor;
	}

	/**
	 * Sets the maximum premium variation allow with factor.
	 * 
	 * @param aMaximumPremiumVariationAllowWithFactor the new maximum premium variation allow with factor
	 */
	public void setMaximumPremiumVariationAllowWithFactor(Double aMaximumPremiumVariationAllowWithFactor) {
		this.maximumPremiumVariationAllowWithFactor = aMaximumPremiumVariationAllowWithFactor;
	}
	
	/**
	 * Gets the rating factor type.
	 * 
	 * @return the ratingFactoryType
	 */
	public RatingFactorTypeCodeEnum getRatingFactorType() {
		return this.ratingFactorType;
	}

	/**
	 * Sets the rating factor type.
	 * 
	 * @param aRatingFactorType the rating factor type to set
	 */
	public void setRatingFactorType(RatingFactorTypeCodeEnum aRatingFactorType) {
		this.ratingFactorType = aRatingFactorType;
	}

	/**
	 * Gets the rating factor calculation method.
	 * 
	 * @return the ratingFactorCalculationMethod
	 */
	public RatingFactorCalculationMethodEnum getRatingFactorCalculationMethod() {
		return this.ratingFactorCalculationMethod;
	}

	/**
	 * Sets the rating factor calculation method.
	 * 
	 * @param ratingFactorCalculationMethod the ratingFactorCalculationMethod to set
	 */
	public void setRatingFactorCalculationMethod(
			RatingFactorCalculationMethodEnum ratingFactorCalculationMethod) {
		this.ratingFactorCalculationMethod = ratingFactorCalculationMethod;
	}

	/**
	 * Gets the rating factor apply condition.
	 * 
	 * @return the rating factor apply condition
	 */
	public String getRatingFactorApplyCondition() {
		return this.ratingFactorApplyCondition;
	}

	/**
	 * Sets the rating factor apply condition.
	 * 
	 * @param ratingFactorApplyCond the new rating factor apply condition
	 */
	public void setRatingFactorApplyCondition(String ratingFactorApplyCond) {
		this.ratingFactorApplyCondition = ratingFactorApplyCond;
	}

}
