/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insuranceriskoffer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * SubCoveragePremiumOffer entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "SUB_COVERAGE_PREMIUM_OFFER", uniqueConstraints = {})
public class SubCoveragePremiumOffer extends BaseEntity {
	private static final long serialVersionUID = 1L;

	/** The coverage premium offer id. */
	@Id
	@GeneratedValue(generator = "coveragePremiumOfferForeignGenerator")
	@org.hibernate.annotations.GenericGenerator(name = "coveragePremiumOfferForeignGenerator", strategy = "foreign", parameters = @Parameter(name = "property", value = "coveragePremiumOffer"))
	@Column(name = "COVERAGE_PREMIUM_OFFER_ID")
	private Long id;

	/** The coverage premium offer. */
	@OneToOne(cascade = {}, fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn(name = "COVERAGE_PREMIUM_OFFER_ID")
	private CoveragePremiumOffer coveragePremiumOffer;

	/** The anl prem lblty bdly injry amount. */
	@Column(name = "ANL_PREM_LBLTY_BDLY_INJRY_AMT", precision = 12, scale = 3)
	private Double annualPremiumLiabilityBodilyInjured;

	/** The anl prem lblty prpty dmd amount. */
	@Column(name = "ANL_PREM_LBLTY_PRPTY_DMD_AMT", precision = 12, scale = 3)
	private Double annualPremiumLiabilityPropertyDamage;

	/** The anl prem acdnt bnft amount. */
	@Column(name = "ANL_PREM_ACDNT_BNFT_AMT", precision = 12, scale = 3)
	private Double annualPremiumAccidentBenefit;

	/** The anl prem all perils amount. */
	@Column(name = "ANL_PREM_ALL_PERILS_AMT", precision = 12, scale = 3)
	private Double annualPremiumAllPerils;

	/** The anl prem collision amount. */
	@Column(name = "ANL_PREM_COLLISION_AMT", precision = 12, scale = 3)
	private Double annualPremiumCollision;

	/** The anl prem comprehensive amount. */
	@Column(name = "ANL_PREM_COMPREHENSIVE_AMT", precision = 12, scale = 3)
	private Double annualPremiumComprehensive;

	/** The anl prem specified perils amount. */
	@Column(name = "ANL_PREM_SPECIFIED_PERILS_AMT", precision = 12, scale = 3)
	private Double annualPremiumSpecifiedPerils;

	/** The anl prem lblty amount. */
	@Column(name = "ANL_PREM_LBLTY_AMT", precision = 12, scale = 3)
	private Double annualPremiumLiability;

	/** The anl prem medical expenses amount. */
	@Column(name = "ANL_PREM_MEDICAL_EXPENSES_AMT", precision = 12, scale = 3)
	private Double annualPremiumMedicalExpenses;

	/** The anl prem total disability amount. */
	@Column(name = "ANL_PREM_TOTAL_DISABILITY_AMT", precision = 12, scale = 3)
	private Double annualPremiumTotalDisability;

	/**
	 * Instantiates a new sub coverage premium offer.
	 */
	public SubCoveragePremiumOffer() {
		// noarg constructor
	}

	/**
	 * Instantiates a new sub coverage premium offer.
	 * 
	 * @param aCoveragePremiumOffer the a coverage premium offer
	 */
	public SubCoveragePremiumOffer(CoveragePremiumOffer aCoveragePremiumOffer) {
		setCoveragePremiumOffer(aCoveragePremiumOffer);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the coverage premium offer.
	 * 
	 * @return the coverage premium offer
	 */
	@XmlTransient // parent
	public CoveragePremiumOffer getCoveragePremiumOffer() {
		return this.coveragePremiumOffer;
	}

	/**
	 * Sets the coverage premium offer.
	 * 
	 * @param aCoveragePremiumOffer the new coverage premium offer
	 */
	public void setCoveragePremiumOffer(CoveragePremiumOffer aCoveragePremiumOffer) {
		AssociationsHelper.updateOneToOneFields(aCoveragePremiumOffer, CoveragePremiumOffer.class,
				"subCoveragePremiumOffer", this, SubCoveragePremiumOffer.class, "coveragePremiumOffer");
	}

	/**
	 * Gets the anl prem lblty bdly injry amount.
	 * 
	 * @return the anl prem lblty bdly injry amount
	 */
	public Double getAnnualPremiumLiabilityBodilyInjured() {
		return this.annualPremiumLiabilityBodilyInjured;
	}

	/**
	 * Sets the anl prem lblty bdly injry amount.
	 * 
	 * @param aAnlPremLbltyBdlyInjryAmount the new anl prem lblty bdly injry amount
	 */
	public void setAnnualPremiumLiabilityBodilyInjured(Double aAnlPremLbltyBdlyInjryAmount) {
		this.annualPremiumLiabilityBodilyInjured = aAnlPremLbltyBdlyInjryAmount;
	}

	/**
	 * Gets the anl prem lblty prpty dmd amount.
	 * 
	 * @return the anl prem lblty prpty dmd amount
	 */
	public Double getAnnualPremiumLiabilityPropertyDamage() {
		return this.annualPremiumLiabilityPropertyDamage;
	}

	/**
	 * Sets the anl prem lblty prpty dmd amount.
	 * 
	 * @param aAnlPremLbltyPrptyDmdAmount the new anl prem lblty prpty dmd amount
	 */
	public void setAnnualPremiumLiabilityPropertyDamage(Double aAnlPremLbltyPrptyDmdAmount) {
		this.annualPremiumLiabilityPropertyDamage = aAnlPremLbltyPrptyDmdAmount;
	}

	/**
	 * Gets the anl prem acdnt bnft amount.
	 * 
	 * @return the anl prem acdnt bnft amount
	 */
	public Double getAnnualPremiumAccidentBenefit() {
		return this.annualPremiumAccidentBenefit;
	}

	/**
	 * Sets the anl prem acdnt bnft amount.
	 * 
	 * @param aAnlPremAcdntBnftAmount the new anl prem acdnt bnft amount
	 */
	public void setAnnualPremiumAccidentBenefit(Double aAnlPremAcdntBnftAmount) {
		this.annualPremiumAccidentBenefit = aAnlPremAcdntBnftAmount;
	}

	/**
	 * Gets the anl prem all perils amount.
	 * 
	 * @return the anl prem all perils amount
	 */
	public Double getAnnualPremiumAllPerils() {
		return this.annualPremiumAllPerils;
	}

	/**
	 * Sets the anl prem all perils amount.
	 * 
	 * @param aAnlPremAllPerilsAmount the new anl prem all perils amount
	 */
	public void setAnnualPremiumAllPerils(Double aAnlPremAllPerilsAmount) {
		this.annualPremiumAllPerils = aAnlPremAllPerilsAmount;
	}

	/**
	 * Gets the anl prem collision amount.
	 * 
	 * @return the anl prem collision amount
	 */
	public Double getAnnualPremiumCollision() {
		return this.annualPremiumCollision;
	}

	/**
	 * Sets the anl prem collision amount.
	 * 
	 * @param aAnlPremCollisionAmount the new anl prem collision amount
	 */
	public void setAnnualPremiumCollision(Double aAnlPremCollisionAmount) {
		this.annualPremiumCollision = aAnlPremCollisionAmount;
	}

	/**
	 * Gets the anl prem comprehensive amount.
	 * 
	 * @return the anl prem comprehensive amount
	 */
	public Double getAnnualPremiumComprehensive() {
		return this.annualPremiumComprehensive;
	}

	/**
	 * Sets the anl prem comprehensive amount.
	 * 
	 * @param aAnlPremComprehensiveAmount the new anl prem comprehensive amount
	 */
	public void setAnnualPremiumComprehensive(Double aAnlPremComprehensiveAmount) {
		this.annualPremiumComprehensive = aAnlPremComprehensiveAmount;
	}

	/**
	 * Gets the anl prem specified perils amount.
	 * 
	 * @return the anl prem specified perils amount
	 */
	public Double getAnnualPremiumSpecifiedPerils() {
		return this.annualPremiumSpecifiedPerils;
	}

	/**
	 * Sets the anl prem specified perils amount.
	 * 
	 * @param aAnlPremSpecifiedPerilsAmount the new anl prem specified perils amount
	 */
	public void setAnnualPremiumSpecifiedPerils(Double aAnlPremSpecifiedPerilsAmount) {
		this.annualPremiumSpecifiedPerils = aAnlPremSpecifiedPerilsAmount;
	}

	/**
	 * Gets the anl prem lblty amount.
	 * 
	 * @return the anl prem lblty amount
	 */
	public Double getAnnualPremiumLiability() {
		return this.annualPremiumLiability;
	}

	/**
	 * Sets the anl prem lblty amount.
	 * 
	 * @param aAnlPremLbltyAmount the new anl prem lblty amount
	 */
	public void setAnnualPremiumLiability(Double aAnlPremLbltyAmount) {
		this.annualPremiumLiability = aAnlPremLbltyAmount;
	}

	/**
	 * Gets the anl prem medical expenses amount.
	 * 
	 * @return the anl prem medical expenses amount
	 */
	public Double getAnnualPremiumMedicalExpenses() {
		return this.annualPremiumMedicalExpenses;
	}

	/**
	 * Sets the anl prem medical expenses amount.
	 * 
	 * @param aAnlPremMedicalExpensesAmount the new anl prem medical expenses amount
	 */
	public void setAnnualPremiumMedicalExpenses(Double aAnlPremMedicalExpensesAmount) {
		this.annualPremiumMedicalExpenses = aAnlPremMedicalExpensesAmount;
	}

	/**
	 * Gets the anl prem total disability amount.
	 * 
	 * @return the anl prem total disability amount
	 */
	public Double getAnnualPremiumTotalDisability() {
		return this.annualPremiumTotalDisability;
	}

	/**
	 * Sets the anl prem total disability amount.
	 * 
	 * @param aAnlPremTotalDisabilityAmount the new anl prem total disability amount
	 */
	public void setAnnualPremiumTotalDisability(Double aAnlPremTotalDisabilityAmount) {
		this.annualPremiumTotalDisability = aAnlPremTotalDisabilityAmount;
	}

}
