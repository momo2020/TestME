/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.domain.enums.RatingFactorCalculationMethodEnum;
import com.ing.canada.plp.domain.enums.RatingFactorTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.MultiplicativeRatingFactorFromNonBasicCoverage;
import com.ing.canada.plp.domain.insurancerisk.RatingRisk;

/**
 * This interface exposes services required to manage Rating risks related entities.
 * 
 * @author Stephane Desjardins
 */
public interface IMultiplicativeRatingFactorFromNonBasicCoverageService extends ICRUDService<MultiplicativeRatingFactorFromNonBasicCoverage> {
	
	/**
	 * Retrieve the list of non basic coverage factor from the parameter pass.
	 * @param ratingRisk
	 * @param calculationMethodEnum
	 * @param factorTypeCodeEnum
	 * @param endorsementCode
	 * @return
	 */
	List<MultiplicativeRatingFactorFromNonBasicCoverage> getMultiplicativeRatingFactorFromNonBasicCoverage(
			RatingRisk ratingRisk, 
			RatingFactorCalculationMethodEnum calculationMethodEnum,
			RatingFactorTypeCodeEnum factorTypeCodeEnum,
			String endorsementCode);

}
