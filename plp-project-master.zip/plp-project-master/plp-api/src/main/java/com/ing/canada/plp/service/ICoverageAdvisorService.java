package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.domain.coverage.CoverageOption;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;


public interface ICoverageAdvisorService extends ICRUDService<CoverageOption>{
	
	/**
	 * Find the list of coverage advisor by insurance risk Id
	 * @param insuranceRiskId The insurance risk Id
	 * @return list of coverage options
	 * @throws Exception
	 */
	List<CoverageOption> findCoverageAdvisorByRisk(Long insuranceRiskId) throws Exception;
	
	/**
	 * Save the coverage options associated to an insuranceRisk.
	 * 
	 * @param insuranceRisk {@link InsuranceRisk}
	 * @throws Exception
	 */
	void save(InsuranceRisk insuranceRisk) throws Exception;
}
