/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.domain.IPRestriction;
import com.ing.canada.plp.domain.enums.IPRestrictionTypeCodeEnum;

/**
 * The Interface IIPRestrictionService.
 * 
 */
public interface IIPRestrictionService {

	List<IPRestriction> getIPRestrictionsForIP(
			String ipNumber);
	
	IPRestriction getEffectiveRestrictionForIP (String ipNumber);
	
	IPRestriction getEffectiveRestrictionExemptionForIP (String ipNumber);
	
	IPRestriction getEffectiveRestrictionForIP(String ipNumber, IPRestrictionTypeCodeEnum restrictionCode);
	
	public Long reassignSubBroker(String ipNumber, String subBrokerNumber);
	
	public IPRestriction persist(IPRestriction aIPRestriction);
}
