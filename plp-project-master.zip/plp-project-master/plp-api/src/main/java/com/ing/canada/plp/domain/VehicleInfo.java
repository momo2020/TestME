/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain;

import java.util.Locale;

/**
 * Vehicle info. use for reporting only.
 * 
 * @author fsimard
 */
public class VehicleInfo {
    
    /** The id. */
    private Long id;
    
    /** The sequence of the vehicle. */
    private short insuranceRiskSequence;
    
    /** The year. */
    private String year;
    
    /** The model eng. */
    private String modelEng;
    
    /** The model fre. */
    private String modelFre;
    
    /** The make eng. */
    private String makeEng;
    
    /** The make fre. */
    private String makeFre;
    
    /**
     * Instantiates a new vehicle info.
     * 
     * @param aId the a id
     * @param aYear the a year
     * @param aModelEng the a model eng
     * @param aModelFre the a model fre
     * @param aMakeEng the a make eng
     * @param aMakeFre the a make fre
     * @param aInsuranceRiskSequence The Vehicle sequence
     */
    public VehicleInfo(Long aId, Integer aYear, String aModelEng, String aModelFre, String aMakeEng, String aMakeFre,short aInsuranceRiskSequence) {
        this.id = aId;
        if (aYear != null) {
            this.year = aYear.toString();
        }
        this.modelEng = aModelEng;
        this.modelFre = aModelFre;
        this.makeEng = aMakeEng;
        this.makeFre = aMakeFre;
        this.insuranceRiskSequence=aInsuranceRiskSequence;
    }
    
    /**
     * Getter for id.
     * 
     * @return the id
     */
    public Long getId() {
        return this.id;
    }
    
    /**
     * Setter for id.
     * 
     * @param aId the id to set
     */
    public void setId(Long aId) {
        this.id = aId;
    }
    
    /**
     * Getter for year.
     * 
     * @return the year
     */
    public String getYear() {
        return this.year;
    }
    
    /**
     * Setter for year.
     * 
     * @param aYear the year to set
     */
    public void setYear(String aYear) {
        this.year = aYear;
    }
    
    /**
     * Gets the make eng.
     * 
     * @return the make eng
     */
    public String getMakeEng() {
        return this.makeEng;
    }
    
    /**
     * Sets the make eng.
     * 
     * @param aMakeEng the new make eng
     */
    public void setMakeEng(String aMakeEng) {
        this.makeEng = aMakeEng;
    }
    
    /**
     * Gets the make fre.
     * 
     * @return the make fre
     */
    public String getMakeFre() {
        return this.makeFre;
    }
    
    /**
     * Sets the make fre.
     * 
     * @param aMakeFre the new make fre
     */
    public void setMakeFre(String aMakeFre) {
        this.makeFre = aMakeFre;
    }
    
    /**
     * Gets the model eng.
     * 
     * @return the model eng
     */
    public String getModelEng() {
        return this.modelEng;
    }
    
    /**
     * Sets the model eng.
     * 
     * @param aModelEng the new model eng
     */
    public void setModelEng(String aModelEng) {
        this.modelEng = aModelEng;
    }
    
    /**
     * Gets the model fre.
     * 
     * @return the model fre
     */
    public String getModelFre() {
        return this.modelFre;
    }
    
    /**
     * Sets the model fre.
     * 
     * @param aModelFre the new model fre
     */
    public void setModelFre(String aModelFre) {
        this.modelFre = aModelFre;
    }
    
    /**
     * Gets the make from specific Locale.
     * 
     * @param aLocale the a locale
     * 
     * @return the make
     */
    public String getMake(Locale aLocale) {
        if (aLocale.getLanguage().equals(Locale.FRENCH.toString())) {
            return this.makeFre;
        }
        return this.makeEng;
    }
    
    /**
     * Gets the model from specific Locale.
     * 
     * @param aLocale the a locale
     * 
     * @return the model
     */
    public String getModel(Locale aLocale) {
        if (aLocale.getLanguage().equals(Locale.FRENCH.toString())) {
            return this.modelFre;
        }
        return this.modelEng;
    }
    
    /**
     * Gets the insurance risk sequence.
     * 
     * @return the insurance risk sequence
     */
    public short getInsuranceRiskSequence() {
        return this.insuranceRiskSequence;
    }
    
    /**
     * Sets the insurance risk sequence.
     * 
     * @param aInsuranceRiskSequence the new insurance risk sequence
     */
    public void setInsuranceRiskSequence(short aInsuranceRiskSequence) {
        this.insuranceRiskSequence = aInsuranceRiskSequence;
    }
    
}
