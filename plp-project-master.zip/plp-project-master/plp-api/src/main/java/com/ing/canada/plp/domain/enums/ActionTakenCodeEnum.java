/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum ActionTakenCodeEnum.
 */
public enum ActionTakenCodeEnum {
	
	/** ADD */
	ADD("A"), 
	
	/** LOGICAL DELETE */
	LOGICAL_DELETE("D"),
	
	/** MODIFY */
	MODIFY("M"),
	
	/** SUBSTITUTION */
	SUBSTITUTION("S");

	/** The Constant log. */

	/**
	 * Instantiates a new additional interest type code enum.
	 * 
	 * @param aCode the code
	 */
	private ActionTakenCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the additional interest type code enum
	 */
	public static ActionTakenCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (ActionTakenCodeEnum v : values()) {
			if (v.code.equals(value)) {			
				return v;
			}

		}

		throw new IllegalArgumentException("no value found for code: " + value);

	}

}
