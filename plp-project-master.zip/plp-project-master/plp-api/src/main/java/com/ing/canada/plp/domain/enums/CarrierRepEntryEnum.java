/**
 * 
 */
package com.ing.canada.plp.domain.enums;

/**
 * Enumerate insurers code from table CARRIER_REP_ENTRY
 * 
 * @author xpham
 * 
 */
public enum CarrierRepEntryEnum {

	// Code to describe other insurers in Belair company
	AC("AC"), AD("AD"),
	// Code to describe other insurers in Intact company
	OT3("OT3");

	/**
	 * @param aCode the a code
	 */
	private CarrierRepEntryEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}
}
