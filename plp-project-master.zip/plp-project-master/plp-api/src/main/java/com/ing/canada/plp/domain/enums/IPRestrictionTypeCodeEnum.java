package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

public enum IPRestrictionTypeCodeEnum {

	ROADBLOCK1("RDBK1"), 
	ROADBLOCK2("RDBK2"), 
	CAPTCHA("CAPT"),
	NEVER("NEVER");	
	
	/**
	 * Instantiates a new restriction code enum.
	 * 
	 * @param aCode the a code
	 */
	private IPRestrictionTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the restriction code enum
	 */
	public static IPRestrictionTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (IPRestrictionTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
	
}
