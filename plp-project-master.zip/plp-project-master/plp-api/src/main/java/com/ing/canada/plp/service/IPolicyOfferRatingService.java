/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.enums.InternalTechnicalOfferTypeCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.PolicyOfferRating;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;
import com.ing.canada.plp.exception.CloneException;

/**
 * This interface exposes services required to manage PolicyOfferRating related entities.
 *
 * @author R�gis Brochu
 */
public interface IPolicyOfferRatingService extends ICRUDService<PolicyOfferRating> {

	/**
	 * Clones a the policy offer rating and its peripheral objects. 
	 * Most objects in the graph are deep copied. Some objects like
	 * repository entries are NOT cloned, the existing reference is kept (shallow copy). 
	 * 
	 * @param aPolicyVersion the policy version to be cloned
	 * @return the cloned policy offer rating 
	 * @throws com.ing.canada.plp.exception.CloneException something bad really occured
	 */
	PolicyOfferRating clone(PolicyVersion aPolicyVersion) throws CloneException;

	/**
	 * Gets the latest policy offer rating for a policyversion.
	 * 
	 * @param aPolicyVersion the a policy version
	 * 
	 * @return the latest
	 */
	PolicyOfferRating getLatest(PolicyVersion aPolicyVersion);

	/**
	 * Clones the policy offer rating graph and the associated diagnostics advices.
	 * 
	 * @param policyVersion the policy version
	 * @param anInternalOfferTypeCode the an internal offer type code
	 * 
	 * @return Id of the cloned policy offer rating
	 * 
	 * @throws CloneException the clone exception
	 */
	PolicyOfferRating cloneOfferAndDiagnostics(PolicyOfferRating policyVersion,
				InternalTechnicalOfferTypeCodeEnum anInternalOfferTypeCode) throws CloneException;

	public void resetLastAction(PolicyOfferRating policyOfferRating);
	
	public boolean isTransactionMessage(PolicyOfferRating rating, String messageNumber); 
	
}