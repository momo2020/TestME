/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum PaymentPlanCodeEnum.
 */
public enum PaymentPlanCodeEnum {

	ANNUAL("AN"), BI_MONTHLY("BM"), MONTHLY("MO"), QUARTERLY("QU"), SEMI_ANNUAL("SA"), SIX_MONTH_POLICY_SINGLE_PAYMENT(
			"S1"), SIX_MONTH_POLICY_TWO_EQUAL_PAYMENTS("S2"), SIX_MONTH_POLICY_THREE_EQUAL_PAYMENTS("S3"), SIX_MONTH_POLICY_FOUR_EQUAL_PAYMENTS(
			"S4"), SIX_MONTH_POLICY_SIX_EQUAL_PAYMENTS("S5"), ONE_PAY_FOR_ANNUAL_POLICY("1"), TWO_PAYMENTS("2"), THREE_PAYMENTS(
			"3"), FOUR_PAYMENTS("4"), FORTY_THIRTY_THIRTY_PERCENTS("6"), DOWN_PAYMENT_10_MONTHLY_PAYMENTS("7"), THREE_YEAR_ANNUAL_INSTALLMENTS(
			"8"), THREE_YEAR_LUMP_SUM_PAYMENT("9"), OTHER("OT");

	/**
	 * Instantiates a new payment plan code enum.
	 * 
	 * @param aCode the a code
	 */
	private PaymentPlanCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the payment plan code enum
	 */
	public static PaymentPlanCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (PaymentPlanCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
