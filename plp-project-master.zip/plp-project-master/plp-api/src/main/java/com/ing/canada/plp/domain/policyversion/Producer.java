/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.policyversion;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * The Class Producer.
 * 
 * @author plafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "PRODUCER", uniqueConstraints = {})
public class Producer extends BaseEntity {

	private static final long serialVersionUID = 4481394715630691332L;

	/** The id. */
	@Id
	@GeneratedValue(generator = "policyVersionForeignGenerator")
	@org.hibernate.annotations.GenericGenerator(name = "policyVersionForeignGenerator", strategy = "foreign", parameters = @Parameter(name = "property", value = "policyVersion"))
	@Column(name = "POLICY_VERSION_ID")
	private Long id = null;

	/** The policy version. */
	@OneToOne(cascade = {}, fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn(name = "POLICY_VERSION_ID")
	private PolicyVersion policyVersion;

	/** The producer repository entry. */
	@ManyToOne(cascade = { CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name = "PRODUCER_REPOSITORY_ENTRY_ID")
	private ProducerRepositoryEntry producerRepositoryEntry = null;

	/** The original scenario policy version. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_POLICY_VERSION_ID", insertable = false, updatable = false)
	private PolicyVersion originalScenarioPolicyVersion;

	/**
	 * Instantiates a new producer.
	 */
	public Producer() {
		// noarg constructor
	}

	/**
	 * Instantiates a new producer.
	 * 
	 * @param aPolicyVersion the a policy version
	 * @param aProducerRepositoryEntry the a producer repository entry
	 */
	public Producer(PolicyVersion aPolicyVersion, ProducerRepositoryEntry aProducerRepositoryEntry) {
		setPolicyVersion(aPolicyVersion);
		setProducerRepositoryEntry(aProducerRepositoryEntry);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the policy version.
	 * 
	 * @return the policy version
	 */
	@XmlTransient // parent
	public PolicyVersion getPolicyVersion() {
		return this.policyVersion;
	}

	/**
	 * Sets the policy version.
	 * 
	 * @param aPolicyVersion the new policy version
	 */
	public void setPolicyVersion(PolicyVersion aPolicyVersion) {
		AssociationsHelper.updateOneToOneFields(aPolicyVersion, PolicyVersion.class, "producer", this, Producer.class,
				"policyVersion");
	}

	/**
	 * Gets the producer repository entry.
	 * 
	 * @return the producer repository entry
	 */
	public ProducerRepositoryEntry getProducerRepositoryEntry() {
		return this.producerRepositoryEntry;
	}

	/**
	 * Sets the producer repository entry.
	 * 
	 * @param aProducerRepositoryEntry the new producer repository entry
	 */
	public void setProducerRepositoryEntry(ProducerRepositoryEntry aProducerRepositoryEntry) {
		this.producerRepositoryEntry = aProducerRepositoryEntry;
	}

	/**
	 * Gets the original scenario policy version.
	 * 
	 * @return the original scenario policy version
	 */
	@XmlTransient // reference source
	public PolicyVersion getOriginalScenarioPolicyVersion() {
		return this.originalScenarioPolicyVersion;
	}

	/**
	 * Sets the original scenario policy version.
	 * 
	 * @param aOriginalScenarioPolicyVersion the new original scenario policy version
	 */
	protected void setOriginalScenarioPolicyVersion(PolicyVersion aOriginalScenarioPolicyVersion) {
		this.originalScenarioPolicyVersion = aOriginalScenarioPolicyVersion;
	}
}
