/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum PriorCarrierDeclinedOrCancelledCodeEnum.
 */
public enum PriorCarrierDeclinedOrCancelledCodeEnum {

	ALCOHOL_DRUGS("AD"), 
	BAD_RISK("BR"), 
	CLAIMS_FREQUENCY("CF"), 
	CANCELLED_DUE_TO_CONVICTIONS("CV"), 
	CANCELLED_DUE_TO_FRAUD_AGAINST_INSURANCE("FC"), 
	CANCELLED_DUE_TO_LICENSE_SUSPENSION("LS"), 
	CANCELLED_DUE_TO_MISREPRESENTATION("MI"), 
	MOVED("MO"), 
	MORAL_RISK("MR"), 
	MISCELLANEOUS("MS"), 
	CANCELLED_FOR_NON_PAYMENT("NP"), 
	PRIOR_CARRIER_NOT_WRITING_BUSINESS_IN_THIS_TERRITORY("PC"), 
	PHYSICAL_HAZARD("PH"), 
	OTHER("OT");

	/**
	 * Instantiates a new prior carrier declined or cancelled code enum.
	 * 
	 * @param aCode the a code
	 */
	private PriorCarrierDeclinedOrCancelledCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the prior carrier declined or cancelled code enum
	 */
	public static PriorCarrierDeclinedOrCancelledCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (PriorCarrierDeclinedOrCancelledCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
