/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum PartyRoleInRiskTypeCodeEnum.
 */
public enum PartyRoleInRiskTypeCodeEnum {

	IS_DRIVER_OF("DRIVER"), IS_INSURED_OF("INSURE"), IS_OWNER_OF("OWNER");

	/**
	 * Instantiates a new party role in risk type code enum.
	 * 
	 * @param aCode the a code
	 */
	private PartyRoleInRiskTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the party role in risk type code enum
	 */
	public static PartyRoleInRiskTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (PartyRoleInRiskTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
