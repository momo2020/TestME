/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.domain.enums.EndorsementCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.CoveragePremiumOffer;
import com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer;
import com.ing.canada.plp.domain.insuranceriskoffer.PolicyOfferRating;
import com.ing.canada.plp.domain.insuranceriskoffer.RatingRiskOffer;

/**
 * This interface exposes services required to manage Coverage related entities.
 * 
 * @author fsimard
 */
public interface ICoveragePremiumOfferService extends IBaseService<CoveragePremiumOffer> {

	/**
	 * Gets the coverage premium offers.
	 * 
	 * @param insuranceRiskOffer the insurance risk offer
	 * @param ratingRiskOffer the rating risk offer
	 * 
	 * @return the coverage premium offers
	 */
	List<CoveragePremiumOffer> getCoveragePremiumOffers(InsuranceRiskOffer insuranceRiskOffer,
			RatingRiskOffer ratingRiskOffer);

	/**
	 * Return the list of non basic coverage attach to the insurance risk offer (selected or not).
	 * 
	 * @param ratingRiskOffer the rating risk offer
	 * @param insuranceRiskOffer the insurance risk offer
	 * 
	 * @return the non basic coverage premium offer
	 */
	List<CoveragePremiumOffer> getNonBasicCoveragePremiumOffer(InsuranceRiskOffer insuranceRiskOffer,
			RatingRiskOffer ratingRiskOffer);

	/**
	 * Return the list of selected basic coverage attach to the insurance risk offer (selected or not).
	 * 
	 * @param ratingRiskOffer the rating risk offer
	 * @param insuranceRiskOffer the insurance risk offer
	 * 
	 * @return the selected basic coverage premium offer
	 */
	List<CoveragePremiumOffer> getSelectedBasicCoveragePremiumOffer(InsuranceRiskOffer insuranceRiskOffer,
			RatingRiskOffer ratingRiskOffer);

	/**
	 * Gets the specific selected non basic coverage premium offer.
	 * 
	 * @param insuranceRiskOffer the insurance risk offer
	 * @param ratingRiskOffer the rating risk offer
	 * @param endorsementCodeEnum the endorsement code enum
	 * 
	 * @return the specific selected non basic coverage premium offer
	 */
	List<CoveragePremiumOffer> getSpecificSelectedNonBasicCoveragePremiumOffer(InsuranceRiskOffer insuranceRiskOffer,
			RatingRiskOffer ratingRiskOffer, EndorsementCodeEnum endorsementCodeEnum);

	/**
	 * Gets the coverage premium offers.
	 * 
	 * @param policyOfferRating the policy offer rating
	 * 
	 * @return the coverage premium offers
	 */
	List<CoveragePremiumOffer> getCoveragePremiumOffers(PolicyOfferRating policyOfferRating);

}
