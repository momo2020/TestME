/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.List;
import java.util.Locale;

import com.ing.canada.plp.domain.enums.DeviceCategoryCodeEnum;
import com.ing.canada.plp.domain.enums.DeviceModelCodeEnum;
import com.ing.canada.plp.domain.vehicle.AntiTheftDeviceModelRepositoryEntry;

/**
 * The Interface IAntiTheftDeviceModelService.
 * 
 * @author pabonnea
 */
public interface IAntiTheftDeviceModelService {

	/**
	 * Find anti theft device model by category order by name. This service will be use to feed the list of Anti Theft
	 * Device in the jsp page.
	 * 
	 * @return the list< anti theft device model repository entry>
	 */
	List<AntiTheftDeviceModelRepositoryEntry> findAntiTheftDeviceModelByCategory(DeviceCategoryCodeEnum anEnum,
			Locale aLocale);
	/**
	 * Find anti theft device model by category and model 
	 * This service will be use to feed the info on view quote in web zone .
	 * 
	 * @return the anti theft device model repository entry
	 */
	AntiTheftDeviceModelRepositoryEntry findByCategoryAndModel(DeviceCategoryCodeEnum aDeviceCategory, DeviceModelCodeEnum aDeviceModel);

}
