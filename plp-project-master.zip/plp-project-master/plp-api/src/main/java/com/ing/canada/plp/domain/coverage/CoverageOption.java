package com.ing.canada.plp.domain.coverage;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.usertype.BaseEntity;

@Entity
@Table(name = "COVERAGE_OPTION", uniqueConstraints = { @UniqueConstraint(columnNames = { "INSURANCE_RISK_ID",
		"COVERAGE_REPOSITORY_ENTRY_ID" }) })
public class CoverageOption extends BaseEntity {
	
	private static final long serialVersionUID = 7730901531268661835L;

	/**
	 * Instantiates a new coverage.
	 */
	public CoverageOption() {
		// noarg constructor
	}
	
	/**
	 * Instantiates a new Coverage Option.
	 * 
	 * @param aCoverageRepositoryEntry the a coverage repository entry
	 * @param aInsuranceRisk the a insurance risk
	 */
	public CoverageOption(CoverageRepositoryEntry aCoverageRepositoryEntry, InsuranceRisk aInsuranceRisk) {
		setCoverageRepositoryEntry(aCoverageRepositoryEntry);
		setInsuranceRisk(aInsuranceRisk);
	}

	/** The id. */
	@Id
	@Column(name = "COVERAGE_OPTION_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "CoverageOptionSequence")
	@SequenceGenerator(name = "CoverageOptionSequence", sequenceName = "COVERAGE_OPTION_SEQ", allocationSize = 5)
	private Long id;
	
	/** The insurance risk. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_RISK_ID", nullable = false, updatable = true)
	private InsuranceRisk insuranceRisk;
	
	/** The coverage repository entry. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "COVERAGE_REPOSITORY_ENTRY_ID", nullable = false, updatable = true)
	private CoverageRepositoryEntry coverageRepositoryEntry;
	
	/** The deductible amount. */
	@Column(name = "DEDUCTIBLE_AMT", precision = 9, scale = 0)
	private Integer deductibleAmount;
	
	/** The insurance limit amount. */
	@Column(name = "LIMIT_OF_INSURANCE_AMT", precision = 9, scale = 0)
	private Integer limitOfInsurance;
	
	/** Profile buying percentage */
	@Column(name = "PROFILE_BUYING_PCT", precision = 5, scale = 2)
	private Double buyingPercentage;
	
	/** The most popular indicator */
	@Column(name = "PROFILE_MOST_POPULAR_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean mostPopularInd;
	
	/** Recommended Indicator */
	@Column(name = "RECOMMENDED_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean recommendedInd;
	
	/** The recommendation Code */
	@Column(name = "RECOMMENDATION_CD", length = 10)
	private String recommendationCode;
	
	/*new attributes from YVAN*/
	/** The medical expenses limit per person. */
//	@Column(name = "LMT_MED_EXPENSES_PER_PRSN_AMT", precision = 8, scale = 0)
//	protected Integer limitMedicalExpensePerPerson;
//
//	/** The mutilation and death indemnity limit. */
//	@Column(name = "LMT_MUTLTN_DEATH_INDEMNITY_AMT", precision = 8, scale = 0)
//	protected Integer limitMutilationDeathIndemnity;
//
//	/** The weekly benefits. */
//	@Column(name = "WEEKLY_BENEFITS_AMT", precision = 9, scale = 0)
//	protected Integer weeklyBenefits;
	
	@Override
	public Long getId() {
		return this.id;
	}

	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	public InsuranceRisk getInsuranceRisk() {
		return this.insuranceRisk;
	}

	public void setInsuranceRisk(InsuranceRisk insuranceRisk) {
		AssociationsHelper.updateOneToManyFields(insuranceRisk, "coverageOptions", this, "insuranceRisk");
	}

	public CoverageRepositoryEntry getCoverageRepositoryEntry() {
		return this.coverageRepositoryEntry;
	}

	public void setCoverageRepositoryEntry(
			CoverageRepositoryEntry coverageRepositoryEntry) {
		this.coverageRepositoryEntry = coverageRepositoryEntry;
	}

	public Integer getDeductibleAmount() {
		return this.deductibleAmount;
	}

	public void setDeductibleAmount(Integer deductibleAmount) {
		this.deductibleAmount = deductibleAmount;
	}

	public Integer getLimitOfInsurance() {
		return this.limitOfInsurance;
	}

	public void setLimitOfInsurance(Integer limitOfInsurance) {
		this.limitOfInsurance = limitOfInsurance;
	}

	public Double getBuyingPercentage() {
		return this.buyingPercentage;
	}

	public void setBuyingPercentage(Double buyingPercentage) {
		this.buyingPercentage = buyingPercentage;
	}

	public Boolean getMostPopularInd() {
		return this.mostPopularInd;
	}

	public void setMostPopularInd(Boolean mostPopularInd) {
		this.mostPopularInd = mostPopularInd;
	}

	public Boolean getRecommendedInd() {
		return this.recommendedInd;
	}

	public void setRecommendedInd(Boolean recommendedInd) {
		this.recommendedInd = recommendedInd;
	}

	public String getRecommendationCode() {
		return this.recommendationCode;
	}

	public void setRecommendationCode(String recommendationCode) {
		this.recommendationCode = recommendationCode;
	}
}
