/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.party.Party;

/**
 * Party role in risk Helper interface.
 * 
 * <p>
 * This is to help by having a helper to facilitate by retrieving pertaining party role in risk object models.
 * </p>
 * 
 * @author rassaad
 */
public interface IPartyRoleInRiskHelper {

	/**
	 * Set registered owner for party role in risk.
	 * 
	 * @param aParty The {@link Party}.
	 * @param aInsuranceRisk The {@link InsuranceRisk}.
	 * 
	 * @author rassaad
	 */
	void setRegisteredOwner(Party aParty, InsuranceRisk aInsuranceRisk);

	/**
	 * Set pricipal driver for party role in risk.
	 * 
	 * @param aParty The {@link Party}.
	 * @param aInsuranceRisk The {@link InsuranceRisk}.
	 * 
	 * @author rassaad
	 */
	void setPrincipalDriver(Party aParty, InsuranceRisk aInsuranceRisk);

}
