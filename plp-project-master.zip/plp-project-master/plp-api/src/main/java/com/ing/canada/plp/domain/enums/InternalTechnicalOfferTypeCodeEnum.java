/*
 * Important notice: This software is the sole property of ING Canada Inc. and cannot be distributed and/or copied
 * without the written permission of ING Canada Inc. Copyright (c) 2004, ING Canada Inc., All rights reserved.<br>
 * 
 * Created on 2008-05-06.
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum InternalTechnicalOfferTypeCodeEnum.
 */
public enum InternalTechnicalOfferTypeCodeEnum {

	WORKING_OFFER("W"), 
	INVERSE_OFFER("I");

	/**
	 * Instantiates a new sex code enum.
	 * 
	 * @param aCode the a code
	 */
	private InternalTechnicalOfferTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the sex code enum
	 */
	public static InternalTechnicalOfferTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (InternalTechnicalOfferTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
