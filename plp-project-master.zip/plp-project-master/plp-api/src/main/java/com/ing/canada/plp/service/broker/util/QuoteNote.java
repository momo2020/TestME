package com.ing.canada.plp.service.broker.util;

import com.ing.canada.plp.domain.enums.UserActivityTypeCodeEnum;

public class QuoteNote {

	private String note = null;
	private UserActivityTypeCodeEnum type = null;
	private String quote = null;

	public QuoteNote(String quote, String type, String note) {
		this.setQuote(quote);
		this.setType(UserActivityTypeCodeEnum.valueOfCode(type));
		this.setNote(note);
	}

	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public UserActivityTypeCodeEnum getType() {
		return this.type;
	}

	public void setType(UserActivityTypeCodeEnum type) {
		this.type = type;
	}

	public String getQuote() {
		return this.quote;
	}

	public void setQuote(String quote) {
		this.quote = quote;
	}

	public String toString() {
	return "[quote=" + this.getQuote() + ", type=" + this.getType() + ", note=" + this.getNote() + "]";
	}
}
