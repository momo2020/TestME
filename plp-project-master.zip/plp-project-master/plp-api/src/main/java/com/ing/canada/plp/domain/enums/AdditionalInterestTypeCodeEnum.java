/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum AdditionalInterestTypeCodeEnum.
 */
public enum AdditionalInterestTypeCodeEnum {

	ADDITIONAL_NAMED_INSURED("A"), 
	PRINT_LIENHOLDER_COPY("C"), 
	STANDARD_MORTGAGE_CLAUSE("H"), 
	LIENHOLDER("I"), 
	LESSOR("L"), 
	NAMED_INSURED("N"), 
	OTHER_TYPE_OF_INTERESTS("O"), 
	SPECIAL_MORTGAGE_CLAUSE("S"), 
	MORTGAGEE("M");

	/**
	 * Instantiates a new additional interest type code enum.
	 * 
	 * @param aCode the a code
	 */
	private AdditionalInterestTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the additional interest type code enum
	 */
	public static AdditionalInterestTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (AdditionalInterestTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {				
				return v;
			}

		}

		throw new IllegalArgumentException("no value found for code: " + value);

	}
}
