/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum HolderAutoInsuranceSinceCodeEnum.
 */
public enum HolderAutoInsuranceSinceCodeEnum {

	LESS_THAN_1_YEAR("0"), 
	ONE_YEAR_BUT_LESS_THAN_TWO("1"), 
	TWO_YEARS_BUT_LESS_THAN_THREE("2"), 
	THREE_YEARS_BUT_LESS_THAN_FOUR("3"), 
	FOUR_YEARS_BUT_LESS_THAN_FIVE("4"), 
	FIVE_YEARS_BUT_LESS_THAN_SIX("5"),
	MORE_THAN_SIX("6"), // AB and ON
	SIX_YEARS_BUT_LESS_THAN_SEVEN("6"),
	SEVEN_YEARS_BUT_LESS_THAN_EIGHT("7"),
	EIGHT_YEARS_BUT_LESS_THAN_NINE("8"),
	NINE_YEARS_BUT_LESS_THAN_TEN("9"),
	MORE_THAN_TEN("10");
	

	/**
	 * Instantiates a new holder auto insurance since code enum.
	 * 
	 * @param aCode the a code
	 */
	private HolderAutoInsuranceSinceCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the holder auto insurance since code enum
	 */
	public static HolderAutoInsuranceSinceCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (HolderAutoInsuranceSinceCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
