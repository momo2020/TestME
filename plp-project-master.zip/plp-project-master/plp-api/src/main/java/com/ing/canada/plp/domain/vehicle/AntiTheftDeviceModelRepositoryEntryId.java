/**
 * 
 */
package com.ing.canada.plp.domain.vehicle;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.enums.DeviceCategoryCodeEnum;
import com.ing.canada.plp.domain.enums.DeviceModelCodeEnum;

/**
 * AntiTheftDvMdRepEntryId entity.
 * 
 * @author ub8169
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Embeddable
public class AntiTheftDeviceModelRepositoryEntryId implements java.io.Serializable {

	// Fields
	private static final long serialVersionUID = 1L;
	
	
	@Column(name = "DEVICE_CATEGORY_CD", nullable = false, length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.DeviceCategoryCodeEnum") })
	protected DeviceCategoryCodeEnum deviceCategory;
	
	@Column(name = "DEVICE_MODEL_CD", nullable = false, length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.DeviceModelCodeEnum") })
	protected DeviceModelCodeEnum deviceModel;

	/** default constructor */
	public AntiTheftDeviceModelRepositoryEntryId() {
		// Nothing to do
	}

	/** full constructor */
	public AntiTheftDeviceModelRepositoryEntryId(DeviceCategoryCodeEnum aDeviceCategoryCd, DeviceModelCodeEnum aDeviceModelCd) {
		this.deviceCategory = aDeviceCategoryCd;
		this.deviceModel = aDeviceModelCd;
	}

	// Property accessors
	public DeviceCategoryCodeEnum getDeviceCategory() {
		return this.deviceCategory;
	}

	public void setDeviceCategory(DeviceCategoryCodeEnum aDeviceCategoryCd) {
		this.deviceCategory = aDeviceCategoryCd;
	}

	public DeviceModelCodeEnum getDeviceModel() {
		return this.deviceModel;
	}

	public void setDeviceModel(DeviceModelCodeEnum aDeviceModelCd) {
		this.deviceModel = aDeviceModelCd;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override	
	public boolean equals(Object other) {
		if (this == other){
			return true;
		}
			
		if (other == null){
			return false;
		}
			
		if (!(other instanceof AntiTheftDeviceModelRepositoryEntryId)){
			return false;
		}
		
		AntiTheftDeviceModelRepositoryEntryId castOther = (AntiTheftDeviceModelRepositoryEntryId) other;

		return ((this.getDeviceCategory() == castOther.getDeviceCategory()) || (this
				.getDeviceCategory() != null
				&& castOther.getDeviceCategory() != null && this
				.getDeviceCategory().equals(castOther.getDeviceCategory())))
				&& ((this.getDeviceModel() == castOther.getDeviceModel()) || (this
						.getDeviceModel() != null
						&& castOther.getDeviceModel() != null && this
						.getDeviceModel()
						.equals(castOther.getDeviceModel())));
	}

	/**
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		int result = 17;

		result = 37
				* result
				+ (getDeviceCategory() == null ? 0 : this
						.getDeviceCategory().hashCode());
		result = 37
				* result
				+ (getDeviceModel() == null ? 0 : this.getDeviceModel()
						.hashCode());
		return result;
	}

}