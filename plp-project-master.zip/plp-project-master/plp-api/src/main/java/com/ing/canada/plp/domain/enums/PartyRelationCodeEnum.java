package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

public enum PartyRelationCodeEnum {
	ICO("ICO"), CPO("CPO");
	
	
	private PartyRelationCodeEnum(String aCode) {
		this.code = aCode;
	}

	private String code = null;

	public String getCode() {
		return this.code;
	}

	public static PartyRelationCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (PartyRelationCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
	
}
