/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper.enums;

public enum PaymentPlanEnum {

	// Bank Withdrawal - monthly payments
	PLAN_A("A"),
	
	// Credit card payment - one full payment
	PLAN_B("B"),
	
	//	Payroll deductions payment plan - monthly payments at source
	PLAN_C("C"),
	
	// Credit Card - monthly payments
	PLAN_E("E");

	/**
	 * Instantiates a new additional interest type code enum.
	 * 
	 * @param aCode the code
	 */
	private PaymentPlanEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}
}
