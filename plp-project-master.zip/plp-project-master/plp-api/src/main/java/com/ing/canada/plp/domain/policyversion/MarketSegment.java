/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.policyversion;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * The Class MarketSegment.
 * 
 * @author sduchesne
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "MARKET_SEGMENT", uniqueConstraints = {})
public class MarketSegment extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "MARKET_SEGMENT_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "MarketSegmentSequence")
	@SequenceGenerator(name = "MarketSegmentSequence", sequenceName = "MARKET_SEGMENT_SEQ", allocationSize = 5)
	private Long id;

	/** The policy version. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "POLICY_VERSION_ID", nullable = false, updatable = true)
	private PolicyVersion policyVersion;

	/** The actual segment name. */
	@Column(name = "MARKET_SEGMENT_NAME_TXT", length = 15)
	private String marketSegmentNameTxt;

	/** The segment type code. */
	@Column(name = "MARKET_SEGMENT_TYPE_CD", length = 20)
	private String marketSegmentType;

	/** Is segment eligible */
	@Column(name = "MARKET_SEGMENT_ELIGIBLE_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean marketSegmentEligibleIndicator;

	/** Is segment eligible */
	@Column(name = "MARKET_SEGMENT_PERMANENT_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean marketSegmentPermamentIndicator;

	/** The system date time. */
	@Column(name = "SYSTEM_CREATE_TS", length = 11, insertable = false, updatable = false)
	protected Date systemDateTime;

	/**
	 * Instantiates a new producer.
	 */
	public MarketSegment() {
		// noarg constructor
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the policy version.
	 * 
	 * @return the policy version
	 */
	@XmlTransient // parent
	public PolicyVersion getPolicyVersion() {
		return this.policyVersion;
	}

	/**
	 * Sets the policy version.
	 * 
	 * @param aPolicyVersion the new policy version
	 */
	public void setPolicyVersion(PolicyVersion aPolicyVersion) {
		AssociationsHelper.updateOneToManyFields(aPolicyVersion, "marketSegments", this, "policyVersion");
	}

	/**
	 * @return {@link #marketSegmentNameTxt}
	 */
	public String getMarketSegmentNameTxt() {
		return this.marketSegmentNameTxt;
	}

	/**
	 * @param marketSegmentNameTxt
	 */
	public void setMarketSegmentNameTxt(String marketSegmentNameTxt) {
		this.marketSegmentNameTxt = marketSegmentNameTxt;
	}

	/**
	 * @return {@link #marketSegmentEligibleIndicator}
	 */
	public Boolean getMarketSegmentEligibleIndicator() {
		return this.marketSegmentEligibleIndicator;
	}

	/**
	 * @param marketSegmentEligibleIndicator
	 */
	public void setMarketSegmentEligibleIndicator(Boolean marketSegmentEligibleIndicator) {
		this.marketSegmentEligibleIndicator = marketSegmentEligibleIndicator;
	}

	/**
	 * @return {@link #systemDateTime}
	 */
	public Date getSystemDateTime() {
		return this.systemDateTime;
	}

	/**
	 * @param systemDateTime
	 */
	public void setSystemDateTime(Date systemDateTime) {
		this.systemDateTime = systemDateTime;
	}

	/**
	 * @return {@link #marketSegmentType}
	 */
	public String getMarketSegmentType() {
		return this.marketSegmentType;
	}

	/**
	 * @param marketSegmentType
	 */
	public void setMarketSegmentType(String marketSegmentType) {
		this.marketSegmentType = marketSegmentType;
	}

	/**
	 * @return {@link #marketSegmentPermamentIndicator}
	 */
	public Boolean getMarketSegmentPermamentIndicator() {
		return this.marketSegmentPermamentIndicator;
	}

	/**
	 * @param marketSegmentPermamentIndicator
	 */
	public void setMarketSegmentPermamentIndicator(Boolean marketSegmentPermamentIndicator) {
		this.marketSegmentPermamentIndicator = marketSegmentPermamentIndicator;
	}

	/**
	 * @param id
	 */
	public void setId(Long id) {
		this.id = id;
	}
}
