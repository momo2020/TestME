package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;
import com.ing.canada.plp.report.insurancePolicy.InsurancePolicyBrokerInfo;
import com.ing.canada.plp.report.insurancePolicy.criteria.QuoteSearchCriteria;

/**
 * This interface exposes services required to manage InsurancePolicyBrokerInfo related entities.
 * 
 * @author selleing
 */


public interface IInsurancePolicyBrokerService {
	
	/**
	 * Gets the insurance policy broker list.
	 * The returned object is a Map with com.ing.canada.plp.report.insurancePolicy.InsurancePolicyBrokerInfo as key
	 * and a Collection of com.ing.canada.plp.report.insurancePolicy.InsurancePolicyNoteInfo as value
	 *	
	 * BR5828 - Items Displayed per Regional Access : 
 	 * The items displayed in the various lists and search results (i.e.: List of Quotes, 
 	 * List of Users, Point of Sale List, etc.) will be limited to the items available 
 	 * for the current region of the user.
 	 * 
	 * @param availableMasters: the available masters
	 * @param aNbrOfDayLeft : the nbr of day left according to province code enum
	 * @param aProvinceCode
	 * @param aSubBrokerCompanyNumber : the subbroker company number 
	 * @param aManufacturerCompanyCode
	 * @param adminRole : the admin role
	 * 
	 * @return the insurance policy broker list
	 */
	List<InsurancePolicyBrokerInfo> getInsurancePolicyBrokerList(List<String> availableMasters, Integer aNbrOfDayLeft, ProvinceCodeEnum aProvinceCode, String aSubBrokerCompanyNumber, ManufacturerCompanyCodeEnum aManufacturerCompanyCode, boolean adminRole, int maxRow);

	/**
	 * Gets the insurance policy broker list.  
	 * The returned object is a Map with com.ing.canada.plp.report.insurancePolicy.InsurancePolicyBrokerInfo as key 
	 * and a Collection of com.ing.canada.plp.report.insurancePolicy.InsurancePolicyNoteInfo as value
	 *	
	 * BR5828 - Items Displayed per Regional Access : 
 	 * The items displayed in the various lists and search results (i.e.: List of Quotes, 
 	 * List of Users, Point of Sale List, etc.) will be limited to the items available 
 	 * for the current region of the user.
	 *
	 * BR5592  Search Quotes - Accessible Owners: 
	 * @param aSearchCriteria
	 * @param aProvinceCode
	 * @param aSubBrokerCompanyNumber
	 * @param aManufacturerCompanyCode
	 *  
	 * 
	 * @return
	 */
	List<InsurancePolicyBrokerInfo> getInsurancePolicyBrokerListSP(QuoteSearchCriteria aSearchCriteria, ProvinceCodeEnum aProvinceCode, String aSubBrokerCompanyNumber, ManufacturerCompanyCodeEnum aManufacturerCompanyCode);
	
	
	void addPolicyEmailToken(List<InsurancePolicyBrokerInfo> list, String aToken);
	
	/**
	 * Acknowledge the insurance policy returned by the broker lead service.
	 * @param token specifies the insurance policy to be acknowledged.
	 * @return the number of acknowledged policies for the specified token (may be 0).
	 */
	int acknowledgeInsurancePolicyForBroker(String token);
	
}
