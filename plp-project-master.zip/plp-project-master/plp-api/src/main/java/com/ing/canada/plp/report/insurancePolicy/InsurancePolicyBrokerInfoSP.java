package com.ing.canada.plp.report.insurancePolicy;

import javax.persistence.Entity;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.report.enums.QuoteStatusCodeEnum;

@Entity
public class InsurancePolicyBrokerInfoSP extends InsurancePolicyBrokerInfo {

	private static final long serialVersionUID = 1L;
	
	/** the master broker */
	private String masterBroker;

	/** the row number */
	private Integer rowNumber;

	/** The quote status code. */
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.QuoteStatusCodeEnum") })
	private QuoteStatusCodeEnum quoteStatusCode;
	
	private Boolean synchroDiscount;
	
	
	/**
	 * Gets the master broker
	 * 
	 * @return String
	 */
	public String getMasterBroker() {
		return this.masterBroker;
	}

	/**
	 * Sets the master Broker
	 * 
	 * @param aMasterBroker the masterBroker to set
	 */
	public void setMasterBroker(String aMasterBroker) {
		this.masterBroker = aMasterBroker;
	}

	public Integer getRowNumber() {
		return this.rowNumber;
	}

	public void setRowNumber(Integer aRowNumber) {
		this.rowNumber = aRowNumber;
	}

	public QuoteStatusCodeEnum getQuoteStatusCode() {
		return this.quoteStatusCode;
	}

	public void setQuoteStatusCode(QuoteStatusCodeEnum aQuoteStatusCode) {
		this.quoteStatusCode = aQuoteStatusCode;
	}
	
	/**
	 * Gets the synchro discount indicator
	 * @return Boolean.TRUE else Boolean.FALSE
	 */
	public Boolean getSynchroDiscount() {
		return this.synchroDiscount;
	}

	/**
	 * @param aSynchroDiscount
	 */
	public void setSynchroDiscount(Boolean aSynchroDiscount) {
		this.synchroDiscount = aSynchroDiscount;
	}	

}
