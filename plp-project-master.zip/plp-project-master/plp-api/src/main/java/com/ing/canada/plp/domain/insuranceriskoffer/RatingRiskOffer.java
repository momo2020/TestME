/**
 * 
 */
package com.ing.canada.plp.domain.insuranceriskoffer;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cascade;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.RatingRiskTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.BaseRatingRisk;

/**
 * A rating risk offer.
 * 
 * @author plafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "RATING_RISK_OFFER", uniqueConstraints = {})
@NamedQueries( { @NamedQuery(name = "RatingRiskOffer.findAllRatingRiskOffers", query = "select c from RatingRiskOffer c join c.insuranceRiskOffer iro join iro.insuranceRisk ir where ir.selectedInsuranceRiskOffer = iro.id and ir.policyVersion = :policyVersion") })
public class RatingRiskOffer extends BaseRatingRisk {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 623604622599107534L;

	/** The id. */
	@Id
	@Column(name = "RATING_RISK_OFFER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "RatingRiskOfferSequence")
	@SequenceGenerator(name = "RatingRiskOfferSequence", sequenceName = "RATING_RISK_OFFER_SEQ", allocationSize = 5)
	private Long id;

	/** The insurance risk. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_RISK_OFFER_ID", nullable = false, updatable = true)
	private InsuranceRiskOffer insuranceRiskOffer = null;

	/** The coverage premium offers. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "ratingRiskOffer")
	@Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<CoveragePremiumOffer> coveragePremiumOffers = new HashSet<CoveragePremiumOffer>(0);

	/**
	 * Instantiates a new rating risk.
	 */
	public RatingRiskOffer() {
		// noarg constructor
	}

	/**
	 * Instantiates a new rating risk.
	 * 
	 * @param aRatingRiskType the a rating risk type
	 * @param aInsuranceRiskOffer the a insurance risk offer
	 */
	public RatingRiskOffer(InsuranceRiskOffer aInsuranceRiskOffer, RatingRiskTypeCodeEnum aRatingRiskType) {
		setInsuranceRiskOffer(aInsuranceRiskOffer);
		setRatingRiskType(aRatingRiskType);
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the parent insurance risk offer.
	 * 
	 * @return the parent InsuranceRiskOffer
	 */
	@XmlTransient // parent
	public InsuranceRiskOffer getInsuranceRiskOffer() {
		return this.insuranceRiskOffer;
	}

	/**
	 * Associates this object to a parent InsuranceRiskOffer.
	 * 
	 * @param aInsuranceRiskOffer the a insurance risk offer
	 */
	public void setInsuranceRiskOffer(InsuranceRiskOffer aInsuranceRiskOffer) {
		AssociationsHelper.updateOneToManyFields(aInsuranceRiskOffer, "ratingRiskOffers", this, "insuranceRiskOffer");
	}

	/**
	 * Gets the coverage premium offers.
	 * 
	 * @return the coverage premium offers
	 */
	@XmlElementWrapper(name="coveragePremiumOffers")
	@XmlElement(name="coveragePremiumOffer")
	public Set<CoveragePremiumOffer> getCoveragePremiumOffers() {
		return Collections.unmodifiableSet(this.coveragePremiumOffers);
	}

	/**
	 * Sets the coverage premium offers.
	 * 
	 * @param aCoveragePremiumOffers the new coverage premium offers
	 */
	protected void setCoveragePremiumOffers(Set<CoveragePremiumOffer> aCoveragePremiumOffers) {
		this.coveragePremiumOffers = aCoveragePremiumOffers;
	}

	/**
	 * Adds the coverage premium offer.
	 * 
	 * @param coveragePremiumOffer the coverage premium offer
	 */
	public void addCoveragePremiumOffer(
			com.ing.canada.plp.domain.insuranceriskoffer.CoveragePremiumOffer coveragePremiumOffer) {
		AssociationsHelper
				.updateOneToManyFields(this, "coveragePremiumOffers", coveragePremiumOffer, "ratingRiskOffer");
	}

	/**
	 * Removes the coverage premium offer.
	 * 
	 * @param coveragePremiumOffer the coverage premium offer
	 */
	public void removeCoveragePremiumOffer(
			com.ing.canada.plp.domain.insuranceriskoffer.CoveragePremiumOffer coveragePremiumOffer) {
		AssociationsHelper
				.updateOneToManyFields(null, "coveragePremiumOffers", coveragePremiumOffer, "ratingRiskOffer");
	}

}
