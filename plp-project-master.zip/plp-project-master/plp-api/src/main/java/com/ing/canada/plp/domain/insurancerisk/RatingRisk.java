/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insurancerisk;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.coverage.BasicCoverageBasePremium;
import com.ing.canada.plp.domain.coverage.CoveragePremium;
import com.ing.canada.plp.domain.enums.RatingRiskTypeCodeEnum;

/**
 * RatingRisk entity.
 *
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "RATING_RISK", uniqueConstraints = {})
public class RatingRisk extends BaseRatingRisk {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "RATING_RISK_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "RatingRiskSequence")
	@SequenceGenerator(name = "RatingRiskSequence", sequenceName = "RATING_RISK_SEQ", allocationSize = 5)
	private Long id;

	/** The insurance risk. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_RISK_ID", nullable = false, updatable = true)
	private InsuranceRisk insuranceRisk;

	@OneToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "ratingRisk")
	@JoinColumn(name = "RATING_RISK_ID", nullable = false)
	private BasicCoverageBasePremium basicCoverageBasePremium = null;

	/** The coverage premiums. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "ratingRisk")
	private Set<CoveragePremium> coveragePremiums = new HashSet<CoveragePremium>(0);

	/** The multiplicative rating factor from non basic coverages. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "ratingRisk")
	private Set<MultiplicativeRatingFactorFromNonBasicCoverage> multiplicativeRatingFactorFromNonBasicCoverages = new HashSet<MultiplicativeRatingFactorFromNonBasicCoverage>(
			0);

	/** The multiplicative rating factor from basic coverages. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "ratingRisk")
	private Set<MultiplicativeRatingFactorFromBasicCoverage> multiplicativeRatingFactorFromBasicCoverages = new HashSet<MultiplicativeRatingFactorFromBasicCoverage>(0);

	/**
	 * Instantiates a new rating risk.
	 */
	public RatingRisk() {
		// noarg constructor
	}

	/**
	 * Instantiates a new rating risk.
	 *
	 * @param aInsuranceRisk the a insurance risk
	 * @param aRatingRiskType the a rating risk type
	 */
	public RatingRisk(InsuranceRisk aInsuranceRisk, RatingRiskTypeCodeEnum aRatingRiskType) {
		this.setInsuranceRisk(aInsuranceRisk);
		this.setRatingRiskType(aRatingRiskType);
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 *
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param aId the a id
	 *
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the insurance risk.
	 *
	 * @return the insurance risk
	 */
	@XmlTransient // parent
	public InsuranceRisk getInsuranceRisk() {
		return this.insuranceRisk;
	}

	/**
	 * @see com.ing.canada.plp.domain.insurancerisk.BaseRatingRisk#setInsuranceRisk(com.ing.canada.plp.domain.insurancerisk.InsuranceRisk)
	 */
	@Override
	public void setInsuranceRisk(InsuranceRisk aInsuranceRisk) {
		AssociationsHelper.updateOneToManyFields(aInsuranceRisk, "ratingRisks", this, "insuranceRisk");
	}

	/**
	 * Gets the coverage premiums.
	 *
	 * @return the coverage premiums
	 */
	@XmlElementWrapper(name="coveragePremiums")
	@XmlElement(name="coveragePremium")
	public Set<CoveragePremium> getCoveragePremiums() {
		return Collections.unmodifiableSet(this.coveragePremiums);
	}

	/**
	 * Sets the coverage premiums.
	 *
	 * @param aCoveragePremiums the new coverage premiums
	 */
	protected void setCoveragePremiums(Set<CoveragePremium> aCoveragePremiums) {
		this.coveragePremiums = aCoveragePremiums;
	}

	/**
	 * @see com.ing.canada.plp.domain.insurancerisk.BaseRatingRisk#addCoveragePremium(com.ing.canada.plp.domain.coverage.CoveragePremium)
	 */
	@Override
	public void addCoveragePremium(com.ing.canada.plp.domain.coverage.CoveragePremium premium) {
		AssociationsHelper.updateOneToManyFields(this, "coveragePremiums", premium, "ratingRisk");
	}

	/**
	 * @see com.ing.canada.plp.domain.insurancerisk.BaseRatingRisk#removeCoveragePremium(com.ing.canada.plp.domain.coverage.CoveragePremium)
	 */
	@Override
	public void removeCoveragePremium(com.ing.canada.plp.domain.coverage.CoveragePremium premium) {
		AssociationsHelper.updateOneToManyFields(null, "coveragePremiums", premium, "ratingRisk");
	}

	/**
	 * @return the multiplicativeRatingFactorFromBasicCoverages
	 */
	@XmlElementWrapper(name="multiplicativeRatingFactorFromBasicCoverages")
	@XmlElement(name="multiplicativeRatingFactorFromBasicCoverage")
	public Set<MultiplicativeRatingFactorFromBasicCoverage> getMultiplicativeRatingFactorFromBasicCoverages() {
		return Collections.unmodifiableSet(this.multiplicativeRatingFactorFromBasicCoverages);
	}

	/**
	 * @param aMultiplicativeRatingFactorFromBasicCoverages the multiplicativeRatingFactorFromBasicCoverages to set
	 */
	protected void setMultiplicativeRatingFactorFromBasicCoverages(
			Set<MultiplicativeRatingFactorFromBasicCoverage> aMultiplicativeRatingFactorFromBasicCoverages) {
		this.multiplicativeRatingFactorFromBasicCoverages = aMultiplicativeRatingFactorFromBasicCoverages;
	}

	/**
	 * Adds a multiplicative rating factor from basic coverage.
	 *
	 * @param aMultiplicativeRatingFactorFromBasicCoverage
	 */
	public void addMultiplicativeRatingFactorFromBasicCoverage(
			MultiplicativeRatingFactorFromBasicCoverage aMultiplicativeRatingFactorFromBasicCoverage) {
		AssociationsHelper.updateOneToManyFields(this, "multiplicativeRatingFactorFromBasicCoverages",
				aMultiplicativeRatingFactorFromBasicCoverage, "ratingRisk");
	}

	/**
	 * Removes the multiplicative rating factor from basic coverage.
	 *
	 * @param aMultiplicativeRatingFactorFromBasicCoverage
	 */
	public void removeMultiplicativeRatingFactorFromBasicCoverage(
			MultiplicativeRatingFactorFromBasicCoverage aMultiplicativeRatingFactorFromBasicCoverage) {
		AssociationsHelper.updateOneToManyFields(null, "multiplicativeRatingFactorFromBasicCoverages",
				aMultiplicativeRatingFactorFromBasicCoverage, "ratingRisk");
	}

	/**
	 * @return the multiplicativeRatingFactorFromNonBasicCoverages
	 */
	@XmlElementWrapper(name="multiplicativeRatingFactorFromNonBasicCoverages")
	@XmlElement(name="multiplicativeRatingFactorFromNonBasicCoverages")
	public Set<MultiplicativeRatingFactorFromNonBasicCoverage> getMultiplicativeRatingFactorFromNonBasicCoverages() {
		return Collections.unmodifiableSet(this.multiplicativeRatingFactorFromNonBasicCoverages);
	}

	/**
	 * @param aMultiplicativeRatingFactorFromNonBasicCoverages the multiplicativeRatingFactorFromNonBasicCoverages to
	 *            set
	 */
	protected void setMultiplicativeRatingFactorFromNonBasicCoverages(
			Set<MultiplicativeRatingFactorFromNonBasicCoverage> aMultiplicativeRatingFactorFromNonBasicCoverages) {
		this.multiplicativeRatingFactorFromNonBasicCoverages = aMultiplicativeRatingFactorFromNonBasicCoverages;
	}

	/**
	 * Adds a multiplicative rating factor from non basic coverage.
	 *
	 * @param aMultiplicativeRatingFactorFromNonBasicCoverage
	 */
	public void addMultiplicativeRatingFactorFromNonBasicCoverage(
			MultiplicativeRatingFactorFromNonBasicCoverage aMultiplicativeRatingFactorFromNonBasicCoverage) {
		AssociationsHelper.updateOneToManyFields(this, "multiplicativeRatingFactorFromNonBasicCoverages",
				aMultiplicativeRatingFactorFromNonBasicCoverage, "ratingRisk");
	}

	/**
	 * Removes the multiplicative rating factor from non basic coverage.
	 *
	 * @param aMultiplicativeRatingFactorFromNonBasicCoverage
	 */
	public void removeMultiplicativeRatingFactorFromNonBasicCoverage(
			MultiplicativeRatingFactorFromNonBasicCoverage aMultiplicativeRatingFactorFromNonBasicCoverage) {
		AssociationsHelper.updateOneToManyFields(null, "multiplicativeRatingFactorFromNonBasicCoverages",
				aMultiplicativeRatingFactorFromNonBasicCoverage, "ratingRisk");
	}

	/**
	 * @return the basicCoverageBasePremium
	 */
	public BasicCoverageBasePremium getBasicCoverageBasePremium() {
		return this.basicCoverageBasePremium;
	}

	/**
	 * @param aBasicCoverageBasePremium the basicCoverageBasePremium to set
	 */
	public void setBasicCoverageBasePremium(BasicCoverageBasePremium aBasicCoverageBasePremium) {
		AssociationsHelper.updateOneToOneFields(this, RatingRisk.class, "basicCoverageBasePremium",
				aBasicCoverageBasePremium, BasicCoverageBasePremium.class, "ratingRisk");
	}

}
