/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.policyversion.MarketSegment;

/**
 * This interface exposes services required to manage Market segments related entities.
 * 
 * @author fsimard
 */
public interface IMarketSegmentService extends ICRUDService<MarketSegment> {

	
	/**
	 * @param aMarketSegment the market segment
	 * 
	 * @return the market segment
	 * 
	 * @see com.ing.canada.plp.service.IBaseService#persist(com.ing.canada.plp.domain.usertype.BaseEntity)
	 */
	@Override
	MarketSegment persist(MarketSegment aMarketSegment);

}
