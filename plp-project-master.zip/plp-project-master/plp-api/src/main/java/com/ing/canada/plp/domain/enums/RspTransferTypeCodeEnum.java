/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum RspTransferTypeCodeEnum.
 */
public enum RspTransferTypeCodeEnum {

	REGULAR("6"), SPECIAL("7"), ALBERTA_GRAY_AREA("A"), ALBERTA_GOVERNMENT_GRID_POOL("G"), NO_TRANSFERT("N");

	/**
	 * Instantiates a new rsp transfer type code enum.
	 * 
	 * @param aCode the a code
	 */
	private RspTransferTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the rsp transfer type code enum
	 */
	public static RspTransferTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (RspTransferTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
