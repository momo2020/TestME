/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.lock;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public final class InsurancePolicyLockManagerThreadLocal {

	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(InsurancePolicyLockManagerThreadLocal.class);

	private InsurancePolicyLockManagerThreadLocal() {
		// noop
	}

	private static final ThreadLocal<InsurancePolicyLockManager> groupLockManagers = new ThreadLocal<InsurancePolicyLockManager>() {

		@Override
		protected InsurancePolicyLockManager initialValue() {
			// do not create a InsurancePolicyLockManager here, it must be created by Spring cuz we need
			return null;
			// @Transactional behavior
		}

	};

	public static void setGroupLockManager(InsurancePolicyLockManager mgr) {
		groupLockManagers.set(mgr);
	}

	public static InsurancePolicyLockManager getGroupLockManager() {
		return groupLockManagers.get();
	}

}
