/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import com.ing.canada.plp.roadblock.Roadblockable;

/**
 * This service manages the persistence of roadblockable entities when a roadblock is triggered.
 * 
 * @author plafleur
 */
public interface IRoadblockService {

	void persistRoadblock(Roadblockable roadblockable);

}
