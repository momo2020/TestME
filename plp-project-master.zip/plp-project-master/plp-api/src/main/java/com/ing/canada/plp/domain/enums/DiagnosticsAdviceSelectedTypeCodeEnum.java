package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/*
 * Different values for the selection actions taken on the diagnostics.
 * 
 */

public enum DiagnosticsAdviceSelectedTypeCodeEnum {

	/** Diagnostic advice has been selected by the agent */
	DIAGNOSTIC_SELECTED_BY_AGENT("A"),

	/** Diagnostic advice has been deselected by the agent */
	DIAGNOSTIC_DESELECTED_BY_AGENT("B"),

	/** Diagnostic advice has been selected by the client */
	DIAGNOSTIC_SELECTED_BY_CLIENT("C"),

	/** Diagnostic advice has been deselected by the client */
	DIAGNOSTIC_DESELECTED_BY_CLIENT("D"),

	/** Diagnostic advice has been added by the system */
	DIAGNOSTIC_ADDED_BY_SYSTEM("S");

	/**
	 * Instantiates a new diagnostics advice type code enum.
	 * 
	 * @param aCode the a code
	 */
	private DiagnosticsAdviceSelectedTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the additional interest type code enum
	 */
	public static DiagnosticsAdviceSelectedTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (DiagnosticsAdviceSelectedTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no value found for code: " + value);

	}

}
