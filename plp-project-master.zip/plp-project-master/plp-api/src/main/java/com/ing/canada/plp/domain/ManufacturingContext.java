/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.enums.DistributionChannelCodeEnum;
import com.ing.canada.plp.domain.enums.InsuranceBusinessCodeEnum;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * ManufacturingContext entity.
 * 
 * Equals/Hashcode attributes: distributionChannel, insuranceBusiness, province.
 * 
 * @author Patrick Lafleur
 */
@Entity
@Table(name = "MANUFACTURING_CONTEXT", uniqueConstraints = {})
public class ManufacturingContext extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "MANUFACTURING_CONTEXT_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "ManufacturingContextSequence")
	@SequenceGenerator(name = "ManufacturingContextSequence", sequenceName = "MANUFACTURING_CONTEXT_SEQ", allocationSize = 5)
	private Long id;

	/** The distribution channel. */
	@Column(name = "DISTRIBUTION_CHANNEL_CD", nullable = false, length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.DistributionChannelCodeEnum") })
	private DistributionChannelCodeEnum distributionChannel;

	/** The insurance business. */
	@Column(name = "INSURANCE_BUSINESS_CD", nullable = false, length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.InsuranceBusinessCodeEnum") })
	private InsuranceBusinessCodeEnum insuranceBusiness;

	/** The province. */
	@Column(name = "PROVINCE_CD", nullable = false, length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ProvinceCodeEnum") })
	private ProvinceCodeEnum province;

	@Column(name = "MANUFACTURER_COMPANY_CD", nullable = false, length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum") })
	private ManufacturerCompanyCodeEnum manufacturerCompany;

	/**
	 * Instantiates a new manufacturing context.
	 */
	public ManufacturingContext() {
		// NOOP
	}

	/**
	 * Instantiates a new manufacturing context.
	 * 
	 * @param distributionChannelCode the distribution channel code
	 * @param insuranceBusinessCode the insurance business code
	 * @param provinceCode the province code
	 * @param manufacturerCompany {@link ManufacturerCompanyCodeEnum}
	 */
	public ManufacturingContext(DistributionChannelCodeEnum distributionChannelCode,
			InsuranceBusinessCodeEnum insuranceBusinessCode, ProvinceCodeEnum provinceCode, ManufacturerCompanyCodeEnum manufacturerCompany) {
		setDistributionChannel(distributionChannelCode);
		setInsuranceBusiness(insuranceBusinessCode);
		setProvince(provinceCode);
		setManufacturerCompany(manufacturerCompany);
	}
	
	public ManufacturingContext(String distributionChannelCode,
			String insuranceBusinessCode, String provinceCode, String manufacturerCompany) {
		setDistributionChannel(DistributionChannelCodeEnum.valueOfCode(distributionChannelCode));
		setInsuranceBusiness(InsuranceBusinessCodeEnum.valueOfCode(insuranceBusinessCode));
		setProvince(ProvinceCodeEnum.valueOfCode(provinceCode));
		setManufacturerCompany(ManufacturerCompanyCodeEnum.valueOfCode(manufacturerCompany));
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Equals/Hashcode attributes: distributionChannel, insuranceBusiness, province.
	 * 
	 * @param object the object
	 * 
	 * @return true, if equals
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof ManufacturingContext)) {
			return false;
		}
		ManufacturingContext rhs = (ManufacturingContext) object;
		return new EqualsBuilder().appendSuper(super.equals(object)).append(this.distributionChannel,
				rhs.distributionChannel).append(this.insuranceBusiness, rhs.insuranceBusiness).append(this.province,
				rhs.province).isEquals();
	}

	/**
	 * Equals/Hashcode attributes: distributionChannel, insuranceBusiness, province.
	 * 
	 * @return the int
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return new HashCodeBuilder(138163033, -180634823).appendSuper(super.hashCode())
				.append(this.distributionChannel).append(this.insuranceBusiness).append(this.province).toHashCode();
	}

	/**
	 * Gets the distribution channel.
	 * 
	 * @return the distribution channel
	 */
	public DistributionChannelCodeEnum getDistributionChannel() {
		return this.distributionChannel;
	}

	/**
	 * Sets the distribution channel.
	 * 
	 * @param distributionChannelCode the new distribution channel
	 */
	public void setDistributionChannel(DistributionChannelCodeEnum distributionChannelCode) {
		this.distributionChannel = distributionChannelCode;
	}

	/**
	 * Gets the insurance business.
	 * 
	 * @return the insurance business
	 */
	public InsuranceBusinessCodeEnum getInsuranceBusiness() {
		return this.insuranceBusiness;
	}

	/**
	 * Sets the insurance business.
	 * 
	 * @param insuranceBusinessCode the new insurance business
	 */
	public void setInsuranceBusiness(InsuranceBusinessCodeEnum insuranceBusinessCode) {
		this.insuranceBusiness = insuranceBusinessCode;
	}

	/**
	 * Gets the province.
	 * 
	 * @return the province
	 */
	public ProvinceCodeEnum getProvince() {
		return this.province;
	}

	/**
	 * Sets the province.
	 * 
	 * @param provinceCode the new province
	 */
	public void setProvince(ProvinceCodeEnum provinceCode) {
		this.province = provinceCode;
	}

	/**
	 * Adds the municipality detail spec.
	 * 
	 * @param spec the spec
	 */
	public void addMunicipalityDetailSpecification(com.ing.canada.plp.domain.party.MunicipalityDetailSpecification spec) {
		AssociationsHelper
				.updateOneToManyFields(this, "municipalityDetailSpecifications", spec, "manufacturingContext");
	}

	/**
	 * Removes the municipality detail spec.
	 * 
	 * @param spec the spec
	 */
	public void removeMunicipalityDetailSpecification(
			com.ing.canada.plp.domain.party.MunicipalityDetailSpecification spec) {
		AssociationsHelper
				.updateOneToManyFields(null, "municipalityDetailSpecifications", spec, "manufacturingContext");
	}

	/**
	 * Adds the group repository entry.
	 * 
	 * @param entry the entry
	 */
	public void addGroupRepositoryEntry(com.ing.canada.plp.domain.party.GroupRepositoryEntry entry) {
		AssociationsHelper.updateOneToManyFields(this, "groupRepositoryEntries", entry, "manufacturingContext");
	}

	/**
	 * Removes the group repository entry.
	 * 
	 * @param entry the entry
	 */
	public void removeGroupRepositoryEntry(com.ing.canada.plp.domain.party.GroupRepositoryEntry entry) {
		AssociationsHelper.updateOneToManyFields(null, "groupRepositoryEntries", entry, "manufacturingContext");
	}

	/**
	 * Adds the vehicle detail spec repository entry.
	 * 
	 * @param entry the entry
	 */
	public void addVehicleDetailSpecificationRepositoryEntry(
			com.ing.canada.plp.domain.vehicle.VehicleDetailSpecificationRepositoryEntry entry) {
		AssociationsHelper.updateOneToManyFields(this, "vehicleDetailSpecificationRepositoryEntries", entry,
				"manufacturingContext");
	}

	/**
	 * Removes the vehicle detail spec repository entry.
	 * 
	 * @param entry the entry
	 */
	public void removeVehicleDetailSpecificationRepositoryEntry(
			com.ing.canada.plp.domain.vehicle.VehicleDetailSpecificationRepositoryEntry entry) {
		AssociationsHelper.updateOneToManyFields(null, "vehicleDetailSpecificationRepositoryEntries", entry,
				"manufacturingContext");
	}

	/**
	 * Adds the message repository entry.
	 * 
	 * @param entry the entry
	 */
	public void addMessageRepositoryEntry(com.ing.canada.plp.domain.businesstransaction.MessageRepositoryEntry entry) {
		AssociationsHelper.updateOneToManyFields(this, "messageRepositoryEntries", entry, "manufacturingContext");
	}

	/**
	 * Removes the message repository entry.
	 * 
	 * @param entry the entry
	 */
	public void removeMessageRepositoryEntry(com.ing.canada.plp.domain.businesstransaction.MessageRepositoryEntry entry) {
		AssociationsHelper.updateOneToManyFields(null, "messageRepositoryEntries", entry, "manufacturingContext");
	}

	/**
	 * Gets the manufacturer company.
	 * 
	 * @return the manufacturer company
	 */
	public ManufacturerCompanyCodeEnum getManufacturerCompany() {
		return this.manufacturerCompany;
	}

	/**
	 * Sets the manufacturer company.
	 * 
	 * @param aManufacturerCompany {@link ManufacturerCompanyCodeEnum} 
	 */
	public void setManufacturerCompany(ManufacturerCompanyCodeEnum aManufacturerCompany) {
		this.manufacturerCompany = aManufacturerCompany;
	}

	
}
