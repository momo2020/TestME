/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.policyversion;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.driver.DriverComplementInfo;
import com.ing.canada.plp.domain.enums.RelationTypeCodeEnum;
import com.ing.canada.plp.domain.insurancepolicy.InsurancePolicy;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * RelatedInsurancePolicy entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "RELATED_INSURANCE_POLICY", uniqueConstraints = {})
public class RelatedInsurancePolicy extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "RELATED_INSURANCE_POLICY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "RelatedInsurancePolicySequence")
	@SequenceGenerator(name = "RelatedInsurancePolicySequence", sequenceName = "RELATED_INSURANCE_POLICY_SEQ", allocationSize = 5)
	private Long id;

	/** The policy version. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "POLICY_VERSION_ID", updatable = true)
	private PolicyVersion policyVersion;

	/** The relation type. */
	@Column(name = "RELATION_TYPE_CD", nullable = false, length = 4)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.RelationTypeCodeEnum") })
	private RelationTypeCodeEnum relationType;

	/** The related agreement number. */
	@Column(name = "RELATED_AGREEMENT_NBR", nullable = false, length = 25)
	private String relatedAgreementNumber;

	/** The insurance policies. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "relatedInsurancePolicy")
	private Set<InsurancePolicy> insurancePolicies = new HashSet<InsurancePolicy>(0);

	/** The driver complement infos. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "relatedInsurancePolicy")
	private Set<DriverComplementInfo> driverComplementInfos = new HashSet<DriverComplementInfo>(0);

	/** The original scenario related insurance policy. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_RELATED_INS_POLICY_ID", insertable = false, updatable = false)
	private RelatedInsurancePolicy originalScenarioRelatedInsurancePolicy;

	/**
	 * Instantiates a new related insurance policy.
	 */
	public RelatedInsurancePolicy() {
		// noarg constructor
	}

	/**
	 * Instantiates a new related insurance policy.
	 * 
	 * @param relationTypeCode the relation type code
	 * @param aRelatedAgreementNumber the a related agreement number
	 */
	public RelatedInsurancePolicy(RelationTypeCodeEnum relationTypeCode, String aRelatedAgreementNumber) {
		setRelationType(relationTypeCode);
		setRelatedAgreementNumber(aRelatedAgreementNumber);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the policy version.
	 * 
	 * @return the policy version
	 */
	@XmlTransient // parent
	public PolicyVersion getPolicyVersion() {
		return this.policyVersion;
	}

	/**
	 * Sets the policy version.
	 * 
	 * @param aPolicyVersion the new policy version
	 */
	public void setPolicyVersion(PolicyVersion aPolicyVersion) {
		AssociationsHelper.updateOneToManyFields(aPolicyVersion, "relatedInsurancePolicies", this, "policyVersion");
	}

	/**
	 * Gets the relation type.
	 * 
	 * @return the relation type
	 */
	public RelationTypeCodeEnum getRelationType() {
		return this.relationType;
	}

	/**
	 * Sets the relation type.
	 * 
	 * @param relationTypeCode the new relation type
	 */
	public void setRelationType(RelationTypeCodeEnum relationTypeCode) {
		this.relationType = relationTypeCode;
	}

	/**
	 * Gets the related agreement number.
	 * 
	 * @return the related agreement number
	 */
	public String getRelatedAgreementNumber() {
		return this.relatedAgreementNumber;
	}

	/**
	 * Sets the related agreement number.
	 * 
	 * @param aRelatedAgreementNumber the new related agreement number
	 */
	public void setRelatedAgreementNumber(String aRelatedAgreementNumber) {
		this.relatedAgreementNumber = aRelatedAgreementNumber;
	}

	/**
	 * Gets the insurance policies.
	 * 
	 * @return the insurance policies
	 */
	@XmlElementWrapper(name="insurancePolicies")
	@XmlElement(name="insurancePolicy")
	public Set<InsurancePolicy> getInsurancePolicies() {
		return Collections.unmodifiableSet(this.insurancePolicies);
	}

	/**
	 * Sets the insurance policies.
	 * 
	 * @param aInsurancePolicies the new insurance policies
	 */
	protected void setInsurancePolicies(Set<InsurancePolicy> aInsurancePolicies) {
		this.insurancePolicies = aInsurancePolicies;
	}

	/**
	 * Adds the insurance policy.
	 * 
	 * @param policy the policy
	 */
	public void addInsurancePolicy(com.ing.canada.plp.domain.insurancepolicy.InsurancePolicy policy) {
		AssociationsHelper.updateOneToManyFields(this, "insurancePolicies", policy, "relatedInsurancePolicy");
	}

	/**
	 * Removes the insurance policy.
	 * 
	 * @param policy the policy
	 */
	public void removeInsurancePolicy(com.ing.canada.plp.domain.insurancepolicy.InsurancePolicy policy) {
		AssociationsHelper.updateOneToManyFields(null, "insurancePolicies", policy, "relatedInsurancePolicy");
	}

	/**
	 * Gets the driver complement infos.
	 * 
	 * @return the driver complement infos
	 */
	@XmlElementWrapper(name="driverComplementInfos")
	@XmlElement(name="driverComplementInfo")
	public Set<DriverComplementInfo> getDriverComplementInfos() {
		return Collections.unmodifiableSet(this.driverComplementInfos);
	}

	/**
	 * Sets the driver complement infos.
	 * 
	 * @param aDriverComplementInfos the new driver complement infos
	 */
	protected void setDriverComplementInfos(Set<DriverComplementInfo> aDriverComplementInfos) {
		this.driverComplementInfos = aDriverComplementInfos;
	}

	/**
	 * Adds the driver complement info.
	 * 
	 * @param info the info
	 */
	public void addDriverComplementInfo(com.ing.canada.plp.domain.driver.DriverComplementInfo info) {
		AssociationsHelper.updateOneToManyFields(this, "driverComplementInfos", info, "relatedInsurancePolicy");
	}

	/**
	 * Removes the driver complement info.
	 * 
	 * @param info the info
	 */
	public void removeDriverComplementInfo(com.ing.canada.plp.domain.driver.DriverComplementInfo info) {
		AssociationsHelper.updateOneToManyFields(null, "driverComplementInfos", info, "relatedInsurancePolicy");
	}

	/**
	 * Gets the original scenario related insurance policy.
	 * 
	 * @return the original scenario related insurance policy
	 */
	@XmlTransient // reference source
	public RelatedInsurancePolicy getOriginalScenarioRelatedInsurancePolicy() {
		return this.originalScenarioRelatedInsurancePolicy;
	}

	/**
	 * Sets the original scenario related insurance policy.
	 * 
	 * @param anOriginalScenarioRelatedInsurancePolicy the new original scenario related insurance policy
	 */
	protected void setOriginalScenarioRelatedInsurancePolicy(
			RelatedInsurancePolicy anOriginalScenarioRelatedInsurancePolicy) {
		this.originalScenarioRelatedInsurancePolicy = anOriginalScenarioRelatedInsurancePolicy;
	}

}
