/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.domain.BusinessContext;
import com.ing.canada.plp.domain.ManufacturingContext;
import com.ing.canada.plp.domain.enums.AdditionalInterestTypeCodeEnum;
import com.ing.canada.plp.domain.enums.LanguageCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.AdditionalInterestRepositoryManufacturingContext;

/**
 * The Interface IAdditionalInterestRepositoryService.
 * 
 * @author strichar
 */
public interface IAdditionalInterestRepositoryService {

	/**
	 * Gets the additional interests sorted by french name.
	 * 
	 * @param aManufacturingContext the a manufacturing context
	 * @param aAdditionalInterestType the a additional interest type
	 * 
	 * @return the additional interests sorted french
	 */
	List<AdditionalInterestRepositoryManufacturingContext> getAdditionalInterestsSortedFrench(
			ManufacturingContext aManufacturingContext, AdditionalInterestTypeCodeEnum aAdditionalInterestType);

	/**
	 * Gets the additional interests sorted sorted by english name.
	 * 
	 * @param aManufacturingContext the a manufacturing context
	 * @param aAdditionalInterestType the a additional interest type
	 * 
	 * @return the additional interests sorted english
	 */
	List<AdditionalInterestRepositoryManufacturingContext> getAdditionalInterestsSortedEnglish(
			ManufacturingContext aManufacturingContext, AdditionalInterestTypeCodeEnum aAdditionalInterestType);

	/**
	 * Gets a specific AdditionalInterestRepositoryManufacturingContext.
	 * 
	 * @param id the id
	 * 
	 * @return the additional interest
	 */
	AdditionalInterestRepositoryManufacturingContext getAdditionalInterest(Long id);

	public List<AdditionalInterestRepositoryManufacturingContext> getAdditionalInterests(BusinessContext context, LanguageCodeEnum language, 
			AdditionalInterestTypeCodeEnum interestType);

}
