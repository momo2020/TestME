package com.ing.canada.plp.service.broker.util;

public class Policy {
	
	private String policyId = null;
	
	public Policy() {
	}

	public String getId() {
		return policyId;
	}

	public void setId(String policyId) {
		this.policyId = policyId;
	}
	
	public String toString() {
		return "[policy identifier=" + this.getId() + "]";
	}

}
