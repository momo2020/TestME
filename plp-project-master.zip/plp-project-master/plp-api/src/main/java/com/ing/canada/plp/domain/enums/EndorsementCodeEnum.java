/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

/**
 * @author sbulzak
 * 
 */
public enum EndorsementCodeEnum {
	C01("C01", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C02("C02", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C03("C03", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C04("C04", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C05("C05", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C06("C06", CoverageGroupCodeEnum.YOUNG_DRIV_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	C07("C07", CoverageGroupCodeEnum.YOUNG_DRIV_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	C08("C08", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C09("C09", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C10("C10", CoverageGroupCodeEnum.MINIMUM_PREMIUM, CoverageCodeDomainEnum.CLASSIC), //
	C11("C11", CoverageGroupCodeEnum.MINIMUM_PREMIUM, CoverageCodeDomainEnum.CLASSIC), //
	C12("C12", CoverageGroupCodeEnum.MINIMUM_PREMIUM, CoverageCodeDomainEnum.CLASSIC), //
	C13("C13", CoverageGroupCodeEnum.MULTI_VEH_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	C15("C15", CoverageGroupCodeEnum.MULTI_VEH_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	C16("C16", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C22("C22", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C23("C23", CoverageGroupCodeEnum.OUT_PROV_USE, CoverageCodeDomainEnum.CLASSIC), //
	C24("C24", CoverageGroupCodeEnum.OUT_PROV_USE, CoverageCodeDomainEnum.CLASSIC), //
	C25("C25", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C26("C26", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C27("C27", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C28("C28", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C30("C30", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C31("C31", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C37("C37", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C38("C38", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C50("C50", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C51("C51", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C63("C63", CoverageGroupCodeEnum.MULTI_VEH_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	C64("C64", CoverageGroupCodeEnum.MULTI_VEH_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	C65("C65", CoverageGroupCodeEnum.MULTI_VEH_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	C67("C67", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C68("C68", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C76("C76", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C77("C77", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C89("C89", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C90("C90", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	C92("C92", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	DUO("DUO", CoverageGroupCodeEnum.DUOFLEX_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	D20("D20", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	EX0("EX0", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	F01("F01", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	BMG("BMG", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC),
	// STE- PARKING IN A DRIVEWAY
	STE("STE", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC),
	// STG- PARKING IN A SHARED INDOOR GARAGE
	STG("STG", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC),
	// STP- PARKING IN A PRIVATE INDOOR GARAGE
	STP("STP", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC),
	// STR- PARKING ON THE STREET
	STR("STR", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC),

	/** Protected value warranty */
	GVP("GVP", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC),

	/** Internet rebate */
	INTERNET_REBATE("INTERNET_REBATE", CoverageGroupCodeEnum.INTERNET_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	I50("I50", CoverageGroupCodeEnum.INTERNET_DISCNT, CoverageCodeDomainEnum.CLASSIC), //

	/** INOV for IRCA */
	H90("H90", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	E90("E90", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	
	/** AutoComfort */
	I90("I90", CoverageGroupCodeEnum.AUTOCOMFORT, CoverageCodeDomainEnum.CLASSIC), //
	I98("I98", CoverageGroupCodeEnum.AUTOCOMFORT, CoverageCodeDomainEnum.CLASSIC), //
	I99("I99", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	J06("J06", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	J07("J07", CoverageGroupCodeEnum.DRIVING_COURS_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	J08("J08", CoverageGroupCodeEnum.DRIVING_COURS_DISCNT, CoverageCodeDomainEnum.CLASSIC), //

	L02("L02", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	L17("L17", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //

	/** CAA Membership */
	MC1("MC1", CoverageGroupCodeEnum.MEMBERSHIP_CAA, CoverageCodeDomainEnum.CLASSIC), //
	MC2("MC2", CoverageGroupCodeEnum.MEMBERSHIP_CAA, CoverageCodeDomainEnum.CLASSIC), //
	MC3("MC3", CoverageGroupCodeEnum.MEMBERSHIP_CAA, CoverageCodeDomainEnum.CLASSIC), //
	MC4("MC4", CoverageGroupCodeEnum.MEMBERSHIP_CAA, CoverageCodeDomainEnum.CLASSIC), //
	MC5("MC5", CoverageGroupCodeEnum.MEMBERSHIP_CAA, CoverageCodeDomainEnum.CLASSIC), //

	MG1("MG1", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //

	/** Crash-proof and CAA Supercoverage */
	N10("N10", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	NV1("NV1", CoverageGroupCodeEnum.CRASH_PROOF, CoverageCodeDomainEnum.CLASSIC), //
	NV2("NV2", CoverageGroupCodeEnum.CRASH_PROOF_OPEN_RD, CoverageCodeDomainEnum.CLASSIC), //

	// NBD
	// Belair: THE NEW CRASH-PROOF POLICY
	// Intact: GOOD RECORD PROTECTION
	NBD("NBD", CoverageGroupCodeEnum.NEW_CRASH_PROOF, CoverageCodeDomainEnum.CLASSIC),
	NBE("NBE", CoverageGroupCodeEnum.NEW_CRASH_PROOF, CoverageCodeDomainEnum.CLASSIC),
	
	// NV3
	// Belair: THE NEW CRASH-PROOF POLICY OPEN ROAD
	// Intact: GOOD RECORD PROTECTION OPEN ROAD
	NV3("NV3", CoverageGroupCodeEnum.NEW_CRASH_PROOF_OPEN_RD, CoverageCodeDomainEnum.CLASSIC), //
	NVA("NVA", CoverageGroupCodeEnum.NEW_CRASH_PROOF_OPEN_RD, CoverageCodeDomainEnum.CLASSIC), //
	PHI("PHI", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	P01("P01", CoverageGroupCodeEnum.SPECIAL_PROMO_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	P02("P02", CoverageGroupCodeEnum.SPECIAL_PROMO_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	P03("P03", CoverageGroupCodeEnum.SPECIAL_PROMO_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	P05("P05", CoverageGroupCodeEnum.SPECIAL_PROMO_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	P06("P06", CoverageGroupCodeEnum.SPECIAL_PROMO_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	P07("P07", CoverageGroupCodeEnum.SPECIAL_PROMO_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	P08("P08", CoverageGroupCodeEnum.SPECIAL_PROMO_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	P09("P09", CoverageGroupCodeEnum.SPECIAL_PROMO_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	P21("P21", CoverageGroupCodeEnum.SPECIAL_PROMO_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	P22("P22", CoverageGroupCodeEnum.SPECIAL_PROMO_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	P25("P25", CoverageGroupCodeEnum.SPECIAL_PROMO_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	P29("P29", CoverageGroupCodeEnum.SPECIAL_PROMO_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	R01("R01", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	RCA("RCA", CoverageGroupCodeEnum.CAA_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	RC1("RC1", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	R25("R25", CoverageGroupCodeEnum.CAA_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	R26("R26", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	R27("R27", CoverageGroupCodeEnum.CAA_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	R30("R30", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	S01("S01", CoverageGroupCodeEnum.DUOFLEX_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	S55("S55", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	TXP("TXP", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	T02("T02", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	T11("T11", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	VRP("VRP", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	VR1("VR1", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	V01("V01", CoverageGroupCodeEnum.ANTI_THEFT_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	V02("V02", CoverageGroupCodeEnum.ANTI_THEFT_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	V03("V03", CoverageGroupCodeEnum.ANTI_THEFT_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	V04("V04", CoverageGroupCodeEnum.ANTI_THEFT_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	V05("V05", CoverageGroupCodeEnum.ANTI_THEFT_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	V06("V06", CoverageGroupCodeEnum.ANTI_THEFT_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	V07("V07", CoverageGroupCodeEnum.ANTI_THEFT_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	V08("V08", CoverageGroupCodeEnum.ANTI_THEFT_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	V09("V09", CoverageGroupCodeEnum.ANTI_THEFT_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	V10("V10", CoverageGroupCodeEnum.ANTI_THEFT_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	V11("V11", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	V12("V12", CoverageGroupCodeEnum.ANTI_THEFT_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	V13("V13", CoverageGroupCodeEnum.ANTI_THEFT_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	V20("V20", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	V21("V21", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	V22("V22", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	V25("V25", CoverageGroupCodeEnum.ANTI_THEFT_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	V30("V30", CoverageGroupCodeEnum.ANTI_THEFT_DISCNT, CoverageCodeDomainEnum.CLASSIC),

	/** Glass repair coverage */
	_13("13", CoverageGroupCodeEnum.GLASS_DEL_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	_13C("13C", CoverageGroupCodeEnum.GLASS_DEL_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	_13D("13D", CoverageGroupCodeEnum.GLASS_DEL_DISCNT, CoverageCodeDomainEnum.CLASSIC), //

	/** Suspension of coverage */
	_16("16", CoverageGroupCodeEnum.SUSPEND_COV, CoverageCodeDomainEnum.CLASSIC), //
	_16M("16M", CoverageGroupCodeEnum.SUSPEND_COV, CoverageCodeDomainEnum.CLASSIC),

	_17("17", CoverageGroupCodeEnum.REINST_COV, CoverageCodeDomainEnum.CLASSIC), //
	_19("19", CoverageGroupCodeEnum.VALUED_VEH, CoverageCodeDomainEnum.CLASSIC), //
	_2("2", CoverageGroupCodeEnum.DRIVER_OTH_AUTO, CoverageCodeDomainEnum.CLASSIC), //
	_20A("20A", CoverageGroupCodeEnum.LOSS_OF_USE, CoverageCodeDomainEnum.CLASSIC), //
	_20B("20B", CoverageGroupCodeEnum.LOSS_OF_USE, CoverageCodeDomainEnum.CLASSIC), //
	_20C("20C", CoverageGroupCodeEnum.LOSS_OF_USE, CoverageCodeDomainEnum.CLASSIC), //
	_20D("20D", CoverageGroupCodeEnum.LOSS_OF_USE, CoverageCodeDomainEnum.CLASSIC), //
	_20E("20E", CoverageGroupCodeEnum.LOSS_OF_USE, CoverageCodeDomainEnum.CLASSIC), //
	_20F("20F", CoverageGroupCodeEnum.LOSS_OF_USE, CoverageCodeDomainEnum.CLASSIC), //
	_25("25", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_25A("25A", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_25D("25D", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_25E("25E", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_25N("25N", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_25P("25P", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_25T("25T", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_27("27", CoverageGroupCodeEnum.RENTAL_CAR, CoverageCodeDomainEnum.CLASSIC), //
	_27A("27A", CoverageGroupCodeEnum.RENTAL_CAR, CoverageCodeDomainEnum.CLASSIC), //
	_27E("27E", CoverageGroupCodeEnum.RENTAL_CAR, CoverageCodeDomainEnum.CLASSIC), //
	_27I("27I", CoverageGroupCodeEnum.RENTAL_CAR, CoverageCodeDomainEnum.CLASSIC), //
	_28("28", CoverageGroupCodeEnum.EXCLUDED_DRIVER, CoverageCodeDomainEnum.CLASSIC),

	_3("3", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_30("30", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_31("31", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_32("32", CoverageGroupCodeEnum.RECREAT_VEH, CoverageCodeDomainEnum.CLASSIC),

	// FAQ 33E: INSURANCE FOR ROADSIDE ASSISTANCE COSTS
	_33E("33E", CoverageGroupCodeEnum.ROADSIDE_ASSISTANCE, CoverageCodeDomainEnum.CLASSIC), 
	_33N("33N", CoverageGroupCodeEnum.ROADSIDE_ASSISTANCE, CoverageCodeDomainEnum.CLASSIC),
	_34A("34A", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_34B("34B", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_37A("37A", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_37B("37B", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_4B("4B", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_40("40", CoverageGroupCodeEnum.FIRE_DEDUC, CoverageCodeDomainEnum.CLASSIC),

	/** Compensation without depreciation */
	_43("43", CoverageGroupCodeEnum.WAIVER_DEPRECIATION, CoverageCodeDomainEnum.CLASSIC), //
	_43A("43A", CoverageGroupCodeEnum.WAIVER_DEPRECIATION, CoverageCodeDomainEnum.CLASSIC), //
	_43I("43I", CoverageGroupCodeEnum.WAIVER_DEPRECIATION, CoverageCodeDomainEnum.CLASSIC), //
	_43U("43U", CoverageGroupCodeEnum.WAIVER_DEPRECIATION, CoverageCodeDomainEnum.CLASSIC),

	/** Replacement cost */
	_43V("43V", CoverageGroupCodeEnum.REPLACEMENT_COST, CoverageCodeDomainEnum.CLASSIC), //
	_43W("43W", CoverageGroupCodeEnum.REPLACEMENT_COST, CoverageCodeDomainEnum.CLASSIC), //
	_FP5("FP5", CoverageGroupCodeEnum.REPLACEMENT_COST, CoverageCodeDomainEnum.CLASSIC), //
	_18("18", CoverageGroupCodeEnum.REPLACEMENT_COST, CoverageCodeDomainEnum.CLASSIC), //
	_FPX("FPX", CoverageGroupCodeEnum.REPLACEMENT_COST, CoverageCodeDomainEnum.CLASSIC),//

	_FPU("FPU", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //

	_5("5", CoverageGroupCodeEnum.LEASE_VEH, CoverageCodeDomainEnum.CLASSIC), //
	_5A("5A", CoverageGroupCodeEnum.LEASE_VEH, CoverageCodeDomainEnum.CLASSIC), //
	_5C("5C", CoverageGroupCodeEnum.LEASE_VEH, CoverageCodeDomainEnum.CLASSIC), //
	_5D("5D", CoverageGroupCodeEnum.LEASE_VEH, CoverageCodeDomainEnum.CLASSIC),

	_8("8", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_9("9", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC),

	CPC("CPC", CoverageGroupCodeEnum.CRASH_PROOF, CoverageCodeDomainEnum.CLASSIC), //
	CPF("CPF", CoverageGroupCodeEnum.CRASH_PROOF, CoverageCodeDomainEnum.CLASSIC), //
	SPG("SPG", CoverageGroupCodeEnum.CRASH_PROOF, CoverageCodeDomainEnum.CLASSIC),

	_39("39", CoverageGroupCodeEnum.CRASH_PROOF, CoverageCodeDomainEnum.CLASSIC), //
	_39F("39F", CoverageGroupCodeEnum.CRASH_PROOF, CoverageCodeDomainEnum.CLASSIC),

	H1A("H1A", CoverageGroupCodeEnum.AUTOCOMFORT, CoverageCodeDomainEnum.CLASSIC), //
	H1B("H1B", CoverageGroupCodeEnum.AUTOCOMFORT, CoverageCodeDomainEnum.CLASSIC), //
	H1C("H1C", CoverageGroupCodeEnum.AUTOCOMFORT, CoverageCodeDomainEnum.CLASSIC), //
	H1D("H1D", CoverageGroupCodeEnum.AUTOCOMFORT, CoverageCodeDomainEnum.CLASSIC),

	_6A("6A", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_20("20", CoverageGroupCodeEnum.TRANSP_REPLAC, CoverageCodeDomainEnum.CLASSIC), //
	_23A("23A", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_28A("28A", CoverageGroupCodeEnum.EXCLUDED_DRIVER, CoverageCodeDomainEnum.CLASSIC), //
	_38("38", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC),

	_44("44", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_47("47", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC),

	S0H("S0H", CoverageGroupCodeEnum.DUOFLEX_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	S0T("S0T", CoverageGroupCodeEnum.DUOFLEX_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	S0C("S0C", CoverageGroupCodeEnum.DUOFLEX_DISCNT, CoverageCodeDomainEnum.CLASSIC),

	MAO("MAO", CoverageGroupCodeEnum.MULTI_VEH_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	MVD("MVD", CoverageGroupCodeEnum.MULTI_VEH_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	MV2("MV2", CoverageGroupCodeEnum.MULTI_VEH_DISCNT, CoverageCodeDomainEnum.CLASSIC),

	CDC("CDC", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	IR1("IR1", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	IR2("IR2", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	IR3("IR3", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	DFB("DFB", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	FRC("FRC", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	G2O("G2O", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	G2P("G2P", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	G2N("G2N", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	IND("IND", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	MDL("MDL", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	RET("RET", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	UNI("UNI", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	_101("101", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	COM("COM", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	EDP("EDP", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC),

	HP1("HP1", CoverageGroupCodeEnum.PLEASURE_OUT_PROV, CoverageCodeDomainEnum.CLASSIC), //
	HP2("HP2", CoverageGroupCodeEnum.PLEASURE_OUT_PROV, CoverageCodeDomainEnum.CLASSIC), //
	HP3("HP3", CoverageGroupCodeEnum.PLEASURE_OUT_PROV, CoverageCodeDomainEnum.CLASSIC), //
	HP4("HP4", CoverageGroupCodeEnum.PLEASURE_OUT_PROV, CoverageCodeDomainEnum.CLASSIC),

	HB1("HB1", CoverageGroupCodeEnum.BUSINESS_OUT_PROV, CoverageCodeDomainEnum.CLASSIC), //
	HB2("HB2", CoverageGroupCodeEnum.BUSINESS_OUT_PROV, CoverageCodeDomainEnum.CLASSIC), //
	HB3("HB3", CoverageGroupCodeEnum.BUSINESS_OUT_PROV, CoverageCodeDomainEnum.CLASSIC), //
	HB4("HB4", CoverageGroupCodeEnum.BUSINESS_OUT_PROV, CoverageCodeDomainEnum.CLASSIC),

	VMO("VMO", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC),

	WIN("WIN", CoverageGroupCodeEnum.WINTER_TIRE_DISCNT, CoverageCodeDomainEnum.CLASSIC), //
	WIO("WIO", CoverageGroupCodeEnum.WINTER_TIRE_DISCNT, CoverageCodeDomainEnum.CLASSIC), WTD("WTD",
			CoverageGroupCodeEnum.WINTER_TIRE_DISCNT, CoverageCodeDomainEnum.CLASSIC),

	// NAB - New Accident Benefits
	NAB("NAB", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC),

	// Accident Benefits Combos
	MBA("MBA", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	MID("MID", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	CHD("CHD", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	MAC("MAC", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC),

	// Grid discount - Endorsement
	GRD("GRD", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //
	GRO("GRO", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC),

	// CVI discount - Endorsement
	CVI("CVI", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), //

	// UBI Enrollment - Endorsements
	UBI("UBI", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC), UBO("UBO",
			CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC),

	ACCB_SAV("ACCB", CoverageGroupCodeEnum.BSC_COV_ACC_BENEF, CoverageCodeDomainEnum.SAVERS),

	// Savers Coverage Codes for INTACT Ontario/Alberta (as in spec)
	_5_SAV("5", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_05_SAV("05", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_13_SAV("13", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_13C_SAV("13C", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_13D_SAV("13D", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_20_SAV("20", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_23A_SAV("23A", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_27_SAV("27", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_27A_SAV("27A", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_35_SAV("35", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_38_SAV("38", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_39_SAV("CSE", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_39F_SAV("CSF", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_40_SAV("40", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_43_SAV("43", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_43A_SAV("43A", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	ACHV_SAV("ACHV", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	RDP_SAV("RDP", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	PPC_SAV("PPC", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	PPD_SAV("PPD", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	EPCE_SAV("EPCE", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	UE05("UE05", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), // UBI endorsement for Ontario
																						// And Alberta

	// additional coverages
	_03_SAV("03", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_2MVD_SAV("2MVD", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_43L_SAV("43L", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_43R_SAV("43R", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_44_SAV("44", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_48_SAV("48", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	_49F_SAV("49F", CoverageGroupCodeEnum.CLAIMS_ADVNTG, CoverageCodeDomainEnum.SAVERS), //
	_49Y_SAV("49Y", CoverageGroupCodeEnum.CLAIMS_ADVNTG, CoverageCodeDomainEnum.SAVERS), //
	_50F_SAV("50F", CoverageGroupCodeEnum.CLAIMS_ADVNTG, CoverageCodeDomainEnum.SAVERS), //
	_50Y_SAV("50Y", CoverageGroupCodeEnum.CLAIMS_ADVNTG, CoverageCodeDomainEnum.SAVERS), //
	_H17_SAV("H17", CoverageGroupCodeEnum.HAIL_COV, CoverageCodeDomainEnum.SAVERS), //
	_H18_SAV("H18", CoverageGroupCodeEnum.HAIL_COV, CoverageCodeDomainEnum.SAVERS), //
	APIP_SAV("APIP", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	PIP_SAV("PIP", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	CDC_SAV("CDC", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	CNVO_SAV("CNVO", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	CNVP_SAV("CNVP", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	DFB_SAV("DFB", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	ETCH_SAV("ETCH", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	EXPR_SAV("EXPR", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	FAM_SAV("FAM", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	GAP_SAV("GAP", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	GOOD_SAV("GOOD", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	GRAD_SAV("GRAD", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	GROUP_SAV("GROUP", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	HPP_SAV("HPP", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	HYBD_SAV("HYBD", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	IND_SAV("IND", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	IPP_SAV("IPP", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	IPX_SAV("IPX", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	IR_SAV("IR", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	MDL_SAV("MDL", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	NBLD_SAV("NBLD", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	O16_SAV("O16", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	O17_SAV("O17", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	O6A_SAV("O6A", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	OGRAD_SAV("OGRAD", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	PMPD_SAV("PMPD", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	PPA_SAV("PPA", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	PPB_SAV("PPB", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	RDC_SAV("RDC", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	RDG_SAV("RDG", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	RDW_SAV("RDW", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	RDX_SAV("RDX", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	RETD_SAV("RETD", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	RNWL_SAV("RNWL", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	THEFT_SAV("THEFT", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	TRAC_SAV("TRAC", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	UNIV_SAV("UNIV", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	CFE_SAV("CFE", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	CFF_SAV("CFF", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	DISGS_SAV("DISGS", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	DISOC_SAV("DISOC", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //

	// RELY Discount ***POSTPONED***
	// RELY("RLY", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS),

	// Savers 'marketing' discount indicators
	ZZZMV_SAV("ZZZMV", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	ZZZEP_SAV("ZZZEP", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	ZZZEO_SAV("ZZZEO", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	ZZZCP_SAV("ZZZCP", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	ZZZCO_SAV("ZZZCO", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	ZZZDP_SAV("ZZZDP", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS), //
	ZZZDO_SAV("ZZZDO", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS),

	/** Hail Coverage Removal for Alberta */
	H06("H06", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.CLASSIC),

	/** Winter tire for Ontario */
	WINT_SAV("WINT", CoverageGroupCodeEnum.STANDALONE_END, CoverageCodeDomainEnum.SAVERS),

	/** BC Classic Codes **/
	UM2("UM2", CoverageGroupCodeEnum.EXCESS_UMP, CoverageCodeDomainEnum.CLASSIC), // Excess Underinsured Motorist (UMP)
																					// Protection, 1M
	UM3("UM3", CoverageGroupCodeEnum.EXCESS_UMP, CoverageCodeDomainEnum.CLASSIC), // Excess Underinsured Motorist (UMP)
																					// Protection, 2M
	UM4("UM4", CoverageGroupCodeEnum.EXCESS_UMP, CoverageCodeDomainEnum.CLASSIC), // Excess Underinsured Motorist (UMP)
																					// Protection, 3M
	UM5("UM5", CoverageGroupCodeEnum.EXCESS_UMP, CoverageCodeDomainEnum.CLASSIC), // Excess Underinsured Motorist (UMP)
																					// Protection, 4M

	H1E("H1E", CoverageGroupCodeEnum.AUTOCOMFORT, CoverageCodeDomainEnum.CLASSIC), // AutoComfort
	H1F("H1F", CoverageGroupCodeEnum.AUTOCOMFORT, CoverageCodeDomainEnum.CLASSIC), // AutoComfort
	H1G("H1G", CoverageGroupCodeEnum.AUTOCOMFORT, CoverageCodeDomainEnum.CLASSIC), // AutoComfort

	_13R("13R", CoverageGroupCodeEnum.WINDSHIELD_REPAIR, CoverageCodeDomainEnum.CLASSIC); // Windshield Repair Coverage

	/** The Constant SAVERS_MANUFACTURERS. */
	private static final List<ManufacturerCompanyCodeEnum> SAVERS_MANUFACTURERS = new ArrayList<ManufacturerCompanyCodeEnum>(
			Arrays.asList(ManufacturerCompanyCodeEnum.ING_CENTRAL_ATLANTIC_REGION,
					ManufacturerCompanyCodeEnum.ING_WESTERN_REGION));

	/** Set of codes for endorsements that are for SAVERS Ontario */
	private static final Set<EndorsementCodeEnum> ONTARIO_SAVERS_ENDORSEMENTS = new HashSet<EndorsementCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		{
			add(_5_SAV);
			add(_13C_SAV);
			add(_20_SAV);
			add(_23A_SAV);
			add(_27A_SAV);
			add(_35_SAV);
			add(_40_SAV);
			add(_43_SAV);
			add(_43A_SAV);
			add(_44_SAV);
			add(ACHV_SAV);
			add(RDP_SAV);
			add(PPC_SAV);
			add(EPCE_SAV);
			add(PPD_SAV);
			add(_49F_SAV);
			add(_49Y_SAV);
			add(_50F_SAV);
			add(_50Y_SAV);
		}
	};

	/** Set of codes for discounts that are for SAVERS */
	private static final Set<EndorsementCodeEnum> ONTARIO_SAVERS_DISCOUNTS = new HashSet<EndorsementCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		{
			add(UNIV_SAV);
			add(GOOD_SAV);
			add(GRAD_SAV);
			add(OGRAD_SAV);
			add(NBLD_SAV);
			add(RETD_SAV);
			add(THEFT_SAV);
			add(ETCH_SAV);
			add(TRAC_SAV);
			add(APIP_SAV);
			add(HYBD_SAV);

			add(WINT_SAV);

			// add(RELY);

			// not uploaded discounts
			add(ZZZMV_SAV);
			add(ZZZEP_SAV);
			add(ZZZEO_SAV);
			add(ZZZCP_SAV);
			add(ZZZCO_SAV);
			add(ZZZDP_SAV);
			add(ZZZDO_SAV);
		}
	};

	/** Set of codes for endorsements that are for SAVERS Alberta */
	private static final Set<EndorsementCodeEnum> ALBERTA_SAVERS_ENDORSEMENTS = new HashSet<EndorsementCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 2L;
		{
			add(_5_SAV);
			add(_13D_SAV);
			add(_20_SAV);
			add(_23A_SAV);
			add(_27A_SAV);
			add(_35_SAV);
			add(_39_SAV);
			add(_39F_SAV);
			add(CFE_SAV);
			add(CFF_SAV);
			add(_43R_SAV);
			add(_43L_SAV);
			add(_44_SAV);
			add(PPA_SAV);
			add(PPB_SAV);
			add(_49F_SAV);
			add(_49Y_SAV);
			add(_50F_SAV);
			add(_50Y_SAV);
			add(_H17_SAV);
			add(_H18_SAV);
		}
	};

	/** Set of codes for discounts that are for SAVERS */
	private static final Set<EndorsementCodeEnum> ALBERTA_SAVERS_DISCOUNTS = new HashSet<EndorsementCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 2L;
		{
			add(DISGS_SAV);
			add(HYBD_SAV);

			// not uploaded discounts
			add(RNWL_SAV);
			add(DISOC_SAV);
			add(APIP_SAV);
			add(PIP_SAV);
			add(ZZZMV_SAV);
			add(ZZZEP_SAV);
			add(ZZZEO_SAV);
			add(ZZZCP_SAV);
			add(ZZZCO_SAV);
			add(ZZZDP_SAV);
			add(ZZZDO_SAV);
		}
	};
	
	/** Set of codes for of endorsement UNDERINSURED MOTORIST PROTECTION */
	private static final Set<EndorsementCodeEnum> LIST_UMP = new HashSet<EndorsementCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		{
			add(UM2);
			add(UM3);
			add(UM4);
			add(UM5);
		}
	};
	
	/**
	 * Gets the Savers endorsement set.
	 * 
	 * @return Savers endorsement set.
	 */
	public static Set<EndorsementCodeEnum> getSaversEndorsementsSet(ProvinceCodeEnum province) {
		switch (province) {
		case ONTARIO:
			return Collections.unmodifiableSet(ONTARIO_SAVERS_ENDORSEMENTS);
		case ALBERTA:
			return Collections.unmodifiableSet(ALBERTA_SAVERS_ENDORSEMENTS);
		default:
			throw new RuntimeException("No savers endorsements defined for province " + province);
		}
	}

	/**
	 * Gets the Savers discounts set.
	 * 
	 * @return Savers discounts set.
	 */
	public static Set<EndorsementCodeEnum> getSaversDiscountsSet(ProvinceCodeEnum province) {
		switch (province) {
		case ONTARIO:
			return Collections.unmodifiableSet(ONTARIO_SAVERS_DISCOUNTS);
		case ALBERTA:
			return Collections.unmodifiableSet(ALBERTA_SAVERS_DISCOUNTS);
		default:
			throw new RuntimeException("No savers discounts defined for province " + province);
		}

	}
	
	/**
	 * @param province
	 * @return
	 */
	public static Set<EndorsementCodeEnum> getListUnderinsuredMotoristProtection() {
		return Collections.unmodifiableSet(LIST_UMP);
	}

	private EndorsementCodeEnum(String aCode, CoverageGroupCodeEnum aGroup, CoverageCodeDomainEnum aCoverageCodeDomain) {
		this.code = aCode;
		this.group = aGroup;
		this.coverageCodeDomain = aCoverageCodeDomain;
	}

	private String code = null;

	private CoverageGroupCodeEnum group = null;

	private CoverageCodeDomainEnum coverageCodeDomain = null;

	public String getCode() {
		return this.code;
	}

	public CoverageGroupCodeEnum getGroup() {
		return this.group;
	}

	public static EndorsementCodeEnum valueOfCode(String value, ManufacturerCompanyCodeEnum manufacturerCompanyCodeEnum) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		// Since the coverage codes may overlap because we use Classic and Savers coverage code domains, we must
		// discriminate by choosing which domain to apply. By default CAR(ING_CENTRAL_ATLANTIC_REGION and ING_WESTERN)
		// goes to Savers,
		// and all others go to Classic.
		if (manufacturerCompanyCodeEnum == null || !SAVERS_MANUFACTURERS.contains(manufacturerCompanyCodeEnum)) {
			for (EndorsementCodeEnum v : values()) {
				if (v.code.equals(value) && v.coverageCodeDomain.equals(CoverageCodeDomainEnum.CLASSIC)) {
					return v;
				}
			}
		} else {
			for (EndorsementCodeEnum v : values()) {
				if (v.code.equals(value) && v.coverageCodeDomain.equals(CoverageCodeDomainEnum.SAVERS)) {
					return v;
				}
			}
		}

		return null;

	}

}
