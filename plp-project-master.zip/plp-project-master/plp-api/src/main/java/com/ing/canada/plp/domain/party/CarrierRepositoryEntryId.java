/**
 * 
 */
package com.ing.canada.plp.domain.party;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;

/**
 * CarrierRepEntryId entity.
 * 
 * @author ub8169
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Embeddable
public class CarrierRepositoryEntryId implements java.io.Serializable {

	// Fields
	private static final long serialVersionUID = 1L;

	@Column(name = "CARRIER_CD", nullable = false, length = 6)
	private String carrierCd;

	@Column(name = "PROVINCE_CD", nullable = false, length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ProvinceCodeEnum") })
	private ProvinceCodeEnum provinceCd;

	/** The manufacturer code. */
	@Column(name = "MANUFACTURER_COMPANY_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum") })
	private ManufacturerCompanyCodeEnum manufacturerCompanyCode;

	/** default constructor */
	public CarrierRepositoryEntryId() {
		// Nothing to do
	}

	/** 
	 * full constructor
	 * 
	 * @deprecated use constructor with ManufacturerCompanyCode
	 */
	@Deprecated
	public CarrierRepositoryEntryId(String aCarrierCd, ProvinceCodeEnum aProvinceCd) {
		this.carrierCd = aCarrierCd;
		this.provinceCd = aProvinceCd;
	}

	/**
	 * Instantiates a new carrier repository entry id.
	 * 
	 * @param aCarrierCd the a carrier cd
	 * @param aProvinceCd the a province cd
	 * @param manufacturerCompanyCode the manufacturer company code
	 */
	public CarrierRepositoryEntryId(String aCarrierCd, ProvinceCodeEnum aProvinceCd, ManufacturerCompanyCodeEnum aManufacturerCompanyCode) {
		this.carrierCd = aCarrierCd;
		this.provinceCd = aProvinceCd;
		this.manufacturerCompanyCode = aManufacturerCompanyCode; 
	}
	
	/**
	 * Gets the carrier cd.
	 * 
	 * @return the carrier cd
	 */
	public String getCarrierCd() {
		return this.carrierCd;
	}

	/**
	 * Sets the carrier cd.
	 * 
	 * @param aCarrierCd the new carrier cd
	 */
	public void setCarrierCd(String aCarrierCd) {
		this.carrierCd = aCarrierCd;
	}

	/**
	 * Gets the province cd.
	 * 
	 * @return the province cd
	 */
	public ProvinceCodeEnum getProvinceCd() {
		return this.provinceCd;
	}

	/**
	 * Sets the province cd.
	 * 
	 * @param aProvinceCd the new province cd
	 */
	public void setProvinceCd(ProvinceCodeEnum aProvinceCd) {
		this.provinceCd = aProvinceCd;
	}

	/**
	 * Gets the manufacturer company code.
	 * 
	 * @return the manufacturer company code
	 */
	public ManufacturerCompanyCodeEnum getManufacturerCompanyCode() {
		return this.manufacturerCompanyCode;
	}

	/**
	 * Sets the manufacturer company code.
	 * 
	 * @param aManufacturerCompanyCode the new manufacturer company code
	 */
	public void setManufacturerCompanyCode(ManufacturerCompanyCodeEnum aManufacturerCompanyCode) {
		this.manufacturerCompanyCode = aManufacturerCompanyCode;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}

		if (other == null) {
			return false;
		}

		if (!(other instanceof CarrierRepositoryEntryId)) {
			return false;
		}

		CarrierRepositoryEntryId castOther = (CarrierRepositoryEntryId) other;

		return ((this.getCarrierCd() == castOther.getCarrierCd()) || (this.getCarrierCd() != null
				&& castOther.getCarrierCd() != null && this.getCarrierCd().equals(castOther.getCarrierCd())))
				&& ((this.getProvinceCd() == castOther.getProvinceCd()) || (this.getProvinceCd() != null
						&& castOther.getProvinceCd() != null && this.getProvinceCd().equals(castOther.getProvinceCd())))
				&& ((this.getManufacturerCompanyCode() == castOther.getManufacturerCompanyCode()) || (this
						.getManufacturerCompanyCode() != null
						&& castOther.getManufacturerCompanyCode() != null && this.getManufacturerCompanyCode().equals(
						castOther.getManufacturerCompanyCode())));
	}

	/**
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		int result = 17;

		result = 37 * result + (getCarrierCd() == null ? 0 : this.getCarrierCd().hashCode());
		result = 37 * result + (getProvinceCd() == null ? 0 : this.getProvinceCd().hashCode());
		result = 37 * result
				+ (getManufacturerCompanyCode() == null ? 0 : this.getManufacturerCompanyCode().hashCode());
		return result;
	}

}
