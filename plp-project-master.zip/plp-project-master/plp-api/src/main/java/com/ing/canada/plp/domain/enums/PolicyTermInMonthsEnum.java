/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;


/**
 * The Enum PolicyTermInMonthsEnum.
 */
public enum PolicyTermInMonthsEnum {

	SIX_MONTHS(new Integer(6)), 
	TWELVE_MONTHS(new Integer(12)), 
	TWENTYFOUR_MONTHS(new Integer(24));

	/**
	 * Instantiates a new policy term in months enum.
	 * 
	 * @param aCode the a code
	 */
	private PolicyTermInMonthsEnum(Integer aCode) {
		this.code = aCode;
	}

	/** The code. */
	private Integer code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public Integer getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the policy term in months enum
	 */
	public static PolicyTermInMonthsEnum valueOfCode(Integer value) {

		if (value == null) {
			return null;
		}

		for (PolicyTermInMonthsEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
