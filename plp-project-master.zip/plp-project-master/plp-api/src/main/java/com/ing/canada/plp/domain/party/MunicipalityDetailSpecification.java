/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.party;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.ManufacturingContext;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * MunicipalityDetailSpecification entity.
 * 
 * @author Patrick Lafleur
 * 
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "MUNICIPALITY_DETAIL_SPEC", uniqueConstraints = {})
public class MunicipalityDetailSpecification extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "MUNICIPALITY_DETAIL_SPEC_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "MunicipalityDetailSpecSequence")
	@SequenceGenerator(name = "MunicipalityDetailSpecSequence", sequenceName = "MUNICIPALITY_DETAIL_SPEC_SEQ", allocationSize = 5)
	private Long id;

	/** The manufacturing context. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "MANUFACTURING_CONTEXT_ID", updatable = true)
	private ManufacturingContext manufacturingContext;

	/** The municipality repository entry. */
	@ManyToOne(cascade = { CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name = "MUNICIPALITY_RPSTRY_ENTRY_ID", nullable = false, updatable = true)
	private MunicipalityRepositoryEntry municipalityRepositoryEntry;

	/** The facility risk sharing pool scoring. */
	@Column(name = "FCLTY_RSK_SHR_POOL_SCORING_QTY", precision = 2, scale = 0)
	private Byte facilityRiskSharingPoolScoring;

	/** The automobile territory stat. */
	@Column(name = "AUTOMOBILE_TERRITORY_STAT_CD", length = 3)
	private String automobileTerritoryStat;

	/** The municipal adjustment auto. */
	@Column(name = "MUNICIPAL_ADJUSTMENT_AUTO_CD", length = 1)
	private String municipalAdjustmentAuto;

	/** The automobile territory rating. */
	@Column(name = "AUTOMOBILE_TERRITORY_RATING_CD", length = 2, scale = 0)
	private Integer automobileTerritoryRating;

	/** The prohibited municipality indicator auto. */
	@Column(name = "PROHIBITED_MNCPL_AUTO_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean prohibitedMunicipalityAutoIndicator;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", length = 7)
	private Date effectiveDate;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;

	/**
	 * Instantiates a new municipality detail spec.
	 */
	public MunicipalityDetailSpecification() {
		// noarg constructor
	}

	/**
	 * Instantiates a new municipality detail spec.
	 * 
	 * @param aMunicipalityRepositoryEntry the a municipality repository entry
	 */
	public MunicipalityDetailSpecification(MunicipalityRepositoryEntry aMunicipalityRepositoryEntry) {
		setMunicipalityRepositoryEntry(aMunicipalityRepositoryEntry);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the manufacturing context.
	 * 
	 * @return the manufacturing context
	 */
	public ManufacturingContext getManufacturingContext() {
		return this.manufacturingContext;
	}

	/**
	 * Sets the manufacturing context.
	 * 
	 * @param aManufacturingContext the new manufacturing context
	 */
	public void setManufacturingContext(ManufacturingContext aManufacturingContext) {
		this.manufacturingContext = aManufacturingContext;
	}

	/**
	 * Gets the municipality repository entry.
	 * 
	 * @return the municipality repository entry
	 */
	public MunicipalityRepositoryEntry getMunicipalityRepositoryEntry() {
		return this.municipalityRepositoryEntry;
	}

	/**
	 * Sets the municipality repository entry.
	 * 
	 * @param aMunicipalityRepositoryEntry the new municipality repository entry
	 */
	public void setMunicipalityRepositoryEntry(MunicipalityRepositoryEntry aMunicipalityRepositoryEntry) {
		this.municipalityRepositoryEntry = aMunicipalityRepositoryEntry;
	}

	/**
	 * Gets the facility risk sharing pool scoring.
	 * 
	 * @return the facility risk sharing pool scoring
	 */
	public Byte getFacilityRiskSharingPoolScoring() {
		return this.facilityRiskSharingPoolScoring;
	}

	/**
	 * Sets the facility risk sharing pool scoring.
	 * 
	 * @param fcltyRskShrPoolScoring the new facility risk sharing pool scoring
	 */
	public void setFacilityRiskSharingPoolScoring(Byte fcltyRskShrPoolScoring) {
		this.facilityRiskSharingPoolScoring = fcltyRskShrPoolScoring;
	}

	/**
	 * Gets the automobile territory stat.
	 * 
	 * @return the automobile territory stat
	 */
	public String getAutomobileTerritoryStat() {
		return this.automobileTerritoryStat;
	}

	/**
	 * Sets the automobile territory stat.
	 * 
	 * @param automobileTerritoryStatCode the new automobile territory stat
	 */
	public void setAutomobileTerritoryStat(String automobileTerritoryStatCode) {
		this.automobileTerritoryStat = automobileTerritoryStatCode;
	}

	/**
	 * Gets the municipal adjustment auto.
	 * 
	 * @return the municipal adjustment auto
	 */
	public String getMunicipalAdjustmentAuto() {
		return this.municipalAdjustmentAuto;
	}

	/**
	 * Sets the municipal adjustment auto.
	 * 
	 * @param municipalAdjustmentAutoCode the new municipal adjustment auto
	 */
	public void setMunicipalAdjustmentAuto(String municipalAdjustmentAutoCode) {
		this.municipalAdjustmentAuto = municipalAdjustmentAutoCode;
	}

	/**
	 * Gets the automobile territory rating.
	 * 
	 * @return the automobile territory rating
	 */
	public Integer getAutomobileTerritoryRating() {
		return this.automobileTerritoryRating;
	}

	/**
	 * Sets the automobile territory rating.
	 * 
	 * @param automobileTerritoryRatingCode the new automobile territory rating
	 */
	public void setAutomobileTerritoryRating(Integer automobileTerritoryRatingCode) {
		this.automobileTerritoryRating = automobileTerritoryRatingCode;
	}

	/**
	 * Gets the prohibited municipality indicator auto.
	 * 
	 * @return the prohibited municipality indicator auto
	 */
	public Boolean getProhibitedMunicipalityAutoIndicator() {
		return this.prohibitedMunicipalityAutoIndicator;
	}

	/**
	 * Sets the prohibited municipality indicator auto.
	 * 
	 * @param prohibitedMncplAutoIndicator the new prohibited municipality indicator auto
	 */
	public void setProhibitedMunicipalityAutoIndicator(Boolean prohibitedMncplAutoIndicator) {
		this.prohibitedMunicipalityAutoIndicator = prohibitedMncplAutoIndicator;
	}

	/**
	 * Gets the effective date.
	 * 
	 * @return the effective date
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * Sets the effective date.
	 * 
	 * @param aEffectiveDate the new effective date
	 */
	public void setEffectiveDate(Date aEffectiveDate) {
		this.effectiveDate = aEffectiveDate;
	}

	/**
	 * Gets the expiry date.
	 * 
	 * @return the expiry date
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * Sets the expiry date.
	 * 
	 * @param aExpiryDate the new expiry date
	 */
	public void setExpiryDate(Date aExpiryDate) {
		this.expiryDate = aExpiryDate;
	}
}
