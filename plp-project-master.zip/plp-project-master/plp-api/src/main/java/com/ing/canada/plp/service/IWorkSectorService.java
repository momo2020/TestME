package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.domain.BusinessContext;
import com.ing.canada.plp.domain.enums.PartyGroupTypeCodeEnum;
import com.ing.canada.plp.domain.party.GroupRepositoryEntry;

public interface IWorkSectorService extends ICRUDService<GroupRepositoryEntry> {

	public List<GroupRepositoryEntry> findWorkSectors(BusinessContext businessContext, PartyGroupTypeCodeEnum code);

	public List<GroupRepositoryEntry> findOccupations(BusinessContext businessContext, String workSector);

	public GroupRepositoryEntry findWorkSector(BusinessContext businessContext, String occupationCode);

}
