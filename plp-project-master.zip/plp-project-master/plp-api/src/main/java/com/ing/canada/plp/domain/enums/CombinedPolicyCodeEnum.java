/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum CombinedPolicyCodeEnum.
 */
public enum CombinedPolicyCodeEnum {

	COMBO_POLICY("C"), MONOLINE_POLICY("M"), COMBO_POLICY_TO_BE_APPLIED_AT_RENEWAL("R"), PIP_POLICY("P");

	/**
	 * Instantiates a new combined policy code enum.
	 * 
	 * @param aCode the a code
	 */
	private CombinedPolicyCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the combined policy code enum
	 */
	public static CombinedPolicyCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (CombinedPolicyCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
