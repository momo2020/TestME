/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2017, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import java.util.Set;

import com.ing.canada.plp.domain.coverage.CoverageOption;
import com.ing.canada.plp.domain.coverage.CoverageRepositoryEntry;
import com.ing.canada.plp.domain.enums.BasicCoverageCodeEnum;
import com.ing.canada.plp.domain.enums.CoverageGroupCodeEnum;
import com.ing.canada.plp.domain.enums.EndorsementCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.CoverageOffer;

/**
 * Interface for the coverage option helper.
 *
 * @author <a href="mailto:pascal.meunier@intact.net">Pascal Meunier</a>
 *
 */
public interface ICoverageOptionHelper {

	/**
	 * Find a matching set of coverage options to a set of coverage offers for a specific coverage group code.
	 *
	 * @param covOptions the set of coverage options.
	 * @param covOffers the set of coverage offers
	 * @param coverageGroupCodeEnum {@link CoverageGroupCodeEnum}
	 *
	 * @return the non-null set of coverage options, empty when none are matched.
	 */
	Set<CoverageOption> match(final Set<CoverageOption> covOptions, final Set<CoverageOffer> covOffers, final CoverageGroupCodeEnum coverageGroupCodeEnum);

	/**
	 * Find a matching set of coverage options to a set of coverage offers for a specific coverage code.
	 *
	 * @param covOptions the set of coverage options.
	 * @param covOffers the set of coverage offers
	 * @param coverageCode {@link BasicCoverageCodeEnum}
	 *
	 * @return the non-null set of coverage options, empty when none are matched.
	 */
	Set<CoverageOption> match(final Set<CoverageOption> covOptions, final Set<CoverageOffer> covOffers, final BasicCoverageCodeEnum coverageCode);

	/**
	 * Find the matching coverage option from a collection of coverage offers for a sepcific endorsement code.
	 *
	 * @param covOptions the set of {@linkplain CoverageOption}s
	 * @param covOffers the set of {@linkplain CoverageOffer}s
	 * @param endorsementCode {@link EndorsementCodeEnum}
	 *
	 * @return the found {@link CoverageOption} otherwise null
	 */
	CoverageOption matchSingle(final Set<CoverageOption> covOptions, final Set<CoverageOffer> covOffers, final EndorsementCodeEnum endorsementCode);

	/**
	 * Find the matching coverage option from a collection of coverage offers for a sepcific coverage group code.
	 *
	 * @param covOptions the set of {@linkplain CoverageOption}s
	 * @param covOffers the set of {@linkplain CoverageOffer}s
	 * @param covGroupCode {@link CoverageGroupCodeEnum}
	 *
	 * @return the found {@link CoverageOption} otherwise null
	 */
	CoverageOption matchSingle(final Set<CoverageOption> covOptions, final Set<CoverageOffer> covOffers, final CoverageGroupCodeEnum covGroupCode);

	/**
	 * Find a coverage option matching the provided coverage repository entry
	 * .
	 * @param covOptions the set of {@@ CoverageOption}s to search
	 * @param coverageRepositoryEntry the {@link CoverageRepositoryEntry} to match
	 *
	 * @return the found {@link CoverageOption} null otherwise
	 */
	CoverageOption find(final Set<CoverageOption> covOptions, final CoverageRepositoryEntry coverageRepositoryEntry);
}
