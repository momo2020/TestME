package com.ing.canada.plp.report.insurancePolicy;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.enums.UserActivityTypeCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * This class is used to build a real time insurance policy info list for report to brokers.
 */

@Entity
public class InsurancePolicyNoteInfo extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
	/** The id. */
	@Id
	private Long id;
	
	/** The note. */
	private String note;
	
	/** The author uid. */
	private String authorUID;
	
	/** The user activity type. */
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.UserActivityTypeCodeEnum") })
	private UserActivityTypeCodeEnum userActivityType;


	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}
	
	/**
	 * Gets the note.
	 * 
	 * @return the note
	 */
	public String getNote() {
		return this.note;
	}

	/**
	 * Sets the note.
	 * 
	 * @param aNote the new note
	 */
	public void setNote(String aNote) {
		this.note = aNote;
	}

	/**
	 * Gets the author uid.
	 * 
	 * @return the author uid
	 */
	public String getAuthorUID() {
		return this.authorUID;
	}

	/**
	 * Sets the author uid.
	 * 
	 * @param authorUID the new author uid
	 */
	public void setAuthorUID(String aAuthorUID) {
		this.authorUID = aAuthorUID;
	}

	/**
	 * Gets the user activity type.
	 * 
	 * @return the user activity type
	 */
	public UserActivityTypeCodeEnum getUserActivityType() {
		return this.userActivityType;
	}

	/**
	 * Sets the user activity type.
	 * 
	 * @param userActivityType the new user activity type
	 */
	public void setUserActivityType(UserActivityTypeCodeEnum aUserActivityType) {
		this.userActivityType = aUserActivityType;
	}
}
