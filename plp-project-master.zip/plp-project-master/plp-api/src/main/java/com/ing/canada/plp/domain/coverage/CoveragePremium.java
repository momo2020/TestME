/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.coverage;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.insurancerisk.RatingRisk;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * CoveragePremium entity.
 * 
 * @author Patrick Lafleur
 */
@Entity
@Table(name = "COVERAGE_PREMIUM", uniqueConstraints = {})
public class CoveragePremium extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "COVERAGE_PREMIUM_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "CoveragePremiumSequence")
	@SequenceGenerator(name = "CoveragePremiumSequence", sequenceName = "COVERAGE_PREMIUM_SEQ", allocationSize = 5)
	private Long id;

	/** The rating risk. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "RATING_RISK_ID", nullable = false, updatable = true)
	private RatingRisk ratingRisk;

	/** The coverage. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "COVERAGE_ID", nullable = false, updatable = true)
	private Coverage coverage;

	/** The annual premium amount. */
	@Column(name = "ANNUAL_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer annualPremium;

	/** The full term premium amount. */
	@Column(name = "FULL_TERM_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer fullTermPremium;

	/** The additional return premium amount. */
	@Column(name = "ADDITIONAL_RETURN_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer additionalReturnPremium;

	/** The sub coverage premiums. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "coveragePremium")
	@OrderBy("basicCoverageCode ASC")
	private Set<SubCoveragePremium> subCoveragePremiums = new HashSet<SubCoveragePremium>(0);

	/** The annual premium modified. */
	@Column(name = "ANNUAL_PREMIUM_MOD_AMT", precision = 9, scale = 0)
	private Integer annualPremiumModified;

	/** The annual premium system. */
	@Column(name = "ANNUAL_PREMIUM_SYS_AMT", precision = 9, scale = 0)
	private Integer annualPremiumSystem;

	/**
	 * Instantiates a new coverage premium.
	 */
	public CoveragePremium() {
		// noarg constructor
	}

	/**
	 * Instantiates a new coverage premium.
	 * 
	 * @param aRatingRisk the a rating risk
	 * @param aCoverage the a coverage
	 */
	public CoveragePremium(RatingRisk aRatingRisk, Coverage aCoverage) {
		setRatingRisk(aRatingRisk);
		setCoverage(aCoverage);
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the rating risk.
	 * 
	 * @return the rating risk
	 */
	@XmlTransient
	public RatingRisk getRatingRisk() {
		return this.ratingRisk;
	}

	/**
	 * Sets the rating risk.
	 * 
	 * @param aRatingRisk the new rating risk
	 */
	public void setRatingRisk(RatingRisk aRatingRisk) {
		AssociationsHelper.updateOneToManyFields(aRatingRisk, "coveragePremiums", this, "ratingRisk");
	}

	/**
	 * Gets the coverage.
	 * 
	 * @return the coverage
	 */
	@XmlTransient
	public Coverage getCoverage() {
		return this.coverage;
	}

	/**
	 * Sets the coverage.
	 * 
	 * @param aCoverage the new coverage
	 */
	public void setCoverage(Coverage aCoverage) {
		AssociationsHelper.updateOneToManyFields(aCoverage, "coveragePremiums", this, "coverage");
	}

	/**
	 * Gets the annual premium amount.
	 * 
	 * @return the annual premium amount
	 */
	public Integer getAnnualPremium() {
		return this.annualPremium;
	}

	/**
	 * Sets the annual premium amount.
	 * 
	 * @param aAnnualPremiumAmount the new annual premium amount
	 */
	public void setAnnualPremium(Integer aAnnualPremiumAmount) {
		this.annualPremium = aAnnualPremiumAmount;
	}

	/**
	 * Gets the full term premium amount.
	 * 
	 * @return the full term premium amount
	 */
	public Integer getFullTermPremium() {
		return this.fullTermPremium;
	}

	/**
	 * Sets the full term premium amount.
	 * 
	 * @param aFullTermPremiumAmount the new full term premium amount
	 */
	public void setFullTermPremium(Integer aFullTermPremiumAmount) {
		this.fullTermPremium = aFullTermPremiumAmount;
	}

	/**
	 * Gets the additional return premium amount.
	 * 
	 * @return the additional return premium amount
	 */
	public Integer getAdditionalReturnPremium() {
		return this.additionalReturnPremium;
	}

	/**
	 * Sets the additional return premium amount.
	 * 
	 * @param aAdditionalReturnPremiumAmount the new additional return premium amount
	 */
	public void setAdditionalReturnPremium(Integer aAdditionalReturnPremiumAmount) {
		this.additionalReturnPremium = aAdditionalReturnPremiumAmount;
	}

	/**
	 * Gets the sub coverage premiums.
	 * 
	 * @return the sub coverage premiums
	 */
	@XmlElementWrapper(name="subCoveragePremiums")
	@XmlElement(name="subCoveragePremium")
	public Set<SubCoveragePremium> getSubCoveragePremiums() {
		return Collections.unmodifiableSet(this.subCoveragePremiums);
	}

	/**
	 * Sets the sub coverage premiums.
	 * 
	 * @param aSubCoveragePremiums the new sub coverage premiums
	 */
	protected void setSubCoveragePremiums(Set<SubCoveragePremium> aSubCoveragePremiums) {
		this.subCoveragePremiums = aSubCoveragePremiums;
	}

	/**
	 * Adds the sub coverage premium.
	 * 
	 * @param subCoveragePremium the sub coverage premium
	 */
	public void addSubCoveragePremium(com.ing.canada.plp.domain.coverage.SubCoveragePremium subCoveragePremium) {
		AssociationsHelper.updateOneToManyFields(this, "subCoveragePremiums", subCoveragePremium, "coveragePremium");
	}

	/**
	 * Removes the sub coverage premium.
	 * 
	 * @param subCoveragePremium the sub coverage premium
	 */
	public void removeSubCoveragePremium(com.ing.canada.plp.domain.coverage.SubCoveragePremium subCoveragePremium) {
		AssociationsHelper.updateOneToManyFields(null, "subCoveragePremiums", subCoveragePremium, "coveragePremium");
	}

	/**
	 * Gets the annual premium modified.
	 * 
	 * @return the annual premium modified
	 */
	public Integer getAnnualPremiumModified() {
		return this.annualPremiumModified;
	}

	/**
	 * Sets the annual premium modified.
	 * 
	 * @param anAnnualPremiumModified the new annual premium modified
	 */
	public void setAnnualPremiumModified(Integer anAnnualPremiumModified) {
		this.annualPremiumModified = anAnnualPremiumModified;
	}

	/**
	 * Gets the annual premium system.
	 * 
	 * @return the annual premium system
	 */
	public Integer getAnnualPremiumSystem() {
		return this.annualPremiumSystem;
	}

	/**
	 * Sets the annual premium system.
	 * 
	 * @param anAnnualPremiumSystem the new annual premium system
	 */
	public void setAnnualPremiumSystem(Integer anAnnualPremiumSystem) {
		this.annualPremiumSystem = anAnnualPremiumSystem;
	}

}
