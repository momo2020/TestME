/*
 * Important notice: This software is the sole property of ING Canada Inc. and cannot be distributed and/or copied
 * without the written permission of ING Canada Inc. Copyright (c) 2004, ING Canada Inc., All rights reserved.<br>
 * 
 * Created on 2008-05-06.
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum CountryCodeEnum.
 */
public enum CreditCardTransactionStatusCodeEnum {

	CREATED_IN_MONERIS("TC"), DELETED_IN_MONERIS("TD"), MARKED_TO_BE_DELETED("MD");

	/**
	 * Instantiates a new country code enum.
	 * 
	 * @param aCode the a code
	 */
	private CreditCardTransactionStatusCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the country code enum
	 */
	public static CreditCardTransactionStatusCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (CreditCardTransactionStatusCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
