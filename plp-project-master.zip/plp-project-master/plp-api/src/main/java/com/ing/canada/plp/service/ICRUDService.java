package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.usertype.BaseEntity;

public interface ICRUDService<E extends BaseEntity> extends IBaseService<E> {
	
	/**
	 * Persist.
	 * 
	 * @param newEntity the new entity
	 * 
	 * @return the e
	 */
	E persist(E newEntity);

	/**
	 * Delete.
	 * 
	 * @param id the id
	 * 
	 * @return the e
	 */
	E delete(long id);

	/**
	 * Delete.
	 * 
	 * @param entity the entity
	 * 
	 * @return the e
	 */
	E delete(E entity);

	/**
	 * Refresh.
	 * 
	 * @param entity the entity
	 * 
	 * @return the e
	 */
	E refresh(E entity);

}
