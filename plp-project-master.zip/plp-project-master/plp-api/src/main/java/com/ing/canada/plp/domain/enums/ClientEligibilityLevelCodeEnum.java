/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum ClientEligibilityLevelCodeEnum.
 */
public enum ClientEligibilityLevelCodeEnum {


	NO_HIT("NHT"),
	NOT_REQUIRED("NRQ"),
	NOT_ALLOWED("NRP"),
	REQUEST_NOT_FOUND("NFD"),
	ERROR("ERR"),
	COMMUNICATION_PROBLEM("PCO"),
	
	/** Depending on the credit score status and credit score value , 
	 * we might obtain one of the following
	 */
	ELSE("ELSE"),
	EIGHT_HUNDRED("800"),
	SEVEN_HUNDRED("700"),
	SIX_HUNDRED("600"),
	FOUR_HUNDRED("400"),
	FIVE_HUNDRED("500"),
	ONE_HUNDRED("100"),
	ZERO("000"),
	
	/** According to PLP Physical database documentation , the following items 
	 * are deprecated.*/
	HIT_LESS_23("HIT_LESS_23"),	
	TECHP("TECHP"),
	BELOW("BELOW"),
	ABOVE("ABOVE"),
	ABNHT("ABNHT"),
	REG("REG"),
	ADV("ADV"),
	ADNHT("ADNHT"),
	PRI("PRI"),
	PRP("PRP");

	/**
	 * Instantiates a new client eligibility level code enum.
	 * 
	 * @param aCode the a code
	 */
	private ClientEligibilityLevelCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the client eligibility level code enum
	 */
	public static ClientEligibilityLevelCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (ClientEligibilityLevelCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
