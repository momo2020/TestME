package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.businesstransaction.MessageRepositoryEntry;
import com.ing.canada.plp.domain.businesstransaction.TransactionalMessage;

public interface ITransactionalMessageService extends ICRUDService<TransactionalMessage> {

	// no-op - All operations are in the parent class
	public MessageRepositoryEntry getEntry(String messageNumber);
}
