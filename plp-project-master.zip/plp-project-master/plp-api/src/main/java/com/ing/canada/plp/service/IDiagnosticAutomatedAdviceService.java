/*
 * Important notice: This software is the sole property of ING Canada Inc. and cannot be distributed and/or copied
 * without the written permission of ING Canada Inc. Copyright (c) 2004, ING Canada Inc., All rights reserved.<br>
 * Created on 3-Apr-08
 */

package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.diagnostics.DiagnosticAutomatedAdvice;

/**
 * This interface exposes services required to manage DiagnosticAutomatedAdvice related entities.
 * 
 * @author R�gis Brochu
 */
public interface IDiagnosticAutomatedAdviceService extends ICRUDService<DiagnosticAutomatedAdvice> {
	// no-op
}
