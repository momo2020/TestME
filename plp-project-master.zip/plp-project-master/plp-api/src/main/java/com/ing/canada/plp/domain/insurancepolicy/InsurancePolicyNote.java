package com.ing.canada.plp.domain.insurancepolicy;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.UserActivityTypeCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * InsurancePolicyNote entity.
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "INSURANCE_POLICY_NOTE", uniqueConstraints = {})
// USED 4 PERFORMANCE ONLY.
// SHOULD NOT NORMALLY BE USED
// DO NOT TRY TO REFACTOR FOR PURISM MATTERS
@NamedNativeQueries({ 
	@NamedNativeQuery(name = "InsurancePolicyNote.createPolicyNotes", query = "INSERT INTO PLPADMIN.INSURANCE_POLICY_NOTE (INSURANCE_POLICY_NOTE_ID, AUTHOR_U_ID, INSURANCE_POLICY_NOTE, SYSTEM_CREATE_TS, INSURANCE_POLICY_ID, USER_ACTIVITY_TYPE_CD) SELECT PLPADMIN.INSURANCE_POLICY_NOTE_SEQ.NEXTVAL, UPPER(?), 'FROM : ' || SBF.NAME_LINE1 || COALESCE(SBF.NAME_LINE2, '') || ' TO : ' || SBT.NAME_LINE1 || COALESCE(SBT.NAME_LINE2, ''), CURRENT_DATE, IP.INSURANCE_POLICY_ID, 'REAS_QUO' FROM PLPADMIN.INSURANCE_POLICY IP, CIFADMIN.SUB_BROKERS SBF, CIFADMIN.SUB_BROKERS SBT, PLPADMIN.SUB_BROKER_ASSIGNMENT SBA WHERE IP.AGREEMENT_NBR = ? AND SBT.SUB_BROKER = ? AND SBA.CIF_SUB_BROKER_ID = SBF.SUB_BROKER AND SBA.SYSTEM_CREATE_TS IN (SELECT MAX(SBA2.SYSTEM_CREATE_TS) FROM PLPADMIN.SUB_BROKER_ASSIGNMENT SBA2 WHERE SBA2.INSURANCE_POLICY_ID = IP.INSURANCE_POLICY_ID)") 
})

public class InsurancePolicyNote extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "INSURANCE_POLICY_NOTE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "InsurancePolicyNoteSequence")
	@SequenceGenerator(name = "InsurancePolicyNoteSequence", sequenceName = "INSURANCE_POLICY_NOTE_SEQ", allocationSize = 5)
	private Long id;

	/** The insurancePolicy. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_POLICY_ID", nullable = false, updatable = true)
	private InsurancePolicy insurancePolicy;

	/** The author uid. */
	@Column(name = "AUTHOR_U_ID", nullable = false, length = 256)
	private String authorUID;

	/** The insurance policy note. */
	@Column(name = "INSURANCE_POLICY_NOTE", nullable = true, length = 300)
	private String insurancePolicyNote;

	/** The user activity type. */
	@Column(name = "USER_ACTIVITY_TYPE_CD", nullable = false, length = 10)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.UserActivityTypeCodeEnum") })
	private UserActivityTypeCodeEnum userActivityType;

	/**
	 * Instantiates a new address.
	 */
	public InsurancePolicyNote() {
		// noarg constructor
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the insurancePolicy.
	 * 
	 * @return the insurancePolicy
	 */
	@XmlTransient
	// parent
	public InsurancePolicy getInsurancePolicy() {
		return this.insurancePolicy;
	}

	/**
	 * Sets the insurancePolicy.
	 * 
	 * @param aInsurancePolicy the new insurancePolicy
	 */
	public void setInsurancePolicy(InsurancePolicy aInsurancePolicy) {
		AssociationsHelper.updateOneToManyFields(aInsurancePolicy, "insurancePolicyNotes", this, "insurancePolicy");
	}

	/**
	 * Gets the insurance policy note.
	 * 
	 * @return the insurance policy note
	 */
	public String getInsurancePolicyNote() {
		return this.insurancePolicyNote;
	}

	/**
	 * Sets the insurance policy note.
	 * 
	 * @param aInsurancePolicyNote the a insurance policy note
	 */
	public void setInsurancePolicyNote(String aInsurancePolicyNote) {
		this.insurancePolicyNote = aInsurancePolicyNote;
	}

	/**
	 * Gets the author uid.
	 * 
	 * @return the author uid
	 */
	public String getAuthorUID() {
		return this.authorUID;
	}

	/**
	 * Sets the author uid.
	 * 
	 * @param aAuthorUID the a author uid
	 */
	public void setAuthorUID(String aAuthorUID) {
		this.authorUID = aAuthorUID;
	}

	/**
	 * Gets the user activity type.
	 * 
	 * @return the user activity type
	 */
	public UserActivityTypeCodeEnum getUserActivityType() {
		return this.userActivityType;
	}

	/**
	 * Sets the user activity type.
	 * 
	 * @param aUserActivityType the new user activity type
	 */
	public void setUserActivityType(UserActivityTypeCodeEnum aUserActivityType) {
		this.userActivityType = aUserActivityType;
	}
}
