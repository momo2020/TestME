/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.vehicle;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.EquipmentTypeCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * VehicleEquipment entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "VEHICLE_EQUIPMENT", uniqueConstraints = {})
public class VehicleEquipment extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "VEHICLE_EQUIPMENT_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "VehicleEquipmentSequence")
	@SequenceGenerator(name = "VehicleEquipmentSequence", sequenceName = "VEHICLE_EQUIPMENT_SEQ", allocationSize = 5)
	private Long id;

	/** The vehicle. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_RISK_ID", nullable = false, updatable = true)
	private Vehicle vehicle;

	/** The equipment type. */
	@Column(name = "EQUIPMENT_TYPE_CD", nullable = false, length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.EquipmentTypeCodeEnum") })
	private EquipmentTypeCodeEnum equipmentType;

	/** The equipment value. */
	@Column(name = "EQUIPMENT_VALUE_AMT", precision = 7, scale = 0)
	private Integer equipmentValue;

	/** The Original Scenario Vehicle Equipment * */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_VEHICLE_EQUIPMENT_ID", insertable = false, updatable = false)
	private VehicleEquipment originalScenarioVehicleEquipment;

	/**
	 * Instantiates a new vehicle equipment.
	 */
	public VehicleEquipment() {
		// noarg constructor
	}

	/**
	 * Instantiates a new vehicle equipment.
	 * 
	 * @param aVehicle the a vehicle
	 * @param anEquipmentTypeCode the equipment type code
	 */
	public VehicleEquipment(Vehicle aVehicle, EquipmentTypeCodeEnum anEquipmentTypeCode) {
		setVehicle(aVehicle);
		setEquipmentType(anEquipmentTypeCode);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the vehicle.
	 * 
	 * @return the vehicle
	 */
	@XmlTransient // parent
	public Vehicle getVehicle() {
		return this.vehicle;
	}

	/**
	 * Sets the vehicle.
	 * 
	 * @param aVehicle the new vehicle
	 */
	public void setVehicle(Vehicle aVehicle) {
		AssociationsHelper.updateOneToManyFields(aVehicle, "vehicleEquipments", this, "vehicle");
	}

	/**
	 * Gets the equipment type.
	 * 
	 * @return the equipment type
	 */
	public EquipmentTypeCodeEnum getEquipmentType() {
		return this.equipmentType;
	}

	/**
	 * Sets the equipment type.
	 * 
	 * @param equipmentTypeCode the new equipment type
	 */
	public void setEquipmentType(EquipmentTypeCodeEnum equipmentTypeCode) {
		this.equipmentType = equipmentTypeCode;
	}

	/**
	 * Gets the equipment value.
	 * 
	 * @return the equipment value
	 */
	public Integer getEquipmentValue() {
		return this.equipmentValue;
	}

	/**
	 * Sets the equipment value.
	 * 
	 * @param equipmentValueAmount the new equipment value
	 */
	public void setEquipmentValue(Integer equipmentValueAmount) {
		this.equipmentValue = equipmentValueAmount;
	}

	/**
	 * Gets the original scenario vehicle equipment
	 * 
	 * @return the original scenario vehicle equipment
	 */
	@XmlTransient // reference source
	public VehicleEquipment getOriginalScenarioVehicleEquipment() {
		return this.originalScenarioVehicleEquipment;
	}

	/**
	 * Sets the original scenario vehicle equipment
	 * 
	 * @param the original scenario vehicle equipment
	 */
	protected void setOriginalScenarioVehicleEquipment(VehicleEquipment anOriginalScenarioVehicleEquipment) {
		this.originalScenarioVehicleEquipment = anOriginalScenarioVehicleEquipment;
	}

}
