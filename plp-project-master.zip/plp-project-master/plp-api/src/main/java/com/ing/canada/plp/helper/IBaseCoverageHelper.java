/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import java.util.Set;

import com.ing.canada.plp.domain.coverage.BaseCoverage;

/**
 * The Interface IBaseCoverageHelper.
 * 
 * @author strichar
 */
public interface IBaseCoverageHelper {

	/**
	 * Gets the first selected coverage.
	 * 
	 * @param aBaseCoverageSet the a base coverage set
	 * 
	 * @return the first selected coverage
	 */
	BaseCoverage getFirstSelectedCoverage(Set<? extends BaseCoverage> aBaseCoverageSet);

	/**
	 * Since GPSM, this method is removed and replace by 
	 * 		ICoverageHelper#getSelectedEndorsement(...)
	 * 
	 * Check coverage.
	 * 
	 * @param aBaseCoverage the a base coverage
	 * 
	 * @return true, if successful
	 *
	boolean checkCoverageSelected(BaseCoverage aBaseCoverage);
	*/
}
