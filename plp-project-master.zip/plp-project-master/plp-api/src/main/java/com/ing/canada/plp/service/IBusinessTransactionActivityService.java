/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.businesstransaction.BusinessTransaction;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransactionActivity;

/**
 * This interface exposes services required to manage BusinessTransactionActivity related entities.
 * 
 * @author mblouin
 * 
 */
public interface IBusinessTransactionActivityService extends ICRUDService<BusinessTransactionActivity> {

	/**
	 * this method call the businessTransactionActivityDAO to the IQP activity of an insurance policy.
	 */
	BusinessTransactionActivity findIQPBusinessTransactionActivity(String agreementNumber);

	/**
	 * Returns the last transaction activity associated with a business transaction.
	 * 
	 * @param businessTransaction
	 * @return the <tt>BusinessTransactionActivity</tt>
	 */
	BusinessTransactionActivity findLastBusinessTransactionActivity(BusinessTransaction businessTransaction);

	/**
	 * Returns the last transaction activity associated with a business transaction.
	 * 
	 * @param businessTransactionId
	 * @return
	 */
	BusinessTransactionActivity findLastBusinessTransactionActivity(Long businessTransactionId);
}
