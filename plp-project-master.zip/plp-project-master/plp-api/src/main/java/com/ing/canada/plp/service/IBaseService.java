/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * This interface defines service commons to all service class.<br>
 * Most of the calls are delegated directly to the associated DAO.<br>
 * Classes implementing this interface are responsible of adding additional functionalities required for a particular
 * entity.
 * 
 * @author fsimard
 * @param <E> Entity
 */
public interface IBaseService<E extends BaseEntity> {

	/**
	 * Find all.
	 * 
	 * @return the list< e>
	 */
	List<E> findAll();

	/**
	 * Find by id.
	 * 
	 * @param id the id
	 * 
	 * @return the e
	 */
	E findById(long id);

	/**
	 * Find by property.
	 * 
	 * @param propertyName the property name
	 * @param value the value
	 * 
	 * @return the list< e>
	 */
	List<E> findByProperty(String propertyName, Object value);
}
