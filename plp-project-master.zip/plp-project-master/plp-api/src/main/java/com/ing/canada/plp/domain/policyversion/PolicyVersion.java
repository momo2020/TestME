/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.policyversion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.ManufacturingContext;
import com.ing.canada.plp.domain.billing.Billing;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransaction;
import com.ing.canada.plp.domain.driver.AffinityGroupRepositoryEntry;
import com.ing.canada.plp.domain.driver.DriverComplementInfo;
import com.ing.canada.plp.domain.enums.AgreementStatusCodeEnum;
import com.ing.canada.plp.domain.enums.BusinessSourceCodeEnum;
import com.ing.canada.plp.domain.enums.CancellationReasonCodeEnum;
import com.ing.canada.plp.domain.enums.ClientTargetReasonCodeEnum;
import com.ing.canada.plp.domain.enums.CombinedPolicyCodeEnum;
import com.ing.canada.plp.domain.enums.CombinedPolicyScenarioCodeEnum;
import com.ing.canada.plp.domain.enums.ConvertedPolicyCodeEnum;
import com.ing.canada.plp.domain.enums.DistributorCodeEnum;
import com.ing.canada.plp.domain.enums.HolderAutoInsuranceSinceCodeEnum;
import com.ing.canada.plp.domain.enums.InitialTransactionCodeEnum;
import com.ing.canada.plp.domain.enums.LanguageCodeEnum;
import com.ing.canada.plp.domain.enums.PolicyDiscountTypeCodeEnum;
import com.ing.canada.plp.domain.enums.PolicyHolderTypeCodeEnum;
import com.ing.canada.plp.domain.enums.PolicyTermInMonthsEnum;
import com.ing.canada.plp.domain.enums.PolicyVersionTypeCodeEnum;
import com.ing.canada.plp.domain.enums.PreferredPaymentPlanCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;
import com.ing.canada.plp.domain.enums.UnderwritingActionCodeEnum;
import com.ing.canada.plp.domain.enums.UnderwritingCompanyCodeEnum;
import com.ing.canada.plp.domain.helper.BaseEntityHelper;
import com.ing.canada.plp.domain.insurancepolicy.InsurancePolicy;
import com.ing.canada.plp.domain.insurancerisk.Claim;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.insuranceriskoffer.PolicyOfferRating;
import com.ing.canada.plp.domain.partnership.Partnership;
import com.ing.canada.plp.domain.party.Party;
import com.ing.canada.plp.domain.usertype.BaseEntity;
import com.ing.canada.plp.lock.InsurancePolicyLockable;

/**
 * PolicyVersion entity.
 *
 * @author Patrick Lafleur
 *
 *         Modifications: - May 1st, 2008: Renamed methods returning a Boolean/boolean from getBoolean() to isBoolean()
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "POLICY_VERSION", uniqueConstraints = { @UniqueConstraint(columnNames = { "BUSINESS_TRANSACTION_ID" }) })
@NamedQueries({
		@NamedQuery(name = "PolicyVersion.getDriverInfoList", query = "select new com.ing.canada.plp.domain.DriverInfo(p.id, p.firstName, p.lastName, p.middleName, p.suffixName, dci.driverSequence, p.birthDate, p.actionTaken, p.roadBlockIndicator) from Party p inner join p.policyVersion as pv inner join p.driverComplementInfo as dci left join p.partyRoleInRisks as prir left join prir.insuranceRisk as ir where pv.id = :policyVersionId and (ir.riskType is null or ir.riskType = 'PPV') order by dci.driverSequence"),
		@NamedQuery(name = "PolicyVersion.getDriverPartyList", query = "select p from Party p inner join p.policyVersion as pv inner join p.driverComplementInfo as dci left join p.partyRoleInRisks as prir left join prir.insuranceRisk as ir where pv.id = :policyVersionId and (ir.riskType is null or ir.riskType = 'PPV') order by dci.driverSequence"),
		@NamedQuery(name = "PolicyVersion.findMaxAdditionalInterestSequenceNo", query = "select max(p.additionalInterestSequence) from Party p where p.policyVersion = :policyVersion"),
		@NamedQuery(name = "PolicyVersion.getVehicleInfoList", query = "select new com.ing.canada.plp.domain.VehicleInfo(veh.id, vdsre.vehicleYear, vre.vehicleModelEnglish, vre.vehicleModelFrench, vre.vehicleMakeEnglish, vre.vehicleMakeFrench, ir.insuranceRiskSequence) from PolicyVersion as pv inner join pv.insuranceRisks as ir inner join ir.vehicle as veh inner join veh.vehicleDetailSpecificationRepositoryEntry as vdsre inner join vdsre.vehicleRepositoryEntry as vre where pv.id = :policyVersionId order by ir.insuranceRiskSequence"),
		@NamedQuery(name = "PolicyVersion.countTransactionActivitiesByActivityCode", query = "select count(*) from PolicyVersion pv inner join pv.businessTransaction bt inner join bt.businessTransactionActivities bta where pv.id = :policyVersionId and bta.businessTransactionActivityCode = :businessTransactionActivityCode"),
		@NamedQuery(name = "PolicyVersion.findCloneSourcePolicyVersion", query = "from PolicyVersion pv_parent where pv_parent.id = (select pv_child.cloneSourcePolicyVersion from PolicyVersion pv_child where pv_child.id = :policyVersionId)"),
		@NamedQuery(name = "PolicyVersion.findAllPolicyVersionForCifIdExcludingPartner", query = "select pv from PolicyVersion pv inner join pv.parties py inner join py.policyHolders ph where pv.id in (select max(subpv.id) from PolicyVersion subpv inner join subpv.parties subp inner join subpv.insurancePolicy subip where subp.cifClientId = :cifId and subip.agreementType in (:agreementTypes) and subpv.partnerships.size = 0 group by subpv.insurancePolicy) and py.cifClientId = :cifId order by pv.id desc"),
		@NamedQuery(name = "PolicyVersion.findAllPolicyVersionForCifId", query = "select pv from PolicyVersion pv inner join pv.parties py inner join py.policyHolders ph where pv.id in (select max(subpv.id) from PolicyVersion subpv inner join subpv.parties subp inner join subpv.insurancePolicy subip where subp.cifClientId = :cifId and subip.agreementType in (:agreementTypes) group by subpv.insurancePolicy) and py.cifClientId = :cifId order by pv.id desc"),
		@NamedQuery(name = "PolicyVersion.findAllPolicyVersionForCifIdWithPartner", query = "select pv from PolicyVersion pv inner join pv.parties py inner join py.policyHolders ph where pv.id in (select max(subpv.id) from PolicyVersion subpv inner join subpv.parties subp inner join subpv.insurancePolicy subip inner join subpv.partnerships subps 	where subp.cifClientId = :cifId and subip.agreementType in (:agreementTypes) and subps.partnershipCode = :partnershipCode group by subpv.insurancePolicy) and py.cifClientId = :cifId order by pv.id desc"),
		@NamedQuery(name = "PolicyVersion.getGroupRepositoryEntry", query = "select gre from PolicyVersion pv, InsuranceRiskOffer iro, RatingRiskOffer rro, GroupRepositoryEntry gre, Party p , PartyGroup pg where  pv.id = :policyVersionId and iro.insuranceRisk.id = (SELECT ir.id from InsuranceRisk ir where ir.policyVersion = pv.id and rownum=1) and rro.insuranceRiskOffer = iro.id and rro.ratingRiskType = 'P' and iro.selectedForPolicyOfferRatingIndicator = 'Y' and p.policyVersion = pv.id and pg.party = p.id and pg.groupRepositoryEntry = gre.id and gre.insuredGroup = rro.insuredGroupRated)"),
		@NamedQuery(name = "PolicyVersion.getGroupRepositoryEntryBeforeOffer", query = "select gre from PolicyVersion pv, PolicyHolder ph, PartyGroup pg, GroupRepositoryEntry gre where pv.id = :policyVersionId and pv.id=ph.policyVersion.id and ph.policyHolderType='P' and ph.party.id=pg.party.id and pv.affinityGroupRepositoryEntry.id=pg.affinityGroupRepositoryEntry.id and gre.id=pg.groupRepositoryEntry.id)"),
		@NamedQuery(name = "PolicyVersion.countPolicyVersionForIPNumberInTheLastHour", query = "select  count(*) from PolicyVersion pv where pv.clientXForwardIPNbr = :ipNumber and pv.auditTrail.createTimestamp between sysdate-1/24 and sysdate "),
		@NamedQuery(name = "PolicyVersion.countPolicyVersionForIPNumberInTheLast24Hours", query = "select  count(*) from PolicyVersion pv where pv.clientXForwardIPNbr = :ipNumber and pv.auditTrail.createTimestamp between sysdate-1 and sysdate ") })
public class PolicyVersion extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "POLICY_VERSION_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "PolicyVersionSequence")
	@SequenceGenerator(name = "PolicyVersionSequence", sequenceName = "POLICY_VERSION_SEQ", allocationSize = 5)
	private Long id;

	/** The insurance policy. */
	@ManyToOne(cascade = {}, fetch = FetchType.EAGER)
	@JoinColumn(name = "INSURANCE_POLICY_ID", nullable = false, updatable = true)
	private InsurancePolicy insurancePolicy;

	/** The business transaction. */
	@OneToOne(cascade = { CascadeType.PERSIST }, optional = false, fetch = FetchType.LAZY)
	@JoinColumn(name = "BUSINESS_TRANSACTION_ID", unique = true, nullable = false, updatable = true)
	private BusinessTransaction businessTransaction;

	@OneToOne(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER, mappedBy = "policyVersion")
	@Fetch(FetchMode.JOIN)
	private ReferenceDate referenceDate;

	/** The producer. */
	// There should be always a producer! We are not cascading, the policy version service will do it
	// so the repository will get update correctly
	@OneToOne(cascade = { CascadeType.PERSIST }, optional = true, fetch = FetchType.EAGER)
	@PrimaryKeyJoinColumn(name = "POLICY_VERSION_ID")
	@Fetch(FetchMode.JOIN)
	private Producer producer;

	/** The policy version type. */
	@Column(name = "POLICY_VERSION_TYPE_CD", nullable = false, length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PolicyVersionTypeCodeEnum") })
	private PolicyVersionTypeCodeEnum policyVersionType;

	/** The converted policy code. */
	@Column(name = "CONVERTED_POLICY_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ConvertedPolicyCodeEnum") })
	private ConvertedPolicyCodeEnum convertedPolicyCode;

	/** The business source. */
	@Column(name = "BUSINESS_SOURCE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.BusinessSourceCodeEnum") })
	private BusinessSourceCodeEnum businessSource;

	/** The language of communication. */
	@Column(name = "LANGUAGE_OF_COMMUNICATION_CD", length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.LanguageCodeEnum") })
	private LanguageCodeEnum languageOfCommunication;

	/** The initial transaction code. */
	@Column(name = "INITIAL_TRANSACTION_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.InitialTransactionCodeEnum") })
	private InitialTransactionCodeEnum initialTransactionCode;

	/** The risk bound confirmation number. */
	@Column(name = "RISK_BOUND_CONFIRMATION_NBR", length = 10)
	private String riskBoundConfirmationNumber;

	/** The inception date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "POLICY_INCEPTION_DT", length = 7)
	private Date policyInceptionDate;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "POLICY_EXPIRY_DT", length = 7)
	private Date policyExpiryDate;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "RES_POLICY_SOLICITATION_DT", length = 7)
	private Date residentialPolicySolicitationDate;

	/** The policy term in months. */
	@Column(name = "POLICY_TERM_IN_MONTHS_QTY", precision = 2, scale = 0)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PolicyTermInMonthsEnum") })
	private PolicyTermInMonthsEnum policyTermInMonths;

	/** The rating date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "RATING_DT", length = 7)
	private Date ratingDate;

	/** The client of broker since auto. */
	@Temporal(TemporalType.DATE)
	@Column(name = "CLIENT_OF_BROKER_SINCE_AUTO_DT", length = 7)
	private Date clientOfBrokerSinceAuto;

	/** The client of broker since res code. */
	@Column(name = "CLIENT_BROKER_SINCE_RES_CD", length = 2)
	private String clientOfBrokerSinceResCode;

	/** The holder of auto insurance since. */
	@Temporal(TemporalType.DATE)
	@Column(name = "HOLDER_AUTO_INSURANCE_SINCE_DT", length = 7)
	private Date holderOfAutoInsuranceSince;

	/** The holder of auto insurance since code. */
	@Column(name = "HOLDER_AUTO_INSURANCE_SINCE_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.HolderAutoInsuranceSinceCodeEnum") })
	private HolderAutoInsuranceSinceCodeEnum holderOfAutoInsuranceSinceCode;

	/** The combined policy code. */
	@Column(name = "COMBINED_POLICY_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.CombinedPolicyCodeEnum") })
	private CombinedPolicyCodeEnum combinedPolicyCode;

	/** The combined policy scenario code. */
	@Column(name = "COMBINED_POLICY_SCENARIO_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.CombinedPolicyScenarioCodeEnum") })
	private CombinedPolicyScenarioCodeEnum combinedPolicyScenarioCode;

	/** The policy discount type. */
	@Column(name = "POLICY_DISCOUNT_TYPE_CD", length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PolicyDiscountTypeCodeEnum") })
	private PolicyDiscountTypeCodeEnum policyDiscountType;

	/** The loyalty discount. */
	@Column(name = "LOYALTY_DISCOUNT_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean loyaltyDiscountIndicator;

	/** The has held full term auto insurance. */
	@Column(name = "HAS_HELD_FULL_TRM_AUTO_INS_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean hasHeldFullTermAutoInsuranceIndicator;

	/** The mvrsaaq authorization indicator. */
	@Column(name = "MVRSAAQ_AUTHORIZATION_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean mvrSaaqAuthorizationIndicator;

	/** The annual premium. */
	@Column(name = "ANNUAL_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer annualPremium;

	/** The full term premium. */
	@Column(name = "FULL_TERM_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer fullTermPremium;

	/** The full term premium taxable. */
	@Column(name = "FULL_TERM_PREMIUM_TAXABLE_AMT", precision = 9, scale = 0)
	private Integer fullTermPremiumTaxable;

	/** The additional return premium. */
	@Column(name = "ADDITIONAL_RETURN_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer additionalReturnPremium;

	/** The add return premium taxable. */
	@Column(name = "ADD_RETURN_PREMIUM_TAXABLE_AMT", precision = 9, scale = 0)
	private Integer additionalReturnPremiumTaxable;

	/** The underwriting company. */
	@Column(name = "UNDERWRITING_COMPANY_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.UnderwritingCompanyCodeEnum") })
	private UnderwritingCompanyCodeEnum underwritingCompany;

	/** The marketing promotion code. */
	@Column(name = "MARKETING_PROMOTION_CD", length = 20)
	private String marketingPromotionCode;

	/** The original marketing promotion code entry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "ORIG_MRKT_PROM_CODE_ENTRY_DT", length = 7)
	private Date originalMarketingPromotionCodeEntryDate;

	/** The marketing promotion internal code. */
	@Column(name = "MARKETING_PROMO_INTERNAL_CD", length = 5)
	private String marketingPromotionInternalCode;

	/** The affinity group code. */
	@Column(name = "AFFINITY_GROUP_CD", length = 20)
	private String affinityGroupCode;

	/** The original affinity group code entry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "ORIG_AFFINITY_GR_CODE_ENTRY_DT", length = 7)
	private Date originalAffinityGroupCodeEntryDate;

	/** The affinity group internal code. */
	@Column(name = "AFFINITY_GROUP_INTERNAL_CD", length = 5)
	private String affinityGroupInternalCode;

	/** The license suspended or revoked. */
	@Column(name = "LICENSE_SUSPENDED_REVOKED_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean licenseSuspendedOrRevokedIndicator;

	@Column(name = "HOLDER_AUTO_INSURANCE_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean holderAutoInsuranceIndicator;

	/** The prior carrier policy infos. */
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "PRIOR_CARRIER_POLICY_INFO_ID")
	@Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private PriorCarrierPolicyInfo priorCarrierPolicyInfo;

	/** The parties. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "policyVersion")
	@Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	@OrderBy("id ASC")
	private Set<Party> parties = new HashSet<Party>(0);

	/** The insurance risks. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "policyVersion")
	@OrderBy("insuranceRiskSequence ASC")
	private Set<InsuranceRisk> insuranceRisks = new HashSet<InsuranceRisk>(0);

	/** The related insurance policies. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "policyVersion")
	private Set<RelatedInsurancePolicy> relatedInsurancePolicies = new HashSet<RelatedInsurancePolicy>(0);

	/** The billing. */
	@OneToOne(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
	@PrimaryKeyJoinColumn(name = "POLICY_VERSION_ID")
	@Fetch(FetchMode.JOIN)
	private Billing billing = null;

	/** The policy additional coverages. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "policyVersion")
	private Set<PolicyAdditionalCoverage> policyAdditionalCoverages = new HashSet<PolicyAdditionalCoverage>(0);

	/** The policy holders. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "policyVersion")
	private Set<PolicyHolder> policyHolders = new HashSet<PolicyHolder>(0);

	/** The claims. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "policyVersion")
	private Set<Claim> claims = new HashSet<Claim>(0);

	/** The original scenario policy version. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_POLICY_VERSION_ID", insertable = false, updatable = false)
	private PolicyVersion originalScenarioPolicyVersion;

	/** The clone source policy version. */
	@OneToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "CLONE_SOURCE_POLICY_VERSION_ID", insertable = false, updatable = false)
	private PolicyVersion cloneSourcePolicyVersion;

	/** The market segments */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "policyVersion")
	private Set<MarketSegment> marketSegments = new HashSet<MarketSegment>(0);

	/**
	 * The clone target policy version.
	 *
	 * @OneToOne(cascade = {}, fetch = FetchType.LAZY, mappedBy = "cloneSourcePolicyVersion") private PolicyVersion cloneTargetPolicyVersion;
	 */
	/** The extented policy term request indicator. */
	@Column(name = "EXTENTED_POLICY_TERM_REQ_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean extentedPolicyTermRequestIndicator;

	/** The policy offer rating. Sorted from newest to oldest (based on the creation timestamp). */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "policyVersion")
	@OrderBy("auditTrail.createTimestamp DESC")
	private Set<PolicyOfferRating> policyOfferRatings = new HashSet<PolicyOfferRating>(0);

	/** Added 10/07/2009 ub8169 */
	@Column(name = "OTH_DRVR_WITH_COMP_IN_HHLD_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean otherDriverWithCompanyInHouseholdInd;

	/** Added 10/07/2009 ub8169 */
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "AFF_GR_REP_ENTRY_ID")
	private AffinityGroupRepositoryEntry affinityGroupRepositoryEntry;

	/** The backend transaction in progress ind. THIS FIELD WILL NOT BE PERSISTED IN THE DATABASE. */
	@Transient
	private Boolean backendTransactionInProgressInd;

	/** The backend transaction for other terms in progress ind. THIS FIELD WILL NOT BE PERSISTED IN THE DATABASE. */
	@Transient
	private Boolean backendTransactionInProgressOtherTermsInd;

	/**
	 * Indicates that there were an ongoing Policy Change transaction on that policyVersion but it was out of sync with
	 * Classic and therefore reset. THIS FIELD WILL NOT BE PERSISTED IN THE DATABASE.
	 */
	@Transient
	private Boolean policyChangeTransactionWasReset;

	@Column(name = "UNDERWRITING_ACTION_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.UnderwritingActionCodeEnum") })
	private UnderwritingActionCodeEnum underwritingActionCode;

	/** Date at which the cancellation (if cancelled) will be effective */
	@Temporal(TemporalType.DATE)
	@Column(name = "POLICY_CANCELLATION_DT", length = 7)
	private Date policyCancellationDate;

	@Column(name = "CANCELLATION_REASON_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.CancellationReasonCodeEnum") })
	private CancellationReasonCodeEnum cancellationReasonCode;

	@Column(name = "POLICY_TERM_STATUS_LEGACY_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.AgreementStatusCodeEnum") })
	private AgreementStatusCodeEnum policyTermStatusLegacyCd;

	@Column(name = "BILLING_PLAN_FOR_UNDWTR_ACT_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PreferredPaymentPlanCodeEnum") })
	private PreferredPaymentPlanCodeEnum preferredPaymentMethod;

	@Column(name = "MAILING_DIFF_FROM_HOM_ADDR_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean mailAddressDifferentHome;

	@Column(name = "OUTSTD_PRM_OWED_WITH_OT_CO_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean outstandingPremiumWithOtherCompanyIndicator;

	@Column(name = "POL_CHG_PRM_WAR_PRD_IN_DAY_QTY", precision = 4, scale = 0)
	private Byte policyChangePremiumWarrantyPeriodInDays;

	/** Date at which the cancellation (if cancelled) will be effective */
	@Temporal(TemporalType.DATE)
	@Column(name = "POL_CHG_PRM_WAR_EXP_DT", length = 7)
	private Date policyChangePremiumWarrantyPeriodDate;

	// RBRP-3
	@Column(name = "IN_PROCS_DOING_AUT_POL_CHG_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean inProcsDoingAutPolChgIndicator;

	/** The reason why a client was determined target (RSDAR-8) */
	@Column(name = "CLIENT_TARGET_REASON_CD", length = 6)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ClientTargetReasonCodeEnum") })
	private ClientTargetReasonCodeEnum clientTargetReason;

	/** The X Forward IP For, CM011009 */
	@Column(name = "CLIENT_XFORWARD_IP_NBR", length = 100, nullable = true)
	private String clientXForwardIPNbr;

	/** The reason why a client was determined target (RSDAR-8) */
	@Column(name = "CLIENT_IP_NBR", length = 100, nullable = true)
	private String clientIPNbr;

	/** DE1594 Other licensed drivers */
	@Column(name = "OTH_DRVR_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean otherDriversLicensedIndicator;

	/** DE1595 All drivers have their own insurance */
	@Column(name = "ALL_OTH_DRVR_INSRD_OUTSIDE_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean otherDriversOwnInsuredIndicator;

	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "policyVersion")
	private Set<Partnership> partnerships = new HashSet<Partnership>(0);

	/** indicator if policyholder was the principal driver on a previous auto policy */
	@Column(name = "HOLDER_AUT_INS_AS_PRIN_DRV_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean holderAutoInsuranceAsPrincipalDriverIndicator;

	@Column(name = "NBR_OF_QU_LAST_HR_FOR_IP_QTY", precision = 12, scale = 0)
	private Byte numberOfQuotesLastHourForIP;

	@Column(name = "NBR_OF_QU_LAST_24HR_FOR_IP_QTY", precision = 12, scale = 0)
	private Byte numberOfQuotesLastTwentyfourHourForIP;

	@Temporal(TemporalType.DATE)
	@Column(name = "NBR_OF_QU_FOR_IP_CALC_TS", length = 7)
	private Date dateNumberOfQuoteForIPCalculated;

	/** The direct channel distributo repository entry, ie. the distributor */
	@ManyToOne(cascade = {}, fetch = FetchType.EAGER)
	@JoinColumn(name = "DIRECT_CHAN_DIST_REP_ENTRY_ID", nullable = true, updatable = true)
	private DirectChanDistRepEntry directChanDistRepEntry;

	@Transient
	private Map<PolicyHolderTypeCodeEnum, PolicyHolder> holders = null;

	/**
	 * Instantiates a new policy version.
	 */
	public PolicyVersion() {
		// noarg constructor
	}

	/**
	 * Constructor.
	 *
	 * @param policyVersionId the id
	 */
	/**
	 * @param policyVersionId
	 */
	public PolicyVersion(long policyVersionId) {
		this.setId(policyVersionId);
	}

	/**
	 * Instantiates a new policy version.
	 *
	 * @param aInsurancePolicy the insurance policy
	 * @param aBusinessTransaction the business transaction
	 * @param aPolicyVersionTypeCodeEnum the policy version type code enum
	 */
	public PolicyVersion(InsurancePolicy aInsurancePolicy, BusinessTransaction aBusinessTransaction,
			PolicyVersionTypeCodeEnum aPolicyVersionTypeCodeEnum) {
		this.setInsurancePolicy(aInsurancePolicy);
		this.setBusinessTransaction(aBusinessTransaction);
		this.setPolicyVersionType(aPolicyVersionTypeCodeEnum);
	}

	/**
	 * @return get the group lock parent: {@link #insurancePolicy}
	 */
	public InsurancePolicyLockable getGroupLockParent() {
		return this.getInsurancePolicy();
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 *
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@XmlAttribute(name = "id", required = true)
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param aId the a id
	 *
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the insurance policy.
	 *
	 * @return the insurance policy
	 */
	@XmlTransient
	// parent
	public InsurancePolicy getInsurancePolicy() {
		return this.insurancePolicy;
	}

	/**
	 * Sets the insurance policy.
	 *
	 * @param aInsurancePolicy the new insurance policy
	 */
	public void setInsurancePolicy(InsurancePolicy aInsurancePolicy) {
		AssociationsHelper.updateOneToManyFields(aInsurancePolicy, "policyVersions", this, "insurancePolicy");
	}

	/**
	 * Gets the business transaction.
	 *
	 * @return the business transaction
	 */
	public BusinessTransaction getBusinessTransaction() {
		return this.businessTransaction;
	}

	/**
	 * Sets the business transaction.
	 *
	 * @param aBusinessTransaction the new business transaction
	 */
	public void setBusinessTransaction(BusinessTransaction aBusinessTransaction) {
		AssociationsHelper.updateOneToOneFields(this, PolicyVersion.class, "businessTransaction", aBusinessTransaction,
				BusinessTransaction.class, "policyVersion");
	}

	/**
	 * Gets the policy version type.
	 *
	 * @return the policy version type
	 */
	public PolicyVersionTypeCodeEnum getPolicyVersionType() {
		return this.policyVersionType;
	}

	/**
	 * Sets the policy version type.
	 *
	 * @param policyVersionTypeCode the new policy version type
	 */
	public void setPolicyVersionType(PolicyVersionTypeCodeEnum policyVersionTypeCode) {
		this.policyVersionType = policyVersionTypeCode;
	}

	/**
	 * Gets the converted policy code.
	 *
	 * @return the converted policy code
	 */
	public ConvertedPolicyCodeEnum getConvertedPolicyCode() {
		return this.convertedPolicyCode;
	}

	/**
	 * Sets the converted policy code.
	 *
	 * @param aConvertedPolicyCode the new converted policy code
	 */
	public void setConvertedPolicyCode(ConvertedPolicyCodeEnum aConvertedPolicyCode) {
		this.convertedPolicyCode = aConvertedPolicyCode;
	}

	/**
	 * Gets the business source.
	 *
	 * @return the business source
	 */
	public BusinessSourceCodeEnum getBusinessSource() {
		return this.businessSource;
	}

	/**
	 * Sets the business source.
	 *
	 * @param businessSourceCode the new business source
	 */
	public void setBusinessSource(BusinessSourceCodeEnum businessSourceCode) {
		this.businessSource = businessSourceCode;
	}

	/**
	 * Gets the language of communication.
	 *
	 * @return the language of communication
	 */
	public LanguageCodeEnum getLanguageOfCommunication() {
		return this.languageOfCommunication;
	}

	/**
	 * Sets the language of communication.
	 *
	 * @param languageOfCommunicationCode the new language of communication
	 */
	public void setLanguageOfCommunication(LanguageCodeEnum languageOfCommunicationCode) {
		this.languageOfCommunication = languageOfCommunicationCode;
	}

	/**
	 * Gets the initial transaction code.
	 *
	 * @return the initial transaction code
	 */
	public InitialTransactionCodeEnum getInitialTransactionCode() {
		return this.initialTransactionCode;
	}

	/**
	 * Sets the initial transaction code.
	 *
	 * @param aInitialTransactionCode the new initial transaction code
	 */
	public void setInitialTransactionCode(InitialTransactionCodeEnum aInitialTransactionCode) {
		this.initialTransactionCode = aInitialTransactionCode;
	}

	/**
	 * Gets the risk bound confirmation number.
	 *
	 * @return the risk bound confirmation number
	 */
	public String getRiskBoundConfirmationNumber() {
		return this.riskBoundConfirmationNumber;
	}

	/**
	 * Sets the risk bound confirmation number.
	 *
	 * @param aRiskBoundConfirmationNumber the new risk bound confirmation number
	 */
	public void setRiskBoundConfirmationNumber(String aRiskBoundConfirmationNumber) {
		this.riskBoundConfirmationNumber = aRiskBoundConfirmationNumber;
	}

	/**
	 * Gets the inception date.
	 *
	 * @return the inception date
	 */
	public Date getPolicyInceptionDate() {
		return this.policyInceptionDate;
	}

	/**
	 * Sets the inception date.
	 *
	 * @param aPolicyInceptionDate the new inception date
	 */
	public void setPolicyInceptionDate(Date aPolicyInceptionDate) {
		this.policyInceptionDate = aPolicyInceptionDate;
	}

	/**
	 * Gets the expiry date.
	 *
	 * @return the expiry date
	 */
	public Date getPolicyExpiryDate() {
		return this.policyExpiryDate;
	}

	/**
	 * Sets the expiry date.
	 *
	 * @param aPolicyExpiryDate the new expiry date
	 */
	public void setPolicyExpiryDate(Date aPolicyExpiryDate) {
		this.policyExpiryDate = aPolicyExpiryDate;
	}

	/**
	 * Gets the policy term in months.
	 *
	 * @return the policy term in months
	 */
	public PolicyTermInMonthsEnum getPolicyTermInMonths() {
		return this.policyTermInMonths;
	}

	/**
	 * Sets the policy term in months.
	 *
	 * @param aPolicyTermInMonths the new policy term in months
	 */
	public void setPolicyTermInMonths(PolicyTermInMonthsEnum aPolicyTermInMonths) {
		this.policyTermInMonths = aPolicyTermInMonths;
	}

	/**
	 * Gets the rating date.
	 *
	 * @return the rating date
	 */
	public Date getRatingDate() {
		return this.ratingDate;
	}

	/**
	 * Sets the rating date.
	 *
	 * @param aRatingDate the new rating date
	 */
	public void setRatingDate(Date aRatingDate) {
		this.ratingDate = aRatingDate;
	}

	/**
	 * Gets the client of broker since auto.
	 *
	 * @return the client of broker since auto
	 */
	public Date getClientOfBrokerSinceAuto() {
		return this.clientOfBrokerSinceAuto;
	}

	/**
	 * Sets the client of broker since auto.
	 *
	 * @param clientOfBrokerSinceAutoDate the new client of broker since auto
	 */
	public void setClientOfBrokerSinceAuto(Date clientOfBrokerSinceAutoDate) {
		this.clientOfBrokerSinceAuto = clientOfBrokerSinceAutoDate;
	}

	/**
	 * Gets the client of broker since res code.
	 *
	 * @return the client of broker since res code
	 */
	public String getClientOfBrokerSinceResCode() {
		return this.clientOfBrokerSinceResCode;
	}

	/**
	 * Sets the client of broker since res code.
	 *
	 * @param clientBrokerSinceResCode the new client of broker since res code
	 */
	public void setClientOfBrokerSinceResCode(String clientBrokerSinceResCode) {
		this.clientOfBrokerSinceResCode = clientBrokerSinceResCode;
	}

	/**
	 * Gets the holder of auto insurance since.
	 *
	 * @return the holder of auto insurance since
	 */
	public Date getHolderOfAutoInsuranceSince() {
		return this.holderOfAutoInsuranceSince;
	}

	/**
	 * Sets the holder of auto insurance since.
	 *
	 * @param holderAutoInsuranceSinceDate the new holder of auto insurance since
	 */
	public void setHolderOfAutoInsuranceSince(Date holderAutoInsuranceSinceDate) {
		this.holderOfAutoInsuranceSince = holderAutoInsuranceSinceDate;
	}

	/**
	 * Gets the holder of auto insurance since code.
	 *
	 * @return the holder of auto insurance since code
	 */
	public HolderAutoInsuranceSinceCodeEnum getHolderOfAutoInsuranceSinceCode() {
		return this.holderOfAutoInsuranceSinceCode;
	}

	/**
	 * Sets the holder of auto insurance since code.
	 *
	 * @param holderAutoInsuranceSinceCode the new holder of auto insurance since code
	 */
	public void setHolderOfAutoInsuranceSinceCode(HolderAutoInsuranceSinceCodeEnum holderAutoInsuranceSinceCode) {
		this.holderOfAutoInsuranceSinceCode = holderAutoInsuranceSinceCode;
	}

	/**
	 * Gets the combined policy code.
	 *
	 * @return the combined policy code
	 */
	public CombinedPolicyCodeEnum getCombinedPolicyCode() {
		return this.combinedPolicyCode;
	}

	/**
	 * Sets the combined policy code.
	 *
	 * @param aCombinedPolicyCode the new combined policy code
	 */
	public void setCombinedPolicyCode(CombinedPolicyCodeEnum aCombinedPolicyCode) {
		this.combinedPolicyCode = aCombinedPolicyCode;
	}

	/**
	 * Gets the combined policy scenario code.
	 *
	 * @return the combined policy scenario code
	 */
	public CombinedPolicyScenarioCodeEnum getCombinedPolicyScenarioCode() {
		return this.combinedPolicyScenarioCode;
	}

	/**
	 * Sets the combined policy scenario code.
	 *
	 * @param aCombinedPolicyScenarioCode the new combined policy scenario code
	 */
	public void setCombinedPolicyScenarioCode(CombinedPolicyScenarioCodeEnum aCombinedPolicyScenarioCode) {
		this.combinedPolicyScenarioCode = aCombinedPolicyScenarioCode;
	}

	/**
	 * Gets the policy discount type.
	 *
	 * @return the policy discount type
	 */
	public PolicyDiscountTypeCodeEnum getPolicyDiscountType() {
		return this.policyDiscountType;
	}

	/**
	 * Sets the policy discount type code.
	 *
	 * @param policyDiscountTypeCode the new policy discount type code
	 */
	public void setPolicyDiscountType(PolicyDiscountTypeCodeEnum policyDiscountTypeCode) {
		this.policyDiscountType = policyDiscountTypeCode;
	}

	/**
	 * Gets the loyalty discount.
	 *
	 * @return the loyalty discount
	 */
	public Boolean getLoyaltyDiscountIndicator() {
		return this.loyaltyDiscountIndicator;
	}

	/**
	 * Sets the loyalty discount.
	 *
	 * @param aLoyaltyDiscountIndicator the new loyalty discount
	 */
	public void setLoyaltyDiscountIndicator(Boolean aLoyaltyDiscountIndicator) {
		this.loyaltyDiscountIndicator = aLoyaltyDiscountIndicator;
	}

	/**
	 * Gets the checks for held full term auto insurance.
	 *
	 * @return the checks for held full term auto insurance
	 */
	public Boolean getHasHeldFullTermAutoInsuranceIndicator() {
		return this.hasHeldFullTermAutoInsuranceIndicator;
	}

	/**
	 * Sets the checks for held full term auto insurance.
	 *
	 * @param hasHeldFullTrmAutoInsIndicator the new checks for held full term auto insurance
	 */
	public void setHasHeldFullTermAutoInsuranceIndicator(Boolean hasHeldFullTrmAutoInsIndicator) {
		this.hasHeldFullTermAutoInsuranceIndicator = hasHeldFullTrmAutoInsIndicator;
	}

	/**
	 * Gets the mvrsaaq authorization indicator.
	 *
	 * @return the mvrsaaq authorization indicator
	 */
	public Boolean getMvrSaaqAuthorizationIndicator() {
		return this.mvrSaaqAuthorizationIndicator;
	}

	/**
	 * Sets the mvrsaaq authorization indicator.
	 *
	 * @param aMvrsaaqAuthorizationIndicator the new mvrsaaq authorization indicator
	 */
	public void setMvrSaaqAuthorizationIndicator(Boolean aMvrsaaqAuthorizationIndicator) {
		this.mvrSaaqAuthorizationIndicator = aMvrsaaqAuthorizationIndicator;
	}

	/**
	 * Gets the annual premium.
	 *
	 * @return the annual premium
	 */
	public Integer getAnnualPremium() {
		return this.annualPremium;
	}

	/**
	 * Sets the annual premium.
	 *
	 * @param annualPremiumAmount the new annual premium
	 */
	public void setAnnualPremium(Integer annualPremiumAmount) {
		this.annualPremium = annualPremiumAmount;
	}

	public Double getRoundedMonthlyPremium() {

		Double premium = null;

		if (this.getAnnualPremium() != null) {
			premium = new Double(this.getAnnualPremium()) / this.getPolicyTermInMonths().getCode();
			premium = Math.round(premium * 100.0) / 100.0;
		}

		return premium;
	}

	/**
	 * Gets the full term premium.
	 *
	 * @return the full term premium
	 */
	public Integer getFullTermPremium() {
		return this.fullTermPremium;
	}

	/**
	 * Sets the full term premium.
	 *
	 * @param fullTermPremiumAmount the new full term premium
	 */
	public void setFullTermPremium(Integer fullTermPremiumAmount) {
		this.fullTermPremium = fullTermPremiumAmount;
	}

	/**
	 * Gets the full term premium taxable.
	 *
	 * @return the full term premium taxable
	 */
	public Integer getFullTermPremiumTaxable() {
		return this.fullTermPremiumTaxable;
	}

	/**
	 * Sets the full term premium taxable.
	 *
	 * @param fullTermPremiumTaxableAmount the new full term premium taxable
	 */
	public void setFullTermPremiumTaxable(Integer fullTermPremiumTaxableAmount) {
		this.fullTermPremiumTaxable = fullTermPremiumTaxableAmount;
	}

	/**
	 * Gets the additional return premium.
	 *
	 * @return the additional return premium
	 */
	public Integer getAdditionalReturnPremium() {
		return this.additionalReturnPremium;
	}

	/**
	 * Sets the additional return premium.
	 *
	 * @param additionalReturnPremiumAmount the new additional return premium
	 */
	public void setAdditionalReturnPremium(Integer additionalReturnPremiumAmount) {
		this.additionalReturnPremium = additionalReturnPremiumAmount;
	}

	/**
	 * Gets the adds the return premium taxable.
	 *
	 * @return the adds the return premium taxable
	 */
	public Integer getAdditionalReturnPremiumTaxable() {
		return this.additionalReturnPremiumTaxable;
	}

	/**
	 * Sets the adds the return premium taxable.
	 *
	 * @param addReturnPremiumTaxableAmount the new adds the return premium taxable
	 */
	public void setAdditionalReturnPremiumTaxable(Integer addReturnPremiumTaxableAmount) {
		this.additionalReturnPremiumTaxable = addReturnPremiumTaxableAmount;
	}

	/**
	 * Gets the underwriting company.
	 *
	 * @return the underwriting company
	 */
	public UnderwritingCompanyCodeEnum getUnderwritingCompany() {
		return this.underwritingCompany;
	}

	/**
	 * Sets the underwriting company.
	 *
	 * @param underwritingCompanyCode the new underwriting company
	 */
	public void setUnderwritingCompany(UnderwritingCompanyCodeEnum underwritingCompanyCode) {
		this.underwritingCompany = underwritingCompanyCode;
	}

	/**
	 * Gets the marketing promotion code.
	 *
	 * @return the marketing promotion code
	 */
	public String getMarketingPromotionCode() {
		return this.marketingPromotionCode;
	}

	/**
	 * Sets the marketing promotion code.
	 *
	 * @param aMarketingPromotionCode the new marketing promotion code
	 */
	public void setMarketingPromotionCode(String aMarketingPromotionCode) {
		this.marketingPromotionCode = aMarketingPromotionCode;
	}

	/**
	 * Gets the original marketing promotion code entry date.
	 *
	 * @return the original marketing promotion code entry date
	 */
	public Date getOriginalMarketingPromotionCodeEntryDate() {
		return this.originalMarketingPromotionCodeEntryDate;
	}

	/**
	 * Sets the original marketing promotion code entry date.
	 *
	 * @param origMrktPromCodeEntryDate the new original marketing promotion code entry date
	 */
	public void setOriginalMarketingPromotionCodeEntryDate(Date origMrktPromCodeEntryDate) {
		this.originalMarketingPromotionCodeEntryDate = origMrktPromCodeEntryDate;
	}

	/**
	 * Gets the marketing promotion internal code.
	 *
	 * @return the marketing promotion internal code
	 */
	public String getMarketingPromotionInternalCode() {
		return this.marketingPromotionInternalCode;
	}

	/**
	 * Sets the marketing promotion internal code.
	 *
	 * @param marketingPromoInternalCode the new marketing promotion internal code
	 */
	public void setMarketingPromotionInternalCode(String marketingPromoInternalCode) {
		this.marketingPromotionInternalCode = marketingPromoInternalCode;
	}

	/**
	 * Gets the affinity group code.
	 *
	 * @return the affinity group code
	 */
	public String getAffinityGroupCode() {
		return this.affinityGroupCode;
	}

	/**
	 * Sets the affinity group code.
	 *
	 * @param aAffinityGroupCode the new affinity group code
	 */
	public void setAffinityGroupCode(String aAffinityGroupCode) {
		this.affinityGroupCode = aAffinityGroupCode;
	}

	/**
	 * Gets the original affinity group code entry date.
	 *
	 * @return the original affinity group code entry date
	 */
	public Date getOriginalAffinityGroupCodeEntryDate() {
		return this.originalAffinityGroupCodeEntryDate;
	}

	/**
	 * Sets the original affinity group code entry date.
	 *
	 * @param origAffinityGrCodeEntryDate the new original affinity group code entry date
	 */
	public void setOriginalAffinityGroupCodeEntryDate(Date origAffinityGrCodeEntryDate) {
		this.originalAffinityGroupCodeEntryDate = origAffinityGrCodeEntryDate;
	}

	/**
	 * Gets the affinity group internal code.
	 *
	 * @return the affinity group internal code
	 */
	public String getAffinityGroupInternalCode() {
		return this.affinityGroupInternalCode;
	}

	/**
	 * Sets the affinity group internal code.
	 *
	 * @param aAffinityGroupInternalCode the new affinity group internal code
	 */
	public void setAffinityGroupInternalCode(String aAffinityGroupInternalCode) {
		this.affinityGroupInternalCode = aAffinityGroupInternalCode;
	}

	/**
	 * Gets the license suspended or revoked.
	 *
	 * @return the license suspended or revoked
	 */
	public Boolean getLicenseSuspendedOrRevokedIndicator() {
		return this.licenseSuspendedOrRevokedIndicator;
	}

	/**
	 * Sets the license suspended or revoked.
	 *
	 * @param licenseSuspendedRevokedIndicator the new license suspended or revoked
	 */
	public void setLicenseSuspendedOrRevokedIndicator(Boolean licenseSuspendedRevokedIndicator) {
		this.licenseSuspendedOrRevokedIndicator = licenseSuspendedRevokedIndicator;
	}

	/**
	 * Gets the prior carrier policy infos.
	 *
	 * @return the prior carrier policy info
	 */
	public PriorCarrierPolicyInfo getPriorCarrierPolicyInfo() {
		return this.priorCarrierPolicyInfo;
	}

	/**
	 * Sets the prior carrier policy info.
	 *
	 * @param aPriorCarrierPolicyInfo the new prior carrier policy info
	 */
	public void setPriorCarrierPolicyInfo(PriorCarrierPolicyInfo aPriorCarrierPolicyInfo) {
		AssociationsHelper.updateOneToManyFields(aPriorCarrierPolicyInfo, "policyVersions", this,
				"priorCarrierPolicyInfo");
	}

	/**
	 * Gets the parties.
	 *
	 * @return the parties
	 */
	@XmlElementWrapper(name = "parties")
	@XmlElement(name = "party")
	public Set<Party> getParties() {
		return Collections.unmodifiableSet(this.parties);
	}

	/**
	 * Sets the parties.
	 *
	 * @param aParties the new parties
	 */
	protected void setParties(Set<Party> aParties) {
		this.parties = aParties;
	}

	/**
	 * Adds the party.
	 *
	 * @param party the party
	 */
	public void addParty(com.ing.canada.plp.domain.party.Party party) {
		AssociationsHelper.updateOneToManyFields(this, "parties", party, "policyVersion");
	}

	/**
	 * Removes the party.
	 *
	 * @param party the party
	 */
	public void removeParty(com.ing.canada.plp.domain.party.Party party) {
		AssociationsHelper.updateOneToManyFields(null, "parties", party, "policyVersion");
	}

	/**
	 * Gets the insurance risks.
	 *
	 * @return the insurance risks
	 */
	@XmlElementWrapper(name = "insuranceRisks")
	@XmlElement(name = "insuranceRisk")
	public Set<InsuranceRisk> getInsuranceRisks() {
		return Collections.unmodifiableSet(this.insuranceRisks);
	}

	/**
	 * Sets the insurance risks.
	 *
	 * @param aInsuranceRisks the new insurance risks
	 */
	protected void setInsuranceRisks(Set<InsuranceRisk> aInsuranceRisks) {
		this.insuranceRisks = aInsuranceRisks;
	}

	/**
	 * Adds the insurance risk.
	 *
	 * @param insuranceRisk the insurance risk
	 */
	public void addInsuranceRisk(com.ing.canada.plp.domain.insurancerisk.InsuranceRisk insuranceRisk) {
		AssociationsHelper.updateOneToManyFields(this, "insuranceRisks", insuranceRisk, "policyVersion");
	}

	/**
	 * Removes the insurance risk.
	 *
	 * @param insuranceRisk the insurance risk
	 */
	public void removeInsuranceRisk(com.ing.canada.plp.domain.insurancerisk.InsuranceRisk insuranceRisk) {
		AssociationsHelper.updateOneToManyFields(null, "insuranceRisks", insuranceRisk, "policyVersion");
	}

	/**
	 * Gets the related insurance policies.
	 *
	 * @return the related insurance policies
	 */
	@XmlElementWrapper(name = "relatedInsurancePolicies")
	@XmlElement(name = "relatedInsurancePolicy")
	public Set<RelatedInsurancePolicy> getRelatedInsurancePolicies() {
		return Collections.unmodifiableSet(this.relatedInsurancePolicies);
	}

	/**
	 * Sets the related insurance policies.
	 *
	 * @param aRelatedInsurancePolicies the new related insurance policies
	 */
	protected void setRelatedInsurancePolicies(Set<RelatedInsurancePolicy> aRelatedInsurancePolicies) {
		this.relatedInsurancePolicies = aRelatedInsurancePolicies;
	}

	/**
	 * Adds the related insurance policy.
	 *
	 * @param relatedInsurancePolicy the related insurance policy
	 */
	public void addRelatedInsurancePolicy(RelatedInsurancePolicy relatedInsurancePolicy) {
		AssociationsHelper.updateOneToManyFields(this, "relatedInsurancePolicies", relatedInsurancePolicy,
				"policyVersion");
	}

	/**
	 * Removes the related insurance policy.
	 *
	 * @param relatedInsurancePolicy the related insurance policy
	 */
	public void removeRelatedInsurancePolicy(RelatedInsurancePolicy relatedInsurancePolicy) {
		AssociationsHelper.updateOneToManyFields(null, "relatedInsurancePolicies", relatedInsurancePolicy,
				"policyVersion");
	}

	/**
	 * Gets the billing.
	 *
	 * @return the billing
	 */
	public Billing getBilling() {
		return this.billing;
	}

	/**
	 * Sets the billing.
	 *
	 * @param aBilling the new billing
	 */
	public void setBilling(Billing aBilling) {
		AssociationsHelper.updateOneToOneFields(this, PolicyVersion.class, "billing", aBilling, Billing.class,
				"policyVersion");
	}

	/**
	 * Gets the policy additional coverages.
	 *
	 * @return the policy additional coverages
	 */
	@XmlElementWrapper(name = "policyAdditionalCoverages")
	@XmlElement(name = "policyAdditionalCoverage")
	public Set<PolicyAdditionalCoverage> getPolicyAdditionalCoverages() {
		return Collections.unmodifiableSet(this.policyAdditionalCoverages);
	}

	/**
	 * Sets the policy additional coverages.
	 *
	 * @param aPolicyAdditionalCoverages the new policy additional coverages
	 */
	protected void setPolicyAdditionalCoverages(Set<PolicyAdditionalCoverage> aPolicyAdditionalCoverages) {
		this.policyAdditionalCoverages = aPolicyAdditionalCoverages;
	}

	/**
	 * Adds the policy additional coverage.
	 *
	 * @param coverage the coverage
	 */
	public void addPolicyAdditionalCoverage(com.ing.canada.plp.domain.policyversion.PolicyAdditionalCoverage coverage) {
		AssociationsHelper.updateOneToManyFields(this, "policyAdditionalCoverages", coverage, "policyVersion");
	}

	/**
	 * Removes the policy additional coverage.
	 *
	 * @param coverage the coverage
	 */
	public void removePolicyAdditionalCoverage(com.ing.canada.plp.domain.policyversion.PolicyAdditionalCoverage coverage) {
		AssociationsHelper.updateOneToManyFields(null, "policyAdditionalCoverages", coverage, "policyVersion");
	}

	/**
	 * Gets the policy holders.
	 *
	 * @return the policy holders
	 */
	@XmlElementWrapper(name = "policyHolders")
	@XmlElement(name = "policyHolder")
	public Set<PolicyHolder> getPolicyHolders() {
		return Collections.unmodifiableSet(this.policyHolders);
	}

	/**
	 * Sets the policy holders.
	 *
	 * @param aPolicyHolders the new policy holders
	 */
	protected void setPolicyHolders(Set<PolicyHolder> aPolicyHolders) {
		this.policyHolders = aPolicyHolders;
	}

	/**
	 * Adds the policy holder.
	 *
	 * @param holder the holder
	 */
	public void addPolicyHolder(com.ing.canada.plp.domain.policyversion.PolicyHolder holder) {
		AssociationsHelper.updateOneToManyFields(this, "policyHolders", holder, "policyVersion");
	}

	/**
	 * Removes the policy holder.
	 *
	 * @param holder the holder
	 */
	public void removePolicyHolder(com.ing.canada.plp.domain.policyversion.PolicyHolder holder) {
		AssociationsHelper.updateOneToManyFields(null, "policyHolders", holder, "policyVersion");
	}

	/**
	 * Gets the claims.
	 *
	 * @return the claims
	 */
	@XmlElementWrapper(name = "claims")
	@XmlElement(name = "claim")
	public Set<Claim> getClaims() {
		return Collections.unmodifiableSet(this.claims);
	}

	/**
	 * Sets the claims.
	 *
	 * @param aClaims the new claims
	 */
	protected void setClaims(Set<Claim> aClaims) {
		this.claims = aClaims;
	}

	/**
	 * Adds the claim.
	 *
	 * @param claim the claim
	 */
	public void addClaim(com.ing.canada.plp.domain.insurancerisk.Claim claim) {
		AssociationsHelper.updateOneToManyFields(this, "claims", claim, "policyVersion");
	}

	/**
	 * Removes the claim.
	 *
	 * @param claim the claim
	 */
	public void removeClaim(com.ing.canada.plp.domain.insurancerisk.Claim claim) {
		AssociationsHelper.updateOneToManyFields(null, "claims", claim, "policyVersion");
	}

	/**
	 * Gets the original scenario policy version.
	 *
	 * @return the original scenario policy version
	 */
	@XmlTransient
	// reference source
	public PolicyVersion getOriginalScenarioPolicyVersion() {
		return this.originalScenarioPolicyVersion;
	}

	/**
	 * Sets the original scenario policy version.
	 *
	 * @param anOriginalScenarioPolicyVersion the new original scenario policy version
	 */
	public void setOriginalScenarioPolicyVersion(PolicyVersion anOriginalScenarioPolicyVersion) {
		this.originalScenarioPolicyVersion = anOriginalScenarioPolicyVersion;
	}

	/**
	 * Gets the clone source policy version.
	 *
	 * @return the clone source policy version
	 */
	@XmlTransient
	// reference source
	public PolicyVersion getCloneSourcePolicyVersion() {
		return this.cloneSourcePolicyVersion;
	}

	/**
	 * Sets the clone source policy version.
	 *
	 * @param aCloneSourcePolicyVersion the new clone source policy version
	 */
	protected void setCloneSourcePolicyVersion(PolicyVersion aCloneSourcePolicyVersion) {
		this.cloneSourcePolicyVersion = aCloneSourcePolicyVersion;
	}

	/**
	 *
	 * @return the producer
	 */
	public Producer getProducer() {
		return this.producer;
	}

	/**
	 * Sets the producer.
	 *
	 * @param aProducer the producer to set
	 */
	public void setProducer(Producer aProducer) {
		AssociationsHelper.updateOneToOneFields(this, PolicyVersion.class, "producer", aProducer, Producer.class, "policyVersion");
	}

	/**
	 * Gets the backend transaction in progress ind.
	 *
	 * @return the backend transaction in progress ind
	 */
	public Boolean getBackendTransactionInProgressInd() {
		return this.backendTransactionInProgressInd;
	}

	/**
	 * Sets the backend transaction in progress ind. THE VALUE WILL NOT BE PERSISTED IN THE DATABASE.
	 *
	 * @param aBackendTransactionInProgressInd the new backend transaction in progress ind
	 */
	public void setBackendTransactionInProgressInd(Boolean aBackendTransactionInProgressInd) {
		this.backendTransactionInProgressInd = aBackendTransactionInProgressInd;
	}

	/**
	 * Gets the extented policy term request indicator.
	 *
	 * @return the extented policy term request indicator
	 */
	public Boolean getExtentedPolicyTermRequestIndicator() {
		return this.extentedPolicyTermRequestIndicator;
	}

	/**
	 * Sets the extented policy term request indicator.
	 *
	 * @param aExtentedPolicyTermRequestIndicator the new extented policy term request indicator
	 */
	public void setExtentedPolicyTermRequestIndicator(Boolean aExtentedPolicyTermRequestIndicator) {
		this.extentedPolicyTermRequestIndicator = aExtentedPolicyTermRequestIndicator;
	}

	/**
	 * @return {@link policyOfferRatings}
	 */
	public PolicyOfferRating getLatestPolicyOfferRating() {
		if (this.policyOfferRatings.isEmpty()) {
			return null;
		}
		return (PolicyOfferRating) BaseEntityHelper.findMostRecentCreateTimestamp(this.policyOfferRatings);
	}

	/**
	 * Gets the policy offer rating.
	 *
	 * @return the policy offer rating
	 */
	@XmlElementWrapper(name = "policyOfferRating")
	@XmlElement(name = "policyOfferRating")
	public Set<PolicyOfferRating> getPolicyOfferRatings() {
		return Collections.unmodifiableSet(this.policyOfferRatings);
	}

	/**
	 * Sets the policy offer rating.
	 *
	 * @param aPolicyOfferRating the new policy offer rating
	 */
	protected void setPolicyOfferRatings(Set<PolicyOfferRating> aPolicyOfferRating) {
		this.policyOfferRatings = aPolicyOfferRating;
	}

	/**
	 * Adds the policy offer rating.
	 *
	 * @param aPolicyOfferRating the a policy offer rating
	 */
	public void addPolicyOfferRating(PolicyOfferRating aPolicyOfferRating) {
		AssociationsHelper.updateOneToManyFields(this, "policyOfferRatings", aPolicyOfferRating, "policyVersion");
	}

	/**
	 * Removes the policy offer rating.
	 *
	 * @param aPolicyOfferRating
	 */
	public void removePolicyOfferRating(PolicyOfferRating aPolicyOfferRating) {
		AssociationsHelper.updateOneToManyFields(null, "policyOfferRatings", aPolicyOfferRating, "policyVersion");
	}

	/**
	 * Gets the backend transaction in progress ind.
	 *
	 * @return the backend transaction in progress ind
	 */
	public Boolean getBackendTransactionInProgressOtherTermsInd() {
		return this.backendTransactionInProgressOtherTermsInd;
	}

	/**
	 * Sets the backend transaction in progress ind. THE VALUE WILL NOT BE PERSISTED IN THE DATABASE.
	 *
	 * @param backendTransactionInProgressInd the new backend transaction in progress ind
	 */
	public void setBackendTransactionInProgressOtherTermsInd(Boolean aBackendTransactionInProgressOtherTermsInd) {
		this.backendTransactionInProgressOtherTermsInd = aBackendTransactionInProgressOtherTermsInd;
	}

	/**
	 * @return the holderAutoInsuranceIndicator
	 */
	public Boolean getHolderAutoInsuranceIndicator() {
		return this.holderAutoInsuranceIndicator;
	}

	/**
	 * @param holderAutoInsuranceIndicator the holderAutoInsuranceIndicator to set
	 */
	public void setHolderAutoInsuranceIndicator(Boolean aHolderAutoInsuranceIndicator) {
		this.holderAutoInsuranceIndicator = aHolderAutoInsuranceIndicator;
	}

	/**
	 * @return the referenceDate
	 */
	public ReferenceDate getReferenceDate() {
		return this.referenceDate;
	}

	/**
	 * @param aReferenceDate the referenceDate to set
	 */
	public void setReferenceDate(ReferenceDate aReferenceDate) {
		AssociationsHelper.updateOneToOneFields(this, PolicyVersion.class, "referenceDate", aReferenceDate,
				ReferenceDate.class, "policyVersion");
	}

	/**
	 * @return the otherDriverWithCompanyInHouseholdInd
	 */
	public Boolean getOtherDriverWithCompanyInHouseholdInd() {
		return this.otherDriverWithCompanyInHouseholdInd;
	}

	/**
	 * @param anOtherDriverWithCompanyInHouseholdInd the otherDriverWithCompanyInHouseholdInd to set
	 */
	public void setOtherDriverWithCompanyInHouseholdInd(Boolean anOtherDriverWithCompanyInHouseholdInd) {
		this.otherDriverWithCompanyInHouseholdInd = anOtherDriverWithCompanyInHouseholdInd;
	}

	/**
	 * @return {@link #affinityGroupRepositoryEntry}
	 */
	public AffinityGroupRepositoryEntry getAffinityGroupRepositoryEntry() {
		return this.affinityGroupRepositoryEntry;
	}

	/**
	 * @param aAffinityGroupRepositoryEntry {@link #affinityGroupRepositoryEntry}
	 */
	public void setAffinityGroupRepositoryEntry(AffinityGroupRepositoryEntry aAffinityGroupRepositoryEntry) {
		this.affinityGroupRepositoryEntry = aAffinityGroupRepositoryEntry;
	}

	/**
	 * @return {@link #residentialPolicySolicitationDate}
	 */
	public Date getResidentialPolicySolicitationDate() {
		return this.residentialPolicySolicitationDate;
	}

	/**
	 * @param aResidentialPolicySolicitationDate {@link #residentialPolicySolicitationDate}
	 */
	public void setResidentialPolicySolicitationDate(Date aResidentialPolicySolicitationDate) {
		this.residentialPolicySolicitationDate = aResidentialPolicySolicitationDate;
	}

	public UnderwritingActionCodeEnum getUnderwritingActionCode() {
		return this.underwritingActionCode;
	}

	public void setUnderwritingActionCode(UnderwritingActionCodeEnum aUnderwritingActionCode) {
		this.underwritingActionCode = aUnderwritingActionCode;
	}

	public CancellationReasonCodeEnum getCancellationReasonCode() {
		return this.cancellationReasonCode;
	}

	public void setCancellationReasonCode(CancellationReasonCodeEnum aCancellationReasonCode) {
		this.cancellationReasonCode = aCancellationReasonCode;
	}

	public Date getPolicyCancellationDate() {
		return this.policyCancellationDate;
	}

	public void setPolicyCancellationDate(Date aPolicyCancellationDate) {
		this.policyCancellationDate = aPolicyCancellationDate;
	}

	public AgreementStatusCodeEnum getPolicyTermStatusLegacyCd() {
		return this.policyTermStatusLegacyCd;
	}

	public void setPolicyTermStatusLegacyCd(AgreementStatusCodeEnum aPolicyTermStatusLegacyCd) {
		this.policyTermStatusLegacyCd = aPolicyTermStatusLegacyCd;
	}

	public Boolean getPolicyChangeTransactionWasReset() {
		return this.policyChangeTransactionWasReset;
	}

	public void setPolicyChangeTransactionWasReset(Boolean aPolicyChangeTransactionWasReset) {
		this.policyChangeTransactionWasReset = aPolicyChangeTransactionWasReset;
	}

	public PreferredPaymentPlanCodeEnum getPreferredPaymentMethod() {
		return this.preferredPaymentMethod;
	}

	public void setPreferredPaymentMethod(PreferredPaymentPlanCodeEnum aPreferredPaymentMethod) {
		this.preferredPaymentMethod = aPreferredPaymentMethod;
	}

	public Boolean getMailAddressDifferentHome() {
		return this.mailAddressDifferentHome;
	}

	public void setMailAddressDifferentHome(Boolean aMailAddressDifferentHome) {
		this.mailAddressDifferentHome = aMailAddressDifferentHome;
	}

	/**
	 * get the outstanding premium owed to an other insurance company indicator.
	 *
	 * @return outstanding premium indicator
	 */
	public Boolean getOutstandingPremiumWithOtherCompanyIndicator() {
		return this.outstandingPremiumWithOtherCompanyIndicator;
	}

	/**
	 * Set the outstanding premium owed to an other insurance company indicator.
	 *
	 * @param aOutstandingPremiumWithOtherCompanyIndicator {@link #aOutstandingPremiumWithOtherCompanyIndicator}
	 */
	public void setOutstandingPremiumWithOtherCompanyIndicator(Boolean aOutstandingPremiumWithOtherCompanyIndicator) {
		this.outstandingPremiumWithOtherCompanyIndicator = aOutstandingPremiumWithOtherCompanyIndicator;
	}

	public Date getPolicyChangePremiumWarrantyPeriodDate() {
		return this.policyChangePremiumWarrantyPeriodDate;
	}

	public void setPolicyChangePremiumWarrantyPeriodDate(Date aPolicyChangePremiumWarrantyPeriodDate) {
		this.policyChangePremiumWarrantyPeriodDate = aPolicyChangePremiumWarrantyPeriodDate;
	}

	public Byte getPolicyChangePremiumWarrantyPeriodInDays() {
		return this.policyChangePremiumWarrantyPeriodInDays;
	}

	public void setPolicyChangePremiumWarrantyPeriodInDays(Byte aPolicyChangePremiumWarrantyPeriodInDays) {
		this.policyChangePremiumWarrantyPeriodInDays = aPolicyChangePremiumWarrantyPeriodInDays;
	}

	// RBRP-3
	public Boolean getInProcsDoingAutPolChgIndicator() {
		return this.inProcsDoingAutPolChgIndicator;
	}

	public void setInProcsDoingAutPolChgIndicator(Boolean inProcsDoingAutPolChgIndicator) {
		this.inProcsDoingAutPolChgIndicator = inProcsDoingAutPolChgIndicator;
	}

	/**
	 * @return {@link #clientTargetReason}
	 */
	public ClientTargetReasonCodeEnum getClientTargetReason() {
		return this.clientTargetReason;
	}

	/**
	 * @param clientTargetReason {@link #clientTargetReason}
	 */
	public void setClientTargetReason(ClientTargetReasonCodeEnum clientTargetReason) {
		this.clientTargetReason = clientTargetReason;
	}

	/**
	 * @return Market segments
	 */
	@XmlElementWrapper(name = "marketSegments")
	@XmlElement(name = "marketSegment")
	public Set<MarketSegment> getMarketSegments() {
		return Collections.unmodifiableSet(this.marketSegments);
	}

	/**
	 * @param marketSegments
	 */
	public void setMarketSegments(Set<MarketSegment> marketSegments) {
		this.marketSegments = marketSegments;
	}

	/**
	 * Adds the market segment
	 *
	 * @param marketSegment market segment
	 */
	public void addMarketSegment(MarketSegment marketSegment) {
		AssociationsHelper.updateOneToManyFields(this, "marketSegments", marketSegment, "policyVersion");
	}

	/**
	 * Removes the market segment
	 *
	 * @param marketSegment market segment
	 */
	public void removeMarketSegment(MarketSegment marketSegment) {
		AssociationsHelper.updateOneToManyFields(null, "marketSegments", marketSegment, "policyVersion");
	}

	/**
	 * @return the clientXForwardIPNbr
	 */
	public String getClientXForwardIPNbr() {
		return this.clientXForwardIPNbr;
	}

	/**
	 * @param clientXForwardIPNbr the clientXForwardIPNbr to set
	 */
	public void setClientXForwardIPNbr(String clientXForwardIPNbr) {
		this.clientXForwardIPNbr = clientXForwardIPNbr;
	}

	/**
	 * @return the clientIPNbr
	 */
	public String getClientIPNbr() {
		return this.clientIPNbr;
	}

	/**
	 * @param clientIPNbr the clientIPNbr to set
	 */
	public void setClientIPNbr(String clientIPNbr) {
		this.clientIPNbr = clientIPNbr;
	}

	/**
	 * @return {@link #otherDriversLicensedIndicator}
	 */
	public Boolean getOtherDriversLicensedIndicator() {
		return this.otherDriversLicensedIndicator;
	}

	/**
	 * @param otherDriverLicensedIndicator {@link #otherDriversLicensedIndicator}
	 */
	public void setOtherDriversLicensedIndicator(Boolean otherDriverLicensedIndicator) {
		this.otherDriversLicensedIndicator = otherDriverLicensedIndicator;
	}

	/**
	 * @return {@link #otherDriversOwnInsuredIndicator}
	 */
	public Boolean getOtherDriversOwnInsuredIndicator() {
		return this.otherDriversOwnInsuredIndicator;
	}

	/**
	 * @param otherDriversOwnInsuredIndicator {@link #otherDriversOwnInsuredIndicator}
	 */
	public void setOtherDriversOwnInsuredIndicator(Boolean otherDriversOwnInsuredIndicator) {
		this.otherDriversOwnInsuredIndicator = otherDriversOwnInsuredIndicator;
	}

	/**
	 * @return {@link #partnerships}
	 */
	@XmlElementWrapper(name = "partnerships")
	@XmlElement(name = "partnership")
	public Set<Partnership> getPartnerships() {
		return this.partnerships;
	}

	/**
	 * @param partnerships the {@link Set} of {@link Partnership}
	 */
	public void setPartnerships(Set<Partnership> partnerships) {
		this.partnerships = partnerships;
	}

	/**
	 * @param partnership {@link Partnership} to add
	 */
	public void addPartnership(Partnership partnership) {
		AssociationsHelper.updateOneToManyFields(this, "partnerships", partnership, "policyVersion");
	}

	/**
	 * @return the holderAutoInsuranceAsPrincipalDriverIndicator
	 */
	public Boolean getHolderAutoInsuranceAsPrincipalDriverIndicator() {
		return this.holderAutoInsuranceAsPrincipalDriverIndicator;
	}

	/**
	 * @param holderAutoInsuranceAsPrincipalDriverIndicator the holderAutoInsuranceAsPrincipalDriverIndicator to set
	 */
	public void setHolderAutoInsuranceAsPrincipalDriverIndicator(Boolean holderAutoInsuranceAsPrincipalDriverIndicator) {
		this.holderAutoInsuranceAsPrincipalDriverIndicator = holderAutoInsuranceAsPrincipalDriverIndicator;
	}

	/**
	 * @return {@link #numberOfQuotesLastHourForIP}
	 */
	public Byte getNumberOfQuotesLastHourForIP() {
		return this.numberOfQuotesLastHourForIP;
	}

	/**
	 * @param numberOfQuotesLastHourForIP {@link #numberOfQuotesLastHourForIP}
	 */
	public void setNumberOfQuotesLastHourForIP(Byte numberOfQuotesLastHourForIP) {
		this.numberOfQuotesLastHourForIP = numberOfQuotesLastHourForIP;
	}

	/**
	 * @return {@link #numberOfQuotesLastTwentyfourHourForIP}
	 */
	public Byte getNumberOfQuotesLastTwentyfourHourForIP() {
		return this.numberOfQuotesLastTwentyfourHourForIP;
	}

	/**
	 * @param numberOfQuotesLastTwentyfourHourForIP {@link #numberOfQuotesLastTwentyfourHourForIP}
	 */
	public void setNumberOfQuotesLastTwentyfourHourForIP(Byte numberOfQuotesLastTwentyfourHourForIP) {
		this.numberOfQuotesLastTwentyfourHourForIP = numberOfQuotesLastTwentyfourHourForIP;
	}

	/**
	 * @return {@link #dateNumberOfQuoteForIPCalculated}
	 */
	public Date getDateNumberOfQuoteForIPCalculated() {
		return this.dateNumberOfQuoteForIPCalculated;
	}

	/**
	 * @param dateNumberOfQuoteForIPCalculated {@link #dateNumberOfQuoteForIPCalculated}
	 */
	public void setDateNumberOfQuoteForIPCalculated(Date dateNumberOfQuoteForIPCalculated) {
		this.dateNumberOfQuoteForIPCalculated = dateNumberOfQuoteForIPCalculated;
	}

	public InsuranceRisk getRisk(int riskSequence) {
		Map<Short, InsuranceRisk> newRisks = new HashMap<Short, InsuranceRisk>();
		for (InsuranceRisk risk : this.getInsuranceRisks()) {
			newRisks.put(risk.getInsuranceRiskSequence(), risk);
		}
		return newRisks.get((short) riskSequence);
	}

	public PolicyHolder getPolicyHolder(PolicyHolderTypeCodeEnum holderType) {
		if (this.holders == null) {
			Map<PolicyHolderTypeCodeEnum, PolicyHolder> newHolders = new HashMap<PolicyHolderTypeCodeEnum, PolicyHolder>();
			for (PolicyHolder holder : this.getPolicyHolders()) {
				newHolders.put(holder.getPolicyHolderType(), holder);
			}
			this.holders = newHolders;
		}
		return this.holders.get(holderType);
	}

	public List<DriverComplementInfo> getDrivers() {

		List<DriverComplementInfo> drivers = new ArrayList<DriverComplementInfo>();

		for (Party party : this.getParties()) {
			if (party.getDriverComplementInfo() != null) {
				drivers.add(party.getDriverComplementInfo());
			}
		}

		return drivers;
	}

	public DirectChanDistRepEntry getDirectChanDistRepEntry() {
		return this.directChanDistRepEntry;
	}

	public void setDirectChanDistRepEntry(DirectChanDistRepEntry directChanDistRepEntry) {
		this.directChanDistRepEntry = directChanDistRepEntry;
	}

	/**
	 * Safely obtain the distributor code from the policy version's DirectChanDistRepEntry.
	 *
	 * @return {@link DistributorCodeEnum}, null when not undefined or not initialized
	 */
	public DistributorCodeEnum getDistributorCode() {
		return (this.directChanDistRepEntry != null) ? this.directChanDistRepEntry.getCode() : null;
	}

	/**
	 * Safely obtain the manufacturing context form the policy version's insurance policy.
	 * @return {@link ManufacturingContext}
	 */
	public ManufacturingContext getManufacturingContext(){
		return (this.getInsurancePolicy() != null) ? this.getInsurancePolicy().getManufacturingContext(): null;
	}

	/**
	 * Safely obtain the province code form the policy version's manufacturing context.
	 * @return
	 */
	public ProvinceCodeEnum getProvince(){
		return (this.getManufacturingContext() != null ) ? this.getManufacturingContext().getProvince() : null;
	}


}
