/**
 * 
 */
package com.ing.canada.plp.exception;

/**
 * @author plafleur
 * 
 */
public class CloneException extends RuntimeException {

	private static final long serialVersionUID = -3923320037766327914L;

	public CloneException(String msg, Throwable source) {
		super(msg, source);
	}

}
