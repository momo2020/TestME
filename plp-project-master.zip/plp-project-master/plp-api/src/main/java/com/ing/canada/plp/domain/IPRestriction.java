package com.ing.canada.plp.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.enums.IPAdressTypeCodeEnum;
import com.ing.canada.plp.domain.enums.IPRestrictionTypeCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;


/**
 * IP Restriction.
 * 
 * @author devs
 *
 */
@Entity
@Table(name = "IP_RESTRICTION", uniqueConstraints = {})
@NamedQueries({	
	@NamedQuery(name = "IPRestriction.getEffectiveRestrictionForIP", query = "select r from IPRestriction r where r.ipNumber = :ipNumber and (r.endDate is null or sysdate < r.endDate) order by r.endDate desc"),
	@NamedQuery(name = "IPRestriction.getEffectiveRestrictionForIPAndCode", query = "select r from IPRestriction r where r.ipNumber = :ipNumber and r.restrictionTypeCode = :restrictionCode and (r.endDate is null or sysdate < r.endDate) order by r.endDate desc")
})
public class IPRestriction  extends BaseEntity {
	
	/* serial version UID */
	private static final long serialVersionUID = 5255079936459534989L;


	/**
	 * Instantiates a new IPRestriction.
	 */
	public IPRestriction() {
		// noarg constructor
	}
	
	/** The id. */
	@Id
	@Column(name = "IP_RESTRICTION_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "IPRestrictionSequence")
	@SequenceGenerator(name = "IPRestrictionSequence", sequenceName = "IP_RESTRICTION_SEQ", allocationSize = 5)
	private Long id;
	
	/** The transaction code. */
	@Column(name = "IP_TYPE_CD", nullable = false, length = 4)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.IPAdressTypeCodeEnum") })
	protected IPAdressTypeCodeEnum adressTypeCode;
	
	/** The ip adress. */
	@Column(name = "IP_NBR", length = 100)
	private String ipNumber;
	
	/** The transaction code. */
	@Column(name = "RESTRICTION_TYPE_CD", nullable = false, length = 5)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.IPRestrictionTypeCodeEnum") })
	protected IPRestrictionTypeCodeEnum restrictionTypeCode;
	
	@Column(name = "RESTRICTION_SEVERITY_QTY", nullable = true, precision = 3, scale = 0)
	@GeneratedValue(generator = "IPRestrictionSequence")
	private Byte restrictionSeverity;
	
	/** The start timestamp. */
	@Column(name = "START_TS", nullable = false, length = 11)
	private Date startDate;
	
	/** The end timestamp. */
	@Column(name = "END_TS", nullable = false, length = 11)
	private Date endDate;
	
	
	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.ipNumber= (String)aId;
	}

	public IPAdressTypeCodeEnum getAdressTypeCode() {
		return this.adressTypeCode;
	}

	public void setAdressTypeCode(IPAdressTypeCodeEnum adressTypeCode) {
		this.adressTypeCode = adressTypeCode;
	}

	public String getIpNumber() {
		return this.ipNumber;
	}

	public void setIpNumber(String ipNumber) {
		this.ipNumber = ipNumber;
	}

	public IPRestrictionTypeCodeEnum getRestrictionTypeCode() {
		return this.restrictionTypeCode;
	}

	public void setRestrictionTypeCode(IPRestrictionTypeCodeEnum restrictionTypeCode) {
		this.restrictionTypeCode = restrictionTypeCode;
	}

	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Byte getRestrictionSeverity() {
		return this.restrictionSeverity;
	}

	public void setRestrictionSeverity(Byte restrictionSeverity) {
		this.restrictionSeverity = restrictionSeverity;
	}
	
}
