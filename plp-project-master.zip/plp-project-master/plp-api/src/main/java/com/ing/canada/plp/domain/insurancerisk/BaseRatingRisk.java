/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insurancerisk;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.ClaimsFreeDiscountCodeEnum;
import com.ing.canada.plp.domain.enums.DrivingRecordCodeEnum;
import com.ing.canada.plp.domain.enums.DrivingRecordPrTermCodeEnum;
import com.ing.canada.plp.domain.enums.RatingRiskTypeCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * The Class BaseRatingRisk.
 * 
 * @author strichar
 */
@MappedSuperclass
public abstract class BaseRatingRisk extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The rating risk type. */
	@Column(name = "RATING_RISK_TYPE_CD", nullable = false, length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.RatingRiskTypeCodeEnum") })
	private RatingRiskTypeCodeEnum ratingRiskType;

	/** The driving record. */
	@Column(name = "DRIVING_RECORD_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.DrivingRecordCodeEnum") })
	private DrivingRecordCodeEnum drivingRecord;

	/** The driving record. */
	@Column(name = "DRIVING_RECORD_SYS_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.DrivingRecordCodeEnum") })
	private DrivingRecordCodeEnum drivingRecordSystem;

	/** The driving record. */
	@Column(name = "DRIVING_RECORD_MOD_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.DrivingRecordCodeEnum") })
	private DrivingRecordCodeEnum drivingRecordModification;

	/** The claims free discount. */
	@Column(name = "CLAIMS_FREE_DISCOUNT_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ClaimsFreeDiscountCodeEnum") })
	private ClaimsFreeDiscountCodeEnum claimsFreeDiscount;

	/** The system claims free discount. */
	@Column(name = "CLAIMS_FREE_DISCOUNT_SYS_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ClaimsFreeDiscountCodeEnum") })
	private ClaimsFreeDiscountCodeEnum claimsFreeDiscountSystem;

	/** The modification claims free discount. */
	@Column(name = "CLAIMS_FREE_DISCOUNT_MOD_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ClaimsFreeDiscountCodeEnum") })
	private ClaimsFreeDiscountCodeEnum claimsFreeDiscountModification;

	/** The insured group rated. */
	@Column(name = "INSURED_GROUP_RATED_CD", length = 3)
	private String insuredGroupRated;

	/** The insured group discount rated. */
	@Column(name = "INSURED_GROUP_DSCNT_RATED_PCT", precision = 5)
	private BigDecimal insuredGroupDiscountRated;

	/** The driving record pr term. */
	@Column(name = "DRIVING_RECORD_PR_TERM_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.DrivingRecordPrTermCodeEnum") })
	private DrivingRecordPrTermCodeEnum drivingRecordPrTerm;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;
	
	/** The rating risk class */
	@Column(name = "RATING_CLASS_CD", length = 2)
	private String ratingRiskClassCode;

	/**
	 * Instantiates a new rating risk.
	 */
	public BaseRatingRisk() {
		// noarg constructor
	}

	/**
	 * Instantiates a new rating risk.
	 * 
	 * @param aInsuranceRisk the a insurance risk
	 * @param aRatingRiskType the a rating risk type
	 */
	public BaseRatingRisk(InsuranceRisk aInsuranceRisk, RatingRiskTypeCodeEnum aRatingRiskType) {
		setInsuranceRisk(aInsuranceRisk);
		setRatingRiskType(aRatingRiskType);
	}

	/**
	 * Sets the insurance risk.
	 * 
	 * @param aInsuranceRisk the new insurance risk
	 */
	public void setInsuranceRisk(InsuranceRisk aInsuranceRisk) {
		AssociationsHelper.updateOneToManyFields(aInsuranceRisk, "ratingRisks", this, "insuranceRisk");
	}

	/**
	 * Gets the rating risk type.
	 * 
	 * @return the rating risk type
	 */
	public RatingRiskTypeCodeEnum getRatingRiskType() {
		return this.ratingRiskType;
	}

	/**
	 * Sets the rating risk type.
	 * 
	 * @param ratingRiskTypeCode the new rating risk type
	 */
	public void setRatingRiskType(RatingRiskTypeCodeEnum ratingRiskTypeCode) {
		this.ratingRiskType = ratingRiskTypeCode;
	}

	/**
	 * Gets the driving record.
	 * 
	 * @return the driving record
	 */
	public DrivingRecordCodeEnum getDrivingRecord() {
		return this.drivingRecord;
	}

	/**
	 * Sets the driving record.
	 * 
	 * @param drivingRecordCode the new driving record
	 */
	public void setDrivingRecord(DrivingRecordCodeEnum drivingRecordCode) {
		this.drivingRecord = drivingRecordCode;
	}

	/**
	 * Gets the claims free discount.
	 * 
	 * @return the claims free discount
	 */
	public ClaimsFreeDiscountCodeEnum getClaimsFreeDiscount() {
		return this.claimsFreeDiscount;
	}

	/**
	 * Sets the claims free discount.
	 * 
	 * @param claimsFreeDiscountCode the new claims free discount
	 */
	public void setClaimsFreeDiscount(ClaimsFreeDiscountCodeEnum claimsFreeDiscountCode) {
		this.claimsFreeDiscount = claimsFreeDiscountCode;
	}

	/**
	 * Gets the insured group rated.
	 * 
	 * @return the insured group rated
	 */
	public String getInsuredGroupRated() {
		return this.insuredGroupRated;
	}

	/**
	 * Sets the insured group rated.
	 * 
	 * @param insuredGroupRatedCode the new insured group rated
	 */
	public void setInsuredGroupRated(String insuredGroupRatedCode) {
		this.insuredGroupRated = insuredGroupRatedCode;
	}

	/**
	 * Gets the insured group discount rated.
	 * 
	 * @return the insured group discount rated
	 */
	public BigDecimal getInsuredGroupDiscountRated() {
		return this.insuredGroupDiscountRated;
	}

	/**
	 * Sets the insured group discount rated.
	 * 
	 * @param insuredGroupDscntRatedPercentage the new insured group discount rated
	 */
	public void setInsuredGroupDiscountRated(BigDecimal insuredGroupDscntRatedPercentage) {
		this.insuredGroupDiscountRated = insuredGroupDscntRatedPercentage;
	}

	/**
	 * Adds the coverage premium.
	 * 
	 * @param premium the premium
	 */
	public void addCoveragePremium(com.ing.canada.plp.domain.coverage.CoveragePremium premium) {
		AssociationsHelper.updateOneToManyFields(this, "coveragePremiums", premium, "ratingRisk");
	}

	/**
	 * Removes the coverage premium.
	 * 
	 * @param premium the premium
	 */
	public void removeCoveragePremium(com.ing.canada.plp.domain.coverage.CoveragePremium premium) {
		AssociationsHelper.updateOneToManyFields(null, "coveragePremiums", premium, "ratingRisk");
	}

	/**
	 * Gets the expiry date.
	 * 
	 * @return the expiryDate
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * Sets the expiry date.
	 * 
	 * @param aExpiryDate the expiryDate to set
	 */
	public void setExpiryDate(Date aExpiryDate) {
		this.expiryDate = aExpiryDate;
	}

	/**
	 * Gets the driving record modification.
	 * 
	 * @return the drivingRecordModification
	 */
	public DrivingRecordCodeEnum getDrivingRecordModification() {
		return this.drivingRecordModification;
	}

	/**
	 * Sets the driving record modification.
	 * 
	 * @param aDrivingRecordModification the drivingRecordModification to set
	 */
	public void setDrivingRecordModification(DrivingRecordCodeEnum aDrivingRecordModification) {
		this.drivingRecordModification = aDrivingRecordModification;
	}

	/**
	 * Gets the driving record system.
	 * 
	 * @return the drivingRecordSystem
	 */
	public DrivingRecordCodeEnum getDrivingRecordSystem() {
		return this.drivingRecordSystem;
	}

	/**
	 * Sets the driving record system.
	 * 
	 * @param aDrivingRecordSystem the drivingRecordSystem to set
	 */
	public void setDrivingRecordSystem(DrivingRecordCodeEnum aDrivingRecordSystem) {
		this.drivingRecordSystem = aDrivingRecordSystem;
	}

	/**
	 * Gets the claims free discount modification.
	 * 
	 * @return the claims free discount modification
	 */
	public ClaimsFreeDiscountCodeEnum getClaimsFreeDiscountModification() {
		return this.claimsFreeDiscountModification;
	}

	/**
	 * Sets the claims free discount modification.
	 * 
	 * @param aClaimsFreeDiscountModification the new claims free discount modification
	 */
	public void setClaimsFreeDiscountModification(ClaimsFreeDiscountCodeEnum aClaimsFreeDiscountModification) {
		this.claimsFreeDiscountModification = aClaimsFreeDiscountModification;
	}

	/**
	 * Gets the claims free discount system.
	 * 
	 * @return the claims free discount system
	 */
	public ClaimsFreeDiscountCodeEnum getClaimsFreeDiscountSystem() {
		return this.claimsFreeDiscountSystem;
	}

	/**
	 * Sets the claims free discount system.
	 * 
	 * @param aClaimsFreeDiscountSystem the new claims free discount system
	 */
	public void setClaimsFreeDiscountSystem(ClaimsFreeDiscountCodeEnum aClaimsFreeDiscountSystem) {
		this.claimsFreeDiscountSystem = aClaimsFreeDiscountSystem;
	}

	/**
	 * Gets the driving record pr term.
	 * 
	 * @return the driving record pr term
	 */
	public DrivingRecordPrTermCodeEnum getDrivingRecordPrTerm() {
		return this.drivingRecordPrTerm;
	}

	/**
	 * Sets the driving record pr term.
	 * 
	 * @param aDrivingRecordPrTerm the new driving record pr term
	 */
	public void setDrivingRecordPrTerm(DrivingRecordPrTermCodeEnum aDrivingRecordPrTerm) {
		this.drivingRecordPrTerm = aDrivingRecordPrTerm;
	}

	/**
	 * Gets the rating risk class
	 * 
	 * @return the rating risk class
	 */
	public String getRatingRiskClassCode() {
		return ratingRiskClassCode;
	}
	
	/**
	 * Sets the rating risk class
	 * 
	 * @param ratingRiskClassCode the new rating risk class
	 */
	public void setRatingRiskClassCode(String ratingRiskClassCode) {
		this.ratingRiskClassCode = ratingRiskClassCode;
	}
}
