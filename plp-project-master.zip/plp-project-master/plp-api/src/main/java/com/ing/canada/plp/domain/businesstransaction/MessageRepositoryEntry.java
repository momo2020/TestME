/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.businesstransaction;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.ManufacturingContext;
import com.ing.canada.plp.domain.enums.LanguageCodeEnum;
import com.ing.canada.plp.domain.enums.MessageAcceptationLevelTypeCodeEnum;
import com.ing.canada.plp.domain.enums.MessageNatureCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * MessageRepositoryEntry entity.
 * 
 * @author Patrick Lafleur
 */
@Entity
@Table(name = "MESSAGE_REPOSITORY_ENTRY", uniqueConstraints = {})
public class MessageRepositoryEntry extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "MESSAGE_REPOSITORY_ENTRY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	// @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MESSAGE_REPOSITORY_ENTRY_SEQ")
	@GeneratedValue(generator = "MessageRepositoryEntrySequence")
	@SequenceGenerator(name = "MessageRepositoryEntrySequence", sequenceName = "MESSAGE_REPOSITORY_ENTRY_SEQ", allocationSize = 5)
	private Long id;

	/** The manufacturing context. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "MANUFACTURING_CONTEXT_ID", updatable = true)
	private ManufacturingContext manufacturingContext;

	/** The language code. */
	@Column(name = "LANGUAGE_CD", nullable = false, length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.LanguageCodeEnum") })
	private LanguageCodeEnum language;

	/** The message number. */
	@Column(name = "MESSAGE_NBR", length = 8)
	private String messageNumber;

	/** The message nature code. */
	@Column(name = "MESSAGE_NATURE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.MessageNatureCodeEnum") })
	private MessageNatureCodeEnum messageNatureCode;

	/** The message desc. */
	@Column(name = "MESSAGE_DESC", nullable = false, length = 480)
	private String messageDescription;

	/** The msg acceptation level type code. */
	@Column(name = "MSG_ACCEPTATION_LEVEL_TYPE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.MessageAcceptationLevelTypeCodeEnum") })
	private MessageAcceptationLevelTypeCodeEnum messageAcceptationLevelType;

	/** The lvl of authority broker. */
	@Column(name = "LVL_OF_AUTHORITY_BROKER_QTY", precision = 2, scale = 0)
	private Byte levelOfAuthorityBroker;

	/** The lvl of authority in house. */
	@Column(name = "LVL_OF_AUTHORITY_IN_HOUSE_QTY", precision = 2, scale = 0)
	private Byte levelOfAuthorityInHouse;

	/**
	 * Instantiates a new message repository entry.
	 */
	public MessageRepositoryEntry() {
		// noarg constructor
	}

	/**
	 * Instantiates a new message repository entry.
	 * 
	 * @param aLanguageCode the a language code
	 * @param aMessageDescription the a message desc
	 */
	public MessageRepositoryEntry(LanguageCodeEnum aLanguageCode, String aMessageDescription) {
		setLanguage(aLanguageCode);
		setMessageDescription(aMessageDescription);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the manufacturing context.
	 * 
	 * @return the manufacturing context
	 */
	public ManufacturingContext getManufacturingContext() {
		return this.manufacturingContext;
	}

	/**
	 * Sets the manufacturing context.
	 * 
	 * @param aManufacturingContext the new manufacturing context
	 */
	public void setManufacturingContext(ManufacturingContext aManufacturingContext) {

		this.manufacturingContext = aManufacturingContext;
	}

	/**
	 * Gets the language code.
	 * 
	 * @return the language code
	 */
	public LanguageCodeEnum getLanguage() {
		return this.language;
	}

	/**
	 * Sets the language code.
	 * 
	 * @param aLanguageCode the new language code
	 */
	public void setLanguage(LanguageCodeEnum aLanguageCode) {
		this.language = aLanguageCode;
	}

	/**
	 * Gets the message number.
	 * 
	 * @return the message number
	 */
	public String getMessageNumber() {
		return this.messageNumber;
	}

	/**
	 * Sets the message number.
	 * 
	 * @param aMessageNumber the new message number
	 */
	public void setMessageNumber(String aMessageNumber) {
		
		this.messageNumber = aMessageNumber;
		
		if (aMessageNumber != null && aMessageNumber.length() > 8) {
			this.messageNumber = this.messageNumber.substring(0, 7);
		}		
	}

	/**
	 * Gets the message nature code.
	 * 
	 * @return the message nature code
	 */
	public MessageNatureCodeEnum getMessageNatureCode() {
		return this.messageNatureCode;
	}

	/**
	 * Sets the message nature code.
	 * 
	 * @param aMessageNatureCode the new message nature code
	 */
	public void setMessageNatureCode(MessageNatureCodeEnum aMessageNatureCode) {
		this.messageNatureCode = aMessageNatureCode;
	}

	/**
	 * Gets the message desc.
	 * 
	 * @return the message desc
	 */
	public String getMessageDescription() {
		return this.messageDescription;
	}

	/**
	 * Sets the message desc.
	 * 
	 * @param aMessageDesc the new message desc
	 */
	public void setMessageDescription(String aMessageDesc) {
		this.messageDescription = aMessageDesc;
	}

	/**
	 * Gets the msg acceptation level type code.
	 * 
	 * @return the msg acceptation level type code
	 */
	public MessageAcceptationLevelTypeCodeEnum getMessageAcceptationLevelType() {
		return this.messageAcceptationLevelType;
	}

	/**
	 * Sets the msg acceptation level type code.
	 * 
	 * @param aMsgAcceptationLevelTypeCode the new msg acceptation level type code
	 */
	public void setMessageAcceptationLevelType(MessageAcceptationLevelTypeCodeEnum aMsgAcceptationLevelTypeCode) {
		this.messageAcceptationLevelType = aMsgAcceptationLevelTypeCode;
	}

	/**
	 * Gets the lvl of authority broker.
	 * 
	 * @return the lvl of authority broker
	 */
	public Byte getLevelOfAuthorityBroker() {
		return this.levelOfAuthorityBroker;
	}

	/**
	 * Sets the lvl of authority broker.
	 * 
	 * @param aLvlOfAuthorityBroker the new lvl of authority broker
	 */
	public void setLevelOfAuthorityBroker(Byte aLvlOfAuthorityBroker) {
		this.levelOfAuthorityBroker = aLvlOfAuthorityBroker;
	}

	/**
	 * Gets the lvl of authority in house.
	 * 
	 * @return the lvl of authority in house
	 */
	public Byte getLevelOfAuthorityInHouse() {
		return this.levelOfAuthorityInHouse;
	}

	/**
	 * Sets the lvl of authority in house.
	 * 
	 * @param aLvlOfAuthorityInHouse the new lvl of authority in house
	 */
	public void setLevelOfAuthorityInHouse(Byte aLvlOfAuthorityInHouse) {
		this.levelOfAuthorityInHouse = aLvlOfAuthorityInHouse;
	}

	/**
	 * Adds the transactional message.
	 * 
	 * @param msg the msg
	 */
	public void addTransactionalMessage(com.ing.canada.plp.domain.businesstransaction.TransactionalMessage msg) {
		AssociationsHelper.updateOneToManyFields(this, "transactionalMessages", msg, "messageRepositoryEntry");
	}

	/**
	 * Removes the transactional message.
	 * 
	 * @param msg the msg
	 */
	public void removeTransactionalMessage(com.ing.canada.plp.domain.businesstransaction.TransactionalMessage msg) {
		AssociationsHelper.updateOneToManyFields(null, "transactionalMessages", msg, "messageRepositoryEntry");
	}

}
