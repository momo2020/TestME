/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insuranceriskoffer;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * CoveragePremiumOffer entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity 
@Table(name = "COVERAGE_PREMIUM_OFFER", uniqueConstraints = {})
@NamedQueries( {
		@NamedQuery(name = "CoveragePremium.getCoveragePremiumOfferNotInList", query = "from CoveragePremiumOffer cpo where cpo.coverageOffer.insuranceRiskOffer.id = :insuranceOfferId and cpo.coverageOffer.coverageRepositoryEntry.coverageCode not in (:coverageCodeEnum) and cpo.ratingRiskOffer.id = :ratingRiskOfferId"),
		@NamedQuery(name = "CoveragePremium.getSelectedCoveragePremiumOfferInList", query = "from CoveragePremiumOffer cpo where cpo.coverageOffer.insuranceRiskOffer.id = :insuranceOfferId and cpo.coverageOffer.coverageRepositoryEntry.coverageCode in (:coverageCodeEnum) and cpo.coverageOffer.coverageSelectedIndicator = true and cpo.ratingRiskOffer.id = :ratingRiskOfferId"),
		@NamedQuery(name = "CoveragePremium.getCoveragePremiumOffers", query = "from CoveragePremiumOffer cpo where cpo.coverageOffer.insuranceRiskOffer.id = :insuranceOfferId and cpo.ratingRiskOffer.id = :ratingRiskOfferId"),
		@NamedQuery(name = "CoveragePremium.getCoveragePremiumOffersOnPolicyOfferRating", query = "from CoveragePremiumOffer cpo where cpo.coverageOffer.insuranceRiskOffer.policyOfferRating.id = :policyOfferRatingId") })
public class CoveragePremiumOffer extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "COVERAGE_PREMIUM_OFFER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "CoveragePremiumOfferSequence")
	@SequenceGenerator(name = "CoveragePremiumOfferSequence", sequenceName = "COVERAGE_PREMIUM_OFFER_SEQ", allocationSize = 5)
	private Long id;

	/** The coverage offer. */
	@ManyToOne(cascade = { CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name = "COVERAGE_OFFER_ID", nullable = false, insertable = true, updatable = false)
	private CoverageOffer coverageOffer;

	/** The annual premium amount. */
	@Column(name = "ANNUAL_PREMIUM_AMT", precision = 12, scale = 3)
	private Double annualPremium;

	/** The full term premium amount. */
	@Column(name = "FULL_TERM_PREMIUM_AMT", precision = 12, scale = 3)
	private Double fullTermPremium;

	/** The annual premium amount. */
	@Column(name = "ANNUAL_PREMIUM_WITH_CAA_AMT", precision = 12, scale = 3)
	private Double annualPremiumCAA;

	/** The full term premium amount. */
	@Column(name = "FULL_TERM_PREMIUM_WITH_CAA_AMT", precision = 12, scale = 3)
	private Double fullTermPremiumCAA;

	/** The additional return premium amount. */
	@Column(name = "ADDITIONAL_RETURN_PREMIUM_AMT", precision = 12, scale = 3)
	private Double additionalReturnPremium;

	/** The sub coverage premium offer. */
	@OneToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "coveragePremiumOffer")
	@Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private SubCoveragePremiumOffer subCoveragePremiumOffer = null;

	/** The rating risk offer. */
	@ManyToOne(cascade = { CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name = "RATING_RISK_OFFER_ID", nullable = false, insertable = true, updatable = false)
	private RatingRiskOffer ratingRiskOffer;

	/** The rated indicator. */
	@Column(name = "RATED_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean ratedIndicator = null;

	/**
	 * Instantiates a new coverage premium offer.
	 */
	public CoveragePremiumOffer() {
		// noarg constructor
	}

	/**
	 * Instantiates a new coverage premium offer.
	 * 
	 * @param aCoverageOffer the a coverage offer
	 * @param aRatingRiskOffer the a rating risk offer
	 */
	public CoveragePremiumOffer(CoverageOffer aCoverageOffer, RatingRiskOffer aRatingRiskOffer) {
		setCoverageOffer(aCoverageOffer);
		setRatingRiskOffer(aRatingRiskOffer);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the coverage offer.
	 * 
	 * @return the coverage offer
	 */
	@XmlTransient // parent
	public CoverageOffer getCoverageOffer() {
		return this.coverageOffer;
	}

	/**
	 * Sets the coverage offer.
	 * 
	 * @param aCoverageOffer the new coverage offer
	 */
	public void setCoverageOffer(CoverageOffer aCoverageOffer) {
		AssociationsHelper.updateOneToManyFields(aCoverageOffer, "coveragePremiumOffers", this, "coverageOffer");
	}

	/**
	 * Gets the annual premium amount.
	 * 
	 * @return the annual premium amount
	 */
	public Double getAnnualPremium() {
		return this.annualPremium;
	}

	/**
	 * Sets the annual premium amount.
	 * 
	 * @param aAnnualPremiumAmount the new annual premium amount
	 */
	public void setAnnualPremium(Double aAnnualPremiumAmount) {
		this.annualPremium = aAnnualPremiumAmount;
	}

	/**
	 * Gets the full term premium amount.
	 * 
	 * @return the full term premium amount
	 */
	public Double getFullTermPremium() {
		return this.fullTermPremium;
	}

	/**
	 * Sets the full term premium amount.
	 * 
	 * @param aFullTermPremiumAmount the new full term premium amount
	 */
	public void setFullTermPremium(Double aFullTermPremiumAmount) {
		this.fullTermPremium = aFullTermPremiumAmount;
	}

	/**
	 * Gets the additional return premium amount.
	 * 
	 * @return the additional return premium amount
	 */
	public Double getAdditionalReturnPremium() {
		return this.additionalReturnPremium;
	}

	/**
	 * Sets the additional return premium amount.
	 * 
	 * @param aAdditionalReturnPremiumAmount the new additional return premium amount
	 */
	public void setAdditionalReturnPremium(Double aAdditionalReturnPremiumAmount) {
		this.additionalReturnPremium = aAdditionalReturnPremiumAmount;
	}

	/**
	 * Gets the sub coverage premium offer.
	 * 
	 * @return the sub coverage premium offer
	 */
	public SubCoveragePremiumOffer getSubCoveragePremiumOffer() {
		return this.subCoveragePremiumOffer;
	}

	/**
	 * Sets the sub coverage premium offer.
	 * 
	 * @param aSubCoveragePremiumOffer the new sub coverage premium offer
	 */
	public void setSubCoveragePremiumOffer(SubCoveragePremiumOffer aSubCoveragePremiumOffer) {
		AssociationsHelper.updateOneToOneFields(this, CoveragePremiumOffer.class, "subCoveragePremiumOffer",
				aSubCoveragePremiumOffer, SubCoveragePremiumOffer.class, "coveragePremiumOffer");
	}

	/**
	 * Gets the rating risk offer.
	 * 
	 * @return the rating risk offer
	 */
	@XmlTransient // parent
	public RatingRiskOffer getRatingRiskOffer() {
		return this.ratingRiskOffer;
	}

	/**
	 * Sets the rating risk offer.
	 * 
	 * @param aRatingRiskOffer the new rating risk offer
	 */
	public void setRatingRiskOffer(RatingRiskOffer aRatingRiskOffer) {
		AssociationsHelper.updateOneToManyFields(aRatingRiskOffer, "coveragePremiumOffers", this, "ratingRiskOffer");

	}

	/**
	 * Gets the rated indicator.
	 * 
	 * @return the rated indicator
	 */
	public Boolean getRatedIndicator() {
		return this.ratedIndicator;
	}

	/**
	 * Sets the rated indicator.
	 * 
	 * @param aRatedIndicator the new rated indicator
	 */
	public void setRatedIndicator(Boolean aRatedIndicator) {
		this.ratedIndicator = aRatedIndicator;
	}

	public Double getAnnualPremiumCAA() {
		return this.annualPremiumCAA;
	}

	public void setAnnualPremiumCAA(Double aAnnualPremiumCAA) {
		this.annualPremiumCAA = aAnnualPremiumCAA;
	}

	public Double getFullTermPremiumCAA() {
		return this.fullTermPremiumCAA;
	}

	public void setFullTermPremiumCAA(Double aFullTermPremiumCAA) {
		this.fullTermPremiumCAA = aFullTermPremiumCAA;
	}
	
}
