/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum PolicyVersionTypeCodeEnum.
 */
public enum PolicyVersionTypeCodeEnum {

	AUTOMOBILE_AND_RESIDENTIAL_PRODUCT_INCLUDED("AR"), 
	INDIVIDUAL_AUTOMOBILE_PERSONAL("AU"), 
	ONLY_RESIDENTIAL_PRODUCT_INCLUDED("RE"),
	INDIVIDUAL_AUTOMOBILE_COMMERCIAL("AUC")
	;

	/**
	 * Instantiates a new policy version type code enum.
	 * 
	 * @param aCode the a code
	 */
	private PolicyVersionTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the policy version type code enum
	 */
	public static PolicyVersionTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (PolicyVersionTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
