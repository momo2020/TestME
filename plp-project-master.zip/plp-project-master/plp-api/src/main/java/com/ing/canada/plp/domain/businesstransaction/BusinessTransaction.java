/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.businesstransaction;

import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.ApplicationFlowStateCodeEnum;
import com.ing.canada.plp.domain.enums.PolicyChangeTypeCodeEnum;
import com.ing.canada.plp.domain.enums.TransactionCodeEnum;
import com.ing.canada.plp.domain.enums.TransactionStatusCodeEnum;
import com.ing.canada.plp.domain.enums.UserLastAccessedPageCodeEnum;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * BusinessTransaction entity.
 * 
 * @author Patrick Lafleur
 * 
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "BUSINESS_TRANSACTION", uniqueConstraints = {})
public class BusinessTransaction extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "BUSINESS_TRANSACTION_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "BusinessTransactionSequence")
	@SequenceGenerator(name = "BusinessTransactionSequence", sequenceName = "BUSINESS_TRANSACTION_SEQ", allocationSize = 5)
	protected Long id;

	/** The policy version. */
	@OneToOne(optional = false, fetch = FetchType.LAZY, mappedBy = "businessTransaction")
	protected PolicyVersion policyVersion = null;

	/** The transaction code. */
	@Column(name = "TRANSACTION_CD", nullable = false, length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.TransactionCodeEnum") })
	protected TransactionCodeEnum transactionCode;

	/** The transaction status. */
	@Column(name = "TRANSACTION_STATUS_CD", nullable = true, length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.TransactionStatusCodeEnum") })
	protected TransactionStatusCodeEnum transactionStatus;

	/** The creation date time. */
	@Column(name = "CREATION_TS", nullable = false, length = 11)
	@Temporal(TemporalType.TIMESTAMP)
	protected Date creationDateTime;

	/** The transaction sequence. */
	@Column(name = "TRANSACTION_SEQ", nullable = false, precision = 4, scale = 0)
	protected short transactionSequence;

	/** The transaction effective date time. */
	@Column(name = "TRANSACTION_EFFECTIVE_TS", length = 11)
	@Temporal(TemporalType.TIMESTAMP)
	protected Date transactionEffectiveDateTime;

	/** The processing date time. */
	@Column(name = "PROCESSING_TS", length = 11)
	@Temporal(TemporalType.TIMESTAMP)
	protected Date processingDateTime;

	/** The last rating sequence. */
	@Column(name = "LAST_RATING_SEQ", precision = 4, scale = 0)
	protected Short lastRatingSequence;

	/** The transactional paper. */
	@Column(name = "TRANSACTIONAL_PAPER_IND", length = 1)
	@Type(type = "yes_no")
	protected Boolean transactionalPaperIndicator;

	@Column(name = "USER_LAST_PAGE_ACCESSED_CD", length = 10)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.UserLastAccessedPageCodeEnum") })
	protected UserLastAccessedPageCodeEnum userLastAccessedPage = null;

	/** The policy change type. */
	@Column(name = "POLICY_CHANGE_TYPE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PolicyChangeTypeCodeEnum") })
	protected PolicyChangeTypeCodeEnum policyChangeType;

	/** The business transaction activities. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "businessTransaction")
	@OrderBy("auditTrail.createTimestamp ASC")
	protected Set<BusinessTransactionActivity> businessTransactionActivities = new HashSet<BusinessTransactionActivity>();

	/** The current application flow state. */
	@Column(name = "CURRENT_APP_FLOW_STATE_CD", length = 20)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ApplicationFlowStateCodeEnum") })
	protected ApplicationFlowStateCodeEnum currentApplicationFlowState = null;

	/** The previous application flow state. */
	@Column(name = "PREVIOUS_APP_FLOW_STATE_CD", length = 20)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ApplicationFlowStateCodeEnum") })
	protected ApplicationFlowStateCodeEnum previousApplicationFlowState = null;

	/** The send paper at previous address indicator. */
	@Column(name = "SEND_PAPER_PREV_ADDRESS_IND", length = 1)
	@Type(type = "yes_no")
	protected Boolean sendPaperAtPreviousAddressIndicator;

	/** The last update date time. */
	@Column(name = "LAST_UPDATE_TS", length = 11)
	@Temporal(TemporalType.TIMESTAMP)
	protected Date lastUpdateDateTime;

	/**
	 * Instantiates a new business transaction.
	 */
	public BusinessTransaction() {
		// noarg constructor
	}

	/**
	 * Instantiates a new business transaction.
	 * 
	 * @param aTransactionCode the a transaction code
	 * @param aCreationTimestamp the a creation timestamp
	 * @param aPolicyVersion the a policy version
	 * @param status {@link TransactionStatusCodeEnum}
	 */
	public BusinessTransaction(PolicyVersion aPolicyVersion, TransactionCodeEnum aTransactionCode,
			TransactionStatusCodeEnum status, Date aCreationTimestamp) {
		setPolicyVersion(aPolicyVersion);
		setTransactionCode(aTransactionCode);
		setTransactionStatus(status);
		setCreationDateTime(aCreationTimestamp);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@XmlAttribute
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the transaction code.
	 * 
	 * @return the transaction code
	 */
	public TransactionCodeEnum getTransactionCode() {
		return this.transactionCode;
	}

	/**
	 * Sets the transaction code.
	 * 
	 * @param aTransactionCode the new transaction code
	 */
	public void setTransactionCode(TransactionCodeEnum aTransactionCode) {
		this.transactionCode = aTransactionCode;
	}

	/**
	 * Gets the transaction status.
	 * 
	 * @return the transaction status
	 */
	public TransactionStatusCodeEnum getTransactionStatus() {
		return this.transactionStatus;
	}

	/**
	 * Sets the transaction status.
	 * 
	 * @param transactionStatusCode the new transaction status
	 */
	public void setTransactionStatus(TransactionStatusCodeEnum transactionStatusCode) {
		this.transactionStatus = transactionStatusCode;
	}

	/**
	 * Gets the creation date time.
	 * 
	 * @return the creation date time
	 */
	public Date getCreationDateTime() {
		return this.creationDateTime;
	}

	/**
	 * Sets the creation date time.
	 * 
	 * @param creationTimestamp the new creation date time
	 */
	public void setCreationDateTime(Date creationTimestamp) {
		this.creationDateTime = creationTimestamp;
	}

	/**
	 * Gets the transaction sequence.
	 * 
	 * @return the transaction sequence
	 */
	public short getTransactionSequence() {
		return this.transactionSequence;
	}

	/**
	 * Sets the transaction sequence.
	 * 
	 * @param transactionSeq the new transaction sequence
	 */
	public void setTransactionSequence(short transactionSeq) {
		this.transactionSequence = transactionSeq;
	}

	/**
	 * Gets the transaction effective date time.
	 * 
	 * @return the transaction effective date time
	 */
	public Date getTransactionEffectiveDateTime() {
		return this.transactionEffectiveDateTime;
	}

	/**
	 * Sets the transaction effective date time.
	 * 
	 * @param transactionEffectiveTimestamp the new transaction effective date time
	 */
	public void setTransactionEffectiveDateTime(Date transactionEffectiveTimestamp) {
		this.transactionEffectiveDateTime = transactionEffectiveTimestamp;
	}

	/**
	 * Gets the processing date time.
	 * 
	 * @return the processing date time
	 */
	public Date getProcessingDateTime() {
		return this.processingDateTime;
	}

	/**
	 * Sets the processing date time.
	 * 
	 * @param processingTimestamp the new processing date time
	 */
	public void setProcessingDateTime(Date processingTimestamp) {
		this.processingDateTime = processingTimestamp;
	}

	/**
	 * Gets the last rating sequence.
	 * 
	 * @return the last rating sequence
	 */
	public Short getLastRatingSequence() {
		return this.lastRatingSequence;
	}

	/**
	 * Sets the last rating sequence.
	 * 
	 * @param lastRatingSeq the new last rating sequence
	 */
	public void setLastRatingSequence(Short lastRatingSeq) {
		this.lastRatingSequence = lastRatingSeq;
	}

	/**
	 * Gets the policy change type.
	 * 
	 * @return the policy change type
	 */
	public PolicyChangeTypeCodeEnum getPolicyChangeType() {
		return this.policyChangeType;
	}

	/**
	 * Sets the policy change type.
	 * 
	 * @param policyChangeTypeCode the new policy change type
	 */
	public void setPolicyChangeType(PolicyChangeTypeCodeEnum policyChangeTypeCode) {
		this.policyChangeType = policyChangeTypeCode;
	}

	/**
	 * Gets the policy versions.
	 * 
	 * @return the policy versions
	 */
	@XmlTransient // parent
	public PolicyVersion getPolicyVersion() {
		return this.policyVersion;
	}

	/**
	 * Sets the policy version.
	 * 
	 * @param aPolicyVersion the new policy version
	 */
	public void setPolicyVersion(PolicyVersion aPolicyVersion) {
		AssociationsHelper.updateOneToOneFields(aPolicyVersion, PolicyVersion.class, "businessTransaction", this,
				BusinessTransaction.class, "policyVersion");
	}

	/**
	 * Gets the business transaction activities.
	 * 
	 * @return the business transaction activities
	 */
	@XmlElementWrapper(name="businessTransactionActivities")
	@XmlElement(name="businessTransactionActivity")
	public Set<BusinessTransactionActivity> getBusinessTransactionActivities() {
		return Collections.unmodifiableSet(this.businessTransactionActivities);
	}

	/**
	 * Sets the business transaction activities.
	 * 
	 * @param aBusinessTransactionActivities the new business transaction activities
	 */
	protected void setBusinessTransactionActivities(Set<BusinessTransactionActivity> aBusinessTransactionActivities) {
		this.businessTransactionActivities = aBusinessTransactionActivities;
	}

	/**
	 * Adds the business transaction activity.
	 * 
	 * @param activity the activity
	 */
	public void addBusinessTransactionActivity(BusinessTransactionActivity activity) {
		AssociationsHelper
				.updateOneToManyFields(this, "businessTransactionActivities", activity, "businessTransaction");
	}

	/**
	 * Removes the business transaction activity.
	 * 
	 * @param activity the activity
	 */
	public void removeBusinessTransactionActivity(BusinessTransactionActivity activity) {
		AssociationsHelper
				.updateOneToManyFields(null, "businessTransactionActivities", activity, "businessTransaction");
	}

	/**
	 * @return the userLastAccessedPage
	 */
	public UserLastAccessedPageCodeEnum getUserLastAccessedPage() {
		return this.userLastAccessedPage;
	}

	/**
	 * @param aUserLastAccessedPage the userLastAccessedPage to set
	 */
	public void setUserLastAccessedPage(UserLastAccessedPageCodeEnum aUserLastAccessedPage) {
		this.userLastAccessedPage = aUserLastAccessedPage;
	}

	/**
	 * @return the transactionalPaperIndicator
	 */
	public Boolean getTransactionalPaperIndicator() {
		return this.transactionalPaperIndicator;
	}

	/**
	 * @param aTransactionalPaperIndicator the transactionalPaperIndicator to set
	 */
	public void setTransactionalPaperIndicator(Boolean aTransactionalPaperIndicator) {
		this.transactionalPaperIndicator = aTransactionalPaperIndicator;
	}

	/**
	 * @return the {@link #currentApplicationFlowState}
	 */
	public ApplicationFlowStateCodeEnum getCurrentApplicationFlowState() {
		return this.currentApplicationFlowState;
	}

	/**
	 * @param aCurrentApplicationFlowState {@link #currentApplicationFlowState}
	 */
	public void setCurrentApplicationFlowState(ApplicationFlowStateCodeEnum aCurrentApplicationFlowState) {
		this.currentApplicationFlowState = aCurrentApplicationFlowState;
	}

	/**
	 * Gets the previous application flow state.
	 * 
	 * @return the previous application flow state
	 */
	public ApplicationFlowStateCodeEnum getPreviousApplicationFlowState() {
		return this.previousApplicationFlowState;
	}

	/**
	 * Sets the previous application flow state.
	 * 
	 * @param aPreviousApplicationFlowState the new previous application flow state
	 */
	public void setPreviousApplicationFlowState(ApplicationFlowStateCodeEnum aPreviousApplicationFlowState) {
		this.previousApplicationFlowState = aPreviousApplicationFlowState;
	}

	/**
	 * Gets the last business transaction activity.
	 * 
	 * @return the last business transaction activity
	 */
	public BusinessTransactionActivity getLastBusinessTransactionActivity() {

		if (this.businessTransactionActivities.size() > 0) {
			return (BusinessTransactionActivity) this.businessTransactionActivities.toArray()[this.businessTransactionActivities
					.size() - 1];
		}

		return null;
	}

	/**
	 * Gets the send paper at previous address indicator.
	 * 
	 * @return the send paper at previous address indicator
	 */
	public Boolean getSendPaperAtPreviousAddressIndicator() {
		return this.sendPaperAtPreviousAddressIndicator;
	}

	/**
	 * Sets the send paper at previous address indicator.
	 * 
	 * @param aSendPaperAtPreviousAddressIndicator the new send paper at previous address indicator
	 */
	public void setSendPaperAtPreviousAddressIndicator(Boolean aSendPaperAtPreviousAddressIndicator) {
		this.sendPaperAtPreviousAddressIndicator = aSendPaperAtPreviousAddressIndicator;
	}

	/**
	 * Gets the last update date time.
	 * 
	 * @return the last update date time
	 */
	public Date getLastUpdateDateTime() {
		return this.lastUpdateDateTime;
	}

	/**
	 * Sets the last update date time.
	 * 
	 * @param aLastUpdateDateTime the new last update date time
	 */
	public void setLastUpdateDateTime(Date aLastUpdateDateTime) {
		this.lastUpdateDateTime = aLastUpdateDateTime;
	}

}
