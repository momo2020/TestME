/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.policyversion;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.NumberStabilityMonthsCodeEnum;
import com.ing.canada.plp.domain.enums.PolicyHolderTypeCodeEnum;
import com.ing.canada.plp.domain.party.Party;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * PolicyHolder entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "POLICY_HOLDER", uniqueConstraints = { @UniqueConstraint(columnNames = { "POLICY_VERSION_ID", "PARTY_ID" }) })
public class PolicyHolder extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "POLICY_HOLDER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "PolicyHolderSequence")
	@SequenceGenerator(name = "PolicyHolderSequence", sequenceName = "POLICY_HOLDER_SEQ", allocationSize = 5)
	private Long id;

	/** The policy version. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "POLICY_VERSION_ID", nullable = false, updatable = true)
	private PolicyVersion policyVersion;

	/** The party. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "PARTY_ID", nullable = false, updatable = true)
	protected Party party;

	/** The policy holder type. */
	@Column(name = "POLICY_HOLDER_TYPE_CD", nullable = false, length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PolicyHolderTypeCodeEnum") })
	private PolicyHolderTypeCodeEnum policyHolderType;

	/** The number of stability months. */
	@Column(name = "NBR_STABILITY_MONTHS_CD", length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.NumberStabilityMonthsCodeEnum") })
	private NumberStabilityMonthsCodeEnum numberStabilityMonthsCode = null;

	/** The annual premium. */
	@Column(name = "NBR_STABILITY_MONTHS_QTY", precision = 3, scale = 0)
	private Integer numberStabilityMonths;

	/** The original scenario policy holder. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_POLICY_HOLDER_ID", insertable = false, updatable = false)
	private PolicyHolder originalScenarioPolicyHolder;
	
	/** The rely network agreement indicator. ***POSTPONED*** */
	//@Column(name = "AGREE_TO_USE_AUTO_RELY_NET_IND", length = 1)
	//@Type(type = "yes_no")
	//private Boolean agreeToUseAutoRelyNetwork;
	
	/**
	 * Instantiates a new policy holder.
	 */
	public PolicyHolder() {
		// noarg constructor
	}

	/**
	 * Instantiates a new policy holder.
	 * 
	 * @param aPolicyVersion the a policy version
	 * @param aParty the a party
	 * @param aPolicyHolderTypeCode the policy holder type code
	 */
	public PolicyHolder(PolicyVersion aPolicyVersion, Party aParty, PolicyHolderTypeCodeEnum aPolicyHolderTypeCode) {
		setPolicyVersion(aPolicyVersion);
		setParty(aParty);
		setPolicyHolderTypeCode(aPolicyHolderTypeCode);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the policy version.
	 * 
	 * @return the policy version
	 */
	@XmlTransient // parent
	public PolicyVersion getPolicyVersion() {
		return this.policyVersion;
	}

	/**
	 * Sets the policy version.
	 * 
	 * @param aPolicyVersion the new policy version
	 */
	public void setPolicyVersion(PolicyVersion aPolicyVersion) {
		AssociationsHelper.updateOneToManyFields(aPolicyVersion, "policyHolders", this, "policyVersion");
	}

	/**
	 * Gets the party.
	 * 
	 * @return the party
	 */
	@XmlTransient // parent
	public Party getParty() {
		return this.party;
	}

	/**
	 * Sets the party.
	 * 
	 * @param aParty the new party
	 */
	public void setParty(Party aParty) {
		AssociationsHelper.updateOneToManyFields(aParty, "policyHolders", this, "party");
	}

	/**
	 * Gets the policy holder type.
	 * 
	 * @return the policy holder type
	 */
	public PolicyHolderTypeCodeEnum getPolicyHolderType() {
		return this.policyHolderType;
	}

	/**
	 * Sets the policy holder type code.
	 * 
	 * @param policyHolderTypeCode the new policy holder type code
	 */
	public void setPolicyHolderTypeCode(PolicyHolderTypeCodeEnum policyHolderTypeCode) {
		this.policyHolderType = policyHolderTypeCode;
	}

	/**
	 * @return the numberStabilityMonthsCode
	 */
	public NumberStabilityMonthsCodeEnum getNumberStabilityMonthsCode() {
		return this.numberStabilityMonthsCode;
	}

	/**
	 * @param aNumberStabilityMonthsCode the numberStabilityMonthsCode to set
	 */
	public void setNumberStabilityMonthsCode(NumberStabilityMonthsCodeEnum aNumberStabilityMonthsCode) {
		this.numberStabilityMonthsCode = aNumberStabilityMonthsCode;
	}

	/**
	 * @param aPolicyHolderType the policyHolderType to set
	 */
	public void setPolicyHolderType(PolicyHolderTypeCodeEnum aPolicyHolderType) {
		this.policyHolderType = aPolicyHolderType;
	}

	/**
	 * Gets the original scenario policy holder.
	 * 
	 * @return the original scenario policy holder
	 */
	@XmlTransient // reference source 
	public PolicyHolder getOriginalScenarioPolicyHolder() {
		return this.originalScenarioPolicyHolder;
	}

	/**
	 * Sets the original scenario policy holder.
	 * 
	 * @param anOriginalScenarioPolicyHolder the new original scenario policy holder
	 */
	public void setOriginalScenarioPolicyHolder(PolicyHolder anOriginalScenarioPolicyHolder) {
		this.originalScenarioPolicyHolder = anOriginalScenarioPolicyHolder;
	}

	/**
	 * @return the numberStabilityMonths
	 */
	public Integer getNumberStabilityMonths() {
		return this.numberStabilityMonths;
	}

	/**
	 * @param aNumberStabilityMonths the numberStabilityMonths to set
	 */
	public void setNumberStabilityMonths(Integer aNumberStabilityMonths) {
		this.numberStabilityMonths = aNumberStabilityMonths;
	}

	//public Boolean getAgreeToUseAutoRelyNetwork() {
	//	return agreeToUseAutoRelyNetwork;
	//}

	//public void setAgreeToUseAutoRelyNetwork(Boolean agreeToUseAutoRelyNetwork) {
	//	this.agreeToUseAutoRelyNetwork = agreeToUseAutoRelyNetwork;
	//}

}
