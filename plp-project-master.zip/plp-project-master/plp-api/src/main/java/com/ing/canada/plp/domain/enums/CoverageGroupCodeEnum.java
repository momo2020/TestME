/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import static org.apache.commons.lang.StringUtils.isBlank;
import static org.apache.commons.lang.StringUtils.equalsIgnoreCase;

/**
 * The Enum CoverageGroupCodeEnum.
 */
public enum CoverageGroupCodeEnum {
	STANDALONE_END("STANDALONE_END"),
	YOUNG_DRIV_DISCNT("YOUNG_DRIV_DISCNT"),
	MINIMUM_PREMIUM("MINIMUM_PREMIUM"),
	OUT_PROV_USE("OUT_PROV_USE"),
	MULTI_VEH_DISCNT("MULTI_VEH_DISCNT"),
	DUOFLEX_DISCNT("DUOFLEX_DISCNT"),
	INTERNET_DISCNT("INTERNET_DISCNT"),
	AUTOCOMFORT("AUTOCOMFORT"),
	DRIVING_COURS_DISCNT("DRIVING_COURS_DISCNT"),
	MEMBERSHIP_CAA("MEMBERSHIP_CAA"),
	SPECIAL_PROMO_DISCNT("SPECIAL_PROMO_DISCNT"),
	CAA_DISCNT("CAA_DISCNT"),
	ANTI_THEFT_DISCNT( "ANTI_THEFT_DISCNT"),
	GLASS_DEL_DISCNT("GLASS_DEL_DISCNT"),
	LOSS_OF_USE("LOSS_OF_USE"),
	WAIVER_DEPRECIATION("WAIVER_DEPRECIATION"),
	REPLACEMENT_COST("REPLACEMENT_COST"),
	CRASH_PROOF("CRASH_PROOF"),
	CRASH_PROOF_OPEN_RD("CRASH_PROOF_OPEN_RD"),
	DRIVER_OTH_AUTO("DRIVER_OTH_AUTO"),
	LEASE_VEH("LEASE_VEH"),
	SUSPEND_COV("SUSPEND_COV"),
	REINST_COV("REINST_COV"),
	VALUED_VEH("VALUED_VEH"),
	TRANSP_REPLAC("TRANSP_REPLAC"),
	RENTAL_CAR("RENTAL_CAR"),
	EXCLUDED_DRIVER("EXCLUDED_DRIVER"),
	RECREAT_VEH("RECREAT_VEH"),
	FIRE_DEDUC("FIRE_DEDUC"),
	BSC_COV_LIABILITY("BSC_COV_LIABILITY"),
	BSC_COV_COLLISION("BSC_COV_COLLISION"),
	BSC_COV_COMPREH("BSC_COV_COMPREH"),
	BSC_COV_ALL_PERIL("BSC_COV_ALL_PERIL"),
	BSC_COV_SPC_PERIL("BSC_COV_SPC_PERIL"),
	BSC_COV_ACC_BENEF("BSC_COV_ACC_BENEF"),
	WEEKLY_BENEF("WEEKLY_BENEF"),
	PLEASURE_OUT_PROV("PLEASURE_OUT_PROV"),
	BUSINESS_OUT_PROV("BUSINESS_OUT_PROV"),
	WINTER_TIRE_DISCNT("WINTER_TIRE_DISCNT"),
	ROADSIDE_ASSISTANCE("ROADSIDE_ASSISTANCE"),
	NEW_CRASH_PROOF("NEW_CRASH_PRF"),
	NEW_CRASH_PROOF_OPEN_RD("NEW_CRASH_PRF_OP_RD"),
	UBI("UBI"),
	CLAIMS_ADVNTG("CLAIMS_ADVNTG"),
	HAIL_COV("HAIL"),
	EXCESS_UMP("EXCESS_UMP"),
	WINDSHIELD_REPAIR("WINDSHIELD_REPAIR");

	/** The code. */
	private String code = null;
	
	/**
	 * Instantiates a new endorsement group code enum.
	 * 
	 * @param code the a code
	 */
	private CoverageGroupCodeEnum(final String code) {
		this.code = code;
	}

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the endorsement group code enum
	 */
	public static CoverageGroupCodeEnum valueOfCode(final String value) {
		if ( isBlank(value)) {
			return null;
		}

		for (CoverageGroupCodeEnum coverageGroupCodeEnum : values()) {
			if ( equalsIgnoreCase( coverageGroupCodeEnum.code, value) ) {
				return coverageGroupCodeEnum;
			}
		}

		throw new IllegalArgumentException("no enum value found for code: " + value);
	}
}