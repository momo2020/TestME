/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.Date;
import java.util.List;

import com.ing.canada.plp.domain.billing.Account;
import com.ing.canada.plp.domain.enums.BillingPlanCodeEnum;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;

public interface IAccountService extends ICRUDService<Account> {
	
	List<Account> findAccount(final BillingPlanCodeEnum billingPlan, final List<ManufacturerCompanyCodeEnum> manufactuterCompany, final Date fromDate, final Date toDate) throws Exception;
}
