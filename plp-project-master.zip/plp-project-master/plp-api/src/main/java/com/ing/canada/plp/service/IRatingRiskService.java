/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.domain.enums.RatingRiskTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.insurancerisk.RatingRisk;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * This interface exposes services required to manage Rating risks related entities.
 * 
 * @author R�gis Brochu
 */
public interface IRatingRiskService extends ICRUDService<RatingRisk> {

	/**
	 * This method returns all rating risks offers of all selected offers 
	 * of all insurance risk of the policy version.
	 * 
	 * @param policyVersion the policy version
	 * 
	 * @return the list< rating risk >
	 */
	List<RatingRisk> findAllRatingRisksByPolicyVersion(PolicyVersion policyVersion);	
	
	
	/** Returns the rating risk (if any) for the given rating risk type.
	 * 
	 * @param aRisk the insurance risk 
	 * @param aType rating risk type code
	 * @return RatingRisk the rating risk associated with the type
	 */
	RatingRisk findRatingRiskByType(InsuranceRisk aRisk, RatingRiskTypeCodeEnum aType);
}
