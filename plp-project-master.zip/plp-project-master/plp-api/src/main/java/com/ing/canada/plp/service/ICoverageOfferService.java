/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.insuranceriskoffer.CoverageOffer;

/**
 * This interface exposes services required to manage Coverage related entities.
 * 
 * @author fsimard
 */
public interface ICoverageOfferService extends ICRUDService<CoverageOffer> {
	// Nothing to implements
}
