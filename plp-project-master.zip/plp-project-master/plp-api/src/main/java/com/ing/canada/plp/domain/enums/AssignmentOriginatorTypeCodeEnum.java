package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

public enum AssignmentOriginatorTypeCodeEnum {

	SYSTEM("SYS"), CLIENT("CLI"), EMPLOYEE("EMP"), BROKER("BRK");

	/**
	 * Instantiates a new assignment originator type code enum.
	 * 
	 * @param aCode the a code
	 */
	private AssignmentOriginatorTypeCodeEnum(String aCode) {
		this.setCode(aCode);
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Sets the code.
	 * 
	 * @param aCode the new code
	 */
	public void setCode(String aCode) {
		this.code = aCode;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the branch code enum
	 */
	public static AssignmentOriginatorTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (AssignmentOriginatorTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}

}
