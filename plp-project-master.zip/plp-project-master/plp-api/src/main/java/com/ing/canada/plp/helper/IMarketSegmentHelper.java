package com.ing.canada.plp.helper;

import java.util.Set;

import com.ing.canada.plp.domain.policyversion.MarketSegment;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * MarketSegment utilities
 * 
 * @author sduchesn
 * 
 */
public interface IMarketSegmentHelper {
	/**
	 * Returns the list of the eligible segment names if they exist for the policyversion. ex:
	 * {"TYPE_A.SEGMENT1","TYPE_A.SEGMENT2","TYPE_B.SEGMENT1"}
	 * 
	 * @param policyVersion {@link PolicyVersion}
	 * @return the list of the eligible segment names
	 */
	Set<String> getEligibleMarketSegmentNames(PolicyVersion policyVersion);

	/**
	 * @param aPolicyVersion
	 * @return the number of segments present
	 */
	int getNbSegments(PolicyVersion aPolicyVersion);

	/**
	 * @param segments
	 * @param includeEligible
	 * @param includeNonEligible
	 * @return A segment list prefix with segement type : "TYPE_A.SEGMENT1, TYPE_A.SEGMENT2, TYPE_B.SEGMENT1"
	 */
	String printSegmentList(Set<MarketSegment> segments, boolean includeEligible, boolean includeNonEligible);

	/**
	 * Obtain the market segment name of the first market segment linked to a policy version
	 * 
	 * @param policyVersion {@link PolicyVersion}
	 * @return the market segment name
	 */
	String getFirstMarketSegmentName(PolicyVersion policyVersion);
}
