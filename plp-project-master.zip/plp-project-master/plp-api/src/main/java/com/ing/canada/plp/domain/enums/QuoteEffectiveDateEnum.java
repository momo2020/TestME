package com.ing.canada.plp.domain.enums;


/**
 * The Enum QuoteEffectiveDateMaxDayEnum.
 */
public enum QuoteEffectiveDateEnum {
	
	/** MAX DAYS 60 */
	MAX_DAYS_60(60), 
	
	/** MAX DAYS 90 */
	MAX_DAYS_90(90), 
	
	/** MAX DAYS 1 */
	MIN_DAYS_1(1), 
	
	/** MAX DAYS 5 */
	MIN_DAYS_5(5);
	

	/** The number of days. */
	private Integer days = null;

	/**
	 * Initiates a new quote effective date max day enum
	 * 
	 * @param aDays
	 */
	private QuoteEffectiveDateEnum (Integer aDays) {
		this.days = aDays;
	}
	
	/**
	 * Gets the number of days
	 * 
	 * @return {@link #days}
	 */
	public Integer getDays() {
		return this.days;
	}	

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the country code enum
	 */
	public static QuoteEffectiveDateEnum valueOfDays(Integer value) {

		if (value == null) {
			return null;
		}

		for (QuoteEffectiveDateEnum v : values()) {
			if (v.days.equals(value)) {
				return v;
			}
		}

		throw new IllegalArgumentException("no enum value found for the number of days: " + value);

	}
}

