package com.ing.canada.plp.domain.businesstransaction;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * The Class BusinessTransactionSubActivityComplementInfo.
 * 
 * @author Genevieve Meloche
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "BUS_TRX_SUB_ACTV_COMP_INF", uniqueConstraints = {})
public class BusinessTransactionSubActivityComplementInfo extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "BUS_TRX_SUB_ACTV_COMP_INF_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "BusinessTransactionSubActivityCompSequence")
	@SequenceGenerator(name = "BusinessTransactionSubActivityCompSequence", sequenceName = "BUS_TRX_SUB_ACTV_COMP_INF_SEQ", allocationSize = 5)
	private Long id;

	/** The attribute name. */
	@Column(name = "ATTRIBUTE_NAME_TXT", length = 32, nullable = false)
	private String attributeName;

	/** The attribute value. */
	@Column(name = "ATTRIBUTE_VALUE_TXT", length = 100, nullable = false)
	private String attributeValue;

	/** The business transaction sub activity. */
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "BUSINESS_TRX_SUB_ACTIVITY_ID", nullable = false)
	private BusinessTransactionSubActivity businessTransactionSubActivity = null;

	/**
	 * Instantiates a new business transaction sub activity complement info.
	 */
	public BusinessTransactionSubActivityComplementInfo() {
		// noarg constructor
	}

	/**
	 * Instantiates a new business transaction sub activity complement info.
	 * 
	 * @param aBusinessTransactionSubActivity the a business transaction sub activity
	 * @param anAttributeName the an attribute name
	 * @param anAttributeValue the an attribute value
	 */
	public BusinessTransactionSubActivityComplementInfo(BusinessTransactionSubActivity aBusinessTransactionSubActivity,
			String anAttributeName, String anAttributeValue) {
		setBusinessTransactionSubActivity(aBusinessTransactionSubActivity);
		setAttributeName(anAttributeName);
		setAttributeValue(anAttributeValue);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the attribute name.
	 * 
	 * @return the attribute name
	 */
	public String getAttributeName() {
		return this.attributeName;
	}

	/**
	 * Sets the attribute name.
	 * 
	 * @param anAttributeName the new attribute name
	 */
	public void setAttributeName(String anAttributeName) {
		this.attributeName = anAttributeName;
	}

	/**
	 * Gets the attribute value.
	 * 
	 * @return the attribute value
	 */
	public String getAttributeValue() {
		return this.attributeValue;
	}

	/**
	 * Sets the attribute value.
	 * 
	 * @param anAttributeValue the new attribute value
	 */
	public void setAttributeValue(String anAttributeValue) {
		this.attributeValue = anAttributeValue;
	}

	/**
	 * Gets the business transaction sub activity.
	 * 
	 * @return the business transaction sub activity
	 */
	@XmlTransient // parent
	public BusinessTransactionSubActivity getBusinessTransactionSubActivity() {
		return this.businessTransactionSubActivity;
	}

	/**
	 * Sets the business transaction sub activity.
	 * 
	 * @param aBusinessTransactionSubActivity the new business transaction sub activity
	 */
	public void setBusinessTransactionSubActivity(BusinessTransactionSubActivity aBusinessTransactionSubActivity) {
		AssociationsHelper.updateOneToManyFields(aBusinessTransactionSubActivity,
				"businessTransactionSubActivityComplementInfos", this, "businessTransactionSubActivity");
	}

}
