/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.policyversion;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.coverage.CoverageRepositoryEntry;
import com.ing.canada.plp.domain.enums.ActionTakenCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * PolicyAdditionalCoverage entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "POLICY_ADDITIONAL_COVERAGE", uniqueConstraints = {})
public class PolicyAdditionalCoverage extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "POLICY_ADDITIONAL_COVERAGE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "PolicyAdditionalCoverageSequence")
	@SequenceGenerator(name = "PolicyAdditionalCoverageSequence", sequenceName = "POLICY_ADDITIONAL_COVERAGE_SEQ", allocationSize = 5)
	private Long id;

	/** The policy version. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "POLICY_VERSION_ID", nullable = false, updatable = true)
	private PolicyVersion policyVersion;

	/** The coverage description. */
	@Column(name = "COVERAGE_DESC", length = 65)
	private String coverageDescription;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", length = 7)
	private Date effectiveDate;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;

	/** The coverage eligible indicator. */
	@Column(name = "COVERAGE_ELIGIBLE_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean coverageEligibleIndicator = null;

	/** The original scenario policy additional coverage id. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_POLICY_ADD_COV_ID", insertable = false, updatable = false)
	private PolicyAdditionalCoverage originalScenarioPolicyAdditionalCoverageId;

	/** The coverage repository entry. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "COVERAGE_REPOSITORY_ENTRY_ID", nullable = false, insertable = true, updatable = false)
	private CoverageRepositoryEntry coverageRepositoryEntry;

	/** The action taken. */
	@Column(name = "ACTION_TAKEN_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ActionTakenCodeEnum") })
	private ActionTakenCodeEnum actionTaken = null;
	
	/** The action taken. */
	@Column(name = "MOST_RECENT_USR_ACT_TAKEN_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ActionTakenCodeEnum") })
	private ActionTakenCodeEnum lastActionTaken = null;

	/**
	 * Instantiates a new policy additional coverage.
	 */
	public PolicyAdditionalCoverage() {
		// noarg constructor
	}

	/**
	 * Instantiates a new policy additional coverage.
	 * 
	 * @param aPolicyVersion the a policy version
	 * @param aCoverageRepositoryEntry the a coverage code
	 */
	public PolicyAdditionalCoverage(PolicyVersion aPolicyVersion, CoverageRepositoryEntry aCoverageRepositoryEntry) {
		setPolicyVersion(aPolicyVersion);
		setCoverageRepositoryEntry(aCoverageRepositoryEntry);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the policy version.
	 * 
	 * @return the policy version
	 */
	@XmlTransient // parent
	public PolicyVersion getPolicyVersion() {
		return this.policyVersion;
	}

	/**
	 * Sets the policy version.
	 * 
	 * @param aPolicyVersion the new policy version
	 */
	public void setPolicyVersion(PolicyVersion aPolicyVersion) {
		AssociationsHelper.updateOneToManyFields(aPolicyVersion, "policyAdditionalCoverages", this, "policyVersion");
	}

	/**
	 * Gets the coverage description.
	 * 
	 * @return the coverage description
	 */
	public String getCoverageDescription() {
		return this.coverageDescription;
	}

	/**
	 * Sets the coverage description.
	 * 
	 * @param coverageDesc the new coverage description
	 */
	public void setCoverageDescription(String coverageDesc) {
		this.coverageDescription = coverageDesc;
	}

	/**
	 * Gets the effective date.
	 * 
	 * @return the effective date
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * Sets the effective date.
	 * 
	 * @param aEffectiveDate the new effective date
	 */
	public void setEffectiveDate(Date aEffectiveDate) {
		this.effectiveDate = aEffectiveDate;
	}

	/**
	 * Gets the expiry date.
	 * 
	 * @return the expiry date
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * Sets the expiry date.
	 * 
	 * @param aExpiryDate the new expiry date
	 */
	public void setExpiryDate(Date aExpiryDate) {
		this.expiryDate = aExpiryDate;
	}

	/**
	 * Gets the original scenario policy additional coverage id.
	 * 
	 * @return the original scenario policy additional coverage id
	 */
	@XmlTransient // reference source
	public PolicyAdditionalCoverage getOriginalScenarioPolicyAdditionalCoverageId() {
		return this.originalScenarioPolicyAdditionalCoverageId;
	}

	/**
	 * Sets the original scenario policy additional coverage id.
	 * 
	 * @param anOriginalScenarioPolicyAdditionalCoverageId the new original scenario policy additional coverage id
	 */
	public void setOriginalScenarioPolicyAdditionalCoverageId(
			PolicyAdditionalCoverage anOriginalScenarioPolicyAdditionalCoverageId) {
		this.originalScenarioPolicyAdditionalCoverageId = anOriginalScenarioPolicyAdditionalCoverageId;
	}

	/**
	 * Gets the coverage repository entry.
	 * 
	 * @return the coverage repository entry
	 */
	public CoverageRepositoryEntry getCoverageRepositoryEntry() {
		return this.coverageRepositoryEntry;
	}

	/**
	 * Sets the coverage repository entry.
	 * 
	 * @param aCoverageRepositoryEntry the new coverage repository entry
	 */
	public void setCoverageRepositoryEntry(CoverageRepositoryEntry aCoverageRepositoryEntry) {
		this.coverageRepositoryEntry = aCoverageRepositoryEntry;

	}

	/**
	 * Gets the action taken.
	 * 
	 * @return the action taken
	 */
	public ActionTakenCodeEnum getActionTaken() {
		return this.actionTaken;
	}

	/**
	 * Sets the action taken.
	 * 
	 * @param anActionTaken the new action taken
	 */
	public void setActionTaken(ActionTakenCodeEnum anActionTaken) {
		this.actionTaken = anActionTaken;
	}

	public ActionTakenCodeEnum getLastActionTaken() {
		return lastActionTaken;
	}

	public void setLastActionTaken(ActionTakenCodeEnum lastActionTaken) {
		this.lastActionTaken = lastActionTaken;
	}

	/**
	 * @return the coverageEligibleIndicator
	 */
	public Boolean getCoverageEligibleIndicator() {
		return this.coverageEligibleIndicator;
	}

	/**
	 * @param aCoverageEligibleIndicator the coverageEligibleIndicator to set
	 */
	public void setCoverageEligibleIndicator(Boolean aCoverageEligibleIndicator) {
		this.coverageEligibleIndicator = aCoverageEligibleIndicator;
	}
}
