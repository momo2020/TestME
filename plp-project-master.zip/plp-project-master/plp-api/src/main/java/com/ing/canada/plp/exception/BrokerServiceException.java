package com.ing.canada.plp.exception;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

public class BrokerServiceException extends Exception {

	private static final long serialVersionUID = 7666030045274753629L;

	public static final String EXEC_DEFAULT_ERROR = "exec.broker.default.error";
	
	public static final String PARAM_CONTEXT_NULL = "param.broker.context.null";

	public static final String PARAM_QUOTE_REASSIGN_NULL = "param.broker.quote.reassign.null";
	
	public static final String PARAM_QUOTE_NOTE_NULL = "param.broker.quote.note.null";
	
	public static final String PARAM_QUOTE_UPLOAD_NULL = "param.broker.quote.upload.null";
	
	public static final String PARAM_QUOTE_BROKER_NULL = "param.broker.quote.broker.null";

	public static final String EXEC_REASSIGN_QUOTES_ERROR = "exec.broker.reassign.quotes.error";
	
	public static final String EXEC_UPLOAD_QUOTE_ERROR = "exec.broker.upload.quote.error";

	public static final String EXEC_ADD_QUOTE_NOTE_ERROR = "exec.broker.add.quote.note.error";

	public static final String EXEC_GET_BROKERS_LIST_ERROR = "exec.broker.get.brokers.list.error";


	private static Map<String, String> messages = null;

	private String code = null;

	public BrokerServiceException(String exceptionCode, Object... parameters) {
		this(exceptionCode, null, parameters);
	}

	public BrokerServiceException(String exceptionCode, Throwable cause, Object... parameters) {
		this(BrokerServiceException.getMessage(exceptionCode, parameters), cause);
		this.setCode(exceptionCode);
	}

	public BrokerServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public static Map<String, String> getMessages() {
		return BrokerServiceException.messages;
	}

	public static void setMessages(Map<String, String> messages) {
		BrokerServiceException.messages = messages;
	}

	protected static String getMessage(String exceptionCode, Object... parameters) {

		if (BrokerServiceException.getMessages() == null) {
			BrokerServiceException.initMessages();
		}

		String messageFormat = BrokerServiceException.getMessages().get(exceptionCode);

		if (messageFormat == null) {
			messageFormat = BrokerServiceException.getMessages().get(BrokerServiceException.EXEC_DEFAULT_ERROR);
		}

		return MessageFormat.format(messageFormat, parameters);
	}

	protected static synchronized void initMessages() {

		Map<String, String> messages = new HashMap<String, String>();

		messages.put(BrokerServiceException.EXEC_DEFAULT_ERROR,
				"An unknown error occured while using the Broker Service.  The error is not documented at this time.  The cause is {0}");

		messages.put(BrokerServiceException.PARAM_QUOTE_REASSIGN_NULL,
				"The quote reassign is null.  Please call the method using non-null QuoteReassign object.");
		
		messages.put(BrokerServiceException.PARAM_QUOTE_UPLOAD_NULL,
				"The quote upload is null.  Please call the method using non-null QuoteUpload object.");
		
		messages.put(BrokerServiceException.PARAM_CONTEXT_NULL,
				"The context is null.  Please call the method using non-null UserContext object.");
		
		messages.put(BrokerServiceException.PARAM_QUOTE_NOTE_NULL,
				"The note is null.  Please call the method using non-null QuoteNote object.");
		
		messages.put(BrokerServiceException.PARAM_QUOTE_BROKER_NULL,
				"The quote broker is null.  Please call the method using non-null QuoteBroker object.");

		messages.put(BrokerServiceException.EXEC_REASSIGN_QUOTES_ERROR,
				"An error while reassigning quotes using {1} with the context {2} and the reassign {3}.  The cause is {0}.");
		
		messages.put(BrokerServiceException.EXEC_UPLOAD_QUOTE_ERROR,
				"An error while uploading quote using {1} with the context {2} and the upload {3}.  The cause is {0}.");

		messages.put(BrokerServiceException.EXEC_GET_BROKERS_LIST_ERROR,
				"An error while retrieving list of brokers using {1} with the context {2} and the broker {3}.  The cause is {0}.");
		
		messages.put(BrokerServiceException.EXEC_ADD_QUOTE_NOTE_ERROR,
				"An error while adding a note to the policy using {1} with the context {2} and the note {3}.  The cause is {0}.");

		BrokerServiceException.setMessages(messages);
	}

}
