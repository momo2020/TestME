package com.ing.canada.plp.domain.policyemailtoken;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.insurancepolicy.InsurancePolicy;
import com.ing.canada.plp.domain.usertype.BaseEntity;

@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "POLICY_EMAIL_TOKEN", uniqueConstraints = {})
@NamedQueries({@NamedQuery(name = PolicyEmailToken.FIND_BY_INSURANCE_POLICY_AND_EVENT_TRIGGER_CD, query = "from PolicyEmailToken petok where upper(petok.eventTriggerCd) = upper(:eventTriggerCd) and petok.insurancePolicy.id = :policyId")})
public class PolicyEmailToken extends BaseEntity {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	public static final String FIND_BY_INSURANCE_POLICY_AND_EVENT_TRIGGER_CD = "PolicyEmailToken.findByInsurancePolicyAndEventTriggerCd";

	/** The id. */
	@Id
	@Column(name = "POLICY_EMAIL_TOKEN_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "PolicyEmailTokenSequence")
	@SequenceGenerator(name = "PolicyEmailTokenSequence", sequenceName = "POLICY_EMAIL_TOKEN_SEQ", allocationSize = 5)
	private Long id;
	
	/** The insurancePolicy. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_POLICY_ID", nullable = false, updatable = true)
	private InsurancePolicy insurancePolicy;
	
	
	/** The event trigger code. */
	@Column(name = "EVENT_TRIGGER_CD", nullable = false, length = 20)
	private String eventTriggerCd;
	
	/** The token. */
	@Column(name = "TOKEN_ID", nullable = false, length = 40)
	private String tokenId;
	
	/** The start timestamp. */
	@Column(name = "START_TS", nullable = false, length = 11)
	private Date startDate;
	
	/** The end timestamp. */
	@Column(name = "END_TS", nullable = true, length = 11)
	private Date endDate;
	
	/**
	 * The system date time.
	 */
	@Column(name = "SYSTEM_CREATE_TS", length = 11, insertable = false, updatable = false)
	protected Date systemDateTime;
	
	
	
	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the insurancePolicy.
	 * 
	 * @return the insurancePolicy
	 */
	@XmlTransient // parent
	public InsurancePolicy getInsurancePolicy() {
		return this.insurancePolicy;
	}

	/**
	 * Sets the insurancePolicy.
	 * 
	 * @param aInsurancePolicy the new insurancePolicy
	 */
	public void setInsurancePolicy(InsurancePolicy aInsurancePolicy) {
		AssociationsHelper.updateOneToManyFields(aInsurancePolicy, "policyEmailTokens", this, "insurancePolicy");
	}

	public String getEventTriggerCd() {
		return eventTriggerCd;
	}

	public void setEventTriggerCd(String eventTriggerCd) {
		this.eventTriggerCd = eventTriggerCd;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getSystemDateTime() {
		return systemDateTime;
	}

	public void setSystemDateTime(Date systemDateTime) {
		this.systemDateTime = systemDateTime;
	}

}
