/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum MethodOfPaymentCodeEnum.
 */
public enum MethodOfPaymentCodeEnum {

	BANKING_BY_PHONE("BP"), CASH_OR_CHEQUE("CC"), CREDIT_CARD("CD"), ELECTRONIC_FUNDS_TRANSFER("EF"), SALARY_DEDUCTION(
			"SD"), NON_AUTOMATIC_ACCOUNT("MA");

	/**
	 * Instantiates a new method of payment code enum.
	 * 
	 * @param aCode the a code
	 */
	private MethodOfPaymentCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the method of payment code enum
	 */
	public static MethodOfPaymentCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (MethodOfPaymentCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
