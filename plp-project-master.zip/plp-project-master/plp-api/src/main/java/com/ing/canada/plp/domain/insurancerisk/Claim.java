/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insurancerisk;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.ClaimCategoryCodeEnum;
import com.ing.canada.plp.domain.enums.ClaimConsideredCodeEnum;
import com.ing.canada.plp.domain.enums.ClaimLossDateCodeEnum;
import com.ing.canada.plp.domain.enums.ClaimStatusCodeEnum;
import com.ing.canada.plp.domain.enums.ClaimTypeCodeEnum;
import com.ing.canada.plp.domain.enums.NatureOfClaimCodeEnum;
import com.ing.canada.plp.domain.party.Party;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * Claim entity.
 * 
 * @author Patrick Lafleur
 * 
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "CLAIM", uniqueConstraints = {})
public class Claim extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "CLAIM_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "ClaimSequence")
	@SequenceGenerator(name = "ClaimSequence", sequenceName = "CLAIM_SEQ", allocationSize = 5)
	private Long id;

	/** The policy version. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "POLICY_VERSION_ID", updatable = true)
	private PolicyVersion policyVersion;

	/** The party. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "PARTY_ID", updatable = true)
	private Party party;

	/** The insurance risk. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_RISK_ID", updatable = true)
	private InsuranceRisk insuranceRisk;

	/** The claim type. */
	@Column(name = "CLAIM_TYPE_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ClaimTypeCodeEnum") })
	private ClaimTypeCodeEnum claimType;

	/** The nature of claim. */
	@Column(name = "NATURE_OF_CLAIM_CD", length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.NatureOfClaimCodeEnum") })
	private NatureOfClaimCodeEnum natureOfClaim;

	/** The claim number. */
	@Column(name = "CLAIM_NBR", length = 30)
	private String claimNumber;

	/** The claim status. */
	@Column(name = "CLAIM_STATUS_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ClaimStatusCodeEnum") })
	private ClaimStatusCodeEnum claimStatus;

	/** The date of loss. */
	@Temporal(TemporalType.DATE)
	@Column(name = "LOSS_DT", length = 7)
	private Date dateOfLoss;

	/** The loss date code. */
	@Column(name = "LOSS_DT_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ClaimLossDateCodeEnum") })
	private ClaimLossDateCodeEnum claimLossDateCode;

	/** The claim at fault. */
	@Column(name = "CLAIM_AT_FAULT_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean claimAtFaultIndicator;

	/** The claim considered code. */
	@Column(name = "CLAIM_CONSIDERED_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ClaimConsideredCodeEnum") })
	private ClaimConsideredCodeEnum claimConsideredCode;

	/** The percentage of liability. */
	@Column(name = "LIABILITY_PCT", precision = 3, scale = 0)
	private Short percentageOfLiability;

	/** The cancelled vehicle class. */
	@Column(name = "CANCELLED_VEHICLE_CLASS_CD", length = 5)
	private String cancelledVehicleClass;

	/** The claim ordering sequence. */
	@Column(name = "CLAIM_ORDERING_SEQ", precision = 3, scale = 0)
	private Short claimOrdering;

	/** The kind of losses. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "claim")
	@Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<KindOfLoss> kindOfLosses = new HashSet<KindOfLoss>(0);

	/** The original scenario claim. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_CLAIM_ID", insertable = false, updatable = false)
	private Claim originalScenarioClaim;
	
	
	
	/** The loss after on reform 2016. */
	@Column(name = "LOSS_AFTER_ON_REFORM_2016_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean lossAfterOnReform2016Indicator;
	
	/** The person hurt in accident. */
	@Column(name = "PERSON_HURT_IN_ACCIDENT_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean personHurtInAccidentIndicator;

	/** The insurer paid for damage. */
	@Column(name = "INSURER_PAID_FOR_DAMAGE_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean insurerPaidForDamageIndicator;
	
	/** The damage amount exceeded 2000. */
	@Column(name = "DAMAGE_AMT_EXCEEDED_2000_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean damageAmountExceeded2000Indicator;
	
	/** The claim category chargeable. */
	@Column(name = "CLAIM_CATEGORY_CHARGEABLE_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean claimCategoryChargeableIndicator;
	
	/** The claim category code. */
	@Column(name = "CLAIM_CATEGORY_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ClaimCategoryCodeEnum") })
	private ClaimCategoryCodeEnum claimCategoryCode;
	

	/**
	 * Instantiates a new claim.
	 */
	public Claim() {
		// noarg constructor
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the policy version.
	 * 
	 * @return the policy version
	 */
	@XmlTransient // parent
	public PolicyVersion getPolicyVersion() {
		return this.policyVersion;
	}

	/**
	 * Sets the policy version.
	 * 
	 * @param aPolicyVersion the new policy version
	 */
	public void setPolicyVersion(PolicyVersion aPolicyVersion) {
		AssociationsHelper.updateOneToManyFields(aPolicyVersion, "claims", this, "policyVersion");
	}

	/**
	 * Gets the party.
	 * 
	 * @return the party
	 */
	@XmlTransient // parent
	public Party getParty() {
		return this.party;
	}

	/**
	 * Sets the party.
	 * 
	 * @param aParty the new party
	 */
	public void setParty(Party aParty) {
		AssociationsHelper.updateOneToManyFields(aParty, "claims", this, "party");
	}

	/**
	 * Gets the insurance risk.
	 * 
	 * @return the insurance risk
	 */
	@XmlTransient // parent
	public InsuranceRisk getInsuranceRisk() {
		return this.insuranceRisk;
	}

	/**
	 * Sets the insurance risk.
	 * 
	 * @param aInsuranceRisk the new insurance risk
	 */
	public void setInsuranceRisk(InsuranceRisk aInsuranceRisk) {
		AssociationsHelper.updateOneToManyFields(aInsuranceRisk, "claims", this, "insuranceRisk");
	}

	/**
	 * Gets the claim type.
	 * 
	 * @return the claim type
	 */
	public ClaimTypeCodeEnum getClaimType() {
		return this.claimType;
	}

	/**
	 * Gets the nature of claim.
	 * 
	 * @return the nature of claim
	 */
	public NatureOfClaimCodeEnum getNatureOfClaim() {
		return this.natureOfClaim;
	}

	/**
	 * Gets the claim number.
	 * 
	 * @return the claim number
	 */
	public String getClaimNumber() {
		return this.claimNumber;
	}

	/**
	 * Sets the claim number.
	 * 
	 * @param aClaimNumber the new claim number
	 */
	public void setClaimNumber(String aClaimNumber) {
		this.claimNumber = aClaimNumber;
	}

	/**
	 * Gets the claim status.
	 * 
	 * @return the claim status
	 */
	public ClaimStatusCodeEnum getClaimStatus() {
		return this.claimStatus;
	}

	/**
	 * Gets the date of loss.
	 * 
	 * @return the date of loss
	 */
	public Date getDateOfLoss() {
		return this.dateOfLoss;
	}

	/**
	 * Sets the date of loss.
	 * 
	 * @param lossDate the new date of loss
	 */
	public void setDateOfLoss(Date lossDate) {
		this.dateOfLoss = lossDate;
	}

	/**
	 * Gets the claim at fault.
	 * 
	 * @return the claim at fault
	 */
	public Boolean getClaimAtFaultIndicator() {
		return this.claimAtFaultIndicator;
	}

	/**
	 * Sets the claim at fault.
	 * 
	 * @param aClaimAtFaultIndicator the new claim at fault
	 */
	public void setClaimAtFaultIndicator(Boolean aClaimAtFaultIndicator) {
		this.claimAtFaultIndicator = aClaimAtFaultIndicator;
	}

	/**
	 * Gets the claim considered code.
	 * 
	 * @return the claim considered code
	 */
	public ClaimConsideredCodeEnum getClaimConsideredCode() {
		return this.claimConsideredCode;
	}

	/**
	 * Sets the claim considered code.
	 * 
	 * @param aClaimConsideredCode1 the new claim considered code
	 */
	public void setClaimConsideredCode(ClaimConsideredCodeEnum aClaimConsideredCode1) {
		this.claimConsideredCode = aClaimConsideredCode1;
	}

	/**
	 * Gets the percentage of liability.
	 * 
	 * @return the percentage of liability
	 */
	public Short getPercentageOfLiability() {
		return this.percentageOfLiability;
	}

	/**
	 * Sets the percentage of liability.
	 * 
	 * @param liabilityPercentage the new percentage of liability
	 */
	public void setPercentageOfLiability(Short liabilityPercentage) {
		this.percentageOfLiability = liabilityPercentage;
	}

	/**
	 * Gets the cancelled vehicle class.
	 * 
	 * @return the cancelled vehicle class
	 */
	public String getCancelledVehicleClass() {
		return this.cancelledVehicleClass;
	}

	/**
	 * Sets the cancelled vehicle class.
	 * 
	 * @param cancelledVehicleClassCode the new cancelled vehicle class
	 */
	public void setCancelledVehicleClass(String cancelledVehicleClassCode) {
		this.cancelledVehicleClass = cancelledVehicleClassCode;
	}

	/**
	 * Gets the claim ordering sequence.
	 * 
	 * @return the claim ordering sequence
	 */
	public Short getClaimOrdering() {
		return this.claimOrdering;
	}

	/**
	 * Sets the claim ordering sequence.
	 * 
	 * @param claimOrderingSeq the new claim ordering sequence
	 */
	public void setClaimOrdering(Short claimOrderingSeq) {
		this.claimOrdering = claimOrderingSeq;
	}

	/**
	 * Gets the kind of losses.
	 * 
	 * @return the kind of losses
	 */
	@XmlElementWrapper(name="kindOfLosses")
	@XmlElement(name="kindOfLoss")
	public Set<KindOfLoss> getKindOfLosses() {
		return this.kindOfLosses;
	}

	/**
	 * Sets the kind of losses.
	 * 
	 * @param aKindOfLosses the new kind of losses
	 */
	protected void setKindOfLosses(Set<KindOfLoss> aKindOfLosses) {
		this.kindOfLosses = aKindOfLosses;
	}

	/**
	 * Adds the kind of loss.
	 * 
	 * @param kindOfLoss the kind of loss
	 */
	public void addKindOfLoss(com.ing.canada.plp.domain.insurancerisk.KindOfLoss kindOfLoss) {
		AssociationsHelper.updateOneToManyFields(this, "kindOfLosses", kindOfLoss, "claim");
	}

	/**
	 * Removes the kind of loss.
	 * 
	 * @param kindOfLoss the kind of loss
	 */
	public void removeKindOfLoss(com.ing.canada.plp.domain.insurancerisk.KindOfLoss kindOfLoss) {
		AssociationsHelper.updateOneToManyFields(null, "kindOfLosses", kindOfLoss, "claim");
	}

	/**
	 * Gets the claim loss date code.
	 * 
	 * @return the claimLossDateCode
	 */
	public ClaimLossDateCodeEnum getClaimLossDateCode() {
		return this.claimLossDateCode;
	}

	/**
	 * Sets the claim loss date code.
	 * 
	 * @param aClaimLossDateCode the claimLossDateCode to set
	 */
	public void setClaimLossDateCode(ClaimLossDateCodeEnum aClaimLossDateCode) {
		this.claimLossDateCode = aClaimLossDateCode;
	}

	/**
	 * Sets the claim status.
	 * 
	 * @param aClaimStatus the claimStatus to set
	 */
	public void setClaimStatus(ClaimStatusCodeEnum aClaimStatus) {
		this.claimStatus = aClaimStatus;
	}

	/**
	 * Sets the claim type.
	 * 
	 * @param aClaimType the claimType to set
	 */
	public void setClaimType(ClaimTypeCodeEnum aClaimType) {
		this.claimType = aClaimType;
	}

	/**
	 * Sets the nature of claim.
	 * 
	 * @param aNatureOfClaim the natureOfClaim to set
	 */
	public void setNatureOfClaim(NatureOfClaimCodeEnum aNatureOfClaim) {
		this.natureOfClaim = aNatureOfClaim;
	}

	/**
	 * Gets the original scenario claim.
	 * 
	 * @return the original scenario claim
	 */
	public Claim getOriginalScenarioClaim() {
		return this.originalScenarioClaim;
	}

	/**
	 * Sets the original scenario claim.
	 * 
	 * @param anOriginalScenarioClaim the new original scenario claim
	 */
	public void setOriginalScenarioClaim(Claim anOriginalScenarioClaim) {
		this.originalScenarioClaim = anOriginalScenarioClaim;
	}

	/**
	 * Helper method to get the total paid amount
	 */
	public BigDecimal getPaidAmount() {
		BigDecimal total = BigDecimal.ZERO;
		for (KindOfLoss aKindOfLoss : this.kindOfLosses) {
			total = total.add(aKindOfLoss.getAmountPaid() != null ? aKindOfLoss.getAmountPaid() : BigDecimal.ZERO);
		}
		return total;
	}

	public Boolean getLossAfterOnReform2016Indicator() {
		return lossAfterOnReform2016Indicator;
	}

	public void setLossAfterOnReform2016Indicator(Boolean lossAfterOnReform2016Indicator) {
		this.lossAfterOnReform2016Indicator = lossAfterOnReform2016Indicator;
	}

	public Boolean getPersonHurtInAccidentIndicator() {
		return personHurtInAccidentIndicator;
	}

	public void setPersonHurtInAccidentIndicator(Boolean personHurtInAccidentIndicator) {
		this.personHurtInAccidentIndicator = personHurtInAccidentIndicator;
	}

	public Boolean getInsurerPaidForDamageIndicator() {
		return insurerPaidForDamageIndicator;
	}

	public void setInsurerPaidForDamageIndicator(Boolean insurerPaidForDamageIndicator) {
		this.insurerPaidForDamageIndicator = insurerPaidForDamageIndicator;
	}

	public Boolean getDamageAmountExceeded2000Indicator() {
		return damageAmountExceeded2000Indicator;
	}

	public void setDamageAmountExceeded2000Indicator(Boolean damageAmountExceeded2000Indicator) {
		this.damageAmountExceeded2000Indicator = damageAmountExceeded2000Indicator;
	}

	public Boolean getClaimCategoryChargeableIndicator() {
		return claimCategoryChargeableIndicator;
	}

	public void setClaimCategoryChargeableIndicator(Boolean claimCategoryChargeableIndicator) {
		this.claimCategoryChargeableIndicator = claimCategoryChargeableIndicator;
	}

	public ClaimCategoryCodeEnum getClaimCategoryCode() {
		return claimCategoryCode;
	}

	public void setClaimCategoryCode(ClaimCategoryCodeEnum claimCategoryCode) {
		this.claimCategoryCode = claimCategoryCode;
	}
}
