/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.party;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.driver.AffinityGroupRepositoryEntry;
import com.ing.canada.plp.domain.enums.MemberTypeCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * PartyGroup entity.
 * 
 * @author Patrick Lafleur
 * 
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "PARTY_GROUP", uniqueConstraints = { @UniqueConstraint(columnNames = { "PARTY_ID",
		"GROUP_REPOSITORY_ENTRY_ID" }) })
public class PartyGroup extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "PARTY_GROUP_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "PartyGroupSequence")
	@SequenceGenerator(name = "PartyGroupSequence", sequenceName = "PARTY_GROUP_SEQ", allocationSize = 5)
	private Long id;

	/** The group repository entry. */
	@ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE}, fetch = FetchType.EAGER)
	@JoinColumn(name = "GROUP_REPOSITORY_ENTRY_ID", nullable = false, updatable = true)
	private GroupRepositoryEntry groupRepositoryEntry;

	/** The party. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "PARTY_ID", nullable = false, updatable = true)
	private Party party;

	/** The member type. */
	@Column(name = "MEMBER_TYPE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.MemberTypeCodeEnum") })
	private MemberTypeCodeEnum memberType;

	/** The member number. */
	@Column(name = "MEMBER_NBR", length = 20)
	private String memberNumber;

	/** The internal billing indicator. */
	@Column(name = "INTERNAL_BILLING_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean internalBillingIndicator;

	/** Division nbr */
	@Column(name = "DIVISION_NBR", length = 10)
	private String divisionNumber;

	/** The original scenario party group. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_PARTY_GROUP_ID", insertable = false, updatable = false)
	private PartyGroup originalScenarioPartyGroup;

	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "AFF_GR_REP_ENTRY_ID")
	private AffinityGroupRepositoryEntry affinityGroupRepositoryEntry;

	/**
	 * Instantiates a new party group.
	 */
	public PartyGroup() {
		// noarg constructor
	}

	/**
	 * Instantiates a new party group.
	 * 
	 * @param aGroupRepositoryEntry the a group repository entry
	 * @param aParty the a party
	 */
	public PartyGroup(GroupRepositoryEntry aGroupRepositoryEntry, Party aParty) {
		setGroupRepositoryEntry(aGroupRepositoryEntry);
		setParty(aParty);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the group repository entry.
	 * 
	 * @return the group repository entry
	 */
	public GroupRepositoryEntry getGroupRepositoryEntry() {
		return this.groupRepositoryEntry;
	}

	/**
	 * Sets the group repository entry.
	 * 
	 * @param aGroupRepositoryEntry the new group repository entry
	 */
	public void setGroupRepositoryEntry(GroupRepositoryEntry aGroupRepositoryEntry) {
		this.groupRepositoryEntry = aGroupRepositoryEntry;
	}

	/**
	 * Gets the party.
	 * 
	 * @return the party
	 */
	@XmlTransient // parent
	public Party getParty() {
		return this.party;
	}

	/**
	 * Sets the party.
	 * 
	 * @param aParty the new party
	 */
	public void setParty(Party aParty) {
		AssociationsHelper.updateOneToManyFields(aParty, "partyGroups", this, "party");
	}

	/**
	 * Gets the member type.
	 * 
	 * @return the member type
	 */
	public MemberTypeCodeEnum getMemberType() {
		return this.memberType;
	}

	/**
	 * Sets the member type.
	 * 
	 * @param memberTypeCode the new member type
	 */
	public void setMemberType(MemberTypeCodeEnum memberTypeCode) {
		this.memberType = memberTypeCode;
	}

	/**
	 * Gets the member number.
	 * 
	 * @return the member number
	 */
	public String getMemberNumber() {
		return this.memberNumber;
	}

	/**
	 * Sets the member number.
	 * 
	 * @param aMemberNumber the new member number
	 */
	public void setMemberNumber(String aMemberNumber) {
		this.memberNumber = aMemberNumber;
	}

	/**
	 * Gets the internal billing indicator.
	 * 
	 * @return the internal billing indicator
	 */
	public Boolean getInternalBillingIndicator() {
		return this.internalBillingIndicator;
	}

	/**
	 * Sets the internal billing indicator.
	 * 
	 * @param aInternalBillingIndicator the new internal billing indicator
	 */
	public void setInternalBillingIndicator(Boolean aInternalBillingIndicator) {
		this.internalBillingIndicator = aInternalBillingIndicator;
	}

	/**
	 * Gets the original scenario party group.
	 * 
	 * @return the original scenario party group
	 */
	public PartyGroup getOriginalScenarioPartyGroup() {
		return this.originalScenarioPartyGroup;
	}

	/**
	 * Sets the original scenario party group.
	 * 
	 * @param anOriginalScenarioPartyGroup the new original scenario party group
	 */
	@XmlTransient // reference source
	protected void setOriginalScenarioPartyGroup(PartyGroup anOriginalScenarioPartyGroup) {
		this.originalScenarioPartyGroup = anOriginalScenarioPartyGroup;
	}

	/**
	 * @return the divisionNumber
	 */
	public String getDivisionNumber() {
		return this.divisionNumber;
	}

	/**
	 * @param aDivisionNumber the divisionNumber to set
	 */
	public void setDivisionNumber(String aDivisionNumber) {
		this.divisionNumber = aDivisionNumber;
	}

	/**
	 * @return {@link #affinityGroupRepositoryEntry}
	 */
	public AffinityGroupRepositoryEntry getAffinityGroupRepositoryEntry() {
		return this.affinityGroupRepositoryEntry;
	}

	/**
	 * @param aAffinityGroupRepositoryEntry {@link #affinityGroupRepositoryEntry}
	 */
	public void setAffinityGroupRepositoryEntry(AffinityGroupRepositoryEntry aAffinityGroupRepositoryEntry) {
		this.affinityGroupRepositoryEntry = aAffinityGroupRepositoryEntry;
	}

}
