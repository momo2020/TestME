/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum RenewalActionCodeEnum.
 */
public enum RenewalActionCodeEnum {
	
	/** The Triggered for all lines constant. */
	TRIGGERED_FOR_ALL_LINES("T"),
	
	/** The Triggered for fleets and garages constant. */
	TRIGGERED_FOR_FLEETS_AND_GARAGES("F"),
	
	/** The Triggered for personal lines constant. */
	TRIGGERED_FOR_PERSONAL_LINES("L");

	/**
	 * The Constant log.
	 * 
	 * @param aCode the a code
	 */

	/**
	 * Instantiates a new additional interest type code enum.
	 * 
	 * @param aCode the code
	 */
	private RenewalActionCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the additional interest type code enum
	 */
	public static RenewalActionCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (RenewalActionCodeEnum v : values()) {
			if (v.code.equals(value)) {			
				return v;
			}

		}

		throw new IllegalArgumentException("no value found for code: " + value);

	}

}
