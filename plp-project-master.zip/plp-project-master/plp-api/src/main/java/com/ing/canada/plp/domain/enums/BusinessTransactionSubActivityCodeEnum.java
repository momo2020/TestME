/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import java.util.EnumSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

/**
 * @author plafleur
 * 
 */
public enum BusinessTransactionSubActivityCodeEnum {

	ADD_VEHICLE("ADD_VEH"),
	ADD_DRIVER("ADD_DRIVER"),
	MODIFY_DRIVER("MOD_DRIVER"),
	MODIFY_VEHICLE("MOD_VEH"),
	REPLACE_VEHICLE("SUBSTITUTE_VEH"),
	DELETE_VEHICLE("DEL_VEH"),
	DELETE_DRIVER("DEL_DRIVER"),
	MODIFY_ADDRESS("MOD_ADDRESS"),
	ROADBLOCK("ROAD_BLOCK"),
	CLICK_TO_CHAT("CLICK_TO_CHAT"),
	RECALCULATE("RECAL_PREMIUM"),
	UPDATE_SAVINGS("UPD_SAVING"),
	ADDRESS_CHANGED("CHANGED_ADDRESS"),
	MODIFY_USAGE("MOD_VEH_USAGE"),
	GET_OFFER("GOF"),
	PURCHASE_REQUESTED("PRQ"),
	EMAIL_NOTIF("EMAIL_NOTIF"),
	MODIFY_COVERAGE("MOD_COV"),
	RESET("RST"),
	GET_BIND_VALID("GET_BIND_VALID"), 
	GET_BIND_INFO("GET_BIND_INFO"), 
	GET_BIND_COV("GET_BIND_COV"), 
	GET_BIND_VEH_DRVR("GET_BIND_VEH_DRVR"), 
	GET_BIND_PROFILE("GET_BIND_PROFIL"), 
	GET_PURCHASE("GET_PURCHASE"), 
	RETRIEVE_QUOTE("RETRIEVE_QUOTE"),
	DIAGNOSTIC_AUTOMATED_ADVICE_APPLIED("DGN_AUTO_ADV_APPL"),
	CHG_LANG_SCR("CHG_LANG_SCR");
	    
    /** The Set of sub-activities NOT considered as policy change modifications */
    private static final Set <BusinessTransactionSubActivityCodeEnum> noPolicyChangeSubAct = 
        EnumSet.of(BusinessTransactionSubActivityCodeEnum.CLICK_TO_CHAT,
            BusinessTransactionSubActivityCodeEnum.GET_OFFER,
            BusinessTransactionSubActivityCodeEnum.EMAIL_NOTIF,
            BusinessTransactionSubActivityCodeEnum.RESET,
            BusinessTransactionSubActivityCodeEnum.ROADBLOCK);
   
    /**
     * Checks if <tt>subActivityCodeEnum</tt> is a policy change modification.
     * 
     * @param subActivityCodeEnum the sub activity code enum
     * 
     * @return true, if <tt>subActivityCodeEnum</tt> is, by convention, a policy change modification
     */
    public static boolean isPolicyChangeModification(BusinessTransactionSubActivityCodeEnum subActivityCodeEnum) {
        return !noPolicyChangeSubAct.contains(subActivityCodeEnum);
    }
    
	/**
	 * Instantiates a new business transaction sub activity code enum.
	 * 
	 * @param aCode the a code
	 */
	private BusinessTransactionSubActivityCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the business transaction sub activity code enum
	 */
	public static BusinessTransactionSubActivityCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (BusinessTransactionSubActivityCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}
		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}

}
