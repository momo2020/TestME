/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum ReasonAbsenceThirdPartyLiabilityCoverageCodeEnum.
 */
public enum ReasonAbsenceThirdPartyLiabilityCoverageCodeEnum {

	REFERS_TO_A_GARAGE_POLICY("G"), REFERS_TO_A_GENERAL_LIABILITY_POLICY("L"), PERMANENT_STORAGE("P"), TEMPORARY_STORAGE(
			"T"), WINTER_STORAGE("W"), MAXI_SNOW_PROGRAM("M"), OTHER_REASON("O");

	/**
	 * Instantiates a new reason absence third party liability coverage code enum.
	 * 
	 * @param aCode the a code
	 */
	private ReasonAbsenceThirdPartyLiabilityCoverageCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the reason absence third party liability coverage code enum
	 */
	public static ReasonAbsenceThirdPartyLiabilityCoverageCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (ReasonAbsenceThirdPartyLiabilityCoverageCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
