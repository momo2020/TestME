package com.ing.canada.plp.domain.subbrokerassignment;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.enums.AssignmentOriginatorTypeCodeEnum;
import com.ing.canada.plp.domain.enums.AssignmentReasonCodeEnum;
import com.ing.canada.plp.domain.insurancepolicy.InsurancePolicy;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * SubBrokerAssignment entity
 * 
 * @author selleing / Stephane Elleingand
 *
 */
@Entity
@Table(name = "SUB_BROKER_ASSIGNMENT", uniqueConstraints = {})
@NamedQueries({
		@NamedQuery(name = "SubBrokerAssignment.findSubBrokerAssignments", query = "select sa from SubBrokerAssignment sa where sa.effectiveDate between :dateFrom and :dateTo  order by sa.effectiveDate desc"),
		@NamedQuery(name = "SubBrokerAssignment.getAllSubBrokerAssignments", query = "select sa from SubBrokerAssignment sa order by sa.effectiveDate desc"),
		@NamedQuery(name = "SubBrokerAssignment.getLastSubBrokerAssignmentForPolicy", query = "select sba2 from SubBrokerAssignment sba2 where sba2.id = (select max(sba.id) from PolicyVersion pv inner join pv.insurancePolicy ip inner join ip.subBrokerAssignments sba where pv.id = :policyVersionId)") })

// USED 4 PERFORMANCE ONLY.
// SHOULD NOT NORMALLY BE USED
// DO NOT TRY TO REFACTOR FOR PURISM MATTERS
@NamedNativeQueries({ 
	@NamedNativeQuery(name = "SubBrokerAssignment.reassignPolicies", query = "INSERT INTO PLPADMIN.SUB_BROKER_ASSIGNMENT (SUB_BROKER_ASSIGNMENT_ID,ASSIGNMENT_ORIGINATOR_TYPE_CD,ASSIGNMENT_REASON_CD,EFFECTIVE_DT,EXPIRY_DT,INSURANCE_POLICY_ID,SYSTEM_CREATE_TS,PREV_SUB_BROKER_ASSIGNMENT_ID,CIF_SUB_BROKER_ID,ASSIGNOR_USER_ID) SELECT PLPADMIN.SUB_BROKER_ASSIGNMENT_SEQ.NEXTVAL, 'BRK', 'BRK_REORG', CURRENT_DATE, NULL, IP.INSURANCE_POLICY_ID, CURRENT_DATE, SBA.SUB_BROKER_ASSIGNMENT_ID, ?, UPPER(?) FROM PLPADMIN.INSURANCE_POLICY IP, PLPADMIN.SUB_BROKER_ASSIGNMENT SBA WHERE IP.AGREEMENT_NBR = ? AND SBA.INSURANCE_POLICY_ID = IP.INSURANCE_POLICY_ID AND SBA.SYSTEM_CREATE_TS IN (SELECT MAX(SBA2.SYSTEM_CREATE_TS) FROM PLPADMIN.SUB_BROKER_ASSIGNMENT SBA2 WHERE SBA2.INSURANCE_POLICY_ID = IP.INSURANCE_POLICY_ID)"), 
	@NamedNativeQuery(name = "SubBrokerAssignment.closePolicyAssignations", query = "UPDATE PLPADMIN.SUB_BROKER_ASSIGNMENT SBA SET SBA.EXPIRY_DT = CURRENT_DATE WHERE SBA.EXPIRY_DT IS NULL AND EXISTS (SELECT 1 FROM PLPADMIN.INSURANCE_POLICY IP WHERE IP.AGREEMENT_NBR = ? AND SBA.INSURANCE_POLICY_ID = IP.INSURANCE_POLICY_ID)")
})
public class SubBrokerAssignment extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "SUB_BROKER_ASSIGNMENT_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "SubBrokerAssignmentSequence")
	@SequenceGenerator(name = "SubBrokerAssignmentSequence", sequenceName = "SUB_BROKER_ASSIGNMENT_SEQ", allocationSize = 5)
	private Long id;

	// The assignment reason code.
	@Column(name = "ASSIGNMENT_ORIGINATOR_TYPE_CD", nullable = false, length = 10)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.AssignmentOriginatorTypeCodeEnum") })
	private AssignmentOriginatorTypeCodeEnum assignmentOriginatorType;

	// The assignment reason code.
	@Column(name = "ASSIGNMENT_REASON_CD", nullable = false, length = 12)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.AssignmentReasonCodeEnum") })
	private AssignmentReasonCodeEnum assignmentReason;

	// The effective date.
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", nullable = false, length = 7)
	private Date effectiveDate;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;

	/** The insurance policy . */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_POLICY_ID", nullable = false, updatable = true)
	private InsurancePolicy insurancePolicy;

	/** The previous sub broker assignment . */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "PREV_SUB_BROKER_ASSIGNMENT_ID", nullable = true, updatable = true)
	private SubBrokerAssignment previousSubBrokerAssignment;

	@Column(name = "CIF_SUB_BROKER_ID", precision = 12, scale = 0)
	private Long cifSubBrokerId;

	@Column(name = "ASSIGNOR_USER_ID", length = 65)
	private String assignorUserId;

	/**
	 * Gets the assignment originator type code.
	 * 
	 * @return the assignment originator type code
	 */
	public AssignmentOriginatorTypeCodeEnum getAssignmentOriginatorType() {
		return this.assignmentOriginatorType;
	}

	/**
	 * Sets the assignment originator type code.
	 * 
	 * @param anAssignmentOriginatorType the new assignment originator type code
	 */
	public void setAssignmentOriginatorType(AssignmentOriginatorTypeCodeEnum anAssignmentOriginatorType) {
		this.assignmentOriginatorType = anAssignmentOriginatorType;
	}

	/**
	 * Gets the assignment reason code.
	 * 
	 * @return the assignment reason code
	 */

	public AssignmentReasonCodeEnum getAssignmentReason() {
		return this.assignmentReason;
	}

	/**
	 * Sets the assignment reason code.
	 * 
	 * @param anAssignmentReason the new assignment reason code
	 */
	public void setAssignmentReason(AssignmentReasonCodeEnum anAssignmentReason) {
		this.assignmentReason = anAssignmentReason;
	}

	/**
	 * Gets the effective date.
	 * 
	 * @return the effective date
	 */

	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * set the effective date.
	 * 
	 * @param anEffectiveDate the new effective date
	 */
	public void setEffectiveDate(Date anEffectiveDate) {
		this.effectiveDate = anEffectiveDate;
	}

	/**
	 * Gets the expiry date.
	 * 
	 * @return the expirye date
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * set the expiry date.
	 * 
	 * @param anEffectiveDate the new expiry date
	 */
	public void setExpiryDate(Date anExpiryDate) {
		this.expiryDate = anExpiryDate;
	}

	/**
	 * Gets the insurance policy.
	 * 
	 * @return the insurance policy
	 */
	@XmlTransient
	public InsurancePolicy getInsurancePolicy() {
		return this.insurancePolicy;
	}

	/**
	 * set the insurance policy.
	 * 
	 * @param anInsurancePolicy the new insurance policy
	 */
	public void setInsurancePolicy(InsurancePolicy anInsurancePolicy) {
		this.insurancePolicy = anInsurancePolicy;
	}

	public SubBrokerAssignment getPreviousSubBrokerAssignment() {
		return this.previousSubBrokerAssignment;
	}

	public void setPreviousSubBrokerAssignment(SubBrokerAssignment aPreviousSubBrokerAssignment) {
		this.previousSubBrokerAssignment = aPreviousSubBrokerAssignment;
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * @return the cifSubBrokerId
	 */
	public Long getCifSubBrokerId() {
		return this.cifSubBrokerId;
	}

	/**
	 * @param aCifSubBrokerId the cifSubBrokerId to set
	 */
	public void setCifSubBrokerId(Long aCifSubBrokerId) {
		this.cifSubBrokerId = aCifSubBrokerId;
	}

	/**
	 * Gets the assignor user id
	 * 
	 * @return the assignor user id
	 */
	public String getAssignorUserId() {
		return this.assignorUserId;
	}

	/**
	 * Sets the assignor user id
	 * 
	 * @param anAssignorUserId the assignor user id to set
	 * 
	 */
	public void setAssignorUserId(String aAssignorUserId) {
		this.assignorUserId = aAssignorUserId;
	}

}
