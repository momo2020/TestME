/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.policyversion;

import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.NumberTimesCanceledRefusedNonPaymentEnum;
import com.ing.canada.plp.domain.enums.ReasonDeclinedOrCancelledCodeEnum;
import com.ing.canada.plp.domain.party.Party;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * PriorCarrierPolicyInfo entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "PRIOR_CARRIER_POLICY_INFO", uniqueConstraints = {})
public class PriorCarrierPolicyInfo extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "PRIOR_CARRIER_POLICY_INFO_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "priorCarriorPolicyInfoSequence")
	@SequenceGenerator(name = "priorCarriorPolicyInfoSequence", sequenceName = "PRIOR_CARRIER_POLICY_INFO_SEQ", allocationSize = 5)
	private Long id;

	/** The policy versions. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "priorCarrierPolicyInfo")
	private Set<PolicyVersion> policyVersions = new HashSet<PolicyVersion>(0);

	/** The prior carrier policy number. */
	@Column(name = "PRIOR_CARRIER_POLICY_NBR", length = 25)
	private String priorCarrierPolicyNumber;

	/** The carrier code. */
	@Column(name = "CARRIER_CD", length = 6)
	private String carrierCode;

	/** The prior carrier name. */
	@Column(name = "PRIOR_CARRIER_NAME_TXT", length = 20)
	private String priorCarrierName;

	/** The prior policy expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "PRIOR_POLICY_EXPIRY_DT", length = 7)
	private Date priorPolicyExpiryDate;

	/** The number of years continuously insured with prior carrier. */
	@Column(name = "NBR_YRS_CONT_INSRD_PR_CARR_QTY", precision = 2, scale = 0)
	private Byte numberOfYearsContinuouslyInsuredWithPriorCarrier;

	/** The prior carrier declined or cancelled name. */
	@Column(name = "PRIOR_CARR_DCLN_CNCL_NAME_TXT", length = 60)
	private String priorCarrierDeclinedOrCancelledName;

	/** The prior carrier declined or cancelled date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "PRIOR_CARR_DCLN_CNCL_DT", length = 7)
	private Date priorCarrierDeclinedOrCancelledDate;

	@Type(type = "yes_no")
	@Column(name = "REASON_DECLINED_OR_CNCL_IND", length = 1)
	private Boolean reasonDeclinedOrCancelledIndicator = null;

	/** The reason declined or cancelled. */
	@Column(name = "REASON_DECLINED_OR_CNCL_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ReasonDeclinedOrCancelledCodeEnum") })
	private ReasonDeclinedOrCancelledCodeEnum reasonDeclinedOrCancelled;

	/** The number of times the policy was canceled for no-payment */
	@Column(name = "NBR_OF_NON_PAYMENT_CNCLTN_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.NumberTimesCanceledRefusedNonPaymentEnum") })
	private NumberTimesCanceledRefusedNonPaymentEnum numberCanceledForNonPayment;

	/** The original scenario prior carrier policy info. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_PRIOR_CARR_POL_INF_ID", insertable = false, updatable = false)
	private PriorCarrierPolicyInfo originalScenarioPriorCarrierPolicyInfo;

	/** The policy versions. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "priorCarrierPolicyInfo")
	private Set<Party> parties = new HashSet<Party>(0);

	/**
	 * Instantiates a new prior carrier policy info.
	 */
	public PriorCarrierPolicyInfo() {
		// noarg constructor
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param policyVersionId the policy version id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object policyVersionId) {
		this.id = (Long) policyVersionId;
	}

	/**
	 * Gets the policy versions.
	 * 
	 * @return the policy versions
	 */
	@XmlTransient // don't display in XML, not a top-level element
	public Set<PolicyVersion> getPolicyVersions() {
		return Collections.unmodifiableSet(this.policyVersions);
	}

	/**
	 * Sets the policy versions.
	 * 
	 * @param aPolicyVersion the new policy versions
	 */
	protected void setPolicyVersions(Set<PolicyVersion> aPolicyVersions) {
		this.policyVersions = aPolicyVersions;
	}

	/**
	 * Adds the policy version.
	 * 
	 * @param policyVersion the policy version
	 */
	public void addPolicyVersion(PolicyVersion policyVersion) {
		AssociationsHelper.updateOneToManyFields(this, "policyVersions", policyVersion, "priorCarrierPolicyInfo");
	}

	/**
	 * Removes the policy version.
	 * 
	 * @param policyVersion the policy version
	 */
	public void removePolicyVersion(PolicyVersion policyVersion) {
		AssociationsHelper.updateOneToManyFields(null, "policyVersions", policyVersion, "priorCarrierPolicyInfo");
	}

	/**
	 * Gets the prior carrier policy number.
	 * 
	 * @return the prior carrier policy number
	 */
	public String getPriorCarrierPolicyNumber() {
		return this.priorCarrierPolicyNumber;
	}

	/**
	 * Sets the prior carrier policy number.
	 * 
	 * @param aPriorCarrierPolicyNumber the new prior carrier policy number
	 */
	public void setPriorCarrierPolicyNumber(String aPriorCarrierPolicyNumber) {
		this.priorCarrierPolicyNumber = aPriorCarrierPolicyNumber;
	}

	/**
	 * Gets the carrier code.
	 * 
	 * @return the carrier code
	 */
	public String getCarrierCode() {
		return this.carrierCode;
	}

	/**
	 * Sets the carrier code.
	 * 
	 * @param aCarrierCode the new carrier code
	 */
	public void setCarrierCode(String aCarrierCode) {
		this.carrierCode = aCarrierCode;
	}

	/**
	 * Gets the prior carrier name.
	 * 
	 * @return the prior carrier name
	 */
	public String getPriorCarrierName() {
		return this.priorCarrierName;
	}

	/**
	 * Sets the prior carrier name.
	 * 
	 * @param aPriorCarrierName the new prior carrier name
	 */
	public void setPriorCarrierName(String aPriorCarrierName) {
		this.priorCarrierName = aPriorCarrierName;
	}

	/**
	 * Gets the prior policy expiry date.
	 * 
	 * @return the prior policy expiry date
	 */
	public Date getPriorPolicyExpiryDate() {
		return this.priorPolicyExpiryDate;
	}

	/**
	 * Sets the prior policy expiry date.
	 * 
	 * @param aPriorPolicyExpiryDate the new prior policy expiry date
	 */
	public void setPriorPolicyExpiryDate(Date aPriorPolicyExpiryDate) {
		this.priorPolicyExpiryDate = aPriorPolicyExpiryDate;
	}

	/**
	 * Gets the number of years continuously insured with prior carrier.
	 * 
	 * @return the number of years continuously insured with prior carrier
	 */
	public Byte getNumberOfYearsContinuouslyInsuredWithPriorCarrier() {
		return this.numberOfYearsContinuouslyInsuredWithPriorCarrier;
	}

	/**
	 * Sets the number of years continuously insured with prior carrier.
	 * 
	 * @param nbrYrsContInsrdPrCarr the new number of years continuously insured with prior carrier
	 */
	public void setNumberOfYearsContinuouslyInsuredWithPriorCarrier(Byte nbrYrsContInsrdPrCarr) {
		this.numberOfYearsContinuouslyInsuredWithPriorCarrier = nbrYrsContInsrdPrCarr;
	}

	/**
	 * Gets the prior carrier declined or cancelled name.
	 * 
	 * @return the prior carrier declined or cancelled name
	 */
	public String getPriorCarrierDeclinedOrCancelledName() {
		return this.priorCarrierDeclinedOrCancelledName;
	}

	/**
	 * Sets the prior carrier declined or cancelled name.
	 * 
	 * @param priorCarrDclnCnclName the new prior carrier declined or cancelled name
	 */
	public void setPriorCarrierDeclinedOrCancelledName(String priorCarrDclnCnclName) {
		this.priorCarrierDeclinedOrCancelledName = priorCarrDclnCnclName;
	}

	/**
	 * Gets the prior carrier declined or cancelled date.
	 * 
	 * @return the prior carrier declined or cancelled date
	 */
	public Date getPriorCarrierDeclinedOrCancelledDate() {
		return this.priorCarrierDeclinedOrCancelledDate;
	}

	/**
	 * Sets the prior carrier declined or cancelled date.
	 * 
	 * @param priorCarrDclnCnclDate the new prior carrier declined or cancelled date
	 */
	public void setPriorCarrierDeclinedOrCancelledDate(Date priorCarrDclnCnclDate) {
		this.priorCarrierDeclinedOrCancelledDate = priorCarrDclnCnclDate;
	}

	/**
	 * Gets the number of time the policy was canceled for non-payment
	 * 
	 * @return the number of time the policy was canceled for non-payment
	 */
	public NumberTimesCanceledRefusedNonPaymentEnum getNumberCanceledForNonPayment() {
		return this.numberCanceledForNonPayment;
	}

	/**
	 * Sets the number of time the policy was canceled for non-payment.
	 * 
	 * @param aNumberCanceledForNonPayment the number of time the policy was canceled for non-payment
	 */
	public void setNumberCanceledForNonPayment(NumberTimesCanceledRefusedNonPaymentEnum aNumberCanceledForNonPayment) {
		this.numberCanceledForNonPayment = aNumberCanceledForNonPayment;
	}

	/**
	 * Gets the reason declined or cancelled.
	 * 
	 * @return the reason declined or cancelled
	 */
	public ReasonDeclinedOrCancelledCodeEnum getReasonDeclinedOrCancelled() {
		return this.reasonDeclinedOrCancelled;
	}

	/**
	 * Sets the reason declined or cancelled.
	 * 
	 * @param reasonDeclinedOrCnclCode the new reason declined or cancelled
	 */
	public void setReasonDeclinedOrCancelled(ReasonDeclinedOrCancelledCodeEnum reasonDeclinedOrCnclCode) {
		this.reasonDeclinedOrCancelled = reasonDeclinedOrCnclCode;
	}

	/**
	 * @return the reasonDeclinedOrCancelledIndicator
	 */
	public Boolean getReasonDeclinedOrCancelledIndicator() {
		return this.reasonDeclinedOrCancelledIndicator;
	}

	/**
	 * @param aReasonDeclinedOrCancelledIndicator the reasonDeclinedOrCancelledIndicator to set
	 */
	public void setReasonDeclinedOrCancelledIndicator(Boolean aReasonDeclinedOrCancelledIndicator) {
		this.reasonDeclinedOrCancelledIndicator = aReasonDeclinedOrCancelledIndicator;
	}

	/**
	 * Gets the original scenario prior carrier policy info.
	 * 
	 * @return the original scenario prior carrier policy info
	 */
	@XmlTransient // reference source
	public PriorCarrierPolicyInfo getOriginalScenarioPriorCarrierPolicyInfo() {
		return this.originalScenarioPriorCarrierPolicyInfo;
	}

	/**
	 * Sets the original scenario prior carrier policy info.
	 * 
	 * @param anOriginalScenarioPriorCarrierPolicyInfo the new original scenario prior carrier policy info
	 */
	protected void setOriginalScenarioPriorCarrierPolicyInfo(
			PriorCarrierPolicyInfo anOriginalScenarioPriorCarrierPolicyInfo) {
		this.originalScenarioPriorCarrierPolicyInfo = anOriginalScenarioPriorCarrierPolicyInfo;
	}

	/**
	 * Gets the parties.
	 * 
	 * @return the parties
	 */
	@XmlTransient // don't display in XML, not a top-level element
	public Set<Party> getParties() {
		return Collections.unmodifiableSet(this.parties);
	}

	/**
	 * Sets the parties.
	 * 
	 * @param aParties the new parties
	 */
	protected void setParties(Set<Party> aParties) {
		this.parties = aParties;
	}

	/**
	 * Adds the party.
	 * 
	 * @param party the party
	 */
	public void addParty(Party party) {
		AssociationsHelper.updateOneToManyFields(this, "parties", party, "priorCarrierPolicyInfo");
	}

	/**
	 * Removes the party.
	 * 
	 * @param party the party
	 */
	public void removeParty(Party party) {
		AssociationsHelper.updateOneToManyFields(null, "parties", party, "priorCarrierPolicyInfo");
	}
}
