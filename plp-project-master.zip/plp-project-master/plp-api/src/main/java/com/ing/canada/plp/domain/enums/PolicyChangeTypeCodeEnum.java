/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum PolicyChangeTypeCodeEnum.
 */
public enum PolicyChangeTypeCodeEnum {

	BROKER_SALE("B"), NON_CHARGEABLE_CLAIM("E"), POLICY_CHANGE("N"), POLICY_CHANGE_REWRITE("O"), P("P"), COMPU_QUOTE(
			"Q"), CHARGEABLE_CLAIM("R"), QUOTE_RENEWAL("S"), ULTIMA("U"), REINSTATEMENT("V"), EXTENSION_CANCELLATION("C"),
			APPLY_UBI_USAGE_VALUE("D");

	/**
	 * Instantiates a new policy change type code enum.
	 * 
	 * @param aCode the a code
	 */
	private PolicyChangeTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the policy change type code enum
	 */
	public static PolicyChangeTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (PolicyChangeTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
