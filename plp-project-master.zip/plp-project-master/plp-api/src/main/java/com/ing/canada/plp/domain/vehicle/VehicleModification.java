/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.vehicle;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.VehicleModificationTypeCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * VehicleEquipment entity.
 *
 * @author Francois Demers
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "VEHICLE_MODIFICATION", uniqueConstraints = {})
public class VehicleModification extends BaseEntity {

	private static final long serialVersionUID = 957929824753301893L;

	/** The id. */
	@Id
	@Column(name = "VEHICLE_MODIFICATION_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "VehicleModificationSequence")
	@SequenceGenerator(name = "VehicleModificationSequence", sequenceName = "VEHICLE_MODIFICATION_SEQ", allocationSize = 5)
	private Long id;

	/** The vehicle. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_RISK_ID", nullable = false, updatable = true)
	private Vehicle vehicle;

	/** The modification type. */
	@Column(name = "MODIFICATION_TYPE_CD", nullable = false, length = 7)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.VehicleModificationTypeCodeEnum") })
	private VehicleModificationTypeCodeEnum modificationType;

	/**
	 * Instantiates a new vehicle modification.
	 */
	public VehicleModification() {
		// noarg constructor
	}

	/**
	 * Instantiates a new vehicle modification.
	 *
	 * @param aVehicle the a vehicle
	 * @param aVehicleModificationTypeCode the modification type code
	 */
	public VehicleModification(Vehicle aVehicle, VehicleModificationTypeCodeEnum aVehicleModificationTypeCode) {
		setVehicle(aVehicle);
		setVehicleModificationType(aVehicleModificationTypeCode);
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 *
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param aId the a id
	 *
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the vehicle.
	 *
	 * @return the vehicle
	 */
	@XmlTransient // parent
	public Vehicle getVehicle() {
		return this.vehicle;
	}

	/**
	 * Sets the vehicle.
	 *
	 * @param aVehicle the new vehicle
	 */
	public void setVehicle(Vehicle aVehicle) {
		AssociationsHelper.updateOneToManyFields(aVehicle, "vehicleModifications", this, "vehicle");
	}

	/**
	 * Gets the modification type.
	 *
	 * @return the modification type
	 */
	public VehicleModificationTypeCodeEnum getModificationType() {
		return this.modificationType;
	}

	/**
	 * Sets the modification type.
	 *
	 * @param vehicleModificationTypeCode the new modification type
	 */
	public void setVehicleModificationType(VehicleModificationTypeCodeEnum modificationTypeCode) {
		this.modificationType = modificationTypeCode;
	}

}
