/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insuranceriskoffer;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.coverage.BaseCoverage;
import com.ing.canada.plp.domain.coverage.CoverageRepositoryEntry;
import com.ing.canada.plp.domain.enums.ActionTakenCodeEnum;

/**
 * CoverageOffer entity.
 * 
 * @author Patrick Lafleur
 * 
 * Modifications: - May 1st, 2008: Renamed methods returning a Boolean/boolean from getBoolean() to isBoolean()
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "COVERAGE_OFFER", uniqueConstraints = {})
@NamedQueries({
			@NamedQuery(name = "CoverageOffer.findAllSelectedCoverageOffers",
					query = "select c from CoverageOffer c join c.insuranceRiskOffer iro join iro.insuranceRisk ir where c.coverageSelectedIndicator = 'Y'  and ir.selectedInsuranceRiskOffer = iro.id and ir.policyVersion = :policyVersion"), 
			@NamedQuery(name = "CoverageOffer.findAllSelectedCoverageOffersForInternalOfferType", 
					query = "select c from CoverageOffer c join c.insuranceRiskOffer iro join iro.insuranceRisk ir where c.coverageSelectedIndicator = 'Y' and iro.internalTechnicalOfferType = :internalOfferType and ir.policyVersion = :policyVersion"),
			@NamedQuery(name = "CoverageOffer.findAllCoverageOffersByPolicyOfferRatingAndCoverageGroup", 
					query = "select c from CoverageOffer c join c.insuranceRiskOffer iro join c.coverageRepositoryEntry cre where cre.coverageCode = :cd  and iro.policyOfferRating = :por")
})
public class CoverageOffer extends BaseCoverage {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "COVERAGE_OFFER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "CoverageOfferSequence")
	@SequenceGenerator(name = "CoverageOfferSequence", sequenceName = "COVERAGE_OFFER_SEQ", allocationSize = 5)
	private Long id;

	/** The insurance risk offer. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_RISK_OFFER_ID", nullable = false, updatable = true)
	private InsuranceRiskOffer insuranceRiskOffer;

	/** The coverage premium offers. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "coverageOffer")
	@Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<CoveragePremiumOffer> coveragePremiumOffers = new HashSet<CoveragePremiumOffer>(0);

	/** The action taken. */
	@Column(name = "ACTION_TAKEN_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ActionTakenCodeEnum") })
	private ActionTakenCodeEnum actionTaken = null;
	
	/** The action taken. */
	@Column(name = "MOST_RECENT_USR_ACT_TAKEN_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ActionTakenCodeEnum") })
	private ActionTakenCodeEnum lastActionTaken = null;

	/** The road block indicator. */
	@Column(name = "ROAD_BLOCK_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean roadBlockIndicator;

	/**
	 * Instantiates a new coverage offer.
	 */
	public CoverageOffer() {
		// noarg constructor
	}

	/**
	 * Instantiates a new coverage offer.
	 * 
	 * @param aCoverageRepositoryEntry the a coverage repository entry
	 * @param aInsuranceRiskOffer the a insurance risk offer
	 */
	public CoverageOffer(CoverageRepositoryEntry aCoverageRepositoryEntry, InsuranceRiskOffer aInsuranceRiskOffer) {
		setCoverageRepositoryEntry(aCoverageRepositoryEntry);
		setInsuranceRiskOffer(aInsuranceRiskOffer);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the insurance risk offer.
	 * 
	 * @return the insurance risk offer
	 */
	@XmlTransient // parent
	public InsuranceRiskOffer getInsuranceRiskOffer() {
		return this.insuranceRiskOffer;
	}

	/**
	 * Sets the insurance risk offer.
	 * 
	 * @param aInsuranceRiskOffer the new insurance risk offer
	 */
	public void setInsuranceRiskOffer(InsuranceRiskOffer aInsuranceRiskOffer) {
		AssociationsHelper.updateOneToManyFields(aInsuranceRiskOffer, "coverageOffers", this, "insuranceRiskOffer");
	}

	/**
	 * Gets the last update timestamp.
	 * 
	 * @return the last update timestamp
	 */
	@XmlElementWrapper(name="coveragePremiumOffers")
	@XmlElement(name="coveragePremiumOffer")
	public Set<CoveragePremiumOffer> getCoveragePremiumOffers() {
		return Collections.unmodifiableSet(this.coveragePremiumOffers);
	}

	/**
	 * Sets the coverage premium offers.
	 * 
	 * @param aCoveragePremiumOffers the new coverage premium offers
	 */
	protected void setCoveragePremiumOffers(Set<CoveragePremiumOffer> aCoveragePremiumOffers) {
		this.coveragePremiumOffers = aCoveragePremiumOffers;
	}

	/**
	 * Adds the coverage premium offer.
	 * 
	 * @param offer the offer
	 */
	public void addCoveragePremiumOffer(CoveragePremiumOffer offer) {
		AssociationsHelper.updateOneToManyFields(this, "coveragePremiumOffers", offer, "coverageOffer");
	}

	/**
	 * Removes the coverage premium offer.
	 * 
	 * @param offer the offer
	 */
	public void removeCoveragePremiumOffer(CoveragePremiumOffer offer) {
		AssociationsHelper.updateOneToManyFields(null, "coveragePremiumOffers", offer, "coverageOffer");
	}
	
	/**
	 * Clears the CoveragePremiumOffer collection and detaches them from this CoverageOffer (on both side of the
	 * relationship, and on the RatingRiskOffer relationship as well).
	 */
	public void clearCoveragePremiumOffers() {
		for (CoveragePremiumOffer coveragePremiumOffer : new HashSet<CoveragePremiumOffer>(this.coveragePremiumOffers)) {
			// Remove the link via the RatingRiskOffer
			coveragePremiumOffer.getRatingRiskOffer().removeCoveragePremiumOffer(coveragePremiumOffer);
			// Remove the link via the CoverageOffer
			this.removeCoveragePremiumOffer(coveragePremiumOffer);
		}
	}

	/**
	 * Gets the action taken.
	 * 
	 * @return the action taken
	 */
	public ActionTakenCodeEnum getActionTaken() {
		return this.actionTaken;
	}

	/**
	 * Sets the action taken.
	 * 
	 * @param anActionTaken the new action taken
	 */
	public void setActionTaken(ActionTakenCodeEnum anActionTaken) {
		this.actionTaken = anActionTaken;
	}

	public ActionTakenCodeEnum getLastActionTaken() {
		return lastActionTaken;
	}

	public void setLastActionTaken(ActionTakenCodeEnum lastActionTaken) {
		this.lastActionTaken = lastActionTaken;
	}

	/**
	 * Gets the road block indicator.
	 * 
	 * @return the road block indicator
	 */
	public Boolean getRoadBlockIndicator() {
		return this.roadBlockIndicator;
	}

	/**
	 * Sets the road block indicator.
	 * 
	 * @param aRoadBlockIndicator the new road block indicator
	 */
	public void setRoadBlockIndicator(Boolean aRoadBlockIndicator) {
		this.roadBlockIndicator = aRoadBlockIndicator;
	}
	
	public String toString() {
		return this.getCoverageRepositoryEntry() != null ? this.getCoverageRepositoryEntry().getCoverageCode() : null;
	}
}
