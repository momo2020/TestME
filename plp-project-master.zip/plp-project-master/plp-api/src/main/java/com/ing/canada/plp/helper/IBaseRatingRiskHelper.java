/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import java.util.Set;

import com.ing.canada.plp.domain.insurancerisk.BaseRatingRisk;

/**
 * The Interface IBaseCoverageHelper.
 * 
 * @author strichar
 */
public interface IBaseRatingRiskHelper {

	/**
	 * Find the principal rating risk.
	 * 
	 * @param ratingRiskSet the rating risk set
	 * 
	 * @return the base rating risk
	 */
	BaseRatingRisk findPrincipalRatingRisk(Set<? extends BaseRatingRisk> ratingRiskSet);
}
