/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum InsuredWithCompanyCodeEnum.
 */
public enum InsuredWithCompanyCodeEnum {

	LESS_THAN_1_YEAR("0"), ONE_YEAR_BUT_LESS_THAN_TWO("1"), TWO_YEARS_BUT_LESS_THAN_THREE("2"), THREE_YEARS_BUT_LESS_THAN_FOUR(
	"3"), FOUR_YEARS_BUT_LESS_THAN_FIVE("4"), FIVE_YEARS_BUT_LESS_THAN_SIX("5"), MORE_THAN_SIX("6");

	/**
	 * Instantiates a new holder auto insurance since code enum.
	 * 
	 * @param aCode the a code
	 */
	private InsuredWithCompanyCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the holder auto insurance since code enum
	 */
	public static InsuredWithCompanyCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (InsuredWithCompanyCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
