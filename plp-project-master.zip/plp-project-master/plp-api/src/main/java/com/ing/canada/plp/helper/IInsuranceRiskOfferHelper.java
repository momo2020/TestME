/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import java.util.List;

import com.ing.canada.plp.domain.enums.EndorsementCodeEnum;
import com.ing.canada.plp.domain.enums.InternalTechnicalOfferTypeCodeEnum;
import com.ing.canada.plp.domain.enums.OfferTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer;
import com.ing.canada.plp.domain.insuranceriskoffer.PolicyOfferRating;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * The Interface IInsuranceRiskOfferHelper.
 * 
 * @author nilaplan
 */
public interface IInsuranceRiskOfferHelper {

	/**
	 * Gets the insurance risk offer for offer type.
	 * 
	 * @param aPolicyOfferRating
	 *            the a policy offer rating
	 * @param anInsuranceRisk
	 *            the an insurance risk
	 * @param anOfferType
	 *            the an offer type
	 * 
	 * @return the insurance risk offer for offer type
	 */
	InsuranceRiskOffer getInsuranceRiskOfferForOfferType(InsuranceRisk anInsuranceRisk, OfferTypeCodeEnum anOfferType);

	/**
	 * Checks if liability, comprehensive and collision are selected on an
	 * offer. This method will always return true for any non-custom offer.
	 * 
	 * @param offer
	 *            the offer to check coverages on
	 * @return true if all 3 basic coverages are selected on the specified
	 *         offer, false otherwise
	 */
	boolean areBasicCoveragesSelectedOnOffer(InsuranceRiskOffer offer);

	/**
	 * Checks if an endorsement is present on an insuranceRiskOffer.
	 * 
	 * @param endorsementList
	 *            List of
	 *            {@link com.ing.canada.plp.domain.enums.EndorsementCodeEnum}
	 * @param aInsuranceRiskOffer
	 *            {@link InsuranceRiskOffer}
	 * 
	 * @return true, if one endorsement is present on an insuranceRiskOffer
	 */
	boolean isCoveragePresentAndSelectedOnInsuranceRiskOffer(InsuranceRiskOffer aInsuranceRiskOffer,
			final Object[] endorsementList);

	boolean isCoveragePresentAndSelectedOnInsuranceRiskOffer(InsuranceRiskOffer aInsuranceRiskOffer,
			final EndorsementCodeEnum code);

	/**
	 * Finds the current InsuranceRiskOffer match to a risk on the latest
	 * policyoffferrarting
	 * 
	 * @param anInsuranceRisk
	 *            the an insurance risk
	 * 
	 * @return the insurance risk offer for risk
	 */
	List<InsuranceRiskOffer> getInsuranceRiskOfferForRisk(InsuranceRisk anInsuranceRisk);

	/**
	 * Gets the insurance risk offer for risk sequence offer type and policy
	 * version.
	 * 
	 * @param insuranceRiskSequence
	 *            the insurance risk sequence
	 * @param offerType
	 *            the offer type
	 * @param plPolicyVersion
	 *            the pl policy version
	 * 
	 * @return the insurance risk offer for risk sequence offer type and policy
	 *         version
	 */
	InsuranceRiskOffer getInsuranceRiskOfferForRiskSequenceOfferTypeAndPolicyVersion(Integer insuranceRiskSequence,
			OfferTypeCodeEnum anOfferType, PolicyVersion plPolicyVersion);

	/**
	 * 
	 * @param anInsuranceRiskSequence
	 * @param anInternalOfferType
	 * @param aplPolicyVersion
	 * @return
	 */
	InsuranceRiskOffer getInsuranceRiskOfferForRiskSequenceInternalOfferType(Integer anInsuranceRiskSequence,
			InternalTechnicalOfferTypeCodeEnum anInternalOfferType, PolicyVersion aplPolicyVersion);

	/**
	 * 
	 * @param aPolicy
	 * @param anInternal
	 * @return
	 */
	PolicyOfferRating getPolicyOfferRatingForInternalOfferType(PolicyVersion aPolicy,
			InternalTechnicalOfferTypeCodeEnum anInternal);

	/**
	 * 
	 * @param anInsuranceRisk
	 * @param anInternal
	 * @return
	 */
	InsuranceRiskOffer getInsuranceRiskOfferForRiskAndInternalOfferType(InsuranceRisk anInsuranceRisk,
			InternalTechnicalOfferTypeCodeEnum anInternal);

	/**
	 * Retrieve the most recent (latest) insurance risk offer which : - doesn`t
	 * have any diagnostics attached to it. This method is used by the data
	 * mediator to SOM (Diagnostics) to retrieve the original custom offer used
	 * for the diagnostics.
	 * 
	 * @param anInsuranceRisk
	 *            Insurance risk
	 * @return latest non diagnosticated insurance risk offer
	 */
	InsuranceRiskOffer getLatestNonDiagnosticatedInsuranceRiskOffer(InsuranceRisk anInsuranceRisk);

	/**
	 * Make the transfer of the messages from one <code>PolicyOfferRating</code>
	 * ton another
	 * 
	 * @param policyOfferFrom
	 * @param policyOfferTo
	 * @return whether or not there were messages to transfer
	 */
	public Boolean transferTransactionalMessages(PolicyOfferRating policyOfferFrom, PolicyOfferRating policyOfferTo);

}
