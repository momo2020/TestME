/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum OfferTypeCodeEnum.
 */
public enum OfferTypeCodeEnum {
	
	/* Ce qu'il y a dans 14C 
	OFFER_WITH_THE_BEST_COVERAGE("C"), 
	OFFER_WITH_THE_BEST_PRICE("P"),
	OFFER_WITH_THE_BEST_VALUE("V"), 
	CUSTOM_OFFER_DONE_BY_THE_CLIENT("O"), 
	MARKET_OFFER_KANETIX("M");
	*/
	
	// Ce qu'il y a dans R26
	
	/*COVERAGEADVISOR_ prefix has been added to make them distinct from the others possibles values, especially due to the fact
	 * that RECOMMENDED already exists */
	PREMIUM("C"), ECONOMY("P"), RECOMMENDED("V"), CUSTOM("O"), MARKET("M"), COVERAGEADVISOR_PEOPLELIKEYOU("Y"), COVERAGEADVISOR_RECOMMENDED("R");

	/**
	 * Instantiates a new offer type code enum.
	 * 
	 * @param aCode the a code
	 */
	private OfferTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	@Override
	public String toString() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the offer type code enum
	 */
	public static OfferTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (OfferTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
