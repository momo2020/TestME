package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum UserActivityTypeCodeEnum.
 */
public enum UserActivityTypeCodeEnum {
	
	VIEW_QUOTE("VIEW_QUO"), UPLOAD_QUOTE("UPLOAD_QUO"), CHANGE_FOLLOWUP_STATUS("CHG_FLW_ST"), ADD_NOTE("ADD_NOTE"), REASSIGNED_QUOTE("REAS_QUO"), CUSTOMER_CALLBACK_REQUESTED("CUS_CBK_RQ"), DUPLICATE_FAKE("DISCARD");

	/** The code. */
	private String code = null;
	
	/**
	 * Instantiates a new user activity type code enum.
	 * 
	 * @param aCode the a code
	 */
	private UserActivityTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the user activity type code enum
	 */
	public static UserActivityTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (UserActivityTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
