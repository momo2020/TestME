package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

public enum AddressDeliveryModeCodeEnum {
	PO_BOX("PO BOX", "3"),
	RURAL_ROUTE("RR", "4"),
	GENERAL_DELIVERY("GD", "5");

	/**
	 * Instantiates a new a AddressDeliveryModeCodeEnum
	 * 
	 * @param aCode the code
	 */
	private AddressDeliveryModeCodeEnum(String aCode, String aRTCode) {
		this.code = aCode;
		this.recordTypeCode = aRTCode;
	}

	/** The code. */
	private String code = null;
	
	/** The associated record type */
	private String recordTypeCode = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the additional interest type code enum
	 */
	public static AddressDeliveryModeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (AddressDeliveryModeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no value found for code: " + value);

	}
	
	/**
	 * Value for postal code record type.
	 * 
	 * @param value the value
	 * 
	 * @return the additional interest type code enum
	 */
	public static AddressDeliveryModeCodeEnum valueForRecordType(String recordType) {

		if (StringUtils.isBlank(recordType) 
				|| "1".equals(recordType) 
				|| "2".equals(recordType)) {
			return null;
		}
		for (AddressDeliveryModeCodeEnum v : values()) {
			if (v.recordTypeCode.equals(recordType)) {
				return v;
			}
		}
		throw new IllegalArgumentException("no value found for record type code: " + recordType);
	}

	/**
	 * Gets the record type code
	 * 
	 * @return the recordTypeCode
	 */
	public String getRecordTypeCode() {
		return this.recordTypeCode;
	}

}
