/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum ProvinceCodeEnum.
 */
public enum ProvinceCodeEnum {
	ALBERTA("AB"), //
	BRITISH_COLUMBIA("BC"),  //
	MANITOBA("MB"),  //
	NEW_BRUNSWICK("NB"),  //
	NEWFOUNDLAND_AND_LABRADOR("NL"),  //
	NOVA_SCOTIA("NS"),  //
	ONTARIO("ON"),  //
	PRINCE_EDWARD_ISLAND("PE"),  //
	QUEBEC("QC"),  //
	SASKATCHEWAN("SK"),  //
	NORTHWEST_TERRITORIES("NT"),  //
	YUKON("YT"),  //
	NUNAVUT("NU"),  //
	OTHER("OT"),  //
	USA("US"),  //
	EUROPE("EC"); 
	
	private static Map<String, ProvinceCodeEnum> valuesMap = null;

	/** The code. */
	private String code = null;
	
	/**
	 * Instantiates a new province code enum.
	 * 
	 * @param aCode the a code
	 */
	private ProvinceCodeEnum(String code) {
		this.code = code;
	}

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the province code enum
	 */
	public static ProvinceCodeEnum valueOfCode(String value) {
		if (StringUtils.isBlank(value)) {
			return null;
		}

		for (ProvinceCodeEnum v : values()) {
			if (StringUtils.equalsIgnoreCase(v.code, value)) {
				return v;
			}

		}
		throw new IllegalArgumentException("no enum value found for code: " + value);
	}

	private static List<ProvinceCodeEnum> CANADIAN_PROVINCES = 
			                    Collections.unmodifiableList(
			                          Arrays.asList(ALBERTA, BRITISH_COLUMBIA, MANITOBA, NEW_BRUNSWICK , NEWFOUNDLAND_AND_LABRADOR,
	                                                NOVA_SCOTIA, ONTARIO, PRINCE_EDWARD_ISLAND, QUEBEC, SASKATCHEWAN,
                                        	        NORTHWEST_TERRITORIES, YUKON, NUNAVUT ) );
	
	public static ProvinceCodeEnum valueOfCodeForCanadianProvince(String value) {
		if(StringUtils.isBlank(value)){
			return null;
		}
		
		final ProvinceCodeEnum result = valueOfCode(value);
		
		if(CANADIAN_PROVINCES.contains(result) ){
			return result;
		}
		return null;
	}

	/**
	 * Returns the ProvinceCodeEnum based on the variant of the provided locale.
	 * 
	 * @return null if no variant is defined
	 * */
	public static ProvinceCodeEnum fromLocale(Locale locale) {
		ProvinceCodeEnum province = null;

		if (locale != null && StringUtils.isNotEmpty(locale.getVariant())) {
			if (QUEBEC.getCode().equalsIgnoreCase(locale.getVariant())) {
				province = QUEBEC;

			} else if (ONTARIO.getCode().equalsIgnoreCase(locale.getVariant())) {
				province = ONTARIO;

			} else if (ALBERTA.getCode().equalsIgnoreCase(locale.getVariant())) {
				province = ALBERTA;
			} else if (BRITISH_COLUMBIA.getCode().equalsIgnoreCase(locale.getVariant())) {
				province = BRITISH_COLUMBIA;
			}
		}

		return province;
	}
	
	public static ProvinceCodeEnum fromCode(String code) {
		if (code != null) {
			code = code.toUpperCase();
		}
		
		
		if (ProvinceCodeEnum.valuesMap == null) {
			ProvinceCodeEnum.valuesMap = new HashMap<String, ProvinceCodeEnum>();

			for (ProvinceCodeEnum province : ProvinceCodeEnum.values())
				ProvinceCodeEnum.valuesMap.put(province.getCode().toUpperCase(), province);
		}

		return ProvinceCodeEnum.valuesMap.get(code);
	}
}
