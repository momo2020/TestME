package com.ing.canada.plp.domain.enums;

import static org.apache.commons.lang.StringUtils.isEmpty;

public enum ReportType {
	
	FCSA("FCSA"),
	MVR("MVR"),
	AUTOPLUS("ATPL");
	
	
	private String code;
	
	
	private ReportType(final String code) {
		this.code = code;
	}


	public String getCode() {
		return code;
	}


	public void setCode(final String code) {
		this.code = code;
	}
	
	
	public static ReportType valueOfCode(final String code) {

		if (isEmpty(code))
			return null;

		for (ReportType c : values()) {
			if (c.code.equals(code)) {
				return (c);
			}

		}

		throw new IllegalArgumentException("ReportType enum code=" + code + " does not exist");

	}
	

}
