/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.domain.enums.RatingRiskTypeCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer;
import com.ing.canada.plp.domain.insuranceriskoffer.RatingRiskOffer;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * This interface exposes services required to manage Rating risks offers related entities.
 * 
 * @author R�gis Brochu
 */
public interface IRatingRiskOfferService extends ICRUDService<RatingRiskOffer> {

	/**
	 * This method returns all rating risks offers of all selected offers 
	 * of all insurance risk of the policy version.
	 * 
	 * @param policyVersion the policy version
	 * 
	 * @return the list< rating risk offer>
	 */
	List<RatingRiskOffer> findAllRatingRiskOffersByPolicyVersion(PolicyVersion policyVersion);	
	
	
	/** Returns the rating risk offer (if any) for the given rating risk type.
	 * 
	 * @param aRisk the insurance risk offer
	 * @param aType rating risk type code
	 * @return RatingRiskOffer the rating risk offer associated with the type
	 */
	RatingRiskOffer findRatingRiskByType(InsuranceRiskOffer aRisk, RatingRiskTypeCodeEnum aType);
	
}
