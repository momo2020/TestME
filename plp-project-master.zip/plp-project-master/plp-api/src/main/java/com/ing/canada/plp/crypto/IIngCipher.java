/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.crypto;

/**
 * Service to encrypt and decrypt strings or byte arrays of arbitrary length.
 */
public interface IIngCipher {

	/**
	 * Encrypts <code>decryptedString</code> into a byte array.
	 * 
	 * @param decryptedString Decrypted string to be encrypted. Nullable.
	 * @return Encrypted base 64 string. Null when <code>decryptedString</code> is <code>null</code>.
	 * @throws Exception the exception
	 */
	String encryptString(String decryptedString) throws Exception;

	/**
	 * Encrypts <code>decryptedBytes</code> into a byte array.
	 * 
	 * @param decryptedBytes Data to be encrypted. Nullable.
	 * @return Encrypted base 64 string. Null when <code>decryptedBytes</code> is <code>null</code>.
	 * @throws Exception the exception
	 */
	String encrypt(byte[] decryptedBytes) throws Exception;

	/**
	 * Decrypts <code>encryptedString</code> into a string.
	 * 
	 * @param encryptedString Encrypted base 64 string to be decrypted. Nullable.
	 * @return Decrypted string. Null when <code>encryptedBytes</code> is <code>null</code>.
	 * @throws Exception the exception
	 */
	String decryptToString(String encryptedString) throws Exception;

	/**
	 * Decrypts <code>encryptedString</code> into a byte array.
	 * 
	 * @param encryptedString Encrypted base 64 string to be decrypted. Nullable.
	 * @return Decrypted data. Null when <code>encryptedBytes</code> is <code>null</code>.
	 * @throws Exception the exception
	 */
	byte[] decrypt(String encryptedString) throws Exception;
}
