/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.roadblock;

/**
 * @author plafleur
 * 
 * All entities that can be roadblocked must implement this interface.
 */
public interface Roadblockable {

	/**
	 * Marks the state of this entity as roadblocked, ready to be saved in the db so we know which entity triggered the
	 * roadblock when the user edits it's quote.
	 */
	void markAsRoadblocked();

	/**
	 * Resets the roadblock state so the entity is not roadblocked anymore.
	 */
	void clearRoadblock();

}
