/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import com.ing.canada.plp.domain.enums.OfferTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer;
import com.ing.canada.plp.domain.insuranceriskoffer.PolicyOfferRating;

/**
 * The Interface IPolicyOfferRatingHelper.
 * 
 * @author strichar
 */
public interface IPolicyOfferRatingHelper {

	/**
	 * Verifies if a message from classic was set on this policy version.
	 * 
	 * @param aMessage the message
	 * @param aPolicyOfferRating the a policy offer rating
	 * 
	 * @return true, if successful
	 */
	boolean hasMessage(PolicyOfferRating aPolicyOfferRating, String aMessage);

	/**
	 * Gets the selected insurance risk offer.
	 * 
	 * @param aSequenceNumber the sequence number
	 * @param aPolicyOfferRating the a policy offer rating
	 * 
	 * @return the selected insurance risk offer
	 */
	InsuranceRiskOffer getSelectedInsuranceRiskOffer(final Short aSequenceNumber, PolicyOfferRating aPolicyOfferRating);

	/**
	 * Gets the risk offer by offer type.
	 * 
	 * @param anInsuranceRisk the an insurance risk
	 * @param aPolicyOfferRating the a policy offer rating
	 * @param anOfferType the an offer type
	 * 
	 * @return the insurance risk offer by type
	 */
	InsuranceRiskOffer getInsuranceRiskOfferByType(InsuranceRisk anInsuranceRisk, PolicyOfferRating aPolicyOfferRating,
			OfferTypeCodeEnum anOfferType);

	/**
	 * Gets the extended term (1 year, 2 year or 0 for none.
	 * 
	 * @param aPolicyOfferRating the a policy offer rating
	 * 
	 * @return the extended term
	 */
	int getExtendedTerm(PolicyOfferRating aPolicyOfferRating);
}
