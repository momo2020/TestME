package com.ing.canada.plp.helper;

import java.util.Set;

import com.ing.canada.plp.domain.enums.AdditionalInterestTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.AdditionalInterestRole;

public interface IAdditionalInterestRoleHelper {

	/**
	 * Gets the additional interest role.
	 * 
	 * @param additionalInterestRoles the additional interest roles
	 * @param aAdditionalInterestTypeCodeEnum the a additional interest type code enum
	 * 
	 * @return the additional interest role
	 */
	AdditionalInterestRole getAdditionalInterestRole(Set<AdditionalInterestRole> additionalInterestRoles,
			AdditionalInterestTypeCodeEnum aAdditionalInterestTypeCodeEnum);

}
