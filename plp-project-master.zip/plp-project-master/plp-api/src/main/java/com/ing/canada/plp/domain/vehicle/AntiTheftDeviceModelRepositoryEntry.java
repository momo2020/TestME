package com.ing.canada.plp.domain.vehicle;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * AntiTheftDvMdRepEntry entity.
 * 
 * @author ub8169
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "ANTI_THEFT_DV_MD_REP_ENTRY")
public class AntiTheftDeviceModelRepositoryEntry extends BaseEntity {
	// Fields
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private AntiTheftDeviceModelRepositoryEntryId id;

	@Column(name = "DEVICE_MODEL_NAME_ENG_TXT", nullable = false, length = 20)
	private String deviceModelNameEnglish;

	@Column(name = "DEVICE_MODEL_NAME_FRE_TXT", nullable = false, length = 20)
	private String deviceModelNameFrench;

	@Column(name = "ORDER_ITEM_ENG_NBR", nullable = false, precision = 4, scale = 0)
	private Long orderItemEnglishNumber;

	@Column(name = "ORDER_ITEM_FRE_NBR", nullable = false, precision = 4, scale = 0)
	private Long orderItemFrenchNumber;

	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", nullable = false, length = 7)
	private Date effectiveDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;

	/** default constructor */
	public AntiTheftDeviceModelRepositoryEntry() {
		// Nothing to do
	}
	
	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public AntiTheftDeviceModelRepositoryEntryId getId() {
		return this.id;
	}
	
	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object anId) {
		if (anId != null && !(anId instanceof AntiTheftDeviceModelRepositoryEntryId)) {
			throw new IllegalArgumentException(
					"the id must be of type AntiTheftDeviceModelRepositoryEntryId (received: " + anId + ")");
		}
		this.id = (AntiTheftDeviceModelRepositoryEntryId) anId;
	}

	/**
	 * @return the deviceModelNameEnglish
	 */
	public String getDeviceModelNameEnglish() {
		return this.deviceModelNameEnglish;
	}

	/**
	 * @param deviceModelNameEnglish the deviceModelNameEnglish to set
	 */
	public void setDeviceModelNameEnglish(String aDeviceModelNameEnglish) {
		this.deviceModelNameEnglish = aDeviceModelNameEnglish;
	}

	/**
	 * @return the deviceModelNameFrench
	 */
	public String getDeviceModelNameFrench() {
		return this.deviceModelNameFrench;
	}

	/**
	 * @param deviceModelNameFrench the deviceModelNameFrench to set
	 */
	public void setDeviceModelNameFrench(String aDeviceModelNameFrench) {
		this.deviceModelNameFrench = aDeviceModelNameFrench;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date anEffectiveDate) {
		this.effectiveDate = anEffectiveDate;
	}

	/**
	 * @return the expiryDate
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * @param expiryDate the expiryDate to set
	 */
	public void setExpiryDate(Date anExpiryDate) {
		this.expiryDate = anExpiryDate;
	}

	/**
	 * @return the orderItemEnglishNumber
	 */
	public Long getOrderItemEnglishNumber() {
		return this.orderItemEnglishNumber;
	}

	/**
	 * @param orderItemEnglishNumber the orderItemEnglishNumber to set
	 */
	public void setOrderItemEnglishNumber(Long anOrderItemEnglishNumber) {
		this.orderItemEnglishNumber = anOrderItemEnglishNumber;
	}

	/**
	 * @return the orderItemFrenchNumber
	 */
	public Long getOrderItemFrenchNumber() {
		return this.orderItemFrenchNumber;
	}

	/**
	 * @param orderItemFrenchNumber the orderItemFrenchNumber to set
	 */
	public void setOrderItemFrenchNumber(Long anOrderItemFrenchNumber) {
		this.orderItemFrenchNumber = anOrderItemFrenchNumber;
	}
}
