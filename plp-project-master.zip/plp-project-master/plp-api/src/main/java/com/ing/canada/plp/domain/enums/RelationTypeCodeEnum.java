/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum RelationTypeCodeEnum.
 */
public enum RelationTypeCodeEnum {

	COMBINED("COMB"), OTHER("OTHR"), REPLACING("RPLC"), PARENTS_POLICY("PPAR"), OTHER_DRIVER_WITH_COMPANY_IN_HOUSEHOLD(
			"ODCH");

	/**
	 * Instantiates a new relation type code enum.
	 * 
	 * @param aCode the a code
	 */
	private RelationTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the relation type code enum
	 */
	public static RelationTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (RelationTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
