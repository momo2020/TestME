/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum DeviceModelCodeEnum.
 */
public enum DeviceModelCodeEnum {

	/** The BANSHEE_ICALOCK. */
	BANSHEE_ICALOCK("B"),

	/** The ARMED_GUARD_SHERLOCK. */
	ARMED_GUARD_SHERLOCK("A"),

	/** The VIPER. */
	VIPER("V"),

	/** The MERLIN. */
	MERLIN("M"),

	/** The HAWK_200_AUTOLAND. */
	HAWK_200_AUTOLAND("H"),

	/** The OTHER. */
	OTHER("AU"),

	/** The ADAV. */
	ADAV("AD"),

	/** The AUTOGRAPH. */
	AUTOGRAPH("AG"),

	/** The AMERI_KOP. */
	AMERI_KOP("AK"),

	/** The AUTOLUCK. */
	AUTOLUCK("AL"),

	/** The AUTOMOBILE_MANUFACTURER. */
	AUTOMOBILE_MANUFACTURER("AM"),

	/** The GUARDIAN. */
	GUARDIAN("GU"),

	/** The LARLOK. */
	LARLOK("LA"),

	/** The OTOPROTEC. */
	OTOPROTEC("OT"),

	/** The SHERLOCK. */
	SHERLOCK("SH"),

	/** The VIN_LOCK. */
	VIN_LOCK("VI"),

	/** The ULTRACAR. */
	ULTRACAR("UL"),

	/** The BOOMERANG_1. */
	BOOMERANG_1("B1"),

	/** The BOOMERANG_2. */
	BOOMERANG_2("B2"),

	/** The INTERCEPTER_STAR_TRACK. */
	INTERCEPTER_STAR_TRACK("IN"),

	/** The LYNX*/
	LYNX("LY"),

	/** The MOBILIUS. */
	MOBILIUS("MO"),

	/** The NAVLYNX_AUTOGUARD. */
	NAVLYNX_AUTOGUARD("NA"),

	/** The ON_STAR. */
	ON_STAR("OS"),

	/** The SATELINX. */
	SATELINX("SA"),

	/** The SPAVTRACK. */
	SPAVTRACK("SP"),

	/** The ECONOTRACK. */
	ECONOTRACK("ET"),

	/** The TAG. */
	TAG("TG"),
	
	DATADOTDNA("DA"),
	GLOBALGLOBALI("GL"),
	MICRODOTDNA("MC"),
	THREEEYETRACKING("3Y"),
	CELLUTRACK("CT"),
	LOJACKBOOMERANG("LJ"),
	MLINK("ML"),		
	ORCA("OC"),
	VIGILGPS("VG"),
	BARRACUDA("BA"),
	KOLOMBO("KO")
	;
	

	/**
	 * Instantiates a new device model code enum.
	 * 
	 * @param aCode the a code
	 */
	private DeviceModelCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the device model code enum
	 */
	public static DeviceModelCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (DeviceModelCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
