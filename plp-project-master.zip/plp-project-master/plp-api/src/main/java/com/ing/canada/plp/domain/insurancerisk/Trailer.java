/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insurancerisk;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import org.hibernate.annotations.Parameter;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.usertype.BaseEntity;
import com.ing.canada.plp.domain.vehicle.Vehicle;

/**
 * Trailer entity.
 * 
 * @author Patrick Lafleur
 */
@Entity
@Table(name = "TRAILER", uniqueConstraints = {})
public class Trailer extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The insurance risk id. */
	@Id
	@GeneratedValue(generator = "insuranceRiskForeignGenerator")
	@org.hibernate.annotations.GenericGenerator(name = "insuranceRiskForeignGenerator", strategy = "foreign", parameters = @Parameter(name = "property", value = "insuranceRisk"))
	@Column(name = "INSURANCE_RISK_ID")
	private Long id;

	/** The vehicle. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "VEHICLE_ID", insertable = true, updatable = true)
	private Vehicle vehicle;

	/** The insurance risk. */
	@OneToOne(cascade = {}, fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn(name = "INSURANCE_RISK_ID")
	private InsuranceRisk insuranceRisk;

	/** The trailer year. */
	@Column(name = "TRAILER_YR", length = 4)
	private String trailerYear;

	/** The trailer make. */
	@Column(name = "TRAILER_MAKE_TXT", length = 20)
	private String trailerMake;

	/** The trailer model. */
	@Column(name = "TRAILER_MODEL_TXT", length = 40)
	private String trailerModel;

	/** The trailer code. */
	@Column(name = "TRAILER_CD", length = 5)
	private String trailerCode;

	/** The additional interest roles. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "trailer")
	private Set<AdditionalInterestRole> additionalInterestRoles = new HashSet<AdditionalInterestRole>(0);

	/** The Original Scenario Insurance Risk * */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_INSURANCE_RISK_ID", insertable = false, updatable = false)
	private InsuranceRisk originalScenarioInsuranceRisk;

	/**
	 * Instantiates a new trailer.
	 */
	public Trailer() {
		// noarg constructor
	}

	/**
	 * Instantiates a new trailer.
	 * 
	 * @param aInsuranceRisk the insurance risk
	 */
	public Trailer(InsuranceRisk aInsuranceRisk) {
		setInsuranceRisk(aInsuranceRisk);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aInsuranceRiskId the a insurance risk id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aInsuranceRiskId) {
		this.id = (Long)aInsuranceRiskId;
	}

	/**
	 * Gets the vehicle.
	 * 
	 * @return the vehicle
	 */
	public Vehicle getVehicle() {
		return this.vehicle;
	}

	/**
	 * Sets the vehicle.
	 * 
	 * @param aVehicle the new vehicle
	 */
	public void setVehicle(Vehicle aVehicle) {
		AssociationsHelper.updateOneToManyFields(aVehicle, "trailers", this, "vehicle");
	}

	/**
	 * Gets the insurance risk.
	 * 
	 * @return the insurance risk
	 */
	public InsuranceRisk getInsuranceRisk() {
		return this.insuranceRisk;
	}

	/**
	 * Sets the insurance risk.
	 * 
	 * @param aInsuranceRisk the new insurance risk
	 */
	public void setInsuranceRisk(InsuranceRisk aInsuranceRisk) {
		AssociationsHelper.updateOneToOneFields(aInsuranceRisk, InsuranceRisk.class, "trailer", this, Trailer.class,
				"insuranceRisk");
	}

	/**
	 * Gets the trailer year.
	 * 
	 * @return the trailer year
	 */
	public String getTrailerYear() {
		return this.trailerYear;
	}

	/**
	 * Sets the trailer year.
	 * 
	 * @param trailerYr the new trailer year
	 */
	public void setTrailerYear(String trailerYr) {
		this.trailerYear = trailerYr;
	}

	/**
	 * Gets the trailer make.
	 * 
	 * @return the trailer make
	 */
	public String getTrailerMake() {
		return this.trailerMake;
	}

	/**
	 * Sets the trailer make.
	 * 
	 * @param aTrailerMake the new trailer make
	 */
	public void setTrailerMake(String aTrailerMake) {
		this.trailerMake = aTrailerMake;
	}

	/**
	 * Gets the trailer model.
	 * 
	 * @return the trailer model
	 */
	public String getTrailerModel() {
		return this.trailerModel;
	}

	/**
	 * Sets the trailer model.
	 * 
	 * @param aTrailerModel the new trailer model
	 */
	public void setTrailerModel(String aTrailerModel) {
		this.trailerModel = aTrailerModel;
	}

	/**
	 * Gets the trailer code.
	 * 
	 * @return the trailer code
	 */
	public String getTrailerCode() {
		return this.trailerCode;
	}

	/**
	 * Sets the trailer code.
	 * 
	 * @param aTrailerCode the new trailer code
	 */
	public void setTrailerCode(String aTrailerCode) {
		this.trailerCode = aTrailerCode;
	}

	/**
	 * Gets the additional interest roles.
	 * 
	 * @return the additional interest roles
	 */
	@XmlElementWrapper(name="additionalInterestRoles")
	@XmlElement(name="additionalInterestRole")
	public Set<AdditionalInterestRole> getAdditionalInterestRoles() {
		return Collections.unmodifiableSet(this.additionalInterestRoles);
	}

	/**
	 * Sets the additional interest roles.
	 * 
	 * @param aAdditionalInterestRoles the new additional interest roles
	 */
	protected void setAdditionalInterestRoles(Set<AdditionalInterestRole> aAdditionalInterestRoles) {
		this.additionalInterestRoles = aAdditionalInterestRoles;
	}

	/**
	 * Adds the additional interest role.
	 * 
	 * @param additionalInterestRole the additional interest role
	 */
	public void addAdditionalInterestRole(AdditionalInterestRole additionalInterestRole) {
		AssociationsHelper.updateOneToManyFields(this, "additionalInterestRoles", additionalInterestRole, "trailer");
	}

	/**
	 * Removes the additional interest role.
	 * 
	 * @param additionalInterestRole the additional interest role
	 */
	public void removeAdditionalInterestRole(AdditionalInterestRole additionalInterestRole) {
		AssociationsHelper.updateOneToManyFields(null, "additionalInterestRoles", additionalInterestRole, "trailer");
	}

	/**
	 * Gets the original scenario insurance risk.
	 * 
	 * @return the original scenario insurance risk
	 */
	public InsuranceRisk getOriginalScenarioInsuranceRisk() {
		return this.originalScenarioInsuranceRisk;
	}

	/**
	 * Sets the original scenario insurance risk.
	 * 
	 * @param anOriginalScenarioInsuranceRisk the new original scenario insurance risk
	 */
	protected void setOriginalScenarioInsuranceRisk(InsuranceRisk anOriginalScenarioInsuranceRisk) {
		this.originalScenarioInsuranceRisk = anOriginalScenarioInsuranceRisk;
	}

}
