/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum BusinessTransactionActivityCodeEnum.
 */
public enum BusinessTransactionActivityCodeEnum {

	INITIAL_CONVERSION_FROM_AQS("CON"),
	INITIAL_QUOTE_OR_POLICY_CREATION("IQP"),
	VERSION_UPLOADED_IN_LEGACY("VUL"),
	VERSION_UPLOADED_IN_LEGACY_CANCELLED("VUC"),
	VERSION_CREATION_IN_LEGACY("VCL"),
	VERSION_RETRIEVED("VRW");


	/**
	 * Instantiates a new business transaction activity code enum.
	 * 
	 * @param aCode the a code
	 */
	private BusinessTransactionActivityCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the business transaction activity code enum
	 */
	public static BusinessTransactionActivityCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (BusinessTransactionActivityCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
