/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.coverage;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.insurancerisk.RatingRisk;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * BasicCoverageBasePremium entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "BASIC_COV_BASE_PREMIUM", uniqueConstraints = @UniqueConstraint(columnNames = "RATING_RISK_ID"))
public class BasicCoverageBasePremium extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	// Fields
	/** The id. */
	@Id
	@Column(name = "BASIC_COV_BASE_PREMIUM_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "BasicCoverageBasePremiumSequence")
	@SequenceGenerator(name = "BasicCoverageBasePremiumSequence", sequenceName = "BASIC_COV_BASE_PREMIUM_SEQ", allocationSize = 5)
	private Long id;

	/** The rating risk. */
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "RATING_RISK_ID", unique = true, nullable = false)
	private RatingRisk ratingRisk;

	/** The liability bodily injury amount. */
	@Column(name = "B_AN_PREM_LBLTY_BDLY_INJRY_AMT", precision = 12, scale = 3)
	private Double liabilityBodilyInjuryAmount;

	/** The liability property damage amount. */
	@Column(name = "B_AN_PREM_LBLTY_PRPTY_DMD_AMT", precision = 12, scale = 3)
	private Double liabilityPropertyDamageAmount;

	/** The accident benefit amount. */
	@Column(name = "B_AN_PREM_ACDNT_BNFT_AMT", precision = 12, scale = 3)
	private Double accidentBenefitAmount;

	/** The all perils amount. */
	@Column(name = "B_AN_PREM_ALL_PERILS_AMT", precision = 12, scale = 3)
	private Double allPerilsAmount;

	/** The collision amount. */
	@Column(name = "B_AN_PREM_COLLISION_AMT", precision = 12, scale = 3)
	private Double collisionAmount;

	/** The comprehensive amount. */
	@Column(name = "B_AN_PREM_COMPREHENSIVE_AMT", precision = 12, scale = 3)
	private Double comprehensiveAmount;

	/** The specified perils amount. */
	@Column(name = "B_AN_PREM_SPECIFIED_PERILS_AMT", precision = 12, scale = 3)
	private Double specifiedPerilsAmount;

	/** The liability amount. */
	@Column(name = "B_AN_PREM_LBLTY_AMT", precision = 12, scale = 3)
	private Double liabilityAmount;

	/** The medical expenses amount. */
	@Column(name = "B_AN_PREM_MEDICAL_EXPENSES_AMT", precision = 12, scale = 3)
	private Double medicalExpensesAmount;

	/** The total disability amount. */
	@Column(name = "B_AN_PREM_TOTAL_DISABILITY_AMT", precision = 12, scale = 3)
	private Double totalDisabilityAmount;

	/**
	 * default constructor.
	 */
	public BasicCoverageBasePremium() {
		// Nothing to do
	}

	/**
	 * minimal constructor.
	 * 
	 * @param basicCovBasePremiumId the basic cov base premium id
	 * @param aRatingRisk the rating risk
	 */
	public BasicCoverageBasePremium(Long basicCovBasePremiumId, RatingRisk aRatingRisk) {
		this.id = basicCovBasePremiumId;
		this.ratingRisk = aRatingRisk;
	}

	/**
	 * full constructor.
	 * 
	 * @param basicCovBasePremiumId the basic cov base premium id
	 * @param aRatingRisk the rating risk
	 * @param BAnPremLbltyBdlyInjryAmt the b an prem lblty bdly injry amt
	 * @param BAnPremLbltyPrptyDmdAmt the b an prem lblty prpty dmd amt
	 * @param BAnPremAcdntBnftAmt the b an prem acdnt bnft amt
	 * @param BAnPremAllPerilsAmt the b an prem all perils amt
	 * @param BAnPremCollisionAmt the b an prem collision amt
	 * @param BAnPremComprehensiveAmt the b an prem comprehensive amt
	 * @param BAnPremSpecifiedPerilsAmt the b an prem specified perils amt
	 * @param BAnPremLbltyAmt the b an prem lblty amt
	 * @param BAnPremMedicalExpensesAmt the b an prem medical expenses amt
	 * @param BAnPremTotalDisabilityAmt the b an prem total disability amt
	 */
	public BasicCoverageBasePremium(Long basicCovBasePremiumId, RatingRisk aRatingRisk,
			Double BAnPremLbltyBdlyInjryAmt, Double BAnPremLbltyPrptyDmdAmt, Double BAnPremAcdntBnftAmt,
			Double BAnPremAllPerilsAmt, Double BAnPremCollisionAmt, Double BAnPremComprehensiveAmt,
			Double BAnPremSpecifiedPerilsAmt, Double BAnPremLbltyAmt, Double BAnPremMedicalExpensesAmt,
			Double BAnPremTotalDisabilityAmt) {
		this.id = basicCovBasePremiumId;
		this.ratingRisk = aRatingRisk;
		this.liabilityBodilyInjuryAmount = BAnPremLbltyBdlyInjryAmt;
		this.liabilityPropertyDamageAmount = BAnPremLbltyPrptyDmdAmt;
		this.accidentBenefitAmount = BAnPremAcdntBnftAmt;
		this.allPerilsAmount = BAnPremAllPerilsAmt;
		this.collisionAmount = BAnPremCollisionAmt;
		this.comprehensiveAmount = BAnPremComprehensiveAmt;
		this.specifiedPerilsAmount = BAnPremSpecifiedPerilsAmt;
		this.liabilityAmount = BAnPremLbltyAmt;
		this.medicalExpensesAmount = BAnPremMedicalExpensesAmt;
		this.totalDisabilityAmount = BAnPremTotalDisabilityAmt;
	}

	// Property accessors
	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object basicCovBasePremiumId) {
		this.id = (Long) basicCovBasePremiumId;
	}

	/**
	 * Gets the rating risk.
	 * 
	 * @return the rating risk
	 */
	@XmlTransient // parent
	public RatingRisk getRatingRisk() {
		return this.ratingRisk;
	}

	/**
	 * Sets the rating risk.
	 * 
	 * @param aRatingRisk the new rating risk
	 */
	public void setRatingRisk(RatingRisk aRatingRisk) {
		AssociationsHelper.updateOneToOneFields(aRatingRisk, RatingRisk.class, "basicCoverageBasePremium", this,
				BasicCoverageBasePremium.class, "ratingRisk");
	}

	/**
	 * Gets the liability bodily injury amount.
	 * 
	 * @return the liability bodily injury amount
	 */
	public Double getLiabilityBodilyInjuryAmount() {
		return this.liabilityBodilyInjuryAmount;
	}

	/**
	 * Sets the liability bodily injury amount.
	 * 
	 * @param BAnPremLbltyBdlyInjryAmt the new liability bodily injury amount
	 */
	public void setLiabilityBodilyInjuryAmount(Double BAnPremLbltyBdlyInjryAmt) {
		this.liabilityBodilyInjuryAmount = BAnPremLbltyBdlyInjryAmt;
	}

	/**
	 * Gets the liability property damage amount.
	 * 
	 * @return the liability property damage amount
	 */
	public Double getLiabilityPropertyDamageAmount() {
		return this.liabilityPropertyDamageAmount;
	}

	/**
	 * Sets the liability property damage amount.
	 * 
	 * @param BAnPremLbltyPrptyDmdAmt the new liability property damage amount
	 */
	public void setLiabilityPropertyDamageAmount(Double BAnPremLbltyPrptyDmdAmt) {
		this.liabilityPropertyDamageAmount = BAnPremLbltyPrptyDmdAmt;
	}

	/**
	 * Gets the accident benefit amount.
	 * 
	 * @return the accident benefit amount
	 */
	public Double getAccidentBenefitAmount() {
		return this.accidentBenefitAmount;
	}

	/**
	 * Sets the accident benefit amount.
	 * 
	 * @param BAnPremAcdntBnftAmt the new accident benefit amount
	 */
	public void setAccidentBenefitAmount(Double BAnPremAcdntBnftAmt) {
		this.accidentBenefitAmount = BAnPremAcdntBnftAmt;
	}

	/**
	 * Gets the all perils amount.
	 * 
	 * @return the all perils amount
	 */
	public Double getAllPerilsAmount() {
		return this.allPerilsAmount;
	}

	/**
	 * Sets the all perils amount.
	 * 
	 * @param BAnPremAllPerilsAmt the new all perils amount
	 */
	public void setAllPerilsAmount(Double BAnPremAllPerilsAmt) {
		this.allPerilsAmount = BAnPremAllPerilsAmt;
	}

	/**
	 * Gets the collision amount.
	 * 
	 * @return the collision amount
	 */
	public Double getCollisionAmount() {
		return this.collisionAmount;
	}

	/**
	 * Sets the collision amount.
	 * 
	 * @param BAnPremCollisionAmt the new collision amount
	 */
	public void setCollisionAmount(Double BAnPremCollisionAmt) {
		this.collisionAmount = BAnPremCollisionAmt;
	}

	/**
	 * Gets the comprehensive amount.
	 * 
	 * @return the comprehensive amount
	 */
	public Double getComprehensiveAmount() {
		return this.comprehensiveAmount;
	}

	/**
	 * Sets the comprehensive amount.
	 * 
	 * @param BAnPremComprehensiveAmt the new comprehensive amount
	 */
	public void setComprehensiveAmount(Double BAnPremComprehensiveAmt) {
		this.comprehensiveAmount = BAnPremComprehensiveAmt;
	}

	/**
	 * Gets the specified perils amount.
	 * 
	 * @return the specified perils amount
	 */
	public Double getSpecifiedPerilsAmount() {
		return this.specifiedPerilsAmount;
	}

	/**
	 * Sets the specified perils amount.
	 * 
	 * @param BAnPremSpecifiedPerilsAmt the new specified perils amount
	 */
	public void setSpecifiedPerilsAmount(Double BAnPremSpecifiedPerilsAmt) {
		this.specifiedPerilsAmount = BAnPremSpecifiedPerilsAmt;
	}

	/**
	 * Gets the liability amount.
	 * 
	 * @return the liability amount
	 */
	public Double getLiabilityAmount() {
		return this.liabilityAmount;
	}

	/**
	 * Sets the liability amount.
	 * 
	 * @param BAnPremLbltyAmt the new liability amount
	 */
	public void setLiabilityAmount(Double BAnPremLbltyAmt) {
		this.liabilityAmount = BAnPremLbltyAmt;
	}

	/**
	 * Gets the medical expenses amount.
	 * 
	 * @return the medical expenses amount
	 */
	public Double getMedicalExpensesAmount() {
		return this.medicalExpensesAmount;
	}

	/**
	 * Sets the medical expenses amount.
	 * 
	 * @param BAnPremMedicalExpensesAmt the new medical expenses amount
	 */
	public void setMedicalExpensesAmount(Double BAnPremMedicalExpensesAmt) {
		this.medicalExpensesAmount = BAnPremMedicalExpensesAmt;
	}

	/**
	 * Gets the total disability amount.
	 * 
	 * @return the total disability amount
	 */
	public Double getTotalDisabilityAmount() {
		return this.totalDisabilityAmount;
	}

	/**
	 * Sets the total disability amount.
	 * 
	 * @param BAnPremTotalDisabilityAmt the new total disability amount
	 */
	public void setTotalDisabilityAmount(Double BAnPremTotalDisabilityAmt) {
		this.totalDisabilityAmount = BAnPremTotalDisabilityAmt;
	}

}
