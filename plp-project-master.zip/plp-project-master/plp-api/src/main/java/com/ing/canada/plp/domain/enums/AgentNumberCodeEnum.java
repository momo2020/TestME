/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum AgentNumberCodeEnum.
 */
public enum AgentNumberCodeEnum {
	BELAIR_QC_IN_HOUSE_USER("9143"),
	BELAIR_QC_CLIENT("9243"),
	BELAIR_QC_CLIENT_QUICK_QUOTE("99QF"),

	BELAIR_ON_IN_HOUSE_USER("9136"),
	BELAIR_ON_CLIENT("9090"),
	BELAIR_ON_CLIENT_QUICK_QUOTE("97QF"),

	BELAIR_BC_CLIENT("P4CD"),
	BELAIR_BC_CLIENT_QUICK_QUOTE("P3CD"),

	GREYPOWER_AB_IN_HOUSE_USER("P236"),
	GREYPOWER_AB_CLIENT("P190"),
	GREYPOWER_AB_CLIENT_QUICK_QUOTE("P1QF"),

	/** AGBN CLIENT WEB AUTO = 99BR */
	AGBN_QC_CLIENT_AQ("99BR"),

	/** AGBN CLIENT WEB QUICK QUOTE = 99BF */
	AGBN_QC_CLIENT_QQ("99BF");

	/**
	 * Instantiates a new agent number code enum.
	 *
	 * @param aCode the a code
	 */
	private AgentNumberCodeEnum(final String code) {
		this.code = code;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 *
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 *
	 * @param value the value
	 *
	 * @return the branch code enum
	 */
	public static AgentNumberCodeEnum valueOfCode(final String value) {
		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (AgentNumberCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);
	}
}