/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum PrincipalDriverSinceCodeEnum.
 */
public enum PrincipalDriverSinceCodeEnum {

	NO_EXPERIENCE("N"),
	LESS_THAN_12_MONTHS("00"), 
	TWELVE_TO_TWENTYTHREE_MONTHS("12"), 
	TWENTYFOUR_TO_THIRTYFIVE_MONTHS("24"), 
	THIRTYSIX_TO_FORTYSEVEN_MONTHS("36"), 
	FORTYEIGHT_TO_FIFTYNINE_MONTHS("48"), 
	SIXTY_TO_SEVENTY_ONE_MONTHS("60"), 
	SEVENTY_TWO_TO_EIGHTY_THREE_MONTHS("72"), 
	EIGHTY_FOUR_TO_NINETY_FIVE_MONTHS("84"), 
	NINETY_SIX_TO_ONE_HUNDRED_AND_SEVEN_MONTHS("96"), 
	ONE_HUNDRED_AND_EIGHT_TO_ONE_HUNDRED_AND_NINETEEN_MONTHS("108"), 
	MORE_THAN_ONE_HUNDRED_AND_TWENTY_MONTHS("120");
	
	/**
	 * Instantiates a new principal driver since code enum.
	 * 
	 * @param aCode the a code
	 */
	private PrincipalDriverSinceCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the principal driver since code enum
	 */
	public static PrincipalDriverSinceCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (PrincipalDriverSinceCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
