/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.businesstransaction;

import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.UnderwritingMessageStatusCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer;
import com.ing.canada.plp.domain.insuranceriskoffer.PolicyOfferRating;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * TransactionalMessage entity.
 * 
 * @author Patrick Lafleur
 */
@Entity
@Table(name = "TRANSACTIONAL_MESSAGE", uniqueConstraints = {})
public class TransactionalMessage extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "TRANSACTIONAL_MESSAGE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "TransactionalMessageSequence")
	@SequenceGenerator(name = "TransactionalMessageSequence", sequenceName = "TRANSACTIONAL_MESSAGE_SEQ", allocationSize = 5)
	private Long id;

	/** The message repository entry. */
	@ManyToOne(cascade = { }, fetch = FetchType.LAZY)
	@JoinColumn(name = "MESSAGE_REPOSITORY_ENTRY_ID", nullable = false, updatable = true)
	private MessageRepositoryEntry messageRepositoryEntry;

	/** The accepting timestamp. */
	@Column(name = "ACCEPTING_TS", length = 11)
	private Date acceptingDateTime;

	/** The accepting user id. */
	@Column(name = "ACCEPTING_USER_ID", length = 65)
	private String acceptingUserId;

	/** The underwriting message status code. */
	@Column(name = "UNDERWRITING_MESSAGE_STATUS_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.UnderwritingMessageStatusCodeEnum") })
	private UnderwritingMessageStatusCodeEnum underwritingMessageStatusCode;

	/** The context key number. */
	@Column(name = "CONTEXT_KEY_NBR", length = 50)
	private String contextKey;

	/** The transactional message desc. */
	@Column(name = "TRANSACTIONAL_MESSAGE_DESC", length = 150)
	private String transactionalMessageDescription;

	/** The transactional message elements. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "transactionalMessage")
	private Set<TransactionalMessageElement> transactionalMessageElements = new HashSet<TransactionalMessageElement>(0);

	/** The policy offer rating. */
	@ManyToOne(cascade = {}, fetch = FetchType.EAGER)
	@JoinColumn(name = "POLICY_OFFER_RATING_ID", nullable = true, updatable = true)
	private PolicyOfferRating policyOfferRating = null;
	
	@ManyToOne(cascade = {}, fetch = FetchType.EAGER)
	@JoinColumn(name = "INSURANCE_RISK_OFFER_ID", nullable = true, updatable = true)
	private InsuranceRiskOffer insuranceRiskOffer = null;

	/**
	 * Instantiates a new transactional message.
	 */
	public TransactionalMessage() {
	}

	/**
	 * Instantiates a new transactional message.
	 * 
	 * @param aMessageRepositoryEntry the a message repository entry
	 */
	public TransactionalMessage(MessageRepositoryEntry aMessageRepositoryEntry) {
		setMessageRepositoryEntry(aMessageRepositoryEntry);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the message repository entry.
	 * 
	 * @return the message repository entry
	 */
	public MessageRepositoryEntry getMessageRepositoryEntry() {
		return this.messageRepositoryEntry;
	}

	/**
	 * Sets the message repository entry.
	 * 
	 * @param aMessageRepositoryEntry the new message repository entry
	 */
	public void setMessageRepositoryEntry(MessageRepositoryEntry aMessageRepositoryEntry) {
		this.messageRepositoryEntry = aMessageRepositoryEntry;
	}

	/**
	 * Gets the accepting timestamp.
	 * 
	 * @return the accepting timestamp
	 */
	public Date getAcceptingDateTime() {
		return this.acceptingDateTime;
	}

	/**
	 * Sets the accepting timestamp.
	 * 
	 * @param aAcceptingTimestamp the new accepting timestamp
	 */
	public void setAcceptingDateTime(Date aAcceptingTimestamp) {
		this.acceptingDateTime = aAcceptingTimestamp;
	}

	/**
	 * Gets the accepting user id.
	 * 
	 * @return the accepting user id
	 */
	public String getAcceptingUserId() {
		return this.acceptingUserId;
	}

	/**
	 * Sets the accepting user id.
	 * 
	 * @param aAcceptingUserId the new accepting user id
	 */
	public void setAcceptingUserId(String aAcceptingUserId) {
		this.acceptingUserId = aAcceptingUserId;
	}

	/**
	 * Gets the underwriting message status code.
	 * 
	 * @return the underwriting message status code
	 */
	public UnderwritingMessageStatusCodeEnum getUnderwritingMessageStatusCode() {
		return this.underwritingMessageStatusCode;
	}

	/**
	 * Sets the underwriting message status code.
	 * 
	 * @param aUnderwritingMessageStatusCode the new underwriting message status code
	 */
	public void setUnderwritingMessageStatusCode(UnderwritingMessageStatusCodeEnum aUnderwritingMessageStatusCode) {
		this.underwritingMessageStatusCode = aUnderwritingMessageStatusCode;
	}

	/**
	 * Gets the context key number.
	 * 
	 * @return the context key number
	 */
	public String getContextKey() {
		return this.contextKey;
	}

	/**
	 * Sets the context key number.
	 * 
	 * @param aContextKeyNumber the new context key number
	 */
	public void setContextKey(String aContextKeyNumber) {
		this.contextKey = aContextKeyNumber;
	}

	/**
	 * Gets the transactional message desc.
	 * 
	 * @return the transactional message desc
	 */
	public String getTransactionalMessageDescription() {
		return this.transactionalMessageDescription;
	}

	/**
	 * Sets the transactional message desc.
	 * 
	 * @param aTransactionalMessageDesc the new transactional message desc
	 */
	public void setTransactionalMessageDescription(String aTransactionalMessageDesc) {
		this.transactionalMessageDescription = aTransactionalMessageDesc;
	}

	/**
	 * Gets the transactional message elements.
	 * 
	 * @return the transactional message elements
	 */
	@XmlElementWrapper(name="transactionalMessageElements")
	@XmlElement(name="transactionalMessageElement")
	public Set<TransactionalMessageElement> getTransactionalMessageElements() {
		return Collections.unmodifiableSet(this.transactionalMessageElements);
	}

	/**
	 * Sets the transactional message elements.
	 * 
	 * @param aTransactionalMessageElements the new transactional message elements
	 */
	protected void setTransactionalMessageElements(Set<TransactionalMessageElement> aTransactionalMessageElements) {
		this.transactionalMessageElements = aTransactionalMessageElements;
	}

	/**
	 * Adds the transactional message element.
	 * 
	 * @param element the element
	 */
	public void addTransactionalMessageElement(TransactionalMessageElement element) {
		AssociationsHelper.updateOneToManyFields(this, "transactionalMessageElements", element, "transactionalMessage");
	}

	/**
	 * Removes the transactional message element.
	 * 
	 * @param element the element
	 */
	public void removeTransactionalMessageElement(TransactionalMessageElement element) {
		AssociationsHelper.updateOneToManyFields(null, "transactionalMessageElements", element, "transactionalMessage");
	}

	/**
	 * Gets the policy offer rating.
	 * 
	 * @return the policy offer rating
	 */
	@XmlTransient
	public PolicyOfferRating getPolicyOfferRating() {
		return this.policyOfferRating;
	}

	/**
	 * Sets the policy offer rating.
	 * 
	 * @param aPolicyOfferRating the new policy offer rating
	 */
	public void setPolicyOfferRating(PolicyOfferRating aPolicyOfferRating) {
		AssociationsHelper
				.updateOneToManyFields(aPolicyOfferRating, "transactionalMessages", this, "policyOfferRating");
	}

	@XmlTransient
	public InsuranceRiskOffer getInsuranceRiskOffer() {
		return this.insuranceRiskOffer;
	}

	public void setInsuranceRiskOffer(InsuranceRiskOffer insuranceRiskOffer) {
		AssociationsHelper
		.updateOneToManyFields(insuranceRiskOffer, "transactionalMessages", this, "insuranceRiskOffer");
	}

}
