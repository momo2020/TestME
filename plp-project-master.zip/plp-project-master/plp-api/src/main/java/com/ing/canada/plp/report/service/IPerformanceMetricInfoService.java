package com.ing.canada.plp.report.service;

import java.util.Date;
import java.util.List;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;
import com.ing.canada.plp.report.performancemetric.PerformanceMetricInfo;

public interface IPerformanceMetricInfoService {
	
	/**
	 * Find all the performance metric info 
	 * 
	 * BR5828  Items Displayed per Regional Access: 
	 * 
	 * @param aDateFrom
	 * @param aDateTo
	 * @param aQuoteSource
	 * @param aProvinceCode
	 * @param aSubBrokerCompanyNumber
	 * @param aManufacturerCompanyCode
	 * @return list of performance metric list info
	 */
	List<PerformanceMetricInfo> getPerformanceMetricListSP(Date aDateFrom, Date aDateTo, String aQuoteSource,ProvinceCodeEnum aProvinceCode, String aSubBrokerCompanyNumber, ManufacturerCompanyCodeEnum aManufacturerCompanyCode);	

}