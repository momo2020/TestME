/**
 * 
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author plafleur
 * 
 */
public enum DrivingRecordPrTermCodeEnum {

	ZERO("00"), ONE("01"), TWO("02"), THREE("03"), FOUR("04"), FIVE("05"), SIX("06"), SEVEN("07"), NINE("09"), TEN("10");

	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(DrivingRecordPrTermCodeEnum.class);

	/**
	 * Instantiates a new driving record pr term code enum.
	 * 
	 * @param aCode the a code
	 */
	private DrivingRecordPrTermCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the driving record pr term code enum
	 */
	public static DrivingRecordPrTermCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (DrivingRecordPrTermCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}

}
