package com.ing.canada.plp.lock;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class InsurancePolicyLockToken implements Serializable {

	private static final Log log = LogFactory.getLog(InsurancePolicyLockToken.class);

	private static final long serialVersionUID = 0L;

	private Class<?> entityClass = null;

	private Long id = null;

	private Date version = null;

	/**
	 * Creates a new lock object.
	 * 
	 * @param newKlazz the type of object to be locked
	 * @param newId the id of the object to be locked
	 * @param newVersion the version of the object to be locked
	 */
	public InsurancePolicyLockToken(Class<?> newKlazz, Long newId, Date newVersion) {
		this.entityClass = newKlazz;
		this.id = newId;
		this.version = newVersion;

		log.trace(" OPTIMISTIC LOCK : creates new lock token \n" + "id=" + this.id + "\n" + "version=" + this.version);
	}

	/**
	 * Clones an existing lock. The original lock object can be modified without affecting the clone.
	 * 
	 * @param source the lock to be cloned
	 */
	public InsurancePolicyLockToken(InsurancePolicyLockToken source) {
		this(source.entityClass, source.id, source.version);

		log.trace(" OPTIMISTIC LOCK : clone existing lock ");
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	/**
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((this.id == null) ? 0 : this.id.hashCode());
		result = PRIME * result + ((this.entityClass == null) ? 0 : this.entityClass.getName().hashCode());
		return result;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {

		if (this == obj) {
			return true;
		}

		if (obj == null) {
			return false;
		}

		if (getClass() != obj.getClass()) {
			return false;
		}

		final InsurancePolicyLockToken other = (InsurancePolicyLockToken) obj;

		if (this.id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!this.id.equals(other.id)) {
			return false;
		}

		if (this.entityClass == null && other.entityClass != null) {
			return false;
		} else if (this.entityClass != null && other.entityClass == null) {
			return false;
		} else if (this.entityClass == null && other.entityClass == null) {
			return true;
		}
		if (!this.entityClass.getName().equals(other.entityClass.getName())) {
			return false;
		}
		return true;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return this.id;
	}

	/**
	 * @param anId the id to set
	 */
	protected void setId(Long anId) {
		this.id = anId;
	}

	/**
	 * @return the entityClass
	 */
	public Class<?> getEntityClass() {
		return this.entityClass;
	}

	/**
	 * @param entityClass the entityClass to set
	 */
	protected void setEntityClass(Class<?> klazz) {
		this.entityClass = klazz;
	}

	/**
	 * @return the version
	 */
	public Date getVersion() {
		return this.version;
	}

	/**
	 * @param aVersion the version to set
	 */
	public void setVersion(Date aVersion) {
		log.trace(" OPTIMISTIC LOCK : set NEW lock timestamp " + "id=" + this.id + "\n" + "old version=" + this.version);
		this.version = aVersion;
		log.trace(" OPTIMISTIC LOCK : set NEW lock timestamp " + "id=" + this.id + "\n" + "new version=" + this.version);
	}

	/**
	 * Checks if is same version.
	 * 
	 * @param token the token
	 * @return true, if is same version
	 */
	public boolean isSameVersion(InsurancePolicyLockToken token) {
		// both tstamps are null?
		if (this.version == null && token.version == null) {
			log.trace("verifying if the object group was modified since the lock was acquired: " + token);
			// checks it's the same object group (entityClass && id matches)
			boolean same = this.equals(token);
			log.trace(same ? "the object group was not modified"
					: "the object group WAS modified (concurrency occured)");
			return same;
		}

		if (this.version == null || token.version == null) {
			log.trace("the object group was modified, one of the acquired lock or the current lock version is null");
			return false;
		}

		// checks it's the same object group (entityClass && id matches)
		boolean same = this.equals(token)
		// are they the same version?
				&& this.version.equals(token.version);
		log.trace("is the acquired lock still valid? " + (same ? "YES" : "NO (concurrency occured)"));
		return same;

	}

}
