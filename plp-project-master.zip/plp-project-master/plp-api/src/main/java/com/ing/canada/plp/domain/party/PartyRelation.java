/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.party;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * PartyRelation entity.
 * 
 * @author Mahmoud Mounir
 * 
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "PARTY_RELATION", uniqueConstraints = { @UniqueConstraint(columnNames = { "PARTY_RELATION_ID" }) })
public class PartyRelation extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "PARTY_RELATION_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "PartyRelationSequence")
	@SequenceGenerator(name = "PartyRelationSequence", sequenceName = "PARTY_RELATION_SEQ", allocationSize = 5)
	private Long id;


	/** The party from. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "PARTY_FROM_ID", nullable = false, updatable = true)
	private Party partyFrom;
	
	/** The party to. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "PARTY_TO_ID", nullable = false, updatable = true)
	private Party partyTo;

	/** The nature party from. */
	@Column(name = "NATURE_FROM_CD", length = 3)
	private String natureFrom;
	
	/** The nature party to. */
	@Column(name = "NATURE_TO_CD", length = 3)
	private String natureTo;

	/**
	 * Instantiates a new party relation.
	 */
	public PartyRelation() {
		// noarg constructor
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	@XmlTransient // parent
	public Party getPartyFrom() {
		return partyFrom;
	}

	public void setPartyFrom(Party partyFrom) {
		this.partyFrom = partyFrom;
	}

	@XmlTransient // parent
	public Party getPartyTo() {
		return partyTo;
	}

	public void setPartyTo(Party partyTo) {
		this.partyTo = partyTo;
	}

	public String getNatureFrom() {
		return natureFrom;
	}

	public void setNatureFrom(String natureFrom) {
		this.natureFrom = natureFrom;
	}

	public String getNatureTo() {
		return natureTo;
	}

	public void setNatureTo(String natureTo) {
		this.natureTo = natureTo;
	}
}
