/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insurancepolicy;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.OptimisticLock;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.ManufacturingContext;
import com.ing.canada.plp.domain.enums.AgreementFollowUpStatusEnum;
import com.ing.canada.plp.domain.enums.AgreementStatusCodeEnum;
import com.ing.canada.plp.domain.enums.AgreementTypeCodeEnum;
import com.ing.canada.plp.domain.enums.ApplicationModeEnum;
import com.ing.canada.plp.domain.enums.ExternalSystemOriginCodeEnum;
import com.ing.canada.plp.domain.enums.LineOfBusinessCodeEnum;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.RatingBasisCodeEnum;
import com.ing.canada.plp.domain.helper.BaseEntityHelper;
import com.ing.canada.plp.domain.policyemailtoken.PolicyEmailToken;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;
import com.ing.canada.plp.domain.policyversion.RelatedInsurancePolicy;
import com.ing.canada.plp.domain.subbrokerassignment.SubBrokerAssignment;
import com.ing.canada.plp.domain.usertype.BaseEntity;
import com.ing.canada.plp.lock.InsurancePolicyLockToken;
import com.ing.canada.plp.lock.InsurancePolicyLockable;

/**
 * InsurancePolicy entity.
 * 
 * @author Patrick Lafleur
 * 
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "INSURANCE_POLICY", uniqueConstraints = { @UniqueConstraint(columnNames = { "AGREEMENT_NBR" }) })
@NamedQueries({
		@NamedQuery(name = "InsurancePolicy.findAllInsurancePolicyForCifId", query = "select DISTINCT ip from InsurancePolicy ip inner join ip.policyVersions pv where ip.agreementType = :agreementTypeCode and pv.id in (select max(subpv.id) from PolicyVersion subpv inner join subpv.parties subp where subp.cifClientId = :cifId group by subpv.insurancePolicy) order by ip.id"),
		@NamedQuery(name = "InsurancePolicy.findRatedPolicies", query = "select ip from InsurancePolicy ip where trunc(last_locked_ts) = trunc(:dateToTest) and ip.agreementType = :quotation and ip in (select pv.insurancePolicy from PolicyVersion pv where pv.insurancePolicy = ip and pv IN (select max(pv1) from PolicyVersion pv1 WHERE pv1.insurancePolicy = ip ) and pv.businessTransaction in (select bt from BusinessTransaction bt where bt = pv.businessTransaction and bt.transactionStatus in (:bind, :offer, :submitted, :interventionWithPremium))) order by ip.agreementNumber"),
		@NamedQuery(name = "InsurancePolicy.findAllUnexpiredInsurancePolicyForTamUniqueId", query = "select ip from InsurancePolicy ip where ip.agreementType = 'QUO' and ip.tamUniqueId = :tamUniqueId and ip.quotationValidityExpiryDate > sysdate"),
		@NamedQuery(name = "InsurancePolicy.findAllUnexpiredInsurancePolicyForEmail", query = "select ip from InsurancePolicy ip, PolicyVersion pv, Party pa where ip.agreementType = 'QUO' and pv.insurancePolicy = ip and pa.policyVersion = pv and pa.emailAddress = :email and ip.quotationValidityExpiryDate > sysdate"),
		@NamedQuery(name = "InsurancePolicy.findInsurancePolicyById", query = "select ip from InsurancePolicy ip where ip.id=:insurancePolicyId") })
@NamedNativeQueries({
		@NamedNativeQuery(name = "InsurancePolicy.findAllUnexpiredInsurancePolicy", query = "SELECT ip.* "
				+ " FROM plpadmin.insurance_policy ip, plpadmin.policy_version pv, plpadmin.party pa"
				+ " WHERE ip.agreement_type_cd = 'QUO' AND pv.insurance_policy_id = ip.insurance_policy_id"
				+ " AND pa.policy_version_id = pv.policy_version_id AND ip.quotation_validity_expiry_dt > sysdate"
				+ " AND pa.email_address_txt = :email"
				+ " AND exists(SELECT * FROM plpadmin.sub_broker_assignment sba, cifadmin.sub_brokers sb, CIFADMIN.broker_infos bri"
				+ " WHERE sba.insurance_policy_id = ip.insurance_policy_id and sb.sub_broker = sba.cif_sub_broker_id AND bri.subroker_nbr = sb.sub_broker_number"
				+ " AND bri.master_owner_nbr IN (:listMasterOwnerNbr))", resultClass = InsurancePolicy.class), 
		
		@NamedNativeQuery(name = "InsurancePolicy.findAllInsurancePolicyForRetrieveWEBBK", query = "SELECT ip.* "
				+ " FROM plpadmin.insurance_policy ip, plpadmin.policy_version pv, plpadmin.party pa, plpadmin.sub_broker_assignment sba, cifadmin.sub_brokers sb, cifadmin.broker_infos bi"
				+ " WHERE ip.agreement_type_cd = 'QUO'"
				+ " AND ip.application_mode_cd = 'R'"
				+ " AND ip.external_system_origin_cd = 'WEBBK'"		
				+ " AND pa.email_address_txt = :email"
				+ " AND pa.last_name_txt = :lastName"
				+ " AND pa.birth_dt = :birthDate"
				+ " AND bi.master_owner_nbr = :masterOwnerNbr"
				+ " AND pv.insurance_policy_id = ip.insurance_policy_id"
				+ " AND pa.policy_version_id = pv.policy_version_id"
				+ " AND ip.insurance_policy_id = sba.insurance_policy_id"
				+ " AND sba.cif_sub_broker_id = sb.sub_broker"
				+ " AND sb.sub_broker_number = bi.subroker_nbr"
				+ " ORDER BY ip.LAST_UPDATE_TS desc", resultClass = InsurancePolicy.class),
				
		@NamedNativeQuery(name = "InsurancePolicy.findAllInsurancePolicyForRetrieveINTACT", query = "SELECT ip.* "
				+ " FROM plpadmin.insurance_policy ip, plpadmin.policy_version pv, plpadmin.party pa "
				+ " WHERE ip.agreement_type_cd = 'QUO'"
				+ " AND ip.application_mode_cd = 'R'"
				+ " AND ip.external_system_origin_cd is null"		
				+ " AND pa.email_address_txt = :email"
				+ " AND pa.last_name_txt = :lastName"
				+ " AND pa.birth_dt = :birthDate"
				+ " AND pv.insurance_policy_id = ip.insurance_policy_id"
				+ " AND pa.policy_version_id = pv.policy_version_id"
				+ " ORDER BY ip.LAST_UPDATE_TS desc", resultClass = InsurancePolicy.class), 
				
		@NamedNativeQuery(name = "InsurancePolicy.findAllInsurancePolicyForEmail", query = "SELECT ip.* "
				+ " FROM plpadmin.insurance_policy ip, plpadmin.policy_version pv, plpadmin.party pa "
				+ " WHERE ip.agreement_type_cd = 'QUO'"
				+ " AND ip.application_mode_cd = 'R'"
				+ " AND pa.email_address_txt = :email"
				+ " AND pv.insurance_policy_id = ip.insurance_policy_id"
				+ " AND pa.policy_version_id = pv.policy_version_id"
				+ " ORDER BY ip.LAST_UPDATE_TS desc", resultClass = InsurancePolicy.class),
				
				
		@NamedNativeQuery(name = "InsurancePolicy.findAllInsurancePolicyForEmailWEBBK", query = "SELECT ip.* "
				+ " FROM plpadmin.insurance_policy ip, plpadmin.policy_version pv, plpadmin.party pa, plpadmin.sub_broker_assignment sba, cifadmin.sub_brokers sb, cifadmin.broker_infos bi"
				+ " WHERE ip.agreement_type_cd = 'QUO'"
				+ " AND ip.application_mode_cd = 'R'"
				+ " AND ip.external_system_origin_cd = 'WEBBK'"		
				+ " AND pa.email_address_txt = :email"
				+ " AND bi.master_owner_nbr = :masterOwnerNbr"
				+ " AND pv.insurance_policy_id = ip.insurance_policy_id"
				+ " AND pa.policy_version_id = pv.policy_version_id"
				+ " AND ip.insurance_policy_id = sba.insurance_policy_id"
				+ " AND sba.cif_sub_broker_id = sb.sub_broker"
				+ " AND sb.sub_broker_number = bi.subroker_nbr"
				+ " ORDER BY ip.LAST_UPDATE_TS desc", resultClass = InsurancePolicy.class), 
		
				
		@NamedNativeQuery(name = "InsurancePolicy.findAllInsurancePolicyForEmailINTACT", query = "SELECT ip.* "
				+ " FROM plpadmin.insurance_policy ip, plpadmin.policy_version pv, plpadmin.party pa "
				+ " WHERE ip.agreement_type_cd = 'QUO'"
				+ " AND ip.application_mode_cd = 'R'"
				+ " AND ip.external_system_origin_cd is null"		
				+ " AND pa.email_address_txt = :email"
				+ " AND pv.insurance_policy_id = ip.insurance_policy_id"
				+ " AND pa.policy_version_id = pv.policy_version_id"
				+ " ORDER BY ip.LAST_UPDATE_TS desc", resultClass = InsurancePolicy.class)
				

})

public class InsurancePolicy extends BaseEntity implements InsurancePolicyLockable {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "INSURANCE_POLICY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "InsurancePolicySequence")
	@SequenceGenerator(name = "InsurancePolicySequence", sequenceName = "INSURANCE_POLICY_SEQ", allocationSize = 5)
	private Long id;
	
	/** The uuId. */
	@Column(name = "UUID", unique = true, nullable = true, length = 36)
	private String uuId;

	/** The manufacturing context. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "MANUFACTURING_CONTEXT_ID", nullable = false, updatable = true)
	private ManufacturingContext manufacturingContext;

	/** The manufacturer company code. */
	@Column(name = "MANUFACTURER_COMPANY_CD", nullable = true, length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum") })
	private ManufacturerCompanyCodeEnum manufacturerCompany;

	/** The related insurance policy. */
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "REPLACING_INSURANCE_POLICY_ID", updatable = true)
	private RelatedInsurancePolicy relatedInsurancePolicy;

	/** The agreement type. */
	@Column(name = "AGREEMENT_TYPE_CD", nullable = false, length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.AgreementTypeCodeEnum") })
	private AgreementTypeCodeEnum agreementType;

	/** The agreement number. */
	@Column(name = "AGREEMENT_NBR", unique = true, nullable = true, length = 25)
	private String agreementNumber;

	/** The agreement legacy number. */
	@OptimisticLock(excluded = true)
	@Column(name = "AGREEMENT_LEGACY_NBR", length = 25)
	private String agreementLegacyNumber;

	/** The agreement status. */
	@Column(name = "AGREEMENT_STATUS_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.AgreementStatusCodeEnum") })
	private AgreementStatusCodeEnum agreementStatus;

	/** The original inception date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "ORIGINAL_INCEPTION_DT", length = 7)
	private Date originalInceptionDate;

	/**
	 * The quotation validity expiry date. Contains the date at which the quotation expires, this may change from 90
	 * days to 30 days in the future, when it will Intact must must honour the given guarantees.
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "QUOTATION_VALIDITY_EXPIRY_DT", length = 7)
	private Date quotationValidityExpiryDate;

	/** The spf code. */
	@Column(name = "SPF_CD", length = 1)
	private String spfCode;

	/** The rating basis. */
	@Column(name = "RATING_BASIS_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.RatingBasisCodeEnum") })
	private RatingBasisCodeEnum ratingBasis;

	/** The line of business. */
	@Column(name = "LINE_OF_BUSINESS_CD", nullable = false, length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.LineOfBusinessCodeEnum") })
	private LineOfBusinessCodeEnum lineOfBusiness;

	/** The test data. */
	@Column(name = "TEST_DATA_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean testDataIndicator;

	/** The last generated driver sequence. */
	@Column(name = "LAST_GENERATED_DRIVER_SEQ", precision = 4, scale = 0)
	private Short lastGeneratedDriverSequence;

	/** The last generated additional interest sequence. */
	@Column(name = "LAST_GENERATED_ADDL_INT_SEQ", precision = 4, scale = 0)
	private Short lastGeneratedAdditionalInterestSequence;

	/** The last generated insurance risk sequence. */
	@Column(name = "LAST_GENERATED_INS_RISK_SEQ", precision = 4, scale = 0)
	private Short lastGeneratedInsuranceRiskSequence;

	/** The last generated conviction sequence. */
	@Column(name = "LAST_GENERATED_CONVICTION_SEQ", precision = 4, scale = 0)
	private Short lastGeneratedConvictionSequence;

	/** The policy versions. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "insurancePolicy")
	@OrderBy("auditTrail.createTimestamp DESC")
	private Set<PolicyVersion> policyVersions = new HashSet<PolicyVersion>(0);

	/** The last update timestamp. */
	@Column(name = "LAST_UPDATE_TS", nullable = false, length = 11)
	private Timestamp lastUpdateTimestamp;

	/** The last locked timestamp. */
	@Version
	@Column(name = "LAST_LOCKED_TS", nullable = true, length = 11)
	private Timestamp lastLockedTimestamp;

	/** The credit score info client confirmation indicator */
	@Column(name = "CREDIT_SCR_INF_CLIENT_CONF_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean creditScoreInfoClientConfirmationInd;

	/** The tam unique identifier. */
	@Column(name = "TAM_UNIQUE_ID", nullable = true, length = 12)
	private Long tamUniqueId;

	/** The insurancePolicyNotes. */
	@OptimisticLock(excluded = true)
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "insurancePolicy")
	@OrderBy("auditTrail.createTimestamp ASC")
	private Set<InsurancePolicyNote> insurancePolicyNotes = new TreeSet<InsurancePolicyNote>();
	
	/** The policyEmailTokens. */
	@OptimisticLock(excluded = true)
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "insurancePolicy")
	private Set<PolicyEmailToken> policyEmailTokens = new TreeSet<PolicyEmailToken>();

	/** The agreement follow up status. */
	@OptimisticLock(excluded = true)
	@Column(name = "AGREEMENT_FOLLOW_UP_STATUS_CD", nullable = true, length = 15)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.AgreementFollowUpStatusEnum") })
	private AgreementFollowUpStatusEnum agreementFollowUpStatus;

	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "insurancePolicy")
	@OrderBy("auditTrail.createTimestamp DESC")
	private Set<SubBrokerAssignment> subBrokerAssignments = new HashSet<SubBrokerAssignment>(0);

	/** The external system origin code. */
	@Column(name = "EXTERNAL_SYSTEM_ORIGIN_CD", nullable = true, length = 6)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ExternalSystemOriginCodeEnum") })
	private ExternalSystemOriginCodeEnum externalSystemOrigin;

	/** The last generated conviction sequence. */
	@Column(name = "QUO_VALD_PRD_IN_DAYS_QTY", precision = 4, scale = 0)
	private Short quoteValidityPeriodInDays;

	/** The application mode code . */
	@Column(name = "APPLICATION_MODE_CD", nullable = true, length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ApplicationModeEnum") })
	private ApplicationModeEnum applicationMode;

	/**
	 * Instantiates a new insurance policy.
	 */
	public InsurancePolicy() {
		this.lastUpdateTimestamp = new Timestamp(System.currentTimeMillis());
	}

	/**
	 * Instantiates a new insurance policy.
	 * 
	 * @param aManufacturingContext the a manufacturing context
	 * @param agreementTypeCode the agreement type code
	 * @param aAgreementNumber the a agreement number
	 * @param lineOfBusinessCode the line of business code
	 */
	public InsurancePolicy(ManufacturingContext aManufacturingContext, AgreementTypeCodeEnum agreementTypeCode,
			String aAgreementNumber, LineOfBusinessCodeEnum lineOfBusinessCode) {
		setManufacturingContext(aManufacturingContext);
		setAgreementType(agreementTypeCode);
		setAgreementNumber(aAgreementNumber);
		setLineOfBusiness(lineOfBusinessCode);
	}

	public InsurancePolicy(String agreementNumber) {
		this.setAgreementNumber(agreementNumber);
	}

	/**
	 * @see com.ing.canada.plp.lock.InsurancePolicyLockable#getInsurancePolicyLockToken()
	 */
	@Override
	public InsurancePolicyLockToken getInsurancePolicyLockToken() {
		return new InsurancePolicyLockToken(this.getClass(), this.getId(), this.getLastLockedTimestamp());
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the manufacturing context.
	 * 
	 * @return the manufacturing context
	 */
	public ManufacturingContext getManufacturingContext() {
		return this.manufacturingContext;
	}

	/**
	 * Sets the manufacturing context.
	 * 
	 * @param aManufacturingContext the new manufacturing context
	 */
	public void setManufacturingContext(ManufacturingContext aManufacturingContext) {
		this.manufacturingContext = aManufacturingContext;
	}

	/**
	 * Gets the related insurance policy.
	 * 
	 * @return the related insurance policy
	 */
	public RelatedInsurancePolicy getRelatedInsurancePolicy() {
		return this.relatedInsurancePolicy;
	}

	/**
	 * Sets the related insurance policy.
	 * 
	 * @param aRelatedInsurancePolicy the new related insurance policy
	 */
	public void setRelatedInsurancePolicy(RelatedInsurancePolicy aRelatedInsurancePolicy) {
		AssociationsHelper.updateOneToManyFields(aRelatedInsurancePolicy, "insurancePolicies", this,
				"relatedInsurancePolicy");
	}

	/**
	 * Gets the last update timestamp.
	 * 
	 * @return the last update timestamp
	 */
	@XmlTransient
	public Timestamp getLastUpdateTimestamp() {
		return this.lastUpdateTimestamp;
	}

	/**
	 * Sets the last update timestamp.
	 * 
	 * @param aLastUpdateTimestamp the new last update timestamp
	 */
	public void setLastUpdateTimestamp(Timestamp aLastUpdateTimestamp) {
		this.lastUpdateTimestamp = aLastUpdateTimestamp;
	}

	/**
	 * Gets the agreement type.
	 * 
	 * @return the agreement type
	 */
	public AgreementTypeCodeEnum getAgreementType() {
		return this.agreementType;
	}

	/**
	 * Sets the agreement type.
	 * 
	 * @param agreementTypeCode the new agreement type
	 */
	public void setAgreementType(AgreementTypeCodeEnum agreementTypeCode) {
		this.agreementType = agreementTypeCode;
	}

	/**
	 * Gets the agreement number.
	 * 
	 * @return the agreement number
	 */
	public String getAgreementNumber() {
		return this.agreementNumber;
	}

	/**
	 * Sets the agreement number.
	 * 
	 * @param aAgreementNumber the new agreement number
	 */
	public void setAgreementNumber(String aAgreementNumber) {
		this.agreementNumber = aAgreementNumber;
	}

	/**
	 * Gets the agreement legacy number.
	 * 
	 * @return the agreement legacy number
	 */
	public String getAgreementLegacyNumber() {
		return this.agreementLegacyNumber;
	}

	/**
	 * Sets the agreement legacy number.
	 * 
	 * @param aAgreementLegacyNumber the new agreement legacy number
	 */
	public void setAgreementLegacyNumber(String aAgreementLegacyNumber) {
		this.agreementLegacyNumber = aAgreementLegacyNumber;
	}

	/**
	 * Gets the agreement status.
	 * 
	 * @return the agreement status
	 */
	public AgreementStatusCodeEnum getAgreementStatus() {
		return this.agreementStatus;
	}

	/**
	 * Sets the agreement status.
	 * 
	 * @param agreementStatusCode the new agreement status
	 */
	public void setAgreementStatus(AgreementStatusCodeEnum agreementStatusCode) {
		this.agreementStatus = agreementStatusCode;
	}

	/**
	 * Gets the original inception date.
	 * 
	 * @return the original inception date
	 */
	public Date getOriginalInceptionDate() {
		return this.originalInceptionDate;
	}

	/**
	 * Sets the original inception date.
	 * 
	 * @param aOriginalInceptionDate the new original inception date
	 */
	public void setOriginalInceptionDate(Date aOriginalInceptionDate) {
		this.originalInceptionDate = aOriginalInceptionDate;
	}

	/**
	 * Gets the spf code.
	 * 
	 * @return the spf code
	 */
	public String getSpfCode() {
		return this.spfCode;
	}

	/**
	 * Sets the spf code.
	 * 
	 * @param aSpfCode the new spf code
	 */
	public void setSpfCode(String aSpfCode) {
		this.spfCode = aSpfCode;
	}

	/**
	 * Gets the rating basis.
	 * 
	 * @return the rating basis
	 */
	public RatingBasisCodeEnum getRatingBasis() {
		return this.ratingBasis;
	}

	/**
	 * Sets the rating basis.
	 * 
	 * @param ratingBasisCode the new rating basis
	 */
	public void setRatingBasis(RatingBasisCodeEnum ratingBasisCode) {
		this.ratingBasis = ratingBasisCode;
	}

	/**
	 * Gets the line of business.
	 * 
	 * @return the line of business
	 */
	public LineOfBusinessCodeEnum getLineOfBusiness() {
		return this.lineOfBusiness;
	}

	/**
	 * Sets the line of business code.
	 * 
	 * @param lineOfBusinessCode the new line of business code
	 */
	public void setLineOfBusinessCode(LineOfBusinessCodeEnum lineOfBusinessCode) {
		this.lineOfBusiness = lineOfBusinessCode;
	}

	/**
	 * Gets the test data.
	 * 
	 * @return the test data
	 */
	public Boolean getTestDataIndicator() {
		return this.testDataIndicator;
	}

	/**
	 * Sets the test data.
	 * 
	 * @param aTestDataIndicator the new test data
	 */
	public void setTestDataIndicator(Boolean aTestDataIndicator) {
		this.testDataIndicator = aTestDataIndicator;
	}

	/**
	 * Gets the last generated driver sequence.
	 * 
	 * @return the last generated driver sequence
	 */
	public Short getLastGeneratedDriverSequence() {
		return this.lastGeneratedDriverSequence;
	}

	/**
	 * Sets the last generated driver sequence.
	 * 
	 * @param lastGeneratedDriverSeq the new last generated driver sequence
	 */
	public void setLastGeneratedDriverSequence(Short lastGeneratedDriverSeq) {
		this.lastGeneratedDriverSequence = lastGeneratedDriverSeq;
	}

	/**
	 * Gets the last generated additional interest sequence.
	 * 
	 * @return the last generated additional interest sequence
	 */
	public Short getLastGeneratedAdditionalInterestSequence() {
		return this.lastGeneratedAdditionalInterestSequence;
	}

	/**
	 * Sets the last generated additional interest sequence.
	 * 
	 * @param lastGeneratedAddlIntSeq the new last generated additional interest sequence
	 */
	public void setLastGeneratedAdditionalInterestSequence(Short lastGeneratedAddlIntSeq) {
		this.lastGeneratedAdditionalInterestSequence = lastGeneratedAddlIntSeq;
	}

	/**
	 * Gets the last generated insurance risk sequence.
	 * 
	 * @return the last generated insurance risk sequence
	 */
	public Short getLastGeneratedInsuranceRiskSequence() {
		return this.lastGeneratedInsuranceRiskSequence;
	}

	/**
	 * Sets the last generated insurance risk sequence.
	 * 
	 * @param lastGeneratedInsRiskSeq the new last generated insurance risk sequence
	 */
	public void setLastGeneratedInsuranceRiskSequence(Short lastGeneratedInsRiskSeq) {
		this.lastGeneratedInsuranceRiskSequence = lastGeneratedInsRiskSeq;
	}

	/**
	 * Gets the last generated conviction sequence.
	 * 
	 * @return the last generated conviction sequence
	 */
	public Short getLastGeneratedConvictionSequence() {
		return this.lastGeneratedConvictionSequence;
	}

	/**
	 * Sets the last generated conviction sequence.
	 * 
	 * @param lastGeneratedConvictionSeq the new last generated conviction sequence
	 */
	public void setLastGeneratedConvictionSequence(Short lastGeneratedConvictionSeq) {
		this.lastGeneratedConvictionSequence = lastGeneratedConvictionSeq;
	}

	/**
	 * Gets the policy versions.
	 * 
	 * @return the policy versions
	 */
	@XmlElementWrapper(name="policyVersions")
	@XmlElement(name="policyVersion")
	public Set<PolicyVersion> getPolicyVersions() {
		return Collections.unmodifiableSet(this.policyVersions);
	}

	/**
	 * Sets the policy versions.
	 * 
	 * @param aPolicyVersions the new policy versions
	 */
	protected void setPolicyVersions(Set<PolicyVersion> aPolicyVersions) {
		this.policyVersions = aPolicyVersions;
	}

	/**
	 * Adds the policy version.
	 * 
	 * @param pv the pv
	 */
	public void addPolicyVersion(com.ing.canada.plp.domain.policyversion.PolicyVersion pv) {
		AssociationsHelper.updateOneToManyFields(this, "policyVersions", pv, "insurancePolicy");
	}

	/**
	 * Removes the policy version.
	 * 
	 * @param pv the pv
	 */
	public void removePolicyVersion(com.ing.canada.plp.domain.policyversion.PolicyVersion pv) {
		AssociationsHelper.updateOneToManyFields(null, "policyVersions", pv, "insurancePolicy");
	}

	/**
	 * Gets the last locked timestamp.
	 * 
	 * @return the lastLockedTimestamp
	 */
	@XmlTransient
	public Timestamp getLastLockedTimestamp() {
		return this.lastLockedTimestamp;
	}

	/**
	 * Sets the last locked timestamp.
	 * 
	 * @param aLastLockedTimestamp the lastLockedTimestamp to set
	 */
	public void setLastLockedTimestamp(Timestamp aLastLockedTimestamp) {
		this.lastLockedTimestamp = aLastLockedTimestamp;
	}

	/**
	 * Sets the line of business.
	 * 
	 * @param aLineOfBusiness the lineOfBusiness to set
	 */
	public void setLineOfBusiness(LineOfBusinessCodeEnum aLineOfBusiness) {
		this.lineOfBusiness = aLineOfBusiness;
	}

	/**
	 * Gets the credit score info client confirmation ind.
	 * 
	 * @return the credit score info client confirmation ind
	 */
	public Boolean getCreditScoreInfoClientConfirmationInd() {
		return this.creditScoreInfoClientConfirmationInd;
	}

	/**
	 * Sets the credit score info client confirmation ind.
	 * 
	 * @param aCreditScoreInfoClientConfirmationInd the new credit score info client confirmation ind
	 */
	public void setCreditScoreInfoClientConfirmationInd(Boolean aCreditScoreInfoClientConfirmationInd) {
		this.creditScoreInfoClientConfirmationInd = aCreditScoreInfoClientConfirmationInd;
	}

	/**
	 * Gets the quotation validity expiry date.
	 * 
	 * @return the quotation validity expiry date
	 */
	public Date getQuotationValidityExpiryDate() {
		return this.quotationValidityExpiryDate;
	}

	/**
	 * Sets the quotation validity expiry date.
	 * 
	 * @param aQuotationValidityExpiryDate the new quotation validity expiry date
	 */
	public void setQuotationValidityExpiryDate(Date aQuotationValidityExpiryDate) {
		this.quotationValidityExpiryDate = aQuotationValidityExpiryDate;
	}

	/**
	 * Gets the insurance policy notes.
	 * 
	 * @return the insurance policy notes
	 */
	@XmlElementWrapper(name="insurancePolicyNotes")
	@XmlElement(name="insurancePolicyNote")
	public Set<InsurancePolicyNote> getInsurancePolicyNotes() {
		return Collections.unmodifiableSet(this.insurancePolicyNotes);
	}

	/**
	 * Sets the insurance policy notes.
	 * 
	 * @param insurancePolicyNotes the new insurance policy notes
	 */
	public void setInsurancePolicyNotes(Set<InsurancePolicyNote> aInsurancePolicyNotes) {
		this.insurancePolicyNotes = aInsurancePolicyNotes;
	}

	/**
	 * Adds the insurance policy notes.
	 * 
	 * @param insurancePolicyNote the insurance policy notes.
	 */
	public void addInsurancePolicyNote(InsurancePolicyNote insurancePolicyNote) {
		AssociationsHelper.updateOneToManyFields(this, "insurancePolicyNotes", insurancePolicyNote, "insurancePolicy");
	}

	/**
	 * Gets the latest insurance policy note.
	 * 
	 * @return the latest insurance policy note
	 */
	public InsurancePolicyNote getLatestInsurancePolicyNote() {
		if (this.insurancePolicyNotes.isEmpty()) {
			return null;
		}
		return (InsurancePolicyNote) BaseEntityHelper.findMostRecentCreateTimestamp(this.insurancePolicyNotes);
	}

	/**
	 * Removes the insurance policy notes.
	 * 
	 * @param insurancePolicyNote the insurance policy notes.
	 */
	public void removeInsurancePolicyNote(InsurancePolicyNote insurancePolicyNote) {
		AssociationsHelper.updateOneToManyFields(null, "insurancePolicyNotes", insurancePolicyNote, "insurancePolicy");
	}

	
	/**
	 * Gets the policy email tokens.
	 * 
	 * @return the policy email tokens
	 */
	@XmlElementWrapper(name="policyEmailTokens")
	@XmlElement(name="policyEmailToken")
	public Set<PolicyEmailToken> getPolicyEmailTokens() {
		return Collections.unmodifiableSet(this.policyEmailTokens);
	}

	/**
	 * Sets the policy email tokens.
	 * 
	 * @param policyEmailTokens
	 */
	public void setPolicyEmailTokens(Set<PolicyEmailToken> aPolicyEmailTokens) {
		this.policyEmailTokens = aPolicyEmailTokens;
	}

	/**
	 * Adds the policy email tokens.
	 * 
	 * @param policyEmailToken the policy email tokens.
	 */
	public void addPolicyEmailToken(PolicyEmailToken policyEmailToken) {
		AssociationsHelper.updateOneToManyFields(this, "policyEmailTokens", policyEmailToken, "insurancePolicy");
	}


	/**
	 * Removes the insurance policy notes.
	 * 
	 * @param insurancePolicyNote the insurance policy notes.
	 */
	public void removePolicyEmailToken(PolicyEmailToken policyEmailToken) {
		AssociationsHelper.updateOneToManyFields(null, "policyEmailTokens", policyEmailToken, "insurancePolicy");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * Gets the agreement follow up status.
	 * 
	 * @return the agreement follow up status
	 */
	public AgreementFollowUpStatusEnum getAgreementFollowUpStatus() {
		return this.agreementFollowUpStatus;
	}

	/**
	 * Sets the agreement follow up status.
	 * 
	 * @param agreementFollowUpStatus the new agreement follow up status
	 */
	public void setAgreementFollowUpStatus(AgreementFollowUpStatusEnum aAgreementFollowUpStatus) {
		this.agreementFollowUpStatus = aAgreementFollowUpStatus;
	}

	/**
	 * Gets the external system origin code.
	 * 
	 * @return the external system origin code.
	 */
	public ExternalSystemOriginCodeEnum getExternalSystemOrigin() {
		return this.externalSystemOrigin;
	}

	/**
	 * Sets the external system origin code.
	 * 
	 * @param externalSystemOrigin the new external system origin code.
	 */
	public void setExternalSystemOrigin(ExternalSystemOriginCodeEnum aExternalSystemOrigin) {
		this.externalSystemOrigin = aExternalSystemOrigin;
	}

	/**
	 * Gets the sub broker assignments.
	 * 
	 * @return the sub broker assignments
	 */
	@XmlElementWrapper(name="subBrokerAssignments")
	@XmlElement(name="subBrokerAssignment")
	public Set<SubBrokerAssignment> getSubBrokerAssignments() {
		return Collections.unmodifiableSet(this.subBrokerAssignments);
	}

	/**
	 * Sets the sub broker assignments.
	 * 
	 * @param subBrokerAssignments the new sub broker assignments
	 */
	public void setSubBrokerAssignments(Set<SubBrokerAssignment> aSubBrokerAssignments) {
		this.subBrokerAssignments = aSubBrokerAssignments;
	}

	/**
	 * Adds the sub broker assignment.
	 * 
	 * @param subBrokerAssignment the sub broker assignment
	 */
	public void addSubBrokerAssignment(SubBrokerAssignment aSubBrokerAssignment) {
		AssociationsHelper.updateOneToManyFields(this, "subBrokerAssignments", aSubBrokerAssignment, "insurancePolicy");
	}

	/**
	 * Removes the sub broker assignment.
	 * 
	 * @param subBrokerAssignment the sub broker assignment
	 */
	public void removeSubBrokerAssignment(SubBrokerAssignment aSubBrokerAssignment) {
		AssociationsHelper.updateOneToManyFields(null, "subBrokerAssignments", aSubBrokerAssignment, "insurancePolicy");
	}

	/**
	 * Gets the latest sub broker assignment.
	 * 
	 * @return the latest sub broker assignment
	 */
	public SubBrokerAssignment getLatestSubBrokerAssignment() {
		if (this.subBrokerAssignments.isEmpty()) {
			return null;
		}
		return (SubBrokerAssignment) BaseEntityHelper.findMostRecentCreateTimestamp(this.subBrokerAssignments);
	}

	/**
	 * Gets the tam unique id
	 * 
	 * @return tam unique id
	 */
	public Long getTamUniqueId() {
		return this.tamUniqueId;
	}

	/**
	 * Sets the tam unique id
	 * 
	 * @param tamUniqueId
	 */
	public void setTamUniqueId(Long aTamUniqueId) {
		this.tamUniqueId = aTamUniqueId;
	}

	/**
	 * Gets the manufacturer company.
	 * 
	 * @return the manufacturer company
	 */
	public ManufacturerCompanyCodeEnum getManufacturerCompany() {
		return this.manufacturerCompany;
	}

	/**
	 * Sets the manufacturer company.
	 * 
	 * @param manufacturerCompany
	 */
	public void setManufacturerCompany(ManufacturerCompanyCodeEnum aManufacturerCompany) {
		this.manufacturerCompany = aManufacturerCompany;
	}

	public Short getQuoteValidityPeriodInDays() {
		return this.quoteValidityPeriodInDays;
	}

	public void setQuoteValidityPeriodInDays(Short aQuoteValidityPeriodInDays) {
		this.quoteValidityPeriodInDays = aQuoteValidityPeriodInDays;
	}

	/**
	 * @return the applicationMode
	 */
	public ApplicationModeEnum getApplicationMode() {
		return this.applicationMode;
	}

	/**
	 * @param applicationMode the applicationMode to set
	 */
	public void setApplicationMode(ApplicationModeEnum applicationMode) {
		this.applicationMode = applicationMode;
	}
	
	
	/**
	 * @return uuId
	 */
	public String getUuId() {
		return uuId;
	}

	/**
	 * @param uuId the uuId to set
	 */
	public void setUuId(String uuId) {
		this.uuId = uuId;
	}
}
