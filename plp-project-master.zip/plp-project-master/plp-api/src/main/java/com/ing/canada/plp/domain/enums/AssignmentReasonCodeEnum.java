package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * 
 * The Enum AssignmentReasonCodeEnum
 * 
 * @author stephane elleingand
 */
public enum AssignmentReasonCodeEnum {

	BROKER_REORGANIZATION_STRUCTURE("BRK_REORG"), //
	BROKER_DISSATISFACTION("BRK_DISSATIS"), //
	BROKER_LOCATION("BRK_LOCATION"), //
	SYSTEM_DEFAULT_ASSIGNMENT("SYS_DEFAULT"), //
	EXISTING_CLIENT("EXIST_CLIENT"), //
	OTHER("OTHER");

	/** The code. */
	private String code = null;

	private AssignmentReasonCodeEnum(String aCode) {
		this.setCode(aCode);
	}

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Sets the code.
	 * 
	 * @param code the new code
	 */
	public void setCode(String aCode) {
		this.code = aCode;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the assignment reason code enum
	 */
	public static AssignmentReasonCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (AssignmentReasonCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);
	}

	/**
	 * Gets the description.
	 * 
	 * @return the description
	 */
	public String getDescription() {
		if (this.code.equals("BRK_REORG")) {
			return "Broker Reorganization structure";
		} else if (this.code.equals("BRK_DISSATIS")) {
			return "Broker Dissatisfaction";
		} else if (this.code.equals("BRK_LOCATION")) {
			return "Broker Location";
		} else if (this.code.equals("SYS_DEFAULT")) {
			return "System Default Assignment";
		} else if (this.code.equals("EXIST_CLIENT")) {
			return "Intact Existing Client";
		}

		return "Other";
	}

}
