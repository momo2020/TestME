/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum NatureOfClaimCodeEnum.
 */
public enum NatureOfClaimCodeEnum {

	AT_FAULT_ACCIDENT("AA"), //
	NOT_AT_FAULT_ACCIDENT("NA"), //
	AT_FAULT_ACCIDENT_FOR_50_PCT("AAF"), //
	AT_FAULT_ACCIDENT_WITH_THIRD_PARTY_LIABILITY_PAYOUT("AWP"), //
	SINGLE_VEHICLE_ACCIDENT_WITH_NO_DAMAGE_TO_A_THIRD_PARTYS_VEHICLE_OR_OBJECT("SWD"), //
	HIT_AND_RUN("HR"), //
	FIRE_VANDALISM("FV"), //
	WINDSHIELD_REPAIR("GR"), //
	WINDSHIELD_REPLACEMENT("GW"), //
	THEFT("TH"), //
	WINDSTORM_OR_HAIL("WN"), //
	INSURANCE_OF_PERSON("AP"), //
	ACCIDENT_BENEFITS("AB"), //
	BODILY_INJURY("BI"), //
	FIRE("FIR"), //
	VANDALISM("VAN"), //
	IMPACT_WITH_ANIMAL("IA"), //
	// Added for Intact Alberta
	STRUCK_OBJECT_VEHICLE("SOV"), //
	HIT_BY_DISOBEYING_DRIVER("HDS"), //
	STRUCK_PEDESTRIAN("SP"), //
	STRUCK_DISOBEYING_PEDESTRIAN("SPS"), //
	STRUCK_CYCLIST("SB"), //
	STRUCK_DISOBEYING_CYCLIST("SBS"), //
	REAR_ENDED_BY_VEHICLE("YWR"), //
	REAR_ENDED("YRV"), //
	BACKED_INTO_VEHICLE("BAV"), //
	BACKED_BY_VEHICLE("VBY"), //
	SINGLE_CAR_ACCIDENT("SCA"), //
	MULTI_CAR_ACCIDENT("WMA"), //
	OTHER_AT_FAULT_ACCIDENT("OAF"), //
	OTHER_PARTIALLY_AT_FAULT_ACCIDENT("OPA"), //
	OTHER_NOT_AT_FAULT_ACCIDENT("ONF"), //
	OTHER_NON_COLLISION_CLAIM("ONC");

	/**
	 * Instantiates a new nature of claim code enum.
	 * 
	 * @param aCode the a code
	 */
	private NatureOfClaimCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the nature of claim code enum
	 */
	public static NatureOfClaimCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (NatureOfClaimCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
	
	public static NatureOfClaimCodeEnum toCode(String value) {
		
		for (NatureOfClaimCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}
		}
		
		return null;
	}
}
