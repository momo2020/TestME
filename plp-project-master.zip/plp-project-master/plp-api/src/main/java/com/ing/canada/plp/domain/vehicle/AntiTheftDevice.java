/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.vehicle;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.ActionTakenCodeEnum;
import com.ing.canada.plp.domain.enums.DeviceCategoryCodeEnum;
import com.ing.canada.plp.domain.enums.DeviceModelCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * AntiTheftDevice entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "ANTI_THEFT_DEVICE", uniqueConstraints = {})
public class AntiTheftDevice extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "ANTI_THEFT_DEVICE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "AntiTheftDeviceSequence")
	@SequenceGenerator(name = "AntiTheftDeviceSequence", sequenceName = "ANTI_THEFT_DEVICE_SEQ", allocationSize = 5)
	private Long id;

	/** The vehicle. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_RISK_ID", nullable = false, updatable = true)
	private Vehicle vehicle;

	/** The device category code. */
	@Column(name = "DEVICE_CATEGORY_CD", nullable = false, length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.DeviceCategoryCodeEnum") })
	private DeviceCategoryCodeEnum deviceCategory;

	/** The device model code. */
	@Column(name = "DEVICE_MODEL_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.DeviceModelCodeEnum") })
	private DeviceModelCodeEnum deviceModel;
	
	/** The action taken. */
	@Column(name = "ACTION_TAKEN_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ActionTakenCodeEnum") })
	private ActionTakenCodeEnum actionTaken = null;

	/**
	 * Instantiates a new anti theft device.
	 */
	public AntiTheftDevice() {
		// noarg constructor
	}

	/**
	 * Instantiates a new anti theft device.
	 * 
	 * @param aDeviceCategoryCode the a device category code
	 * @param aDeviceModelCode the a device model code
	 */
	public AntiTheftDevice(Vehicle aVehicle, DeviceCategoryCodeEnum aDeviceCategoryCode, DeviceModelCodeEnum aDeviceModelCode) {
		setVehicle(aVehicle);
		setDeviceCategory(aDeviceCategoryCode);
		setDeviceModel(aDeviceModelCode);
	}
	
	/**
	 * Instantiates a new anti theft device.
	 * 
	 * @param aVehicle the vehicle
	 * @param aDeviceCategoryCode the device category code
	 * @param aDeviceModelCodeEnum the device model code
	 * @param aActionTaken the action taken on the anti theft
	 */
	public AntiTheftDevice(Vehicle aVehicle, DeviceCategoryCodeEnum aDeviceCategoryCode, DeviceModelCodeEnum aDeviceModelCode, ActionTakenCodeEnum aActionTaken){
		setVehicle(aVehicle);
		setDeviceCategory(aDeviceCategoryCode);
		setDeviceModel(aDeviceModelCode);
		setActionTaken(aActionTaken);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the vehicle.
	 * 
	 * @return the vehicle
	 */
	@XmlTransient // parent
	public Vehicle getVehicle() {
		return this.vehicle;
	}

	/**
	 * Sets the vehicle.
	 * 
	 * @param aVehicle the new vehicle
	 */
	public void setVehicle(Vehicle aVehicle) {
		AssociationsHelper.updateOneToManyFields(aVehicle, "antiTheftDevices", this, "vehicle");
	}

	/**
	 * Gets the device category code.
	 * 
	 * @return the device category code
	 */
	public DeviceCategoryCodeEnum getDeviceCategory() {
		return this.deviceCategory;
	}

	/**
	 * Sets the device category code.
	 * 
	 * @param aDeviceCategoryCode the new device category code
	 */
	public void setDeviceCategory(DeviceCategoryCodeEnum aDeviceCategoryCode) {
		this.deviceCategory = aDeviceCategoryCode;
	}

	/**
	 * Gets the device model code.
	 * 
	 * @return the device model code
	 */
	public DeviceModelCodeEnum getDeviceModel() {
		return this.deviceModel;
	}

	/**
	 * Sets the device model code.
	 * 
	 * @param aDeviceModelCode the new device model code
	 */
	public void setDeviceModel(DeviceModelCodeEnum aDeviceModelCode) {
		this.deviceModel = aDeviceModelCode;
	}
	
	/**
	 * Gets the action taken.
	 *
	 * @return the action taken
	 */
	public ActionTakenCodeEnum getActionTaken() {
		return this.actionTaken;
	}

	/**
	 * Sets the action taken.
	 *
	 * @param anActionTaken the new action taken
	 */
	public void setActionTaken(ActionTakenCodeEnum anActionTaken) {
		this.actionTaken = anActionTaken;
	}

}
