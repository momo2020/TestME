/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain;

import java.lang.reflect.Field;
import java.util.Collection;

import org.hibernate.proxy.HibernateProxy;

/*
 * Helper methods to manage bidirectionnal associations in the rich domain model.
 * 
 * It manages the following associations: <ul> <li>one to one</li> <li>one to many</li><li>many to one</li> </ul>
 * 
 * It injects the references in both association ends using the reflection API (even if fields are protected or
 * private).
 * 
 * @author plafleur
 * 
 * Modifications: May 1st, 2008 - Added better documentation on updateOneToOneFields and updateOneToManyFields
 * 
 */
/**
 * The Class AssociationsHelper.
 */
public final class AssociationsHelper {

	/**
	 * Instantiates a new associations helper.
	 */
	private AssociationsHelper() {
		// Default constructor
	}

	/**
	 * Updates both ends of a bidirectionnal one to one association.
	 * 
	 * Let's say we have a class InsuranceRisk that can be associated to a Vehicle. The association can be resumed as:
	 * one insurance risk can be associated to a single vehicle and that same vehicle is also associated to the
	 * insurance risk.
	 * 
	 * If we create the following objects: <code>
	 * 
	 * InsuranceRisk ir1 = new Vehicle(); 
	 * Vehicle v1 = new Vehicle();
	 * </code>
	 * 
	 * Then to attach them we should be able to call a setter on either side: <code>
	 * 
	 * ir1.setVehicle(v1); 
	 * 
	 * </code>
	 * 
	 * By calling ir1.setVehicle(v1), two references should be updated (ir1.vehicle and v1.insuranceRisk). Since both
	 * references should be updated, the following assertions should be true after attaching the objects together:<code>
	 * ir1.vehicle == v1
	 * v1.insuranceRisk == r1
	 * </code>
	 * 
	 * Inversely, you should be able to attach the objects the other way around by calling the setInsuranceRisk() method
	 * on the vehicle. The outcome should be the same, the assertions should still test positive:<code>
	 * v1.setInsuranceRisk(ir1);
	 * </code>
	 * 
	 * Either setters should synchronize both pointers. Doing this logic for every association setter would become
	 * cumbersome if the logic changed (Don't repeat yourself!). This is the main reason why these helper methods were
	 * created.
	 * 
	 * Here's the code required in each setter: <code>
	 * public class InsuranceRisk{
	 * 		...
	 * 		private Vehicle vehicle = null;
	 * 		public void setVehicle(Vehicle v){
	 * 			AssociationsHelper.updateOneToOneFields(this, InsuranceRisk.class, "vehicle", v, Vehicle.class, "insuranceRisk");
	 * 		}
	 * 		...
	 * }
	 * 
	 * public class Vehicle{
	 * 		...
	 * 		private InsuranceRisk insuranceRisk = null;
	 * 		public void setInsuranceRisk(InsuranceRisk ir){
	 * 			AssociationsHelper.updateOneToOneFields(ir, InsuranceRisk.class, "vehicle", this, Vehicle.class, "insuranceRisk");
	 * 		}
	 * 		...
	 * }
	 * </code>
	 * 
	 * Doing this, ensures all references participating in the one to one associations are kept in synch.
	 * 
	 * GOOD TO KNOW: the reflection API is used to set the references in both objects, we do not use the setters. The
	 * fields can have any visibility: public, private, protected or default. Private or protected visibility is always
	 * preferred.
	 * 
	 * A MORE COMPLEX EXAMPLE: Let's say we have one more InsuranceRisk (ir2) and one more Vehicle objects with the
	 * following associations ir1 <-> v1 and ir2 <-> v2.
	 * 
	 * If we execute the following code:<code>
	 * InsuranceRisk ir1 = new InsuranceRisk();
	 * InsuranceRisk ir2 = new InsuranceRisk();
	 * Vehicle v1 = new Vehicle();
	 * Vehicle v2 = new Vehicle();
	 * ir1.setVehicle(v1);  // sets both ends of ir1<->v1
	 * ir2.setVehicle(v2);  // sets both ends of ir2<->v2  
	 * </code>
	 * 
	 * Now if we associate v1 to ir2 with the following code:<code>
	 * ir2.setVehicle(v1);
	 * </code>
	 * 
	 * This helper method will make sure the object graph is valid when it's job is done. By using a classic POJO setter
	 * (setting a simple attribute), the references would be: <code>
	 * ir1.vehicle -> v1 
	 * ir2.vehicle -> v1 
	 * v1.insuranceRisk -> ir1 
	 * v2.insuranceRisk -> ir2
	 * </code>
	 * 
	 * Which is invalid, because some relations are not mirrored. We have assigned a different children vehicle to ir2,
	 * but the previous vehicle still references ir2. The assigned vehicle still references it's previous insurance risk
	 * ...
	 * 
	 * By using this helper, you are making sure that both sides of an association are always in synch/valid. Here's the
	 * result:<code>
	 * ir1.vehicle -> null        // does not reference v1 anymore since it was assigned to another object
	 * ir2.vehicle -> v1		  // ir2 now references v1 as its child
	 * v1.insuranceRisk -> ir2	  // v1 now references ir1 as its parent
	 * v2.insuranceRisk -> null   // assigning a new object makes it an orphan
	 * </code>
	 * 
	 * @param parent the parent
	 * @param parentClass the parent class
	 * @param childAttribute the child attribute
	 * @param child the child
	 * @param childClass the child class
	 * @param parentAttribute the parent attribute
	 */
	public static void updateOneToOneFields(Object parent, Class<?> parentClass, String childAttribute, Object child,
			Class<?> childClass, String parentAttribute) {

		if (childAttribute == null || childAttribute.trim().length() == 0) {
			throw new IllegalArgumentException("childAttribute is required");
		}

		if (parentAttribute == null || parentAttribute.trim().length() == 0) {
			throw new IllegalArgumentException("parentAttribute is required");
		}

		if (parent == null && child == null) {
			throw new IllegalArgumentException("the parent and the child object cannot be null");
		}

		Object unproxyedParent = unproxy(parent);
		Object unproxyedChild = unproxy(child);

		try {

			Field parentField = findField(childClass, parentAttribute);
			if (parentField == null) {
				throw new IllegalArgumentException("cannot find field '" + parentAttribute + " in "
						+ childClass.getSimpleName() + " hierarchy");
			}
			Field childField = findField(parentClass, childAttribute);
			if (childField == null) {
				throw new IllegalArgumentException("cannot find field '" + childAttribute + " in "
						+ parentClass.getSimpleName() + " hierarchy");
			}

			boolean parentFieldAccessible = parentField.isAccessible();
			boolean childFieldAccessible = childField.isAccessible();

			parentField.setAccessible(true);
			childField.setAccessible(true);

			if (unproxyedParent != null) {

				// is the parent assigned to a another child object?
				Object previousChild = unproxy(childField.get(unproxyedParent));
				if (previousChild != null) {
					// detaches the parent from the previous child object
					parentField.set(previousChild, null);
				}

				// child might be null
				childField.set(unproxyedParent, unproxyedChild); 

			}

			if (unproxyedChild != null) {

				Object previousParent = unproxy(parentField.get(unproxyedChild));

				if (previousParent != null) {
					childField.set(previousParent, null);
				}

				parentField.set(unproxyedChild, unproxyedParent);

			}

			parentField.setAccessible(parentFieldAccessible);
			childField.setAccessible(childFieldAccessible);

		} catch (Throwable e) {
			throw new RuntimeException(e);
		}

	}

	/**
	 * Updates both ends of a bidirectionnal one to many association.
	 * 
	 * Let's say we have a Category that can be associated to many Items. The association can be resumed as: one
	 * category contains many items and an item can be associated to a single Category.
	 * 
	 * If we create the following objects: <code>
	 * 
	 * Category c1 = new Category(); 
	 * Item i1 = new Item();
	 * Item i2 = new Item();
	 * </code>
	 * 
	 * The easiest way to attach objects is (if not using this helper method):<code>
	 * c1.getItems().add(i1); 
	 * i1.setCategory(c1); // this one is very easy to forget!
	 * c1.getItems().add(i2);
	 * i1.setCategory(c1);
	 * </code>
	 * 
	 * Inversely, if you wish to remove an item from a category, the following code is required:<code>
	 * c1.getItems().remove(i1);
	 * i1.setCategory(null); // this one is very easy to forget!
	 * </code>
	 * 
	 * You have to manage the references on both side yourself. This makes it very easy to forget to set both ends of
	 * the association. In that case you are not guaranteed Hibernate will do what you expect as it REQUIRES that both
	 * side of a bidirectionnal association to be mirrors.
	 * 
	 * A better approach is to add helper methods in the objects themselves. <code>
	 * public class Category {
	 * 		Set<Item> items = new HashSet<Item>(0);
	 * 		...
	 * 		public void add(Item i){
	 * 			this.items.add(i);
	 * 			i.setCategory(this);
	 * 		}
	 * 		public void remove(Item i){
	 * 			this.items.remove(i);
	 * 			i.setCategory(null);
	 * 		}
	 * }
	 * </code>
	 * 
	 * This is getting better, but you must not forget to call the helper method instead of the method directly exposed
	 * by the collection. You can prevent such a thing by protected your collection from client code manipulation:<code>
	 * public class Category {
	 * 		Set<Item> items = new HashSet<Item>(0);
	 *		protected void setItems(Set<Item> newItems){
	 *			this.items = newItems;
	 *		} 		
	 *		public Set<Item> getItems(){
	 *			return Collections.unmodifiableSet(this.items);
	 *		}
	 * 		public void add(Item i){
	 * 			this.items.add(i);
	 * 			i.setCategory(this);
	 * 		}
	 * 		public void remove(Item i){
	 * 			this.items.remove(i);
	 * 			i.setCategory(null);
	 * 		}
	 * }
	 * 
	 * Category c1 = new Category();
	 * c1.getItems().add(new Item()); // will not work because it now throws an UnsupportedOperationException
	 * c1.add(new Item()); 			  // works: add the item to the collection and set the parent to c1 (both ends updated!)
	 * c1.getItems().remove(i1);      // will not work because it now throws an UnsupportedOperationException
	 * c1.remove(i1); 				  // works: remove the item from the collection and set the parent to null (both ends updated!)
	 * </code>
	 * 
	 * Now we are getting somewhere. But the story does not end here. What would happen if we executed the following
	 * code? <code>
	 * Category c1 = new Category();
	 * Item i1 = new Item();
	 * c1.add(i1);
	 * i1.setCategory(null);
	 * </code>
	 * 
	 * That would leave us with an invalid object graph. i1 would not be referencing it's parent Category object, but
	 * would still be referenced as a children. Wrong, both association ends must always be in synch. Calling the
	 * item.category setter method should attach the object as a children if it's non null. By using
	 * AssociationsHelper.updateOneToManyFields the following code:<code>
	 * Category c1 = new Category();
	 * Item i1 = new Item();
	 * i1.setCategory(c1); // sets both ends of the assocaion (meaning i1.category == c1 and c1.items.contains(i1) == true) 
	 * </code>
	 * becomes equivalent to:<code>
	 * Category c1 = new Category();
	 * Item i1 = new Item();
	 * c1.add(i1); // sets both ends of the assocaion (meaning i1.category == c1 and c1.items.contains(i1) == true)
	 * </code>
	 * 
	 * You can now manage the associations from either end. Using this utility method also ensures that if you remove
	 * the item object from a category, the item.category attribute is also resetted to null. Trying to assign null to
	 * an item.category which was previously attached also means it will be removed from it's previous category.items
	 * collection.
	 * 
	 * Suppose we have 2 Category objects and 3 Item objects:<code>
	 * Category c1 = new Category();
	 * Category c2 = new Category();
	 * Item i1 = new Item();
	 * c1.add(i1);
	 * Item i2 = new Item();
	 * c1.add(i2);  // c1 contains two items  
	 * Item i3 = new Item();
	 * c2.add(i3);  // c2 contains one item
	 * 
	 * i1.setCategory(c2); // remove i1 from c1.items, attaches it to c2.items and i1.category = c2 (c1.items.size == 1 and c2.items.size == 2)
	 * c2.remove(i3);      // makes i3 an orphan by removing it from c2.items, it's category resetted to null (c1.items.size == 1 and c2.items.size == 1)
	 * </code>
	 * 
	 * Because of the validity of the object graph we can be assured Hibernate will modify the database correctly.
	 * 
	 * GOOD TO KNOW: the reflection API is used to set the references in both objects, we do not use the setters. The
	 * fields can have any visibility: public, private, protected or default. Private or protected visibility is always
	 * preferred.
	 * 
	 * @param parent the parent
	 * @param childrenAttribute the children attribute
	 * @param child the child
	 * @param parentAttribute the parent attribute
	 */
	@SuppressWarnings({ "unchecked" })
	public static void updateOneToManyFields(Object parent, String childrenAttribute, Object child,
			String parentAttribute) {

		if (childrenAttribute == null || childrenAttribute.trim().length() == 0) {
			throw new IllegalArgumentException("childrenAttribute is required");
		}

		if (parentAttribute == null || parentAttribute.trim().length() == 0) {
			throw new IllegalArgumentException("parentAttribute is required");
		}

		if (child == null) {
			throw new IllegalArgumentException("child cannot be null");
		}

		// we want the real db objects, bypasses the proxy if the db objects are proxied
		Object unproxyedChild = unproxy(child);
		Object unproxyedParent = unproxy(parent);

		try {
			Field parentField = findField(unproxyedChild.getClass(), parentAttribute);

			parentField.setAccessible(true);
			Object currentParent = unproxy(parentField.get(unproxyedChild));

			if (currentParent != null) {

				// Remove the object from it's previous parent
				Field childrenField = findField(currentParent.getClass(), childrenAttribute); 
				childrenField.setAccessible(true);
				Collection<Object> currentParentChildren = (Collection<Object>) childrenField.get(currentParent);

				// Loop through all items and unproxy them, we have to do this since the remove wont find the item to
				// delete when it compares proxy vs unproxy
				for (Object object : currentParentChildren) {
					Object unproxyedChildFromCollection = unproxy(object);
					if (unproxyedChildFromCollection.equals(unproxyedChild)) {
						currentParentChildren.remove(object);
						break;
					}
				}
				childrenField.setAccessible(false);
			}

			// sets the child pointer -> parent, and adds the child -> parent.children (if parent != null)
			parentField.set(unproxyedChild, unproxyedParent);

			if (unproxyedParent != null) {
				Field childrenField = findField(unproxyedParent.getClass(), childrenAttribute);
				childrenField.setAccessible(true);
				Collection<Object> parentChildren = (Collection<Object>) childrenField.get(unproxyedParent);
				parentChildren.add(unproxyedChild);
				childrenField.setAccessible(false);
			}

			parentField.setAccessible(false);

		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * This method checks if an entity is proxied. If it is, it forces the proxy to materialize the database object.
	 * This method has no effect if the entity is already a materialized database object.
	 * 
	 * @param entity - can be a real entity or an hibernate proxy (representing an entity). If null is
	 *            passed, the method returns null.
	 * 
	 * @return the materialized database object or null
	 */
	public static Object unproxy(Object entity) {
		if (entity == null) {
			return null;
		}

		if (entity instanceof HibernateProxy) {
			HibernateProxy proxy = (HibernateProxy) entity;
			return proxy.getHibernateLazyInitializer().getImplementation();
		}
		return entity;
	}

	/**
	 * This method searches the fields of in the class hierarchy. The JDK getDeclaredField() looks up for attributes
	 * declared directly in the class, it WILL NOT return a field defined in one of the class we inherits from.
	 * 
	 * Use this method if you wish to retrieve all fields in the classe hierarchy.
	 * 
	 * It scans the whole class hierarchy until it finds the specified attribute or we are at the root class.
	 * 
	 * The field can be public, protected or private.
	 * 
	 * <i>Explanations on why we have to scan the whole hierarchy: Hibernate will sometime create a proxy object around
	 * our entities to permits the lazy loading of association and collections. When an object is proxied, Hibernate
	 * creates a subclass of our entity class. So if we called getDeclaredField() directly on the proxy, it would never
	 * find the field as it is defined in the entity class.</i>
	 * 
	 * @param c the c
	 * @param fieldName the field name
	 * 
	 * @return the corresponding Field object
	 * 
	 * @throws NoSuchFieldException the no such field exception
	 * 
	 * @exception NoSuchFieldException thrown if the field is not found in the class hierarchy
	 */
	protected static Field findField(Class<?> c, String fieldName) throws NoSuchFieldException {
		if (fieldName == null) {
			throw new IllegalArgumentException("fieldName is required");
		}

		Class<?> clazz = c;

		while (clazz != Object.class) {
			try {
				return clazz.getDeclaredField(fieldName);
			} catch (NoSuchFieldException e) {
				clazz = clazz.getSuperclass();
				if (clazz == Object.class) {
					throw e;
				}
			}
		}
		return null;
	}
}
