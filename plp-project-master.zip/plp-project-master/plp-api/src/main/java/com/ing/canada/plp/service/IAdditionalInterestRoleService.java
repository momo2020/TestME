/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.domain.insurancerisk.AdditionalInterestRole;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * This interface exposes services required to manage Coverage related entities.
 * 
 * @author syltremb
 */
public interface IAdditionalInterestRoleService extends ICRUDService<AdditionalInterestRole> {

	/**
	 * This method must return all claims associated to the PolicyVersion, 
	 * the one of the Party or of the InsuranceRisk. 
	 * The claim should not be present more than once in the list.
	 * 
	 * @param policyVersion
	 * @return
	 */
	List<AdditionalInterestRole> findAllAdditionalInterestRoleByPolicyVersion(PolicyVersion policyVersion);
	
}
