/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insurancerisk;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.ManufacturingContext;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * AdditionalInterestRole entity.
 * 
 * @author Patrick Lafleur
 */
@Entity
@Table(name = "ADDL_INT_REP_MAN_CONTEXT", uniqueConstraints = {})
@NamedQueries( {
		@NamedQuery(name = "AdditionalInterestRepositoryManufacturingContext.getAdditionalInterestsSortedFrench", query = "select airmc from AdditionalInterestRepositoryManufacturingContext airmc inner join airmc.additionalInterestRepositoryEntry aire where airmc.manufacturingContext = :manufacturingContext and trunc(airmc.effectiveDate) <= trunc(current_date()) and (trunc(airmc.expiryDate) >= trunc(current_date()) or airmc.expiryDate is null) and aire.additionalInterestType = :additionalInterestType order by upper(aire.nameFrench)"),
		@NamedQuery(name = "AdditionalInterestRepositoryManufacturingContext.getAdditionalInterestsSortedEnglish", query = "select airmc from AdditionalInterestRepositoryManufacturingContext airmc inner join airmc.additionalInterestRepositoryEntry aire where airmc.manufacturingContext = :manufacturingContext and trunc(airmc.effectiveDate) <= trunc(current_date()) and (trunc(airmc.expiryDate) >= trunc(current_date()) or airmc.expiryDate is null) and aire.additionalInterestType = :additionalInterestType order by upper(aire.nameEnglish)"),
		@NamedQuery(name = "AdditionalInterestRepositoryManufacturingContext.getAdditionalInterest", query = "select airmc from AdditionalInterestRepositoryManufacturingContext airmc where airmc.id = :id") })
public class AdditionalInterestRepositoryManufacturingContext extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "ADDL_INT_REP_MAN_CONTEXT_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "AdditionalInterestRepositoryManufacturingContextSequence")
	@SequenceGenerator(name = "AdditionalInterestRepositoryManufacturingContextSequence", sequenceName = "ADDL_INT_REP_MAN_CONTEXT_SEQ", allocationSize = 5)
	private Long id;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", length = 7)
	protected Date effectiveDate;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	protected Date expiryDate;

	/** The additional interest repository entry. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ADDL_INTEREST_REP_ENTRY_ID", updatable = true)
	private AdditionalInterestRepositoryEntry additionalInterestRepositoryEntry;

	/** The manufacturing context. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "MANUFACTURING_CONTEXT_ID", nullable = false, updatable = true)
	private ManufacturingContext manufacturingContext;

	/**
	 * Instantiates a new additional interest repository manufacturing context.
	 */
	public AdditionalInterestRepositoryManufacturingContext() {
		// noarg constructor
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the additional interest repository entry.
	 * 
	 * @return the additional interest repository entry
	 */
	public AdditionalInterestRepositoryEntry getAdditionalInterestRepositoryEntry() {
		return this.additionalInterestRepositoryEntry;
	}

	/**
	 * Sets the additional interest repository entry.
	 * 
	 * @param aAdditionalInterestRepositoryEntry the new additional interest repository entry
	 */
	public void setAdditionalInterestRepositoryEntry(
			AdditionalInterestRepositoryEntry aAdditionalInterestRepositoryEntry) {
		AssociationsHelper.updateOneToManyFields(aAdditionalInterestRepositoryEntry,
				"additionalInterestRepositoryManufacturingContextSequence", this, "additionalInterestRepositoryEntry");
	}

	/**
	 * Gets the manufacturing context.
	 * 
	 * @return the manufacturing context
	 */
	public ManufacturingContext getManufacturingContext() {
		return this.manufacturingContext;
	}

	/**
	 * Sets the manufacturing context.
	 * 
	 * @param aManufacturingContext the new manufacturing context
	 */
	public void setManufacturingContext(ManufacturingContext aManufacturingContext) {
		this.manufacturingContext = aManufacturingContext;
	}

	/**
	 * Gets the effective date.
	 * 
	 * @return the effective date
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * Sets the effective date.
	 * 
	 * @param aEffectiveDate the new effective date
	 */
	public void setEffectiveDate(Date aEffectiveDate) {
		this.effectiveDate = aEffectiveDate;
	}

	/**
	 * Gets the expiry date.
	 * 
	 * @return the expiry date
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * Sets the expiry date.
	 * 
	 * @param aExpiryDate the new expiry date
	 */
	public void setExpiryDate(Date aExpiryDate) {
		this.expiryDate = aExpiryDate;
	}
}
