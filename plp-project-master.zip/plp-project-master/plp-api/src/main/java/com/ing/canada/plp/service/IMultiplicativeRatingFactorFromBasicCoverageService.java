/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.enums.BasicCoverageCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.MultiplicativeRatingFactorFromBasicCoverage;
import com.ing.canada.plp.domain.insurancerisk.RatingRisk;

/**
 * This interface exposes services required to manage Rating risks related entities.
 * 
 * @author Stephane Desjardins
 */
public interface IMultiplicativeRatingFactorFromBasicCoverageService extends ICRUDService<MultiplicativeRatingFactorFromBasicCoverage> {
	
	/**
	 * Retrieve the factor associated to the specified arguments
	 * @param ratingRisk
	 * @param basicCoverageCode
	 * @param limitOfInsuranceAmount
	 * @param deductibleAmount
	 * @param limitMedicalExpensesPerPersonAmount
	 * @param limitMutilationDeathIndemnityAmount
	 * @param weeklyBenefitsAmount
	 * @return
	 */
	MultiplicativeRatingFactorFromBasicCoverage getMultiplicativeRatingFactorFromBasicCoverage(
			RatingRisk ratingRisk,
			BasicCoverageCodeEnum basicCoverageCode,
			Integer limitOfInsuranceAmount,
			Integer deductibleAmount,
			Integer limitMedicalExpensesPerPersonAmount,
			Integer limitMutilationDeathIndemnityAmount,
			Integer weeklyBenefitsAmount);
}
