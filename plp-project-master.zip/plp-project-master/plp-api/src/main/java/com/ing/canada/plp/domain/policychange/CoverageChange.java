package com.ing.canada.plp.domain.policychange;


public class CoverageChange {
	
	private String code = null;
	private Float amount = null;
	private short riskSequence = 0;
	private CoverageValueTypeEnum coverageValueType = null;
	
	
	public CoverageChange() {
	}
	
	public CoverageChange(CoverageChange change) {
		this.setCode(change.getCode());
		this.setAmount(change.getAmount());
		this.setRiskSequence(change.getRiskSequence());
		this.setCoverageValueType(change.getCoverageValueType());
	}

	public String getCode() {
		return this.code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public short getRiskSequence() {
		return this.riskSequence;
	}

	public void setRiskSequence(short riskSequence) {
		this.riskSequence = riskSequence;
	}

	public Float getAmount() {
		return this.amount;
	}
	public void setAmount(Float amount) {
		this.amount = amount;
	}
	
	public CoverageValueTypeEnum getCoverageValueType() {
		return coverageValueType;
	}

	public void setCoverageValueType(CoverageValueTypeEnum coverageValueType) {
		this.coverageValueType = coverageValueType;
	}

	public String toString() {
		return "[code=" + this.getCode() + ", amount=" + this.getAmount() + " risk sequence=" + this.getRiskSequence() + "]";
	}
	

}
