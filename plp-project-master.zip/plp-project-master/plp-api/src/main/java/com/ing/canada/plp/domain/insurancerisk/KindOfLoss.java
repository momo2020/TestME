/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insurancerisk;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.BasicCoverageCodeEnum;
import com.ing.canada.plp.domain.enums.CoverageTypeCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * KindOfLoss entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "KIND_OF_LOSS", uniqueConstraints = {})
public class KindOfLoss extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "KIND_OF_LOSS_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "KindOfLossSequence")
	@SequenceGenerator(name = "KindOfLossSequence", sequenceName = "KIND_OF_LOSS_SEQ", allocationSize = 5)
	private Long id;

	/** The claim. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "CLAIM_ID", nullable = false, updatable = true)
	private Claim claim;

	/** The kind of loss code. */
	@Column(name = "KIND_OF_LOSS_CD", nullable = false, length = 2)	
	private String kindOfLoss;

	/** The coverage type code. */
	@Column(name = "COVERAGE_TYPE_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.CoverageTypeCodeEnum") })
	private CoverageTypeCodeEnum coverageTypeCode;

	/** The coverage code. */
	@Column(name = "COVERAGE_CD", length = 5)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.BasicCoverageCodeEnum") })
	private BasicCoverageCodeEnum coverageCode;

	/** The paid amount. */
	@Column(name = "PAID_AMT", precision = 12)
	private BigDecimal amountPaid;

	/** The reserve amount. */
	@Column(name = "RESERVE_AMT", precision = 12)
	private BigDecimal amountReserve;	
	
	/** The original scenario kind of loss. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_KIND_OF_LOSS_ID", insertable = false, updatable = false)
	private KindOfLoss originalScenarioKindOfLoss;

	/**
	 * Instantiates a new kind of loss.
	 */
	public KindOfLoss() {
		// noarg constructor
	}

	/**
	 * Instantiates a new kind of loss.
	 * 
	 * @param aClaim the a claim
	 * @param aKindOfLossCode the a kind of loss code
	 */
	public KindOfLoss(Claim aClaim, String aKindOfLossCode) {
		setClaim(aClaim);
		setKindOfLoss(aKindOfLossCode);
	}

	public KindOfLoss(int amount) {
		this.setAmountPaid(BigDecimal.valueOf(amount));
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the claim.
	 * 
	 * @return the claim
	 */
	@XmlTransient // parent
	public Claim getClaim() {
		return this.claim;
	}

	/**
	 * Sets the claim.
	 * 
	 * @param aClaim the new claim
	 */
	public void setClaim(Claim aClaim) {
		AssociationsHelper.updateOneToManyFields(aClaim, "kindOfLosses", this, "claim");
	}

	/**
	 * Gets the kind of loss code.
	 * 
	 * @return the kind of loss code
	 */
	public String getKindOfLoss() {
		return this.kindOfLoss;
	}

	/**
	 * Sets the kind of loss code.
	 * 
	 * @param aKindOfLossCode the new kind of loss code
	 */
	public void setKindOfLoss(String aKindOfLossCode) {
		this.kindOfLoss = aKindOfLossCode;
	}

	/**
	 * Gets the coverage type code.
	 * 
	 * @return the coverage type code
	 */
	public CoverageTypeCodeEnum getCoverageTypeCode() {
		return this.coverageTypeCode;
	}

	/**
	 * Sets the coverage type code.
	 * 
	 * @param aCoverageTypeCode the new coverage type code
	 */
	public void setCoverageTypeCode(CoverageTypeCodeEnum aCoverageTypeCode) {
		this.coverageTypeCode = aCoverageTypeCode;
	}

	/**
	 * Gets the coverage code.
	 * 
	 * @return the coverage code
	 */
	public BasicCoverageCodeEnum getCoverageCode() {
		return this.coverageCode;
	}

	/**
	 * Sets the coverage code.
	 * 
	 * @param aCoverageCode the new coverage code
	 */
	public void setCoverageCode(BasicCoverageCodeEnum aCoverageCode) {
		this.coverageCode = aCoverageCode;
	}

	/**
	 * Gets the paid amount.
	 * 
	 * @return the paid amount
	 */
	public BigDecimal getAmountPaid() {
		return this.amountPaid;
	}

	/**
	 * Sets the paid amount.
	 * 
	 * @param aPaidAmount the new paid amount
	 */
	public void setAmountPaid(BigDecimal aPaidAmount) {
		this.amountPaid = aPaidAmount;
	}

	/**
	 * Gets the original scenario kind of loss.
	 * 
	 * @return the original scenario kind of loss
	 */
	@XmlTransient // reference source
	public KindOfLoss getOriginalScenarioKindOfLoss() {
		return this.originalScenarioKindOfLoss;
	}

	/**
	 * Sets the original scenario kind of loss.
	 * 
	 * @param anOriginalScenarioKindOfLoss the new original scenario kind of loss
	 */
	protected void setOriginalScenarioKindOfLoss(KindOfLoss anOriginalScenarioKindOfLoss) {
		this.originalScenarioKindOfLoss = anOriginalScenarioKindOfLoss;
	}

	/**
	 * Gets the amount reserve.
	 * 
	 * @return the amountReserve
	 */
	public BigDecimal getAmountReserve() {
		return this.amountReserve;
	}

	/**
	 * Sets the amount reserve.
	 * 
	 * @param aAmountReserve the amountReserve to set
	 */
	public void setAmountReserve(BigDecimal aAmountReserve) {
		this.amountReserve = aAmountReserve;
	}

}
