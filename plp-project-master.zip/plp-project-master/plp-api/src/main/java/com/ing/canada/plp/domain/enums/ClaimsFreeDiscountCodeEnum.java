/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum ClaimsFreeDiscountCodeEnum.
 */
public enum ClaimsFreeDiscountCodeEnum {

	STANDARD_RATES("0"), 
	HONOR_WITHOUT_FORGIVENESS("1"), 
	STANDARD_RATES_WITH_PARTIAL_FORGIVENESS("2"), 
	HONOR_WITH_FORGIVENESS_RENEWAL("3"), 
	HONOR_WITH_FORGIVENESS("4"), 
	STANDARD_RATES_NO_CLAIM_IN_THE_LAST_YEAR("5"), 
	STANDARD_RATES_NO_CLAIM_IN_THE_LAST_2_YEARS("6"), 
	SPECIAL_RATES_NO_CLAIM_IN_THE_LAST_3_YEARS("7"), 
	SPECIAL_RATES_NO_CLAIM_IN_THE_LAST_4_YEARS("8"), 
	SPECIAL_RATES_NO_CLAIM_IN_THE_LAST_5_YEARS("9"), 
	NOT_ELIGIBLE_TO_THE_CLAIMS_FREE_DISCOUNT("N");

	/**
	 * Instantiates a new claims free discount code enum.
	 * 
	 * @param aCode the a code
	 */
	private ClaimsFreeDiscountCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the claims free discount code enum
	 */
	public static ClaimsFreeDiscountCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (ClaimsFreeDiscountCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
