/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance 
* Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
*/
package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.party.Consent;


/**
 * use only the methods in CRUDService for now.
 * @author mblouin
 *
 */
public interface IConsentService extends ICRUDService<Consent> {
	//no op
}
