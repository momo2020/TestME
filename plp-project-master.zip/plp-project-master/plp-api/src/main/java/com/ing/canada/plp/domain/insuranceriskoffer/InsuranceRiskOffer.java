/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insuranceriskoffer;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang.BooleanUtils;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.businesstransaction.TransactionalMessage;
import com.ing.canada.plp.domain.coverage.BaseCoverage;
import com.ing.canada.plp.domain.diagnostics.DiagnosticAutomatedAdvice;
import com.ing.canada.plp.domain.enums.BasicCoverageCodeEnum;
import com.ing.canada.plp.domain.enums.EndorsementCodeEnum;
import com.ing.canada.plp.domain.enums.GoodDriverCodeEnum;
import com.ing.canada.plp.domain.enums.InternalTechnicalOfferTypeCodeEnum;
import com.ing.canada.plp.domain.enums.OfferTypeCodeEnum;
import com.ing.canada.plp.domain.enums.PolicyTermInMonthsEnum;
import com.ing.canada.plp.domain.enums.QualityRiskLevelCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * InsuranceRiskOffer entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "INSURANCE_RISK_OFFER", uniqueConstraints = {})
@NamedQueries({ @NamedQuery(name = "InsuranceRiskOffer.findInsuranceRiskOfferByInternalOfferType", query = "SELECT iro FROM com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer iro "
		+ "WHERE iro.insuranceRisk.id = :insuranceRiskId " + "AND iro.internalTechnicalOfferType = :internalOfferType ") })
public class InsuranceRiskOffer extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "INSURANCE_RISK_OFFER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "InsuranceRiskOfferSequence")
	@SequenceGenerator(name = "InsuranceRiskOfferSequence", sequenceName = "INSURANCE_RISK_OFFER_SEQ", allocationSize = 5)
	private Long id;

	/** The policy offer rating. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "POLICY_OFFER_RATING_ID", nullable = true, updatable = true)
	private PolicyOfferRating policyOfferRating;

	/** The insurance risk. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_RISK_ID", nullable = false, updatable = true)
	private InsuranceRisk insuranceRisk;

	/** The offer type code. */
	@Column(name = "OFFER_TYPE_CD", nullable = false, length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.OfferTypeCodeEnum") })
	private OfferTypeCodeEnum offerType;

	/** The annual premium amount. */
	@Column(name = "ANNUAL_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer annualPremium;

	/** The full term premium amount. */
	@Column(name = "FULL_TERM_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer fullTermPremium;

	/** The additional return premium amount. */
	@Column(name = "ADDITIONAL_RETURN_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer additionalReturnPremium;

	/** Does the driver has a good record?. */
	@Column(name = "GOOD_DRIVER_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.GoodDriverCodeEnum") })
	private GoodDriverCodeEnum goodDriver;

	/** The quality risk level. */
	@Column(name = "QUALITY_RISK_LEVEL_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.QualityRiskLevelCodeEnum") })
	private QualityRiskLevelCodeEnum qualityRiskLevel;

	/** The rsp scoring. */
	@Column(name = "RSP_SCORING_QTY", precision = 2, scale = 0)
	private Byte rspScoring;

	/** The competitivity score with credit. */
	@Column(name = "COMPET_SCORE_WITH_CR_QTY", precision = 3, scale = 0)
	private Short competitivityScoreWithCredit;

	/** The competitivity score without cr. */
	@Column(name = "COMPET_SCORE_WITHOUT_CR_QTY", precision = 3, scale = 0)
	private Short competitivityScoreWithoutCredit;

	/** The customer value index pure with credit. */
	@Column(name = "CVI_PURE_WITH_CREDIT_QTY", precision = 3, scale = 0)
	private Short customerValueIndexPureWithCredit;

	/** The customer value index pure without credit. */
	@Column(name = "CVI_PURE_WITHOUT_CREDIT_QTY", precision = 5, scale = 0)
	private Short customerValueIndexPureWithoutCredit;

	/** CVI Adjusted with Credit */
	@Column(name = "CVI_ADJD_WITH_CREDIT_QTY", precision = 3, scale = 0)
	private Short customerValueIndexAdjustedWithCredit;

	/** The retention score pure with credit. */
	@Column(name = "RET_SCORE_PURE_WITH_CR_QTY", precision = 3, scale = 0)
	private Short retentionScorePureWithCredit;

	/** The retention score pure without credit. */
	@Column(name = "RET_SCORE_PURE_WITHOUT_CR_QTY", precision = 3, scale = 0)
	private Short retentionScorePureWithoutCredit;

	/** The vehicle rate group code. */
	@Column(name = "VEHICLE_RATE_GROUP_CD", length = 2)
	private String vehicleRateGroupCode = null;

	/** The vehicle rate group liability bodily injury. */
	@Column(name = "VEH_RT_GRP_LBLTY_BDLY_INJRY_CD", length = 2)
	private String vehicleRateGroupLiabilityBodilyInjury = null;

	/** The vehicle rate group liability property damage. */
	@Column(name = "VEH_RT_GRP_LBLTY_PRPTY_DMD_CD", length = 2)
	private String vehicleRateGroupLiabilityPropertyDamage = null;

	/** The vehicle rate group accident benefit. */
	@Column(name = "VEH_RT_GRP_ACDNT_BNFT_CD", length = 2)
	private String vehicleRateGroupAccidentBenefit = null;

	/** The vehicle rate group all perils. */
	@Column(name = "VEH_RT_GRP_ALL_PERILS_CD", length = 2)
	private String vehicleRateGroupAllPerils = null;

	/** The vehicle rate group collision. */
	@Column(name = "VEH_RT_GRP_COLLISION_CD", length = 2)
	private String vehicleRateGroupCollision = null;

	/** The vehicle rate group comprehensive. */
	@Column(name = "VEH_RT_GRP_COMPREHENSIVE_CD", length = 2)
	private String vehicleRateGroupComprehensive = null;

	/** The vehicle rate group specified perils. */
	@Column(name = "VEH_RT_GRP_SPECIFIED_PERILS_CD", length = 2)
	private String vehicleRateGroupSpecifiedPerils = null;

	/** The vehicle rate group liability. */
	@Column(name = "VEH_RT_GRP_LBLTY_CD", length = 2)
	private String vehicleRateGroupLiability = null;

	/** The vehicle rate group medical expenses. */
	@Column(name = "VEH_RT_GRP_MEDICAL_EXPENSES_CD", length = 2)
	private String vehicleRateGroupMedicalExpenses = null;

	/** The vehicle rate group total disability. */
	@Column(name = "VEH_RT_GRP_TOTAL_DISABILITY_CD", length = 2)
	private String vehicleRateGroupTotalDisability = null;

	/** The caa discount applied indicator. */
	@Column(name = "CAA_DISCOUNT_APPLIED_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean caaDiscountAppliedIndicator = null;

	@Column(name = "SELECTED_FOR_POL_OFFER_RAT_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean selectedForPolicyOfferRatingIndicator = null;

	/** The recalculatable offer indicator. */
	@Column(name = "RECALCULATABLE_OFFER_IND", length = 1)
	@Type(type = "yes_no")
	protected Boolean recalculatableOfferIndicator = null;
	
	/** The policy offer rating. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "insuranceRiskOffer")
	@OrderBy("id ASC")
	private Set<TransactionalMessage> transactionalMessages = new HashSet<TransactionalMessage>(0);

	/** The coverage offers. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "insuranceRiskOffer")
	@Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<CoverageOffer> coverageOffers = new HashSet<CoverageOffer>(0);

	/** The rating risks. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "insuranceRiskOffer")
	@Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<RatingRiskOffer> ratingRiskOffers = new HashSet<RatingRiskOffer>(0);

	/** The diagnostics advice. */
	@OneToMany(cascade = { CascadeType.PERSIST }, fetch = FetchType.LAZY, mappedBy = "insuranceRiskOffer")
	@Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<DiagnosticAutomatedAdvice> diagnosticAdvices = new HashSet<DiagnosticAutomatedAdvice>(0);

	/** Diagnostics internal offer type code. */
	@Column(name = "INTERNAL_TECH_OFFER_TYPE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.InternalTechnicalOfferTypeCodeEnum") })
	private InternalTechnicalOfferTypeCodeEnum internalTechnicalOfferType;

	/** The customer value index for underwriting (prefered). */
	@Column(name = "CVI_PURE_FOR_UNDRWTR_PREF_QTY", precision = 3, scale = 0)
	private Short customerValueIndexPurePreferred;

	/** The customer value index for underwriting (regular). */
	@Column(name = "CVI_PURE_FOR_UNDRWTR_REG_QTY", precision = 3, scale = 0)
	private Short customerValueIndexPureRegular;

	/** The optional accident benefits indicator */
	@Column(name = "ACDNT_BNFT_OPTION_SELECTED_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean optionalAccidentBenefitsIndicator;

	/** The creation date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "SYSTEM_CREATE_TS", length = 7, insertable = false, updatable = false)
	private Date systemCreateTS;

	@Transient
	private Map<String, Set<BaseCoverage>> endorsementCoverages = null;

	/**
	 * Instantiates a new insurance risk offer.
	 */
	public InsuranceRiskOffer() {
		// empty constructor ...
	}

	/**
	 * Instantiates a new insurance risk offer.
	 * 
	 * @param aInsuranceRisk the a insurance risk
	 * @param aOfferTypeCode the a offer type code
	 */
	public InsuranceRiskOffer(InsuranceRisk aInsuranceRisk, OfferTypeCodeEnum aOfferTypeCode) {
		setInsuranceRisk(aInsuranceRisk);
		setOfferType(aOfferTypeCode);
	}

	public Short getCustomerValueIndexPurePreferred() {
		return this.customerValueIndexPurePreferred;
	}

	public void setCustomerValueIndexPurePreferred(Short aCustomerValueIndexPurePreferred) {
		this.customerValueIndexPurePreferred = aCustomerValueIndexPurePreferred;
	}

	public Short getCustomerValueIndexPureRegular() {
		return this.customerValueIndexPureRegular;
	}

	public void setCustomerValueIndexPureRegular(Short aCustomerValueIndexPureRegular) {
		this.customerValueIndexPureRegular = aCustomerValueIndexPureRegular;
	}
	
	/**
	 * Gets the transactional messages.
	 * 
	 * @return the transactional messages
	 */
	@XmlElementWrapper(name="transactionalMessages")
	@XmlElement(name="transactionalMessage")
	public Set<TransactionalMessage> getTransactionalMessages() {
		return this.transactionalMessages;
	}

	/**
	 * Sets the transactional messages.
	 * 
	 * @param aTransactionalMessages the new transactional messages
	 */
	public void setTransactionalMessages(Set<TransactionalMessage> aTransactionalMessages) {
		this.transactionalMessages = aTransactionalMessages;
	}

	/**
	 * Gets the policy offer rating.
	 * 
	 * @return the policy offer rating
	 */
	@XmlTransient
	// parent
	public PolicyOfferRating getPolicyOfferRating() {
		return this.policyOfferRating;
	}

	/**
	 * Sets the policy offer rating.
	 * 
	 * @param aPolicyOfferRating the new policy offer rating
	 */
	public void setPolicyOfferRating(PolicyOfferRating aPolicyOfferRating) {
		AssociationsHelper.updateOneToManyFields(aPolicyOfferRating, "insuranceRisksOffers", this, "policyOfferRating");
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the insurance risk.
	 * 
	 * @return the insurance risk
	 */
	@XmlTransient
	// parent
	public InsuranceRisk getInsuranceRisk() {
		return this.insuranceRisk;
	}

	/**
	 * Sets the insurance risk.
	 * 
	 * @param aInsuranceRisk the new insurance risk
	 */
	public void setInsuranceRisk(InsuranceRisk aInsuranceRisk) {
		AssociationsHelper.updateOneToManyFields(aInsuranceRisk, "insuranceRiskOffers", this, "insuranceRisk");
	}

	/**
	 * Gets the offer type.
	 * 
	 * @return the offer type
	 */
	public OfferTypeCodeEnum getOfferType() {
		return this.offerType;
	}

	/**
	 * Sets the offer type.
	 * 
	 * @param aOfferTypeCode the new offer type
	 */
	public void setOfferType(OfferTypeCodeEnum aOfferTypeCode) {
		this.offerType = aOfferTypeCode;
	}

	/**
	 * Gets the annual premium.
	 * 
	 * @return the annual premium
	 */
	public Integer getAnnualPremium() {
		return this.annualPremium;
	}

	/**
	 * Sets the annual premium amount.
	 * 
	 * @param aAnnualPremiumAmount the new annual premium amount
	 */
	public void setAnnualPremium(Integer aAnnualPremiumAmount) {
		this.annualPremium = aAnnualPremiumAmount;
	}

	/** COMPUTED: The monthly premium amount. */
	/**
	 * Gets the monthly premium.
	 * 
	 * @return the monthly premium
	 */
	public Double getMonthlyPremium() {
		/**
		 * This does not work, it should be the full term premium divided instead of annual premium
		 **/
		Double aPremium  = null;
		
		if (this.getAnnualPremium() != null) {
			aPremium = new Double(this.getAnnualPremium());
			aPremium = aPremium / PolicyTermInMonthsEnum.TWELVE_MONTHS.getCode();
		}
		
		return aPremium;
	}
	
	public Double getRoundedMonthlyPremium() {
		return this.getMonthlyPremium() != null ? (Math.round(getMonthlyPremium() * 100.0) / 100.0) : null;
	}

	/**
	 * Gets the full term premium amount.
	 * 
	 * @return the full term premium amount
	 */
	public Integer getFullTermPremium() {
		return this.fullTermPremium;
	}

	/**
	 * Sets the full term premium amount.
	 * 
	 * @param aFullTermPremiumAmount the new full term premium amount
	 */
	public void setFullTermPremium(Integer aFullTermPremiumAmount) {
		this.fullTermPremium = aFullTermPremiumAmount;
	}

	/**
	 * Gets the additional return premium amount.
	 * 
	 * @return the additional return premium amount
	 */
	public Integer getAdditionalReturnPremium() {
		return this.additionalReturnPremium;
	}

	/**
	 * Sets the additional return premium.
	 * 
	 * @param aAdditionalReturnPremiumAmount the new additional return premium
	 */
	public void setAdditionalReturnPremium(Integer aAdditionalReturnPremiumAmount) {
		this.additionalReturnPremium = aAdditionalReturnPremiumAmount;
	}

	/**
	 * fs the insurance risk.
	 * 
	 * @param anInsuranceRisk the an insurance risk
	 */
	public void removeInsuranceRisk(com.ing.canada.plp.domain.insurancerisk.InsuranceRisk anInsuranceRisk) {
		AssociationsHelper.updateOneToManyFields(null, "insuranceRisks", anInsuranceRisk, "insuranceRiskOffer");
	}

	/**
	 * Gets the coverage offers.
	 * 
	 * @return the coverage offers
	 */
	@XmlElementWrapper(name = "coverageOffers")
	@XmlElement(name = "coverageOffer")
	public Set<CoverageOffer> getCoverageOffers() {
		return Collections.unmodifiableSet(this.coverageOffers);
	}

	/**
	 * @param code {@link #EndorsementCodeEnum}
	 * @return {@link #endorsementCoverages}
	 */
	public Set<BaseCoverage> getCoverages(EndorsementCodeEnum code) {

		if (this.endorsementCoverages == null) {

			this.endorsementCoverages = new HashMap<String, Set<BaseCoverage>>();

			for (CoverageOffer coverage : this.getCoverageOffers()) {

				EndorsementCodeEnum tempCode = EndorsementCodeEnum.valueOfCode(coverage.getCoverageRepositoryEntry()
						.getCoverageCode(), coverage.getCoverageRepositoryEntry().getManufacturerCompanyCode());

				if (tempCode == null) {
					continue;
				}

				Set<BaseCoverage> list = this.endorsementCoverages.get(tempCode);

				if (list == null) {
					list = new HashSet<BaseCoverage>();
					this.endorsementCoverages.put(tempCode.getCode(), list);
				}

				list.add(coverage);
			}
		}

		return this.endorsementCoverages.get(code.getCode());
	}

	public Set<BaseCoverage> getCoverages(String coverageCode) {

		if (this.endorsementCoverages == null) {

			this.endorsementCoverages = new HashMap<String, Set<BaseCoverage>>();

			for (CoverageOffer coverage : this.getCoverageOffers()) {

				Set<BaseCoverage> list = this.endorsementCoverages.get(coverage.getCoverageRepositoryEntry()
						.getCoverageCode());

				if (list == null) {
					list = new HashSet<BaseCoverage>();
					this.endorsementCoverages.put(coverage.getCoverageRepositoryEntry().getCoverageCode(), list);
				}

				list.add(coverage);
			}
		}

		return this.endorsementCoverages.get(coverageCode);
	}

	/**
	 * Sets the coverage offers.
	 * 
	 * @param aCoverageOffers the new coverage offers
	 */
	protected void setCoverageOffers(Set<CoverageOffer> aCoverageOffers) {
		this.coverageOffers = aCoverageOffers;
	}

	/**
	 * Adds the coverage offer.
	 * 
	 * @param offer the offer
	 */
	public void addCoverageOffer(com.ing.canada.plp.domain.insuranceriskoffer.CoverageOffer offer) {
		AssociationsHelper.updateOneToManyFields(this, "coverageOffers", offer, "insuranceRiskOffer");
	}

	/**
	 * Removes the coverage offer.
	 * 
	 * @param offer the offer
	 */
	public void removeCoverageOffer(com.ing.canada.plp.domain.insuranceriskoffer.CoverageOffer offer) {
		AssociationsHelper.updateOneToManyFields(null, "coverageOffers", offer, "insuranceRiskOffer");
	}

	/**
	 * Adds the diagnostic advice.
	 * 
	 * @param anDiagnostic Diagnostic advice
	 */
	public void addDiagnosticAutomatedAdvice(
			com.ing.canada.plp.domain.diagnostics.DiagnosticAutomatedAdvice anDiagnostic) {
		AssociationsHelper.updateOneToManyFields(this, "diagnosticAdvices", anDiagnostic, "insuranceRiskOffer");
	}

	/**
	 * Removes the diagnostic advice.
	 * 
	 * @param anDiagnostic Diagnostic advice
	 */
	public void removeDiagnosticAutomatedAdvice(
			com.ing.canada.plp.domain.diagnostics.DiagnosticAutomatedAdvice anDiagnostic) {
		AssociationsHelper.updateOneToManyFields(null, "diagnosticAdvices", anDiagnostic, "insuranceRiskOffer");
	}

	/**
	 * Sets the good driver.
	 * 
	 * @param aGoodDriver the goodDriver to set
	 */
	public void setGoodDriver(GoodDriverCodeEnum aGoodDriver) {
		this.goodDriver = aGoodDriver;
	}

	/**
	 * Gets the good driver.
	 * 
	 * @return the goodDriver
	 */
	public GoodDriverCodeEnum getGoodDriver() {
		return this.goodDriver;
	}

	/**
	 * Sets the quality risk level.
	 * 
	 * @param aQualityRiskLevel the qualityRiskLevel to set
	 */
	public void setQualityRiskLevel(QualityRiskLevelCodeEnum aQualityRiskLevel) {
		this.qualityRiskLevel = aQualityRiskLevel;
	}

	/**
	 * Gets the quality risk level.
	 * 
	 * @return the qualityRiskLevel
	 */
	public QualityRiskLevelCodeEnum getQualityRiskLevel() {
		return this.qualityRiskLevel;
	}

	/**
	 * Gets the competitivity score with credit.
	 * 
	 * @return the competitivityScoreWithCredit
	 */
	public Short getCompetitivityScoreWithCredit() {
		return this.competitivityScoreWithCredit;
	}

	/**
	 * Sets the competitivity score with credit.
	 * 
	 * @param aCompetitivityScoreWithCredit the competitivityScoreWithCredit to set
	 */
	public void setCompetitivityScoreWithCredit(Short aCompetitivityScoreWithCredit) {
		this.competitivityScoreWithCredit = aCompetitivityScoreWithCredit;
	}

	/**
	 * Gets the competitivity score without credit.
	 * 
	 * @return the competitivityScoreWithoutCredit
	 */
	public Short getCompetitivityScoreWithoutCredit() {
		return this.competitivityScoreWithoutCredit;
	}

	/**
	 * Sets the competitivity score without credit.
	 * 
	 * @param aCompetitivityScoreWithoutCredit the competitivityScoreWithoutCredit to set
	 */
	public void setCompetitivityScoreWithoutCredit(Short aCompetitivityScoreWithoutCredit) {
		this.competitivityScoreWithoutCredit = aCompetitivityScoreWithoutCredit;
	}

	/**
	 * Gets the customer value index pure with credit.
	 * 
	 * @return the customerValueIndexPureWithCredit
	 */
	public Short getCustomerValueIndexPureWithCredit() {
		return this.customerValueIndexPureWithCredit;
	}

	/**
	 * Sets the customer value index pure with credit.
	 * 
	 * @param aCustomerValueIndexPureWithCredit the customerValueIndexPureWithCredit to set
	 */
	public void setCustomerValueIndexPureWithCredit(Short aCustomerValueIndexPureWithCredit) {
		this.customerValueIndexPureWithCredit = aCustomerValueIndexPureWithCredit;
	}

	/**
	 * Gets the customer value index pure without credit.
	 * 
	 * @return the customerValueIndexPureWithoutCredit
	 */
	public Short getCustomerValueIndexPureWithoutCredit() {
		return this.customerValueIndexPureWithoutCredit;
	}

	/**
	 * Sets the customer value index pure without credit.
	 * 
	 * @param aCustomerValueIndexPureWithoutCredit the customerValueIndexPureWithoutCredit to set
	 */
	public void setCustomerValueIndexPureWithoutCredit(Short aCustomerValueIndexPureWithoutCredit) {
		this.customerValueIndexPureWithoutCredit = aCustomerValueIndexPureWithoutCredit;
	}

	/**
	 * Gets the retention score pure with credit.
	 * 
	 * @return the retentionScorePureWithCredit
	 */
	public Short getRetentionScorePureWithCredit() {
		return this.retentionScorePureWithCredit;
	}

	/**
	 * Sets the retention score pure with credit.
	 * 
	 * @param aRetentionScorePureWithCredit the retentionScorePureWithCredit to set
	 */
	public void setRetentionScorePureWithCredit(Short aRetentionScorePureWithCredit) {
		this.retentionScorePureWithCredit = aRetentionScorePureWithCredit;
	}

	/**
	 * Gets the retention score pure without credit.
	 * 
	 * @return the retentionScorePureWithoutCredit
	 */
	public Short getRetentionScorePureWithoutCredit() {
		return this.retentionScorePureWithoutCredit;
	}

	/**
	 * Sets the retention score pure without credit.
	 * 
	 * @param aRetentionScorePureWithoutCredit the retentionScorePureWithoutCredit to set
	 */
	public void setRetentionScorePureWithoutCredit(Short aRetentionScorePureWithoutCredit) {
		this.retentionScorePureWithoutCredit = aRetentionScorePureWithoutCredit;
	}

	/**
	 * Gets the rsp scoring.
	 * 
	 * @return the rspScoring
	 */
	public Byte getRspScoring() {
		return this.rspScoring;
	}

	/**
	 * Sets the rsp scoring.
	 * 
	 * @param aRspScoring the rspScoring to set
	 */
	public void setRspScoring(Byte aRspScoring) {
		this.rspScoring = aRspScoring;
	}

	/**
	 * Gets the vehicle rate group accident benefit.
	 * 
	 * @return the vehicleRateGroupAccidentBenefit
	 */
	public String getVehicleRateGroupAccidentBenefit() {
		return this.vehicleRateGroupAccidentBenefit;
	}

	/**
	 * Set the vehiculeRateGroup on the data member corresponding to a:
	 * 
	 * Province+DistributionChannel+coverageCode
	 * 
	 * Note that at this very moment the coverage code used are already unique by province and Distribution channel..
	 * and this implementation is using the coverage code only...
	 * 
	 * @param coveragecode the coveragecode
	 * @param aVehicleRateGroupCode the vehicle rate group code
	 */
	public void setSpecificRateGroup(String coveragecode, String aVehicleRateGroupCode) {

		if (BasicCoverageCodeEnum.ACCIDENT_BENEFITS_P1.getCode().equals(coveragecode)) {
			setVehicleRateGroupMedicalExpenses(aVehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.OPTIONAL_INCOME_REPLACEMENT_P2.getCode().equals(coveragecode)) {
			setVehicleRateGroupTotalDisability(aVehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.LIABILITY_A.getCode().equals(coveragecode)) {
			setVehicleRateGroupLiability(aVehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.ALL_PERILS_B1.getCode().equals(coveragecode)
				|| BasicCoverageCodeEnum.ALL_PERILS_C1.getCode().equals(coveragecode)) {
			setVehicleRateGroupAllPerils(aVehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.COLLISION_B2.getCode().equals(coveragecode)
				|| BasicCoverageCodeEnum.COLLISION_C2.getCode().equals(coveragecode)) {
			setVehicleRateGroupCollision(aVehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.COMPREHENSIVE_B3.getCode().equals(coveragecode)
				|| BasicCoverageCodeEnum.COMPREHENSIVE_C3.getCode().equals(coveragecode)) {
			setVehicleRateGroupComprehensive(aVehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.SPECIFIED_PERILS_B4.getCode().equals(coveragecode)
				|| BasicCoverageCodeEnum.SPECIFIED_PERILS_C4.getCode().equals(coveragecode)) {
			setVehicleRateGroupSpecifiedPerils(aVehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.ACCIDENT_BENEFITS_B.getCode().equals(coveragecode)) {
			setVehicleRateGroupAccidentBenefit(aVehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.LIABILITY_BODILY_INJURY_A1.getCode().equals(coveragecode)) {
			setVehicleRateGroupLiabilityBodilyInjury(aVehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.DIRECT_COMP_PROPERTY_DAM_A2.getCode().equals(coveragecode)) {
			setVehicleRateGroupLiabilityPropertyDamage(aVehicleRateGroupCode);
		}
	}

	/**
	 * Sets the vehicle rate group accident benefit.
	 * 
	 * @param aVehicleRateGroupAccidentBenefit the vehicleRateGroupAccidentBenefit to set
	 */
	public void setVehicleRateGroupAccidentBenefit(String aVehicleRateGroupAccidentBenefit) {
		this.vehicleRateGroupAccidentBenefit = aVehicleRateGroupAccidentBenefit;
	}

	/**
	 * Gets the vehicle rate group all perils.
	 * 
	 * @return the vehicleRateGroupAllPerils
	 */
	public String getVehicleRateGroupAllPerils() {
		return this.vehicleRateGroupAllPerils;
	}

	/**
	 * Sets the vehicle rate group all perils.
	 * 
	 * @param aVehicleRateGroupAllPerils the vehicleRateGroupAllPerils to set
	 */
	public void setVehicleRateGroupAllPerils(String aVehicleRateGroupAllPerils) {
		this.vehicleRateGroupAllPerils = aVehicleRateGroupAllPerils;
	}

	/**
	 * Gets the vehicle rate group collision.
	 * 
	 * @return the vehicleRateGroupCollision
	 */
	public String getVehicleRateGroupCollision() {
		return this.vehicleRateGroupCollision;
	}

	/**
	 * Sets the vehicle rate group collision.
	 * 
	 * @param aVehicleRateGroupCollision the vehicleRateGroupCollision to set
	 */
	public void setVehicleRateGroupCollision(String aVehicleRateGroupCollision) {
		this.vehicleRateGroupCollision = aVehicleRateGroupCollision;
	}

	/**
	 * Gets the vehicle rate group comprehensive.
	 * 
	 * @return the vehicleRateGroupComprehensive
	 */
	public String getVehicleRateGroupComprehensive() {
		return this.vehicleRateGroupComprehensive;
	}

	/**
	 * Sets the vehicle rate group comprehensive.
	 * 
	 * @param aVehicleRateGroupComprehensive the vehicleRateGroupComprehensive to set
	 */
	public void setVehicleRateGroupComprehensive(String aVehicleRateGroupComprehensive) {
		this.vehicleRateGroupComprehensive = aVehicleRateGroupComprehensive;
	}

	/**
	 * Gets the vehicle rate group liability.
	 * 
	 * @return the vehicleRateGroupLiability
	 */
	public String getVehicleRateGroupLiability() {
		return this.vehicleRateGroupLiability;
	}

	/**
	 * Sets the vehicle rate group liability.
	 * 
	 * @param aVehicleRateGroupLiability the vehicleRateGroupLiability to set
	 */
	public void setVehicleRateGroupLiability(String aVehicleRateGroupLiability) {
		this.vehicleRateGroupLiability = aVehicleRateGroupLiability;
	}

	/**
	 * Gets the vehicle rate group liability bodily injury.
	 * 
	 * @return the vehicleRateGroupLiabilityBodilyInjury
	 */
	public String getVehicleRateGroupLiabilityBodilyInjury() {
		return this.vehicleRateGroupLiabilityBodilyInjury;
	}

	/**
	 * Sets the vehicle rate group liability bodily injury.
	 * 
	 * @param aVehicleRateGroupLiabilityBodilyInjury the vehicleRateGroupLiabilityBodilyInjury to set
	 */
	public void setVehicleRateGroupLiabilityBodilyInjury(String aVehicleRateGroupLiabilityBodilyInjury) {
		this.vehicleRateGroupLiabilityBodilyInjury = aVehicleRateGroupLiabilityBodilyInjury;
	}

	/**
	 * Gets the vehicle rate group liability property damage.
	 * 
	 * @return the vehicleRateGroupLiabilityPropertyDamage
	 */
	public String getVehicleRateGroupLiabilityPropertyDamage() {
		return this.vehicleRateGroupLiabilityPropertyDamage;
	}

	/**
	 * Sets the vehicle rate group liability property damage.
	 * 
	 * @param aVehicleRateGroupLiabilityPropertyDamage the vehicleRateGroupLiabilityPropertyDamage to set
	 */
	public void setVehicleRateGroupLiabilityPropertyDamage(String aVehicleRateGroupLiabilityPropertyDamage) {
		this.vehicleRateGroupLiabilityPropertyDamage = aVehicleRateGroupLiabilityPropertyDamage;
	}

	/**
	 * Gets the vehicle rate group medical expenses.
	 * 
	 * @return the vehicleRateGroupMedicalExpenses
	 */
	public String getVehicleRateGroupMedicalExpenses() {
		return this.vehicleRateGroupMedicalExpenses;
	}

	/**
	 * Sets the vehicle rate group medical expenses.
	 * 
	 * @param aVehicleRateGroupMedicalExpenses the vehicleRateGroupMedicalExpenses to set
	 */
	public void setVehicleRateGroupMedicalExpenses(String aVehicleRateGroupMedicalExpenses) {
		this.vehicleRateGroupMedicalExpenses = aVehicleRateGroupMedicalExpenses;
	}

	/**
	 * Gets the vehicle rate group specified perils.
	 * 
	 * @return the vehicleRateGroupSpecifiedPerils
	 */
	public String getVehicleRateGroupSpecifiedPerils() {
		return this.vehicleRateGroupSpecifiedPerils;
	}

	/**
	 * Sets the vehicle rate group specified perils.
	 * 
	 * @param aVehicleRateGroupSpecifiedPerils the vehicleRateGroupSpecifiedPerils to set
	 */
	public void setVehicleRateGroupSpecifiedPerils(String aVehicleRateGroupSpecifiedPerils) {
		this.vehicleRateGroupSpecifiedPerils = aVehicleRateGroupSpecifiedPerils;
	}

	/**
	 * Gets the vehicle rate group total disability.
	 * 
	 * @return the vehicleRateGroupTotalDisability
	 */
	public String getVehicleRateGroupTotalDisability() {
		return this.vehicleRateGroupTotalDisability;
	}

	/**
	 * Sets the vehicle rate group total disability.
	 * 
	 * @param aVehicleRateGroupTotalDisability the vehicleRateGroupTotalDisability to set
	 */
	public void setVehicleRateGroupTotalDisability(String aVehicleRateGroupTotalDisability) {
		this.vehicleRateGroupTotalDisability = aVehicleRateGroupTotalDisability;
	}

	/**
	 * Gets the rating risk offers.
	 * 
	 * @return the ratingRiskOffers
	 */
	@XmlElementWrapper(name = "ratingRiskOffers")
	@XmlElement(name = "ratingRiskOffer")
	public Set<RatingRiskOffer> getRatingRiskOffers() {
		return Collections.unmodifiableSet(this.ratingRiskOffers);
	}

	/**
	 * the rating risk offers to set.
	 * 
	 * @param aRatingRiskOffers the a rating risk offers
	 */
	protected void setRatingRiskOffers(Set<RatingRiskOffer> aRatingRiskOffers) {
		this.ratingRiskOffers = aRatingRiskOffers;
	}

	/**
	 * add a RatingRiskOffer on this insuranceRiskOffer.
	 * 
	 * @param anOffer the an offer
	 * 
	 * @see com.ing.canada.plp.domain.AssociationsHelper#updateOneToManyField(Object, String, Object, String)
	 */
	public void addRatingRiskOffer(RatingRiskOffer anOffer) {
		AssociationsHelper.updateOneToManyFields(this, "ratingRiskOffers", anOffer, "insuranceRiskOffer");
	}

	/**
	 * remove a RatingRiskOffer from this insuranceRiskOffer.
	 * 
	 * @param anOffer the an offer
	 * 
	 * @see com.ing.canada.plp.domain.AssociationsHelper#updateOneToManyField(Object, String, Object, String)
	 */
	public void removeRatingRiskOffer(RatingRiskOffer anOffer) {
		AssociationsHelper.updateOneToManyFields(null, "ratingRiskOffers", anOffer, "insuranceRiskOffer");
	}

	/**
	 * Gets the vehicle rate group code.
	 * 
	 * @return the vehicle rate group code
	 */
	public String getVehicleRateGroupCode() {
		return this.vehicleRateGroupCode;
	}

	/**
	 * Sets the vehicle rate group code.
	 * 
	 * @param aVehicleRateGroupCode the new vehicle rate group code
	 */
	public void setVehicleRateGroupCode(String aVehicleRateGroupCode) {
		this.vehicleRateGroupCode = aVehicleRateGroupCode;
	}

	/**
	 * Gets the caa discount applied indicator.
	 * 
	 * @return the caa discount applied indicator
	 */
	public Boolean getCaaDiscountAppliedIndicator() {
		return this.caaDiscountAppliedIndicator;
	}

	/**
	 * Sets the caa discount applied indicator.
	 * 
	 * @param aCaaDiscountAppliedIndicator the new caa discount applied indicator
	 */
	public void setCaaDiscountAppliedIndicator(Boolean aCaaDiscountAppliedIndicator) {
		this.caaDiscountAppliedIndicator = aCaaDiscountAppliedIndicator;
	}

	/**
	 * Gets the selected for policy offer rating indicator.
	 * 
	 * @return the selected for policy offer rating indicator
	 */
	public Boolean getSelectedForPolicyOfferRatingIndicator() {
		return this.selectedForPolicyOfferRatingIndicator;
	}

	/**
	 * Sets the selected for policy offer rating indicator. This as to be either null or true, false is not an
	 * acceptable value.
	 * 
	 * @param aSelectedForPolicyOfferRatingIndicator the new selected for policy offer rating indicator
	 */
	public void setSelectedForPolicyOfferRatingIndicator(Boolean aSelectedForPolicyOfferRatingIndicator) {
		if (BooleanUtils.isFalse(aSelectedForPolicyOfferRatingIndicator)) {
			throw new IllegalArgumentException("SelectedForPolicyOfferRatingIndicator cannot be false");
		}

		this.selectedForPolicyOfferRatingIndicator = aSelectedForPolicyOfferRatingIndicator;
	}

	/**
	 * Gets the recalculatable offer indicator.
	 * 
	 * @return the recalculatable offer indicator
	 */
	public Boolean getRecalculatableOfferIndicator() {
		return this.recalculatableOfferIndicator;
	}

	/**
	 * Sets the recalculatable offer indicator.
	 * 
	 * @param aRecalculatableOfferIndicator the new recalculatable offer indicator
	 */
	public void setRecalculatableOfferIndicator(Boolean aRecalculatableOfferIndicator) {
		this.recalculatableOfferIndicator = aRecalculatableOfferIndicator;
	}

	/**
	 * Gets the internal technical offer type.
	 * 
	 * @return the internal technical offer type
	 */
	public InternalTechnicalOfferTypeCodeEnum getInternalTechnicalOfferType() {
		return this.internalTechnicalOfferType;
	}

	/**
	 * Sets the internal technical offer type.
	 * 
	 * @param aInternalTechnicalOfferType the new internal technical offer type
	 */
	public void setInternalTechnicalOfferType(InternalTechnicalOfferTypeCodeEnum aInternalTechnicalOfferType) {
		this.internalTechnicalOfferType = aInternalTechnicalOfferType;
	}

	/**
	 * Gets the diagnostic advices.
	 * 
	 * @return the diagnostic advices
	 */
	@XmlElementWrapper(name = "diagnosticAdvices")
	@XmlElement(name = "diagnosticAdvice")
	public Set<DiagnosticAutomatedAdvice> getDiagnosticAdvices() {
		return this.diagnosticAdvices;
	}

	/**
	 * Sets the diagnostic advices.
	 * 
	 * @param aDiagnosticAdvices the new diagnostic advices
	 */
	public void setDiagnosticAdvices(Set<DiagnosticAutomatedAdvice> aDiagnosticAdvices) {
		this.diagnosticAdvices = aDiagnosticAdvices;
	}

	public Short getCustomerValueIndexAdjustedWithCredit() {
		return this.customerValueIndexAdjustedWithCredit;
	}

	public void setCustomerValueIndexAdjustedWithCredit(Short aCustomerValueIndexAdjustedWithCredit) {
		this.customerValueIndexAdjustedWithCredit = aCustomerValueIndexAdjustedWithCredit;
	}

	/**
	 * Gets the optional accident benefits indicator.
	 * 
	 * @return the optional accident benefits indicator
	 */
	public Boolean getOptionalAccidentBenefitsIndicator() {
		return this.optionalAccidentBenefitsIndicator;
	}

	/**
	 * Sets the optional accident benefits indicator.
	 * 
	 * @param aOptionalAccidentBenefitsIndicator the new optional accident benefits indicator
	 */
	public void setOptionalAccidentBenefitsIndicator(Boolean aOptionalAccidentBenefitsIndicator) {
		this.optionalAccidentBenefitsIndicator = aOptionalAccidentBenefitsIndicator;
	}

	public Date getSystemCreateTS() {
		return systemCreateTS;
	}

	public void setSystemCreateTS(Date systemCreateTS) {
		this.systemCreateTS = systemCreateTS;
	}
}
