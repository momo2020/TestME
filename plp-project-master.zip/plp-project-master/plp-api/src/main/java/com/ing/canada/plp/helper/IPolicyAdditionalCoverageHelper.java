/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import java.util.Set;

import com.ing.canada.plp.domain.enums.CoverageGroupCodeEnum;
import com.ing.canada.plp.domain.enums.EndorsementCodeEnum;
import com.ing.canada.plp.domain.policyversion.PolicyAdditionalCoverage;

/**
 * The Interface IPolicyAdditionalCoverageHelper.
 * 
 * @author strichar
 */
public interface IPolicyAdditionalCoverageHelper {

	/**
	 * Gets the endorsement.
	 * 
	 * @param aCoverageGroupCodeEnum the a endorsement group code enum
	 * @param aCoverageSet the a coverage set
	 * 
	 * @return the endorsement
	 */
	Set<PolicyAdditionalCoverage> getEndorsement(Set<PolicyAdditionalCoverage> aCoverageSet,
			CoverageGroupCodeEnum aCoverageGroupCodeEnum);

	/**
	 * Checks if endorsement is present.
	 * 
	 * @param aEndorsementCodeEnum the a endorsement code enum
	 * @param aCoverageSet the a coverage set
	 * 
	 * @return true, if successful
	 */
	PolicyAdditionalCoverage getEndorsement(Set<PolicyAdditionalCoverage> aCoverageSet,
			EndorsementCodeEnum aEndorsementCodeEnum);

	/**
	 * @param aPolicyAdditionalCoverages
	 * @param aS55
	 * @return
	 */
	boolean isEndorsementPresent(Set<PolicyAdditionalCoverage> aPolicyAdditionalCoverages, EndorsementCodeEnum aCode);
}
