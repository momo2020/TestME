package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.exception.BrokerServiceException;
import com.ing.canada.plp.service.broker.util.Policy;
import com.ing.canada.plp.service.broker.util.QuoteBroker;
import com.ing.canada.plp.service.broker.util.QuoteNote;
import com.ing.canada.plp.service.broker.util.QuoteReassign;
import com.ing.canada.plp.service.broker.util.QuoteUpload;
import com.ing.canada.plp.service.util.UserContext;

public interface IBrokerService {
 
	public List<String> getBrokersList(UserContext context, QuoteBroker criteria) throws BrokerServiceException;
  
	public void reassignQuotes(UserContext context, QuoteReassign reassign) throws BrokerServiceException;

	public void addQuoteNote(UserContext context, QuoteNote note) throws BrokerServiceException;

}
