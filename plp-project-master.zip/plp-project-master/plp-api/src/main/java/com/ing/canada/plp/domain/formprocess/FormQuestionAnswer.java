package com.ing.canada.plp.domain.formprocess;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.usertype.BaseEntity;

@Entity
@Table(name = "FORM_QUESTION_ANSWER", uniqueConstraints = {})
public class FormQuestionAnswer extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "FORM_QUESTION_ANSWER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "FormQuestSequence")
	@SequenceGenerator(name = "FormQuestSequence", sequenceName = "FORM_QUESTION_ANSWER_SEQ", allocationSize = 5)
	private Long id = null;

	@Column(name = "QUESTION_TXT", length = 100)
	private String question;

	@Column(name = "ANSWER_TXT", length = 250)
	private String answer;

	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "FORM_REQUEST_ID")
	private FormRequest formRequest;

	@Override
	public Object getId() {
		return this.id;
	}

	@Override
	public void setId(Object id) {
		this.id = (Long) id;
	}

	public FormRequest getFormRequest() {
		return this.formRequest;
	}

	public void setFormRequest(FormRequest aFormRequest) {
		AssociationsHelper.updateOneToManyFields(aFormRequest, "formQuestionAnswers", this, "formRequest");
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getAnswer() {
		return this.answer;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getQuestion() {
		return this.question;
	}

}
