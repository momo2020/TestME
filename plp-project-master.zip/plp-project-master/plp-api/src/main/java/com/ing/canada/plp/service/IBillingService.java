/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.billing.Billing;

/**
 * This interface exposes services required to manage Billing related entities.
 * 
 * @author fsimard
 */
public interface IBillingService extends ICRUDService<Billing> {
    // NOOP
}
