/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.vehicle;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * VehicleRepositoryEntry entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "VEHICLE_REPOSITORY_ENTRY", uniqueConstraints = {})
public class VehicleRepositoryEntry extends BaseEntity {

	protected static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "VEHICLE_REPOSITORY_ENTRY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "VehicleRepositoryEntrySequence")
	@SequenceGenerator(name = "VehicleRepositoryEntrySequence", sequenceName = "VEHICLE_REPOSITORY_ENTRY_SEQ", allocationSize = 5)
	protected Long id;

	/** The vehicle make. */
	@Column(name = "VEHICLE_MAKE_ENG_TXT", nullable = false, length = 20)
	protected String vehicleMakeEnglish;

	/** The vehicle make. */
	@Column(name = "VEHICLE_MAKE_FRE_TXT", nullable = false, length = 20)
	protected String vehicleMakeFrench;

	/** The vehicle model. */
	@Column(name = "VEHICLE_MODEL_ENG_TXT", nullable = false, length = 40)
	protected String vehicleModelEnglish;

	/** The vehicle model. */
	@Column(name = "VEHICLE_MODEL_FRE_TXT", nullable = false, length = 40)
	protected String vehicleModelFrench;

	/** The vehicle code. */
	@Column(name = "VEHICLE_CD", nullable = false, length = 6)
	protected String vehicleCode;

	/** The vehicle make and model abbreviation. */
	@Column(name = "VEH_MAKE_MODEL_ABRVTN_ENG_TXT", length = 20)
	protected String vehicleMakeAndModelAbbreviationEnglish;

	/** The vehicle make and model abbreviation. */
	@Column(name = "VEH_MAKE_MODEL_ABRVTN_FRE_TXT", length = 20)
	protected String vehicleMakeAndModelAbbreviationFrench;

	/** The vehicle detail spec repository entries. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "vehicleRepositoryEntry")
	@LazyCollection(LazyCollectionOption.EXTRA)
	protected Set<VehicleDetailSpecificationRepositoryEntry> vehicleDetailSpecificationRepositoryEntries = new HashSet<VehicleDetailSpecificationRepositoryEntry>(0);

	/**
	 * Instantiates a new vehicle repository entry.
	 */
	public VehicleRepositoryEntry() {
		// noarg constructor
	}

	/**
	 * Instantiates a new vehicle repository entry.
	 * 
	 * @param anEnglishMake the a vehicle make english description
	 * @param aFrenchMake the a vehicle make french description
	 * @param anEnglishModel the a vehicle model english description
	 * @param aFrenchModel the a vehicle model french description
	 * @param aVehicleCode the vehicle code
	 */
	public VehicleRepositoryEntry(String anEnglishMake, String aFrenchMake, String anEnglishModel, String aFrenchModel, String aVehicleCode) {
		setVehicleMakeEnglish(anEnglishMake);
		setVehicleMakeFrench(aFrenchMake);
		setVehicleModelEnglish(anEnglishModel);
		setVehicleModelFrench(aFrenchModel);
		setVehicleCode(aVehicleCode);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the vehicle make.
	 * 
	 * @return the vehicle make
	 */
	public String getVehicleMakeEnglish() {
		return this.vehicleMakeEnglish;
	}

	/**
	 * Sets the vehicle make.
	 * 
	 * @param aVehicleMake the new vehicle make
	 */
	public void setVehicleMakeEnglish(String aVehicleMake) {
		this.vehicleMakeEnglish = aVehicleMake;
	}

	/**
	 * Gets the vehicle model.
	 * 
	 * @return the vehicle model
	 */
	public String getVehicleModelEnglish() {
		return this.vehicleModelEnglish;
	}

	/**
	 * Sets the vehicle model.
	 * 
	 * @param aVehicleModel the new vehicle model
	 */
	public void setVehicleModelEnglish(String aVehicleModel) {
		this.vehicleModelEnglish = aVehicleModel;
	}

	/**
	 * Gets the vehicle code.
	 * 
	 * @return the vehicle code
	 */
	public String getVehicleCode() {
		return this.vehicleCode;
	}

	/**
	 * Sets the vehicle code.
	 * 
	 * @param aVehicleCode the new vehicle code
	 */
	public void setVehicleCode(String aVehicleCode) {
		this.vehicleCode = aVehicleCode;
	}

	/**
	 * Gets the vehicle make and model abbreviation.
	 * 
	 * @return the vehicle make and model abbreviation
	 */
	public String getVehicleMakeAndModelAbbreviationEnglish() {
		return this.vehicleMakeAndModelAbbreviationEnglish;
	}

	/**
	 * Sets the vehicle make and model abbreviation.
	 * 
	 * @param vehicleMakeModelAbrvtn the new vehicle make and model abbreviation
	 */
	public void setVehicleMakeAndModelAbbreviationEnglish(String vehicleMakeModelAbrvtn) {
		this.vehicleMakeAndModelAbbreviationEnglish = vehicleMakeModelAbrvtn;
	}

	/**
	 * Gets the vehicle detail spec repository entries.
	 * 
	 * @return the vehicle detail spec repository entries
	 */
	@XmlTransient // don't bring back complete reference list via XML.
	public Set<VehicleDetailSpecificationRepositoryEntry> getVehicleDetailSpecificationRepositoryEntries() {
		return Collections.unmodifiableSet(this.vehicleDetailSpecificationRepositoryEntries);
	}

	/**
	 * Sets the vehicle detail spec repository entries.
	 * 
	 * @param aVehicleDetailSpecificationRepositoryEntries the new vehicle detail spec repository entries
	 */
	protected void setVehicleDetailSpecificationRepositoryEntries(
			Set<VehicleDetailSpecificationRepositoryEntry> aVehicleDetailSpecificationRepositoryEntries) {
		this.vehicleDetailSpecificationRepositoryEntries = aVehicleDetailSpecificationRepositoryEntries;
	}

	/**
	 * Adds the vehicle detail spec repository entry.
	 * 
	 * @param o the o
	 */
	public void addVehicleDetailSpecificationRepositoryEntry(com.ing.canada.plp.domain.vehicle.VehicleDetailSpecificationRepositoryEntry o) {
		AssociationsHelper.updateOneToManyFields(this, "vehicleDetailSpecificationRepositoryEntries", o, "vehicleRepositoryEntry");
	}

	/**
	 * Removes the vehicle detail spec repository entry.
	 * 
	 * @param o the o
	 */
	public void removeVehicleDetailSpecificationRepositoryEntry(
			com.ing.canada.plp.domain.vehicle.VehicleDetailSpecificationRepositoryEntry o) {
		AssociationsHelper.updateOneToManyFields(null, "vehicleDetailSpecificationRepositoryEntries", o, "vehicleRepositoryEntry");
	}

	/**
	 * Gets the vehicle make french.
	 * 
	 * @return the vehicleMakeFrench
	 */
	public String getVehicleMakeFrench() {
		return this.vehicleMakeFrench;
	}

	/**
	 * Sets the vehicle make french.
	 * 
	 * @param aVehicleMakeFrench the vehicleMakeFrench to set
	 */
	public void setVehicleMakeFrench(String aVehicleMakeFrench) {
		this.vehicleMakeFrench = aVehicleMakeFrench;
	}

	/**
	 * Gets the vehicle model french.
	 * 
	 * @return the vehicleModelFrench
	 */
	public String getVehicleModelFrench() {
		return this.vehicleModelFrench;
	}

	/**
	 * Sets the vehicle model french.
	 * 
	 * @param aVehicleModelFrench the vehicleModelFrench to set
	 */
	public void setVehicleModelFrench(String aVehicleModelFrench) {
		this.vehicleModelFrench = aVehicleModelFrench;
	}

	/**
	 * Gets the vehicle make and model abbreviation french.
	 * 
	 * @return the vehicleMakeAndModelAbbreviationFrench
	 */
	public String getVehicleMakeAndModelAbbreviationFrench() {
		return this.vehicleMakeAndModelAbbreviationFrench;
	}

	/**
	 * Sets the vehicle make and model abbreviation french.
	 * 
	 * @param aVehicleMakeAndModelAbbreviationFrench the vehicleMakeAndModelAbbreviationFrench to set
	 */
	public void setVehicleMakeAndModelAbbreviationFrench(String aVehicleMakeAndModelAbbreviationFrench) {
		this.vehicleMakeAndModelAbbreviationFrench = aVehicleMakeAndModelAbbreviationFrench;
	}

}
