/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.domain.businesstransaction.BusinessTransaction;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransactionSubActivity;
import com.ing.canada.plp.domain.enums.ApplicationFlowStateCodeEnum;
import com.ing.canada.plp.domain.enums.ApplicationIdEnum;
import com.ing.canada.plp.domain.enums.BusinessTransactionActivityCodeEnum;
import com.ing.canada.plp.domain.enums.BusinessTransactionSubActivityCodeEnum;
import com.ing.canada.plp.domain.enums.TransactionStatusCodeEnum;
import com.ing.canada.plp.domain.enums.UserTypeCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer;
import com.ing.canada.plp.domain.insuranceriskoffer.PolicyOfferRating;

/**
 * This interface exposes services required to manage BusinessTransaction related entities.
 * 
 * @author fsimard
 */
public interface IBusinessTransactionService extends ICRUDService<BusinessTransaction> {
	
	public BusinessTransaction save(BusinessTransaction transaction);

	/**
	 * This method persist the newly created BusinessTransaction entity and dependent entities.<br>
	 * This service tries to reuse existing MessageRepositoryEntry as much as possible.<br>
	 * If the repository instance attached to the TransactionalMessage is new (no primary key) the service must look for
	 * a corresponding entity in the repository.<br>
	 * If an entity exists it must reused it and associate it to the TransactionalMessage.<br>
	 * Otherwise it must save the new MessageRepositoryEntry entity.
	 * 
	 * @param entity the entity
	 * 
	 * @return the business transaction
	 * 
	 * @see com.ing.canada.plp.service.IBaseService#persist(com.ing.canada.plp.domain.usertype.BaseEntity)
	 */
	@Override
	BusinessTransaction persist(BusinessTransaction entity);

	/**
	 * 
	 * @param id
	 * @return BusinessTransactionSubActivity
	 */
	BusinessTransactionSubActivity findBusinessTransactionSubActivityById(long id);

	/**
	 * 
	 * @param entity
	 * @return BusinessTransactionSubActivity
	 */
	BusinessTransactionSubActivity persist(BusinessTransactionSubActivity entity);

	/**
	 * this method call retrieve the entity referenced in the business sub-activity.
	 * 
	 * @param subActivity
	 * @return The entity referenced by the root reference id of the sub-activity.
	 */
	Object retrieveBusinessSubActivityRootReferenceEntity(BusinessTransactionSubActivity subActivity);

	/**
	 * {@inheritDoc}
	 */
	BusinessTransactionSubActivity retrieveFirstModificationSubActivity(BusinessTransaction bt);
	
	/**
	 * Return the first activity of having the offer
	 * @param bt
	 * @return
	 */
	BusinessTransactionSubActivity retrieveFirstOfferSubActivity(BusinessTransaction bt);

	/**
	 * {@inheritDoc}
	 */
	List<BusinessTransactionSubActivity> retrieveRecalculationSubActivity(BusinessTransaction bt);

	/**
	 * This method is used to create a BusinessTransactionActivity.
	 * 
	 * @param code the code
	 * @param policyId the policy id
	 * @param userId the user id
	 * @param userType the user type
	 * @param anApplication the an application
	 * 
	 * @return the long
	 */
	Long createActivity(BusinessTransactionActivityCodeEnum code, long policyId, String userId,
			UserTypeCodeEnum userType, ApplicationIdEnum anApplication);

	/**
	 * This method is used to create a BusinessTransactionActivity.
	 * 
	 * @param code the code
	 * @param policyId the policy id
	 * @param userId the user id
	 * @param mainFrameuserId the mainFrame user id
	 * @param userType the user type
	 * @param anApplication the an application
	 * 
	 * @return the long
	 */
	Long createActivity(BusinessTransactionActivityCodeEnum code, long policyId, String userId, String mainframeUserId,
			UserTypeCodeEnum userType, ApplicationIdEnum anApplication);

	/**
	 * This method is used to update the BusinessTransaction Status.
	 * 
	 * @param status
	 * @param policyId
	 */
	void updateBusinessTransactionStatus(TransactionStatusCodeEnum status, long policyId);

	/**
	 * This method is used to perssit the previous and current state from the state machine.
	 * 
	 * @param current
	 * @param policyId
	 */
	void saveBusinessTransactionAppFlowState(ApplicationFlowStateCodeEnum current, long policyId);

	/**
	 * This method is used to create a new <tt>BusinessTransactionSubActivity</tt>.
	 * 
	 * @param event the event
	 * @param policyVersionId the policy version id
	 * @param rootReferenceId the root reference id
	 * 
	 * @return the long
	 */
	Long createSubActivity(BusinessTransactionSubActivityCodeEnum event, Long policyVersionId, Long rootReferenceId);

	/**
	 * This method is used to create a complement info on defined sub activity code. (e.g roadBlock)
	 * 
	 * @param complInfoCode the compl info code
	 * @param complInfoValue the compl info value
	 * @param businessTransSubActId the business trans sub act id
	 * 
	 * @return the long
	 */
	Long createSubActivityComplInfo(String complInfoCode, String complInfoValue, Long businessTransSubActId);

	/**
	 * This method is used to create a BusinessTransactionActivity forced by the application.
	 * 
	 * @param code
	 * @param policyId
	 * @return the activity id
	 */
	Long createSystemActivity(BusinessTransactionActivityCodeEnum code, long policyId);

	/**
	 * Check if the insuranceRiskOffer pass have a subactivity logged for it.
	 * 
	 * @param aRiskOffer
	 * @return true if the sub activity is logged for that insurance risk offer
	 */
	boolean isModifyCoverageLoggedForInsuranceRiskOffer(InsuranceRiskOffer aRiskOffer);
	
	/**
	 * Check if the policy offer ratign have a subactivity logged for it.
	 * 
	 * @param aPolicyOfferRating
	 * @return true if the sub activity is logged for that policy offer rating
	 */
	boolean isDiagnosticsLoggedForPolicyOfferRating(PolicyOfferRating aPolicyOfferRating);
		
	
	
	/**
	 * 
	 * @param subActivity
	 * @param id 
	 * @return
	 */
	Object retrieveBusinessSubActivityRootReferenceDescription(BusinessTransactionSubActivity subActivity);
	
	Object retrieveBusinessSubActivityRootReferenceDescription(BusinessTransactionSubActivity subActivity, Long id);
	
	/**
	 * Retrieves the last <tt>GOF</tt> or <tt>RECAL_PREMIUM</tt> sub activity of the specified
	 * <tt>POlicyVersion</tt>.
	 * 
	 * @param pv
	 * @return the last rating <tt>BusinessTransactionSubActivity</tt> or null, if the policy version was never rated.
	 */
	BusinessTransactionSubActivity retrieveLastRatingSubActivity(BusinessTransaction bt);

	
	List<BusinessTransactionSubActivity> retrieveRecalculationAndDiagnosticsSubActivity(BusinessTransaction bt);
	
}
