/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import java.util.List;

import com.ing.canada.plp.domain.insurancepolicy.InsurancePolicy;

/**
 * InsurancePolicyHelper interface.
 * 
 * <p>
 * This is to help by having a helper to facilitate by retrieving pertaining insurancePolicy object models.
 * </p>
 * 
 * @author pmdroz
 */
public interface IInsurancePolicyHelper {


	/**
	 * Determine if the insurancePolicy is BOUND.
	 * 
	 * @param insurancePolicy
	 * @return true if the insurancePolicy is bound.
	 */
	boolean isInsurancePolicyBound(InsurancePolicy insurancePolicy); 

	/**
	 * Determine an insurancePolicy is BOUND in the list.
	 * 
	 * @param insurancePolicyList
	 * @return true if an insurancePolicy is bound in the list.
	 */
	boolean isInsurancePolicyBound(List<InsurancePolicy> insurancePolicyList); 

}
