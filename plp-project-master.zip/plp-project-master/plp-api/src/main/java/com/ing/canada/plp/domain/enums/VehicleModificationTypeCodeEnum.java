/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum VehicleModificationTypeCodeEnum.
 */
public enum VehicleModificationTypeCodeEnum {

	/** The TURBOCHARGER. */
	TURBOCHARGER("TURCHGR"),
	
	/** The SUPERCHARGER. */
	SUPERCHARGER("SUPCHGR"),
	
	/** The NITROUS OXIDE. */
	NITROUS_OXIDE("NITROOX"),
	
	/** The INTERIOR ROLL CAGE. */
	INTERIOR_ROLL_CAGE("INTRCAG"),
	
	/** The MODIFIED GROUND CLEARANCE. */
	MODIFIED_GROUND_CLEARANCE("MODGDCR"),
	
	/** The MODIFIED TIRE CIRCUMFERENCE. */
	MODIFIED_TIRE_CIRCUMFERENCE("MODTIRC"),
	
	/** The MODIFIED TIRES FOR SPEED. */
	SPEED_TIRES("TIRSPED"),
	
	/** The MODIFICATIONS FOR SPEED. */
	MODIFIED_FOR_SPEED("MODENGS"),
	
	/** The OTHER. */
	OTHER("OTH");

	/**
	 * Instantiates a new vehicle modification type code enum.
	 *
	 * @param aCode the a code
	 */
	private VehicleModificationTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 *
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 *
	 * @param value the value
	 *
	 * @return the vehicle modification type code enum
	 */
	public static VehicleModificationTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (VehicleModificationTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
