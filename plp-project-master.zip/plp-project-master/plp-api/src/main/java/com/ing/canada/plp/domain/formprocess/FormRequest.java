package com.ing.canada.plp.domain.formprocess;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

@Entity
@Table(name = "FORM_REQUEST", uniqueConstraints = {})
public class FormRequest extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "FORM_REQUEST_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "FormReqSequence")
	@SequenceGenerator(name = "FormReqSequence", sequenceName = "FORM_REQUEST_SEQ", allocationSize = 5)
	private Long id = null;

	/** MANUFACTURER COMPANY. */
	@Column(name = "MANUFACTURER_COMPANY_CD", length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum") })
	private ManufacturerCompanyCodeEnum manufacturerCompany;

	@Column(name = "BROKER_NBR", length = 12)
	private String brokerNbr;

	@Column(name = "EMAIL_ADDRESS_TXT", length = 79)
	private String email;

	/** form questions answers. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "formRequest")
	private Set<FormQuestionAnswer> formQuestionAnswers = new HashSet<FormQuestionAnswer>(0);

	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "FORM_ID")
	private Form form;

	@Override
	public Object getId() {
		return this.id;
	}

	@Override
	public void setId(Object id) {
		this.id = (Long) id;
	}

	public ManufacturerCompanyCodeEnum getManufacturerCompany() {
		return this.manufacturerCompany;
	}

	public void setManufacturerCompany(ManufacturerCompanyCodeEnum manufacturerCompany) {
		this.manufacturerCompany = manufacturerCompany;
	}

	public String getBrokerNbr() {
		return this.brokerNbr;
	}

	public void setBrokerNbr(String brokerNbr) {
		this.brokerNbr = brokerNbr;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Set<FormQuestionAnswer> getFormQuestionAnswers() {
		return Collections.unmodifiableSet(this.formQuestionAnswers);
	}

	public void setFormQuestionAnswers(Set<FormQuestionAnswer> formQuestionAnswers) {
		this.formQuestionAnswers = formQuestionAnswers;
	}

	public void addFormQuestionAnswer(FormQuestionAnswer aFormQuestionAnswer) {
		AssociationsHelper.updateOneToManyFields(this, "formQuestionAnswers", aFormQuestionAnswer, "formRequest");
	}

	public void removeFormQuestionAnswer(FormQuestionAnswer aFormQuestionAnswer) {
		AssociationsHelper.updateOneToManyFields(null, "formQuestionAnswers", aFormQuestionAnswer, "formRequest");
	}

	public Form getForm() {
		return this.form;
	}

	public void setForm(Form aForm) {
		AssociationsHelper.updateOneToManyFields(aForm, "formRequests", this, "form");
	}

}
