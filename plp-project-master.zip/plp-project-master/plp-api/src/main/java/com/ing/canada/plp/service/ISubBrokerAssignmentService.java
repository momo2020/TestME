package com.ing.canada.plp.service;

import java.util.Date;
import java.util.List;
import com.ing.canada.plp.domain.subbrokerassignment.SubBrokerAssignment;

/**
 * This interface exposes services required to manage SubBrokerAssignment related entities.
 *
 * 
 */ 

public interface ISubBrokerAssignmentService extends ICRUDService<SubBrokerAssignment>{
	
	/**
	 * This method returns all the sub broker assignment to a Broker.
	 * 
	 * @param brokerId the broker id 	  
	 * @return the insurance risk offer
	 * @author stephane elleingand
	 * 
	 */
	
	List<SubBrokerAssignment> findSubBrokerAssignments(Date aDateFrom, Date aDateTo);	
	List<SubBrokerAssignment> getAllSubBrokerAssignments();	
	
	/**
	 *  Get the last subBroker for a policy version
	 */
	SubBrokerAssignment getLastSubBrokerAssignmentForPolicy(Long aPolicyVersionId);	
	
}
