/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.coverage;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.insurancerisk.AdditionalInterestRole;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;

/**
 * Coverage entity.
 * 
 * @author Patrick Lafleur
 * 
 * Modifications: - May 1st, 2008: Renamed methods returning a Boolean/boolean from getBoolean() to isBoolean()
 */
@Entity
@Table(name = "COVERAGE", uniqueConstraints = { @UniqueConstraint(columnNames = { "INSURANCE_RISK_ID",
		"COVERAGE_REPOSITORY_ENTRY_ID" }) })
public class Coverage extends BaseCoverage {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "COVERAGE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "CoverageSequence")
	@SequenceGenerator(name = "CoverageSequence", sequenceName = "COVERAGE_SEQ", allocationSize = 5)
	private Long id;

	/** The insurance risk. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_RISK_ID", nullable = false, updatable = true)
	private InsuranceRisk insuranceRisk;

	/** The coverage premiums. */
	@OneToMany(cascade = {CascadeType.ALL}, fetch = FetchType.LAZY, mappedBy = "coverage")
	private Set<CoveragePremium> coveragePremiums = new HashSet<CoveragePremium>(0);

	/** The additional interest roles. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "coverage")
	private Set<AdditionalInterestRole> additionalInterestRoles = new HashSet<AdditionalInterestRole>(0);

	/**
	 * Instantiates a new coverage.
	 */
	public Coverage() {
		// noarg constructor
	}

	/**
	 * Instantiates a new coverage.
	 * 
	 * @param aCoverageRepositoryEntry the a coverage repository entry
	 * @param aInsuranceRisk the a insurance risk
	 */
	public Coverage(CoverageRepositoryEntry aCoverageRepositoryEntry, InsuranceRisk aInsuranceRisk) {
		setCoverageRepositoryEntry(aCoverageRepositoryEntry);
		setInsuranceRisk(aInsuranceRisk);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the coverage repository entry.
	 * 
	 * @return the coverage repository entry
	 */
	@Override
	public CoverageRepositoryEntry getCoverageRepositoryEntry() {
		return this.coverageRepositoryEntry;
	}

	/**
	 * Gets the insurance risk.
	 * 
	 * @return the insurance risk
	 */
	@XmlTransient
	public InsuranceRisk getInsuranceRisk() {
		return this.insuranceRisk;
	}

	/**
	 * Sets the insurance risk.
	 * 
	 * @param aInsuranceRisk the new insurance risk
	 */
	public void setInsuranceRisk(InsuranceRisk aInsuranceRisk) {
		AssociationsHelper.updateOneToManyFields(aInsuranceRisk, "coverages", this, "insuranceRisk");
	}

	/**
	 * Gets the coverage premiums.
	 * 
	 * @return the coverage premiums
	 */
	@XmlElementWrapper(name="coveragePremiums")
	@XmlElement(name="coveragePremium")
	public Set<CoveragePremium> getCoveragePremiums() {
		return Collections.unmodifiableSet(this.coveragePremiums);
	}

	/**
	 * Sets the coverage premiums.
	 * 
	 * @param aCoveragePremiums the new coverage premiums
	 */
	protected void setCoveragePremiums(Set<CoveragePremium> aCoveragePremiums) {
		this.coveragePremiums = aCoveragePremiums;
	}

	/**
	 * Adds the coverage premium.
	 * 
	 * @param premium the premium
	 */
	public void addCoveragePremium(com.ing.canada.plp.domain.coverage.CoveragePremium premium) {
		AssociationsHelper.updateOneToManyFields(this, "coveragePremiums", premium, "coverage");
	}

	/**
	 * Removes the coverage premium.
	 * 
	 * @param premium the premium
	 */
	public void removeCoveragePremium(com.ing.canada.plp.domain.coverage.CoveragePremium premium) {
		AssociationsHelper.updateOneToManyFields(null, "coveragePremiums", premium, "coverage");
	}

	/**
	 * Gets the additional interest roles.
	 * 
	 * @return the additional interest roles
	 */
	@XmlElementWrapper(name="additionalInterestRoles")
	@XmlElement(name="additionalInterestRole")
	public Set<AdditionalInterestRole> getAdditionalInterestRoles() {
		return Collections.unmodifiableSet(this.additionalInterestRoles);
	}

	/**
	 * Sets the additional interest roles.
	 * 
	 * @param aAdditionalInterestRoles the new additional interest roles
	 */
	protected void setAdditionalInterestRoles(Set<AdditionalInterestRole> aAdditionalInterestRoles) {
		this.additionalInterestRoles = aAdditionalInterestRoles;
	}

	/**
	 * Adds the additional interest role.
	 * 
	 * @param additionalInterestRole the additional interest role
	 */
	public void addAdditionalInterestRole(AdditionalInterestRole additionalInterestRole) {
		AssociationsHelper.updateOneToManyFields(this, "additionalInterestRoles", additionalInterestRole, "coverage");
	}

	/**
	 * Removes the additional interest role.
	 * 
	 * @param additionalInterestRole the additional interest role
	 */
	public void removeAdditionalInterestRole(AdditionalInterestRole additionalInterestRole) {
		AssociationsHelper.updateOneToManyFields(null, "additionalInterestRoles", additionalInterestRole, "coverage");
	}

}
