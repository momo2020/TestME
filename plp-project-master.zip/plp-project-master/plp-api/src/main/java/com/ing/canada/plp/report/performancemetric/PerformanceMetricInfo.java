package com.ing.canada.plp.report.performancemetric;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.ing.canada.plp.domain.usertype.BaseEntity;

@Entity
public class PerformanceMetricInfo extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/** The id. */
	@Id
	private Long id;
	
	@Override
	public Long getId() {		
		return this.id;
	}

	@Override
	public void setId(Object anId) {
		this.id = (Long)anId;		
	}
	
	private BigDecimal quotesIncomplete;
	private BigDecimal quotesComplete;
	
	private BigDecimal purchaseRequestIncomplete;
	private BigDecimal purchaseRequestComplete;
	
	private BigDecimal uploadedQuotesAccepted;
	private BigDecimal uploadedQuotesRefused;
	private BigDecimal uploadedQuotesNotProceed;
	
	private BigDecimal quotesExpired;	
	private BigDecimal quotesTotal;
	
	private BigDecimal followUpNeverContacted;
	private BigDecimal followUpContactNeeded;
	private BigDecimal followUpNoContactNeeded;
	private BigDecimal followUpNoneRequired;
	
	private BigDecimal followUpTotal;
	
	private String subBrokerName;
	private String masterBrokerName;
	private String subBrokerNbr; 
	private String masterBrokerNbr;

	/**
	 * Gets the purchase request complete
	 * @return (BigDecimal)the purchase request complete
	 */
	public BigDecimal getPurchaseRequestComplete() {
		return this.purchaseRequestComplete;
	}

	/**
	 * Sets the purchase request complete
	 * @param somePurchaseRequestComplete the purchase request complete to set
	 */
	public void setPurchaseRequestComplete(BigDecimal somePurchaseRequestComplete) {
		this.purchaseRequestComplete = somePurchaseRequestComplete;
	}

	/**
	 * Gets the purchase request incomplete
	 * @return (BigDecimal) the purchase request incomplete
	 */
	public BigDecimal getPurchaseRequestIncomplete() {
		return this.purchaseRequestIncomplete;
	}

	/**
	 * Sets the purchase request incomplete
	 * @param somePurchaseRequestIncomplete the purchase request incomplete to set
	 */
	public void setPurchaseRequestIncomplete(BigDecimal somePurchaseRequestIncomplete) {
		this.purchaseRequestIncomplete = somePurchaseRequestIncomplete;
	}

	/**
	 * Gets the quotes complete
	 * @return (BigDecimal) the quotes complete
	 */
	public BigDecimal getQuotesComplete() {
		return this.quotesComplete;
	}

	/**
	 * Sets the quotes complete
	 * @param someQuotesComplete the quotes Complete to set
	 */
	public void setQuotesComplete(BigDecimal someQuotesComplete) {
		this.quotesComplete = someQuotesComplete;
	}

	/**
	 * Gets the quotes incomplete
	 * @return (BigDecimal) the quotes incomplete
	 */
	public BigDecimal getQuotesIncomplete() {
		return this.quotesIncomplete;
	}

	/**
	 * Sets the quotes incomplete
	 * @param someQuotesIncomplete quotes incomplete to set
	 */
	public void setQuotesIncomplete(BigDecimal someQuotesIncomplete) {
		this.quotesIncomplete = someQuotesIncomplete;
	}

	/**
	 * Gets the quotes Total
	 * @return (BigDecimal)the quotes Total
	 */
	public BigDecimal getQuotesTotal() {
		return this.quotesTotal;
	}

	/**
	 * Sets the quotes Total
	 * @param someQuotesTotal the quotes Total to set
	 */
	public void setQuotesTotal(BigDecimal someQuotesTotal) {
		this.quotesTotal = someQuotesTotal;
	}

	/**
	 * Gets the uploaded quotes accepted
	 * @return (BigDecimal) the uploaded quotes accepted
	 */
	public BigDecimal getUploadedQuotesAccepted() {
		return this.uploadedQuotesAccepted;
	}

	/**
	 * Sets the uploaded quotes accepted
	 * @param someUploadedQuotesAccepted the uploaded quotes accepted
	 */
	public void setUploadedQuotesAccepted(BigDecimal someUploadedQuotesAccepted) {
		this.uploadedQuotesAccepted = someUploadedQuotesAccepted;
	}

	/**
	 * Gets the uploaded quotes not proceed
	 * @return the uploaded quotes not proceed
	 */
	public BigDecimal getUploadedQuotesNotProceed() {
		return this.uploadedQuotesNotProceed;
	}

	/**
	 * Sets the uploaded quotes not proceed
	 * @param someUploadedQuotesNotProceed
	 */
	public void setUploadedQuotesNotProceed(BigDecimal someUploadedQuotesNotProceed) {
		this.uploadedQuotesNotProceed = someUploadedQuotesNotProceed;
	}

	/** Gets the uploaded quotes refused
	 * @return (BigDecimal) uploaded quotes refused
	 */
	public BigDecimal getUploadedQuotesRefused() {
		return this.uploadedQuotesRefused;
	}

	/**
	 * Sets the uploaded quotes refused
	 * @param someUploadedQuotesRefused the uploaded quotes refused to set
	 */
	public void setUploadedQuotesRefused(BigDecimal someUploadedQuotesRefused) {
		this.uploadedQuotesRefused = someUploadedQuotesRefused;
	}

	/**
	 * Gets the followUp contact needed
	 * @return (BigDecimal) the followUp Contact needed
	 */
	public BigDecimal getFollowUpContactNeeded() {
		return this.followUpContactNeeded;
	}

	/**
	 * Sets the followUp contact needed
	 * @param aFollowUpContactNeeded the followUp contact needed to set
	 */
	public void setFollowUpContactNeeded(BigDecimal aFollowUpContactNeeded) {
		this.followUpContactNeeded = aFollowUpContactNeeded;
	}

	/**
	 * Gets the followUp never contacted
	 * @return (BigDecimal) followUp never contacted
	 */
	public BigDecimal getFollowUpNeverContacted() {
		return this.followUpNeverContacted;
	}

	/**
	 * Sets the followUp never contacted
	 * @param aFollowUpNeverContacted the followUp never contacted to set
	 */
	public void setFollowUpNeverContacted(BigDecimal aFollowUpNeverContacted) {
		this.followUpNeverContacted = aFollowUpNeverContacted;
	}

	/** Gets the followUp no contact needed
	 * @return (BigDecimal) the followUp no contact needed
	 */
	public BigDecimal getFollowUpNoContactNeeded() {
		return this.followUpNoContactNeeded;
	}

	/**
	 * Sets the followUp no contact needed
	 * @param aFollowUpNoContactNeeded the followUp no contact needed to set
	 */
	public void setFollowUpNoContactNeeded(BigDecimal aFollowUpNoContactNeeded) {
		this.followUpNoContactNeeded = aFollowUpNoContactNeeded;
	}
	
	/** Gets the followUp none required
	 * @return (BigDecimal) the followUp none required
	 */
	public BigDecimal getFollowUpNoneRequired() {
		return this.followUpNoneRequired;
	}

	/**
	 * Sets the followUp none required
	 * @param aFollowUpNoneRequired the followUp none required to set
	 */
	public void setFollowUpNoneRequired(BigDecimal aFollowUpNoneRequired) {
		this.followUpNoneRequired = aFollowUpNoneRequired;
	}

	/**
	 * Gets the followUp Total
	 * @return (BigDecimal) the followUp Total
	 */
	public BigDecimal getFollowUpTotal() {
		return this.followUpTotal;
	}

	/**
	 * Sets the followUp Total
	 * @param aFollowUpTotal the followUp Total to set
	 */
	public void setFollowUpTotal(BigDecimal aFollowUpTotal) {
		this.followUpTotal = aFollowUpTotal;
	}

	/**
	 * Gets the master broker name
	 * @return (String) the master broker name
	 */
	public String getMasterBrokerName() {
		return this.masterBrokerName;
	}

	/**
	 * Sets the master broker name
	 * @param aMasterBrokerName the master broker name to set
	 */
	public void setMasterBrokerName(String aMasterBrokerName) {
		this.masterBrokerName = aMasterBrokerName;
	}

	/**
	 * Gets the subBroker name
	 * @return (String) the subBroker name
	 */
	public String getSubBrokerName() {
		return this.subBrokerName;
	}

	/**
	 * Sets the subBroker name
	 * @param aSubBrokerName the subBroker name to set
	 */
	public void setSubBrokerName(String aSubBrokerName) {
		this.subBrokerName = aSubBrokerName;
	}

	/**
	 * Gets the quotes expired
	 * @return (BigDecimal) the quotes expired
	 */
	public BigDecimal getQuotesExpired() {
		return this.quotesExpired;
	}

	/**
	 * Sets the quotes expired 
	 * @param aQuotesExpired the quotes expired to set 
	 */
	public void setQuotesExpired(BigDecimal aQuotesExpired) {
		this.quotesExpired = aQuotesExpired;
	}

	/**
	 * Gets the subBroker number
	 * @return (String) the subBroker number
	 */
	public String getSubBrokerNbr() {
		return this.subBrokerNbr;
	}
	
	/**
	 * Sets the subBroker number
	 * @param aSubBrokerNbr the subBroker number to set
	 */
	
	public void setSubBrokerNbr(String aSubBrokerNbr) {
		this.subBrokerNbr = aSubBrokerNbr;
	}

	/**
	 * Gets the master broker number
	 * @return (String) the master broker number
	 */
	public String getMasterBrokerNbr() {
		return this.masterBrokerNbr;
	}

	/**
	 * Sets master broker number
	 * @param aMasterBrokerNbr the master broker number to set
	 */
	public void setMasterBrokerNbr(String aMasterBrokerNbr) {
		this.masterBrokerNbr = aMasterBrokerNbr;
	}	
	
}
