package com.ing.canada.plp.domain.policychange;

import java.util.HashMap;
import java.util.Map;

public enum CoverageValueTypeEnum {
	
	LIMIT_AMOUNT(500), DEDUCTIBLE_AMOUNT(501), LIMIT_MUTIL_DEATH_AMOUNT(502), LIMIT_MED_EXPENSES_AMOUNT(503);
	
	private int value = 0;
	private static Map<Integer, CoverageValueTypeEnum> coverages = null;
	
	private CoverageValueTypeEnum(int value) {
		this.value = value;
	}
	
	public int getValue() {
		return this.value;
	}

	/**
	 * 
	 * @param value of CoverageValueTypeEnum.
	 * 
	 * @return the CoverageValueTypeEnum
	 */
	public static CoverageValueTypeEnum valueOfCode(int value) {
		
		if (CoverageValueTypeEnum.coverages == null) {
			CoverageValueTypeEnum.coverages = new HashMap<Integer, CoverageValueTypeEnum>();
			CoverageValueTypeEnum.coverages.put(CoverageValueTypeEnum.LIMIT_AMOUNT.value, CoverageValueTypeEnum.LIMIT_AMOUNT);
			CoverageValueTypeEnum.coverages.put(CoverageValueTypeEnum.DEDUCTIBLE_AMOUNT.value, CoverageValueTypeEnum.DEDUCTIBLE_AMOUNT);
			CoverageValueTypeEnum.coverages.put(CoverageValueTypeEnum.LIMIT_MED_EXPENSES_AMOUNT.value, CoverageValueTypeEnum.LIMIT_MED_EXPENSES_AMOUNT);
			CoverageValueTypeEnum.coverages.put(CoverageValueTypeEnum.LIMIT_MUTIL_DEATH_AMOUNT.value, CoverageValueTypeEnum.LIMIT_MUTIL_DEATH_AMOUNT);
		}
		
		return CoverageValueTypeEnum.coverages.get(value);
	}
	
	public String toString() {
		return "" + this.value;
	}
}
