/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.Date;

import com.ing.canada.plp.domain.enums.AdditionalInterestTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;
import com.ing.canada.plp.domain.vehicle.Vehicle;

/**
 * This interface exposes services required to manage Vehicle related entities.
 * 
 * @author fsimard
 */
public interface IVehicleService extends ICRUDService<Vehicle> {

	/**
	 * This method returns the Vehicle of a PolicyVersion having a particular sequence number.<br>
	 * It returns NULL if no vehicle exists.
	 * 
	 * @param policyVersion the policy version
	 * @param sequence the sequence
	 * 
	 * @return the vehicle
	 */
	Vehicle findBySequence(PolicyVersion policyVersion, Short sequence);

	/**
	 * This method persist the newly created Vehicle entity and dependent entities.<br>
	 * This service tries to reuse existing VehicleDetailSpecificationRepositoryEntry as much as possible.<br>
	 * If the repository instance attached to the Vehicle is new (no primary key) the service must look for a
	 * corresponding entity in the repository.<br>
	 * If an entity exists it must reused it and associate it to the vehicle.<br>
	 * Otherwise it must save the new VehicleDetailSpecificationRepositoryEntry entities and dependencies.
	 * 
	 * @param entity the entity
	 * 
	 * @return the vehicle
	 * 
	 * @see com.ing.canada.plp.service.IBaseService#persist(com.ing.canada.plp.domain.usertype.BaseEntity)
	 */
	@Override
	Vehicle persist(Vehicle entity);

	public Vehicle buildNewVehicle(PolicyVersion policy, Date effectiveDate);

	void removeVehicle(PolicyVersion policyVersion, InsuranceRisk risk);

	public void resetSequenceNumber(PolicyVersion policyVersion);

	public void removeInterests(Vehicle vehicle, AdditionalInterestTypeCodeEnum role);
}
