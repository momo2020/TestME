/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.Date;
import java.util.List;

import com.ing.canada.plp.domain.BusinessContext;
import com.ing.canada.plp.domain.DriverInfo;
import com.ing.canada.plp.domain.ManufacturingContext;
import com.ing.canada.plp.domain.VehicleInfo;
import com.ing.canada.plp.domain.businesstransaction.BusinessTransactionActivity;
import com.ing.canada.plp.domain.enums.AgreementTypeCodeEnum;
import com.ing.canada.plp.domain.enums.ApplicationIdEnum;
import com.ing.canada.plp.domain.enums.ApplicationModeEnum;
import com.ing.canada.plp.domain.enums.BusinessTransactionActivityCodeEnum;
import com.ing.canada.plp.domain.enums.BusinessTransactionSubActivityCodeEnum;
import com.ing.canada.plp.domain.enums.DistributionChannelCodeEnum;
import com.ing.canada.plp.domain.enums.InsuranceBusinessCodeEnum;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.PartnershipCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;
import com.ing.canada.plp.domain.enums.TransactionStatusCodeEnum;
import com.ing.canada.plp.domain.enums.UserTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.AdditionalInterestRole;
import com.ing.canada.plp.domain.party.GroupRepositoryEntry;
import com.ing.canada.plp.domain.party.Party;
import com.ing.canada.plp.domain.policyversion.DirectChanDistRepEntry;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;
import com.ing.canada.plp.exception.CloneException;

/**
 * This interface exposes services required to manage PolicyVersion related entities.
 * 
 * @author fsimard
 */
public interface IPolicyVersionService extends ICRUDService<PolicyVersion> {

	/**
	 * Clones a policy version and its peripheral objects. Most objects in the graph are deep copied. Some objects like
	 * repository entries are NOT cloned, the existing reference is kept (shallow copy). Some references may be resetted
	 * to null in the cloned graph, by example the rating objects if the parameter cloneRatingObjects is set to false.
	 * 
	 * @param policyVersion the policy version
	 * @param cloneCoverages the clone coverages
	 * @param cloneOffers the clone offers
	 * @param userType the user type
	 * @param userId the user id
	 * @param applicationId the application id
	 * @param activityCode the activity code
	 * 
	 * @return the cloned policy version
	 * 
	 * @throws CloneException something bad really occured
	 */
	Long clone(PolicyVersion policyVersion, Boolean cloneCoverages, Boolean cloneOffers, UserTypeCodeEnum userType,
			String userId, ApplicationIdEnum applicationId, BusinessTransactionActivityCodeEnum activityCode)
			throws CloneException;

	public PolicyVersion clonePolicy(PolicyVersion policyVersion, Boolean cloneCoverages, Boolean cloneOffers,
			UserTypeCodeEnum userType, String userId, ApplicationIdEnum applicationId,
			BusinessTransactionActivityCodeEnum activityCode) throws CloneException;

	/**
	 * 
	 * Find all the policy version for a specific CIF ID. keep only the last policy version by insurance policy.
	 * 
	 * @param aCifClientId
	 * @return the list of corresponding policyversion
	 */
	List<PolicyVersion> findAllByCIFId(Long aCifClientId);

	/**
	 * 
	 * Find all the policy version for a specific CIF ID and agreement type. keep only the last policy version by
	 * insurance policy.
	 * 
	 * @param aCifClientId
	 * @return the list of corresponding policyversion
	 */
	List<PolicyVersion> findAllByCIFIdAndAgreementType(Long aCifClientId,
			AgreementTypeCodeEnum... aAgreementTypeCodeEnums);

	/**
	 * 
	 * Find all the policy version for a specific CIF ID, partnershipCode and agreement type. keep only the last policy
	 * version by insurance policy.
	 * 
	 * @param aCifClientId
	 * @param PartnershipCode
	 * @return the list of corresponding policyversion
	 */
	List<PolicyVersion> findAllByCIFIdAndAgreementType(Long aCifClientId, PartnershipCodeEnum partnershipCode,
			AgreementTypeCodeEnum... aAgreementTypeCodeEnums);

	/**
	 * This method returns the last version of a PolicyVersion for a specific CIF ID.
	 * 
	 * @param cifId the cif id
	 * 
	 * @return the policy version
	 */
	PolicyVersion findLastByCIFId(Long cifId);

	/**
	 * This method returns the last version of a PolicyVersion for a specific CIF ID and agreement type.
	 * 
	 * @param cifId the cif id
	 * @param agreementType the agreement type
	 * @param anApplicationMode
	 * 
	 * @return the policy version
	 */
	PolicyVersion findLastByCIFIdAndAgreementType(Long cifId, AgreementTypeCodeEnum agreementType,
			ApplicationModeEnum anApplicationMode);

	/**
	 * Find the last by cif, agreement type and partner
	 * 
	 * @param aCifClientId a cif Id
	 * @param anAgreementType the agreement type
	 * @param partnershipCodeEnum the partner
	 * @param anApplicationMode
	 * 
	 * @return a policyVersion properly instanciated
	 */
	PolicyVersion findLastByCIFIdAndAgreementTypeAndPartner(Long aCifClientId, AgreementTypeCodeEnum anAgreementType,
			PartnershipCodeEnum partnershipCodeEnum, ApplicationModeEnum anApplicationMode);

	/**
	 * This method returns the last version of a PolicyVersion for a specific TAM UNIQUE ID.
	 * 
	 * @param tamUniqueId
	 * 
	 * @return the policy version
	 */
	PolicyVersion findLastByTamUniqueId(Long tamUniqueId);

	/**
	 * This method persist a new PolicyVersion and persist as well dependend entities.<br>
	 * The following Service persist methods will also be called in the same transaction:<br>
	 * <ul>
	 * <li>VehicleService</li>
	 * <li>DriverComplementInfoService</li>
	 * <li>BusinessTransactionService</li>
	 * <li>PartyService</li>
	 * <li>InsuranceRiskService</li>
	 * <li>CoverageService</li>
	 * </ul>
	 * 
	 * @param policyVersion the policy version
	 * 
	 * @return the policy version
	 */
	PolicyVersion persistCascadeAll(PolicyVersion policyVersion);

	PolicyVersion savePolicy(PolicyVersion policyVersion);

	/**
	 * This method persist the newly created PolicyVersion entity and dependent entities.<br>
	 * This service tries to reuse existing ProducerRepositoryEntry as much as possible.<br>
	 * If the repository instance attached to the policy version is new (no primary key) the service must look for a
	 * corresponding entity in the repository.<br>
	 * If an entity exists it must reused it and associate it to the policy version.<br>
	 * Otherwise it must save the new ProducerRepositoryEntry entity.<br>
	 * This method must cascade changes to the BusinessTransaction by calling the persist method of the corresponding
	 * service.
	 * 
	 * @param entity the entity
	 * 
	 * @return the policy version
	 * 
	 * @see com.ing.canada.plp.service.IBaseService#persist(com.ing.canada.plp.domain.usertype.BaseEntity)
	 */
	@Override
	PolicyVersion persist(PolicyVersion entity);

	/**
	 * This method must update all driverComplementInfo.driverSequence and make sure there is no �hole� in the sequence.<br>
	 * The sequence must start at 1 and be incremented by one.
	 * 
	 * @param policyVersion the policy version
	 * 
	 * @return the policy version
	 */
	PolicyVersion updateDriverSequences(PolicyVersion policyVersion);

	/**
	 * This method must update all insuranceRisk.insuranceRiskSequence and make sure there is no �hole� in the sequence.<br>
	 * The sequence must start at 1 and be incremented by one.
	 * 
	 * @param policyVersion the policy version
	 * 
	 * @return the policy version
	 */
	PolicyVersion updateInsuranceRiskSequences(PolicyVersion policyVersion);

	/**
	 * DOCUMENT ME.
	 * 
	 * @param policyVersion the policy version
	 * 
	 * @return the policy version
	 */
	PolicyVersion updateClaimSequences(PolicyVersion policyVersion);

	/**
	 * This method returns the corresponding ManufacturingContext entity from the database.
	 * 
	 * @param provinceCode the province code
	 * @param distributionChannelCode the distribution channel code
	 * @param insuranceBusinessCode the insurance business code
	 * @param manufacturerCompanyCodeEnum the manufacturer company code
	 * 
	 * @return the manufacturing context
	 */
	ManufacturingContext findManufacturingContext(ProvinceCodeEnum provinceCode,
			DistributionChannelCodeEnum distributionChannelCode, InsuranceBusinessCodeEnum insuranceBusinessCode,
			ManufacturerCompanyCodeEnum manufacturerCompanyCodeEnum);

	public DirectChanDistRepEntry findDirectChannel(BusinessContext context);

	/**
	 * This method returns the list of driver info report objects for the policy version.<br>
	 * This method will be used for the menu to display the list of drivers with the name, and so on.
	 * 
	 * @param policyVersionId Policy Version id
	 * 
	 * @return List of driver info.
	 */
	List<DriverInfo> getDriverInfoList(Long policyVersionId);

	/**
	 * This method returns the list of driver party objects for the policy version.<br>
	 * 
	 * 
	 * @param policyVersionId Policy Version id
	 * 
	 * @return List of driver party.
	 */
	List<Party> getDriverPartyList(Long policyVersionId);

	/**
	 * This method returns the list of vehicle info report objects for the policy version.<br>
	 * This method will be used for the menu to display the list of vehicle year, make and models.
	 * 
	 * @param policyVersionId Policy Version id
	 * 
	 * @return list of vehicle info.
	 */
	List<VehicleInfo> getVehicleInfoList(Long policyVersionId);

	/**
	 * This method must update vehicle sequence and make sure there is no �hole� in the sequence.<br>
	 * The sequence must start at 1 and be incremented by one.
	 * 
	 * @param policyVersion the policy version
	 * 
	 * @return the policy version
	 */
	PolicyVersion updateVehicleSequences(PolicyVersion policyVersion);

	/**
	 * Returns the the most recent policy version given a policy number and a business transaction activity code.
	 * 
	 * @see BusinessTransactionActivity#getBusinessTransactionActivityCode()
	 * 
	 * @param policyNumber the agreement number
	 * 
	 * @param btActivityCode the business transaction activity code to look for
	 * @return the policy version, if it exists, or <tt>null</tt> otherwise
	 */
	PolicyVersion findLatestByTransactionActivityCodes(String policyNumber, Date aPolicyInceptionDate,
			BusinessTransactionActivityCodeEnum... businessTransactionActivityCodes);

	/**
	 * Returns the the most recent policy version (quote context ONLY) given a policy number and a business transaction
	 * activity code.
	 * 
	 * @see BusinessTransactionActivity#getBusinessTransactionActivityCode()
	 * 
	 * @param policyNumber the agreement number
	 * 
	 * @param btActivityCode the business transaction activity code to look for
	 * @return the policy version, if it exists, or <tt>null</tt> otherwise
	 */
	PolicyVersion findLatestQuoteByTransactionActivityCodes(String policyNumber,
			BusinessTransactionActivityCodeEnum... businessTransactionActivityCodes);
	
	/**
	 * Returns the the most recent policy version (quote context ONLY) given a Universally Unique IDentifier (UUID) and a business transaction
	 * activity code.
	 * 
	 * @see BusinessTransactionActivity#getBusinessTransactionActivityCode()
	 * 
	 * @param uuid the Universally Unique IDentifier (UUID)
	 * 
	 * @param btActivityCode the business transaction activity code to look for
	 * @return the policy version, if it exists, or <tt>null</tt> otherwise
	 */
	PolicyVersion findLatestQuoteByUUIDAndTransactionActivityCodes(String uuid,
			BusinessTransactionActivityCodeEnum... businessTransactionActivityCodes);

	/**
	 * Returns the the most recent policy version of the latest term (inception_date) given a list of business
	 * transaction activity code.
	 * 
	 * @param agreementNumber
	 * @param businessTransactionActivityCodes
	 * @return
	 */
	PolicyVersion findLatestByInceptionDateAndTransactionActivityCodes(String agreementNumber,
			BusinessTransactionActivityCodeEnum... businessTransactionActivityCodes);

	/**
	 * Returns the the most recent policy version of the latest in force term (inception_date) given a list of business
	 * transaction activity code.
	 * 
	 * @param agreementNumber
	 * @param businessTransactionActivityCodes
	 * @return
	 */
	PolicyVersion findLatestInForceByInceptionDateAndTransactionActivityCodes(String agreementNumber,
			BusinessTransactionActivityCodeEnum... businessTransactionActivityCodes);

	/**
	 * Returns the all policy versions given a policy number and a business transaction activity code.
	 * 
	 * @see BusinessTransactionActivity#getBusinessTransactionActivityCode()
	 * 
	 * @param policyNumber the agreement number
	 * 
	 * @param btActivityCode the business transaction activity code to look for
	 * @return the list of policy versions (may be empty if no policies with the given search criteria exist)
	 */
	List<PolicyVersion> findAllByTransactionActivityCodes(String policyNumber,
			BusinessTransactionActivityCodeEnum... btActivityCode);

	List<PolicyVersion> findAllByTransactionStatusCodes(String agreementNumber, TransactionStatusCodeEnum... codes);

	/**
	 * Returns the latest working copy of the policy version identified by <tt>policyNumber</tt> and transaction
	 * sequence number <tt>seqno</tt>.
	 * 
	 * @return the <tt>PolicyVersion</tt> instance or <tt>null</tt> if no such policy exists
	 */
	PolicyVersion findLatestWorkingByTransactionSequenceNumber(String policyNumber, short seqno);

	/**
	 * This method returns ONLY THE additional interest roles attached to the Vehicle of the policy version. A
	 * additional interest role can be attached to any of the followings: - vehicle (insurance_risk) - trailer
	 * (insurance_risk) - party
	 * 
	 * BUT ONLY THE ADDITIONAL INTEREST ROLES ATTACHED TO THE VEHICLE ARE CONSIDERED
	 * 
	 * @param policyVersion
	 * @return
	 */
	List<AdditionalInterestRole> findAllVehicleAdditionalInterestRoles(PolicyVersion policyVersion);

	/**
	 * This method returns all additional interest roles attached to the policy version. A additional interest role can
	 * be attached to any of the followings: - vehicle (insurance_risk) - trailer (insurance_risk) - party
	 * 
	 * @param policyVersion
	 * @return
	 */
	List<AdditionalInterestRole> findAllAdditionalInterestRoles(PolicyVersion policyVersion);

	/**
	 * This method returns the business transaction activity that was created when the policy version was uploaded. NULL
	 * is returned in the following cases: - There no upload information - The upload has been cancelled
	 * 
	 * @param policyVersion
	 * @return business transaction activity
	 */
	BusinessTransactionActivity getUploadBusinessTransactionActivity(PolicyVersion policyVersion);

	/**
	 * This method returns TRUE is the policy version has been uploaded and the upload has not been cancelled since.
	 * 
	 * 
	 * @param policyVersion
	 * @return uploaded (true) or not (false)
	 */
	boolean isUploaded(PolicyVersion policyVersion);

	/**
	 * This method return TRUE if the agreement is purchased.. Even online by the client or in classic by an agent.
	 * 
	 * @param agreementNumber
	 * @return purchased (true) or not (false)
	 */
	boolean isQuotePurchased(String agreementNumber);

	/**
	 * This method return TRUE if the agreement is refused, rejected or abandonned..
	 * 
	 * @param agreementNumber
	 * @return purchased (true) or not (false)
	 */
	boolean isQuoteRejected(String agreementNumber);

	/**
	 * Returns the date of the first business transaction sub-activity of the given type, recorded for the business
	 * transaction with id equal to <tt>businessTransactionId</tt>. If there is no business transaction with that ID or
	 * if no such sub-activity exists, <tt>null</tt> is returned.
	 * 
	 * @param businessTransactionId
	 * @param subActivityCode
	 * @return the <tt>Date</tt> object, or <tt>null</tt> if the object is not found
	 */
	Date getFirstDateOfBusinessTransactionSubActivity(Long businessTransactionId,
			BusinessTransactionSubActivityCodeEnum subActivityCode);

	/**
	 * Checks whether a policy version is a version created from CLASSIC legacy data.
	 * 
	 * @param policyVersion the <tt>PolicyVersion</tt> to check
	 * @return <tt>true</tt> if the policy version contains at least a business transaction activity marked as VCL;
	 *         <tt>false</tt> otherwise
	 */
	boolean isVersionCreatedFromLegacy(PolicyVersion policyVersion);

	/**
	 * Returns the parent <tt>PolicyVersion</tt> instance from which <tt>policyVersion</tt> was cloned.
	 * 
	 * @param policyVersion the policy version whose parent we're looking for
	 * @return the source from which <tt>policyVersion</tt> was cloned
	 */
	PolicyVersion getCloneSource(PolicyVersion policyVersion);

	/**
	 * Seek all the policy version created in pl where the original is the original the same as the one pass in
	 * parameter. The version pass in parameter can be the vcl version or one of the child.
	 * 
	 * @param policyVersion the version that we want to retreive all the version that have the same vcl
	 * @return all policy version with the vcl version equal to the one pass in parameter
	 */
	List<PolicyVersion> findAllFromVersionCreatedByLegacy(PolicyVersion policyVersion);

	/**
	 * Retrieve all version branch memeber.
	 * 
	 * @param parent the parent that we want to start getting the branch member.
	 * @return
	 */
	List<PolicyVersion> findPolicyVersionBranchMember(PolicyVersion parent);

	/**
	 * Return all the policy version related to a agreeemnt number. Only Root policy version are returned. (Only policy
	 * version cloned from the orginal (VCL) policy version will be returned)
	 * 
	 * @param agreementNumber
	 * @return
	 */
	List<PolicyVersion> findPolicyBranchRootForAgreement(String agreementNumber);

	/**
	 * Return all the policy version that are linked to and insurance policy for a quote, and in a case of a contract,
	 * the policy versions considered as change transaction. Eg. excluding the following business transactions sub
	 * activities:
	 * 
	 * @see BusinessTransactionSubActivityCodeEnum.CLICK_TO_CHAT
	 * @see BusinessTransactionSubActivityCodeEnum.GET_OFFER,
	 * @see BusinessTransactionSubActivityCodeEnum.EMAIL_NOTIF,
	 * @see BusinessTransactionSubActivityCodeEnum.RESET,
	 * @see BusinessTransactionSubActivityCodeEnum.ROADBLOCK
	 * 
	 * @param aInsurancePolicyId
	 * @param aMaxResults the maximum number of policy versions
	 * @return the list of policy version
	 */
	List<PolicyVersion> findPolicyTransactions(Long aInsurancePolicyId, Integer aMaxResults);

	/**
	 * Return all the policy version related to an agreement number.
	 * 
	 * @param agreementNumber
	 * @return
	 */
	List<PolicyVersion> findPolicyBranchForAgreement(String agreementNumber);

	/**
	 * 
	 * @param aPolicyVersion
	 * @return
	 */
	Short getMaxAdditionalInterestSequenceNumber(PolicyVersion aPolicyVersion);

	/**
	 * Return the group repository entry for the affinityGroupRepositoryEntry of the policyVersion.
	 * 
	 * @param policyVersion the policy version
	 * 
	 * @return the group repository entry
	 */
	GroupRepositoryEntry getGroupRepositoryEntry(PolicyVersion policyVersion);

	/**
	 * Return the group repository entry for the affinityGroupRepositoryEntry of the policyVersion. before offer step
	 * 
	 * @param policyVersion the policy version
	 * 
	 * @return the group repository entry
	 */
	GroupRepositoryEntry getGroupRepositoryEntryBeforeOffer(PolicyVersion policyVersion);

	/**
	 * Find the latest in force policy by rating date and given transaction activity codes
	 * 
	 * @param agreementNumber Agreement number
	 * @param codes Transaction activity codes
	 * @return The latest policy version found
	 */
	PolicyVersion findLatestInForceByRatingDateAndTransactionActivityCodes(String agreementNumber,
			BusinessTransactionActivityCodeEnum... codes);

	public PolicyVersion reload(PolicyVersion pv);

	/**
	 * Find all policy_version made with the specified IP number no matter the insurance_policy
	 * 
	 * @param ipNumber
	 * @return
	 */
	List<PolicyVersion> findAllByIPNumber(String ipNumber);

	/**
	 * Counts all policy_version made in the last hour with the specified IP number no matter the insurance_policy
	 * 
	 * @param ipNumber
	 * @return
	 */
	long getNumberByIpNumberInTheLasHour(String ipNumber);

	/**
	 * Counts all policy_version made in the last 24 hours with the specified IP number no matter the insurance_policy
	 * 
	 * @param ipNumber
	 * @return
	 */
	long getNumberByIpNumberInTheLast24Hours(String ipNumber);
}
