/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.party;

import java.util.Date;
import java.util.Locale;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.ManufacturingContext;
import com.ing.canada.plp.domain.enums.LanguageCodeEnum;
import com.ing.canada.plp.domain.enums.PartyGroupTypeCodeEnum;
import com.ing.canada.plp.domain.enums.PartySubGroupTypeCodeEnum;
import com.ing.canada.plp.domain.policyversion.DirectChanDistRepEntry;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * GroupRepositoryEntry entity.
 *
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "GROUP_REPOSITORY_ENTRY", uniqueConstraints = { @UniqueConstraint(columnNames = { "PARTY_GROUP_TYPE_CD",
		"PARTY_GROUP_CD", "PARTY_SUB_GROUP_TYPE_CD", "PARTY_SUB_GROUP_TYPE_CD", "MANUFACTURING_CONTEXT_ID" }) })
@NamedQueries({
		@NamedQuery(name = "GroupRepositoryEntry.findGroupRepositoryEntry", query = " from GroupRepositoryEntry gre"
				+ " where partyGroupType = :partyGroupType"
				+ " and partyGroupCode = :partyGroupCode"
				+ " and partySubGroupType = :partySubGroupType"
				+ " and partySubGroupCode = :partySubGroupCode"
				+ " and manufacturingContext = :manufacturingContext"
				+ " and ((:directChanDistRepEntry is null and directChanDistRepEntry is null) or directChanDistRepEntry = :directChanDistRepEntry)"
				+ " and effectiveDate IS NOT NULL"),
		@NamedQuery(name = "GroupRepositoryEntry.findForInsuredGroup", query = " from GroupRepositoryEntry gre"
				+ " where partyGroupType = :partyGroupType"
				+ " and partyGroupCode = :partyGroupCode"
				+ " and (:partySubGroupType is null or partySubGroupType = :partySubGroupType)"
				+ " and (:partySubGroupCode is null or partySubGroupCode = :partySubGroupCode)"
				+ " and insuredGroup = :insuredGroup"
				+ " and manufacturingContext = :manufacturingContext"
				+ " and ((:directChanDistRepEntry is null and directChanDistRepEntry is null) or directChanDistRepEntry = :directChanDistRepEntry)"
				+ " and effectiveDate IS NOT NULL"),
		@NamedQuery(name = "GroupRepositoryEntry.findGroupRepositoryEntryByPartyGroupType", query = "select gre from GroupRepositoryEntry gre "
				+ " where gre.partyGroupType = :partyGroupType"
				+ " and gre.manufacturingContext = :manufacturingContext"
				+ " and gre.directChanDistRepEntry.code = :distributor"
				+ " and gre.effectiveDate is not null"),
		@NamedQuery(name = "GroupRepositoryEntry.findGroupRepositoryEntryByPartyGroupCode", query = "select distinct gre.partySubGroupCode, gre.partySubGroupDescriptionFrench, gre.partySubGroupDescriptionEnglish from GroupRepositoryEntry gre "
				+ " where gre.partyGroupCode = :partyGroupCode"
				+ " and gre.manufacturingContext = :manufacturingContext"
				+ " and gre.directChanDistRepEntry.code = :distributor"
				+ " and gre.effectiveDate is not null"),
		@NamedQuery(name = "GroupRepositoryEntry.findOccupation", query = "select gre from GroupRepositoryEntry gre "
				+ " where gre.partySubGroupCode = :subPartyGroupCode"
				+ " and gre.partyGroupType = :partyGroupType"
				+ " and gre.manufacturingContext = :manufacturingContext"
				+ " and gre.directChanDistRepEntry.code = :distributor" 
				+ " and gre.effectiveDate is not null") })
public class GroupRepositoryEntry extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "GROUP_REPOSITORY_ENTRY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "GroupRepositoryEntrySequence")
	@SequenceGenerator(name = "GroupRepositoryEntrySequence", sequenceName = "GROUP_REPOSITORY_ENTRY_SEQ", allocationSize = 5)
	private Long id;

	/** The manufacturing context. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "MANUFACTURING_CONTEXT_ID", updatable = true)
	private ManufacturingContext manufacturingContext;

	/** The party group type. */
	@Column(name = "PARTY_GROUP_TYPE_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PartyGroupTypeCodeEnum") })
	private PartyGroupTypeCodeEnum partyGroupType;

	/** The party group code. */
	@Column(name = "PARTY_GROUP_CD", nullable = false, length = 4)
	private String partyGroupCode;

	/** The party group description. */
	@Column(name = "PARTY_GROUP_ENG_DESC", length = 70)
	private String partyGroupDescriptionEnglish;

	/** The party group description. */
	@Column(name = "PARTY_GROUP_FRE_DESC", length = 70)
	private String partyGroupDescriptionFrench;

	/** The party sub group type code. */
	@Column(name = "PARTY_SUB_GROUP_TYPE_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PartySubGroupTypeCodeEnum") })
	private PartySubGroupTypeCodeEnum partySubGroupType;

	/** The party sub group code. */
	@Column(name = "PARTY_SUB_GROUP_CD", length = 4)
	private String partySubGroupCode;

	/** The party sub group description. */
	@Column(name = "PARTY_SUB_GROUP_ENG_DESC", length = 70)
	private String partySubGroupDescriptionEnglish;

	/** The party sub group description. */
	@Column(name = "PARTY_SUB_GROUP_FRE_DESC", length = 70)
	private String partySubGroupDescriptionFrench;

	/** The insured group. */
	@Column(name = "INSURED_GROUP_CD", length = 3)
	private String insuredGroup;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", length = 7)
	private Date effectiveDate;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;

	/** The direct channel distributo repository entry, ie. the distributor */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "DIRECT_CHAN_DIST_REP_ENTRY_ID", nullable = true, updatable = true)
	private DirectChanDistRepEntry directChanDistRepEntry;

	/**
	 * Instantiates a new group repository entry.
	 */
	public GroupRepositoryEntry() {

	}

	/**
	 * Instantiates a new group repository entry.
	 *
	 * @param aPartyGroupCode the a party group code
	 */
	public GroupRepositoryEntry(String aPartyGroupCode) {
		this.setPartyGroupCode(aPartyGroupCode);
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 *
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param aId the a id
	 *
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the manufacturing context.
	 *
	 * @return the manufacturing context
	 */
	public ManufacturingContext getManufacturingContext() {
		return this.manufacturingContext;
	}

	/**
	 * Sets the manufacturing context.
	 *
	 * @param aManufacturingContext the new manufacturing context
	 */
	public void setManufacturingContext(ManufacturingContext aManufacturingContext) {
		this.manufacturingContext = aManufacturingContext;
	}

	/**
	 * Gets the party group type.
	 *
	 * @return the party group type
	 */
	public PartyGroupTypeCodeEnum getPartyGroupType() {
		return this.partyGroupType;
	}

	/**
	 * Sets the party group type code.
	 *
	 * @param partyGroupTypeCode the new party group type code
	 */
	public void setPartyGroupTypeCode(PartyGroupTypeCodeEnum partyGroupTypeCode) {
		this.partyGroupType = partyGroupTypeCode;
	}

	/**
	 * Gets the party group code.
	 *
	 * @return the party group code
	 */
	public String getPartyGroupCode() {
		return this.partyGroupCode;
	}

	/**
	 * Sets the party group code.
	 *
	 * @param aPartyGroupCode the new party group code
	 */
	public void setPartyGroupCode(String aPartyGroupCode) {
		this.partyGroupCode = aPartyGroupCode;
	}

	/**
	 * Gets the party group description.
	 *
	 * @return the party group description
	 */
	public String getPartyGroupDescriptionEnglish() {
		return this.partyGroupDescriptionEnglish;
	}

	public String getDescription(LanguageCodeEnum language) {
		return LanguageCodeEnum.ENGLISH.equals(language) ? this.getPartyGroupDescriptionEnglish() : this
				.getPartyGroupDescriptionFrench();
	}

	/**
	 * Sets the party group description.
	 *
	 * @param partyGroupDesc the new party group description
	 */
	public void setPartyGroupDescriptionEnglish(String partyGroupDesc) {
		this.partyGroupDescriptionEnglish = partyGroupDesc;
	}

	/**
	 * Gets the party sub group type code.
	 *
	 * @return the party sub group type code
	 */
	public PartySubGroupTypeCodeEnum getPartySubGroupType() {
		return this.partySubGroupType;
	}

	/**
	 * Sets the party sub group type code.
	 *
	 * @param aPartySubGroupTypeCode the new party sub group type code
	 */
	public void setPartySubGroupType(PartySubGroupTypeCodeEnum aPartySubGroupTypeCode) {
		this.partySubGroupType = aPartySubGroupTypeCode;
	}

	/**
	 * Gets the party sub group code.
	 *
	 * @return the party sub group code
	 */
	public String getPartySubGroupCode() {
		return this.partySubGroupCode;
	}

	/**
	 * Sets the party sub group code.
	 *
	 * @param aPartySubGroupCode the new party sub group code
	 */
	public void setPartySubGroupCode(String aPartySubGroupCode) {
		this.partySubGroupCode = aPartySubGroupCode;
	}

	/**
	 * Gets the party sub group description.
	 *
	 * @return the party sub group description
	 */
	public String getPartySubGroupDescriptionEnglish() {
		return this.partySubGroupDescriptionEnglish;
	}

	/**
	 * Sets the party sub group description.
	 *
	 * @param partySubGroupDesc the new party sub group description
	 */
	public void setPartySubGroupDescriptionEnglish(String partySubGroupDesc) {
		this.partySubGroupDescriptionEnglish = partySubGroupDesc;
	}

	/**
	 * Gets the insured group.
	 *
	 * @return the insured group
	 */
	public String getInsuredGroup() {
		return this.insuredGroup;
	}

	/**
	 * Sets the insured group.
	 *
	 * @param insuredGroupCode the new insured group
	 */
	public void setInsuredGroup(String insuredGroupCode) {
		this.insuredGroup = insuredGroupCode;
	}

	/**
	 * Gets the party sub group description french.
	 *
	 * @return the partySubGroupDescriptionFrench
	 */
	public String getPartySubGroupDescriptionFrench() {
		return this.partySubGroupDescriptionFrench;
	}

	/**
	 * Sets the party sub group description french.
	 *
	 * @param aPartySubGroupDescriptionFrench the partySubGroupDescriptionFrench to set
	 */
	public void setPartySubGroupDescriptionFrench(String aPartySubGroupDescriptionFrench) {
		this.partySubGroupDescriptionFrench = aPartySubGroupDescriptionFrench;
	}

	/**
	 * Sets the party group type.
	 *
	 * @param aPartyGroupType the partyGroupType to set
	 */
	public void setPartyGroupType(PartyGroupTypeCodeEnum aPartyGroupType) {
		this.partyGroupType = aPartyGroupType;
	}

	/**
	 * Gets the party group description french.
	 *
	 * @return the partyGroupDescriptionFrench
	 */
	public String getPartyGroupDescriptionFrench() {
		return this.partyGroupDescriptionFrench;
	}

	/**
	 * Sets the party group description french.
	 *
	 * @param aPartyGroupDescriptionFrench the partyGroupDescriptionFrench to set
	 */
	public void setPartyGroupDescriptionFrench(String aPartyGroupDescriptionFrench) {
		this.partyGroupDescriptionFrench = aPartyGroupDescriptionFrench;
	}

	/**
	 * Sets the french/english party group description based on the locale parameter.
	 *
	 * @param locale indicates the property to set
	 * @param aPartyGroupDescription the french or english description
	 */
	public void setPartyGroupDescription(Locale locale, String aPartyGroupDescription) {
		if (locale.getLanguage().equals(Locale.FRENCH.getLanguage())) {
			this.setPartyGroupDescriptionFrench(aPartyGroupDescription);
		} else {
			this.setPartyGroupDescriptionEnglish(aPartyGroupDescription);
		}
	}

	/**
	 * Gets the french/english party group description based on the locale parameter.
	 *
	 * @param locale indicates the property to set
	 * @return the french or english description
	 */
	public String getPartyGroupDescription(Locale locale) {

		return locale.getLanguage().equals(Locale.FRENCH.getLanguage()) ? this.getPartyGroupDescriptionFrench() : this
				.getPartyGroupDescriptionEnglish();

	}

	/**
	 * Gets the effective date.
	 *
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * Sets the effective date.
	 *
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * Gets the expiry date.
	 *
	 * @return the expiryDate
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * Sets the expiry date.
	 *
	 * @param expiryDate the expiryDate to set
	 */
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public DirectChanDistRepEntry getDirectChanDistRepEntry() {
		return this.directChanDistRepEntry;
	}

	public void setDirectChanDistRepEntry(DirectChanDistRepEntry directChanDistRepEntry) {
		this.directChanDistRepEntry = directChanDistRepEntry;
	}

}
