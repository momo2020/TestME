/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.usertype;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

/**
 * The Class AuditTrail.
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Embeddable
public class AuditTrail extends Component {

	private static final long serialVersionUID = 1L;

	/** The create timestamp. */
	protected Date createTimestamp = null;

	/**
	 * Instantiates a new audit trail.
	 */
	public AuditTrail() {
		this(new Date());
	}

	/**
	 * Instantiates a new audit trail.
	 * 
	 * @param aCreateTimestamp the a create timestamp
	 */
	public AuditTrail(Date aCreateTimestamp) {
		setCreateTimestamp(aCreateTimestamp);
	}

	/**
	 * Gets the creates the timestamp.
	 * 
	 * @return the creates the timestamp
	 */
	@Column(name = "SYSTEM_CREATE_TS", nullable = false, updatable = false, length = 11)
	@Temporal(TemporalType.TIMESTAMP)
	public Date getCreateTimestamp() {
		return this.createTimestamp;
	}

	/**
	 * Sets the creates the timestamp.
	 * 
	 * @param aCreateTimestamp the new creates the timestamp
	 */
	public void setCreateTimestamp(Date aCreateTimestamp) {
		this.createTimestamp = aCreateTimestamp;
	}

}
