/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.usertype;

import java.util.Comparator;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.MappedSuperclass;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

/**
 * The Class BaseEntity.
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@MappedSuperclass
public abstract class BaseEntity implements IEntity {

	/** Sorts BaseEntity on the auditTrail.createTimestamp from the oldest to the newest */
	public static final Comparator<BaseEntity> CREATE_TIMESTAMP_ASC_COMPARATOR = new Comparator<BaseEntity>() {
		@Override
		public int compare(BaseEntity e1, BaseEntity e2) {
			return e1.getAuditTrail().getCreateTimestamp().compareTo(e2.getAuditTrail().getCreateTimestamp());
		}
	};

	/** Sorts BaseEntity on the auditTrail.createTimestamp from the newest to the oldest */
	public static final Comparator<BaseEntity> CREATE_TIMESTAMP_DESC_COMPARATOR = new Comparator<BaseEntity>() {
		@Override
		public int compare(BaseEntity e1, BaseEntity e2) {
			// using - inverts the sort (desc) compareTo results become: 1 -> -1, 0 -> 0, -1 -> 1
			return -(e1.getAuditTrail().getCreateTimestamp().compareTo(e2.getAuditTrail().getCreateTimestamp()));
		}
	};

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The audit trail. */
	@Embedded
	@AttributeOverrides( { @AttributeOverride(name = "createTimestamp", column = @Column(name = "SYSTEM_CREATE_TS")) })
	protected AuditTrail auditTrail = new AuditTrail();

	/**
	 * Instantiates a new base entity.
	 */
	public BaseEntity() {
		this(null);
	}

	/**
	 * Instantiates a new base entity.
	 * 
	 * @param id the id
	 */
	public BaseEntity(Object id) {
		setId(id);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.IEntity#getId()
	 */
	@XmlTransient // let implemeting child decide to ouputn to XML or not
	@Override
	public abstract Object getId();

	/**
	 * Sets the id.
	 * 
	 * @param id the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.IEntity#setId(java.lang.Object)
	 */
	@Override
	public abstract void setId(Object id);

	/**
	 * This method checks if the entity already has a representation in the database.
	 * 
	 * @return true if the object has an non null id attribute, false otherwise
	 */
	@Override
	public boolean isPersistent() {
		return getId() != null;
	}

	/**
	 * This method indicated if an an entity is not yet persisted.
	 * 
	 * @return true if the object has a null id attribute, true otherwise
	 */
	@Override
	public boolean isTransient() {
		return !isPersistent();
	}

	/**
	 * To string.
	 * 
	 * @return the string
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return new StringBuilder().append(getClass().getSimpleName()).append("[").append("id=").append(
				String.valueOf(getId())).append("]").toString();
	}

	/**
	 * Sets the audit trail.
	 * 
	 * @param trail the trail
	 * 
	 * @see com.ing.canada.plp.domain.usertype.IEntity#setAuditTrail(com.ing.canada.plp.domain.usertype.AuditTrail)
	 */
	@Override
	public void setAuditTrail(AuditTrail trail) {
		this.auditTrail = trail;
	}

	/**
	 * Gets the audit trail.
	 * 
	 * @return the audit trail
	 * @see com.ing.canada.plp.domain.usertype.IEntity#getAuditTrail()
	 */
	@XmlTransient // don't display in XML
	@Override
	public AuditTrail getAuditTrail() {
		return this.auditTrail;
	}

	/**
	 * This method must return all field values part of the natural keys.
	 * 
	 * @return
	 */
	protected Object[] getNaturalKeys() {
		return null;
	}

}
