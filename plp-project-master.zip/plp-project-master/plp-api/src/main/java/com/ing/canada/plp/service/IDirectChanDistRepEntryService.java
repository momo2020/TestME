/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2017, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.enums.DistributorCodeEnum;
import com.ing.canada.plp.domain.policyversion.DirectChanDistRepEntry;

/**
 * Interface for the Direct Channel Distributor Repository Entry Service
 *
 * @author <a href="mailto:pascal.meunier@intact.net">Pascal Meunier</a>
 *
 */
public interface IDirectChanDistRepEntryService extends ICRUDService<DirectChanDistRepEntry> {

	/**
	 * Find a Direct Channel Distributor Repository Entry based on a provided unique code
	 * @param code {@link DistributorCodeEnum}
	 * @return the found {@link DirectChanDistRepEntry}, null when not found.
	 */
	public DirectChanDistRepEntry find(DistributorCodeEnum code);

}
