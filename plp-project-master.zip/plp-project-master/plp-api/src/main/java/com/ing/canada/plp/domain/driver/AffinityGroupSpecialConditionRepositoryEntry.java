/**
 * 
 */
package com.ing.canada.plp.domain.driver;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * AffGrSpCndRepEntry entity.
 * 
 * @author ub8169
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "AFF_GR_SP_CND_REP_ENTRY")
public class AffinityGroupSpecialConditionRepositoryEntry extends BaseEntity {

	// Fields
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "AFF_GR_SP_CND_REP_ENTRY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "AffinityGroupSpecialConditionRepositoryEntrySequence")
	@SequenceGenerator(name = "AffinityGroupSpecialConditionRepositoryEntrySequence", sequenceName = "AFF_GR_SP_CND_REP_ENTRY_SEQ", allocationSize = 5)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "AFF_GR_REP_ENTRY_ID")
	private AffinityGroupRepositoryEntry affinityGroupRepositoryEntry;

	@Column(name = "AFFINITY_GROUP_SP_CND_CD", length = 5)
	private String affinityGroupSpecialConditionCode;

	/** default constructor */
	public AffinityGroupSpecialConditionRepositoryEntry() {
		// Nothing to do
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object anId) {
		this.id = (Long) anId;
	}

	/**
	 * @return the affinityGroupRepositoryEntry
	 */
	@XmlTransient // parent
	public AffinityGroupRepositoryEntry getAffinityGroupRepositoryEntry() {
		return this.affinityGroupRepositoryEntry;
	}

	/**
	 * @param anAffinityGroupRepositoryEntry the affinityGroupRepositoryEntry to set
	 */
	public void setAffinityGroupRepositoryEntry(AffinityGroupRepositoryEntry anAffinityGroupRepositoryEntry) {
		this.affinityGroupRepositoryEntry = anAffinityGroupRepositoryEntry;
	}

	/**
	 * @return the affinityGroupSpecialConditionCode
	 */
	public String getAffinityGroupSpecialConditionCode() {
		return this.affinityGroupSpecialConditionCode;
	}

	/**
	 * @param anAffinityGroupSpecialConditionCode the affinityGroupSpecialConditionCode to set
	 */
	public void setAffinityGroupSpecialConditionCode(String anAffinityGroupSpecialConditionCode) {
		this.affinityGroupSpecialConditionCode = anAffinityGroupSpecialConditionCode;
	}

}
