/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum KindOfLossCodeEnum.
 */
public enum KindOfLossCodeEnum {

	/* A - Liability KOL */
	A_BODILY_INJURY_CLAIMS_BY_PASSEN("01"),
	A_BODILY_INJURY_CLAIMS_BY_ANY_OTH("02"),
	A_PROP_DAMAGE_TO_INSURED_VEHICLE_3("03"),
	A_PROP_DAMAGE_TO_INSURED_VEHICLE_4("04"),
	A_PROP_DAMAGE_TO_INSURED_CONTE("05"),
	A_LOSS_OF_USE_DIRECT_COMPENSATION("06"),
	A_PROP_DAMAGE_TO_OTHER_VEH("07"),
	A_DAMAGE_TO_CONTENTS_UNDER_INSU("08"),
	A_DAMAGE_TO_TRAILERS_UNDER_INSUR("09"),
	A_DAMAGE_TO_OTHER_PROPERTY("10"),		
	A_BODILY_INJURY_CLAIMS_OTHER_THIRD_PARTY("BI"),
	A_DOMMAGES_AU_VEHICULE_DE_ASSURE("PD"),
	A_RISQUE_PASSAGER("PH"),
	
	/* A1 - Liability KOL */
	A1_BODILY_INJURY_CLAIMS_OTHER_THIRD_PARTY("BI"),
	A1_BODILY_INJURY_CLAIMS_TO_PASSENGERS_OF_INSURED("BT"),
	A1_GARANTIE_AUTO_POUR_INSUFFISAN("UD"),
	A1_RECOVERIES_VIA_LOSS_TRANSFER("LT"),

	/* A2 - DCPD KOL */
	A2_DOMMAGES_AU_VEHICULE_DE_ASSURE("PD"),
	A2_DOMM_A_UNE_REMORQUE("TR"),
	A2_DOMM_AU_CONTENU("RT"),
	A2_PERTE_DE_JOUISSANCE("PU"),
	A2_DOMM_AU_VEHICULE("PT"),
	A2_DOMMAGES_AU_CONTENU_APPART("PC"),
	A2_DOMM_MAT_VEH_DUN_TIERS("DC"),


	/* B - Accident Benefits KOL */
	B_PREJUDICE_MATERIEL_EN_EXCEDENT("EC"),	
	B_PROTOCOLE_ALBERTA("AP"),
	B_PRESTATION_DECES("DB"),
	B_PRESTATION_INVALIDITE("DI"),
	B_MUTILATION("DM"),
	B_FRAIS_OBSEQUES("FE"),
	B_FRAIS_MEDICAUX("ME"),
	B_COUVERTURE_POUR_NON_ASS("UN"),
	B_GARANTIE_AUTO_POUR_NON_ASS("UP"),
	B_GARANTIE_AUTO_POUR_NON_ASS_DUN_TIERS_DC("UB"),

	
	/* C2 - Collision KOL */
	C2_DELIT_DE_FUITE("CH"),
	C2_COLLISION_DE_VEHICULES_DIVERS("CO"),
	C2_COLL_OU_VERSEMENT_SANS_IMPLIQUER_AUTRES_VEH("CS"),	
	
	/* C3#C4 - Comprehensive KOL */
	C3_TEMPETE_DE_VENT("WS"),
	C3_C4_INCENDIE_DU_VEHICULE("FV"),
	C3_BRIS_DE_GLACE("GL"),	
	C3_C4_ASSISTANCE_ROUTIERE("ES"),
	C3_C4_FEU("FR"),
	C3_REMPLACEMENT_DE_PARE_BRISE("GW"),
	C3_REPARATION_DE_PARE_BRISE("GR"),	
	C3_GRELE("HL"),
	C2_C3_C4_PRIVATION_DE_JOUISSANCE("LS"),
	C3_C4_AUTRES_SINISTRES("OC"),
	C3_C4_VOL_TOTAL("TE"),
	C3_C4_VOL_PARTIEL("TP"),
	C3_VANDALISME_OU_ACTES_MALVEILLANTS("VN"),
	C3_C4_TEMPETE_DE_VENT_OU_GRELE("WN"),
	
	A1_A2_B_C2_C3_C4_AUTRES("ZZ");
	
	/**
	 * Instantiates a new kind of loss code enum.
	 * 
	 * @param aCode the a code
	 */
	private KindOfLossCodeEnum(String aCode) {
		this.code = aCode;
	}

	/**
	 * The code.
	 */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * @return the kind of loss code enum
	 */
	public static KindOfLossCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (KindOfLossCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
