/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.party;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.CommunicationChannelCodeEnum;
import com.ing.canada.plp.domain.enums.ConsentTypeCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * Consent entity.
 * 
 * @author Patrick Lafleur
 * 
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "CONSENT", uniqueConstraints = {})
public class Consent extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "CONSENT_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "ConsentSequence")
	@SequenceGenerator(name = "ConsentSequence", sequenceName = "CONSENT_SEQ", allocationSize = 5)
	private Long id;

	/** The party. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "PARTY_ID", nullable = false, updatable = true)
	private Party party;

	/** The communication channel code. */
	@Column(name = "COMMUNICATION_CHANNEL_CD", nullable = true, length = 5)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.CommunicationChannelCodeEnum") })
	private CommunicationChannelCodeEnum communicationChannelCode;

	/** The consent type code. */
	@Column(name = "CONSENT_TYPE_CD", nullable = false, length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ConsentTypeCodeEnum") })
	private ConsentTypeCodeEnum consentType;

	/** The consent indicator. */
	@Column(name = "CONSENT_IND", nullable = false, length = 1)
	@Type(type = "yes_no")
	private Boolean consentIndicator;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", nullable = true, length = 7)
	private Date effectiveDate;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;

	/** The creation timestamp. */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATION_TS", nullable = false, length = 11)
	private Date creationTimestamp = new Date();

	/** The original scenario consent. */
	 
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_CONSENT_ID", insertable = false, updatable = false)
	private Consent originalScenarioConsent;

	/**
	 * Instantiates a new consent.
	 */
	public Consent() {
		// noarg constructor
	}

	/**
	 * Instantiates a new consent.
	 * 
	 * @param aParty the a party
	 * @param aCommunicationChannelCode the a communication channel code
	 * @param aConsentTypeCode the a consent type code
	 * @param aConsentIndicator the a consent indicator
	 * @param aCreationTimestamp the a creation timestamp
	 * @param aEffectiveDate the a effective date
	 */
	public Consent(Party aParty, CommunicationChannelCodeEnum aCommunicationChannelCode,
			ConsentTypeCodeEnum aConsentTypeCode, Boolean aConsentIndicator, Date aCreationTimestamp,
			Date aEffectiveDate) {
		setParty(aParty);
		setCommunicationChannelCode(aCommunicationChannelCode);
		setConsentType(aConsentTypeCode);
		setConsentIndicator(aConsentIndicator);
		setCreationTimestamp(aCreationTimestamp);
		setEffectiveDate(aEffectiveDate);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the party.
	 * 
	 * @return the party
	 */
	@XmlTransient // parent
	public Party getParty() {
		return this.party;
	}

	/**
	 * Sets the party.
	 * 
	 * @param aParty the new party
	 */
	public void setParty(Party aParty) {
		AssociationsHelper.updateOneToManyFields(aParty, "consents", this, "party");
	}

	/**
	 * Gets the communication channel code.
	 * 
	 * @return the communication channel code
	 */
	public CommunicationChannelCodeEnum getCommunicationChannelCode() {
		return this.communicationChannelCode;
	}

	/**
	 * Sets the communication channel code.
	 * 
	 * @param aCommunicationChannelCode the new communication channel code
	 */
	public void setCommunicationChannelCode(CommunicationChannelCodeEnum aCommunicationChannelCode) {
		this.communicationChannelCode = aCommunicationChannelCode;
	}

	/**
	 * Gets the consent type code.
	 * 
	 * @return the consent type code
	 */
	public ConsentTypeCodeEnum getConsentType() {
		return this.consentType;
	}

	/**
	 * Sets the consent type code.
	 * 
	 * @param aConsentTypeCode the new consent type code
	 */
	public void setConsentType(ConsentTypeCodeEnum aConsentTypeCode) {
		this.consentType = aConsentTypeCode;
	}

	/**
	 * Gets the consent indicator.
	 * 
	 * @return the consent indicator
	 */
	public Boolean getConsentIndicator() {
		return this.consentIndicator;
	}

	/**
	 * Sets the consent indicator.
	 * 
	 * @param aConsentIndicator the new consent indicator
	 */
	public void setConsentIndicator(Boolean aConsentIndicator) {
		this.consentIndicator = aConsentIndicator;
	}

	/**
	 * Gets the creation timestamp.
	 * 
	 * @return the creation timestamp
	 */
	public Date getCreationTimestamp() {
		return this.creationTimestamp;
	}

	/**
	 * Sets the creation timestamp.
	 * 
	 * @param aCreationTimestamp the new creation timestamp
	 */
	public void setCreationTimestamp(Date aCreationTimestamp) {
		this.creationTimestamp = aCreationTimestamp;
	}

	/**
	 * Gets the effective date.
	 * 
	 * @return the effective date
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * Sets the effective date.
	 * 
	 * @param aEffectiveDate the new effective date
	 */
	public void setEffectiveDate(Date aEffectiveDate) {
		this.effectiveDate = aEffectiveDate;
	}

	/**
	 * Gets the expiry date.
	 * 
	 * @return the expiry date
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * Sets the expiry date.
	 * 
	 * @param aExpiryDate the new expiry date
	 */
	public void setExpiryDate(Date aExpiryDate) {
		this.expiryDate = aExpiryDate;
	}

	/**
	 * Gets the original scenario consent.
	 * 
	 * @return the original scenario consent
	 */
	@XmlTransient // reference source
	public Consent getOriginalScenarioConsent() {
		return this.originalScenarioConsent;
	}

	/**
	 * Sets the original scenario consent.
	 * 
	 * @param anOriginalScenarioConsent the new original scenario consent
	 */
	protected void setOriginalScenarioConsent(Consent anOriginalScenarioConsent) {
		this.originalScenarioConsent = anOriginalScenarioConsent;
	}

}
