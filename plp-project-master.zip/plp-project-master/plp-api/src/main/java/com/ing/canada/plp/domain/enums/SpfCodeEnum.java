/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum SpfCodeEnum.
 */
public enum SpfCodeEnum {

	STANDARD_OWNERS_AUTOMOBILE_POLICY("1"), STANDARD_DRIVERS_AUTOMOBILE_POLICY("2"), CARRIERS_POLICY("3"), STANDARD_GARAGE_AUTOMOBILE_POLICY(
			"4"), STANDARD_NON_OWNED_AUTOMOBILE_POLICY("6"), EXCESS_AUTOMOBILE_POLICY("7"), LESSORS_CONTINGENT_AUTOMOBILE_POLICY(
			"8");

	/**
	 * Instantiates a new spf code enum.
	 * 
	 * @param aCode the a code
	 */
	private SpfCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the spf code enum
	 */
	public static SpfCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (SpfCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
