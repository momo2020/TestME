/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.driver;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.DriverLicenseClassCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * DriverLicenseClass entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "DRIVER_LICENSE_CLASS", uniqueConstraints = {})
public class DriverLicenseClass extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "DRIVER_LICENSE_CLASS_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "DriverLicenseClassSequence")
	@SequenceGenerator(name = "DriverLicenseClassSequence", sequenceName = "DRIVER_LICENSE_CLASS_SEQ", allocationSize = 5)
	private Long id;

	/** The driver complement info. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "PARTY_ID", nullable = false, updatable = true)
	private DriverComplementInfo driverComplementInfo;

	/** The driver license class code. */
	@Column(name = "DRIVER_LICENSE_CLASS_CD", nullable = false, length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.DriverLicenseClassCodeEnum") })
	private DriverLicenseClassCodeEnum driverLicenseClass = null;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", nullable = false, length = 7)
	private Date effectiveDate;

	/** The original scenario driver license class. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_DRVR_LICENSE_CLASS_ID", insertable = false, updatable = false)
	private DriverLicenseClass originalScenarioDriverLicenseClass;

	/**
	 * Instantiates a new driver license class.
	 */
	public DriverLicenseClass() {
		// noarg constructor
	}

	/**
	 * Instantiates a new driver license class.
	 * 
	 * @param aDriverInfo the a driver info
	 * @param aClassCode the a class code
	 * @param anEffectiveDate the an effective date
	 */
	public DriverLicenseClass(DriverComplementInfo aDriverInfo, DriverLicenseClassCodeEnum aClassCode,
			Date anEffectiveDate) {
		setDriverComplementInfo(aDriverInfo);
		setDriverLicenseClass(aClassCode);
		setEffectiveDate(anEffectiveDate);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the driver complement info.
	 * 
	 * @return the driver complement info
	 */
	@XmlTransient // parent
	public DriverComplementInfo getDriverComplementInfo() {
		return this.driverComplementInfo;
	}

	/**
	 * Sets the driver complement info.
	 * 
	 * @param aDriverComplementInfo the new driver complement info
	 */
	public void setDriverComplementInfo(DriverComplementInfo aDriverComplementInfo) {
		AssociationsHelper.updateOneToManyFields(aDriverComplementInfo, "driverLicenseClasses", this,
				"driverComplementInfo");
	}

	/**
	 * Gets the driver license class code.
	 * 
	 * @return the driver license class code
	 */
	public DriverLicenseClassCodeEnum getDriverLicenseClass() {
		return this.driverLicenseClass;
	}

	/**
	 * Sets the driver license class.
	 * 
	 * @param driverLicenseClassCode the new driver license class
	 */
	public void setDriverLicenseClass(DriverLicenseClassCodeEnum driverLicenseClassCode) {
		this.driverLicenseClass = driverLicenseClassCode;
	}

	/**
	 * Gets the effective date.
	 * 
	 * @return the effective date
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * Sets the effective date.
	 * 
	 * @param aEffectiveDate the new effective date
	 */
	public void setEffectiveDate(Date aEffectiveDate) {
		this.effectiveDate = aEffectiveDate;
	}

	/**
	 * Gets the original scenario driver license class.
	 * 
	 * @return the original scenario driver license class
	 */
	@XmlTransient // reference source
	public DriverLicenseClass getOriginalScenarioDriverLicenseClass() {
		return this.originalScenarioDriverLicenseClass;
	}

	/**
	 * Sets the original scenario driver license class.
	 * 
	 * @param anOriginalScenarioDriverLicenseClass the new original scenario driver license class
	 */
	protected void setOriginalScenarioDriverLicenseClass(DriverLicenseClass anOriginalScenarioDriverLicenseClass) {
		this.originalScenarioDriverLicenseClass = anOriginalScenarioDriverLicenseClass;
	}

}
