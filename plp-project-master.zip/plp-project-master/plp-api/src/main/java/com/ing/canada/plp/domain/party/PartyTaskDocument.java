package com.ing.canada.plp.domain.party;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.enums.ReportRequestStatus;
import com.ing.canada.plp.domain.enums.ReportType;
import com.ing.canada.plp.domain.usertype.BaseEntity;

@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "PARTY_TASK_DOCUMENT")
@NamedQuery(
	name = "PartyTaskDocument.findByPartyIdOrderByLastDate", 
	query = "select ptd from PartyTaskDocument ptd join ptd.party p WHERE p.id = :partyId order by ptd.systemDateTime")
public class PartyTaskDocument extends BaseEntity {
	
	private static final long serialVersionUID = 1L;
	
	
	@Id
	@Column(name = "PARTY_TASK_DOCUMENT_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "PartyTaskDocumentSequence")
	@SequenceGenerator(name = "PartyTaskDocumentSequence", sequenceName = "PARTY_TASK_DOCUMENT_SEQ", allocationSize = 5)
	private Long id;
	
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "PARTY_ID", nullable = false, updatable = true)
	private Party party;
	
	@Column(name = "TASK_DOCUMENT_REQUEST_ID", nullable = false, precision = 12, scale = 0)
	private Long taskDocumentRequestId;
	
	@Column(name = "OVERRIDEN_DOCUMENT_INFO_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean internalBillingIndicator;
	
	@Column(name = "REQ_STATUS_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ReportRequestStatus") })
	private ReportRequestStatus requestStatus;
	
	@Column(name = "TYPE_CD", length = 4)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ReportType") })
	private ReportType type;
	
	@Column(name = "SYSTEM_CREATE_TS", length = 11, insertable = false, updatable = false)
	private Date systemDateTime;

	
	@Override
	public Object getId() {
		return id;
	}

	@Override
	public void setId(Object id) {
		this.id = (Long)id;
	}
	
	@XmlTransient
	public Party getParty() {
		return party;
	}

	public void setParty(Party party) {
		this.party = party;
	}

	public Long getTaskDocumentRequestId() {
		return taskDocumentRequestId;
	}

	public void setTaskDocumentRequestId(Long taskDocumentRequestId) {
		this.taskDocumentRequestId = taskDocumentRequestId;
	}

	public Boolean getInternalBillingIndicator() {
		return internalBillingIndicator;
	}

	public void setInternalBillingIndicator(Boolean internalBillingIndicator) {
		this.internalBillingIndicator = internalBillingIndicator;
	}

	public ReportRequestStatus getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(ReportRequestStatus requestStatus) {
		this.requestStatus = requestStatus;
	}

	public ReportType getType() {
		return type;
	}

	public void setType(ReportType type) {
		this.type = type;
	}

	public Date getSystemDateTime() {
		return systemDateTime;
	}

	public void setSystemDateTime(Date systemDateTime) {
		this.systemDateTime = systemDateTime;
	}
	
}
