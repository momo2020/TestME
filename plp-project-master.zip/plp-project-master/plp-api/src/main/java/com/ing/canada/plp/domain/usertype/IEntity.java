/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.usertype;

import java.io.Serializable;

/**
 * The Interface IEntity.
 */
public interface IEntity extends Auditable, Serializable {

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 */
	Object getId();

	/**
	 * Sets the id.
	 * 
	 * @param id the new id
	 */
	void setId(Object id);

	/**
	 * This method indicated if an an entity is not yet persisted.
	 * 
	 * @return true if the object has a null id attribute, true otherwise
	 */
	boolean isTransient();

	/**
	 * This method checks if the entity already has a representation in the database.
	 * 
	 * @return true if the object has an non null id attribute, false otherwise
	 */
	boolean isPersistent();

	/**
	 * Gets the audit trail.
	 * 
	 * @return the audit trail
	 * 
	 * @see com.ing.canada.plp.domain.usertype.Auditable#getAuditTrail()
	 */
	@Override
	AuditTrail getAuditTrail();

	/**
	 * Sets the audit trail.
	 * 
	 * @param trail the trail
	 * 
	 * @see com.ing.canada.plp.domain.usertype.Auditable#setAuditTrail(com.ing.canada.plp.domain.usertype.AuditTrail)
	 */
	@Override
	void setAuditTrail(AuditTrail trail);

}
