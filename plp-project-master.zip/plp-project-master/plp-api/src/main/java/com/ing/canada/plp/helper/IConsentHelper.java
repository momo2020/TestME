/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import java.util.Set;

import com.ing.canada.plp.domain.enums.ConsentTypeCodeEnum;
import com.ing.canada.plp.domain.party.Consent;
import com.ing.canada.plp.domain.party.Party;
import com.ing.canada.plp.domain.policyversion.PolicyHolder;

/**
 * The Interface IConsentHelper.
 * 
 * @author strichar
 */
public interface IConsentHelper {

	/**
	 * Gets the consent.
	 * 
	 * @param aParty the a party
	 * @param aConsentTypeCodeEnum the a consent type code enum
	 * @return the consent
	 */
	Consent getConsent(Party aParty, ConsentTypeCodeEnum aConsentTypeCodeEnum);

	/**
	 * Verify if clients have approved the consent of UBI
	 * 
	 * @param policyHolders a {@link Set} of {@link PolicyHolder}
	 * @return true when consent approved, false otherwise
	 */
	boolean isUbiConsentApproved(Set<PolicyHolder> policyHolders);

}
