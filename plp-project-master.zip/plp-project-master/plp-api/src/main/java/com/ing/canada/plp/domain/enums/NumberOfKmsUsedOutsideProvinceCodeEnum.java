/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum NumberOfKmsUsedOutsideProvinceCodeEnum.
 */
public enum NumberOfKmsUsedOutsideProvinceCodeEnum {

	ZERO("000000"), FIVE_THOUSAND("005000"), TEN_THOUSAND("010000"), FIFTEEN_THOUSAND("015000");
	
	private static Map<Integer, NumberOfKmsUsedOutsideProvinceCodeEnum> valuesMap = null;

	/**
	 * Instantiates a new policy version type code enum.
	 * 
	 * @param aCode the a code
	 */
	private NumberOfKmsUsedOutsideProvinceCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the number of kms the vehicle is used outside the province code enum
	 */
	public static NumberOfKmsUsedOutsideProvinceCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (NumberOfKmsUsedOutsideProvinceCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
	
	public static NumberOfKmsUsedOutsideProvinceCodeEnum valueOfCode(int value) {

		if (NumberOfKmsUsedOutsideProvinceCodeEnum.valuesMap == null) {
			NumberOfKmsUsedOutsideProvinceCodeEnum.valuesMap = new HashMap<Integer, NumberOfKmsUsedOutsideProvinceCodeEnum>();

			for (NumberOfKmsUsedOutsideProvinceCodeEnum nbKm : NumberOfKmsUsedOutsideProvinceCodeEnum.values()) {
				NumberOfKmsUsedOutsideProvinceCodeEnum.valuesMap.put(Integer.parseInt(nbKm.getCode()), nbKm);
			}
		}
		
		return NumberOfKmsUsedOutsideProvinceCodeEnum.valuesMap.get(value);

	}
}
