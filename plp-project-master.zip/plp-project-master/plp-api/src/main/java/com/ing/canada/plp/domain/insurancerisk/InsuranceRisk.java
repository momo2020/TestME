/**
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insurancerisk;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.coverage.Coverage;
import com.ing.canada.plp.domain.coverage.CoverageOption;
import com.ing.canada.plp.domain.diagnostics.DiagnosticAutomatedAdvice;
import com.ing.canada.plp.domain.driver.Conviction;
import com.ing.canada.plp.domain.enums.ActionTakenCodeEnum;
import com.ing.canada.plp.domain.enums.GoodDriverCodeEnum;
import com.ing.canada.plp.domain.enums.PolicyTermInMonthsEnum;
import com.ing.canada.plp.domain.enums.QualityRiskLevelCodeEnum;
import com.ing.canada.plp.domain.enums.ReasonAbsenceThirdPartyLiabilityCoverageCodeEnum;
import com.ing.canada.plp.domain.enums.RetentionBandCodeEnum;
import com.ing.canada.plp.domain.enums.RiskSubTypeCodeEnum;
import com.ing.canada.plp.domain.enums.RiskTypeCodeEnum;
import com.ing.canada.plp.domain.enums.RspDecisionOriginCodeEnum;
import com.ing.canada.plp.domain.enums.RspMentionAtRenewalCodeEnum;
import com.ing.canada.plp.domain.enums.RspTransferTypeCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer;
import com.ing.canada.plp.domain.party.Address;
import com.ing.canada.plp.domain.party.CreditScore;
import com.ing.canada.plp.domain.party.PartyRoleInRisk;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;
import com.ing.canada.plp.domain.usertype.BaseEntity;
import com.ing.canada.plp.domain.vehicle.Vehicle;
import com.ing.canada.plp.roadblock.Roadblockable;

/**
 * InsuranceRisk entity.
 *
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "INSURANCE_RISK", uniqueConstraints = {})
public class InsuranceRisk extends BaseEntity implements Roadblockable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "INSURANCE_RISK_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "InsuranceRiskSequence")
	@SequenceGenerator(name = "InsuranceRiskSequence", sequenceName = "INSURANCE_RISK_SEQ", allocationSize = 5)
	private Long id;

	/** The policy version. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "POLICY_VERSION_ID", nullable = false, updatable = true)
	protected PolicyVersion policyVersion;

	/** The credit score. */
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "CREDIT_SCORE_POSTAL_CD_ID", updatable = true)
	private CreditScore creditScorePostalCode;

	/** The address. */
	@ManyToOne(cascade = { CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name = "ADDRESS_ID", updatable = true)
	private Address address;

	/** The risk type. */
	@Column(name = "RISK_TYPE_CD", nullable = false, length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.RiskTypeCodeEnum") })
	private RiskTypeCodeEnum riskType;

	/** The risk subtype. */
	@Column(name = "RISK_SUBTYPE_CD", length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.RiskSubTypeCodeEnum") })
	private RiskSubTypeCodeEnum riskSubtype;

	/** The insurance risk sequence. */
	@Column(name = "INSURANCE_RISK_SEQ", nullable = false, precision = 4, scale = 0)
	private short insuranceRiskSequence;

	/** The proof driving record5 indicator. */
	@Column(name = "PROOF_DRIVING_RECORD5_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean proofDrivingRecord5Indicator;

	/** The good driver. */
	@Column(name = "GOOD_DRIVER_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.GoodDriverCodeEnum") })
	private GoodDriverCodeEnum goodDriver;

	/** The good driver. */
	@Column(name = "GOOD_DRIVER_SYS_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.GoodDriverCodeEnum") })
	private GoodDriverCodeEnum goodDriverSystem;

	/** The good driver. */
	@Column(name = "GOOD_DRIVER_MOD_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.GoodDriverCodeEnum") })
	private GoodDriverCodeEnum goodDriverModified;
	
	/** The good driver since date */
	 @Temporal(TemporalType.DATE)
	 @Column(name = "GOOD_DRIVER_SINCE_DT", length = 7)
	 private Date goodDriverSinceDate;
	 
	 /** The good driver since mod date */
	 @Temporal(TemporalType.DATE)
	 @Column(name = "GOOD_DRIVER_SINCE_MOD_DT", length = 7)
	 private Date goodDriverSinceModDate; 
	 
	 /** The good driver since sys date */
	 @Temporal(TemporalType.DATE)
	 @Column(name = "GOOD_DRIVER_SINCE_SYS_DT", length = 7)
	 private Date goodDriverSinceSysDate; 
	 
	/** The creation date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "CREATION_DT", length = 7)
	private Date creationDate;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", length = 7)
	private Date effectiveDate;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;

	/** The rating date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "RATING_DT", length = 7)
	private Date ratingDate;

	/** The flex percentage. */
	@Column(name = "FLEX_PCT", precision = 3, scale = 0)
	private Short flexPercentage;

	/** CVI Adjusted with Credit */
	@Column(name = "CVI_ADJD_WITH_CREDIT_QTY", precision = 3, scale = 0)
	private Short customerValueIndexAdjustedWithCredit;

	/** The stability discount. */
	@Column(name = "STABILITY_DISCOUNT_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean stabilityDiscountIndicator;

	/** The stability discount. */
	@Column(name = "STABILITY_DISCOUNT_SYS_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean stabilityDiscountSystemIndicator;

	/** The stability discount. */
	@Column(name = "STABILITY_DISCOUNT_MOD_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean stabilityDiscountModifiedIndicator;

	/** The territory stat. */
	@Column(name = "TERRITORY_STAT_CD", length = 3)
	private String territoryStat;

	/** The municipal adjustment. */
	@Column(name = "MUNICIPAL_ADJUSTMENT_CD", length = 1)
	private String municipalAdjustment;

	/** The capping percentage. */
	@Column(name = "CAPPING_PCT", precision = 3, scale = 0)
	private Short cappingPercentage;

	/** The quality risk level. */
	@Column(name = "QUALITY_RISK_LEVEL_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.QualityRiskLevelCodeEnum") })
	private QualityRiskLevelCodeEnum qualityRiskLevel;

	/** The annual premium. */
	@Column(name = "ANNUAL_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer annualPremium;

	/** The full term premium. */
	@Column(name = "FULL_TERM_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer fullTermPremium;

	/** The additional return premium. */
	@Column(name = "ADDITIONAL_RETURN_PREMIUM_AMT", precision = 9, scale = 0)
	private Integer additionalReturnPremium;

	/** The deductible discount amount. */
	@Column(name = "DEDUCTIBLE_DISCOUNT_AMT", precision = 9, scale = 0)
	private Integer deductibleDiscount;

	/** The deductible discount system amount. */
	@Column(name = "DEDUCTIBLE_DISCOUNT_SYS_AMT", precision = 9, scale = 0)
	private Integer deductibleDiscountSystem;

	/** The deductible discount modification amount. */
	@Column(name = "DEDUCTIBLE_DISCOUNT_MOD_AMT", precision = 9, scale = 0)
	private Integer deductibleDiscountModification;

	/** The reason for absence of third party liability coverage. */
	@Column(name = "RSN_ABS_THIRD_PRTY_LBL_CVRG_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = {
	        @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ReasonAbsenceThirdPartyLiabilityCoverageCodeEnum") })
	private ReasonAbsenceThirdPartyLiabilityCoverageCodeEnum reasonForAbsenceOfThirdPartyLiabilityCoverage;

	/** The rsp transfer type. */
	@Column(name = "RSP_TRANSFER_TYPE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.RspTransferTypeCodeEnum") })
	private RspTransferTypeCodeEnum rspTransferType;

	/** The rsp decision origin code. */
	@Column(name = "RSP_DECISION_ORIGIN_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.RspDecisionOriginCodeEnum") })
	private RspDecisionOriginCodeEnum rspDecisionOriginCode;

	/** The rsp mention at renewal code. */
	@Column(name = "RSP_MENTION_AT_RENEWAL_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.RspMentionAtRenewalCodeEnum") })
	private RspMentionAtRenewalCodeEnum rspMentionAtRenewalCode;

	/** The rsp reason. */
	@Column(name = "RSP_REASON_TXT", length = 15)
	private String rspReason;

	/** The rsp scoring. */
	@Column(name = "RSP_SCORING_QTY", precision = 2, scale = 0)
	private Byte rspScoring;

	/** The scoring adjustment percentage. */
	@Column(name = "SCORING_ADJUSTMENT_PCT", precision = 3, scale = 0)
	private Short scoringAdjustmentPercentage;

	/** The competitivity adjustment percentage. */
	@Column(name = "COMPETITIVITY_ADJUSTMENT_PCT", precision = 3, scale = 0)
	private Short competitivityAdjustmentPercentage;

	/** The competitivity score with credit. */
	@Column(name = "COMPET_SCORE_WITH_CR_QTY", precision = 3, scale = 0)
	private Short competitivityScoreWithCredit;

	/** The competitivity score without cr. */
	@Column(name = "COMPET_SCORE_WITHOUT_CR_QTY", precision = 3, scale = 0)
	private Short competitivityScoreWithoutCredit;

	/** The retention band. */
	@Column(name = "RETENTION_BAND_CD", length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.RetentionBandCodeEnum") })
	private RetentionBandCodeEnum retentionBand;

	/** The retention score pure with credit. */
	@Column(name = "RET_SCORE_PURE_WITH_CR_QTY", precision = 3, scale = 0)
	private Short retentionScorePureWithCredit;

	/** The retention score pure without credit. */
	@Column(name = "RET_SCORE_PURE_WITHOUT_CR_QTY", precision = 3, scale = 0)
	private Short retentionScorePureWithoutCredit;

	/** The customer value index pure with credit. */
	@Column(name = "CVI_PURE_WITH_CREDIT_QTY", precision = 3, scale = 0)
	private Short customerValueIndexPureWithCredit;

	/** The customer value index pure without credit. */
	@Column(name = "CVI_PURE_WITHOUT_CREDIT_QTY", precision = 5, scale = 0)
	private Short customerValueIndexPureWithoutCredit;

	/** The vehicle class. */
	@Column(name = "VEHICLE_CLASS_CD", length = 5)
	private String vehicleClass;

	/** The system vehicle class. */
	@Column(name = "VEHICLE_CLASS_SYS_CD", length = 5)
	private String vehicleClassSystem;

	/** The modification vehicle class. */
	@Column(name = "VEHICLE_CLASS_MOD_CD", length = 5)
	private String vehicleClassModification;

	/** The vehicle class occasional. */
	@Column(name = "VEHICLE_CLASS_OCCASIONAL_CD", length = 5)
	private String vehicleClassOccasional;

	/** The license suspension ind principal. */
	@Column(name = "LICENSE_SUSPENSION_PRINC_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean licenseSuspensionPrincipalIndicator;

	/** The principal driver high rated vehicle indicator. */
	@Column(name = "PRINC_DRVR_HIGH_RATED_VEH_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean principalDriverHighRatedVehicleIndicator;

	/** The vehicle. */
	@OneToOne(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER, mappedBy = "insuranceRisk")
	// @Fetch(FetchMode.JOIN) // Default is SELECT. Perf troubles (full scan)
	// with outer joins
	private Vehicle vehicle = null;

	/** The trailer. */
	@OneToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "insuranceRisk")
	private Trailer trailer = null;

	/** The insurance risk offers. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "insuranceRisk")
	private Set<InsuranceRiskOffer> insuranceRiskOffers = new HashSet<InsuranceRiskOffer>(0);

	/** The selected insurance risk offer. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "SELECTED_INS_RISK_OFFER_ID", updatable = true)
	private InsuranceRiskOffer selectedInsuranceRiskOffer = null;

	/** The selected insurance risk offer. */
	@Column(name = "INS_RISK_OFF_SYS_SELECTED_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean insuranceRiskOfferSystemSelectedIndicator;

	/** The municipal adjustment system code. */
	@Column(name = "MUNICIPAL_ADJUSTMENT_SYS_CD", length = 1)
	private String municipalAdjustmentSystemCode = null;

	/** The municipal adjustment modificatin code. */
	@Column(name = "MUNICIPAL_ADJUSTMENT_MOD_CD", length = 1)
	private String municipalAdjustmentModificationCode = null;

	/** The territory stat system code. */
	@Column(name = "TERRITORY_STAT_SYS_CD", length = 3)
	private String territoryStatSystemCode = null;

	/** The territory stat modification code. */
	@Column(name = "TERRITORY_STAT_MOD_CD", length = 3)
	private String territoryStatModificationCode = null;

	/** The party role in risks. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "insuranceRisk")
	private Set<PartyRoleInRisk> partyRoleInRisks = new HashSet<PartyRoleInRisk>(0);

	/** The coverages. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "insuranceRisk")
	@OrderBy("coverageRepositoryEntry ASC")
	private Set<Coverage> coverages = new HashSet<Coverage>(0);

	/** The rating risks. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "insuranceRisk")
	private Set<RatingRisk> ratingRisks = new HashSet<RatingRisk>(0);

	/** The diagnostics advice. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "insuranceRisk")
	private Set<DiagnosticAutomatedAdvice> diagnosticAdvices = new HashSet<DiagnosticAutomatedAdvice>(0);

	/** The claims. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "insuranceRisk")
	private Set<Claim> claims = new HashSet<Claim>(0);

	/** The claims. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "insuranceRisk")
	private Set<Conviction> convictions = new HashSet<Conviction>(0);

	/** The registered out of province indicator. */
	@Column(name = "RISK_REG_OUT_OF_PROVINCE_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean registeredOutOfProvinceIndicator;

	/** The you or spouse registered ownner indicator. */
	@Column(name = "POL_HLD_SPOUSE_REG_OWN_VEH_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean youOrSpouseRegisteredOwnnerIndicator;

	/** The proof driving record5 occ indicator. */
	@Column(name = "PROOF_DRIVING_RECORD5_OCC_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean proofDrivingRecord5OccIndicator;

	/** The Original Scenario Insurance Risk *. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_INSURANCE_RISK_ID", insertable = false, updatable = false)
	private InsuranceRisk originalScenarioInsuranceRisk;

	/** The action taken. */
	@Column(name = "ACTION_TAKEN_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ActionTakenCodeEnum") })
	private ActionTakenCodeEnum actionTaken = null;

	/** The number of stability months. */
	@Column(name = "NBR_STABILITY_MONTHS_QTY", precision = 3, scale = 0)
	private Short numberOfStabilityMonths;

	/** The road block indicator. */
	@Column(name = "ROAD_BLOCK_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean roadBlockIndicator;

	/** The inov forced by agent indicator. */
	@Column(name = "INOV_FORCED_BY_AGENT_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean inovForcedByAgentIndicator;

	/** The other registered owner indicator. */
	@Column(name = "OTHER_REGISTERED_OWNER_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean otherRegisteredOwnerIndicator = null;

	/** The customer value index for underwriting (prefered). */
	@Column(name = "CVI_PURE_FOR_UNDRWTR_PREF_QTY", precision = 3, scale = 0)
	private Short customerValueIndexPurePreferred;

	/** The customer value index for underwriting (regular). */
	@Column(name = "CVI_PURE_FOR_UNDRWTR_REG_QTY", precision = 3, scale = 0)
	private Short customerValueIndexPureRegular;

	/**
	 * RBRP-3 current or soon want to hold an insurrance for the vehicule indicator.
	 */
	@Column(name = "CURRENT_OR_SOON_VEH_HOLDER_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean currentOrSoonVehHolderIndicator;

	/** Rating territory */
	@Column(name = "RATING_TERRITORY_CD", length = 2)
	private String ratingTerritoryCode = null;

	/** The multi vehicle eligibility indicator */
	@Column(name = "MULT_VEH_DSCNT_ELIGIBILITY_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean multiVehicleDiscountEligibilityIndicator;

	/** The coverage options */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "insuranceRisk")
	private Set<CoverageOption> coverageOptions = new HashSet<CoverageOption>(0);

	@Column(name = "AUT_TERR_COLLISION_BY_PC_CD", length = 2)
	private String autoMobileTerritoryCollision;

	@Column(name = "AUT_TERR_COMP_BY_PC_CD", length = 2)
	private String autoMobileTerritoryComprehensive;

	@Column(name = "AUT_TERR_GLASS_BREAK_BY_PC_CD", length = 2)
	private String autoMobileTerritoryGlassBreak;

	@Column(name = "AUT_TERR_LIABILITY_BY_PC_CD", length = 2)
	private String autoMobileTerritoryLiability;

	@Column(name = "AUT_TERR_RATING_BY_PC_CD", length = 2)
	private String autoMobileTerritoryRating;

	@Column(name = "FIRST_LINE_POLICY_NBR", length = 30)
	private String firstLinePolicyNbr;

	/** The vehicle rate group medical expenses. */

	/** The web Msg Id. */
	@Column(name = "WEB_MSG_ID", precision = 3)
	private Integer webMsgId;

	/** The coding Class */
	@Column(name = "CODING_CLASS_CD", length = 5)
	private String codingClass;

	/** The commercial usage. */
	@OneToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "insuranceRisk")
	private CommercialUsage commercialUsage = null;

	/** The valuation amount. */
	@Column(name = "VALUATION_AMT", precision = 9, scale = 0)
	private Integer valuationAmount;

	/** (4.1.9) Value showing the risk level of AccidentBenefits according to a postal code. */
	@Column(name = "AUT_TERR_ACC_BNF_BY_PC_CD", length = 2)
	private String automobileTerritoryAccidentBenefits;

	/** (4.1.9) Value showing the risk level of Direct Compensation according to a postal code. */
	@Column(name = "AUT_TERR_DIR_COMP_BY_PC_CD", length = 2)
	private String automobileTerritoryDirectCompensation;

	/** (4.1.9) Value showing the risk level of Specified Perils according to a postal code. */
	@Column(name = "AUT_TERR_SPEC_PER_BY_PC_CD", length = 2)
	private String automobileTerritorySpecifiedPerils;

	/** (4.1.9) Correspond to the {@link #automobileTerritoryLiability} but for the scoring */
	@Column(name = "AUT_TERR_LIAB_SCR_BY_PC_CD", length = 2)
	private String automobileTerritoryLiabilityScoring;

	/** (4.1.9)  Correspond to {@link #automobileTerritoryAccidentBenefits} but for the scoring */
	@Column(name = "AUT_TERR_ACC_BNF_SCR_BY_PC_CD", length = 2)
	private String automobileTerritoryAccidentBenefitsScoring;

	/** (4.1.9) Correspond to the {@link #automobileTerritoryCollision} but for the scoring */
	@Column(name = "AUT_TERR_COLL_SCR_BY_PC_CD", length = 2)
	private String automobileTerritoryCollisionScoring;

	/** (4.1.9) Correspond to the {@link #automobileTerritoryComprehensive} but for the scoring */
	@Column(name = "AUT_TERR_COMP_SCR_BY_PC_CD", length = 2)
	private String automobileTerritoryComprehensiveScoring;

	/** (4.1.9) Correspond to the {@link #automobileTerritoryDirectCompensation} but for scoring */
	@Column(name = "AUT_TERR_DIR_COMP_SCR_BY_PC_CD", length = 2)
	private String automobileTerritoryDirectCompensationScoring;

	/** (4.1.9) Correspond to the {@link #automobileTerritorySpecifiedPerils} but for scoring */
	@Column(name = "AUT_TERR_SPEC_PER_SCR_BY_PC_CD", length = 2)
	private String automobileTerritorySpecifiedPerilsScoring;

	// TODO @pameunie uncomment 4.2.0 when ready in PLP, also add get/set-ters
	
//	/** (4.2.0) Value showing the risk level of All Perils according to a postal code.. */
//	@Column(name = "AUT_TERR_ALL_PERL_BY_PC_CD", length = 2)
//	private String autTerrAllPerilsByPostalCode;
//
//	/** (4.2.0) Value showing the risk level of All Perils according to a postal code by scoring. */
//	@Column(name = "AUT_TERR_ALL_PERL_SCR_BY_PC_CD", length = 2)
//	private String autTerrAllPerilsScoringByPostalCode;
//
//	/** (4.2.0) Value showing the risk level of Bodily Injury according to a postal code. */
//	@Column(name = "AUT_TERR_LB_BD_IJ_BY_PC_CD", length = 2)
//	private String autTerrLiabilityBodilyInjuryByPostalCode;
//
//	/** (4.2.0) Value showing the risk level of Bodily Injury according to a postal code by scoring. */
//	@Column(name = "AUT_TERR_LB_BD_IJ_SCR_BY_PC_CD", length = 2)
//	private String autTerrLiabilityBodilyInjuryScoringByPostalCode;
//
//	/** (4.2.0) Value showing the risk level of Property Damage according to a postal code. */
//	@Column(name = "AUT_TERR_LB_PR_DM_BY_PC_CD", length = 2)
//	private String autTerrLiabilityPropertyDamageByPostalCode;
//
//	/** (4.2.0) Value showing the risk level of Property Damage according to a postal code but scoring. */
//	@Column(name = "AUT_TERR_LB_PR_DM_SCR_BY_PC_CD", length = 2)
//	private String autTerrLiabilityPropertyDamageScoringByPostalCode;
//
//	/** (4.2.0) Value showing the risk level of Medical Expenses according to a postal code. */
//	@Column(name = "AUT_TERR_MED_EXP_BY_PC_CD", length = 2)
//	private String autTerrMedicalExpenseByPostalCode;
//
//	/** (4.2.0) Value showing the risk level of Medical Expenses according to a postal code but for scoring. */
//	@Column(name = "AUT_TERR_MED_EXP_SCR_BY_PC_CD", length = 2)
//	private String autTerrMedicalExpenseScoringByPostalCode;
//
//	/** (4.2.0) Value showing the risk level of Total Disability according to a postal code. */
//	@Column(name = "AUT_TERR_TOT_DISB_BY_PC_CD", length = 2)
//	private String autTerrTotalDisabilityByPostalCode;
//
//	/** (4.2.0) Value showing the risk level of Total Disability according to a postal code but for scoring. */
//	@Column(name = "AUT_TERR_TOT_DISB_SCR_BY_PC_CD", length = 2)
//	private String autTerrTotalDisabilityScoringByPostalCode;
		
	@Transient
	private Map<String, InsuranceRiskOffer> offers = null;

	@Transient
	private Map<String, Coverage> coveragesMap = null;

	/**
	 * Instantiates a new insurance risk.
	 */
	public InsuranceRisk() {
		// noarg constructor
	}

	/**
	 * Instantiates a new insurance risk.
	 *
	 * @param aPolicyVersion the a policy version
	 * @param riskTypeCode the risk type code
	 * @param insuranceRiskSeq the insurance risk seq
	 */
	public InsuranceRisk(PolicyVersion aPolicyVersion, RiskTypeCodeEnum riskTypeCode, short insuranceRiskSeq) {
		this.setPolicyVersion(aPolicyVersion);
		this.setRiskType(riskTypeCode);
		this.setInsuranceRiskSequence(insuranceRiskSeq);
	}

	/**
	 * @see com.ing.canada.plp.roadblock.Roadblockable#markAsRoadblocked()
	 */
	@Override
	public void markAsRoadblocked() {
		this.setRoadBlockIndicator(Boolean.TRUE);
	}

	/**
	 * @see com.ing.canada.plp.roadblock.Roadblockable#clearRoadblock()
	 */
	@Override
	public void clearRoadblock() {
		this.setRoadBlockIndicator(null);
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 *
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param aId the a id
	 *
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the policy version.
	 *
	 * @return the policy version
	 */
	@XmlTransient
	// parent
	public PolicyVersion getPolicyVersion() {
		return this.policyVersion;
	}

	/**
	 * Sets the policy version.
	 *
	 * @param aPolicyVersion the new policy version
	 */
	public void setPolicyVersion(PolicyVersion aPolicyVersion) {
		AssociationsHelper.updateOneToManyFields(aPolicyVersion, "insuranceRisks", this, "policyVersion");
	}

	/**
	 * Gets the credit score.
	 *
	 * @return the credit score
	 */
	public CreditScore getCreditScorePostalCode() {
		return this.creditScorePostalCode;
	}

	/**
	 * Sets the credit score.
	 *
	 * @param aCreditScore the new credit score
	 */
	public void setCreditScorePostalCode(CreditScore aCreditScore) {

		AssociationsHelper.updateOneToManyFields(aCreditScore, "insuranceRisks", this, "creditScorePostalCode");
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public Address getAddress() {
		return this.address;
	}

	/**
	 * Sets the address.
	 *
	 * @param aAddress the new address
	 */
	public void setAddress(Address aAddress) {
		AssociationsHelper.updateOneToManyFields(aAddress, "insuranceRisks", this, "address");
	}

	/**
	 * Gets the risk type.
	 *
	 * @return the risk type
	 */
	public RiskTypeCodeEnum getRiskType() {
		return this.riskType;
	}

	/**
	 * Sets the risk type.
	 *
	 * @param riskTypeCode the new risk type
	 */
	public void setRiskType(RiskTypeCodeEnum riskTypeCode) {
		this.riskType = riskTypeCode;
	}

	/**
	 * Gets the risk subtype.
	 *
	 * @return the risk subtype
	 */
	public RiskSubTypeCodeEnum getRiskSubtype() {
		return this.riskSubtype;
	}

	/**
	 * Sets the risk subtype.
	 *
	 * @param riskSubtypeCode the new risk subtype
	 */
	public void setRiskSubtype(RiskSubTypeCodeEnum riskSubtypeCode) {
		this.riskSubtype = riskSubtypeCode;
	}

	/**
	 * Gets the insurance risk sequence.
	 *
	 * @return the insurance risk sequence
	 */
	public short getInsuranceRiskSequence() {
		return this.insuranceRiskSequence;
	}

	/**
	 * Sets the insurance risk sequence.
	 *
	 * @param insuranceRiskSeq the new insurance risk sequence
	 */
	public void setInsuranceRiskSequence(short insuranceRiskSeq) {
		this.insuranceRiskSequence = insuranceRiskSeq;
	}

	/**
	 * Gets the proof driving record5 indicator.
	 *
	 * @return the proof driving record5 indicator
	 */
	public Boolean getProofDrivingRecord5Indicator() {
		return this.proofDrivingRecord5Indicator;
	}

	/**
	 * Sets the proof driving record5 indicator.
	 *
	 * @param aProofDrivingRecord5Indicator the new proof driving record5 indicator
	 */
	public void setProofDrivingRecord5Indicator(Boolean aProofDrivingRecord5Indicator) {
		this.proofDrivingRecord5Indicator = aProofDrivingRecord5Indicator;
	}

	/**
	 * Gets the good driver.
	 *
	 * @return the good driver
	 */
	public GoodDriverCodeEnum getGoodDriver() {
		return this.goodDriver;
	}

	/**
	 * Sets the good driver.
	 *
	 * @param goodDriverCode the new good driver
	 */
	public void setGoodDriver(GoodDriverCodeEnum goodDriverCode) {
		this.goodDriver = goodDriverCode;
	}

	public Date getGoodDriverSinceDate() {
		return goodDriverSinceDate;
	}

	public void setGoodDriverSinceDate(Date goodDriverSinceDate) {
		this.goodDriverSinceDate = goodDriverSinceDate;
	}

	public Date getGoodDriverSinceModDate() {
		return goodDriverSinceModDate;
	}

	public void setGoodDriverSinceModDate(Date goodDriverSinceModDate) {
		this.goodDriverSinceModDate = goodDriverSinceModDate;
	}

	public Date getGoodDriverSinceSysDate() {
		return goodDriverSinceSysDate;
	}

	public void setGoodDriverSinceSysDate(Date goodDriverSinceSysDate) {
		this.goodDriverSinceSysDate = goodDriverSinceSysDate;
	}

	/**
	 * Gets the creation date.
	 *
	 * @return the creation date
	 */
	public Date getCreationDate() {
		return this.creationDate;
	}

	/**
	 * Sets the creation date.
	 *
	 * @param aCreationDate the new creation date
	 */
	public void setCreationDate(Date aCreationDate) {
		this.creationDate = aCreationDate;
	}

	/**
	 * Gets the effective date.
	 *
	 * @return the effective date
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * Sets the effective date.
	 *
	 * @param aEffectiveDate the new effective date
	 */
	public void setEffectiveDate(Date aEffectiveDate) {
		this.effectiveDate = aEffectiveDate;
	}

	/**
	 * Gets the rating date.
	 *
	 * @return the rating date
	 */
	public Date getRatingDate() {
		return this.ratingDate;
	}

	/**
	 * Sets the rating date.
	 *
	 * @param aRatingDate the new rating date
	 */
	public void setRatingDate(Date aRatingDate) {
		this.ratingDate = aRatingDate;
	}

	/**
	 * Gets the flex percentage.
	 *
	 * @return the flex percentage
	 */
	public Short getFlexPercentage() {
		return this.flexPercentage;
	}

	/**
	 * Sets the flex percentage.
	 *
	 * @param aFlexPercentage the new flex percentage
	 */
	public void setFlexPercentage(Short aFlexPercentage) {
		this.flexPercentage = aFlexPercentage;
	}

	/**
	 * Gets the stability discount.
	 *
	 * @return the stability discount
	 */
	public Boolean getStabilityDiscountIndicator() {
		return this.stabilityDiscountIndicator;
	}

	/**
	 * Sets the stability discount.
	 *
	 * @param aStabilityDiscountIndicator the new stability discount
	 */
	public void setStabilityDiscountIndicator(Boolean aStabilityDiscountIndicator) {
		this.stabilityDiscountIndicator = aStabilityDiscountIndicator;
	}

	/**
	 * Gets the territory stat.
	 *
	 * @return the territory stat
	 */
	public String getTerritoryStat() {
		return this.territoryStat;
	}

	/**
	 * Sets the territory stat.
	 *
	 * @param territoryStatCode the new territory stat
	 */
	public void setTerritoryStat(String territoryStatCode) {
		this.territoryStat = territoryStatCode;
	}

	/**
	 * Gets the municipal adjustment.
	 *
	 * @return the municipal adjustment
	 */
	public String getMunicipalAdjustment() {
		return this.municipalAdjustment;
	}

	/**
	 * Sets the municipal adjustment.
	 *
	 * @param municipalAdjustmentCode the new municipal adjustment
	 */
	public void setMunicipalAdjustment(String municipalAdjustmentCode) {
		this.municipalAdjustment = municipalAdjustmentCode;
	}

	/**
	 * Gets the capping percentage.
	 *
	 * @return the capping percentage
	 */
	public Short getCappingPercentage() {
		return this.cappingPercentage;
	}

	/**
	 * Sets the capping percentage.
	 *
	 * @param aCappingPercentage the new capping percentage
	 */
	public void setCappingPercentage(Short aCappingPercentage) {
		this.cappingPercentage = aCappingPercentage;
	}

	/**
	 * Gets the quality risk level.
	 *
	 * @return the quality risk level
	 */
	public QualityRiskLevelCodeEnum getQualityRiskLevel() {
		return this.qualityRiskLevel;
	}

	/**
	 * Sets the quality risk level.
	 *
	 * @param qualityRiskLevelCode the new quality risk level
	 */
	public void setQualityRiskLevel(QualityRiskLevelCodeEnum qualityRiskLevelCode) {
		this.qualityRiskLevel = qualityRiskLevelCode;
	}

	/**
	 * Gets the annual premium.
	 *
	 * @return the annual premium
	 */
	public Integer getAnnualPremium() {
		return this.annualPremium;
	}

	/**
	 * Sets the annual premium.
	 *
	 * @param annualPremiumAmount the new annual premium
	 */
	public void setAnnualPremium(Integer annualPremiumAmount) {
		this.annualPremium = annualPremiumAmount;
	}

	public Double getMonthlyPremium() {
		/**
		 * This does not work, it should be the full term premium divided instead of annual premium
		 **/
		Double aPremium = null;

		if (this.getAnnualPremium() != null) {
			aPremium = new Double(this.getAnnualPremium());
			aPremium = aPremium / PolicyTermInMonthsEnum.TWELVE_MONTHS.getCode();
		}

		return aPremium;
	}

	public Double getRoundedMonthlyPremium() {
		return this.getMonthlyPremium() != null ? (Math.round(this.getMonthlyPremium() * 100.0) / 100.0) : null;
	}

	/**
	 * Gets the full term premium.
	 *
	 * @return the full term premium
	 */
	public Integer getFullTermPremium() {
		return this.fullTermPremium;
	}

	/**
	 * Sets the full term premium.
	 *
	 * @param fullTermPremiumAmount the new full term premium
	 */
	public void setFullTermPremium(Integer fullTermPremiumAmount) {
		this.fullTermPremium = fullTermPremiumAmount;
	}

	/**
	 * Gets the additional return premium.
	 *
	 * @return the additional return premium
	 */
	public Integer getAdditionalReturnPremium() {
		return this.additionalReturnPremium;
	}

	/**
	 * Sets the additional return premium.
	 *
	 * @param additionalReturnPremiumAmount the new additional return premium
	 */
	public void setAdditionalReturnPremium(Integer additionalReturnPremiumAmount) {
		this.additionalReturnPremium = additionalReturnPremiumAmount;
	}

	/**
	 * Gets the reason for absence of third party liability coverage.
	 *
	 * @return the reason for absence of third party liability coverage
	 */
	public ReasonAbsenceThirdPartyLiabilityCoverageCodeEnum getReasonForAbsenceOfThirdPartyLiabilityCoverage() {
		return this.reasonForAbsenceOfThirdPartyLiabilityCoverage;
	}

	/**
	 * Sets the reason for absence of third party liability coverage.
	 *
	 * @param rsnAbsThirdPrtyLblCvrgCode the new reason for absence of third party liability coverage
	 */
	public void setReasonForAbsenceOfThirdPartyLiabilityCoverage(ReasonAbsenceThirdPartyLiabilityCoverageCodeEnum rsnAbsThirdPrtyLblCvrgCode) {
		this.reasonForAbsenceOfThirdPartyLiabilityCoverage = rsnAbsThirdPrtyLblCvrgCode;
	}

	/**
	 * Gets the rsp transfer type.
	 *
	 * @return the rsp transfer type
	 */
	public RspTransferTypeCodeEnum getRspTransferType() {
		return this.rspTransferType;
	}

	/**
	 * Sets the rsp transfer type.
	 *
	 * @param rspTransferTypeCode the new rsp transfer type
	 */
	public void setRspTransferType(RspTransferTypeCodeEnum rspTransferTypeCode) {
		this.rspTransferType = rspTransferTypeCode;
	}

	/**
	 * Gets the rsp decision origin code.
	 *
	 * @return the rsp decision origin code
	 */
	public RspDecisionOriginCodeEnum getRspDecisionOriginCode() {
		return this.rspDecisionOriginCode;
	}

	/**
	 * Sets the rsp decision origin code.
	 *
	 * @param aRspDecisionOriginCode the new rsp decision origin code
	 */
	public void setRspDecisionOriginCode(RspDecisionOriginCodeEnum aRspDecisionOriginCode) {
		this.rspDecisionOriginCode = aRspDecisionOriginCode;
	}

	/**
	 * Gets the rsp mention at renewal code.
	 *
	 * @return the rsp mention at renewal code
	 */
	public RspMentionAtRenewalCodeEnum getRspMentionAtRenewalCode() {
		return this.rspMentionAtRenewalCode;
	}

	/**
	 * Sets the rsp mention at renewal code.
	 *
	 * @param aRspMentionAtRenewalCode the new rsp mention at renewal code
	 */
	public void setRspMentionAtRenewalCode(RspMentionAtRenewalCodeEnum aRspMentionAtRenewalCode) {
		this.rspMentionAtRenewalCode = aRspMentionAtRenewalCode;
	}

	/**
	 * Gets the rsp reason.
	 *
	 * @return the rsp reason
	 */
	public String getRspReason() {
		return this.rspReason;
	}

	/**
	 * Sets the rsp reason.
	 *
	 * @param aRspReason the new rsp reason
	 */
	public void setRspReason(String aRspReason) {
		this.rspReason = aRspReason;
	}

	/**
	 * Gets the rsp scoring.
	 *
	 * @return the rsp scoring
	 */
	public Byte getRspScoring() {
		return this.rspScoring;
	}

	/**
	 * Sets the rsp scoring.
	 *
	 * @param aRspScoring the new rsp scoring
	 */
	public void setRspScoring(Byte aRspScoring) {
		this.rspScoring = aRspScoring;
	}

	/**
	 * Gets the scoring adjustment percentage.
	 *
	 * @return the scoring adjustment percentage
	 */
	public Short getScoringAdjustmentPercentage() {
		return this.scoringAdjustmentPercentage;
	}

	/**
	 * Sets the scoring adjustment percentage.
	 *
	 * @param aScoringAdjustmentPercentage the new scoring adjustment percentage
	 */
	public void setScoringAdjustmentPercentage(Short aScoringAdjustmentPercentage) {
		this.scoringAdjustmentPercentage = aScoringAdjustmentPercentage;
	}

	/**
	 * Gets the competitivity adjustment percentage.
	 *
	 * @return the competitivity adjustment percentage
	 */
	public Short getCompetitivityAdjustmentPercentage() {
		return this.competitivityAdjustmentPercentage;
	}

	/**
	 * Sets the competitivity adjustment percentage.
	 *
	 * @param aCompetitivityAdjustmentPercentage the new competitivity adjustment percentage
	 */
	public void setCompetitivityAdjustmentPercentage(Short aCompetitivityAdjustmentPercentage) {
		this.competitivityAdjustmentPercentage = aCompetitivityAdjustmentPercentage;
	}

	/**
	 * Gets the competitivity score with credit.
	 *
	 * @return the competitivity score with credit
	 */
	public Short getCompetitivityScoreWithCredit() {
		return this.competitivityScoreWithCredit;
	}

	/**
	 * Sets the competitivity score with credit.
	 *
	 * @param competScoreWithCr the new competitivity score with credit
	 */
	public void setCompetitivityScoreWithCredit(Short competScoreWithCr) {
		this.competitivityScoreWithCredit = competScoreWithCr;
	}

	/**
	 * Gets the competitivity score without cr.
	 *
	 * @return the competitivity score without cr
	 */
	public Short getCompetitivityScoreWithoutCredit() {
		return this.competitivityScoreWithoutCredit;
	}

	/**
	 * Sets the competitivity score without cr.
	 *
	 * @param competScoreWithoutCr the new competitivity score without cr
	 */
	public void setCompetitivityScoreWithoutCredit(Short competScoreWithoutCr) {
		this.competitivityScoreWithoutCredit = competScoreWithoutCr;
	}

	/**
	 * Gets the retention band.
	 *
	 * @return the retention band
	 */
	public RetentionBandCodeEnum getRetentionBand() {
		return this.retentionBand;
	}

	/**
	 * Sets the retention band.
	 *
	 * @param retentionBandCode the new retention band
	 */
	public void setRetentionBand(RetentionBandCodeEnum retentionBandCode) {
		this.retentionBand = retentionBandCode;
	}

	/**
	 * Gets the retention score pure with credit.
	 *
	 * @return the retention score pure with credit
	 */
	public Short getRetentionScorePureWithCredit() {
		return this.retentionScorePureWithCredit;
	}

	/**
	 * Sets the retention score pure with credit.
	 *
	 * @param retScorePureWithCr the new retention score pure with credit
	 */
	public void setRetentionScorePureWithCredit(Short retScorePureWithCr) {
		this.retentionScorePureWithCredit = retScorePureWithCr;
	}

	/**
	 * Gets the retention score pure without credit.
	 *
	 * @return the retention score pure without credit
	 */
	public Short getRetentionScorePureWithoutCredit() {
		return this.retentionScorePureWithoutCredit;
	}

	/**
	 * Sets the retention score pure without credit.
	 *
	 * @param retScorePureWithoutCr the new retention score pure without credit
	 */
	public void setRetentionScorePureWithoutCredit(Short retScorePureWithoutCr) {
		this.retentionScorePureWithoutCredit = retScorePureWithoutCr;
	}

	/**
	 * Gets the customer value index pure with credit.
	 *
	 * @return the customer value index pure with credit
	 */
	public Short getCustomerValueIndexPureWithCredit() {
		return this.customerValueIndexPureWithCredit;
	}

	/**
	 * Sets the customer value index pure with credit.
	 *
	 * @param cviPureWithCredit the new customer value index pure with credit
	 */
	public void setCustomerValueIndexPureWithCredit(Short cviPureWithCredit) {
		this.customerValueIndexPureWithCredit = cviPureWithCredit;
	}

	/**
	 * Gets the customer value index pure without credit.
	 *
	 * @return the customer value index pure without credit
	 */
	public Short getCustomerValueIndexPureWithoutCredit() {
		return this.customerValueIndexPureWithoutCredit;
	}

	/**
	 * Sets the customer value index pure without credit.
	 *
	 * @param cviPureWithoutCredit the new customer value index pure without credit
	 */
	public void setCustomerValueIndexPureWithoutCredit(Short cviPureWithoutCredit) {
		this.customerValueIndexPureWithoutCredit = cviPureWithoutCredit;
	}

	/**
	 * Gets the vehicle class.
	 *
	 * @return the vehicle class
	 */
	public String getVehicleClass() {
		return this.vehicleClass;
	}

	/**
	 * Sets the vehicle class.
	 *
	 * @param vehicleClassCode the new vehicle class
	 */
	public void setVehicleClass(String vehicleClassCode) {
		this.vehicleClass = vehicleClassCode;
	}

	/**
	 * Gets the vehicle class occasional.
	 *
	 * @return the vehicle class occasional
	 */
	public String getVehicleClassOccasional() {
		return this.vehicleClassOccasional;
	}

	/**
	 * Sets the vehicle class occasional.
	 *
	 * @param vehicleClassOccasionalCode the new vehicle class occasional
	 */
	public void setVehicleClassOccasional(String vehicleClassOccasionalCode) {
		this.vehicleClassOccasional = vehicleClassOccasionalCode;
	}

	/**
	 * Gets the license suspension ind principal.
	 *
	 * @return the license suspension ind principal
	 */
	public Boolean getLicenseSuspensionPrincipalIndicator() {
		return this.licenseSuspensionPrincipalIndicator;
	}

	/**
	 * Sets the license suspension ind principal.
	 *
	 * @param licenseSuspensionPrincIndicator the new license suspension ind principal
	 */
	public void setLicenseSuspensionPrincipalIndicator(Boolean licenseSuspensionPrincIndicator) {
		this.licenseSuspensionPrincipalIndicator = licenseSuspensionPrincIndicator;
	}

	/**
	 * Gets the selected insurance risk offer.
	 *
	 * @return the selected insurance risk offer
	 */
	public Boolean getInsuranceRiskOfferSystemSelectedIndicator() {
		return this.insuranceRiskOfferSystemSelectedIndicator;
	}

	/**
	 * Sets the selected insurance risk offer.
	 *
	 * @param insRiskOffSysSelectedIndicator the new selected insurance risk offer
	 */
	public void setInsuranceRiskOfferSystemSelectedIndicator(Boolean insRiskOffSysSelectedIndicator) {
		this.insuranceRiskOfferSystemSelectedIndicator = insRiskOffSysSelectedIndicator;
	}

	/**
	 * Gets the vehicle.
	 *
	 * @return the vehicle
	 */
	public Vehicle getVehicle() {
		return this.vehicle;
	}

	/**
	 * Sets the vehicle.
	 *
	 * @param aVehicle the new vehicle
	 */
	public void setVehicle(Vehicle aVehicle) {
		AssociationsHelper.updateOneToOneFields(this, InsuranceRisk.class, "vehicle", aVehicle, Vehicle.class, "insuranceRisk");
	}

	/**
	 * Gets the insurance risk offers.
	 *
	 * @return the insurance risk offers
	 */
	@XmlElementWrapper(name = "insuranceRiskOffers")
	@XmlElement(name = "insuranceRiskOffer")
	public Set<InsuranceRiskOffer> getInsuranceRiskOffers() {
		return Collections.unmodifiableSet(this.insuranceRiskOffers);
	}

	/**
	 * Sets the insurance risk offers.
	 *
	 * @param aInsuranceRiskOffers the new insurance risk offers
	 */
	protected void setInsuranceRiskOffers(Set<InsuranceRiskOffer> aInsuranceRiskOffers) {
		this.insuranceRiskOffers = aInsuranceRiskOffers;
	}

	/**
	 * Adds the insurance risk offer.
	 *
	 * @param offer the offer
	 */
	public void addInsuranceRiskOffer(com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer offer) {
		AssociationsHelper.updateOneToManyFields(this, "insuranceRiskOffers", offer, "insuranceRisk");
	}

	/**
	 * Removes the insurance risk offer. If the offer you wish to remove is currently the selected one, the operation
	 * will fail with an IllegalStateException (you have to reset the selectedInsuranceRiskOffer reference to null
	 * first).
	 *
	 * @param offer the offer
	 *
	 * @exception IllegalStateException if the offer is currently selected (reset the reference to null first)
	 */
	public void removeInsuranceRiskOffer(com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer offer) {

		if (this.getSelectedInsuranceRiskOffer() != null && this.getSelectedInsuranceRiskOffer().equals(offer)) {
			throw new IllegalStateException("before you can remove the insurance risk offer, you must reset the selected insurance risk offer to null (because it's the one currently selected!).");
		}

		AssociationsHelper.updateOneToManyFields(null, "insuranceRiskOffers", offer, "insuranceRisk");
	}

	/**
	 * Gets the party role in risks.
	 *
	 * @return the party role in risks
	 */
	@XmlElementWrapper(name = "partyRoleInRisks")
	@XmlElement(name = "partyRoleInRisk")
	public Set<PartyRoleInRisk> getPartyRoleInRisks() {
		return Collections.unmodifiableSet(this.partyRoleInRisks);
	}

	/**
	 * Sets the party role in risks.
	 *
	 * @param aPartyRoleInRisks the new party role in risks
	 */
	protected void setPartyRoleInRisks(Set<PartyRoleInRisk> aPartyRoleInRisks) {
		this.partyRoleInRisks = aPartyRoleInRisks;
	}

	/**
	 * Adds the party role in risk.
	 *
	 * @param partyRoleInRisk the party role in risk
	 */
	public void addPartyRoleInRisk(com.ing.canada.plp.domain.party.PartyRoleInRisk partyRoleInRisk) {
		AssociationsHelper.updateOneToManyFields(this, "partyRoleInRisks", partyRoleInRisk, "insuranceRisk");
	}

	/**
	 * Removes the party role in risk.
	 *
	 * @param partyRoleInRisk the party role in risk
	 */
	public void removePartyRoleInRisk(com.ing.canada.plp.domain.party.PartyRoleInRisk partyRoleInRisk) {
		AssociationsHelper.updateOneToManyFields(null, "partyRoleInRisks", partyRoleInRisk, "insuranceRisk");
	}

	/**
	 * Gets Coverage as map with coverageCode key.
	 *
	 * @return a Coverage Map using coverage code as key
	 */
	public Map<String, Coverage> getCoveragesMappedByCoverageCode() {

		Iterator<Coverage> covs = this.coverages.iterator();
		HashMap<String, Coverage> res = new HashMap<String, Coverage>();

		while (covs.hasNext()) {
			Coverage curcov = covs.next();
			String covcode = curcov.getCoverageRepositoryEntry().getCoverageCode();
			Coverage returnCov = res.put(covcode, curcov);
			if (returnCov != null) {
				String message = "Two Coverages are associated to the same CoverageRepository (code=" + covcode + ") for InsuranceRisk " + this.getId().toString();
				throw new RuntimeException(message);
			}

		}
		return res;
	}

	/**
	 * Gets the coverages.
	 *
	 * @return the coverages
	 */
	@XmlElementWrapper(name = "coverages")
	@XmlElement(name = "coverages")
	public Set<Coverage> getCoverages() {
		return Collections.unmodifiableSet(this.coverages);
	}

	/**
	 * Sets the coverages.
	 *
	 * @param aCoverages the new coverages
	 */
	protected void setCoverages(Set<Coverage> aCoverages) {
		this.coverages = aCoverages;
	}

	/**
	 * Adds the coverage.
	 *
	 * @param coverage the coverage
	 */
	public void addCoverage(com.ing.canada.plp.domain.coverage.Coverage coverage) {
		AssociationsHelper.updateOneToManyFields(this, "coverages", coverage, "insuranceRisk");
	}

	/**
	 * Removes the coverage.
	 *
	 * @param coverage the coverage
	 */
	public void removeCoverage(com.ing.canada.plp.domain.coverage.Coverage coverage) {
		AssociationsHelper.updateOneToManyFields(null, "coverages", coverage, "insuranceRisk");
	}

	/**
	 * Gets the rating risks.
	 *
	 * @return the rating risks
	 */
	@XmlElementWrapper(name = "ratingRisks")
	@XmlElement(name = "ratingRisks")
	public Set<RatingRisk> getRatingRisks() {
		return Collections.unmodifiableSet(this.ratingRisks);
	}

	/**
	 * Sets the rating risks.
	 *
	 * @param aRatingRisks the new rating risks
	 */
	protected void setRatingRisks(Set<RatingRisk> aRatingRisks) {
		this.ratingRisks = aRatingRisks;
	}

	/**
	 * Adds the rating risk.
	 *
	 * @param ratingRisk the rating risk
	 */
	public void addRatingRisk(com.ing.canada.plp.domain.insurancerisk.RatingRisk ratingRisk) {
		AssociationsHelper.updateOneToManyFields(this, "ratingRisks", ratingRisk, "insuranceRisk");
	}

	/**
	 * Removes the rating risk.
	 *
	 * @param ratingRisk the rating risk
	 */
	public void removeRatingRisk(com.ing.canada.plp.domain.insurancerisk.RatingRisk ratingRisk) {
		AssociationsHelper.updateOneToManyFields(null, "ratingRisks", ratingRisk, "insuranceRisk");
	}

	/**
	 * Gets the trailer.
	 *
	 * @return the trailer
	 */
	public Trailer getTrailer() {
		return this.trailer;
	}

	/**
	 * Sets the trailer.
	 *
	 * @param aTrailer the new trailer
	 */
	public void setTrailer(Trailer aTrailer) {
		AssociationsHelper.updateOneToOneFields(this, InsuranceRisk.class, "trailer", aTrailer, Trailer.class, "insuranceRisk");
	}

	/**
	 * Gets the claims.
	 *
	 * @return the claims
	 */
	@XmlElementWrapper(name = "claims")
	@XmlElement(name = "claims")
	public Set<Claim> getClaims() {
		return this.claims;
	}

	/**
	 * Sets the claims.
	 *
	 * @param aClaims the new claims
	 */
	protected void setClaims(Set<Claim> aClaims) {
		this.claims = aClaims;
	}

	/**
	 * Adds the claim.
	 *
	 * @param claim the claim
	 */
	public void addClaim(com.ing.canada.plp.domain.insurancerisk.Claim claim) {
		AssociationsHelper.updateOneToManyFields(this, "claims", claim, "insuranceRisk");
	}

	/**
	 * Removes the claim.
	 *
	 * @param claim the claim
	 */
	public void removeClaim(com.ing.canada.plp.domain.insurancerisk.Claim claim) {
		AssociationsHelper.updateOneToManyFields(null, "claims", claim, "insuranceRisk");
	}

	/**
	 * Gets the convictions.
	 *
	 * @return the convictions
	 */
	@XmlElementWrapper(name = "convictions")
	@XmlElement(name = "conviction")
	public Set<Conviction> getConvictions() {
		return Collections.unmodifiableSet(this.convictions);
	}

	/**
	 * Sets the convictions.
	 *
	 * @param aConvictions the new convictions
	 */
	protected void setConviction(Set<Conviction> aConvictions) {
		this.convictions = aConvictions;
	}

	/**
	 * Adds the claim.
	 *
	 * @param claim the claim
	 */
	public void addConviction(Conviction aConviction) {
		AssociationsHelper.updateOneToManyFields(this, "convictions", aConviction, "insuranceRisk");
	}

	/**
	 * Removes the claim.
	 *
	 * @param aConviction the {@link Conviction}
	 */
	public void removeConviction(Conviction aConviction) {
		AssociationsHelper.updateOneToManyFields(null, "convictions", aConviction, "insuranceRisk");
	}

	/**
	 * Gets the expiry date.
	 *
	 * @return the expiry date
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * Sets the expiry date.
	 *
	 * @param aExpiryDate the new expiry date
	 */
	public void setExpiryDate(Date aExpiryDate) {
		this.expiryDate = aExpiryDate;
	}

	/**
	 * Gets the selected insurance risk offer.
	 *
	 * @return the selectedInsuranceRiskOffer
	 */
	public InsuranceRiskOffer getSelectedInsuranceRiskOffer() {
		return this.selectedInsuranceRiskOffer;
	}

	/**
	 * This method sets one of the children insurance risk offers as the selected one.
	 *
	 * @param aSelectedInsuranceRiskOffer the selectedInsuranceRiskOffer to set
	 *
	 * @exception IllegalStateException
	 */
	public void setSelectedInsuranceRiskOffer(InsuranceRiskOffer aSelectedInsuranceRiskOffer) {

		if (aSelectedInsuranceRiskOffer != null && !this.isChildOf(aSelectedInsuranceRiskOffer)) {
			throw new IllegalStateException("the insurance risk offer must be attached to this insurance risk (use 'addInsuranceRiskOffer' method), before it is set as the selected");
		}

		this.selectedInsuranceRiskOffer = aSelectedInsuranceRiskOffer;

	}

	/**
	 * This method sets one of the children insurance risk offers as the selected one. It also indicates if the
	 * selection was performed by the system or ther user.
	 *
	 * @param aSelectedInsuranceRiskOffer the selectedInsuranceRiskOffer to set
	 * @param isSystemSelected indicates if the selection is performed by the system
	 *
	 * @exception IllegalStateException
	 */
	public void setSelectedInsuranceRiskOffer(InsuranceRiskOffer aSelectedInsuranceRiskOffer, Boolean isSystemSelected) {
		this.setSelectedInsuranceRiskOffer(aSelectedInsuranceRiskOffer);
		this.setInsuranceRiskOfferSystemSelectedIndicator(isSystemSelected);
	}

	/**
	 * Checks if is child of.
	 *
	 * @param anInsuranceRiskOffer the an insurance risk offer
	 *
	 * @return true if the insurance risk offer is already attached to this insurance risk, false otherwise
	 */
	private Boolean isChildOf(InsuranceRiskOffer anInsuranceRiskOffer) {
		return this.getInsuranceRiskOffers().contains(anInsuranceRiskOffer);
	}

	/**
	 * Gets the municipal adjustment system code.
	 *
	 * @return the municipalAdjustmentSystemCode
	 */
	public String getMunicipalAdjustmentSystemCode() {
		return this.municipalAdjustmentSystemCode;
	}

	/**
	 * Sets the municipal adjustment system code.
	 *
	 * @param aMunicipalAdjustmentSystemCode the municipalAdjustmentSystemCode to set
	 */
	public void setMunicipalAdjustmentSystemCode(String aMunicipalAdjustmentSystemCode) {
		this.municipalAdjustmentSystemCode = aMunicipalAdjustmentSystemCode;
	}

	/**
	 * Gets the municipal adjustment modification code.
	 *
	 * @return the municipalAdjustmentModificationCode
	 */
	public String getMunicipalAdjustmentModificationCode() {
		return this.municipalAdjustmentModificationCode;
	}

	/**
	 * Sets the municipal adjustment modification code.
	 *
	 * @param aMunicipalAdjustmentModificationCode the municipalAdjustmentModificationCode to set
	 */
	public void setMunicipalAdjustmentModificationCode(String aMunicipalAdjustmentModificationCode) {
		this.municipalAdjustmentModificationCode = aMunicipalAdjustmentModificationCode;
	}

	/**
	 * Gets the territory stat system code.
	 *
	 * @return the territoryStatSystemCode
	 */
	public String getTerritoryStatSystemCode() {
		return this.territoryStatSystemCode;
	}

	/**
	 * Sets the territory stat system code.
	 *
	 * @param aTerritoryStatSystemCode the territoryStatSystemCode to set
	 */
	public void setTerritoryStatSystemCode(String aTerritoryStatSystemCode) {
		this.territoryStatSystemCode = aTerritoryStatSystemCode;
	}

	/**
	 * Gets the territory stat modification code.
	 *
	 * @return the territoryStatModificationCode
	 */
	public String getTerritoryStatModificationCode() {
		return this.territoryStatModificationCode;
	}

	/**
	 * Sets the territory stat modification code.
	 *
	 * @param aTerritoryStatModificationCode the territoryStatModificationCode to set
	 */
	public void setTerritoryStatModificationCode(String aTerritoryStatModificationCode) {
		this.territoryStatModificationCode = aTerritoryStatModificationCode;
	}

	/**
	 * Sets the good driver modified.
	 *
	 * @param aGoodDriverModified the goodDriverModified to set
	 */
	public void setGoodDriverModified(GoodDriverCodeEnum aGoodDriverModified) {
		this.goodDriverModified = aGoodDriverModified;
	}

	/**
	 * Gets the good driver modified.
	 *
	 * @return the goodDriverModified
	 */
	public GoodDriverCodeEnum getGoodDriverModified() {
		return this.goodDriverModified;
	}

	/**
	 * Sets the good driver system.
	 *
	 * @param aGoodDriverSystem the goodDriverSystem to set
	 */
	public void setGoodDriverSystem(GoodDriverCodeEnum aGoodDriverSystem) {
		this.goodDriverSystem = aGoodDriverSystem;
	}

	/**
	 * Gets the good driver system.
	 *
	 * @return the goodDriverSystem
	 */
	public GoodDriverCodeEnum getGoodDriverSystem() {
		return this.goodDriverSystem;
	}

	/**
	 * Sets the stability discount modified indicator.
	 *
	 * @param aStabilityDiscountModifiedIndicator the stabilityDiscountModifiedIndicator to set
	 */
	public void setStabilityDiscountModifiedIndicator(Boolean aStabilityDiscountModifiedIndicator) {
		this.stabilityDiscountModifiedIndicator = aStabilityDiscountModifiedIndicator;
	}

	/**
	 * Checks if is stability discount modified indicator.
	 *
	 * @return the stabilityDiscountModifiedIndicator
	 */
	public Boolean getStabilityDiscountModifiedIndicator() {
		return this.stabilityDiscountModifiedIndicator;
	}

	/**
	 * Sets the stability discount system indicator.
	 *
	 * @param aStabilityDiscountSystemIndicator the stabilityDiscountSystemIndicator to set
	 */
	public void setStabilityDiscountSystemIndicator(Boolean aStabilityDiscountSystemIndicator) {
		this.stabilityDiscountSystemIndicator = aStabilityDiscountSystemIndicator;
	}

	/**
	 * Checks if is stability discount system indicator.
	 *
	 * @return the stabilityDiscountSystemIndicator
	 */
	public Boolean getStabilityDiscountSystemIndicator() {
		return this.stabilityDiscountSystemIndicator;
	}

	/**
	 * Gets the deductible discount.
	 *
	 * @return the deductibleDiscount
	 */
	public Integer getDeductibleDiscount() {
		return this.deductibleDiscount;
	}

	/**
	 * Sets the deductible discount.
	 *
	 * @param aDeductibleDiscount the deductibleDiscount to set
	 */
	public void setDeductibleDiscount(Integer aDeductibleDiscount) {
		this.deductibleDiscount = aDeductibleDiscount;
	}

	/**
	 * Gets the deductible discount modification.
	 *
	 * @return the deductibleDiscountModification
	 */
	public Integer getDeductibleDiscountModification() {
		return this.deductibleDiscountModification;
	}

	/**
	 * Sets the deductible discount modification.
	 *
	 * @param aDeductibleDiscountModification the deductibleDiscountModification to set
	 */
	public void setDeductibleDiscountModification(Integer aDeductibleDiscountModification) {
		this.deductibleDiscountModification = aDeductibleDiscountModification;
	}

	/**
	 * Gets the deductible discount system.
	 *
	 * @return the deductibleDiscountSystem
	 */
	public Integer getDeductibleDiscountSystem() {
		return this.deductibleDiscountSystem;
	}

	/**
	 * Sets the deductible discount system.
	 *
	 * @param aDeductibleDiscountSystem the deductibleDiscountSystem to set
	 */
	public void setDeductibleDiscountSystem(Integer aDeductibleDiscountSystem) {
		this.deductibleDiscountSystem = aDeductibleDiscountSystem;
	}

	/**
	 * Gets the vehicle class modification.
	 *
	 * @return the vehicleClassModification
	 */
	public String getVehicleClassModification() {
		return this.vehicleClassModification;
	}

	/**
	 * Sets the vehicle class modification.
	 *
	 * @param aVehicleClassModification the vehicleClassModification to set
	 */
	public void setVehicleClassModification(String aVehicleClassModification) {
		this.vehicleClassModification = aVehicleClassModification;
	}

	/**
	 * Gets the vehicle class system.
	 *
	 * @return the vehicleClassSystem
	 */
	public String getVehicleClassSystem() {
		return this.vehicleClassSystem;
	}

	/**
	 * Sets the vehicle class system.
	 *
	 * @param aVehicleClassSystem the vehicleClassSystem to set
	 */
	public void setVehicleClassSystem(String aVehicleClassSystem) {
		this.vehicleClassSystem = aVehicleClassSystem;
	}

	/**
	 * Checks if is proof driving record5 occ indicator.
	 *
	 * @return the boolean
	 */
	public Boolean getProofDrivingRecord5OccIndicator() {
		return this.proofDrivingRecord5OccIndicator;
	}

	/**
	 * Sets the proof driving record5 occ indicator.
	 *
	 * @param aProofDrivingRecord5OccIndicator the new proof driving record5 occ indicator
	 */
	public void setProofDrivingRecord5OccIndicator(Boolean aProofDrivingRecord5OccIndicator) {
		this.proofDrivingRecord5OccIndicator = aProofDrivingRecord5OccIndicator;
	}

	/**
	 * Checks if is registered out of province indicator.
	 *
	 * @return the boolean
	 */
	public Boolean getRegisteredOutOfProvinceIndicator() {
		return this.registeredOutOfProvinceIndicator;
	}

	/**
	 * Sets the registered out of province indicator.
	 *
	 * @param aRegisteredOutOfProvinceIndicator the new registered out of province indicator
	 */
	public void setRegisteredOutOfProvinceIndicator(Boolean aRegisteredOutOfProvinceIndicator) {
		this.registeredOutOfProvinceIndicator = aRegisteredOutOfProvinceIndicator;
	}

	/**
	 * Checks if is you or spouse registered ownner indicator.
	 *
	 * @return the boolean
	 */
	public Boolean getYouOrSpouseRegisteredOwnnerIndicator() {
		return this.youOrSpouseRegisteredOwnnerIndicator;
	}

	/**
	 * Sets the you or spouse registered ownner indicator.
	 *
	 * @param aYouOrSpouseRegisteredOwnnerIndicator the new you or spouse registered ownner indicator
	 */
	public void setYouOrSpouseRegisteredOwnnerIndicator(Boolean aYouOrSpouseRegisteredOwnnerIndicator) {
		this.youOrSpouseRegisteredOwnnerIndicator = aYouOrSpouseRegisteredOwnnerIndicator;
	}

	/**
	 * Gets the original scenario insurance risk.
	 *
	 * @return the original scenario insurance risk
	 */
	@XmlTransient
	// reference source
	public InsuranceRisk getOriginalScenarioInsuranceRisk() {
		return this.originalScenarioInsuranceRisk;
	}

	/**
	 * Sets the original scenario insurance risk.
	 *
	 * @param anOriginalScenarioInsuranceRisk the new original scenario insurance risk
	 */
	public void setOriginalScenarioInsuranceRisk(InsuranceRisk anOriginalScenarioInsuranceRisk) {
		this.originalScenarioInsuranceRisk = anOriginalScenarioInsuranceRisk;
	}

	/**
	 * Gets the action taken.
	 *
	 * @return the action taken
	 */
	public ActionTakenCodeEnum getActionTaken() {
		return this.actionTaken;
	}

	/**
	 * Sets the action taken.
	 *
	 * @param anActionTaken the new action taken
	 */
	public void setActionTaken(ActionTakenCodeEnum anActionTaken) {
		this.actionTaken = anActionTaken;
	}

	/**
	 * Gets the number of stability months.
	 *
	 * @return the number of stability months
	 */
	public Short getNumberOfStabilityMonths() {
		return this.numberOfStabilityMonths;
	}

	/**
	 * Sets the number of stability months.
	 *
	 * @param aNumberOfStabilityMonths the new number of stability months
	 */
	public void setNumberOfStabilityMonths(Short aNumberOfStabilityMonths) {
		this.numberOfStabilityMonths = aNumberOfStabilityMonths;
	}

	/**
	 * Gets the road block indicator.
	 *
	 * @return the road block indicator
	 */
	public Boolean getRoadBlockIndicator() {
		return this.roadBlockIndicator;
	}

	/**
	 * Sets the road block indicator.
	 *
	 * @param aRoadBlockIndicator the new road block indicator
	 */
	public void setRoadBlockIndicator(Boolean aRoadBlockIndicator) {
		this.roadBlockIndicator = aRoadBlockIndicator;
	}

	/**
	 * Gets the inov forced by agent indicator.
	 *
	 * @return the inov forced by agent indicator
	 */
	public Boolean getInovForcedByAgentIndicator() {
		return this.inovForcedByAgentIndicator;
	}

	/**
	 * Sets the inov forced by agent indicator.
	 *
	 * @param aInovForcedByAgentIndicator the new inov forced by agent indicator
	 */
	public void setInovForcedByAgentIndicator(Boolean aInovForcedByAgentIndicator) {
		this.inovForcedByAgentIndicator = aInovForcedByAgentIndicator;
	}

	/**
	 * @return the otherRegisteredOwnerIndicator
	 */
	public Boolean getOtherRegisteredOwnerIndicator() {
		return this.otherRegisteredOwnerIndicator;
	}

	/**
	 * @param anOtherRegisteredOwnerIndicator the otherRegisteredOwnerIndicator to set
	 */
	public void setOtherRegisteredOwnerIndicator(Boolean anOtherRegisteredOwnerIndicator) {
		this.otherRegisteredOwnerIndicator = anOtherRegisteredOwnerIndicator;
	}

	public Short getCustomerValueIndexPurePreferred() {
		return this.customerValueIndexPurePreferred;
	}

	public void setCustomerValueIndexPurePreferred(Short aCustomerValueIndexPurePreferred) {
		this.customerValueIndexPurePreferred = aCustomerValueIndexPurePreferred;
	}

	public Short getCustomerValueIndexPureRegular() {
		return this.customerValueIndexPureRegular;
	}

	public void setCustomerValueIndexPureRegular(Short aCustomerValueIndexPureRegular) {
		this.customerValueIndexPureRegular = aCustomerValueIndexPureRegular;
	}

	public Boolean getPrincipalDriverHighRatedVehicleIndicator() {
		return this.principalDriverHighRatedVehicleIndicator;
	}

	public void setPrincipalDriverHighRatedVehicleIndicator(Boolean aPrincipalDriverHighRatedVehicleIndicator) {
		this.principalDriverHighRatedVehicleIndicator = aPrincipalDriverHighRatedVehicleIndicator;
	}

	public Short getCustomerValueIndexAdjustedWithCredit() {
		return this.customerValueIndexAdjustedWithCredit;
	}

	public void setCustomerValueIndexAdjustedWithCredit(Short aCustomerValueIndexAdjustedWithCredit) {
		this.customerValueIndexAdjustedWithCredit = aCustomerValueIndexAdjustedWithCredit;
	}

	public Boolean getCurrentOrSoonVehHolderIndicator() {
		return this.currentOrSoonVehHolderIndicator;
	}

	public void setCurrentOrSoonVehHolderIndicator(Boolean aCurrentOrSoonVehHolderIndicator) {
		this.currentOrSoonVehHolderIndicator = aCurrentOrSoonVehHolderIndicator;
	}

	/**
	 * Gets the diagnostic advices.
	 *
	 * @return the diagnostic advices
	 */
	@XmlElementWrapper(name = "diagnosticAdvices")
	@XmlElement(name = "diagnosticAdvice")
	public Set<DiagnosticAutomatedAdvice> getDiagnosticAdvices() {
		return this.diagnosticAdvices;
	}

	/**
	 * Sets the diagnostic advices.
	 *
	 * @param aDiagnosticAdvices the new diagnostic advices
	 */
	public void setDiagnosticAdvices(Set<DiagnosticAutomatedAdvice> aDiagnosticAdvices) {
		this.diagnosticAdvices = aDiagnosticAdvices;
	}

	/**
	 * Adds the diagnostic advice.
	 *
	 * @param anDiagnostic Diagnostic advice
	 */
	public void addDiagnosticAutomatedAdvice(com.ing.canada.plp.domain.diagnostics.DiagnosticAutomatedAdvice anDiagnostic) {
		AssociationsHelper.updateOneToManyFields(this, "diagnosticAdvices", anDiagnostic, "insuranceRisk");
	}

	/**
	 * Removes the diagnostic advice.
	 *
	 * @param anDiagnostic Diagnostic advice
	 */
	public void removeDiagnosticAutomatedAdvice(com.ing.canada.plp.domain.diagnostics.DiagnosticAutomatedAdvice anDiagnostic) {
		AssociationsHelper.updateOneToManyFields(null, "diagnosticAdvices", anDiagnostic, "insuranceRisk");
	}

	public void setRatingTerritoryCode(String ratingTerritoryCode) {
		this.ratingTerritoryCode = ratingTerritoryCode;
	}

	public String getRatingTerritoryCode() {
		return this.ratingTerritoryCode;
	}

	/**
	 * Get insurance risk offer from provided code.
	 *
	 * @param code the code
	 * @return {@link InsuranceRiskOffer}
	 */
	public InsuranceRiskOffer getOffer(String code) {

		if (this.offers == null) {
			this.offers = new HashMap<String, InsuranceRiskOffer>();

			for (InsuranceRiskOffer offer : this.getPolicyVersion().getLatestPolicyOfferRating().getInsuranceRisksOffers()) {
				if (offer.getInsuranceRisk().getId().equals(this.getId())) {
					this.offers.put(offer.getOfferType().getCode(), offer);
				}
			}
		}

		return this.offers.get(code);
	}

	public Boolean getMultiVehicleDiscountEligibilityIndicator() {
		return this.multiVehicleDiscountEligibilityIndicator;
	}

	public void setMultiVehicleDiscountEligibilityIndicator(Boolean multiVehicleDiscountEligibilityIndicator) {
		this.multiVehicleDiscountEligibilityIndicator = multiVehicleDiscountEligibilityIndicator;
	}

	@XmlElementWrapper(name = "coverageOptions")
	@XmlElement(name = "coverageOption")
	public Set<CoverageOption> getCoverageOptions() {
		return this.coverageOptions;
	}

	public void setCoverageOptions(Set<CoverageOption> coverageOptions) {
		this.coverageOptions = coverageOptions;
	}

	/**
	 * Adds the coverage options
	 *
	 * @param coverageOption {@link CoverageOption}
	 */
	public void addCoverageOption(CoverageOption coverageOption) {
		AssociationsHelper.updateOneToManyFields(this, "coverageOptions", coverageOption, "insuranceRisk");
	}

	/**
	 * Removes the coverage options
	 *
	 * @param coverageOption {@link CoverageOption}
	 */
	public void removeCoverageOption(CoverageOption coverageOption) {
		AssociationsHelper.updateOneToManyFields(null, "coverageOptions", coverageOption, "insuranceRisk");
	}

	public String getAutoMobileTerritoryCollision() {
		return this.autoMobileTerritoryCollision;
	}

	public void setAutoMobileTerritoryCollision(String autoMobileTerritoryCollision) {
		this.autoMobileTerritoryCollision = autoMobileTerritoryCollision;
	}

	public String getAutoMobileTerritoryComprehensive() {
		return this.autoMobileTerritoryComprehensive;
	}

	public void setAutoMobileTerritoryComprehensive(String autoMobileTerritoryComprehensive) {
		this.autoMobileTerritoryComprehensive = autoMobileTerritoryComprehensive;
	}

	public String getAutoMobileTerritoryGlassBreak() {
		return this.autoMobileTerritoryGlassBreak;
	}

	public void setAutoMobileTerritoryGlassBreak(String autoMobileTerritoryGlassBreak) {
		this.autoMobileTerritoryGlassBreak = autoMobileTerritoryGlassBreak;
	}

	public String getAutoMobileTerritoryLiability() {
		return this.autoMobileTerritoryLiability;
	}

	public void setAutoMobileTerritoryLiability(String autoMobileTerritoryLiability) {
		this.autoMobileTerritoryLiability = autoMobileTerritoryLiability;
	}

	public String getAutoMobileTerritoryRating() {
		return this.autoMobileTerritoryRating;
	}

	public void setAutoMobileTerritoryRating(String autoMobileTerritoryRating) {
		this.autoMobileTerritoryRating = autoMobileTerritoryRating;
	}

	public String getFirstLinePolicyNbr() {
		return this.firstLinePolicyNbr;
	}

	public void setFirstLinePolicyNbr(String firstLinePolicyNbr) {
		this.firstLinePolicyNbr = firstLinePolicyNbr;
	}

	public Coverage getCoverage(String code) {

		if (this.coveragesMap == null) {

			Map<String, Coverage> tempCoverages = new HashMap<String, Coverage>();

			for (Coverage coverage : this.getCoverages()) {
				if (coverage.getCoverageSelectedIndicator()) {
					tempCoverages.put(coverage.getCoverageRepositoryEntry().getCoverageCode(), coverage);
				}
			}

			this.coveragesMap = tempCoverages;
		}

		return this.coveragesMap.get(code);
	}

	/**
	 * @return the webMsgId
	 */
	public Integer getWebMsgId() {
		return this.webMsgId;
	}

	/**
	 * @param webMsgId the webMsgId to set
	 */
	public void setWebMsgId(Integer webMsgId) {
		this.webMsgId = webMsgId;
	}

	/**
	 * @return the codingClass
	 */
	public String getCodingClass() {
		return this.codingClass;
	}

	/**
	 * @param codingClass the codingClass to set
	 */
	public void setCodingClass(String codingClass) {
		this.codingClass = codingClass;
	}

	/**
	 * @return the commercialUsage
	 */

	public CommercialUsage getCommercialUsage() {
		return this.commercialUsage;
	}

	// public void setTrailer(Trailer aTrailer) {
	// AssociationsHelper.updateOneToOneFields(this, InsuranceRisk.class, "trailer", aTrailer, Trailer.class,
	// "insuranceRisk");
	// }
	//
	//
	/**
	 * Sets the trailer.
	 *
	 * @param commercialUsage the commercialUsage to set
	 */
	public void setCommercialUsage(CommercialUsage aCommercialUsage) {
		AssociationsHelper.updateOneToOneFields(this, InsuranceRisk.class, "commercialUsage", aCommercialUsage, CommercialUsage.class, "insuranceRisk");
	}

	public Integer getValuationAmount() {
		return this.valuationAmount;
	}

	public void setValuationAmount(Integer valuationAmount) {
		this.valuationAmount = valuationAmount;
	}

	public String getAutomobileTerritoryAccidentBenefits() {
		return this.automobileTerritoryAccidentBenefits;
	}

	public void setAutomobileTerritoryAccidentBenefits(String automobileTerritoryAccidentBenefits) {
		this.automobileTerritoryAccidentBenefits = automobileTerritoryAccidentBenefits;
	}

	public String getAutomobileTerritoryDirectCompensation() {
		return this.automobileTerritoryDirectCompensation;
	}

	public void setAutomobileTerritoryDirectCompensation(String automobileTerritoryDirectCompensation) {
		this.automobileTerritoryDirectCompensation = automobileTerritoryDirectCompensation;
	}

	public String getAutomobileTerritorySpecifiedPerils() {
		return this.automobileTerritorySpecifiedPerils;
	}

	public void setAutomobileTerritorySpecifiedPerils(String automobileTerritorySpecifiedPerils) {
		this.automobileTerritorySpecifiedPerils = automobileTerritorySpecifiedPerils;
	}

	public String getAutomobileTerritoryLiabilityScoring() {
		return this.automobileTerritoryLiabilityScoring;
	}

	public void setAutomobileTerritoryLiabilityScoring(String automobileTerritoryLiabilityScoring) {
		this.automobileTerritoryLiabilityScoring = automobileTerritoryLiabilityScoring;
	}

	public String getAutomobileTerritoryAccidentBenefitsScoring() {
		return this.automobileTerritoryAccidentBenefitsScoring;
	}

	public void setAutomobileTerritoryAccidentBenefitsScoring(String automobileTerritoryAccidentBenefitsScoring) {
		this.automobileTerritoryAccidentBenefitsScoring = automobileTerritoryAccidentBenefitsScoring;
	}

	public String getAutomobileTerritoryCollisionScoring() {
		return this.automobileTerritoryCollisionScoring;
	}

	public void setAutomobileTerritoryCollisionScoring(String automobileTerritoryCollisionScoring) {
		this.automobileTerritoryCollisionScoring = automobileTerritoryCollisionScoring;
	}

	public String getAutomobileTerritoryComprehensiveScoring() {
		return this.automobileTerritoryComprehensiveScoring;
	}

	public void setAutomobileTerritoryComprehensiveScoring(String automobileTerritoryComprehensiveScoring) {
		this.automobileTerritoryComprehensiveScoring = automobileTerritoryComprehensiveScoring;
	}

	public String getAutomobileTerritoryDirectCompensationScoring() {
		return this.automobileTerritoryDirectCompensationScoring;
	}

	public void setAutomobileTerritoryDirectCompensationScoring(String automobileTerritoryDirectCompensationScoring) {
		this.automobileTerritoryDirectCompensationScoring = automobileTerritoryDirectCompensationScoring;
	}

	public String getAutomobileTerritorySpecifiedPerilsScoring() {
		return this.automobileTerritorySpecifiedPerilsScoring;
	}

	public void setAutomobileTerritorySpecifiedPerilsScoring(String automobileTerritorySpecifiedPerilsScoring) {
		this.automobileTerritorySpecifiedPerilsScoring = automobileTerritorySpecifiedPerilsScoring;
	}

}
