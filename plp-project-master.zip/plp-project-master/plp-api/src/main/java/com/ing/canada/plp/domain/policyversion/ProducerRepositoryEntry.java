/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.policyversion;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.enums.BranchCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * ProducerRepositoryEntry entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "PRODUCER_REPOSITORY_ENTRY", uniqueConstraints = {})
public class ProducerRepositoryEntry extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "PRODUCER_REPOSITORY_ENTRY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "ProducerRepositoryEntrySequence")
	@SequenceGenerator(name = "ProducerRepositoryEntrySequence", sequenceName = "PRODUCER_REPOSITORY_ENTRY_SEQ", allocationSize = 5)
	private Long id;

	/** The agent number. */
	@Column(name = "AGENT_NBR", nullable = false, length = 12)
	private String agentNumber;

	/** The branch. */
	@Column(name = "BRANCH_CD", length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.BranchCodeEnum") })
	private BranchCodeEnum branch;

	/** The underwriting team. */
	@Column(name = "UNDERWRITING_TEAM_NBR", length = 2)
	private String underwritingTeam;

	/** The marketing territory. */
	@Column(name = "MARKETING_TERRITORY_CD", length = 2)
	private String marketingTerritory;

	/**
	 * Instantiates a new producer repository entry.
	 */
	public ProducerRepositoryEntry() {
		// noarg constructor
	}

	/**
	 * Instantiates a new producer repository entry.
	 * 
	 * @param aAgentNumber the a agent number
	 */
	public ProducerRepositoryEntry(String aAgentNumber) {
		setAgentNumber(aAgentNumber);
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the agent number.
	 * 
	 * @return the agent number
	 */
	public String getAgentNumber() {
		return this.agentNumber;
	}

	/**
	 * Sets the agent number.
	 * 
	 * @param aAgentNumber the new agent number
	 */
	public void setAgentNumber(String aAgentNumber) {
		this.agentNumber = aAgentNumber;
	}

	/**
	 * Gets the branch.
	 * 
	 * @return the branch
	 */
	public BranchCodeEnum getBranch() {
		return this.branch;
	}

	/**
	 * Sets the branch.
	 * 
	 * @param branchCode the new branch
	 */
	public void setBranch(BranchCodeEnum branchCode) {
		this.branch = branchCode;
	}

	/**
	 * Gets the underwriting team.
	 * 
	 * @return the underwriting team
	 */
	public String getUnderwritingTeam() {
		return this.underwritingTeam;
	}

	/**
	 * Sets the underwriting team.
	 * 
	 * @param underwritingTeamNumber the new underwriting team
	 */
	public void setUnderwritingTeam(String underwritingTeamNumber) {
		this.underwritingTeam = underwritingTeamNumber;
	}

	/**
	 * Gets the marketing territory.
	 * 
	 * @return the marketing territory
	 */
	public String getMarketingTerritory() {
		return this.marketingTerritory;
	}

	/**
	 * Sets the marketing territory.
	 * 
	 * @param marketingTerritoryCode the new marketing territory
	 */
	public void setMarketingTerritory(String marketingTerritoryCode) {
		this.marketingTerritory = marketingTerritoryCode;
	}
}
