/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import static com.ing.canada.plp.domain.enums.ConvictionTypeCodeEnum.MAJOR;
import static com.ing.canada.plp.domain.enums.ConvictionTypeCodeEnum.MINOR;

import org.apache.commons.lang.StringUtils;

import com.ing.canada.plp.domain.ManufacturingContext;

/**
 * The Enum ConvictionCodeEnum. The enum code is used to fill the <tt>CONVICTION_CD</tt> of the Conviction table. It
 * also maps to a severity for the given conviction.
 * 
 * @author sbulzak
 */
public enum ConvictionCodeEnum {

	/** Careless driving **/
	CARELESS_DRIVING("CD", "CD", ConvictionTypeCodeEnum.SERIOUS),
	/** Criminal negligence **/
	CRIMINAL_NEGLIGENCE("CN", "CN", ConvictionTypeCodeEnum.SERIOUS),
	/** Dangerous driving **/
	DANGEROUS_DRIVING("DD", "DD", ConvictionTypeCodeEnum.SERIOUS),
	/** Driving with suspended license **/
	DRIVING_WITH_SUSPENDED_LICENSE("DUS", "DUS", ConvictionTypeCodeEnum.SERIOUS),
	/** Driving without insurance **/
	DRIVING_WITHOUT_INSURANCE("OMVNI", "OMVNI", ConvictionTypeCodeEnum.MAJOR),
	/** Drug/alcohol-related offences **/
	DRUG_ALCOHOL_RELATED_OFFENCES("IMP", "IMP", ConvictionTypeCodeEnum.SERIOUS),
	/** Failure to carry/produce proof of insurance **/
	FAILURE_TO_CARRY_PRODUCE_PROOF_OF_INSURANCE("FCIC", "FCIC", ConvictionTypeCodeEnum.MINOR),
	/** Failure to obey traffic sign/signal **/
	FAILURE_TO_OBEY_TRAFFIC_SIGN_SIGNAL("TS", "TS", ConvictionTypeCodeEnum.MINOR),
	/** Failure to remain at an accident **/
	FAILURE_TO_REMAIN_AT_AN_ACCIDENT("FTSSA", "FTSSA", ConvictionTypeCodeEnum.SERIOUS),
	/** Failure to report an accident/damage **/
	FAILURE_TO_REPORT_AN_ACCIDENT_DAMAGE("FRA", "FRA", ConvictionTypeCodeEnum.MAJOR),
	/** Failure to stop for police **/
	FAILURE_TO_STOP_FOR_POLICE("FTSPO", "FTSPO", ConvictionTypeCodeEnum.MAJOR),
	/** Failure to wear seat belt **/
	FAILURE_TO_WEAR_SEAT_BELT("SB", "SB", ConvictionTypeCodeEnum.MINOR),
	/** Following too closely (tailgating) **/
	FOLLOWING_TOO_CLOSELY_TAILGATING("TFTC", "FTC", ConvictionTypeCodeEnum.MINOR),
	/** G1/G2 license infractions - non alcohol **/
	G1_G2_LICENCE_INFRACTIONS_NON_ALCOHOL("GNA", "MAJOR", ConvictionTypeCodeEnum.MAJOR),
	/** G1/G2 license infractions - alcohol **/
	G1_G2_LICENCE_INFRACTIONS_ALCOHOL("GAL", "SECTD", ConvictionTypeCodeEnum.SERIOUS),
	/** Improper passing - school bus **/
	IMPROPER_PASSING_SCHOOL_BUS("PSB", "PSB", ConvictionTypeCodeEnum.MAJOR),
	/** Racing **/
	RACING("RAC", "RAC", ConvictionTypeCodeEnum.SERIOUS),
	/** Improper passing/speeding� schools or playgrounds **/
	IMPROPER_PASSING_SPEEDING_SCHOOLS_OR_PLAYGROUNDS("PSG", "PSG", ConvictionTypeCodeEnum.MAJOR),
	/** Speeding less than 50 km/h over limit **/
	SPEEDING_LESS_THAN_50_KM_H_OVER_LIMIT("SP1", "SP", ConvictionTypeCodeEnum.MINOR),
	/** Speeding 50 km/h to 60 km/h over limit **/
	SPEEDING_50_KM_H_TO_60_KM_H_OVER_LIMIT("SP2", "MAJOR", ConvictionTypeCodeEnum.MAJOR),
	/** Speeding 60 kms or more over speed limit **/
	SPEEDING_60_KMS_OR_MORE_OVER_SPEED_LIMIT("SP3", "SECTD", ConvictionTypeCodeEnum.SERIOUS),
	/** Signaling offences **/
	SIGNALLING_OFFENCES("FTS", "FTS", ConvictionTypeCodeEnum.MINOR),
	/** Unsafe vehicle **/
	UNSAFE_VEHICLE("UV", "UV", ConvictionTypeCodeEnum.MINOR),
	/** Other minor conviction **/
	OTHER_MINOR_CONVICTION("OT1", "MINOR", ConvictionTypeCodeEnum.MINOR),
	/** Other major conviction **/
	OTHER_MAJOR_CONVICTION("OT2", "MAJOR", ConvictionTypeCodeEnum.MAJOR),
	/** Other serious/criminal conviction **/
	OTHER_SERIOUS_CRIMINAL_CONVICTION("OT3", "SECTD", ConvictionTypeCodeEnum.SERIOUS),

	// added for Intact Alberta
	/** The failure to give way. */
	FAILURE_TO_GIVE_WAY("FTY", "FTY", ConvictionTypeCodeEnum.MINOR),
	/** The improper passing. */
	IMPROPER_PASSING("IP", "IP", ConvictionTypeCodeEnum.MINOR),
	/** The IMPROPE r_ passin g_ schoo l_ bu s_2. */
	IMPROPER_PASSING_SCHOOL_BUS_2("IPSB", "IP", ConvictionTypeCodeEnum.MINOR),
	/** Failure to remain at an accident **/
	FAILURE_TO_REMAIN_AT_AN_ACCIDENT_AB("FTSSA", "FTSSA", ConvictionTypeCodeEnum.MAJOR),
	/** The stunting. */
	STUNTING("STN", "STN", ConvictionTypeCodeEnum.MINOR), 
	
	/** 
	 *  Avoid using this code as it has no meaning for other systems. 
	 *  It was added to keep the compatibility with Belair/GP AB, that for some reason were feeding the field with 'CONV' in the adapters.
	 *  */
	CONVICTION("CONV", null, null),
	
	FINE_2_PTS("MIN2", "MINOR", MINOR),
	FINE_3_PTS("MIN3", "MINOR", MINOR),
	FINE_6_PTS("DWC", "MAJOR", MAJOR);

	/** the unique code **/
	private String code;

	/** The csio code. */
	private String csioCode;

	/** The severity. */
	private ConvictionTypeCodeEnum severity;

	/**
	 * Instantiates a new conviction code enum.
	 * 
	 * @param code the code
	 * @param csioCode the csio code
	 * @param severity the severity
	 */
	private ConvictionCodeEnum(String code, String csioCode, ConvictionTypeCodeEnum severity) {
		this.code = code;
		this.csioCode = csioCode;
		this.severity = severity;
	}

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Gets the severity.
	 * 
	 * @return the severity
	 */
	public ConvictionTypeCodeEnum getSeverity() {
		return this.severity;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the conviction code enum
	 */
	public static ConvictionCodeEnum valueOfCode(String value, ManufacturingContext aManufacturingContext) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		// Special case, the same code "FTSSA" is reused with a different severity in Intact Alberta
		if (value.equals(FAILURE_TO_REMAIN_AT_AN_ACCIDENT.getCode())) {
			if (isIntactAlberta(aManufacturingContext)) {
				return FAILURE_TO_REMAIN_AT_AN_ACCIDENT_AB;
			}
			return FAILURE_TO_REMAIN_AT_AN_ACCIDENT;
		}

		for (ConvictionCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}
		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}

	/**
	 * Gets the CSIO code.
	 * 
	 * @return the CSIO code
	 */
	public String getCsioCode() {
		return this.csioCode;
	}

	/**
	 * Sets the CSIO code.
	 * 
	 * @param csioCode the new CSIO code
	 */
	public void setCsioCode(String csioCode) {
		this.csioCode = csioCode;
	}

	private static boolean isIntactAlberta(ManufacturingContext aManufacturingContext) {
		if (aManufacturingContext == null)
			return false;
		return ManufacturerCompanyCodeEnum.ING_WESTERN_REGION.equals(aManufacturingContext.getManufacturerCompany())
				&& ProvinceCodeEnum.ALBERTA.equals(aManufacturingContext.getProvince())
				&& DistributionChannelCodeEnum.THROUGH_BROKERS.equals(aManufacturingContext.getDistributionChannel());
	}

}
