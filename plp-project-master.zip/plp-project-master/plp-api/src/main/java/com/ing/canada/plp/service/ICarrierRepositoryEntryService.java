/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;
import com.ing.canada.plp.domain.party.CarrierRepositoryEntry;
import com.ing.canada.plp.domain.party.CarrierRepositoryEntryId;

/**
 * The Interface ICarrierRepositoryEntryService.
 * 
 * @author ylaberge
 */
public interface ICarrierRepositoryEntryService {

	/**
	 * Gets the carrier repository entries sorted by english name.
	 * 
	 * @param aProvinceCode the province code
	 * 
	 * @return the carrier repository entries sorted english
	 * 
	 * @deprecated use the version with manufacturerCode instead
	 */
	@Deprecated
	List<CarrierRepositoryEntry> getCarrierRepositoryEntrySortedEnglish(ProvinceCodeEnum aProvinceCode);

	/**
	 * Gets the carrier repository entries sorted by english name.
	 * 
	 * @param aProvinceCode the province code
	 * @param manufacturerCode the manufacturer code
	 * 
	 * @return the carrier repository entries sorted english
	 */
	List<CarrierRepositoryEntry> getCarrierRepositoryEntrySortedEnglish(ProvinceCodeEnum aProvinceCode,
			ManufacturerCompanyCodeEnum manufacturerCode);

	/**
	 * Gets the carrier repository entries sorted by french name.
	 * 
	 * @param aProvinceCode the province code
	 * 
	 * @return the carrier repository entries sorted french
	 * 
	 * @deprecated use the version with manufacturerCode instead
	 */
	@Deprecated
	List<CarrierRepositoryEntry> getCarrierRepositoryEntrySortedFrench(ProvinceCodeEnum aProvinceCode);

	/**
	 * Gets the carrier repository entries sorted by french name.
	 * 
	 * @param aProvinceCode the province code
	 * @param manufacturerCode the manufacturer code
	 * 
	 * @return the carrier repository entries sorted french
	 */
	List<CarrierRepositoryEntry> getCarrierRepositoryEntrySortedFrench(ProvinceCodeEnum aProvinceCode,
			ManufacturerCompanyCodeEnum manufacturerCode);

	/**
	 * Gets a specific carrier repository entry by english carrier name.
	 * 
	 * @param aCarrierName the carrier name
	 * @param aProvinceCode the province
	 * 
	 * @return the carrier repository entry
	 * 
	 * @deprecated use the version with manufacturerCode instead
	 */
	@Deprecated
	CarrierRepositoryEntry getCarrierRepositoryEntryByCarrierNameEnglish(String aCarrierName,
			ProvinceCodeEnum aProvinceCode);

	/**
	 * Gets a specific carrier repository entry by english carrier name.
	 * 
	 * @param aCarrierName the carrier name
	 * @param aProvinceCode the province
	 * @param manufacturerCode the manufacturer code
	 * 
	 * @return the carrier repository entry
	 */
	CarrierRepositoryEntry getCarrierRepositoryEntryByCarrierNameEnglish(String aCarrierName,
			ProvinceCodeEnum aProvinceCode, ManufacturerCompanyCodeEnum manufacturerCode);

	/**
	 * Gets a specific carrier repository entry by french carrier name.
	 * 
	 * @param aCarrierName the carrier name
	 * @param aProvinceCode the province
	 * 
	 * @return the carrier repository entry
	 * 
	 * @deprecated use the version with manufacturerCode instead
	 */
	@Deprecated
	CarrierRepositoryEntry getCarrierRepositoryEntryByCarrierNameFrench(String aCarrierName,
			ProvinceCodeEnum aProvinceCode);

	/**
	 * Gets a specific carrier repository entry by french carrier name.
	 * 
	 * @param aCarrierName the carrier name
	 * @param aProvinceCode the province
	 * @param manufacturerCode the manufacturer code
	 * 
	 * @return the carrier repository entry
	 */
	CarrierRepositoryEntry getCarrierRepositoryEntryByCarrierNameFrench(String aCarrierName,
			ProvinceCodeEnum aProvinceCode, ManufacturerCompanyCodeEnum manufacturerCode);

	/**
	 * Gets a specific carrier repository entry by a carrier code.
	 * 
	 * @param aCarrierCode the carrier code
	 * 
	 * @return the carrier repository entry set
	 * 
	 * @deprecated use getCarrierRepositoryEntryByCarrierCodeManuf
	 */
	@Deprecated
	List<CarrierRepositoryEntry> getCarrierRepositoryEntryByCarrierCode(String aCarrierCode);

	/**
	 * Gets a specific carrier repository entry by carrier repository entry id.
	 * 
	 * @param aCarrierRepositoryEntryId the carrier repository entry id
	 * 
	 * @return the carrier repository entry
	 */
	CarrierRepositoryEntry getCarrierRepositoryEntryById(CarrierRepositoryEntryId aCarrierRepositoryEntryId);

	/**
	 * Gets a specific carrier repository entry by carrier code, province and manufacturer.
	 * 
	 * @param aCarrierCd the carrier code
	 * @param aProvinceCode the province
	 * @param manufacturerCode the manufacturer code
	 * 
	 * @return the carrier repository entry
	 */
	CarrierRepositoryEntry getCarrierRepositoryEntryByCarrierCodeManuf(String aCarrierCd,
			ProvinceCodeEnum aProvinceCode, ManufacturerCompanyCodeEnum manufacturerCode);

}
