/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum EndorsementProcessingTypeCodeEnum.
 */
public enum EndorsementProcessingTypeCodeEnum {

	REFERENCE_OR_EF_DISPLAY_PROCESSING("0"), EF_DISPLAY_ONLY_PROCESSING("1"), REFERENCE_ONLY_PROCESSING("2"), PROCESSING_BASED_ON_THE_EF_ASSOCIATED_INDICATOR(
			"3");


	/**
	 * Instantiates a new endorsement processing type code enum.
	 * 
	 * @param aCode the a code
	 */
	private EndorsementProcessingTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the endorsement processing type code enum
	 */
	public static EndorsementProcessingTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (EndorsementProcessingTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
