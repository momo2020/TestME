/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum RspMentionAtRenewalCodeEnum.
 */
public enum RspMentionAtRenewalCodeEnum {

	CONDITIONAL("C"), NO("N"), YES("Y");

	/**
	 * Instantiates a new rsp mention at renewal code enum.
	 * 
	 * @param aCode the a code
	 */
	private RspMentionAtRenewalCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the rsp mention at renewal code enum
	 */
	public static RspMentionAtRenewalCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (RspMentionAtRenewalCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
