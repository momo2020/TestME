/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum BusinessSourceCodeEnum.
 */
public enum BusinessSourceCodeEnum {

	COMPANY_ACQUISITION("A"), 
	FLEXIBILITY_BANK("B"), 
	SUPPLEMENT_TO_CLIENTS_PORTFOLIO("C"),
	DIRECT_MAIL("D"),
	EXISTING("E"),
	TRANSFER_OTHER_CIRCUMSTANCES("F"),
	INGDIRECT("G"), 
	INTERNET("I"),
	OUTBOUND("J"),
	KANETIX("K"), 
	LOCAL_EVENTS("L"), 
	NEWSPAPER_INSERT("M"),
	NEW_BUSINESS("N"), 
	OPTIONS_N_BELAIR_AUTO("O"),
	REGIONAL_CAMPAIGN("P"),
	REQUOTE("Q"),
	POLICY_REPLACING_ANOTHER("R"),
	ONLINE_SEARCH("S"),
	NEGOTIATED_PORTFOLIO_TRANSFER("T"),
	LOYAL_CLIENT_OF_BROKER("V"),
	RESERVED_FOR_COMPANY_USE("W"),
	OPTIONS_B_BELAIR_AUTO("X"),
	YELLOW_PAGES("Y"),
	TARGET_MARKETING("1"),
	MASS_MARKETING("2"),
	NEWS_PAPER("3"),
	TELEVISION("4"),
	SYNTH_MEMBER("6"),
	PREVIOUS_EXISTING_CLIENT("7"),
	THIRD_PARTY_REFERRAL("8"),
	OTHER("9");

	/**
	 * Instantiates a new business source code enum.
	 * 
	 * @param aCode the a code
	 */
	private BusinessSourceCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the business source code enum
	 */
	public static BusinessSourceCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (BusinessSourceCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
