/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import java.util.Locale;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum LanguageCodeEnum.
 */
public enum LanguageCodeEnum {

	FRENCH("FRE", "fr"), //
	ENGLISH("ENG", "en"), //
	BOTH("BOT", "bo");

	/**
	 * Instantiates a new language code enum.
	 * 
	 * @param aCode the a code
	 */

	private LanguageCodeEnum(String code, String codeISO) {
		this.code = code;
		this.codeISO = codeISO;
	}

	/** The code. */
	private String code = null;

	/** The ISO code of the language */
	private String codeISO;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Gets the code ISO.
	 * 
	 * @return the code iso
	 */
	public String getCodeISO() {
		return this.codeISO;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the language code enum
	 */
	public static LanguageCodeEnum valueOfCode(String value) {
		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (LanguageCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}
		}
		throw new IllegalArgumentException("no enum value found for code: " + value);
	}

	/**
	 * Value of code ISO.
	 * 
	 * @param value the value
	 * 
	 * @return the language code enum
	 */
	public static LanguageCodeEnum valueOfCodeISO(String value) {
		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (LanguageCodeEnum v : values()) {
			if (v.codeISO.equals(value)) {
				return v;
			}
		}
		throw new IllegalArgumentException("no enum value found for code: " + value);
	}

	/**
	 * Returns the corresponding LanguageCodeEnum matching the specified locale
	 * 
	 * @param locale the locale
	 * 
	 * @return the language code enum
	 */
	public static LanguageCodeEnum fromLocale(Locale locale) {
		if (locale == null) {
			return null;
		} else if (StringUtils.isBlank(locale.getLanguage())) {
			return null;
		}

		for (LanguageCodeEnum v : values()) {
			if (v.codeISO.equals(locale.getLanguage())) {
				return v;
			}
		}
		throw new IllegalArgumentException("no enum value found for locale: " + locale.toString());
	}

	/**
	 * Helper method to determin if the language is french
	 * 
	 * @return true if this equal French
	 */
	public boolean isFrench() {
		return equals(FRENCH);
	}

	/**
	 * Helper method to determin if the language is english
	 * 
	 * @return true if this equal English
	 */
	public boolean isEnglish() {
		return equals(ENGLISH);
	}
}
