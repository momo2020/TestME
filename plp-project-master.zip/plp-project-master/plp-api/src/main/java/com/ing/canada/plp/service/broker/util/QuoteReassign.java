package com.ing.canada.plp.service.broker.util;

import java.util.List;

import com.ing.canada.plp.domain.insurancepolicy.InsurancePolicy;

public class QuoteReassign {

	private List<InsurancePolicy> policies = null;

	private long brokerId = 0;

	public QuoteReassign() {
	}

	public List<InsurancePolicy> getPolicies() {
		return this.policies;
	}

	public void setPolicies(List<InsurancePolicy> policies) {
		this.policies = policies;
	}

	public long getBrokerId() {
		return this.brokerId;
	}

	public void setBrokerId(long brokerId) {
		this.brokerId = brokerId;
	}

	public String toString() {
		return "[quotes=" + this.getPolicies() + ", broker id" + this.getBrokerId() + "]";
	}

}
