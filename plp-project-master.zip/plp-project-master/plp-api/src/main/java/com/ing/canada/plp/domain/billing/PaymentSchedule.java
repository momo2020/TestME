/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.billing;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * PaymentSchedule entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "PAYMENT_SCHEDULE", uniqueConstraints = {})
public class PaymentSchedule extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "PAYMENT_SCHEDULE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "PaymentScheduleSequence")
	@SequenceGenerator(name = "PaymentScheduleSequence", sequenceName = "PAYMENT_SCHEDULE_SEQ", allocationSize = 5)
	protected Long id = null;

	/** The billing. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "POLICY_VERSION_ID", nullable = false, updatable = true)
	protected Billing billing;

	/** The payment date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "PAYMENT_DT", nullable = false, length = 7)
	protected Date paymentDate;

	/** The payment amount. */
	@Column(name = "PAYMENT_AMT", nullable = false, precision = 11)
	protected BigDecimal paymentAmount;

	/** The payment schedule seq. */
	@Column(name = "PAYMENT_SCHEDULE_SEQ", precision = 3, scale = 0)
	protected Short paymentScheduleSequence;

	/**
	 * The system date time.
	 * 
	 * Added 01/11/2010 by wguandiq This was added to fix PM5158 where payments were not properly sorted on AutoQuote's
	 * confirmation page.
	 */
	@Column(name = "SYSTEM_CREATE_TS", length = 11, insertable = false, updatable = false)
	protected Date systemDateTime;

	/**
	 * Instantiates a new payment schedule.
	 */
	public PaymentSchedule() {
		// noarg constructor
	}

	/**
	 * Instantiates a new payment schedule.
	 * 
	 * @param aBilling the a billing
	 * @param aPaymentDate the a payment date
	 * @param aPaymentAmount the a payment amount
	 */
	public PaymentSchedule(Billing aBilling, Date aPaymentDate, BigDecimal aPaymentAmount) {
		setBilling(aBilling);
		setPaymentDate(aPaymentDate);
		setPaymentAmount(aPaymentAmount);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the payment amount.
	 * 
	 * @return the payment amount
	 */
	public BigDecimal getPaymentAmount() {
		return this.paymentAmount;
	}

	/**
	 * Sets the payment amount.
	 * 
	 * @param aPaymentAmount the new payment amount
	 */
	public void setPaymentAmount(BigDecimal aPaymentAmount) {
		this.paymentAmount = aPaymentAmount;
	}

	/**
	 * Gets the payment date.
	 * 
	 * @return the payment date
	 */
	public Date getPaymentDate() {
		return this.paymentDate;
	}

	/**
	 * Sets the payment date.
	 * 
	 * @param aPaymentDate the new payment date
	 */
	public void setPaymentDate(Date aPaymentDate) {
		this.paymentDate = aPaymentDate;
	}

	/**
	 * Gets the payment schedule seq.
	 * 
	 * @return the payment schedule seq
	 */
	public Short getPaymentScheduleSequence() {
		return this.paymentScheduleSequence;
	}

	/**
	 * Sets the payment schedule seq.
	 * 
	 * @param aPaymentScheduleSeq the new payment schedule seq
	 */
	public void setPaymentScheduleSequence(Short aPaymentScheduleSeq) {
		this.paymentScheduleSequence = aPaymentScheduleSeq;
	}

	/**
	 * Gets the billing.
	 * 
	 * @return the billing
	 */
	public Billing getBilling() {
		return this.billing;
	}

	/**
	 * Sets the billing.
	 * 
	 * @param aBilling the new billing
	 */
	public void setBilling(Billing aBilling) {
		AssociationsHelper.updateOneToManyFields(aBilling, "paymentSchedules", this, "billing");
	}

	/**
	 * Gets the system date time.
	 * 
	 * @return the system date time
	 */
	public Date getSystemDateTime() {
		return this.systemDateTime;
	}

	/**
	 * Sets the system date time.
	 * 
	 * @param aSystemDateTime the new system date time
	 */
	public void setSystemDateTime(Date aSystemDateTime) {
		this.systemDateTime = aSystemDateTime;
	}

}
