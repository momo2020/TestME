/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

/**
 * The Enum SubActivityComplementInfoEnum. The enum name is used to fill the <tt>ATTRIBUTE_VALUE</tt> of the
 * complement info table. The field <tt>attributeName</tt> is used to fill the <tt>ATTRIBUTE_NAME</tt> of the
 * complement info table.
 * 
 * @author Octavian Cismasu
 */
public enum SubActivityComplementInfoEnum {
	SUSP_OFFER("EMAIL_NOTIF_TYPE"), SUSP_OFFER_EXPIRY("EMAIL_NOTIF_TYPE"), SUSP_OFFER_BIND("EMAIL_NOTIF_TYPE"), SUSP_OFFER_BIND_FINAL(
			"EMAIL_NOTIF_TYPE"), SUSP_OFFER_BIND_WORKITEM("CRM_NOTIF_TYPE"), ROADBLOCK("ROADBLOCK");

	/** The attribute name. */
	private String attributeName;

	private SubActivityComplementInfoEnum(String attributeNameToSet) {
		this.attributeName = attributeNameToSet;
	}

	public String getAttributeName() {
		return this.attributeName;
	}

	public void setAttributeName(String anAttributeName) {
		this.attributeName = anAttributeName;
	}
}
