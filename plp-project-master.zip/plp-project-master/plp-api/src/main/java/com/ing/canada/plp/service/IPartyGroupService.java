/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.party.GroupRepositoryEntry;
import com.ing.canada.plp.domain.party.PartyGroup;

/**
 * This interface exposes services required to manage partygroup related entities.
 * 
 * @author mblouin
 * 
 */
public interface IPartyGroupService extends ICRUDService<PartyGroup> {
	// no-op - All operations are in the parent class

	/**
	 * creates a new group repository entry .
	 * 
	 * @param aGroupRepositoryEntry the a group repository entry
	 * 
	 * @return the persistent repository entry
	 */
	GroupRepositoryEntry createGroupRepositoryEntry(GroupRepositoryEntry aGroupRepositoryEntry);

}
