/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.billing;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.annotation.CaseSensitive;
import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.CreditCardCompanyCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * Account entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "ACCOUNT", uniqueConstraints = {})
public class Account extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "ACCOUNT_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "AccountSequence")
	@SequenceGenerator(name = "AccountSequence", sequenceName = "ACCOUNT_SEQ", allocationSize = 5)
	private Long id;

	/** The financial institution number. */
	@Column(name = "FINANCIAL_INSTITUTION_NBR", length = 64)
	@CaseSensitive
	private String financialInstitutionNumber;

	/** The routing number. */
	@Column(name = "ROUTING_NBR", length = 64)
	@CaseSensitive
	private String routingNumber;

	/** The account number. */
	@Column(name = "ACCOUNT_NBR", length = 64)
	@CaseSensitive
	private String accountNumber;

	/** The bank account holder name. */
	@Column(name = "BANK_ACCOUNT_HOLDER_NAME_TXT", length = 64)
	private String bankAccountHolderName;

	/** The credit card company code. */
	@Column(name = "CREDIT_CARD_COMPANY_CD", length = 64)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = {
			@Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.CreditCardCompanyCodeEnum"),
			@Parameter(name = "encrypted", value = "true") })
	@CaseSensitive
	private CreditCardCompanyCodeEnum creditCardCompanyCode;

	/**
	 * The credit card account number. It's encrypted as a base64 string when persisted. In the memory object the string
	 * is unencrypted.
	 */
	@Column(name = "CREDIT_CARD_ACCOUNT_NBR", length = 64)
	@CaseSensitive
	private String creditCardAccountNumber;
	
	/**
	 * The credit card token, it's a key into an external system that contains the client credit card information.
	 */
	@Column(name = "CREDIT_CARD_TOKEN_ID", length = 25)
	@CaseSensitive
	private String creditCardToken;
	
	/**
	 * The credit card token, it's a key into an external system that contains the client credit card information.
	 */
	@Column(name = "CREDIT_CARD_ACCOUNT_MASK_NBR", length = 16)
	@CaseSensitive
	private String creditCardAccountNumberMask;
	
	/**
	 * The credit card expiry date. It's encrypted as a base64 string when persisted. In the memory object the string is
	 * unencrypted.
	 */
	@Column(name = "CREDIT_CARD_EXPIRY_DT", length = 64)
	@CaseSensitive
	private String creditCardExpiryDate;

	/**
	 * The credit card holder name. It's encrypted as a base64 string when persisted. In the memory object the string is
	 * unencrypted.
	 */
	@Column(name = "CREDIT_CARD_HOLDER_NAME_TXT", length = 64)
	// @Type(type = "com.ing.canada.plp.dao.mapping.EncryptedUserType")
	@CaseSensitive
	private String creditCardHolderName;

	/** The billings. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "account")
	private Set<Billing> billings = new HashSet<Billing>(0);
	
	/** If the account owner is the same as the policy holder. */
	@Column(name = "ACCT_HLD_SAME_AS_POL_HLD_IND", length = 1)
	@Type(type = "yes_no")
	protected Boolean accountHolderSameAsPolicyHolderInd;
	
	/**
	 * Instantiates a new account.
	 */
	public Account() {
		// noarg constructor
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the financial institution number.
	 * 
	 * @return the financial institution number
	 */
	public String getFinancialInstitutionNumber() {
		return this.financialInstitutionNumber;
	}

	/**
	 * Sets the financial institution number.
	 * 
	 * @param aFinancialInstitutionNumber the new financial institution number
	 */
	public void setFinancialInstitutionNumber(String aFinancialInstitutionNumber) {
		this.financialInstitutionNumber = aFinancialInstitutionNumber;
	}

	/**
	 * Gets the routing number.
	 * 
	 * @return the routing number
	 */
	public String getRoutingNumber() {
		return this.routingNumber;
	}

	/**
	 * Sets the routing number.
	 * 
	 * @param aRoutingNumber the new routing number
	 */
	public void setRoutingNumber(String aRoutingNumber) {
		this.routingNumber = aRoutingNumber;
	}

	/**
	 * Gets the account number.
	 * 
	 * @return the account number
	 */
	public String getAccountNumber() {
		return this.accountNumber;
	}

	/**
	 * Sets the account number.
	 * 
	 * @param aAccountNumber the new account number
	 */
	public void setAccountNumber(String aAccountNumber) {
		this.accountNumber = aAccountNumber;
	}

	/**
	 * Gets the bank account holder name.
	 * 
	 * @return the bank account holder name
	 */
	public String getBankAccountHolderName() {
		return this.bankAccountHolderName;
	}

	/**
	 * Sets the bank account holder name.
	 * 
	 * @param aBankAccountHolderName the new bank account holder name
	 */
	public void setBankAccountHolderName(String aBankAccountHolderName) {
		this.bankAccountHolderName = aBankAccountHolderName;
	}

	/**
	 * Gets the credit card company code.
	 * 
	 * @return the credit card company code
	 */
	public CreditCardCompanyCodeEnum getCreditCardCompanyCode() {
		return this.creditCardCompanyCode;
	}

	/**
	 * Sets the credit card company code.
	 * 
	 * @param aCreditCardCompanyCode the new credit card company code
	 */
	public void setCreditCardCompanyCode(CreditCardCompanyCodeEnum aCreditCardCompanyCode) {
		this.creditCardCompanyCode = aCreditCardCompanyCode;
	}

	/**
	 * Gets the credit card account number.
	 * 
	 * @return the credit card account number
	 */
	public String getCreditCardAccountNumber() {
		return this.creditCardAccountNumber;
	}

	/**
	 * Sets the credit card account number.
	 * 
	 * @param aCreditCardAccountNumber the new credit card account number
	 */
	public void setCreditCardAccountNumber(String aCreditCardAccountNumber) {
		this.creditCardAccountNumber = aCreditCardAccountNumber;
	}
	
	/**
	 * @return the creditCardToken
	 */
	public String getCreditCardToken() {
		return this.creditCardToken;
	}

	/**
	 * @param aCreditCardToken the creditCardToken to set
	 */
	public void setCreditCardToken(String aCreditCardToken) {
		this.creditCardToken = aCreditCardToken;
	}

	/**
	 * @return the masked credit card number
	 */
	public String getCreditCardAccountNumberMask() {
		return this.creditCardAccountNumberMask;
	}

	/**
	 * 
	 * @param aCreditCardAccountNumberMask the masked credit card number
	 */
	public void setCreditCardAccountNumberMask(String aCreditCardAccountNumberMask) {
		this.creditCardAccountNumberMask = aCreditCardAccountNumberMask;
	}

	/**
	 * Gets the credit card expiry date.
	 * 
	 * @return the credit card expiry date
	 */
	public String getCreditCardExpiryDate() {
		return this.creditCardExpiryDate;
	}

	/**
	 * Sets the credit card expiry date.
	 * 
	 * @param aCreditCardExpiryDate the new credit card expiry date
	 */
	public void setCreditCardExpiryDate(String aCreditCardExpiryDate) {
		this.creditCardExpiryDate = aCreditCardExpiryDate;
	}

	/**
	 * Gets the credit card holder name.
	 * 
	 * @return the credit card holder name
	 */
	public String getCreditCardHolderName() {
		return this.creditCardHolderName;
	}

	/**
	 * Sets the credit card holder name.
	 * 
	 * @param aCreditCardHolderName the new credit card holder name
	 */
	public void setCreditCardHolderName(String aCreditCardHolderName) {
		this.creditCardHolderName = aCreditCardHolderName;
	}

	/**
	 * Gets the billings.
	 * 
	 * @return the billings
	 */
	@XmlElementWrapper(name="billings")
	@XmlElement(name="billing")
	public Set<Billing> getBillings() {
		return Collections.unmodifiableSet(this.billings);
	}

	/**
	 * Sets the billings.
	 * 
	 * @param aBillings the new billings
	 */
	protected void setBillings(Set<Billing> aBillings) {
		this.billings = aBillings;
	}

	/**
	 * Adds the billing.
	 * 
	 * @param billing the billing
	 */
	public void addBilling(com.ing.canada.plp.domain.billing.Billing billing) {
		AssociationsHelper.updateOneToManyFields(this, "billings", billing, "account");
	}

	/**
	 * Removes the billing.
	 *
	 * @param billing the billing
	 */
	public void removeBilling(com.ing.canada.plp.domain.billing.Billing billing) {
		AssociationsHelper.updateOneToManyFields(null, "billings", billing, "account");
	}

	/**
	 * Get the account holder same as policy holder indicator.
	 * @return {@link Boolean}
	 */
	public Boolean getAccountHolderSameAsPolicyHolderInd() {
		return this.accountHolderSameAsPolicyHolderInd;
	}

	/**
	 * Set the account holder same as policy holder indicator.
	 * @param isAccountHolderSameAsPolicyHolderInd {@link Boolean}
	 */
	public void setAccountHolderSameAsPolicyHolderInd(Boolean isAccountHolderSameAsPolicyHolderInd) {
		this.accountHolderSameAsPolicyHolderInd = isAccountHolderSameAsPolicyHolderInd;
	}
}
