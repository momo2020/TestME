package com.ing.canada.plp.service.broker.util;

public class QuoteUpload {

	private String user = null;
	private String quoteId = null;
	private String uploadUser = null;
	private String broker = null;

	public QuoteUpload() {
	}
	
	public QuoteUpload(String quoteId, String broker, String user, String uploadUser) {
		this.setQuoteId(quoteId);
		this.setBroker(broker);
		this.setUser(user);
		this.setUploadUser(uploadUser);
	}

	public String getUser() {
		return this.user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getQuoteId() {
		return this.quoteId;
	}

	public void setQuoteId(String quoteId) {
		this.quoteId = quoteId;
	}

	public String getUploadUser() {
		return this.uploadUser;
	}

	public void setUploadUser(String uploadUser) {
		this.uploadUser = uploadUser;
	}

	public String getBroker() {
		return this.broker;
	}

	public void setBroker(String broker) {
		this.broker = broker;
	}

	@Override
	public String toString() {
		return "[quote=" + this.getQuoteId() + "user=" + getUser() + ", upload user=" + this.getUploadUser()
				+ ", broker=" + this.getBroker() + "]";
	}

}
