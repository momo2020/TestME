/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2017, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import java.util.Set;

import com.ing.canada.plp.domain.enums.BasicCoverageCodeEnum;
import com.ing.canada.plp.domain.enums.CoverageGroupCodeEnum;
import com.ing.canada.plp.domain.enums.EndorsementCodeEnum;
import com.ing.canada.plp.domain.insuranceriskoffer.CoverageOffer;

/**
 * Interface for the Coverage offer helper.
 *
 * @author <a href="mailto:pascal.meunier@intact.net">Pascal Meunier</a>
 *
 */
public interface ICoverageOfferHelper {

	/**
	 * Find a single coverage offer matching in a set matching a provided coverage group code.
	 *
	 * @param covOffers the set of {@link CoverageOffer}s to search
	 * @param covGroupCode the {@link CoverageGroupCodeEnum} to search
	 * @return found entry or null.
	 */
	CoverageOffer findSingle(final Set<CoverageOffer> covOffers, final CoverageGroupCodeEnum covGroupCode);

	/**
	 * Find a single coverage offer matching in a set matching a provided endorsement code.
	 *
	 * @param covOffers the set of {@link CoverageOffer}s to search
	 * @param endorsementCode the {@link EndorsementCodeEnum} to search
	 * @return found entry or null.
	 */
	CoverageOffer findSingle(final Set<CoverageOffer> covOffers, final EndorsementCodeEnum endorsementCode);

	/**
	 * Find a collection of coverage offers matching a provided coverage code.
	 *
	 * @param covOffers the set of {@link CoverageOffer}s to search
	 * @param coverageCode the {@link BasicCoverageCodeEnum} to search
	 * @return the non-null set of matched coverage offers, empty if not matched.
	 */
	Set<CoverageOffer> find(final Set<CoverageOffer> covOffers, final BasicCoverageCodeEnum coverageCode);

	/**
	 * Find a collection of coverage offers matching a provided coverage group code.
	 *
	 * @param covOffers the set of coverage offers
	 * @param coverageGroupCodeEnum {@link CoverageGroupCodeEnum}
	 * @return the non-null set of matched coverage offers, empty if not matched.
	 */
	Set<CoverageOffer> find(final Set<CoverageOffer> covOffers, final CoverageGroupCodeEnum coverageGroupCodeEnum);
}
