/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum ConsentTypeCodeEnum.
 */
public enum ConsentTypeCodeEnum {

	/** Credit Score Consent */
	CREDIT_SCORE("CS"), 
	
	/** Marketing Consent*/
	MARKETING_CONSENT("MK"), 
	
	/** Client Profile Creation Consent */ 
	CLIENT_PROFILE_CREATION("PR"), 
	
	/** General consent */
	GENERAL_CONSENT("GC"),
	
	/** Renewal of solicitation consent */
	RENEWAL_SOLICITATION("RS"),
	
	/** Quotation follow-up consent */
	QUOTATION_FOLLOW_UP("QF"),
	
	/** UBI program consent */
	UBI_PROGRAM_CONSENT("UB"),
	
	/** Partnership (SLF) consent */
	PARTNERSHIP("PA"),
	
	/** Consent for the removal of hail coverage (AB) */
	HAIL_COVERAGE_REMOVAL("HC");
	
	/**
	 * Instantiates a new consent type code enum.
	 * 
	 * @param aCode the a code
	 */
	private ConsentTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the consent type code enum
	 */
	public static ConsentTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (ConsentTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
