/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum MaritalStatusCodeEnum.
 */
public enum MaritalStatusCodeEnum {

	MARRIED("M"),
	SINGLE("C"),
	WIDOWED("V"),
	DIVORCED("D"),
	SEPARATED("S"),
	COMMON_LAW("F"),
	RELIGIOUS("E"),
	SAME_SEX_PARTNER("1"),
	OTHER("A");

	/**
	 * Instantiates a new marital status code enum.
	 *
	 * @param aCode the a code
	 */
	private MaritalStatusCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 *
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 *
	 * @param value the value
	 *
	 * @return the marital status code enum
	 */
	public static MaritalStatusCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (MaritalStatusCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
