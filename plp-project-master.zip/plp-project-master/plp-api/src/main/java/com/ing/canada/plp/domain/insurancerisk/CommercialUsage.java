package com.ing.canada.plp.domain.insurancerisk;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.usertype.BaseEntity;


/**
 * CommercialUsage entity.
 * 
 * @author Patrick Joly
 * 
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "COMMERCIAL_USAGE", uniqueConstraints = {})
public class CommercialUsage extends BaseEntity {
	
	private static final long serialVersionUID = -3634741140075205453L;

	/** The id. */
	@Id
	@Column(name = "COMMERCIAL_USAGE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "CommercialUsageSequence")
	@SequenceGenerator(name = "CommercialUsageSequence", sequenceName = "COMMERCIAL_USAGE_SEQ", allocationSize = 5)
	private Long id;
	
	/** The insurance risk of the commercial usage */
	
	@OneToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_RISK_ID", updatable = true)
	private InsuranceRisk insuranceRisk;
	
	/** The categoryCode of the commercial usage */
	@Column(name = "CATEGORY_CD", length = 15)
	private String categoryCode;
	
	/** The generalUsageCode of the commercial usage */
	@Column(name = "GENERAL_USE_CD", length = 15)
	private String generalUseCode;
	
	/** The specificUseCode of the commercial usage */
	@Column(name = "SPECIFIC_USE_CD", length = 15)
	private String specificUseCode;
	
	/** The creation date. */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "SYSTEM_CREATE_TS", length = 11, insertable = false, updatable = false)
	private Date systemCreateTS;
	
	/* ACCESSORS */
	
	@Override
	public Object getId() {
		return id;
	}

	@Override
	public void setId(Object id) {
		this.id = (Long) id;
		
	}
	
	@XmlTransient
	public InsuranceRisk getInsuranceRisk() {
		return insuranceRisk;
	}

	
	public void setInsuranceRisk(InsuranceRisk aInsuranceRisk) {
		AssociationsHelper.updateOneToOneFields(aInsuranceRisk, InsuranceRisk.class, "commercialUsage", this, CommercialUsage.class,
				"insuranceRisk");
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getGeneralUseCode() {
		return generalUseCode;
	}

	public void setGeneralUseCode(String generalUsageCode) {
		this.generalUseCode = generalUsageCode;
	}

	public String getSpecificUseCode() {
		return specificUseCode;
	}

	public void setSpecificUseCode(String specificUseCode) {
		this.specificUseCode = specificUseCode;
	}

	public Date getSystemCreateTS() {
		return systemCreateTS;
	}

	public void setSystemCreateTS(Date systemCreateTS) {
		this.systemCreateTS = systemCreateTS;
	}
}
