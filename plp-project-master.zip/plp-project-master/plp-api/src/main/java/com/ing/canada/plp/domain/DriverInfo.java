/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain;

import java.util.Date;

import com.ing.canada.plp.domain.enums.ActionTakenCodeEnum;

/**
 * Driver info. use for reporting only.
 * 
 * @author fsimard
 */
public class DriverInfo {

	/** The id. */
	private Long id;

	/** The driver sequence. */
	private int driverSequence;

	/** The first name. */
	private String firstName;

	/** The last name. */
	private String lastName;

	/** The middle name. */
	private String middleName;

	/** The suffix. */
	private String suffix;

	/** Birth date */
	private Date birthDate;

	private String shortFullName;

	/**
	 * Gets a short version of the firstname and lastname for display purpose
	 */
	public String getShortFullName() {

		if (this.shortFullName == null) {
			String shortFirstName = this.firstName.length() > 12 ? this.firstName.substring(0, 12) + "..."
					: this.firstName;
			String shortLastName = this.lastName.length() > 12 ? this.lastName.substring(0, 12) + "..." : this.lastName;

			this.shortFullName = shortFirstName
					+ (this.firstName.length() > 12 || this.lastName.length() > 12 ? "<br>" : " ") + shortLastName;
		}

		return this.shortFullName;
	}

	/** Action taken */
	private ActionTakenCodeEnum actionTaken;

	private Boolean roadBlockIndicator;

	/**
	 * Constructor
	 */
	public DriverInfo() {
		// NOOP
	}

	/**
	 * Constructor with fields
	 * 
	 * @param aId Driver info
	 * @param aFirstName Driver first name
	 * @param aLastName Driver las name
	 * @param aMiddleName Driver middle name
	 * @param aSuffix Driver suffix
	 * @param aDriverSequence The driver Sequence.
	 * @param aActionTaken Flag which indicate if this driver is new/deleted/modified
	 */
	public DriverInfo(Long aId, String aFirstName, String aLastName, String aMiddleName, String aSuffix,
			int aDriverSequence, Date aBirthDate, ActionTakenCodeEnum aActionTaken, Boolean aRoadBlockIndicator) {
		this.id = aId;
		this.firstName = aFirstName;
		this.lastName = aLastName;
		this.middleName = aMiddleName;
		this.suffix = aSuffix;
		this.driverSequence = aDriverSequence;
		this.birthDate = aBirthDate;
		this.actionTaken = aActionTaken;
		this.roadBlockIndicator = aRoadBlockIndicator;
	}

	/**
	 * Returns the hashcode of this object based on it's id.
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((this.id == null) ? 0 : this.id.hashCode());
		return result;
	}

	/**
	 * Check if two objects have the same id. If they have they are considered equals.
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final DriverInfo other = (DriverInfo) obj;
		if (this.id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!this.id.equals(other.id)) {
			return false;
		}
		return true;
	}

	/**
	 * Getter for firstName.
	 * 
	 * @return the firstName
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 * Setter for firstName.
	 * 
	 * @param aFirstName the firstName to set
	 */
	public void setFirstName(String aFirstName) {
		this.firstName = aFirstName;
		this.shortFullName = null;
	}

	/**
	 * Getter for id.
	 * 
	 * @return the id
	 */
	public Long getId() {
		return this.id;
	}

	/**
	 * Setter for id.
	 * 
	 * @param aId the id to set
	 */
	public void setId(Long aId) {
		this.id = aId;
	}

	/**
	 * Getter for lastName.
	 * 
	 * @return the lastName
	 */
	public String getLastName() {
		return this.lastName;
	}

	/**
	 * Setter for lastName.
	 * 
	 * @param aLastName the lastName to set
	 */
	public void setLastName(String aLastName) {
		this.lastName = aLastName;
		this.shortFullName = null;
	}

	/**
	 * Getter for middleName.
	 * 
	 * @return the middleName
	 */
	public String getMiddleName() {
		return this.middleName;
	}

	/**
	 * Setter for middleName.
	 * 
	 * @param aMiddleName the middleName to set
	 */
	public void setMiddleName(String aMiddleName) {
		this.middleName = aMiddleName;
	}

	/**
	 * Getter for suffix.
	 * 
	 * @return the suffix
	 */
	public String getSuffix() {
		return this.suffix;
	}

	/**
	 * Setter for suffix.
	 * 
	 * @param aSuffix the suffix to set
	 */
	public void setSuffix(String aSuffix) {
		this.suffix = aSuffix;
	}

	/**
	 * Getter for driverSequence
	 * 
	 * @return the driverSequence
	 */
	public int getDriverSequence() {
		return this.driverSequence;
	}

	/**
	 * Setter for driverSequence
	 * 
	 * @param aDriverSequence the driverSequence to set
	 */
	public void setDriverSequence(int aDriverSequence) {
		this.driverSequence = aDriverSequence;
	}

	/**
	 * Getter for birthDate.
	 * 
	 * @return the birthDate
	 */
	public Date getBirthDate() {
		return this.birthDate;
	}

	/**
	 * Setter for birthDate
	 * 
	 * @param aBirthDate the birthDate to set
	 */
	public void setBirthDate(Date aBirthDate) {
		this.birthDate = aBirthDate;
	}

	/**
	 * Getter for actionTaken.
	 * 
	 * @return the actionTaken
	 */
	public ActionTakenCodeEnum getActionTaken() {
		return this.actionTaken;
	}

	/**
	 * Setter for actionTaken
	 * 
	 * @param aActionTaken the actionTaken to set
	 */
	public void setNewIndicator(ActionTakenCodeEnum aActionTaken) {
		this.actionTaken = aActionTaken;
	}

	/**
	 * getter for roadblock ind
	 * 
	 * @return {@link #roadBlockIndicator}
	 */
	public Boolean getRoadBlockIndicator() {
		return this.roadBlockIndicator;
	}

	/**
	 * setter for roadblock ind.
	 * 
	 * @param aRoadBlockIndicator {@link #roadBlockIndicator}
	 */
	public void setRoadBlockIndicator(Boolean aRoadBlockIndicator) {
		this.roadBlockIndicator = aRoadBlockIndicator;
	}

}
