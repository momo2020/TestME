/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum TransactionCodeEnum.
 */
public enum TransactionCodeEnum {

	AUTOMATIC_POLICY_ADJUSTMENT_FURTHER_TO_A_CLAIM_FIELD_CLOSED("AJC"), CLAIMS_DATA_MAINTENANCE("CLM"), TERMINATE_CREDIT_OF_INSURANCE_RISK(
			"COI"), PRINT_COPY_OF_POLICY("CPO"), NEW_BUSINESS_QUOTE("NBQ"), NEW_BUSINESS_REWRITE("NBR"), NEW_BUSINESS(
			"NBS"), POLICY_CHANGE("PCH"), POLICY_CLEAN_UP("PCU"), PREMIUM_JOURNAL("PJL"), POLICY_MAINTENANCE("PMA"), REINSTATEMENT(
			"REI"), REINSTATEMENT_AFTER_STORAGE("RST"), RENEWAL_REWRITE("RWE"), RENEWAL("RWL"), LAPSE("RWX"), SEMI_AUTOMATIC_RENEWAL(
			"SRN"), POLICY_TAKEOVER("TKO"), POLICY_TAKE_UP("TKU"), CANCELLATION("XLN");

	/**
	 * Instantiates a new transaction code enum.
	 * 
	 * @param aCode the a code
	 */
	private TransactionCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the transaction code enum
	 */
	public static TransactionCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (TransactionCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
