/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum BasicCoverageCodeEnum.
 */
public enum BasicCoverageCodeEnum {

	/** ACCIDENT BENEFITS P1 */
	ACCIDENT_BENEFITS_P1("P1"),

	/** OPTIONAL INCOME REPLACEMENT P2 */
	OPTIONAL_INCOME_REPLACEMENT_P2("P2"),

	/** LIABILITY */
	LIABILITY_A("A"),

	/** ALL PERILS B1 */
	ALL_PERILS_B1("B1"),

	/** COLLISION B2 */
	COLLISION_B2("B2"),

	/** COMPREHENSIVE B3 */
	COMPREHENSIVE_B3("B3"),

	/** SPECIFIED PERILS B4 */
	SPECIFIED_PERILS_B4("B4"),

	/** ACCIDENT BENEFITS */
	ACCIDENT_BENEFITS_B("B"),

	/** LIABILITY BODILY INJURY A1 */
	LIABILITY_BODILY_INJURY_A1("A1"),

	/** DIRECT COMP PROPERTY DAM2 */
	DIRECT_COMP_PROPERTY_DAM_A2("A2"),

	/** ALL PERILS C1 */
	ALL_PERILS_C1("C1"),

	/** COLLISION C2 */
	COLLISION_C2("C2"),

	/** COMPREHENSIVE C3 */
	COMPREHENSIVE_C3("C3"),

	/** SPECIFIED PERILS C4 */
	SPECIFIED_PERILS_C4("C4"),

	// Savers basic coverages

	/** LIABILITY LIAB */
	LIABILITY_LIAB("LIAB"),

	/** DIRECT COMP PROPERTY DAM DCPD */
	DIRECT_COMP_PROPERTY_DAM_DCPD("DCPD"),

	/** ACCIDENT BENEFITS ACCB */
	ACCIDENT_BENEFITS_ACCB("ACCB"),

	/** ALL PERILS AP */
	ALL_PERILS_AP("AP"),

	/** COLLISION COLL */
	COLLISION_COLL("COLL"),

	/** COMPREHENSIVE COMP */
	COMPREHENSIVE_COMP("COMP"),

	/** SPECIFIED PERILS SP */
	SPECIFIED_PERILS_SP("SP"),

	// EIS codes

	/** LIABILITY BODILY INJURY AL30 */
	LIABILITY_BODILY_INJURY_AL30("AL30"),

	/** COLLISION PD20 */
	COLLISION_PD20("PD20"),

	/** COMPREHENSIVE PD30 */
	COMPREHENSIVE_PD30("PD30");

	/**
	 * Instantiates a new basic coverage code enum.
	 * 
	 * @param aCode the a code
	 */
	private BasicCoverageCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the basic coverage code enum
	 */
	public static BasicCoverageCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (BasicCoverageCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the basic coverage code enum
	 */
	public static boolean isBasicCoverage(String value) {

		if (StringUtils.isEmpty(value)) {
			return false;
		}

		for (BasicCoverageCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return true;
			}

		}
		return false;
	}

	/** Set of codes for coverages that are deductible. */
	private static final Set<BasicCoverageCodeEnum> DEDUCTIBLE_COVERAGES = new HashSet<BasicCoverageCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			add(COLLISION_B2);
			add(COMPREHENSIVE_B3);
			add(COLLISION_C2);
			add(COMPREHENSIVE_C3);
			// savers
			add(COLLISION_COLL);
			add(COMPREHENSIVE_COMP);
		}
	};

	/**
	 * Gets the deductible coverage set.
	 * 
	 * @return Deductible coverage set.
	 */
	public static Set<BasicCoverageCodeEnum> getDeductibleSet() {
		return Collections.unmodifiableSet(DEDUCTIBLE_COVERAGES);
	}

	/**
	 * Indicates if this type of coverage is deductible.
	 * 
	 * @return true if deductible, false otherwise
	 */
	public boolean isDeductible() {
		return DEDUCTIBLE_COVERAGES.contains(this);
	}

	/** Set of codes for coverages that are limit of insurance. */
	private static final Set<BasicCoverageCodeEnum> LIMIT_COVERAGES = new HashSet<BasicCoverageCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			add(LIABILITY_A);
			add(LIABILITY_BODILY_INJURY_A1);
			add(DIRECT_COMP_PROPERTY_DAM_A2);
			add(ACCIDENT_BENEFITS_B);
			add(OPTIONAL_INCOME_REPLACEMENT_P2);
			// savers
			add(LIABILITY_LIAB);
			add(DIRECT_COMP_PROPERTY_DAM_DCPD);
			add(ACCIDENT_BENEFITS_ACCB);
		}
	};

	/**
	 * Gets the limit of insurance coverage set.
	 * 
	 * @return Deductible coverage set.
	 */
	public static Set<BasicCoverageCodeEnum> getLimitOfInsuranceSet() {
		return Collections.unmodifiableSet(LIMIT_COVERAGES);
	}

	/**
	 * Indicates if this type of coverage is deductible.
	 * 
	 * @return true if deductible, false otherwise
	 */
	public boolean isLimitOfInsurance() {
		return LIMIT_COVERAGES.contains(this);
	}

	/** Set of codes for coverages that are for QC. */
	private static final Set<BasicCoverageCodeEnum> QUEBEC_COVERAGES = new HashSet<BasicCoverageCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			add(LIABILITY_A);
			add(COLLISION_B2);
			add(COMPREHENSIVE_B3);
			add(ACCIDENT_BENEFITS_P1);
			add(OPTIONAL_INCOME_REPLACEMENT_P2);
			add(ALL_PERILS_B1);
			add(SPECIFIED_PERILS_B4);
		}
	};

	/**
	 * Gets the Quebec coverage set.
	 * 
	 * @return Quebec coverage set.
	 */
	public static Set<BasicCoverageCodeEnum> getQcSet() {
		return Collections.unmodifiableSet(QUEBEC_COVERAGES);
	}

	/** Set of codes for coverages that are for ON. */
	private static final Set<BasicCoverageCodeEnum> ONTARIO_COVERAGES = new HashSet<BasicCoverageCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			add(ACCIDENT_BENEFITS_B);
			add(LIABILITY_BODILY_INJURY_A1);
			add(DIRECT_COMP_PROPERTY_DAM_A2);
			add(ALL_PERILS_C1);
			add(COLLISION_C2);
			add(COMPREHENSIVE_C3);
			add(SPECIFIED_PERILS_C4);
		}
	};

	/**
	 * Gets the Ontario coverage set.
	 * 
	 * @return Ontario coverage set.
	 */
	public static Set<BasicCoverageCodeEnum> getOnSet() {
		return Collections.unmodifiableSet(ONTARIO_COVERAGES);
	}

	/** Set of codes for coverages that are for ON Savers. */
	private static final Set<BasicCoverageCodeEnum> ONTARIO_SAVERS_COVERAGES = new HashSet<BasicCoverageCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			add(LIABILITY_LIAB);
			add(DIRECT_COMP_PROPERTY_DAM_DCPD);
			add(ACCIDENT_BENEFITS_ACCB);
			add(COLLISION_COLL);
			add(COMPREHENSIVE_COMP);
		}
	};

	/** Set of codes for coverages that are for AB Savers. */
	private static final Set<BasicCoverageCodeEnum> ALBERTA_SAVERS_COVERAGES = new HashSet<BasicCoverageCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			add(LIABILITY_LIAB);
			add(ACCIDENT_BENEFITS_ACCB);
			add(COLLISION_COLL);
			add(COMPREHENSIVE_COMP);
		}
	};

	/**
	 * Gets the Ontario coverage set.
	 * 
	 * @return Ontario coverage set.
	 */
	public static Set<BasicCoverageCodeEnum> getOnSaversSet() {
		return Collections.unmodifiableSet(ONTARIO_SAVERS_COVERAGES);
	}

	/**
	 * Gets the Alberta coverage set.
	 * 
	 * @return Alberta coverage set.
	 */
	public static Set<BasicCoverageCodeEnum> getAbSaversSet() {
		return Collections.unmodifiableSet(ALBERTA_SAVERS_COVERAGES);
	}

	/** Set of codes for coverages that are for AB. */
	private static final Set<BasicCoverageCodeEnum> ALBERTA_COVERAGES = new HashSet<BasicCoverageCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			add(ACCIDENT_BENEFITS_B);
			add(LIABILITY_A);
			add(ALL_PERILS_C1);
			add(COLLISION_C2);
			add(COMPREHENSIVE_C3);
			add(SPECIFIED_PERILS_C4);
		}
	};

	/**
	 * Gets the Alberta coverage set.
	 * 
	 * @return Alberta coverage set.
	 */
	public static Set<BasicCoverageCodeEnum> getAbSet() {
		return Collections.unmodifiableSet(ALBERTA_COVERAGES);
	}

	/**
	 * Gets the basic coverage codes for a province.
	 * 
	 * @param province {@link ProvinceCodeEnum}
	 * @param manufacturerCompany {@link ManufacturerCompanyCodeEnum}
	 * @return the basic coverage codes for a province
	 */
	public static Set<BasicCoverageCodeEnum> getBasicCoverageCodes(ProvinceCodeEnum province,
			ManufacturerCompanyCodeEnum manufacturerCompany) {
		if (ProvinceCodeEnum.QUEBEC.equals(province)) {
			return getQcSet();
		}
		if (ProvinceCodeEnum.ONTARIO.equals(province)) {
			if (ManufacturerCompanyCodeEnum.ING_CENTRAL_ATLANTIC_REGION.equals(manufacturerCompany)) {
				// The set for CAR(ING_CENTRAL_ATLANTIC_REGION) uses Savers codes
				return getOnSaversSet();
			}
			// The default set
			return getOnSet();
		}
		if (ProvinceCodeEnum.ALBERTA.equals(province)) {
			if (ManufacturerCompanyCodeEnum.ING_WESTERN_REGION.equals(manufacturerCompany)) {
				// The set for CAR(ING_WESTERN_REGION) uses Savers codes
				return getAbSaversSet();
			}
			// The default set
			return getAbSet();
		}
		if (ProvinceCodeEnum.BRITISH_COLUMBIA.equals(province)) {
			if (ManufacturerCompanyCodeEnum.ING_WESTERN_REGION.equals(manufacturerCompany)) {
				// The set for CAR(ING_WESTERN_REGION) uses Savers codes
				return getBcSaversSet();
			}
			// The default set
			return getBcSet();
		}
		return Collections.emptySet();
	}

	/** Set of codes for occasional driver coverages that are for QC. */
	private static final Set<BasicCoverageCodeEnum> QUEBEC_OCCASIONAL_COVERAGES = new HashSet<BasicCoverageCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			add(LIABILITY_A);
			add(COLLISION_B2);
			add(ALL_PERILS_B1);
		}
	};

	/**
	 * Gets the occasional driver Quebec coverage set.
	 * 
	 * @return Quebec coverage set.
	 */
	public static Set<BasicCoverageCodeEnum> getQcOccasionalSet() {
		return Collections.unmodifiableSet(QUEBEC_OCCASIONAL_COVERAGES);
	}

	/** Set of codes for occasional driver coverages that are for ON. */
	private static final Set<BasicCoverageCodeEnum> ONTARIO_OCCASIONAL_COVERAGES = new HashSet<BasicCoverageCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			add(LIABILITY_BODILY_INJURY_A1);
			add(ALL_PERILS_C1);
			add(COLLISION_C2);
			add(DIRECT_COMP_PROPERTY_DAM_A2);
			add(ACCIDENT_BENEFITS_B);
		}
	};

	/**
	 * Gets the occasional driver Ontario coverage set.
	 * 
	 * @return Ontario coverage set.
	 */
	public static Set<BasicCoverageCodeEnum> getOnOccasionalSet() {
		return Collections.unmodifiableSet(ONTARIO_OCCASIONAL_COVERAGES);
	}

	/** Set of codes for occasional driver coverages that are for ON Savers. */
	private static final Set<BasicCoverageCodeEnum> ONTARIO_OCCASIONAL_SAVERS_COVERAGES = new HashSet<BasicCoverageCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			add(LIABILITY_LIAB);
			add(DIRECT_COMP_PROPERTY_DAM_DCPD);
			add(ACCIDENT_BENEFITS_ACCB);
			add(COLLISION_COLL);
			add(COMPREHENSIVE_COMP);
		}
	};

	/**
	 * Gets the occasional driver Ontario coverage set.
	 * 
	 * @return Ontario coverage set.
	 */
	public static Set<BasicCoverageCodeEnum> getOnOccasionalSaversSet() {
		return Collections.unmodifiableSet(ONTARIO_OCCASIONAL_SAVERS_COVERAGES);
	}

	/** Set of codes for occasional driver coverages that are for AB. */
	private static final Set<BasicCoverageCodeEnum> ALBERTA_OCCASIONAL_COVERAGES = new HashSet<BasicCoverageCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			add(LIABILITY_A);
			add(ALL_PERILS_C1);
			add(COLLISION_C2);
		}
	};

	/**
	 * Gets the occasional driver Alberta coverage set.
	 * 
	 * @return Ontario coverage set.
	 */
	public static Set<BasicCoverageCodeEnum> getAbOccasionalSet() {
		return Collections.unmodifiableSet(ALBERTA_OCCASIONAL_COVERAGES);
	}

	/**
	 * Gets the basic coverage codes for an occasional driver by province.
	 * 
	 * @param province the province {@link ProvinceCodeEnum}
	 * @param manufacturerCompany {@link ManufacturerCompanyCodeEnum}
	 * @return the basic coverage codes for an occasional driver by province.
	 */
	public static Set<BasicCoverageCodeEnum> getBasicCoverageOccasionalCodes(ProvinceCodeEnum province,
			ManufacturerCompanyCodeEnum manufacturerCompany) {
		if (ProvinceCodeEnum.QUEBEC.equals(province)) {
			return getQcOccasionalSet();
		}
		if (ProvinceCodeEnum.ONTARIO.equals(province)) {
			if (ManufacturerCompanyCodeEnum.ING_CENTRAL_ATLANTIC_REGION.equals(manufacturerCompany)) {
				// The set for CAR(ING_CENTRAL_ATLANTIC_REGION) uses Savers codes
				return getOnOccasionalSaversSet();
			}
			return getOnOccasionalSet();
		}
		if (ProvinceCodeEnum.ALBERTA.equals(province)) {
			return getAbOccasionalSet();
		}
		if (ProvinceCodeEnum.BRITISH_COLUMBIA.equals(province)) {
			return getBcOccasionalSet();
		}
		return Collections.emptySet();
	}

	/** Set of codes for coverages that are for BC. */
	private static final Set<BasicCoverageCodeEnum> BRITISH_COLUMBIA_COVERAGES = new HashSet<BasicCoverageCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			add(LIABILITY_A);
			add(COLLISION_C2);
			add(COMPREHENSIVE_C3);
		}
	};

	/** Set of codes for coverages that are for BC Savers. */
	private static final Set<BasicCoverageCodeEnum> BRITISH_COLUMBIA_SAVERS_COVERAGES = new HashSet<BasicCoverageCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			add(LIABILITY_LIAB);
			add(COLLISION_COLL);
			add(COMPREHENSIVE_COMP);
		}
	};

	/** Set of codes for occasional driver coverages that are for BC. */
	private static final Set<BasicCoverageCodeEnum> BRITISH_COLUMBIA_OCCASIONAL_COVERAGES = new HashSet<BasicCoverageCodeEnum>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		{
			add(LIABILITY_A);
			add(COLLISION_C2);
			add(COMPREHENSIVE_C3);
		}
	};

	/**
	 * Gets the British-Columbia coverage set.
	 * 
	 * @return British-Columbia coverage set.
	 */
	public static Set<BasicCoverageCodeEnum> getBcSet() {
		return Collections.unmodifiableSet(BRITISH_COLUMBIA_COVERAGES);
	}

	/**
	 * Gets the British-Columbia coverage set.
	 * 
	 * @return British-Columbia coverage set.
	 */
	public static Set<BasicCoverageCodeEnum> getBcSaversSet() {
		return Collections.unmodifiableSet(BRITISH_COLUMBIA_SAVERS_COVERAGES);
	}

	/**
	 * Gets the occasional driver British-Columbia coverage set.
	 * 
	 * @return British-Columbia coverage set.
	 */
	public static Set<BasicCoverageCodeEnum> getBcOccasionalSet() {
		return Collections.unmodifiableSet(BRITISH_COLUMBIA_OCCASIONAL_COVERAGES);
	}
}
