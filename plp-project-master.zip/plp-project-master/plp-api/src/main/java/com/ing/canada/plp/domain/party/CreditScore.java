/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.party;

import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.CreditScoreTypeCodeEnum;
import com.ing.canada.plp.domain.enums.ReportSearchTypeCodeEnum;
import com.ing.canada.plp.domain.enums.ServiceStatusCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * CreditScore entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "CREDIT_SCORE", uniqueConstraints = {})
public class CreditScore extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "CREDIT_SCORE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "CreditScoreSequence")
	@SequenceGenerator(name = "CreditScoreSequence", sequenceName = "CREDIT_SCORE_SEQ", allocationSize = 5)
	private Long id;

	/** The party. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "PARTY_ID", nullable = true, updatable = true)
	private Party party;

	/** The credit score. */
	@Column(name = "CREDIT_SCORE_QTY", length = 5)
	private String creditScore;

	/** The credit score date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "CREDIT_SCORE_DT", length = 7)
	private Date creditScoreDate;

	/** The reference date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "REFERENCE_DT", length = 7)
	private Date referenceDate;

	/** The credit score type code. */
	@Column(name = "CREDIT_SCORE_TYPE_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.CreditScoreTypeCodeEnum") })
	private CreditScoreTypeCodeEnum creditScoreType;

	/** The report search type code. */
	@Column(name = "REPORT_SEARCH_TYPE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ReportSearchTypeCodeEnum") })
	private ReportSearchTypeCodeEnum reportSearchType;

	/** The service status code. */
	@Column(name = "SERVICE_STATUS_CD", nullable = false, length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ServiceStatusCodeEnum") })
	private ServiceStatusCodeEnum creditScoreServiceStatus;

	/** The user id. */
	@Column(name = "USER_ID", length = 10)
	private String userId;

	/** The last move date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_MOVE_DT", length = 7)
	private Date dateOfLastMove;

	/** The nbr of trans30 days. */
	@Column(name = "NBR_OF_TRANS_30_DAYS_QTY", precision = 3, scale = 0)
	private Short numberOfTransactionsInLast30Days;

	/** The insurance risks. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "creditScorePostalCode")
	private Set<InsuranceRisk> insuranceRisks = new HashSet<InsuranceRisk>(0);

	/** The original scenario credit score. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_CREDIT_SCORE_ID", insertable = false, updatable = false)
	private CreditScore originalScenarioCreditScore;

	/** The credit score regular indicator. */
	@Type(type = "yes_no")
	@Column(name = "CREDIT_SCORE_REGULAR_IND", length = 1)
	private Boolean creditScoreRegularIndicator;

	/**
	 * Instantiates a new credit score.
	 */
	public CreditScore() {
		// noarg constructor
	}

	/**
	 * Instantiates a new credit score.
	 * 
	 * @param aParty the a party
	 * @param aCreditScoreTypeCode the a credit score type code
	 * @param aReportSearchTypeCode the a report search type code
	 * @param aServiceStatusCode the a service status code
	 */
	public CreditScore(Party aParty, CreditScoreTypeCodeEnum aCreditScoreTypeCode,
			ReportSearchTypeCodeEnum aReportSearchTypeCode, ServiceStatusCodeEnum aServiceStatusCode) {
		setParty(aParty);
		setCreditScoreType(aCreditScoreTypeCode);
		setReportSearchType(aReportSearchTypeCode);
		setCreditScoreServiceStatus(aServiceStatusCode);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Has the client agreed to be credit scored?.
	 * 
	 * @return true if the credit score type is WITH_CONSENT or WITH_CONSENT_AT_THE_REINSTATEMENT, false otherwise
	 * 
	 * @see com.ing.canada.plp.domain.enums.CreditScoreTypeCodeEnum
	 */
	public boolean isConsentant() {
		return getCreditScoreType().equals(CreditScoreTypeCodeEnum.WITH_CONSENT)
				|| getCreditScoreType().equals(CreditScoreTypeCodeEnum.WITH_CONSENT_AT_THE_REINSTATEMENT);
	}

	/**
	 * Gets the party.
	 * 
	 * @return the party
	 */
	@XmlTransient // parent
	public Party getParty() {
		return this.party;
	}

	/**
	 * Sets the party.
	 * 
	 * @param aParty the new party
	 */
	public void setParty(Party aParty) {
		AssociationsHelper.updateOneToManyFields(aParty, "creditScores", this, "party");
	}

	/**
	 * Gets the credit score.
	 * 
	 * @return the credit score
	 */
	public String getCreditScore() {
		return this.creditScore;
	}

	/**
	 * Sets the credit score.
	 * 
	 * @param aCreditScore the new credit score
	 */
	public void setCreditScore(String aCreditScore) {
		this.creditScore = aCreditScore;
	}

	/**
	 * Gets the credit score date.
	 * 
	 * @return the credit score date
	 */
	public Date getCreditScoreDate() {
		return this.creditScoreDate;
	}

	/**
	 * Sets the credit score date.
	 * 
	 * @param aCreditScoreDate the new credit score date
	 */
	public void setCreditScoreDate(Date aCreditScoreDate) {
		this.creditScoreDate = aCreditScoreDate;
	}

	/**
	 * Gets the reference date.
	 * 
	 * @return the reference date
	 */
	public Date getReferenceDate() {
		return this.referenceDate;
	}

	/**
	 * Sets the reference date.
	 * 
	 * @param aReferenceDate the new reference date
	 */
	public void setReferenceDate(Date aReferenceDate) {
		this.referenceDate = aReferenceDate;
	}

	/**
	 * Gets the credit score type code.
	 * 
	 * @return the credit score type code
	 */
	public CreditScoreTypeCodeEnum getCreditScoreType() {
		return this.creditScoreType;
	}

	/**
	 * Sets the credit score type code.
	 * 
	 * @param aCreditScoreTypeCode the new credit score type code
	 */
	public void setCreditScoreType(CreditScoreTypeCodeEnum aCreditScoreTypeCode) {
		this.creditScoreType = aCreditScoreTypeCode;
	}

	/**
	 * Gets the report search type code.
	 * 
	 * @return the report search type code
	 */
	public ReportSearchTypeCodeEnum getReportSearchType() {
		return this.reportSearchType;
	}

	/**
	 * Sets the report search type code.
	 * 
	 * @param aReportSearchTypeCode the new report search type code
	 */
	public void setReportSearchType(ReportSearchTypeCodeEnum aReportSearchTypeCode) {
		this.reportSearchType = aReportSearchTypeCode;
	}

	/**
	 * Gets the service status code.
	 * 
	 * @return the service status code
	 */
	public ServiceStatusCodeEnum getCreditScoreServiceStatus() {
		return this.creditScoreServiceStatus;
	}

	/**
	 * Sets the service status code.
	 * 
	 * @param aServiceStatusCode the new service status code
	 */
	public void setCreditScoreServiceStatus(ServiceStatusCodeEnum aServiceStatusCode) {
		this.creditScoreServiceStatus = aServiceStatusCode;
	}

	/**
	 * Gets the user id.
	 * 
	 * @return the user id
	 */
	public String getUserId() {
		return this.userId;
	}

	/**
	 * Sets the user id.
	 * 
	 * @param aUserId the new user id
	 */
	public void setUserId(String aUserId) {
		this.userId = aUserId;
	}

	/**
	 * Gets the last move date.
	 * 
	 * @return the last move date
	 */
	public Date getDateOfLastMove() {
		return this.dateOfLastMove;
	}

	/**
	 * Sets the date of last move.
	 * 
	 * @param lastMoveDate the new date of last move
	 */
	public void setDateOfLastMove(Date lastMoveDate) {
		this.dateOfLastMove = lastMoveDate;
	}

	/**
	 * Gets the number of transactions in last30 days.
	 * 
	 * @return the number of transactions in last30 days
	 */
	public Short getNumberOfTransactionsInLast30Days() {
		return this.numberOfTransactionsInLast30Days;
	}

	/**
	 * Sets the number of transactions in last30 days.
	 * 
	 * @param nbrOfTrans30Days the new number of transactions in last30 days
	 */
	public void setNumberOfTransactionsInLast30Days(Short nbrOfTrans30Days) {
		this.numberOfTransactionsInLast30Days = nbrOfTrans30Days;
	}

	/**
	 * Gets the insurance risks.
	 * 
	 * @return the insurance risks
	 */
	@XmlTransient // parent
	public Set<InsuranceRisk> getInsuranceRisks() {
		return Collections.unmodifiableSet(this.insuranceRisks);
	}

	/**
	 * Sets the insurance risks.
	 * 
	 * @param aInsuranceRisks the new insurance risks
	 */
	protected void setInsuranceRisks(Set<InsuranceRisk> aInsuranceRisks) {
		this.insuranceRisks = aInsuranceRisks;
	}

	/**
	 * Adds the insurance risk.
	 * 
	 * @param ir the ir
	 */
	public void addInsuranceRisk(com.ing.canada.plp.domain.insurancerisk.InsuranceRisk ir) {
		AssociationsHelper.updateOneToManyFields(this, "insuranceRisks", ir, "creditScorePostalCode");
	}

	/**
	 * Removes the insurance risk.
	 * 
	 * @param ir the ir
	 */
	public void removeInsuranceRisk(com.ing.canada.plp.domain.insurancerisk.InsuranceRisk ir) {
		AssociationsHelper.updateOneToManyFields(null, "insuranceRisks", ir, "creditScorePostalCode");
	}

	/**
	 * Gets the original scenario credit score.
	 * 
	 * @return the original scenario credit score
	 */
	@XmlTransient // reference source
	public CreditScore getOriginalScenarioCreditScore() {
		return this.originalScenarioCreditScore;
	}

	/**
	 * Sets the original scenario credit score.
	 * 
	 * @param anOriginalScenarioCreditScore the new original scenario credit score
	 */
	protected void setOriginalScenarioCreditScore(CreditScore anOriginalScenarioCreditScore) {
		this.originalScenarioCreditScore = anOriginalScenarioCreditScore;
	}

	/**
	 * Gets the credit score regular indicator.
	 * 
	 * @return the credit score regular indicator
	 */
	public Boolean getCreditScoreRegularIndicator() {
		return this.creditScoreRegularIndicator;
	}

	/**
	 * Sets the credit score regular indicator.
	 * 
	 * @param aCreditScoreRegularIndicator the new credit score regular indicator
	 */
	public void setCreditScoreRegularIndicator(Boolean aCreditScoreRegularIndicator) {
		this.creditScoreRegularIndicator = aCreditScoreRegularIndicator;
	}

}
