/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

/**
 * Enum for the conviciton date
 * 
 * @author pabonnea
 */
public enum ConvictionDateCodeEnum {

	LESS_THAN_ONE_YEAR("00") {
		/**
		 * @see com.ing.canada.plp.domain.enums.ConvictionDateCodeEnum#getDate(java.util.Calendar)
		 */
		@Override
		public Date getDate(Calendar instance) {
			instance.add(Calendar.MONTH, -6);
			return instance.getTime();
		}
	},

	ONE_YEAR_BUT_LESS_THAN_TWO("01") {
		/**
		 * @see com.ing.canada.plp.domain.enums.ConvictionDateCodeEnum#getDate(java.util.Calendar)
		 */
		@Override
		public Date getDate(Calendar instance) {
			instance.add(Calendar.MONTH, -18);
			return instance.getTime();
		}
	},

	TWO_YEARS_BUT_LESS_THAN_THREE("02") {
		/**
		 * @see com.ing.canada.plp.domain.enums.ConvictionDateCodeEnum#getDate(java.util.Calendar)
		 */
		@Override
		public Date getDate(Calendar instance) {
			instance.add(Calendar.MONTH, -30);
			return instance.getTime();
		}
	},
	
	THREE_YEARS_BUT_LESS_THAN_FOUR("03") {
		/**
		 * @see com.ing.canada.plp.domain.enums.ConvictionDateCodeEnum#getDate(java.util.Calendar)
		 */
		@Override
		public Date getDate(Calendar instance) {
			instance.add(Calendar.MONTH, -42);
			return instance.getTime();
		}
	},
	
	FOUR_YEARS_BUT_LESS_THAN_FIVE("04") {
		/**
		 * @see com.ing.canada.plp.domain.enums.ConvictionDateCodeEnum#getDate(java.util.Calendar)
		 */
		@Override
		public Date getDate(Calendar instance) {
			instance.add(Calendar.MONTH, -54);
			return instance.getTime();
		}
	};

	/**
	 * Instantiates a new claim loss date code enum.
	 * 
	 * @param aCode the a code
	 */
	private ConvictionDateCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the conviction date code enum
	 */
	public static ConvictionDateCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (ConvictionDateCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}
		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}

	/**
	 * Gets the date.
	 * 
	 * @param instance the instance
	 * 
	 * @return the date
	 */
	public abstract Date getDate(Calendar instance);

}
