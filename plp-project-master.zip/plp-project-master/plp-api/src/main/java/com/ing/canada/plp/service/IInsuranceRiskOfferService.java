/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance 
* Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
*/
package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.enums.InternalTechnicalOfferTypeCodeEnum;
import com.ing.canada.plp.domain.enums.OfferTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;
import com.ing.canada.plp.exception.CloneException;

/**
 * This interface exposes services required to manage InsuranceRiskOffer related entities.
 * 
 * @author ub8199
 * 
 */

public interface IInsuranceRiskOfferService extends ICRUDService<InsuranceRiskOffer> {

	/**
	 * This method returns the InsuranceRiskOffer for a Insurance Risk and an offer type.
	 * 
	 * @param insuranceRisk the insurance Risk
	 * @param offerType the offer Type
	 * 
	 * @return the insurance risk offer
	 */
	InsuranceRiskOffer findInsuranceRiskOfferByInsuranceRiskAndOfferType(InsuranceRisk insuranceRisk,
			OfferTypeCodeEnum offerType);
	
	
	
	/**
	 * Clones the insuranceRiskOffer requested for kanetix 
	 * 
	 * @param anInsuranceRiskOffer the insurance risk offer to be cloned
	 * @return the cloned insurance risk offer 
	 * @throws com.ing.canada.plp.exception.CloneException something bad really occured
	 */
	InsuranceRiskOffer cloneForKanetix(InsuranceRiskOffer anInsuranceRiskOffer) throws CloneException;

	/**
	 * Find insurance risk offer by risk sequence offer type and policy version.
	 * 
	 * @param insuranceRiskSequence the insurance risk sequence
	 * @param anOfferType the offer type
	 * @param plPolicyVersion the pl policy version
	 * 
	 * @return the insurance risk offer
	 */
	InsuranceRiskOffer findInsuranceRiskOfferByRiskSequenceOfferTypeAndPolicyVersion(Integer insuranceRiskSequence, OfferTypeCodeEnum anOfferType, PolicyVersion plPolicyVersion);
	
	public InsuranceRiskOffer findByInternalOfferType(InsuranceRisk aRisk, InternalTechnicalOfferTypeCodeEnum anInternal);
}
