package com.ing.canada.plp.domain.diagnostics;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.enums.DiagnosticsAdviceTypeCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * The Class DiagnosticAutomatedAdviceRepositoryEntry.
 */
@Entity
@Table(name = "DGN_AUTO_ADVICE_REP_ENTRY", uniqueConstraints = {})
public class DiagnosticAutomatedAdviceRepositoryEntry extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "DGN_AUTO_ADVICE_REP_ENTRY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "DiagnosticAutomatedAdviceRepositoryEntrySequence")
	@SequenceGenerator(name = "DiagnosticAutomatedAdviceRepositoryEntrySequence", sequenceName = "DGN_AUTO_ADVICE_REP_ENTRY_SEQ", allocationSize = 5)
	private Long id;

	/** The category of the advice. */
	@Column(name = "ADVICE_TYPE_CD", length = 20)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.DiagnosticsAdviceTypeCodeEnum") })
	private DiagnosticsAdviceTypeCodeEnum adviceType;

	/** The code for the advice. */
	@Column(name = "ADVICE_CD", length = 10)
	private String adviceCode;

	/** The indicator to group the advice in the same category. */
	@Column(name = "ADVICE_GROUPED_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean adviceGroupedInd;

	/** The indicator to group the advice in the same category. */
	@Column(name = "ADVICE_DISPLAY_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean adviceDisplayInd;

	/** The indicator that the advice is selectable. */
	@Column(name = "ADVICE_SELECTABLE_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean adviceSelectableInd;

	/** The indicator that the advice is road block. */
	@Column(name = "ADVICE_ROAD_BLOCK_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean adviceRoadBlockInd;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", length = 7)
	private Date effectiveDate;

	/** The expiration date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the advice code.
	 * 
	 * @return the advice code
	 */
	public String getAdviceCode() {
		return this.adviceCode;
	}

	/**
	 * Sets the advice code.
	 * 
	 * @param anAdviceCode the an advice code
	 */
	public void setAdviceCode(String anAdviceCode) {
		this.adviceCode = anAdviceCode;
	}

	/**
	 * Gets the advice grouped indicator.
	 * 
	 * @return the advice grouped indicator
	 */
	public Boolean getAdviceGroupedInd() {
		return this.adviceGroupedInd;
	}

	/**
	 * Sets the advice grouped indicator.
	 * 
	 * @param anAdviceGroupedInd the an advice grouped ind
	 */
	public void setAdviceGroupedInd(Boolean anAdviceGroupedInd) {
		this.adviceGroupedInd = anAdviceGroupedInd;
	}

	/**
	 * Gets the advice selectable indicator.
	 * 
	 * @return the advice selectable indicator
	 */
	public Boolean getAdviceSelectableInd() {
		return this.adviceSelectableInd;
	}

	/**
	 * Sets the advice selectable indicator.
	 * 
	 * @param anAdviceSelectableInd the an advice selectable ind
	 */
	public void setAdviceSelectableInd(Boolean anAdviceSelectableInd) {
		this.adviceSelectableInd = anAdviceSelectableInd;
	}

	/**
	 * Gets the advice type category.
	 * 
	 * @return the advice type category
	 */
	public DiagnosticsAdviceTypeCodeEnum getAdviceType() {
		return this.adviceType;
	}

	/**
	 * Sets the advice type category.
	 * 
	 * @param anAdviceTypeCategory the an advice type category
	 */
	public void setAdviceType(DiagnosticsAdviceTypeCodeEnum anAdviceTypeCategory) {
		this.adviceType = anAdviceTypeCategory;
	}

	/**
	 * Gets the effective date.
	 * 
	 * @return the effective date
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * Sets the effective date.
	 * 
	 * @param anEffectiveDate the an effective date
	 */
	public void setEffectiveDate(Date anEffectiveDate) {
		this.effectiveDate = anEffectiveDate;
	}

	/**
	 * Gets the expiry date.
	 * 
	 * @return the expiry date
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * Sets the expiry date.
	 * 
	 * @param anExpiryDate the an expiry date
	 */
	public void setExpiryDate(Date anExpiryDate) {
		this.expiryDate = anExpiryDate;
	}

	/**
	 * Gets the advice display ind.
	 * 
	 * @return the adviceDisplayInd
	 */
	public Boolean getAdviceDisplayInd() {
		return this.adviceDisplayInd;
	}

	/**
	 * Sets the advice display ind.
	 * 
	 * @param anAdviceDisplayInd the an advice display ind
	 */
	public void setAdviceDisplayInd(Boolean anAdviceDisplayInd) {
		this.adviceDisplayInd = anAdviceDisplayInd;
	}

	/**
	 * Gets the advice road block ind.
	 * 
	 * @return the advice road block ind
	 */
	public Boolean getAdviceRoadBlockInd() {
		return this.adviceRoadBlockInd;
	}

	/**
	 * Sets the advice road block ind.
	 * 
	 * @param anAdviceRoadBlockInd the new advice road block ind
	 */
	public void setAdviceRoadBlockInd(Boolean anAdviceRoadBlockInd) {
		this.adviceRoadBlockInd = anAdviceRoadBlockInd;
	}

}
