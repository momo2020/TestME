/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.autobannersession;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.ing.canada.plp.domain.usertype.BaseEntity;

// TODO: Auto-generated Javadoc
/**
 * Table used to retrieve a quote by its session id and its policy version id.
 *
 * @author xpham
 */
@Entity
@Table(name = "AUTO_BANNER_SESSION", uniqueConstraints = { @UniqueConstraint(columnNames = { "AUTO_BANNER_SESSION_ID",
		"POLICY_VERSION_ID" }) })
public class AutoBannerSession extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "AUTO_BANNER_SESSION_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "AutoBannerSessionSequence")
	@SequenceGenerator(name = "AutoBannerSessionSequence", sequenceName = "AUTO_BANNER_SESSION_SEQ", allocationSize = 5)
	private Long autoBannerSessionId;

	@Column(name = "POLICY_VERSION_ID", precision = 12, scale = 0)
	private Long policyVersionId;

	/**
	 * Default constructor.
	 */
	public AutoBannerSession() {
		// Nothing to do
	}

	/**
	 * Instantiates a new auto banner session.
	 *
	 * @param aAutoBannerSessionId the a auto banner session id
	 */
	public AutoBannerSession(final Long aAutoBannerSessionId) {
		setId(aAutoBannerSessionId);
	}
	
	/**
	 * Gets the auto banner session id.
	 *
	 * @return the auto banner session id
	 */
	public Long getAutoBannerSessionId() {
		return this.autoBannerSessionId;
	}

	/**
	 * Sets the auto banner session id.
	 *
	 * @param aAutoBannerSessionId the new auto banner session id
	 */
	public void setAutoBannerSessionId(Long aAutoBannerSessionId) {
		this.autoBannerSessionId = aAutoBannerSessionId;
	}

	/**
	 * Gets the policy version id.
	 *
	 * @return the policy version id
	 */
	public Long getPolicyVersionId() {
		return this.policyVersionId;
	}

	/**
	 * Sets the policy version id.
	 *
	 * @param aPolicyVersionId the new policy version id
	 */
	public void setPolicyVersionId(Long aPolicyVersionId) {
		this.policyVersionId = aPolicyVersionId;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.autoBannerSessionId;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(final Object id) {
		this.autoBannerSessionId = (Long) id;
	}
}
