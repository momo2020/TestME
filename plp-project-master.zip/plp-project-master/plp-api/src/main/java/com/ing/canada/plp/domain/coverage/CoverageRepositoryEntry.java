/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.coverage;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import org.apache.commons.lang.ObjectUtils;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.enums.BrokerAuthEndorsementCodeEnum;
import com.ing.canada.plp.domain.enums.CoverageGroupCodeEnum;
import com.ing.canada.plp.domain.enums.CoverageTypeCodeEnum;
import com.ing.canada.plp.domain.enums.CreationFormCodeEnum;
import com.ing.canada.plp.domain.enums.EndorsementApplicableTypeCodeEnum;
import com.ing.canada.plp.domain.enums.EndorsementMethodCalculationCodeEnum;
import com.ing.canada.plp.domain.enums.EndorsementProcessingTypeCodeEnum;
import com.ing.canada.plp.domain.enums.LineOfInsuranceCodeEnum;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.PremiumOrPercentageCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;
import com.ing.canada.plp.domain.enums.RatingRiskTypeApplyCodeEnum;
import com.ing.canada.plp.domain.enums.RenewalActionCodeEnum;
import com.ing.canada.plp.domain.enums.SurchargeDiscountCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * CoverageRepositoryEntry entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "COVERAGE_REPOSITORY_ENTRY", uniqueConstraints = @UniqueConstraint(columnNames = {
		"MANUFACTURER_COMPANY_CD", "COVERAGE_CD", "PROVINCE_CD", "EFFECTIVE_DT" }))
@NamedQueries({
	@NamedQuery(
		name = "CoverageRepositoryEntry.findByCoverageCodeProvinceAndRatingDate", 
		query = "from CoverageRepositoryEntry cre where coverageCode = :coverageCode " +
				"and manufacturerCompanyCode = :company " +
				"and province = :provinceCode and effectiveDate <= :ratingDate and expiryDate >= :ratingDate"
	),
	@NamedQuery(
		name = "CoverageRepositoryEntry.findByProvinceAndRatingDate",
		query = "from CoverageRepositoryEntry cre where " +
				"manufacturerCompanyCode = :company " +
				"and province = :provinceCode and effectiveDate <= :ratingDate and expiryDate >= :ratingDate"
	),
	@NamedQuery(
		name = "CoverageRepositoryEntry.findByManufacturerCompanyCodeAndProvinceAndRatingDate",
		query = "from CoverageRepositoryEntry cre where " +
				"manufacturerCompanyCode = :company " +
				"and province = :provinceCode and effectiveDate <= :ratingDate and expiryDate >= :ratingDate " +
				"and ((coverageGroupCode is null) or (coverageGroupCode in (:coverageGroupCodeList)))"
	),
	@NamedQuery(
			name = "CoverageRepositoryEntry.findByManufacturerCompanyCodeAndProvince",
			query = "from CoverageRepositoryEntry cre where " +
					"manufacturerCompanyCode = :company " +
					"and province = :provinceCode" 
		),
})
public class CoverageRepositoryEntry extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "COVERAGE_REPOSITORY_ENTRY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "CoverageRepositoryEntrySequence")
	@SequenceGenerator(name = "CoverageRepositoryEntrySequence", sequenceName = "COVERAGE_REPOSITORY_ENTRY_SEQ", allocationSize = 5)
	private Long id;

	/** The coverage code. */
	@Column(name = "COVERAGE_CD", nullable = false, length = 5)
	private String coverageCode;

	/** The coverage type. */
	@Column(name = "COVERAGE_TYPE_CD", nullable = false, length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.CoverageTypeCodeEnum") })
	private CoverageTypeCodeEnum coverageType;

	/** The line of insurance. */
	@Column(name = "LINE_OF_INSURANCE_CD", nullable = false, length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.LineOfInsuranceCodeEnum") })
	private LineOfInsuranceCodeEnum lineOfInsurance;

	/** The surcharge discount. */
	@Column(name = "SURCHARGE_DISCOUNT_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.SurchargeDiscountCodeEnum") })
	private SurchargeDiscountCodeEnum surchargeDiscount;

	/** The premium or percentage. */
	@Column(name = "PREMIUM_OR_PERCENTAGE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PremiumOrPercentageCodeEnum") })
	private PremiumOrPercentageCodeEnum premiumOrPercentage;

	/** The creation form. */
	@Column(name = "CREATION_FORM_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.CreationFormCodeEnum") })
	private CreationFormCodeEnum creationForm;

	/** The rating risk type apply. */
	@Column(name = "RATING_RISK_TYPE_APPLY_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.RatingRiskTypeApplyCodeEnum") })
	private RatingRiskTypeApplyCodeEnum ratingRiskTypeApply;

	/** The endorsement processing type. */
	@Column(name = "ENDORSEMENT_PRCSNG_TYPE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.EndorsementProcessingTypeCodeEnum") })
	private EndorsementProcessingTypeCodeEnum endorsementProcessingType;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", length = 7)
	private Date effectiveDate;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;

	/** The endorsement group code. */
	@Column(name = "COVERAGE_GROUP_CD", length = 20)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.CoverageGroupCodeEnum") })
	private CoverageGroupCodeEnum coverageGroupCode;

	/** The province. */
	@Column(name = "PROVINCE_CD", nullable = false, length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ProvinceCodeEnum") })
	private ProvinceCodeEnum province;

	/** The endorsement method calculation. */
	@Column(name = "ENDORSEMENT_METHOD_CALCUL_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.EndorsementMethodCalculationCodeEnum") })
	private EndorsementMethodCalculationCodeEnum endorsementMethodCalculation;

	/** The rating factor total disability. */
	@Column(name = "RAT_FACT_TOTAL_DISABILITY_AMT", precision = 11)
	private Double ratingFactorTotalDisability;

	/** The rating factor medical expenses. */
	@Column(name = "RAT_FACT_MEDICAL_EXPENSES_AMT", precision = 11)
	private Double ratingFactorMedicalExpenses;

	/** The rating factor liability. */
	@Column(name = "RAT_FACT_LBLTY_AMT", precision = 11)
	private Double ratingFactorLiability;

	/** The rating factor specified perils. */
	@Column(name = "RAT_FACT_SPECIFIED_PERILS_AMT", precision = 11)
	private Double ratingFactorSpecifiedPerils;

	/** The rating factor comprehensive. */
	@Column(name = "RAT_FACT_COMPREHENSIVE_AMT", precision = 11)
	private Double ratingFactorComprehensive;

	/** The rating factor collision. */
	@Column(name = "RAT_FACT_COLLISION_AMT", precision = 11)
	private Double ratingFactorCollision;

	/** The rating factor all perils. */
	@Column(name = "RAT_FACT_ALL_PERILS_AMT", precision = 11)
	private Double ratingFactorAllPerils;

	/** The rating factor accident benefit. */
	@Column(name = "RAT_FACT_ACDNT_BNFT_AMT", precision = 11)
	private Double ratingFactorAccidentBenefit;

	/** The rating factor liability property damage. */
	@Column(name = "RAT_FACT_LBLTY_PRPTY_DMD_AMT", precision = 11)
	private Double ratingFactorLiabilityPropertyDamage;

	/** The rating factor liability bodily injury. */
	@Column(name = "RAT_FACT_LBLTY_BDLY_INJRY_AMT", precision = 11)
	private Double ratingFactorLiabilityBodilyInjury;

	/** The coverage short description en. */
	@Column(name = "COVERAGE_SHORT_ENG_DESC", length = 65)
	private String coverageShortDescriptionEn = null;

	/** The coverage short description fr. */
	@Column(name = "COVERAGE_SHORT_FRE_DESC", length = 65)
	private String coverageShortDescriptionFr = null;

	/** The coverage print description en. */
	@Column(name = "COVERAGE_PRINT_ENG_DESC", length = 90)
	private String coveragePrintDescriptionEn = null;

	/** The coverage print description fr. */
	@Column(name = "COVERAGE_PRINT_FRE_DESC", length = 90)
	private String coveragePrintDescriptionFr = null;

	/** The endorsement applicable type code. */
	@Column(name = "ENDORSEMENT_APLCBL_TYPE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.EndorsementApplicableTypeCodeEnum") })
	private EndorsementApplicableTypeCodeEnum endorsementApplicableTypeCode = null;

	/** The renewal action code. */
	@Column(name = "RENEWAL_ACTION_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.RenewalActionCodeEnum") })
	private RenewalActionCodeEnum renewalActionCode = null;

	/** The broker auth endorsement code. */
	@Column(name = "BROKER_AUTH_ENDORSEMENT_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.BrokerAuthEndorsementCodeEnum") })
	private BrokerAuthEndorsementCodeEnum brokerAuthEndorsementCode = null;

	/** The manufacturer auth endorsement code. */
	@Column(name = "MANUFACTURER_COMPANY_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum") })
	private ManufacturerCompanyCodeEnum manufacturerCompanyCode = null;

	/** The upload to savers coverage code. */
	@Column(name = "UPLOAD_SAVERS_COVERAGE_CD", length = 5)
	private String uploadToSaversCoverageCode;
	
	/** IHV Coverage. */
	@Column(name = "IHV_COVERAGE_CD", length = 5)
	private String ihvCoverage;

	/**
	 * Instantiates a new coverage repository entry.
	 */
	public CoverageRepositoryEntry() {
		// noarg constructor
	}

	/**
	 * Instantiates a new coverage repository entry.
	 * 
	 * @param aCoverageCode the a coverage code
	 * @param coverageTypeCode the coverage type code
	 * @param aLineOfInsurance the line of insurance
	 * @param coverageGroupCodeEnum coverage code enum
	 * @param aProvinceCodeEnum the a province code enum
	 */
	public CoverageRepositoryEntry(String aCoverageCode, CoverageTypeCodeEnum coverageTypeCode,
			LineOfInsuranceCodeEnum aLineOfInsurance, CoverageGroupCodeEnum coverageGroupCodeEnum,
			ProvinceCodeEnum aProvinceCodeEnum) {
		setCoverageCode(aCoverageCode);
		setCoverageType(coverageTypeCode);
		setLineOfInsurance(aLineOfInsurance);
		setCoverageGroupCode(coverageGroupCodeEnum);
		setProvince(aProvinceCodeEnum);
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the coverage code.
	 * 
	 * @return the coverage code
	 */
	public String getCoverageCode() {
		return this.coverageCode;
	}

	/**
	 * Sets the coverage code.
	 * 
	 * @param aCoverageCode the new coverage code
	 */
	public void setCoverageCode(String aCoverageCode) {
		this.coverageCode = aCoverageCode;
	}

	/**
	 * Gets the coverage type.
	 * 
	 * @return the coverage type
	 */
	public CoverageTypeCodeEnum getCoverageType() {
		return this.coverageType;
	}

	/**
	 * Sets the coverage type.
	 * 
	 * @param coverageTypeCode the new coverage type
	 */
	public void setCoverageType(CoverageTypeCodeEnum coverageTypeCode) {
		this.coverageType = coverageTypeCode;
	}

	/**
	 * Gets the line of insurance.
	 * 
	 * @return the line of insurance
	 */
	public LineOfInsuranceCodeEnum getLineOfInsurance() {
		return this.lineOfInsurance;
	}

	/**
	 * Sets the line of insurance.
	 * 
	 * @param lineOfInsuranceCode the new line of insurance
	 */
	public void setLineOfInsurance(LineOfInsuranceCodeEnum lineOfInsuranceCode) {
		this.lineOfInsurance = lineOfInsuranceCode;
	}

	/**
	 * Gets the surcharge discount.
	 * 
	 * @return the surcharge discount
	 */
	public SurchargeDiscountCodeEnum getSurchargeDiscount() {
		return this.surchargeDiscount;
	}

	/**
	 * Sets the surcharge discount.
	 * 
	 * @param surchargeDiscountCode the new surcharge discount
	 */
	public void setSurchargeDiscount(SurchargeDiscountCodeEnum surchargeDiscountCode) {
		this.surchargeDiscount = surchargeDiscountCode;
	}

	/**
	 * Gets the premium or percentage.
	 * 
	 * @return the premium or percentage
	 */
	public PremiumOrPercentageCodeEnum getPremiumOrPercentage() {
		return this.premiumOrPercentage;
	}

	/**
	 * Sets the premium or percentage.
	 * 
	 * @param premiumOrPercentageCode the new premium or percentage
	 */
	public void setPremiumOrPercentage(PremiumOrPercentageCodeEnum premiumOrPercentageCode) {
		this.premiumOrPercentage = premiumOrPercentageCode;
	}

	/**
	 * Gets the creation form.
	 * 
	 * @return the creation form
	 */
	public CreationFormCodeEnum getCreationForm() {
		return this.creationForm;
	}

	/**
	 * Sets the creation form.
	 * 
	 * @param creationFormCode the new creation form
	 */
	public void setCreationForm(CreationFormCodeEnum creationFormCode) {
		this.creationForm = creationFormCode;
	}

	/**
	 * Gets the rating risk type apply.
	 * 
	 * @return the rating risk type apply
	 */
	public RatingRiskTypeApplyCodeEnum getRatingRiskTypeApply() {
		return this.ratingRiskTypeApply;
	}

	/**
	 * Sets the rating risk type apply.
	 * 
	 * @param ratingRiskTypeApplyCode the new rating risk type apply
	 */
	public void setRatingRiskTypeApply(RatingRiskTypeApplyCodeEnum ratingRiskTypeApplyCode) {
		this.ratingRiskTypeApply = ratingRiskTypeApplyCode;
	}

	/**
	 * Gets the endorsement processing type.
	 * 
	 * @return the endorsement processing type
	 */
	public EndorsementProcessingTypeCodeEnum getEndorsementProcessingType() {
		return this.endorsementProcessingType;
	}

	/**
	 * Sets the endorsement processing type.
	 * 
	 * @param endorsementPrcsngTypeCode the new endorsement processing type
	 */
	public void setEndorsementProcessingType(EndorsementProcessingTypeCodeEnum endorsementPrcsngTypeCode) {
		this.endorsementProcessingType = endorsementPrcsngTypeCode;
	}

	/**
	 * Gets the effective date.
	 * 
	 * @return the effective date
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * Sets the effective date.
	 * 
	 * @param anEffectiveDate the new effective date
	 */
	public void setEffectiveDate(Date anEffectiveDate) {
		this.effectiveDate = anEffectiveDate;
	}

	/**
	 * Gets the expiry date.
	 * 
	 * @return the expiry date
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * Sets the expiry date.
	 * 
	 * @param anExpiryDate the new expiry date
	 */
	public void setExpiryDate(Date anExpiryDate) {
		this.expiryDate = anExpiryDate;
	}

	/**
	 * Return TRUE is the coverage is an endorsement (coverage type = endorsement).
	 * 
	 * @return true, if checks if is endorsement
	 */
	public boolean isEndorsement() {
		return ObjectUtils.equals(this.coverageType, CoverageTypeCodeEnum.ENDORSEMENT);
	}

	/**
	 * Gets the coverage group code.
	 * 
	 * @return the coverage group code
	 */
	public CoverageGroupCodeEnum getCoverageGroupCode() {
		return this.coverageGroupCode;
	}

	/**
	 * Sets the coverage group code.
	 * 
	 * @param aCoverageGroupCode the new coverage group code
	 */
	public void setCoverageGroupCode(CoverageGroupCodeEnum aCoverageGroupCode) {
		this.coverageGroupCode = aCoverageGroupCode;
	}

	/**
	 * Gets the province.
	 * 
	 * @return the province
	 */
	public ProvinceCodeEnum getProvince() {
		return this.province;
	}

	/**
	 * Sets the province.
	 * 
	 * @param provinceCode the new province
	 */
	public void setProvince(ProvinceCodeEnum provinceCode) {
		this.province = provinceCode;
	}

	/**
	 * Gets the rating factor accident benefit.
	 * 
	 * @return the ratingFactorAccidentBenefit
	 */
	public Double getRatingFactorAccidentBenefit() {
		return this.ratingFactorAccidentBenefit;
	}

	/**
	 * Sets the rating factor accident benefit.
	 * 
	 * @param aRatingFactorAccidentBenefit the a rating factor accident benefit
	 */
	public void setRatingFactorAccidentBenefit(Double aRatingFactorAccidentBenefit) {
		this.ratingFactorAccidentBenefit = aRatingFactorAccidentBenefit;
	}

	/**
	 * Gets the rating factor all perils.
	 * 
	 * @return the ratingFactorAllPerils
	 */
	public Double getRatingFactorAllPerils() {
		return this.ratingFactorAllPerils;
	}

	/**
	 * Sets the rating factor all perils.
	 * 
	 * @param aRatingFactorAllPerils the a rating factor all perils
	 */
	public void setRatingFactorAllPerils(Double aRatingFactorAllPerils) {
		this.ratingFactorAllPerils = aRatingFactorAllPerils;
	}

	/**
	 * Gets the rating factor collision.
	 * 
	 * @return the ratingFactorCollision
	 */
	public Double getRatingFactorCollision() {
		return this.ratingFactorCollision;
	}

	/**
	 * Sets the rating factor collision.
	 * 
	 * @param aRatingFactorCollision the a rating factor collision
	 */
	public void setRatingFactorCollision(Double aRatingFactorCollision) {
		this.ratingFactorCollision = aRatingFactorCollision;
	}

	/**
	 * Gets the rating factor comprehensive.
	 * 
	 * @return the ratingFactorComprehensive
	 */
	public Double getRatingFactorComprehensive() {
		return this.ratingFactorComprehensive;
	}

	/**
	 * Sets the rating factor comprehensive.
	 * 
	 * @param aRatingFactorComprehensive the a rating factor comprehensive
	 */
	public void setRatingFactorComprehensive(Double aRatingFactorComprehensive) {
		this.ratingFactorComprehensive = aRatingFactorComprehensive;
	}

	/**
	 * Gets the rating factor liability.
	 * 
	 * @return the ratingFactorLiability
	 */
	public Double getRatingFactorLiability() {
		return this.ratingFactorLiability;
	}

	/**
	 * Sets the rating factor liability.
	 * 
	 * @param aRatingFactorLiability the a rating factor liability
	 */
	public void setRatingFactorLiability(Double aRatingFactorLiability) {
		this.ratingFactorLiability = aRatingFactorLiability;
	}

	/**
	 * Gets the rating factor liability bodily injury.
	 * 
	 * @return the ratingFactorLiabilityBodilyInjury
	 */
	public Double getRatingFactorLiabilityBodilyInjury() {
		return this.ratingFactorLiabilityBodilyInjury;
	}

	/**
	 * Sets the rating factor liability bodily injury.
	 * 
	 * @param aRatingFactorLiabilityBodilyInjury the a rating factor liability bodily injury
	 */
	public void setRatingFactorLiabilityBodilyInjury(Double aRatingFactorLiabilityBodilyInjury) {
		this.ratingFactorLiabilityBodilyInjury = aRatingFactorLiabilityBodilyInjury;
	}

	/**
	 * Gets the rating factor liability property damage.
	 * 
	 * @return the ratingFactorLiabilityPropertyDamage
	 */
	public Double getRatingFactorLiabilityPropertyDamage() {
		return this.ratingFactorLiabilityPropertyDamage;
	}

	/**
	 * Sets the rating factor liability property damage.
	 * 
	 * @param aRatingFactorLiabilityPropertyDamage the a rating factor liability property damage
	 */
	public void setRatingFactorLiabilityPropertyDamage(Double aRatingFactorLiabilityPropertyDamage) {
		this.ratingFactorLiabilityPropertyDamage = aRatingFactorLiabilityPropertyDamage;
	}

	/**
	 * Gets the rating factor medical expenses.
	 * 
	 * @return the ratingFactorMedicalExpenses
	 */
	public Double getRatingFactorMedicalExpenses() {
		return this.ratingFactorMedicalExpenses;
	}

	/**
	 * Sets the rating factor medical expenses.
	 * 
	 * @param aRatingFactorMedicalExpenses the a rating factor medical expenses
	 */
	public void setRatingFactorMedicalExpenses(Double aRatingFactorMedicalExpenses) {
		this.ratingFactorMedicalExpenses = aRatingFactorMedicalExpenses;
	}

	/**
	 * Gets the rating factor specified perils.
	 * 
	 * @return the ratingFactorSpecifiedPerils
	 */
	public Double getRatingFactorSpecifiedPerils() {
		return this.ratingFactorSpecifiedPerils;
	}

	/**
	 * Sets the rating factor specified perils.
	 * 
	 * @param aRatingFactorSpecifiedPerils the a rating factor specified perils
	 */
	public void setRatingFactorSpecifiedPerils(Double aRatingFactorSpecifiedPerils) {
		this.ratingFactorSpecifiedPerils = aRatingFactorSpecifiedPerils;
	}

	/**
	 * Gets the rating factor total disability.
	 * 
	 * @return the ratingFactorTotalDisability
	 */
	public Double getRatingFactorTotalDisability() {
		return this.ratingFactorTotalDisability;
	}

	/**
	 * Sets the rating factor total disability.
	 * 
	 * @param aRatingFactorTotalDisability the a rating factor total disability
	 */
	public void setRatingFactorTotalDisability(Double aRatingFactorTotalDisability) {
		this.ratingFactorTotalDisability = aRatingFactorTotalDisability;
	}

	/**
	 * Gets the endorsement method calculation.
	 * 
	 * @return the endorsementMethodCalculation
	 */
	public EndorsementMethodCalculationCodeEnum getEndorsementMethodCalculation() {
		return this.endorsementMethodCalculation;
	}

	/**
	 * Sets the endorsement method calculation.
	 * 
	 * @param anEndorsementMethodCalculation the a endorsement method calculation
	 */
	public void setEndorsementMethodCalculation(EndorsementMethodCalculationCodeEnum anEndorsementMethodCalculation) {
		this.endorsementMethodCalculation = anEndorsementMethodCalculation;
	}

	/**
	 * @return the brokerAuthEndorsementCode
	 */
	public BrokerAuthEndorsementCodeEnum getBrokerAuthEndorsementCode() {
		return this.brokerAuthEndorsementCode;
	}

	/**
	 * @param aBrokerAuthEndorsementCode the brokerAuthEndorsementCode to set
	 */
	public void setBrokerAuthEndorsementCode(BrokerAuthEndorsementCodeEnum aBrokerAuthEndorsementCode) {
		this.brokerAuthEndorsementCode = aBrokerAuthEndorsementCode;
	}

	/**
	 * @return the coveragePrintDescriptionEn
	 */
	public String getCoveragePrintDescriptionEn() {
		return this.coveragePrintDescriptionEn;
	}

	/**
	 * @param aCoveragePrintDescriptionEn the coveragePrintDescriptionEn to set
	 */
	public void setCoveragePrintDescriptionEn(String aCoveragePrintDescriptionEn) {
		this.coveragePrintDescriptionEn = aCoveragePrintDescriptionEn;
	}

	/**
	 * @return the coveragePrintDescriptionFr
	 */
	public String getCoveragePrintDescriptionFr() {
		return this.coveragePrintDescriptionFr;
	}

	/**
	 * @param aCoveragePrintDescriptionFr the coveragePrintDescriptionFr to set
	 */
	public void setCoveragePrintDescriptionFr(String aCoveragePrintDescriptionFr) {
		this.coveragePrintDescriptionFr = aCoveragePrintDescriptionFr;
	}

	/**
	 * @return the coverageShortDescriptionEn
	 */
	public String getCoverageShortDescriptionEn() {
		return this.coverageShortDescriptionEn;
	}

	/**
	 * @param aCoverageShortDescriptionEn the coverageShortDescriptionEn to set
	 */
	public void setCoverageShortDescriptionEn(String aCoverageShortDescriptionEn) {
		this.coverageShortDescriptionEn = aCoverageShortDescriptionEn;
	}

	/**
	 * @return the coverageShortDescriptionFr
	 */
	public String getCoverageShortDescriptionFr() {
		return this.coverageShortDescriptionFr;
	}

	/**
	 * @param aCoverageShortDescriptionFr the coverageShortDescriptionFr to set
	 */
	public void setCoverageShortDescriptionFr(String aCoverageShortDescriptionFr) {
		this.coverageShortDescriptionFr = aCoverageShortDescriptionFr;
	}

	/**
	 * @return the endorsementApplicableTypeCode
	 */
	public EndorsementApplicableTypeCodeEnum getEndorsementApplicableTypeCode() {
		return this.endorsementApplicableTypeCode;
	}

	/**
	 * @param anEndorsementApplicableTypeCode the endorsementApplicableTypeCode to set
	 */
	public void setEndorsementApplicableTypeCode(EndorsementApplicableTypeCodeEnum anEndorsementApplicableTypeCode) {
		this.endorsementApplicableTypeCode = anEndorsementApplicableTypeCode;
	}

	/**
	 * @return the renewalActionCode
	 */
	public RenewalActionCodeEnum getRenewalActionCode() {
		return this.renewalActionCode;
	}

	/**
	 * @param aRenewalActionCode the renewalActionCode to set
	 */
	public void setRenewalActionCode(RenewalActionCodeEnum aRenewalActionCode) {
		this.renewalActionCode = aRenewalActionCode;
	}

	public ManufacturerCompanyCodeEnum getManufacturerCompanyCode() {
		return this.manufacturerCompanyCode;
	}

	public void setManufacturerCompanyCode(ManufacturerCompanyCodeEnum aManufacturerCompanyCode) {
		this.manufacturerCompanyCode = aManufacturerCompanyCode;
	}

	/**
	 * @return the uploadToSaversCoverageCode
	 */
	public String getUploadToSaversCoverageCode() {
		return this.uploadToSaversCoverageCode;
	}

	/**
	 * @param uploadToSaversCoverageCode the upload coverage code to set
	 */
	public void setUploadToSaversCoverageCode(String uploadToSaversCoverageCode) {
		this.uploadToSaversCoverageCode = uploadToSaversCoverageCode;
	}

	/**
	 * @return the ihvCoverage
	 */
	public String getIhvCoverage() {
		return ihvCoverage;
	}

	/**
	 * @param ihvCoverage the ihvCoverage to set
	 */
	public void setIhvCoverage(String ihvCoverage) {
		this.ihvCoverage = ihvCoverage;
	}
	
	

}
