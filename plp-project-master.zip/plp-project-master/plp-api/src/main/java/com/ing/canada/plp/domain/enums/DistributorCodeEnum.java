/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2017, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The enum for distributor codes.
 *
 * @author <a href="mailto:pascal.meunier@intact.net">Pascal Meunier</a>
 *
 */
public enum DistributorCodeEnum {

	/** BNA = Banque National Assurance */
	BNA("BNA", "N"),

	/** BEL = Belairdirect*/
	BEL("BEL", " "),
	
	/** Default */
	DEFAULT("", " ");

	/** The db code. */
	private String code = null;
	
	/** The classic code. */
	private String ilCode;

	/**
	 * Instantiates a new distributor enum
	 * @param code code as a {@link String}
	 */
	private DistributorCodeEnum(String code, String ilCode) {
		this.code = code;
		this.ilCode = ilCode;
	}

	/**
	 * Value of code.
	 *
	 * @param value the value to mach
	 * @return the found {@link DistributorCodeEnum}, null when not found.
	 */
	public static DistributorCodeEnum valueOfCode(String value) {
		DistributorCodeEnum found = null;
		if (StringUtils.isNotEmpty(value)){
			for (DistributorCodeEnum val : values()){
				if (val.code.equalsIgnoreCase(value)){
					found = val;
					break; // stop when found;
				}
			}
		}
		return found;
	}
	
	/**
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * @return the ilCode
	 */
	public String getIlCode() {
		return this.ilCode;
	}

}
