package com.ing.canada.plp.domain.formprocess;

import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.usertype.BaseEntity;

@Entity
@Table(name = "FORM", uniqueConstraints = {})
public class Form extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "FORM_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "FormSequence")
	@SequenceGenerator(name = "FormSequence", sequenceName = "FORM_SEQ", allocationSize = 5)
	private Long id = null;

	/** The Form name. */
	@Column(name = "NAME_TXT", length = 80, nullable = false)
	private String name;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", length = 7)
	private Date effectiveDate;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;

	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "form")
	private Set<FormRequest> formRequests = new HashSet<FormRequest>(0);

	@Override
	public Object getId() {
		return this.id;
	}

	@Override
	public void setId(Object id) {
		this.id = (Long) id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getExpiryDate() {
		return this.expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Set<FormRequest> getFormRequests() {
		return Collections.unmodifiableSet(this.formRequests);
	}

	public void setFormRequests(Set<FormRequest> formRequests) {
		this.formRequests = formRequests;
	}

	public void addFormRequest(FormRequest aFormRequest) {
		AssociationsHelper.updateOneToManyFields(this, "formRequests", aFormRequest, "form");
	}

	public void removeFormRequest(FormRequest aFormRequest) {
		AssociationsHelper.updateOneToManyFields(null, "formRequests", aFormRequest, "form");
	}

}
