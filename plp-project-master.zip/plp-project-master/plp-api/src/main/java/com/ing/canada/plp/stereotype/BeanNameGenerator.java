/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.stereotype;

import java.beans.Introspector;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.AnnotationBeanNameGenerator;
import org.springframework.util.ClassUtils;

/**
 * The BeanNameGenerator. Add the prefix plp- on all none define bean.
 * 
 * @author fsimard
 */
public class BeanNameGenerator extends AnnotationBeanNameGenerator {

    
    /** The Constant BEAN_NAME_PREFIX. */
    private static final String BEAN_NAME_PREFIX = "plp-";
       
    /**
     * @see org.springframework.context.annotation.AnnotationBeanNameGenerator#buildDefaultBeanName(org.springframework.beans.factory.config.BeanDefinition)
     */
    @Override
    protected String buildDefaultBeanName(BeanDefinition definition) {
        String shortClassName = ClassUtils.getShortName(definition.getBeanClassName());
        return buildName(shortClassName);
    }

	/**
	 * Builds the name.
	 *
	 * @param beanName the bean name
	 * @return the string
	 */
	public static String buildName(String beanName) {
		return BEAN_NAME_PREFIX + Introspector.decapitalize(beanName);
	}
    
    
}
