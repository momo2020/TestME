package com.ing.canada.plp.domain;

import com.ing.canada.plp.domain.enums.DistributionChannelCodeEnum;
import com.ing.canada.plp.domain.enums.DistributorCodeEnum;
import com.ing.canada.plp.domain.enums.InsuranceBusinessCodeEnum;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;

public class BusinessContext {
	
	private String application = null;

	private ManufacturingContext manufacturingContext = null;

	private DistributorCodeEnum distributor = null;

	public BusinessContext() {
	}
	
	public BusinessContext(ManufacturingContext manufacturingContext) {
		this.setManufacturingContext(manufacturingContext);
	}

	public BusinessContext(ManufacturingContext manufacturingContext, DistributorCodeEnum distributor) {
		this.setDistributor(distributor);
		this.setManufacturingContext(manufacturingContext);
	}

	public BusinessContext(String application, String distributionChannel, String insuranceBusiness,
			String province, String manufacturerCompany, String distributor) {
		this.setApplication(application);
		this.setDistributor(DistributorCodeEnum.valueOfCode(distributor));
		this.setManufacturingContext(new ManufacturingContext(distributionChannel, insuranceBusiness, province,
				manufacturerCompany));
	}

	public String getApplication() {
		return this.application;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public ManufacturingContext getManufacturingContext() {
		return this.manufacturingContext;
	}

	public void setManufacturingContext(ManufacturingContext manufacturingContext) {
		this.manufacturingContext = manufacturingContext;
	}

	public DistributorCodeEnum getDistributor() {
		return this.distributor;
	}

	public void setDistributor(DistributorCodeEnum distributor) {
		this.distributor = distributor;
	}
	
	public static BusinessContext build(ProvinceCodeEnum province, DistributionChannelCodeEnum distributionChannel,
			InsuranceBusinessCodeEnum insuranceBusiness, ManufacturerCompanyCodeEnum manufacturerCompany) {
		BusinessContext context =  new BusinessContext();
		context.setManufacturingContext(new ManufacturingContext(distributionChannel, insuranceBusiness, province, manufacturerCompany));
		
		return context;
	}

	public String toString() {
		return "[application=" + this.getApplication() + ", manufacturing context=" + this.getManufacturingContext() + ", distributor=" + this.getDistributor() + "]";
	}
}
