/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import java.util.Comparator;

import org.apache.commons.lang.StringUtils;

import com.ing.canada.plp.domain.driver.DriverLicenseClass;

/**
 * The Enum DriverLicenseClassCodeEnum.
 */
public enum DriverLicenseClassCodeEnum {

	LEARNER_PERMIT("G1"), //
	PROBATIONARY_PERMIT("G2"), //
	GRADUATED_PERMIT("G"), //
	PROFESSIONAL_ANY_VEHICULE("1"), //
	PROFESSIONAL_BUS("2"), //
	AXLE_PLUS("3"), //
	PROFESSIONAL_TAXI("4"), //
	AXLE_CARS("5"), //
	LEARNER("7"); //

	/**
	 * Instantiates a new driver license class code enum.
	 * 
	 * @param aCode the a code
	 */
	private DriverLicenseClassCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the driver license class code enum
	 */
	public static DriverLicenseClassCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (DriverLicenseClassCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}

	/**
	 * The Class OntarioLicenseClassesComparator. Orders G, G2, G1, ...
	 */
	public static class OntarioLicenseClassesComparator implements Comparator<DriverLicenseClass> {
		@Override
		public int compare(com.ing.canada.plp.domain.driver.DriverLicenseClass o1,
				com.ing.canada.plp.domain.driver.DriverLicenseClass o2) {
			if (DriverLicenseClassCodeEnum.GRADUATED_PERMIT.equals(o1.getDriverLicenseClass())) {
				return -1;
			} else if (DriverLicenseClassCodeEnum.GRADUATED_PERMIT.equals(o2.getDriverLicenseClass())) {
				return 1;
			} else if (DriverLicenseClassCodeEnum.PROBATIONARY_PERMIT.equals(o1.getDriverLicenseClass())) {
				return -1;
			} else if (DriverLicenseClassCodeEnum.PROBATIONARY_PERMIT.equals(o2.getDriverLicenseClass())) {
				return 1;
			}

			return 0;
		}
	}
}
