/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.diagnostics;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.DiagnosticsAdviceSelectedTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.insuranceriskoffer.InsuranceRiskOffer;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * The Class DiagnosticAutomatedAdvice.
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "DGN_AUTO_ADVICE", uniqueConstraints = {})
public class DiagnosticAutomatedAdvice extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "DGN_AUTO_ADVICE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "DiagnosticAutomatedAdviceSequence")
	@SequenceGenerator(name = "DiagnosticAutomatedAdviceSequence", sequenceName = "DGN_AUTO_ADVICE_SEQ", allocationSize = 5)
	private Long id;

	/**
	 * For display purposes only. Indicates if a diagnostic advice is selected.
	 */
	@Column(name = "ADVICE_SELECTED_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean adviceSelectedInd;

	/**
	 * Used to indicate if the diagnostic advice is present and how it was selected (by the system, the client, the
	 * agent).
	 */
	@Column(name = "ADVICE_SELECTED_TYPE_CD", length = 20)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.DiagnosticsAdviceSelectedTypeCodeEnum") })
	private DiagnosticsAdviceSelectedTypeCodeEnum adviceSelectedType;

	/**
	 * Used to indicate if the advice meets all criterias to be eligible for the risk.
	 */
	@Column(name = "ADVICE_ELIGIBLE_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean adviceEligibleInd;

	/**
	 * Used to indicate if the advice meets all criterias to be eligible for the risk.
	 */
	@Column(name = "ADVICE_APPLICABLE_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean adviceApplicableInd;

	/** The Diagnostic Repository Info info. */
	@ManyToOne(cascade = { CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name = "DGN_AUTO_ADVICE_REP_ENTRY_ID", nullable = false, updatable = true)
	private DiagnosticAutomatedAdviceRepositoryEntry diagnosticAutoAdviceRepositoryEntry;

	/** The Insurance Risk Offer info. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_RISK_OFFER_ID", nullable = true, updatable = true)
	private InsuranceRiskOffer insuranceRiskOffer;
	
	/** The Insurance Risk info. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "INSURANCE_RISK_ID", nullable = true, updatable = true)
	private InsuranceRisk insuranceRisk;

	/**
	 * Default Constructor.
	 */
	public DiagnosticAutomatedAdvice() {
		// Nothing to do
	}

	/**
	 * Instantiates a new diagnostic automated advice.
	 * 
	 * @param aDiagnosticAutoAdviceRepositoryEntry the a diagnostic auto advice repository entry
	 * @param aInsuranceRiskOffer the a insurance risk offer
	 */
	public DiagnosticAutomatedAdvice(DiagnosticAutomatedAdviceRepositoryEntry aDiagnosticAutoAdviceRepositoryEntry,
			InsuranceRiskOffer aInsuranceRiskOffer) {
		setDiagnosticAutoAdviceRepositoryEntry(aDiagnosticAutoAdviceRepositoryEntry);
		setInsuranceRiskOffer(aInsuranceRiskOffer);
	}

	/**
	 * Instantiates a new diagnostic automated advice.
	 * 
	 * @param aDiagnosticAutoAdviceRepositoryEntry the a diagnostic auto advice repository entry
	 * @param aInsuranceRisk the a insurance risk 
	 */
	public DiagnosticAutomatedAdvice(DiagnosticAutomatedAdviceRepositoryEntry aDiagnosticAutoAdviceRepositoryEntry,
			InsuranceRisk aInsuranceRisk) {
		setDiagnosticAutoAdviceRepositoryEntry(aDiagnosticAutoAdviceRepositoryEntry);
		setInsuranceRisk(aInsuranceRisk);
	}
	
	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the advice applicable ind.
	 * 
	 * @return the advice applicable ind
	 */
	public Boolean getAdviceApplicableInd() {
		return this.adviceApplicableInd;
	}

	/**
	 * Sets the advice applicable ind.
	 * 
	 * @param anAdviceApplicableInd the new advice applicable ind
	 */
	public void setAdviceApplicableInd(Boolean anAdviceApplicableInd) {
		this.adviceApplicableInd = anAdviceApplicableInd;
	}

	/**
	 * Gets the advice eligible ind.
	 * 
	 * @return the advice eligible ind
	 */
	public Boolean getAdviceEligibleInd() {
		return this.adviceEligibleInd;
	}

	/**
	 * Sets the advice eligible ind.
	 * 
	 * @param anAdviceEligibleInd the new advice eligible ind
	 */
	public void setAdviceEligibleInd(Boolean anAdviceEligibleInd) {
		this.adviceEligibleInd = anAdviceEligibleInd;
	}

	/**
	 * Gets the advice selected ind.
	 * 
	 * @return the advice selected ind
	 */
	public Boolean getAdviceSelectedInd() {
		return this.adviceSelectedInd;
	}

	/**
	 * Sets the advice selected ind.
	 * 
	 * @param anAdviceSelectedInd the new advice selected ind
	 */
	public void setAdviceSelectedInd(Boolean anAdviceSelectedInd) {
		this.adviceSelectedInd = anAdviceSelectedInd;
	}

	/**
	 * Gets the advice select type.
	 * 
	 * @return the advice select type
	 */
	public DiagnosticsAdviceSelectedTypeCodeEnum getAdviceSelectedType() {
		return this.adviceSelectedType;
	}

	/**
	 * Sets the advice select type.
	 * 
	 * @param anAdviceSelectType the new advice select type
	 */
	public void setAdviceSelectedType(DiagnosticsAdviceSelectedTypeCodeEnum anAdviceSelectType) {
		this.adviceSelectedType = anAdviceSelectType;
	}

	/**
	 * Gets the diagnostic auto advice repository entry id.
	 * 
	 * @return the diagnostic auto advice repository entry id
	 */
	public DiagnosticAutomatedAdviceRepositoryEntry getDiagnosticAutoAdviceRepositoryEntry() {
		return this.diagnosticAutoAdviceRepositoryEntry;
	}

	/**
	 * Sets the diagnostic auto advice repository entry id.
	 * 
	 * @param aDiagnosticAutoAdviceRepositoryEntry the new diagnostic auto advice repository entry id
	 */
	public void setDiagnosticAutoAdviceRepositoryEntry(
			DiagnosticAutomatedAdviceRepositoryEntry aDiagnosticAutoAdviceRepositoryEntry) {
		this.diagnosticAutoAdviceRepositoryEntry = aDiagnosticAutoAdviceRepositoryEntry;
	}

	/**
	 * Gets the insurance risk offer id.
	 * 
	 * @return the insurance risk offer id
	 */
	@XmlTransient // parent
	public InsuranceRiskOffer getInsuranceRiskOffer() {
		return this.insuranceRiskOffer;
	}

	/**
	 * Sets the insurance risk offer id.
	 * 
	 * @param aInsuranceRiskOffer the new insurance risk offer id
	 */
	public void setInsuranceRiskOffer(InsuranceRiskOffer aInsuranceRiskOffer) {
		AssociationsHelper.updateOneToManyFields(aInsuranceRiskOffer, "diagnosticAdvices", this, "insuranceRiskOffer");
	}
	
	/**
	 * Gets the insurance risk id.
	 * 
	 * @return the insurance risk id
	 */
	@XmlTransient // parent
	public InsuranceRisk getInsuranceRisk() {
		return this.insuranceRisk;
	}

	/**
	 * Sets the insurance risk  id.
	 * 
	 * @param aInsuranceRisk the new insurance risk  id
	 */
	public void setInsuranceRisk(InsuranceRisk aInsuranceRisk) {
		AssociationsHelper.updateOneToManyFields(aInsuranceRisk, "diagnosticAdvices", this, "insuranceRisk");
	}
}
