/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import java.util.Date;
import java.util.Set;

import com.ing.canada.plp.domain.ManufacturingContext;
import com.ing.canada.plp.domain.enums.HolderAutoInsuranceSinceCodeEnum;
import com.ing.canada.plp.domain.enums.PartyTypeCodeEnum;
import com.ing.canada.plp.domain.enums.PrincipalDriverSinceCodeEnum;
import com.ing.canada.plp.domain.enums.ReasonDeclinedOrCancelledCodeEnum;
import com.ing.canada.plp.domain.enums.RelationTypeCodeEnum;
import com.ing.canada.plp.domain.insurancepolicy.InsurancePolicy;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.insuranceriskoffer.PolicyOfferRating;
import com.ing.canada.plp.domain.partnership.Partnership;
import com.ing.canada.plp.domain.party.Party;
import com.ing.canada.plp.domain.policyversion.MarketSegment;
import com.ing.canada.plp.domain.policyversion.PolicyHolder;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;
import com.ing.canada.plp.domain.policyversion.RelatedInsurancePolicy;
import com.ing.canada.plp.domain.vehicle.Vehicle;

/**
 * Policy version interface.
 * 
 * <p>
 * This is to help by having a helper to facilitate by retrieving pertaining policy version object models.
 * </p>
 * 
 * @author rassaad
 */
public interface IPolicyVersionHelper {

	/**
	 * Get selected party from the policy version.
	 * 
	 * @param aPartyId The selected party Id.
	 * @param aPolicyVersion The {@link PolicyVersion}.
	 * 
	 * @return The {@link Party}.
	 * 
	 * @author rassaad
	 */
	Party getParty(Long aPartyId, PolicyVersion aPolicyVersion);

	/**
	 * Get latest policy version for insurancePolicy
	 * 
	 * @param insurancePolicy
	 * 
	 * @return The {@link PolicyVersion}.
	 * 
	 * @author pmdroz
	 */
	PolicyVersion getLastPolicyVersionForInsurancePolicy(InsurancePolicy insurancePolicy);

	/**
	 * Get all the parties that are of individual type
	 * 
	 * @param aPolicyVersion The policyVersion containing the Parties
	 * @return all the parties that are of individual type
	 */
	Set<Party> getIndividualParties(PolicyVersion aPolicyVersion);

	/**
	 * Get all the parties that are of the asked type.
	 * 
	 * @param aPolicyVersion The policyVersion containing the Parties
	 * @param type the type of the parties to return
	 * 
	 * @return all the parties that are of the asked type
	 */
	Set<Party> getPartiesOfType(PolicyVersion aPolicyVersion, PartyTypeCodeEnum type);

	/**
	 * Get the insurance risk from the insurance risk sequence
	 * 
	 * @param aPolicyVersion The {@link policyVersion}
	 * @param aSequence The sequence.
	 * 
	 * @return The {@link InsuranceRisk}.
	 */
	InsuranceRisk getInsuranceRiskBySequence(PolicyVersion aPolicyVersion, Short sequence);

	/**
	 * Get selected insurance risk from the policy version.
	 * 
	 * @param aInsuranceRiskId The selected insurance risk Id.
	 * @param aPolicyVersion The {@link PolicyVersion}.
	 * 
	 * @return The {@link InsuranceRisk}.
	 * 
	 * @author rassaad
	 */
	InsuranceRisk getInsuranceRisk(Long aInsuranceRiskId, PolicyVersion aPolicyVersion);

	/**
	 * Checks if this is a renewal.
	 * 
	 * @param aPolicyVersion the a policy version
	 * 
	 * @return true, if is renewal
	 */
	boolean isRenewal(PolicyVersion aPolicyVersion);

	/**
	 * Gets the principal insured policy holder.
	 * 
	 * @param aPolicyVersion the a policy version
	 * 
	 * @return the principal insured policy holder
	 */
	PolicyHolder getPrincipalInsuredPolicyHolder(PolicyVersion aPolicyVersion);

	/**
	 * Gets the ReasonDeclinedOrCancelledCodeEnum reason.
	 * 
	 * @param aPolicyVersion the PolicyVersion to check
	 * 
	 * @return the ReasonDeclinedOrCancelledCodeEnum or null if it's not declined or cancelled
	 */
	ReasonDeclinedOrCancelledCodeEnum getDeclinedOrCancelledReason(PolicyVersion aPolicyVersion);

	/**
	 * Checks if is declined or cancelled for the reason parameter
	 * 
	 * @param aPolicyVersion the PolicyVersion to check
	 * @param reason the reason to verify
	 * 
	 * @return true, if is declined or cancelled for the reason parameter
	 */
	boolean isDeclinedOrCancelledFor(PolicyVersion aPolicyVersion, ReasonDeclinedOrCancelledCodeEnum reason);

	/**
	 * Checks if has been cancelled for non payment.
	 * 
	 * @param aPolicyVersion the a policy version
	 * 
	 * @return true, if has been cancelled for non payment.
	 */
	boolean isCancelledForNonPayment(PolicyVersion aPolicyVersion);

	/**
	 * Determine if the policy is under the new accident benefits legislation.
	 * 
	 * @param anOffer - Policy offer
	 * @param aNewAccidentBenefitAvailableDate - Date when the new accident benefits legislation is in force.
	 * @return true if the policy is under the new legislation for accident benefits
	 */
	boolean isUnderNewAccidentBenefits(PolicyOfferRating anOffer, Date aNewAccidentBenefitAvailableDate);

	/**
	 * Determine if the quote is under the new accident benefits legislation.
	 * 
	 * @param anOffer - Policy offer
	 * @param aNewAccidentBenefitAvailableDate - Date when the new accident benefits legislation is in force.
	 * @return true if the policy is under the new legislation for accident benefits.
	 */
	boolean isUnderNewAccidentBenefits(PolicyVersion aPolicyVersion, Date aNewAccidentBenefitAvailableDate);

	/**
	 * Gets a relatedinsurancepolicy from the database with a specified ralationType.
	 * 
	 * @param policyVersion the policy version
	 * @param relationTypeCode the relation type code
	 * 
	 * @return the related insurance policy
	 */
	RelatedInsurancePolicy getRelatedInsurancePolicy(PolicyVersion policyVersion, RelationTypeCodeEnum relationTypeCode);

	/**
	 * Return true if this policy version is rated or if a previous policy version exists (meaning it was previously
	 * rated).
	 * 
	 * @param policyVersion
	 * @return
	 */
	boolean isQuoteAlreadyRatedOnce(PolicyVersion policyVersion);

	/**
	 * Gets the additional policy holder
	 * 
	 * @param aPolicyVersion the a policy version
	 * @param partyId the party id
	 * 
	 * @return the principal insured policy holder
	 */
	PolicyHolder retrievePolicyHolderByPartyId(PolicyVersion aPolicyVersion, Long partyId);

	/**
	 * Determine if the policy version is a combined policy
	 * 
	 * @param policyVersion the policy version
	 * 
	 * @return true if combined policy, false otherwise
	 */
	boolean isCombinedPolicy(PolicyVersion policyVersion);

	/**
	 * Retrieve a vehicle with the id provided from the policy versions's collection of vehicles.<br>
	 * The provided id is matched to the InsuranceRisk's InsuranceRiskSequence field.<br>
	 * 
	 * @param aPolicyVersion - {@link PolicyVersion}.
	 * @param id - vehicle's id in the policy version.
	 * @return {@link Vehicle} with the matching id or null when not found.
	 */
	public Vehicle retrieveVehicle(PolicyVersion aPolicyVersion, int id);
	
	/**
	 * Retrieve a vehicle with the id provided from the policy versions's collection of vehicles.<br>
	 * The provided id is matched to the InsuranceRisk's webMsgId field.<br>
	 * 
	 * @param aPolicyVersion - {@link PolicyVersion}.
	 * @param id - vehicle's id in the policy version.
	 * @return {@link Vehicle} with the matching id or null when not found.
	 */
	public Vehicle retrieveVehicleByWebMsgId(PolicyVersion aPolicyVersion, int id);
	
	

	/**
	 * Retrieve a party with the id provided from the policy versions's collection of party.<br>
	 * The provided id is matched to the DriverComplementInfo's driverSequence field.<br>
	 * 
	 * @param aPolicyVersion - {@link PolicyVersion}.
	 * @param id - party's id in the policy version.
	 * @return {@link Party} with the matching id or null when not found.
	 */
	public Party retrieveParty(final PolicyVersion aPolicyVersion, final int id);
	
	/**
	 * Retrieve a party with the id provided from the policy versions's collection of party.<br>
	 * The provided id is matched to the webMsgId field.<br>
	 * 
	 * @param aPolicyVersion - {@link PolicyVersion}.
	 * @param id - party's id in the policy version.
	 * @return {@link Party} with the matching id or null when not found.
	 */
	Party retrievePartyFromWebMsgId(PolicyVersion aPolicyVersion, final int id); 

	/**
	 * Return the ManufacturingContext for a given PolicyVersion
	 * 
	 * @param PolicyVersion
	 * 
	 * @return the ManufacturingContext
	 */
	public ManufacturingContext getManufactringContextForPolicyVersion(PolicyVersion aPolicyVersion);

	/**
	 * Return the partnership for a given policyVersion
	 * 
	 * @param policyVersion {@link PolicyVersion}
	 * @return {@link Partnership}
	 */
	public Partnership getPartnerShip(PolicyVersion policyVersion);
	
	/**
	 * Get selected MarketSegment from the policy version.
	 * 
	 * @param marketSegment the market segment.
	 * @param aPolicyVersion The {@link PolicyVersion}.
	 * 
	 * @return The {@link MarketSegment}.
	 * 
	 */
	public MarketSegment getMarketSegment(String marketSegment, PolicyVersion aPolicyVersion);

	/**
	 * Set all related information depending on 
	 * 
	 * @param aPlPolicyVersion
	 */
	void definePrincipalDriverRelatedInformation(PolicyVersion aPlPolicyVersion);
	
	/**
	 * Convert date to {@link PrincipalDriverSinceCodeEnum} 
	 * 
	 * @param date {@link Date}
	 * @return {@link PrincipalDriverSinceCodeEnum}
	 */
	public PrincipalDriverSinceCodeEnum convertDateToDriverSinceCodeEnum(Date date);
	
	/**
	 *  Convert date to {@link HolderAutoInsuranceSinceCodeEnum} 
	 * 
	 * @param date {@link Date}
	 * @return {@link HolderAutoInsuranceSinceCodeEnum}
	 */
	public HolderAutoInsuranceSinceCodeEnum convertDateToHolderAutoInsuranceSinceCode(Date dateFromPega);
	
	/**
	 * New registration doesn't use a tam account. 
	 * We check if there's a principal user and if he has an email address
	 * 
	 * @param policyVersionID
	 * @return
	 */
	public boolean isRegistered(Long policyVersionID);

	Set<Party> getParties(PolicyVersion aPolicyVersion);
}
