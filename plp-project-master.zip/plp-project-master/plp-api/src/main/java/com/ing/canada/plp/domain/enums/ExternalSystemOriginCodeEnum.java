package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum ExternalSystemOriginCodeEnum.
 */
public enum ExternalSystemOriginCodeEnum {

	WEB_BROKER("WEBBK"), 
	BROKER_PORTAL("BKPOR");

	/** The code. */
	private String code = null;
	
	private ExternalSystemOriginCodeEnum(String aCode){
		this.code = aCode;
	}


	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the agreement follow up status enum
	 */
	public static ExternalSystemOriginCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (ExternalSystemOriginCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
