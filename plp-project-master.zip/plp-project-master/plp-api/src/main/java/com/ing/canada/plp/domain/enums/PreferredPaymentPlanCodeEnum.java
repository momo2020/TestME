/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum PreferredPaymentPlanCodeEnum.
 * 
 */
public enum PreferredPaymentPlanCodeEnum {
	//Monthly withdrawal from banking account
	PRE_AUTHORIZED_CHEQUE_PLAN("A"), 
	//Payment in full by credit card
	CASH_AND_INSTRUMENTS("B"), 
	//Monthly withdrawal from credit card
	CREDIT_CARD_MONTHLY("E");

	/**
	 * Instantiates a new preferred payment plan code enum.
	 * 
	 * @param aCode the a code
	 */
	private PreferredPaymentPlanCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the preferred payment plan code enum
	 */
	public static PreferredPaymentPlanCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (PreferredPaymentPlanCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
