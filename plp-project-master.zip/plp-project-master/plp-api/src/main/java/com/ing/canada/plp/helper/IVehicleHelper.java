/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import java.util.List;
import java.util.Set;

import com.ing.canada.plp.domain.enums.ActionTakenCodeEnum;
import com.ing.canada.plp.domain.enums.DeviceCategoryCodeEnum;
import com.ing.canada.plp.domain.enums.DeviceModelCodeEnum;
import com.ing.canada.plp.domain.enums.DriverTypeCodeEnum;
import com.ing.canada.plp.domain.enums.EquipmentTypeCodeEnum;
import com.ing.canada.plp.domain.enums.OwnerTypeCodeEnum;
import com.ing.canada.plp.domain.enums.PartyRoleInRiskTypeCodeEnum;
import com.ing.canada.plp.domain.enums.UseOfVehicleCategoryCodeEnum;
import com.ing.canada.plp.domain.enums.UseOfVehicleCodeEnum;
import com.ing.canada.plp.domain.enums.VehicleModificationTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.party.PartyRoleInRisk;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;
import com.ing.canada.plp.domain.vehicle.AntiTheftDevice;
import com.ing.canada.plp.domain.vehicle.Vehicle;
import com.ing.canada.plp.domain.vehicle.VehicleEquipment;
import com.ing.canada.plp.domain.vehicle.VehicleModification;

/**
 * Vehicle Helper interface.
 * 
 * <p>
 * This is to help by having a helper to facilitate by retrieving pertaining vehicle object models.
 * </p>
 * 
 * @author rassaad
 */
public interface IVehicleHelper {
	/**
	 * Get the list of party role in risk from a vehicle.
	 * 
	 * @param aVehicle The {@link Vehicle}.
	 * 
	 * @return Set {@link PartyRoleInRisk} The list of party role in risk.
	 */
	Set<PartyRoleInRisk> getPartyRoleInRiskList(Vehicle aVehicle);

	/**
	 * Get the driver from a vehicle given a type.
	 * 
	 * @param aVehicle The {@link Vehicle}.
	 * @param aDriverType The {@link DriverTypeCodeEnum}.
	 * 
	 * @return The driver encapsulated in PartyRoleInRisk object
	 */
	PartyRoleInRisk getDriverOfType(Vehicle aVehicle, DriverTypeCodeEnum aDriverType);

	/**
	 * Gets the drivers from a vehicle given a type.
	 * 
	 * @param aVehicle The {@link Vehicle}.
	 * @param aDriverType The {@link DriverTypeCodeEnum}.
	 * @return The list of drivers encapsulated in PartyRoleInRisk object
	 */
	List<PartyRoleInRisk> getDriversOfType(Vehicle aVehicle, DriverTypeCodeEnum aDriverType);

	/**
	 * Get the owner from a vehicle given a type.
	 * 
	 * @param aVehicle The {@link Vehicle}.
	 * @param aOwnerType The {@link OwnerTypeCodeEnum}.
	 * 
	 * @return The owner encapsulated in PartyRoleInRisk object
	 */
	PartyRoleInRisk getOwnerOfType(Vehicle aVehicle, OwnerTypeCodeEnum aOwnerType);

	/**
	 * Get the registered owner from a vehicle.
	 * 
	 * @param aVehicle The {@link Vehicle}.
	 * 
	 * @return The registered owner encapsulated in PartyRoleInRisk object
	 */
	PartyRoleInRisk getRegisteredOwner(Vehicle aVehicle);

	/**
	 * Get the owner from a vehicle.
	 * 
	 * @param aVehicle The {@link Vehicle}.
	 * @param aType The {@link PartyRoleInRiskTypeCodeEnum}.
	 * 
	 * @return The PartyRoleInRisk of the owner.
	 */
	PartyRoleInRisk getPartyRoleInRiskOfType(Vehicle aVehicle, PartyRoleInRiskTypeCodeEnum aType);

	/**
	 * Get the principal driver from a vehicle .
	 * 
	 * @param aVehicle The {@link Vehicle}.
	 * 
	 * @return The {@link PartyRoleInRisk} that the principal driver encapsulated in PartyRoleInRisk object.
	 */
	PartyRoleInRisk getPrincipalDriver(Vehicle aVehicle);

	/**
	 * Get the principal driver from a risk .
	 * 
	 * @param aRisk The {@link Risk}.
	 * 
	 * @return The {@link PartyRoleInRisk} that the principal driver encapsulated in PartyRoleInRisk object.
	 */
	PartyRoleInRisk getPrincipalDriver(InsuranceRisk aRisk);

	/**
	 * Retrieve the appopriate use of vehicle from the use of vehicle category.
	 * 
	 * @param useOfVehicleCategory The {@link UseOfVehicleCategoryCodeEnum}.
	 * @return A {@link UseOfVehicleCodeEnum}.
	 */
	UseOfVehicleCodeEnum retrieveUseOfVehicle(UseOfVehicleCategoryCodeEnum useOfVehicleCategory);

	/**
	 * Retrieve the appropriate use of vehicle category from the use of vehicle.
	 * 
	 * @param useOfVehicle the use of vehicle
	 * 
	 * @return A {@link UseOfVehicleCategoryCodeEnum}.
	 */
	UseOfVehicleCategoryCodeEnum retrieveUseOfVehicleCategory(UseOfVehicleCodeEnum useOfVehicle);

	/**
	 * Gets the vehicle equipment based on a specific equipment type.
	 * 
	 * @param aEquipmentType the a equipment type
	 * @param aVehicle the a vehicle
	 * 
	 * @return the vehicle equipment
	 */
	VehicleEquipment getVehicleEquipment(Vehicle aVehicle, EquipmentTypeCodeEnum aEquipmentType);

	/**
	 * Gets the vehicle modification based on a specific modification type.
	 * 
	 * @param aModificationType the a modification type
	 * @param aVehicle the a vehicle
	 * 
	 * @return the vehicle modification
	 */
	VehicleModification getVehicleModification(Vehicle aVehicle, VehicleModificationTypeCodeEnum aModificationType);

	/**
	 * Calculated field, set Vehicle age.
	 * 
	 * @param aVehicle the Vehicle
	 */
	void setVehicleAge(Vehicle aVehicle);

	/**
	 * Retrieve anti theft device to update it later on.
	 * 
	 * @param antiTheftDeviceSet the anti theft device set
	 * @param deviceCategoryCodeSelected the device category code selected
	 * 
	 * @return the anti theft device
	 */
	AntiTheftDevice retrieveAntiTheftDevice(Set<AntiTheftDevice> antiTheftDeviceSet,
			DeviceCategoryCodeEnum deviceCategoryCodeSelected);

	/**
	 * Adds, update or delete an anto theft device.
	 * 
	 * @param aVehicle the a vehicle
	 * @param deviceModelCodeSelected the device model code selected
	 * @param isSelected the is selected
	 * @param aDeviceCategoryCode the a device category code
	 */
	void setAntiTheftDevice(Vehicle aVehicle, Boolean isSelected, DeviceModelCodeEnum deviceModelCodeSelected,
			DeviceCategoryCodeEnum aDeviceCategoryCode);
	
	/**
	 * Initialize a new vehicle.
	 *
	 * @param aPolicyVersion {@link PolicyVersion}
	 * @return {@link Vehicle}
	 */
	Vehicle initNewVehicle(final PolicyVersion aPolicyVersion);

	/**
	 * Check if there is at least one vehicle eligible to UBI
	 * 
	 * @param aPolicyVersionId
	 * @return
	 */
	boolean hasUBIQualifiedVehicles(Long aPolicyVersionId);

	/**
	 * Get all vehicles from policy
	 * 
	 * @param pv
	 * @return
	 */
	List<Vehicle> getVehicles(PolicyVersion pv);

	/**
	 * Set antiTheftDevice with action taken
	 * @param aVehicle
	 * @param isSelected
	 * @param deviceModelCodeSelected
	 * @param aDeviceCategoryCode
	 * @param anActionTaken
	 */
	void setAntiTheftDevice(Vehicle aVehicle, Boolean isSelected, DeviceModelCodeEnum deviceModelCodeSelected,
			DeviceCategoryCodeEnum aDeviceCategoryCode, ActionTakenCodeEnum anActionTaken);
}
