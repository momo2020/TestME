/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.usertype;

/**
 * The Interface Expirable.
 */
public interface Expirable {

	/**
	 * Gets the expiration details.
	 * 
	 * @return the expiration details
	 */
	ExpirationDetails getExpirationDetails();

	/**
	 * Sets the expiration details.
	 * 
	 * @param expirationDetails the new expiration details
	 */
	void setExpirationDetails(ExpirationDetails expirationDetails);

}
