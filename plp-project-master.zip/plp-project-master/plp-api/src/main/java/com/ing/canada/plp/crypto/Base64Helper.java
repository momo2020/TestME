/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.crypto;

/**
 * Set of static methods to encode bytes to and decode bytes from base 64 string. Note that base 64 string has a length
 * that is always a multiple of 4. So it is often padded to the nearest multiple of 4 with "=" characters.<br>
 * <b>Encoded data length:</b> <br>
 * <code>encodedLength = ceiling(decodedLength / 3) * 4</code> <br>
 * <b>Examples of decoded length and matching encoded lengths:</b> <br>
 * <code>
 * Decoded   Encoded
 *    0         0
 *    1         4
 *    2         4
 *    3         4
 *    4         8
 *    5         8
 * </code>
 * 
 * @author Simon Legault
 */
public abstract class Base64Helper {

	// To be retested if we ever use this part of the code
	// Sun's Base64 codecs are not supported. Use Apache Commons Codec instead.
	private static final sun.misc.BASE64Encoder encoder = new sun.misc.BASE64Encoder();

	private static final sun.misc.BASE64Decoder decoder = new sun.misc.BASE64Decoder();

	/**
	 * Utility classes doesn't have a public constructor
	 */
	private Base64Helper() {
		// no-op
	}

	/** Decodes <code>data</code> Base 64 string into a byte array. */
	public static byte[] base64ToBytes(String data) throws Exception {
		byte[] result = decoder.decodeBuffer(data);
		return result;
	}

	/** Encodes <code>data</code> byte array into a Base 64 string. */
	public static String bytesToBase64(byte[] data) {
		String result = encoder.encode(data);
		return result;
	}

}
