/**
 * 
 */
package com.ing.canada.plp.domain.businesstransaction;

import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.BusinessTransactionSubActivityCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * BusinessTransactionSubActivity entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "BUSINESS_TRX_SUB_ACTIVITY", uniqueConstraints = { @UniqueConstraint(columnNames = { "BUSINESS_TRX_SUB_ACTIVITY_ID" }) })
@NamedQueries( {
		@NamedQuery(name = "BusinessTransactionSubActivity.findDateOfFirstTransactionSubActivity", query = "select min(btsa.auditTrail.createTimestamp) from BusinessTransaction bt inner join bt.businessTransactionActivities bta inner join bta.businessTransactionSubActivities btsa where bt.id = :businessTransactionId and btsa.subActivityCode = :businessTrxSubActivityCode"),
		@NamedQuery(name = "BusinessTransactionSubActivity.findLastSubActivityComplementInfo", query = "select complementInfo from BusinessTransactionSubActivityComplementInfo complementInfo where complementInfo.auditTrail.createTimestamp = (select max(ci.auditTrail.createTimestamp) from BusinessTransactionActivity bta join bta.businessTransactionSubActivities btsa join btsa.businessTransactionSubActivityComplementInfos ci where bta.id = :businessTransactionActivityId)"),
		@NamedQuery(name = "BusinessTransactionSubActivity.retrieveAllSubActivityForPolicyVersion", query = "select bsa from BusinessTransaction bt inner join bt.businessTransactionActivities ba inner join ba.businessTransactionSubActivities bsa where bt = :businessTransaction order by bsa.auditTrail.createTimestamp ASC" ),
		@NamedQuery(name = "BusinessTransactionSubActivity.countNumberOfSubActivityUnderInsuranceOffer", query = "select count(*) from BusinessTransactionSubActivity bsa, InsuranceRiskOffer iro where iro = :insuranceRiskOffer and bsa.rootReferenceId = iro.id and bsa.subActivityCode = 'MOD_COV'"),
		@NamedQuery(name = "BusinessTransactionSubActivity.findLastSubActivity",
				query = "from BusinessTransactionSubActivity last " +
						"where last.auditTrail.createTimestamp = " +
						"(select max(btsa.auditTrail.createTimestamp) from BusinessTransactionSubActivity btsa " +
						"where btsa.businessTransactionActivity.businessTransaction.id = :businessTrxId)" +
						"and last.businessTransactionActivity.businessTransaction.id = :businessTrxId"),
		@NamedQuery(name = "BusinessTransactionSubActivity.findLastSubActivityWithCode",
				query = "from BusinessTransactionSubActivity last " +
						"where last.auditTrail.createTimestamp = " +
						"(select max(btsa.auditTrail.createTimestamp) from BusinessTransactionSubActivity btsa " +
						"where btsa.subActivityCode in (:subActivityCodeList) " +
						"and btsa.businessTransactionActivity.businessTransaction.id = :businessTrxId)" +
						"and last.businessTransactionActivity.businessTransaction.id = :businessTrxId"), 
		
		@NamedQuery(name = "BusinessTransactionSubActivity.findInfoForVehicleRootReference", query = "select new com.ing.canada.plp.domain.VehicleInfo(veh.id, vdsre.vehicleYear, vre.vehicleModelEnglish, vre.vehicleModelFrench, vre.vehicleMakeEnglish, vre.vehicleMakeFrench, ir.insuranceRiskSequence) from InsuranceRisk ir inner join ir.vehicle as veh inner join veh.vehicleDetailSpecificationRepositoryEntry as vdsre inner join vdsre.vehicleRepositoryEntry as vre where ir.id = :rootReferenceId" ),
		@NamedQuery(name = "BusinessTransactionSubActivity.findAllSubActivityWithCodeAndReferenceId", query = "from BusinessTransactionSubActivity bsa where bsa.rootReferenceId = :rootReferenceId and bsa.subActivityCode = :subActivityCode" ),
		@NamedQuery(name = "BusinessTransactionSubActivity.findInfoForDriverRootReference", query = "select new com.ing.canada.plp.domain.DriverInfo(p.id, p.firstName, p.lastName, p.middleName, p.suffixName, dci.driverSequence, p.birthDate, p.actionTaken, p.roadBlockIndicator) from Party p inner join p.driverComplementInfo as dci where p.id = :rootReferenceId"),
		@NamedQuery(name = "BusinessTransactionSubActivity.findInfoForCoverageRootReference", query = "select new com.ing.canada.plp.domain.VehicleInfo(veh.id, vdsre.vehicleYear, vre.vehicleModelEnglish, vre.vehicleModelFrench, vre.vehicleMakeEnglish, vre.vehicleMakeFrench, ir.insuranceRiskSequence) from InsuranceRiskOffer as iro inner join iro.insuranceRisk as ir inner join ir.vehicle as veh inner join veh.vehicleDetailSpecificationRepositoryEntry as vdsre inner join vdsre.vehicleRepositoryEntry as vre where iro.id = :rootReferenceId") 
		
})
public class BusinessTransactionSubActivity extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "BUSINESS_TRX_SUB_ACTIVITY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "BusinessTransactionSubActivitySequence")
	@SequenceGenerator(name = "BusinessTransactionSubActivitySequence", sequenceName = "BUSINESS_TRX_SUB_ACTIVITY_SEQ", allocationSize = 5)
	private Long id = null;

	/** The business transaction activity. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "BUSINESS_TRX_ACTIVITY_ID", nullable = false, updatable = true)
	private BusinessTransactionActivity businessTransactionActivity = null;

	/** The sub activity code. */
	@Column(name = "BUSINESS_TRX_SUB_ACTIVITY_CD", nullable = false, length = 18)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.BusinessTransactionSubActivityCodeEnum") })
	private BusinessTransactionSubActivityCodeEnum subActivityCode = null;

	/** The business transaction sub activity complement infos. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "businessTransactionSubActivity")
	private Set<BusinessTransactionSubActivityComplementInfo> businessTransactionSubActivityComplementInfos = new HashSet<BusinessTransactionSubActivityComplementInfo>();

	/** The root reference id. The id of the modified object */
	@Column(name = "ROOT_REFERENCE_ID", precision = 12, scale = 0)
	private Long rootReferenceId;

	/** The system date time. */
	@Column(name = "SYSTEM_CREATE_TS", length = 11, insertable = false, updatable = false)
	protected Date systemDateTime;

	/** 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * gets the parent business transaction activity.
	 * 
	 * @return the parent business transactoin activity
	 */
	@XmlTransient // parent
	public BusinessTransactionActivity getBusinessTransactionActivity() {
		return this.businessTransactionActivity;
	}

	/**
	 * Sets the business transaction activity.
	 * 
	 * @param aBusinessTransactionActivity the a business transaction activity
	 * 
	 * @see AssociationsHelper#updateOneToManyFields(Object, String, Object, String)
	 */
	public void setBusinessTransactionActivity(BusinessTransactionActivity aBusinessTransactionActivity) {
		AssociationsHelper.updateOneToManyFields(aBusinessTransactionActivity, "businessTransactionSubActivities",
				this, "businessTransactionActivity");
	}

	/**
	 * gets the business transaction sub activity code.
	 * 
	 * @return the sub activity code
	 */
	public BusinessTransactionSubActivityCodeEnum getSubActivityCode() {
		return this.subActivityCode;
	}

	/**
	 * sets the business transaction sub activity code.
	 * 
	 * @param aSubActivity the a sub activity
	 */
	public void setSubActivityCode(BusinessTransactionSubActivityCodeEnum aSubActivity) {
		this.subActivityCode = aSubActivity;
	}

	/**
	 * Gets the business transaction sub activity complement infos.
	 * 
	 * @return the business transaction sub activity complement infos
	 */
	@XmlElementWrapper(name="businessTransactionSubActivityComplementInfos")
	@XmlElement(name="businessTransactionSubActivityComplementInfo")
	public Set<BusinessTransactionSubActivityComplementInfo> getBusinessTransactionSubActivityComplementInfos() {
		return Collections.unmodifiableSet(this.businessTransactionSubActivityComplementInfos);
	}

	/**
	 * Sets the business transaction sub activity complement infos.
	 * 
	 * @param aBusinessTransactionSubActivityComplementInfos the new business transaction sub activity complement infos
	 */
	protected void setBusinessTransactionSubActivityComplementInfos(
			Set<BusinessTransactionSubActivityComplementInfo> aBusinessTransactionSubActivityComplementInfos) {
		this.businessTransactionSubActivityComplementInfos = aBusinessTransactionSubActivityComplementInfos;
	}

	/**
	 * Adds the business transaction sub activity complement info.
	 * 
	 * @param msg the msg
	 */
	public void addBusinessTransactionSubActivityComplementInfo(BusinessTransactionSubActivityComplementInfo msg) {
		AssociationsHelper.updateOneToManyFields(this, "businessTransactionSubActivityComplementInfos", msg,
				"businessTransactionSubActivity");
	}

	/**
	 * Removes the business transaction sub activity complement info.
	 * 
	 * @param msg the msg
	 */
	public void removeBusinessTransactionSubActivityComplementInfo(BusinessTransactionSubActivityComplementInfo msg) {
		AssociationsHelper.updateOneToManyFields(null, "businessTransactionSubActivityComplementInfos", msg,
				"businessTransactionSubActivity");
	}

	/**
	 * Gets the root reference id.
	 * 
	 * @return the root reference id
	 */
	public Long getRootReferenceId() {
		return this.rootReferenceId;
	}

	/**
	 * Sets the root reference id.
	 * 
	 * @param aRootReferenceId the new root reference id
	 */
	public void setRootReferenceId(Long aRootReferenceId) {
		this.rootReferenceId = aRootReferenceId;
	}

	/**
	 * Gets the system date time.
	 * 
	 * @return the system date time
	 */
	public Date getSystemDateTime() {
		return this.systemDateTime;
	}

	/**
	 * Sets the system date time.
	 * 
	 * @param aSystemDateTime the new system date time
	 */
	public void setSystemDateTime(Date aSystemDateTime) {
		this.systemDateTime = aSystemDateTime;
	}

}
