/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.service;

import java.util.List;

import com.ing.canada.plp.domain.partnership.Partnership;
import com.ing.canada.plp.domain.party.Party;

/**
 * This interface exposes services required to manage Partnership related entities.
 * 
 * @author pmdroz
 */
public interface IPartnershipService extends ICRUDService<Partnership> {
	
	/**
	 * Find partnership associated to Advisor
	 * 
	 * @param advisor
	 *            {@link Party}
	 * @return List<Partnership>
	 */
	List<Partnership> findPartnership(Party advisor);
}
