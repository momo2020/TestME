/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import java.util.Set;

import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.Claim;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.insurancerisk.KindOfLoss;

/**
 * Contains helper methods to deal with KindOfLoss .
 * 
 * @author R�gis Brochu
 */
public interface IClaimHelper {

	/**
	 * Determines if the Claim is at fault
	 * 
	 * @param aClaim the Claim to check
	 * @param aProvince the Province
	 * @return if the Claim is at fault
	 */
	boolean isClaimAtFault(Claim aClaim, ProvinceCodeEnum aProvince);

	/**
	 * Gets the claims sorted by date of loss (newest to oldest).
	 * 
	 * @param insuranceRisk the insurance risk
	 * 
	 * @return the sorted claim Set
	 */
	Set<Claim> getSortedClaim(InsuranceRisk insuranceRisk);
	
	/**
	 * Gets the sorted KindOfLoss.
	 * 
	 * @param claim the claim
	 * 
	 * @return the sorted KindOfLoss Set
	 */
	Set<KindOfLoss> getSortedKindOfLoss(Claim claim);

}
