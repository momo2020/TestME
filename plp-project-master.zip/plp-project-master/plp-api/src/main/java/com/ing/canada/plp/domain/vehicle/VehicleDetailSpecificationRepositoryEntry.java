/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.vehicle;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.ManufacturingContext;
import com.ing.canada.plp.domain.enums.AntiTheftDeviceRequiredCodeEnum;
import com.ing.canada.plp.domain.enums.LanguageCodeEnum;
import com.ing.canada.plp.domain.enums.VehicleCategoryCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * VehicleDetailSpecificationRepositoryEntry entity.
 * 
 * @author Patrick Lafleur
 * 
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "VEH_DETAIL_SPEC_REP_ENTRY", uniqueConstraints = {})
public class VehicleDetailSpecificationRepositoryEntry extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "VEH_DETAIL_SPEC_REP_ENTRY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "VehicleDetailSpecRepositoryEntrySequence")
	@SequenceGenerator(name = "VehicleDetailSpecRepositoryEntrySequence", sequenceName = "VEH_DETAIL_SPEC_REP_ENTRY_SEQ", allocationSize = 5)
	private Long id;

	/** The manufacturing context. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "MANUFACTURING_CONTEXT_ID", updatable = true)
	private ManufacturingContext manufacturingContext;

	/** The vehicle repository entry. */
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
	@JoinColumn(name = "VEHICLE_REPOSITORY_ENTRY_ID", nullable = false, updatable = true)
	private VehicleRepositoryEntry vehicleRepositoryEntry;

	/** The vehicle year. */
	@Column(name = "VEHICLE_YR", nullable = true, length = 4)
	private Integer vehicleYear;

	/** The vehicle category. */
	@Column(name = "VEHICLE_CATEGORY_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.VehicleCategoryCodeEnum") })
	private VehicleCategoryCodeEnum vehicleCategory;

	/** The restricted vehicle. */
	@Column(name = "RESTRICTED_VEHICLE_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean restrictedVehicleIndicator;

	/** The replacement cost indicator. */
	@Column(name = "REPLACEMENT_COST_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean replacementCostIndicator;

	/** The commercial class eligibility indicator. */
	@Column(name = "COMMERCIAL_CLASS_ELGBLTY_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean commercialClassEligibilityIndicator;

	/** The facility risk sharing pool scoring. */
	@Column(name = "FACILITY_RSP_SCORING_QTY", precision = 3, scale = 0)
	private Short facilityRiskSharingPoolScoring;

	/** The rsp adjustment scenario vehicle new business. */
	@Column(name = "RSP_ADJ_SCENARIO_VEH_NEW_B_QTY", precision = 2, scale = 0)
	private Byte rspAdjustmentScenarioVehicleNewBusiness;

	/** The rsp adjustment scenario vehicle standard. */
	@Column(name = "RSP_ADJ_SCENARIO_VEH_STD_QTY", precision = 2, scale = 0)
	private Byte rspAdjustmentScenarioVehicleStandard;

	/** The rate group clear liability. */
	@Column(name = "RATE_GROUP_CLR_LIABILITY_CD", length = 2)
	private String rateGroupClearLiability;

	/** The rate group clear accident benefit. */
	@Column(name = "RATE_GROUP_CLR_ACDNT_BNFT_CD", length = 2)
	private String rateGroupClearAccidentBenefit;

	/** The rate group clear collision. */
	@Column(name = "RATE_GROUP_CLR_COLLISION_CD", length = 2)
	private String rateGroupClearCollision;

	/** The rate group clear combined. */
	@Column(name = "RATE_GROUP_CLR_COMBINED_CD", length = 2)
	private String rateGroupClearCombined;

	/** The rate group clear comprehensive. */
	@Column(name = "RATE_GROUP_CLR_COMP_CD", length = 2)
	private String rateGroupClearComprehensive;

	/** The rate group clear dcpd. */
	@Column(name = "RATE_GROUP_CLR_DCPD_CD", length = 2)
	private String rateGroupClearDcpd;

	/** The rate group msrp. */
	@Column(name = "RATE_GROUP_MSRP_CD", length = 2)
	private String rateGroupMsrp;

	/** The rate group mod clear combined. */
	@Column(name = "RATE_GROUP_MOD_CLR_COMBINED_CD", length = 2)
	private String rateGroupModClearCombined;

	/** The rate group mod clear combined new business. */
	@Column(name = "RATE_GROUP_MOD_CLR_CMBND_NB_CD", length = 2)
	private String rateGroupModClearCombinedNewBusiness;

	/** The anti theft device required. */
	@Column(name = "ANTI_THEFT_DEVICE_REQUIRED_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.AntiTheftDeviceRequiredCodeEnum") })
	private AntiTheftDeviceRequiredCodeEnum antiTheftDeviceRequired;

	/** The number of cylinders. */
	@Column(name = "NBR_OF_CYLINDERS_QTY", precision = 2, scale = 0)
	private Byte numberOfCylinders;

	/** The minimum deductible mandatory ind b3 b4. */
	@Column(name = "MIN_DEDUCTIBLE_MNDTRY_B3B4_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean minimumDeductibleMandatoryIndB3B4Indicator;

	/** The minimum deductible mandatory ind c2 c3. */
	@Column(name = "MIN_DEDUCTIBLE_MNDTRY_C2C3_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean minimumDeductibleMandatoryIndC2C3Indicator;

	/** The vehicle inspection ind. */
	@Column(name = "VEHICLE_INSPECTION_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean vehicleInspectionIndicator;

	/** The effective date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DT", length = 7)
	private Date effectiveDate;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;

	/** Horsepower */
	@Column(name = "HORSEPOWER_QTY", precision = 3, scale = 0)
	private Short horsePower;

	/** Retail price with taxes */
	@Column(name = "RETAIL_PRICE_WITH_GST_AMT", precision = 6, scale = 0)
	private Integer retailPriceWithGst;

	/** (4.1.7) Wheel base quantity */
	@Column(name = "WHEELBASE_QTY", precision = 4, scale = 0)
	private Integer wheelbaseQty;

	/** (4.1.7) Airbags code */
	@Column(name = "AIRBAGS_CD", length = 1)
	private String airbagsCd;

	/** (4.1.7) ABS brakes code */
	@Column(name = "ABS_BRAKES_CD", length = 1)
	private String absBrakesCd;

	/** (4.1.7) Audbile alarm code */
	@Column(name = "AUDIBLE_ALARM_CD", length = 1)
	private String audibleAlarmCd;

	/** (4.1.7) Cutoff system code */
	@Column(name = "CUT_OFF_SYSTEM_CD", length = 1)
	private String cutOffSystemCd;

	/** (4.1.7) Security key system code */
	@Column(name = "SECURITY_KEY_SYSTEM_CD", length = 1)
	private String securityKeySystemCd;

	/** (4.1.7) IBC approved code */
	@Column(name = "IBC_APPROVED_CD", length = 1)
	private String ibcApprovedCd;

	/** (4.1.7) Engine cylinder code */
	@Column(name = "ENGINE_CYLINDER_CD", length = 2)
	private String engineCylinderCd;

	/** (4.1.7) IBC market code */
	@Column(name = "IBC_MARKET_CD", length = 2)
	private String ibcMarketCd;

	/** (4.1.7) Vehicle size code */
	@Column(name = "VEHICLE_SIZE_CD", length = 1)
	private String vehicleSizeCd;

	/** (4.1.7) Vehicle generation code */
	@Column(name = "VEHICLE_GENERATION_CD", length = 1)
	private String vehicleGenerationCd;

	/** (4.1.7) Fuel used by vehicle code */
	@Column(name = "FUEL_USED_BY_VEHICLE_CD", length = 1)
	private String fuelUsedByVehicleCd;

	/** (4.1.7) Engine force induction code */
	@Column(name = "ENGINE_FORCE_INDUCTION_CD", length = 1)
	private String engineForceInductionCd;

	/** (4.1.7) Engine hybrid code */
	@Column(name = "ENGINE_HYBRID_CD", length = 1)
	private String engineHybridCd;

	/** (4.1.7) Traction control code */
	@Column(name = "TRACTION_CONTROL_CD", length = 1)
	private String tractionControlCd;

	/** (4.1.7) Stability control code */
	@Column(name = "STABILITY_CONTROL_CD", length = 1)
	private String stabitlityControlCd;

	/** (4.1.7) Drive train code */
	@Column(name = "DRIVE_TRAIN_CD", length = 3)
	private String driveTrainCd;

	/**
	 * (4.2.2) Code from VICC used for the rating of the vehicle Accident Benefit. <br>
	 * The vehicle rate group is set according to the year and code of the vehicle for a private passenger automobile<br>
	 * - for commercial vehicles, the value and year of the vehicle determine the vehicle rate group.<br>
	 *  <br>
	 *  Valid Values: See VICC table <br>
	 */
	@Column(name = "RATE_GROUP_ACDNT_BNFT_VICC_CD", length = 2)
	private String rateGroupAccidentBenefitVicc;
	
	/**
	 * (4.2.2) Code from VICC used for the rating of the vehicle Collision.<br>
	 * The vehicle rate group is set according to the year and code of the vehicle for a private passenger automobile <br>
	 * - for commercial vehicles, the value and year of the vehicle determine the vehicle rate group.<br>
	 * <br>
	 * Valid Values: See VICC table <br>
	 */
	@Column(name = "RATE_GROUP_COLLISION_VICC_CD", length = 2)
	private String rateGroupCollisionVicc;
	
	/**
	 * (4.2.2) Code from VICC used for the rating of the vehicle Comprehensive. <br>
	 * The vehicle rate group is set according to the year and code of the vehicle for a private passenger automobile <br>
	 * - for commercial vehicles, the value and year of the vehicle determine the vehicle rate group. <br>
	 * <br>
	 * Valid Values: See VICC table <br>
	 */
	@Column(name = "RATE_GROUP_COMP_VICC_CD", length = 2)
	private String rateGroupComprehensiveVicc;
	
	/**
	 * (4.2.2) Code from VICC used for the rating of the vehicle Liability Property Damage. <br>
	 * The vehicle rate group is set according to the year and code of the vehicle for a private passenger automobile <br>
	 * - for commercial vehicles, the value and year of the vehicle determine the vehicle rate group. <br>
	 * <br>
	 * Valid Values: See VICC table <br>
	 */
	@Column(name = "RATE_GROUP_LIA_PRP_DAM_VICC_CD", length = 2)
	private String rateGroupLiabilityPropertyDamageVicc;
	
	public Short getHorsePower() {
		return this.horsePower;
	}

	public void setHorsePower(Short aHorsePower) {
		this.horsePower = aHorsePower;
	}

	public Integer getRetailPriceWithGst() {
		return this.retailPriceWithGst;
	}

	public void setRetailPriceWithGst(Integer aRetailPriceWithGst) {
		this.retailPriceWithGst = aRetailPriceWithGst;
	}

	/**
	 * Instantiates a new vehicle detail spec repository entry.
	 */
	public VehicleDetailSpecificationRepositoryEntry() {
		// noarg constructor
	}

	/**
	 * Instantiates a new vehicle detail spec repository entry.
	 * 
	 * @param aVehicleRepositoryEntry the a vehicle repository entry
	 */
	public VehicleDetailSpecificationRepositoryEntry(VehicleRepositoryEntry aVehicleRepositoryEntry) {
		this.setVehicleRepositoryEntry(aVehicleRepositoryEntry);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the manufacturing context.
	 * 
	 * @return the manufacturing context
	 */
	public ManufacturingContext getManufacturingContext() {
		return this.manufacturingContext;
	}

	/**
	 * Sets the manufacturing context.
	 * 
	 * @param aManufacturingContext the new manufacturing context
	 */
	public void setManufacturingContext(ManufacturingContext aManufacturingContext) {
		this.manufacturingContext = aManufacturingContext;
	}

	/**
	 * Gets the vehicle repository entry.
	 * 
	 * @return the vehicle repository entry
	 */
	public VehicleRepositoryEntry getVehicleRepositoryEntry() {
		return this.vehicleRepositoryEntry;
	}

	/**
	 * Sets the vehicle repository entry.
	 * 
	 * @param aVehicleRepositoryEntry the new vehicle repository entry
	 */
	public void setVehicleRepositoryEntry(VehicleRepositoryEntry aVehicleRepositoryEntry) {
		AssociationsHelper.updateOneToManyFields(aVehicleRepositoryEntry, "vehicleDetailSpecificationRepositoryEntries", this, "vehicleRepositoryEntry");
	}

	/**
	 * Gets the vehicle year.
	 * 
	 * @return the vehicle year
	 */
	public Integer getVehicleYear() {
		return this.vehicleYear;
	}

	/**
	 * Sets the vehicle year.
	 * 
	 * @param vehicleYr the new vehicle year
	 */
	public void setVehicleYear(Integer vehicleYr) {
		this.vehicleYear = vehicleYr;
	}

	/**
	 * Gets the vehicle category.
	 * 
	 * @return the vehicle category
	 */
	public VehicleCategoryCodeEnum getVehicleCategory() {
		return this.vehicleCategory;
	}

	/**
	 * Sets the vehicle category.
	 * 
	 * @param vehicleCategoryCode the new vehicle category
	 */
	public void setVehicleCategory(VehicleCategoryCodeEnum vehicleCategoryCode) {
		this.vehicleCategory = vehicleCategoryCode;
	}

	/**
	 * Gets the restricted vehicle.
	 * 
	 * @return the restricted vehicle
	 */
	public Boolean getRestrictedVehicleIndicator() {
		return this.restrictedVehicleIndicator;
	}

	/**
	 * Sets the restricted vehicle.
	 * 
	 * @param aRestrictedVehicleIndicator the new restricted vehicle
	 */
	public void setRestrictedVehicleIndicator(Boolean aRestrictedVehicleIndicator) {
		this.restrictedVehicleIndicator = aRestrictedVehicleIndicator;
	}

	/**
	 * Gets the replacement cost indicator.
	 * 
	 * @return the replacement cost indicator
	 */
	public Boolean getReplacementCostIndicator() {
		return this.replacementCostIndicator;
	}

	/**
	 * Sets the replacement cost indicator.
	 * 
	 * @param aReplacementCostIndicator the new replacement cost indicator
	 */
	public void setReplacementCostIndicator(Boolean aReplacementCostIndicator) {
		this.replacementCostIndicator = aReplacementCostIndicator;
	}

	/**
	 * Gets the commercial class eligibility indicator.
	 * 
	 * @return the commercial class eligibility indicator
	 */
	public Boolean getCommercialClassEligibilityIndicator() {
		return this.commercialClassEligibilityIndicator;
	}

	/**
	 * Sets the commercial class eligibility indicator.
	 * 
	 * @param commercialClassElgbltyIndicator the new commercial class eligibility indicator
	 */
	public void setCommercialClassEligibilityIndicator(Boolean commercialClassElgbltyIndicator) {
		this.commercialClassEligibilityIndicator = commercialClassElgbltyIndicator;
	}

	/**
	 * Gets the facility risk sharing pool scoring.
	 * 
	 * @return the facility risk sharing pool scoring
	 */
	public Short getFacilityRiskSharingPoolScoring() {
		return this.facilityRiskSharingPoolScoring;
	}

	/**
	 * Sets the facility risk sharing pool scoring.
	 * 
	 * @param facilityRspScoring the new facility risk sharing pool scoring
	 */
	public void setFacilityRiskSharingPoolScoring(Short facilityRspScoring) {
		this.facilityRiskSharingPoolScoring = facilityRspScoring;
	}

	/**
	 * Gets the rsp adjustment scenario vehicle new business.
	 * 
	 * @return the rsp adjustment scenario vehicle new business
	 */
	public Byte getRspAdjustmentScenarioVehicleNewBusiness() {
		return this.rspAdjustmentScenarioVehicleNewBusiness;
	}

	/**
	 * Sets the rsp adjustment scenario vehicle new business.
	 * 
	 * @param rspAdjScenarioVehNewB the new rsp adjustment scenario vehicle new business
	 */
	public void setRspAdjustmentScenarioVehicleNewBusiness(Byte rspAdjScenarioVehNewB) {
		this.rspAdjustmentScenarioVehicleNewBusiness = rspAdjScenarioVehNewB;
	}

	/**
	 * Gets the rsp adjustment scenario vehicle standard.
	 * 
	 * @return the rsp adjustment scenario vehicle standard
	 */
	public Byte getRspAdjustmentScenarioVehicleStandard() {
		return this.rspAdjustmentScenarioVehicleStandard;
	}

	/**
	 * Sets the rsp adjustment scenario vehicle standard.
	 * 
	 * @param rspAdjScenarioVehStd the new rsp adjustment scenario vehicle standard
	 */
	public void setRspAdjustmentScenarioVehicleStandard(Byte rspAdjScenarioVehStd) {
		this.rspAdjustmentScenarioVehicleStandard = rspAdjScenarioVehStd;
	}

	/**
	 * Gets the rate group clear liability.
	 * 
	 * @return the rate group clear liability
	 */
	public String getRateGroupClearLiability() {
		return this.rateGroupClearLiability;
	}

	/**
	 * Sets the rate group clear liability.
	 * 
	 * @param rateGroupClrLiabilityCode the new rate group clear liability
	 */
	public void setRateGroupClearLiability(String rateGroupClrLiabilityCode) {
		this.rateGroupClearLiability = rateGroupClrLiabilityCode;
	}

	/**
	 * Gets the rate group clear accident benefit.
	 * 
	 * @return the rate group clear accident benefit
	 */
	public String getRateGroupClearAccidentBenefit() {
		return this.rateGroupClearAccidentBenefit;
	}

	/**
	 * Sets the rate group clear accident benefit.
	 * 
	 * @param rateGroupClrAcdntBnftCode the new rate group clear accident benefit
	 */
	public void setRateGroupClearAccidentBenefit(String rateGroupClrAcdntBnftCode) {
		this.rateGroupClearAccidentBenefit = rateGroupClrAcdntBnftCode;
	}

	/**
	 * Gets the rate group clear collision.
	 * 
	 * @return the rate group clear collision
	 */
	public String getRateGroupClearCollision() {
		return this.rateGroupClearCollision;
	}

	/**
	 * Sets the rate group clear collision.
	 * 
	 * @param rateGroupClrCollisionCode the new rate group clear collision
	 */
	public void setRateGroupClearCollision(String rateGroupClrCollisionCode) {
		this.rateGroupClearCollision = rateGroupClrCollisionCode;
	}

	/**
	 * Gets the rate group clear combined.
	 * 
	 * @return the rate group clear combined
	 */
	public String getRateGroupClearCombined() {
		return this.rateGroupClearCombined;
	}

	/**
	 * Sets the rate group clear combined.
	 * 
	 * @param rateGroupClrCombinedCode the new rate group clear combined
	 */
	public void setRateGroupClearCombined(String rateGroupClrCombinedCode) {
		this.rateGroupClearCombined = rateGroupClrCombinedCode;
	}

	/**
	 * Gets the rate group clear comprehensive.
	 * 
	 * @return the rate group clear comprehensive
	 */
	public String getRateGroupClearComprehensive() {
		return this.rateGroupClearComprehensive;
	}

	/**
	 * Sets the rate group clear comprehensive.
	 * 
	 * @param rateGroupClrCompCode the new rate group clear comprehensive
	 */
	public void setRateGroupClearComprehensive(String rateGroupClrCompCode) {
		this.rateGroupClearComprehensive = rateGroupClrCompCode;
	}

	/**
	 * Gets the rate group clear dcpd.
	 * 
	 * @return the rate group clear dcpd
	 */
	public String getRateGroupClearDcpd() {
		return this.rateGroupClearDcpd;
	}

	/**
	 * Sets the rate group clear dcpd.
	 * 
	 * @param rateGroupClrDcpdCode the new rate group clear dcpd
	 */
	public void setRateGroupClearDcpd(String rateGroupClrDcpdCode) {
		this.rateGroupClearDcpd = rateGroupClrDcpdCode;
	}

	/**
	 * Gets the rate group msrp.
	 * 
	 * @return the rate group msrp
	 */
	public String getRateGroupMsrp() {
		return this.rateGroupMsrp;
	}

	/**
	 * Sets the rate group msrp.
	 * 
	 * @param rateGroupMsrpCode the new rate group msrp
	 */
	public void setRateGroupMsrp(String rateGroupMsrpCode) {
		this.rateGroupMsrp = rateGroupMsrpCode;
	}

	/**
	 * Gets the rate group mod clear combined.
	 * 
	 * @return the rate group mod clear combined
	 */
	public String getRateGroupModClearCombined() {
		return this.rateGroupModClearCombined;
	}

	/**
	 * Sets the rate group mod clear combined.
	 * 
	 * @param rateGroupModClrCombinedCode the new rate group mod clear combined
	 */
	public void setRateGroupModClearCombined(String rateGroupModClrCombinedCode) {
		this.rateGroupModClearCombined = rateGroupModClrCombinedCode;
	}

	/**
	 * Gets the rate group mod clear combined new business.
	 * 
	 * @return the rate group mod clear combined new business
	 */
	public String getRateGroupModClearCombinedNewBusiness() {
		return this.rateGroupModClearCombinedNewBusiness;
	}

	/**
	 * Sets the rate group mod clear combined new business.
	 * 
	 * @param rateGroupModClrCmbndNbCode the new rate group mod clear combined new business
	 */
	public void setRateGroupModClearCombinedNewBusiness(String rateGroupModClrCmbndNbCode) {
		this.rateGroupModClearCombinedNewBusiness = rateGroupModClrCmbndNbCode;
	}

	/**
	 * Gets the anti theft device required.
	 * 
	 * @return the anti theft device required
	 */
	public AntiTheftDeviceRequiredCodeEnum getAntiTheftDeviceRequired() {
		return this.antiTheftDeviceRequired;
	}

	/**
	 * Sets the anti theft device required.
	 * 
	 * @param antiTheftDeviceRequiredCode the new anti theft device required
	 */
	public void setAntiTheftDeviceRequired(AntiTheftDeviceRequiredCodeEnum antiTheftDeviceRequiredCode) {
		this.antiTheftDeviceRequired = antiTheftDeviceRequiredCode;
	}

	/**
	 * Gets the number of cylinders.
	 * 
	 * @return the number of cylinders
	 */
	public Byte getNumberOfCylinders() {
		return this.numberOfCylinders;
	}

	/**
	 * Sets the number of cylinders.
	 * 
	 * @param nbrOfCylinders the new number of cylinders
	 */
	public void setNumberOfCylinders(Byte nbrOfCylinders) {
		this.numberOfCylinders = nbrOfCylinders;
	}

	/**
	 * Gets the minimum deductible mandatory ind b3 b4.
	 * 
	 * @return the minimum deductible mandatory ind b3 b4
	 */
	public Boolean getMinimumDeductibleMandatoryIndB3B4Indicator() {
		return this.minimumDeductibleMandatoryIndB3B4Indicator;
	}

	/**
	 * Sets the minimum deductible mandatory ind b3 b4.
	 * 
	 * @param minDeductibleMndtryB3b4Indicator the new minimum deductible mandatory ind b3 b4
	 */
	public void setMinimumDeductibleMandatoryIndB3B4Indicator(Boolean minDeductibleMndtryB3b4Indicator) {
		this.minimumDeductibleMandatoryIndB3B4Indicator = minDeductibleMndtryB3b4Indicator;
	}

	/**
	 * Gets the minimum deductible mandatory ind c2 c3.
	 * 
	 * @return the minimum deductible mandatory ind c2 c3
	 */
	public Boolean getMinimumDeductibleMandatoryIndC2C3Indicator() {
		return this.minimumDeductibleMandatoryIndC2C3Indicator;
	}

	/**
	 * Sets the minimum deductible mandatory ind c2 c3.
	 * 
	 * @param minDeductibleMndtryC2c3Indicator the new minimum deductible mandatory ind c2 c3
	 */
	public void setMinimumDeductibleMandatoryIndC2C3Indicator(Boolean minDeductibleMndtryC2c3Indicator) {
		this.minimumDeductibleMandatoryIndC2C3Indicator = minDeductibleMndtryC2c3Indicator;
	}

	/**
	 * Gets the vehicle inspection ind.
	 * 
	 * @return the vehicle inspection ind
	 */
	public Boolean getVehicleInspectionIndicator() {
		return this.vehicleInspectionIndicator;
	}

	/**
	 * Sets the vehicle inspection ind.
	 * 
	 * @param aVehicleInspectionIndicator the new vehicle inspection ind
	 */
	public void setVehicleInspectionIndicator(Boolean aVehicleInspectionIndicator) {
		this.vehicleInspectionIndicator = aVehicleInspectionIndicator;
	}

	/**
	 * Gets the effective date.
	 * 
	 * @return the effective date
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * Sets the effective date.
	 * 
	 * @param aEffectiveDate the new effective date
	 */
	public void setEffectiveDate(Date aEffectiveDate) {
		this.effectiveDate = aEffectiveDate;
	}

	/**
	 * Gets the expiry date.
	 * 
	 * @return the expiry date
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * Sets the expiry date.
	 * 
	 * @param aExpiryDate the new expiry date
	 */
	public void setExpiryDate(Date aExpiryDate) {
		this.expiryDate = aExpiryDate;
	}

	/**
	 * Return the model based on the provided language.
	 * 
	 * @param language {@link LanguageCodeEnum}
	 * @return the model
	 */
	public String getModel(LanguageCodeEnum language) {
		String model = null;
		if (language != null) {
			switch (language) {
			case FRENCH:
				model = this.vehicleRepositoryEntry.getVehicleModelFrench();
				break;
			default:
				model = this.vehicleRepositoryEntry.getVehicleModelEnglish();
				break;
			}
		}
		return model;
	}

	/**
	 * Return the make based on the provided language.
	 * 
	 * @param language {@link LanguageCodeEnum}
	 * @return the make
	 */
	public String getMake(LanguageCodeEnum language) {
		String make = null;
		if (language != null) {
			switch (language) {
			case FRENCH:
				make = this.vehicleRepositoryEntry.getVehicleMakeFrench();
				break;
			default:
				make = this.vehicleRepositoryEntry.getVehicleMakeEnglish();
				break;
			}
		}
		return make;
	}

	/**
	 * @return the wheelbaseQty
	 */
	public Integer getWheelbaseQty() {
		return this.wheelbaseQty;
	}

	/**
	 * @param wheelbaseQty the wheelbaseQty to set
	 */
	public void setWheelbaseQty(Integer wheelbaseQty) {
		this.wheelbaseQty = wheelbaseQty;
	}

	/**
	 * @return the airbagsCd
	 */
	public String getAirbagsCd() {
		return this.airbagsCd;
	}

	/**
	 * @param airbagsCd the airbagsCd to set
	 */
	public void setAirbagsCd(String airbagsCd) {
		this.airbagsCd = airbagsCd;
	}

	/**
	 * @return the absBrakesCd
	 */
	public String getAbsBrakesCd() {
		return this.absBrakesCd;
	}

	/**
	 * @param absBrakesCd the absBrakesCd to set
	 */
	public void setAbsBrakesCd(String absBrakesCd) {
		this.absBrakesCd = absBrakesCd;
	}

	/**
	 * @return the audibleAlarmCd
	 */
	public String getAudibleAlarmCd() {
		return this.audibleAlarmCd;
	}

	/**
	 * @param audibleAlarmCd the audibleAlarmCd to set
	 */
	public void setAudibleAlarmCd(String audibleAlarmCd) {
		this.audibleAlarmCd = audibleAlarmCd;
	}

	/**
	 * @return the cutOffSystemCd
	 */
	public String getCutOffSystemCd() {
		return this.cutOffSystemCd;
	}

	/**
	 * @param cutOffSystemCd the cutOffSystemCd to set
	 */
	public void setCutOffSystemCd(String cutOffSystemCd) {
		this.cutOffSystemCd = cutOffSystemCd;
	}

	/**
	 * @return the securityKeySystemCd
	 */
	public String getSecurityKeySystemCd() {
		return this.securityKeySystemCd;
	}

	/**
	 * @param securityKeySystemCd the securityKeySystemCd to set
	 */
	public void setSecurityKeySystemCd(String securityKeySystemCd) {
		this.securityKeySystemCd = securityKeySystemCd;
	}

	/**
	 * @return the ibcApprovedCd
	 */
	public String getIbcApprovedCd() {
		return this.ibcApprovedCd;
	}

	/**
	 * @param ibcApprovedCd the ibcApprovedCd to set
	 */
	public void setIbcApprovedCd(String ibcApprovedCd) {
		this.ibcApprovedCd = ibcApprovedCd;
	}

	/**
	 * @return the engineCylinderCd
	 */
	public String getEngineCylinderCd() {
		return this.engineCylinderCd;
	}

	/**
	 * @param engineCylinderCd the engineCylinderCd to set
	 */
	public void setEngineCylinderCd(String engineCylinderCd) {
		this.engineCylinderCd = engineCylinderCd;
	}

	/**
	 * @return the ibcMarketCd
	 */
	public String getIbcMarketCd() {
		return this.ibcMarketCd;
	}

	/**
	 * @param ibcMarketCd the ibcMarketCd to set
	 */
	public void setIbcMarketCd(String ibcMarketCd) {
		this.ibcMarketCd = ibcMarketCd;
	}

	/**
	 * @return the vehicleSizeCd
	 */
	public String getVehicleSizeCd() {
		return this.vehicleSizeCd;
	}

	/**
	 * @param vehicleSizeCd the vehicleSizeCd to set
	 */
	public void setVehicleSizeCd(String vehicleSizeCd) {
		this.vehicleSizeCd = vehicleSizeCd;
	}

	/**
	 * @return the vehicleGenerationCd
	 */
	public String getVehicleGenerationCd() {
		return this.vehicleGenerationCd;
	}

	/**
	 * @param vehicleGenerationCd the vehicleGenerationCd to set
	 */
	public void setVehicleGenerationCd(String vehicleGenerationCd) {
		this.vehicleGenerationCd = vehicleGenerationCd;
	}

	/**
	 * @return the fuelUsedByVehicleCd
	 */
	public String getFuelUsedByVehicleCd() {
		return this.fuelUsedByVehicleCd;
	}

	/**
	 * @param fuelUsedByVehicleCd the fuelUsedByVehicleCd to set
	 */
	public void setFuelUsedByVehicleCd(String fuelUsedByVehicleCd) {
		this.fuelUsedByVehicleCd = fuelUsedByVehicleCd;
	}

	/**
	 * @return the engineForceInductionCd
	 */
	public String getEngineForceInductionCd() {
		return this.engineForceInductionCd;
	}

	/**
	 * @param engineForceInductionCd the engineForceInductionCd to set
	 */
	public void setEngineForceInductionCd(String engineForceInductionCd) {
		this.engineForceInductionCd = engineForceInductionCd;
	}

	/**
	 * @return the engineHybridCd
	 */
	public String getEngineHybridCd() {
		return this.engineHybridCd;
	}

	/**
	 * @param engineHybridCd the engineHybridCd to set
	 */
	public void setEngineHybridCd(String engineHybridCd) {
		this.engineHybridCd = engineHybridCd;
	}

	/**
	 * @return the tractionControlCd
	 */
	public String getTractionControlCd() {
		return this.tractionControlCd;
	}

	/**
	 * @param tractionControlCd the tractionControlCd to set
	 */
	public void setTractionControlCd(String tractionControlCd) {
		this.tractionControlCd = tractionControlCd;
	}

	/**
	 * @return the stabitlityControlCd
	 */
	public String getStabitlityControlCd() {
		return this.stabitlityControlCd;
	}

	/**
	 * @param stabitlityControlCd the stabitlityControlCd to set
	 */
	public void setStabitlityControlCd(String stabitlityControlCd) {
		this.stabitlityControlCd = stabitlityControlCd;
	}

	/**
	 * @return the driveTrainCd
	 */
	public String getDriveTrainCd() {
		return this.driveTrainCd;
	}

	/**
	 * @param driveTrainCd the driveTrainCd to set
	 */
	public void setDriveTrainCd(String driveTrainCd) {
		this.driveTrainCd = driveTrainCd;
	}

	public String getRateGroupAccidentBenefitVicc() {
		return this.rateGroupAccidentBenefitVicc;
	}

	public void setRateGroupAccidentBenefitVicc(String rateGroupAccidentBenefitVicc) {
		this.rateGroupAccidentBenefitVicc = rateGroupAccidentBenefitVicc;
	}

	public String getRateGroupCollisionVicc() {
		return this.rateGroupCollisionVicc;
	}

	public void setRateGroupCollisionVicc(String rateGroupCollisionVicc) {
		this.rateGroupCollisionVicc = rateGroupCollisionVicc;
	}

	public String getRateGroupComprehensiveVicc() {
		return this.rateGroupComprehensiveVicc;
	}

	public void setRateGroupComprehensiveVicc(String rateGroupComprehensiveVicc) {
		this.rateGroupComprehensiveVicc = rateGroupComprehensiveVicc;
	}

	public String getRateGroupLiabilityPropertyDamageVicc() {
		return this.rateGroupLiabilityPropertyDamageVicc;
	}

	public void setRateGroupLiabilityPropertyDamageVicc(String rateGroupLiabilityPropertyDamageVicc) {
		this.rateGroupLiabilityPropertyDamageVicc = rateGroupLiabilityPropertyDamageVicc;
	}
}
