package com.ing.canada.plp.service.util;

import com.ing.canada.plp.domain.BusinessContext;
import com.ing.canada.plp.domain.ManufacturingContext;
import com.ing.canada.plp.domain.enums.ManufacturerCompanyCodeEnum;

public class UserContextBuilder {
	
	public static UserContext build(String userId, String company){
		UserContext newContext =  new UserContext(userId);
		newContext.setBusinessContext(new BusinessContext());
		newContext.getBusinessContext().setManufacturingContext(new ManufacturingContext());
		newContext.getBusinessContext().getManufacturingContext().setManufacturerCompany(ManufacturerCompanyCodeEnum.valueOfCode(company));
		
		return newContext;
	}

}
