/**
* Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
* without the written permission of Intact Insurance
* Copyright (c) 2017, Intact Insurance, All rights reserved.<br>
*/
package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.insuranceriskoffer.PolicyOfferRating;
import com.ing.canada.plp.domain.policychange.CoverageChange;
import com.ing.canada.plp.exception.PolicyChangeServiceException;

public interface IPolicyChangeService {

	public PolicyOfferRating addCoverage(PolicyOfferRating policy, CoverageChange newChange)
			throws PolicyChangeServiceException;

	public PolicyOfferRating removeCoverage(PolicyOfferRating policy, CoverageChange removeChange)
			throws PolicyChangeServiceException;

	public PolicyOfferRating updateCoverage(PolicyOfferRating policy, CoverageChange newChange)
			throws PolicyChangeServiceException;

}
