/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */

package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * @author mblouin
 *
 */
public enum PriorGridLevelClientCodeEnum {
	
	/** LEVEL 15 */
	LEVEL_15("15"),
	
	/** LEVEL 14 */
	LEVEL_14("14"),

	/** LEVEL 13 */
	LEVEL_13("13"),
	
	/** LEVEL 12 */
	LEVEL_12("12"),
	
	/** LEVEL 11 */
	LEVEL_11("11"),
	
	/** LEVEL 10 */
	LEVEL_10("10"),
	
	/** LEVEL 9 */
	LEVEL_9("9"),
	
	/** LEVEL 8 */
	LEVEL_8("8"),
	
	/** LEVEL 7 */
	LEVEL_7("7"),
	
	/** LEVEL 6 */
	LEVEL_6("6"),
	
	/** LEVEL 5 */
	LEVEL_5("5"),
	
	/** LEVEL 4 */
	LEVEL_4("4"),
	
	/** LEVEL 3 */
	LEVEL_3("3"),
	
	/** LEVEL 2 */
	LEVEL_2("2"),
	
	/** LEVEL 1 */
	LEVEL_1("1"),
	
	/** LEVEL 0 */
	LEVEL_ZERO("0"),
	
	/** LEVEL -1 */
	LEVEL_MINUS_1("-1"),
	
	/** LEVEL -2 */
	LEVEL_MINUS_2("-2"),
	
	/** LEVEL -3 */
	LEVEL_MINUS_3("-3"),
	
	/** LEVEL -4 */
	LEVEL_MINUS_4("-4"),
	
	/** LEVEL -5 */
	LEVEL_MINUS_5("-5"),
	
	/** LEVEL -6 */
	LEVEL_MINUS_6("-6"),
	
	/** LEVEL -7 */
	LEVEL_MINUS_7("-7"),
	
	/** LEVEL -8 */
	LEVEL_MINUS_8("-8"),
	
	/** LEVEL -9 */
	LEVEL_MINUS_9("-9"),
	
	/** LEVEL -10 */
	LEVEL_MINUS_10("-10"),
	
	/** LEVEL -11 */
	LEVEL_MINUS_11("-11"),

	/** LEVEL -12 */
	LEVEL_MINUS_12("-12"),
	
	/** LEVEL -13 */
	LEVEL_MINUS_13("-13"),
	
	/** LEVEL -14 */
	LEVEL_MINUS_14("-14"),
	
	/** LEVEL -15 */
	LEVEL_MINUS_15("-15"),
	
	/** DON'T KNOW */
	DONT_KNOW("DK"),
	
	/** NOT INSURED */
	NOT_INSURED("NI");
	
	private PriorGridLevelClientCodeEnum(String aCode){
		this.code = aCode;
	}

	/** The code. */
	private String code = null;
	
	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}
	
	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the prior carrier declined or cancelled code enum
	 */
	public static PriorGridLevelClientCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (PriorGridLevelClientCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}	
	
	/**
	 * convert a String into a PriorGridLevelQty.
	 * 
	 * @param value the prior grid level.
	 * @return shortened prior grid level as {@link Short}
	 */
	public static Short convertToPriorGridLevelShort(String value){
		if (StringUtils.isEmpty(value) ||
			PriorGridLevelClientCodeEnum.DONT_KNOW.getCode().equals(value) ||
			PriorGridLevelClientCodeEnum.NOT_INSURED.getCode().equals(value)) {
			return null;
		}
		
		if (StringUtils.isNumeric(value)|| value.matches("-[\\d]{1,2}")){
			//if numeric or negative numeric value
			Short shortValue = new Short(value);
			if (-15 <= shortValue && shortValue <= 15){
				return shortValue;
			}
		}
		throw new IllegalArgumentException("not able to convert to a Short grid level : " + value);
		
	}
	
}
