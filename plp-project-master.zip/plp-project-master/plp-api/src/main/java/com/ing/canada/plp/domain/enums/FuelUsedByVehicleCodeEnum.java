/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum FuelUsedByVehicleCodeEnum.
 */
public enum FuelUsedByVehicleCodeEnum {

	ALCOHOL("A"), DIESEL("D"), ELECTRIC_BATTERY("E"), ELECTRIC_FUEL_CELL("F"), GASOLINE("G"), SOLAR("L"), NATURAL_GAS(
			"N"), OTHER("O"), PROPANE_FACTORY_INSTALLED("P"), PROPANE_NOT_FACTORY_INSTALLED("Q"), STANDARD("S");

	/**
	 * Instantiates a new fuel used by vehicle code enum.
	 * 
	 * @param aCode the a code
	 */
	private FuelUsedByVehicleCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the fuel used by vehicle code enum
	 */
	public static FuelUsedByVehicleCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (FuelUsedByVehicleCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
