package com.ing.canada.plp.service.broker.util;

import java.util.ArrayList;
import java.util.List;

import com.ing.canada.plp.domain.insurancepolicy.InsurancePolicy;
import com.ing.canada.plp.service.broker.util.QuoteReassign;

public class QuoteReassignBuilder {

	public static QuoteReassign build(List<String> policies, long brokerId) {

		QuoteReassign criteria = new QuoteReassign();
		criteria.setPolicies(new ArrayList<InsurancePolicy>());

		for (String policy : policies) {
			criteria.getPolicies().add(new InsurancePolicy(policy));
		}
		
		criteria.setBrokerId(brokerId);

		return criteria;
	}

}
