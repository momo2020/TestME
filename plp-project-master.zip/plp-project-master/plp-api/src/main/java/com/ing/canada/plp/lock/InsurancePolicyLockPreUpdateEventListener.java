package com.ing.canada.plp.lock;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.event.spi.PostUpdateEvent;
import org.hibernate.event.spi.PostUpdateEventListener;
import org.hibernate.event.spi.PreUpdateEvent;
import org.hibernate.event.spi.PreUpdateEventListener;
import org.hibernate.persister.entity.EntityPersister;


public class InsurancePolicyLockPreUpdateEventListener implements PreUpdateEventListener, PostUpdateEventListener {

	private static final long serialVersionUID = -8806669440915054626L;

	private static final Log log = LogFactory.getLog(InsurancePolicyLockPreUpdateEventListener.class);

	/**
	 * @see org.hibernate.event.PostUpdateEventListener#onPostUpdate(org.hibernate.event.PostUpdateEvent)
	 */
	@Override
	public void onPostUpdate(PostUpdateEvent event) {

		if (InsurancePolicyLockManagerThreadLocal.getGroupLockManager() != null) {

			if (log.isDebugEnabled()) {
				log.debug("pre-updating an entity of type: " + event.getEntity().getClass().getSimpleName());
			}
			Session session = event.getSession();

			// InsurancePolicyLockManagerThreadLocal.getGroupLockManager().checkVersions(session);
			InsurancePolicyLockManagerThreadLocal.getGroupLockManager().upgradeVersions(session);
		}
	}

	@Override
	public boolean onPreUpdate(PreUpdateEvent event) {
		if (InsurancePolicyLockManagerThreadLocal.getGroupLockManager() != null) {
			if (log.isDebugEnabled()) {
				log.debug("pre-updating an entity of type: " + event.getEntity().getClass().getSimpleName());
			}
			InsurancePolicyLockManagerThreadLocal.getGroupLockManager().checkVersions(event.getSession());
		}

		return false;
	}

	@Override
	public boolean requiresPostCommitHanding(EntityPersister persister) {
		// TODO Auto-generated method stub
		return false;
	}
}
