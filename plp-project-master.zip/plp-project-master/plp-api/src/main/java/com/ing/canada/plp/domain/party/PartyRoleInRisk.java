/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.party;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.ActionTakenCodeEnum;
import com.ing.canada.plp.domain.enums.DriverTypeCodeEnum;
import com.ing.canada.plp.domain.enums.OwnerTypeCodeEnum;
import com.ing.canada.plp.domain.enums.PartyRoleInRiskTypeCodeEnum;
import com.ing.canada.plp.domain.enums.PrincipalDriverSinceCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.usertype.BaseEntity;
import com.ing.canada.plp.roadblock.Roadblockable;

/**
 * PartyRoleInRisk entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "PARTY_ROLE_IN_RISK", uniqueConstraints = {})
public class PartyRoleInRisk extends BaseEntity implements Roadblockable {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "PARTY_ROLE_IN_RISK_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "PartyRoleInRiskSequence")
	@SequenceGenerator(name = "PartyRoleInRiskSequence", sequenceName = "PARTY_ROLE_IN_RISK_SEQ", allocationSize = 5)
	private Long id;

	/** The party. */
	@ManyToOne(cascade = { CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH }, fetch = FetchType.EAGER)
	@JoinColumn(name = "PARTY_ID", nullable = true, updatable = true)
	private Party party;

	/** The insurance risk. */
	@ManyToOne(cascade = { CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH }, fetch = FetchType.EAGER)
	@JoinColumn(name = "INSURANCE_RISK_ID", nullable = true, updatable = true)
	private InsuranceRisk insuranceRisk;

	/** The party role in risk type. */
	@Column(name = "PARTY_ROLE_IN_RISK_TYPE_CD", nullable = false, length = 6)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PartyRoleInRiskTypeCodeEnum") })
	private PartyRoleInRiskTypeCodeEnum partyRoleInRiskType;

	/** The driver type. */
	@Column(name = "DRIVER_TYPE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.DriverTypeCodeEnum") })
	private DriverTypeCodeEnum driverType;

	/** The creation date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "CREATION_DT", length = 7)
	private Date creationDate;

	/** The age. */
	@Column(name = "AGE_QTY", precision = 3, scale = 0)
	private Short age;

	/** The date driver has owned vehicle. */
	@Temporal(TemporalType.DATE)
	@Column(name = "DRIVER_HAS_OWNED_VEHICLE_DT", length = 7)
	private Date dateDriverHasOwnedVehicle;

	/** The principal driver since. */
	@Temporal(TemporalType.DATE)
	@Column(name = "PRINCIPAL_DRIVER_SINCE_DT", length = 7)
	private Date principalDriverSince;

	/** The principal driver since code. */
	@Column(name = "PRINCIPAL_DRIVER_SINCE_CD", length = 3)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PrincipalDriverSinceCodeEnum") })
	private PrincipalDriverSinceCodeEnum principalDriverSinceCode;

	/** The owner type. */
	@Column(name = "OWNER_TYPE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.OwnerTypeCodeEnum") })
	private OwnerTypeCodeEnum ownerType;

	/** The original scenario party role in risk. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_PARTY_ROLE_IN_RISK_ID", insertable = false, updatable = false)
	private PartyRoleInRisk originalScenarioPartyRoleInRisk;

	/** The action taken. */
	@Column(name = "ACTION_TAKEN_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ActionTakenCodeEnum") })
	private ActionTakenCodeEnum actionTaken = null;

	/** The road block indicator. */
	@Column(name = "ROAD_BLOCK_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean roadBlockIndicator;

	/** The already been principal driver indicator. */
	@Column(name = "ALREADY_BEEN_PRINC_DRIVER_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean alreadyBeenPrincipalDriverIndicator;

	/** the driver's percentage of use on the risk */
	@Column(name = "DRIVER_PERCENTAGE_USE_QTY", precision = 3, scale = 0)
	private Short driverUsePercentage;

	/**
	 * Instantiates a new party role in risk.
	 */
	public PartyRoleInRisk() {
		// noarg constructor
	}

	/**
	 * Instantiates a new party role in risk.
	 * 
	 * @param aParty the a party
	 * @param aInsuranceRisk the a insurance risk
	 * @param partyRoleInRiskTypeCode the party role in risk type code
	 */
	public PartyRoleInRisk(final Party aParty, final InsuranceRisk aInsuranceRisk,
			final PartyRoleInRiskTypeCodeEnum partyRoleInRiskTypeCode) {
		setParty(aParty);
		setInsuranceRisk(aInsuranceRisk);
		setPartyRoleInRiskType(partyRoleInRiskTypeCode);
	}

	/**
	 * @see com.ing.canada.plp.roadblock.Roadblockable#markAsRoadblocked()
	 */
	@Override
	public void markAsRoadblocked() {
		setRoadBlockIndicator(Boolean.TRUE);
	}

	/**
	 * @see com.ing.canada.plp.roadblock.Roadblockable#clearRoadblock()
	 */
	@Override
	public void clearRoadblock() {
		setRoadBlockIndicator(null);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(final Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the party.
	 * 
	 * @return the party
	 */
	@XmlTransient // parent
	public Party getParty() {
		return this.party;
	}

	/**
	 * Sets the party.
	 * 
	 * @param aParty the new party
	 */
	public void setParty(final Party aParty) {
		AssociationsHelper.updateOneToManyFields(aParty, "partyRoleInRisks", this, "party");
	}

	/**
	 * Gets the insurance risk.
	 * 
	 * @return the insurance risk
	 */
	@XmlTransient // parent
	public InsuranceRisk getInsuranceRisk() {
		return this.insuranceRisk;
	}

	/**
	 * Sets the insurance risk.
	 * 
	 * @param aInsuranceRisk the new insurance risk
	 */
	public void setInsuranceRisk(final InsuranceRisk aInsuranceRisk) {
		AssociationsHelper.updateOneToManyFields(aInsuranceRisk, "partyRoleInRisks", this, "insuranceRisk");
	}

	/**
	 * Gets the party role in risk type.
	 * 
	 * @return the party role in risk type
	 */
	public PartyRoleInRiskTypeCodeEnum getPartyRoleInRiskType() {
		return this.partyRoleInRiskType;
	}

	/**
	 * Sets the party role in risk type.
	 * 
	 * @param partyRoleInRiskTypeCode the new party role in risk type
	 */
	public void setPartyRoleInRiskType(final PartyRoleInRiskTypeCodeEnum partyRoleInRiskTypeCode) {
		this.partyRoleInRiskType = partyRoleInRiskTypeCode;
	}

	/**
	 * Gets the driver type.
	 * 
	 * @return the driver type
	 */
	public DriverTypeCodeEnum getDriverType() {
		return this.driverType;
	}

	/**
	 * Sets the driver type.
	 * 
	 * @param driverTypeCode the new driver type
	 */
	public void setDriverType(final DriverTypeCodeEnum driverTypeCode) {
		this.driverType = driverTypeCode;
	}

	/**
	 * Gets the creation date.
	 * 
	 * @return the creation date
	 */
	public Date getCreationDate() {
		return this.creationDate;
	}

	/**
	 * Sets the creation date.
	 * 
	 * @param aCreationDate the new creation date
	 */
	public void setCreationDate(final Date aCreationDate) {
		this.creationDate = aCreationDate;
	}

	/**
	 * Gets the age.
	 * 
	 * @return the age
	 */
	public Short getAge() {
		return this.age;
	}

	/**
	 * Sets the age.
	 * 
	 * @param aAge the new age
	 */
	public void setAge(final Short aAge) {
		this.age = aAge;
	}

	/**
	 * Gets the date driver has owned vehicle.
	 * 
	 * @return the date driver has owned vehicle
	 */
	public Date getDateDriverHasOwnedVehicle() {
		return this.dateDriverHasOwnedVehicle;
	}

	/**
	 * Sets the date driver has owned vehicle.
	 * 
	 * @param driverHasOwnedVehicleDate the new date driver has owned vehicle
	 */
	public void setDateDriverHasOwnedVehicle(final Date driverHasOwnedVehicleDate) {
		this.dateDriverHasOwnedVehicle = driverHasOwnedVehicleDate;
	}

	/**
	 * Gets the principal driver since.
	 * 
	 * @return the principal driver since
	 */
	public Date getPrincipalDriverSince() {
		return this.principalDriverSince;
	}

	/**
	 * Sets the principal driver since.
	 * 
	 * @param principalDriverSinceDate the new principal driver since
	 */
	public void setPrincipalDriverSince(final Date principalDriverSinceDate) {
		this.principalDriverSince = principalDriverSinceDate;
	}

	/**
	 * Gets the principal driver since code.
	 * 
	 * @return the principal driver since code
	 */
	public PrincipalDriverSinceCodeEnum getPrincipalDriverSinceCode() {
		return this.principalDriverSinceCode;
	}

	/**
	 * Sets the principal driver since code.
	 * 
	 * @param aPrincipalDriverSinceCode the new principal driver since code
	 */
	public void setPrincipalDriverSinceCode(final PrincipalDriverSinceCodeEnum aPrincipalDriverSinceCode) {
		this.principalDriverSinceCode = aPrincipalDriverSinceCode;
	}

	/**
	 * Gets the owner type.
	 * 
	 * @return the owner type
	 */
	public OwnerTypeCodeEnum getOwnerType() {
		return this.ownerType;
	}

	/**
	 * Sets the owner type.
	 * 
	 * @param ownerTypeCode the new owner type
	 */
	public void setOwnerType(final OwnerTypeCodeEnum ownerTypeCode) {
		this.ownerType = ownerTypeCode;
	}

	/**
	 * Gets the original scenario party role in risk.
	 * 
	 * @return the original scenario party role in risk
	 */
	@XmlTransient // reference source
	public PartyRoleInRisk getOriginalScenarioPartyRoleInRisk() {
		return this.originalScenarioPartyRoleInRisk;
	}

	/**
	 * Sets the original scenario party role in risk.
	 * 
	 * @param anOriginalScenarioPartyRoleInRisk the new original scenario party role in risk
	 */
	public void setOriginalScenarioPartyRoleInRisk(final PartyRoleInRisk anOriginalScenarioPartyRoleInRisk) {
		this.originalScenarioPartyRoleInRisk = anOriginalScenarioPartyRoleInRisk;
	}

	/**
	 * Gets the action taken.
	 * 
	 * @return the action taken
	 */
	public ActionTakenCodeEnum getActionTaken() {
		return this.actionTaken;
	}

	/**
	 * Sets the action taken.
	 * 
	 * @param anActionTaken the new action taken
	 */
	public void setActionTaken(final ActionTakenCodeEnum anActionTaken) {
		this.actionTaken = anActionTaken;
	}

	/**
	 * Gets the road block indicator.
	 * 
	 * @return the road block indicator
	 */
	public Boolean getRoadBlockIndicator() {
		return this.roadBlockIndicator;
	}

	/**
	 * Sets the road block indicator.
	 * 
	 * @param aRoadBlockIndicator the new road block indicator
	 */
	public void setRoadBlockIndicator(final Boolean aRoadBlockIndicator) {
		this.roadBlockIndicator = aRoadBlockIndicator;
	}

	/**
	 * @return the alreadyBeenPrincipalDriverIndicator
	 */
	public Boolean getAlreadyBeenPrincipalDriverIndicator() {
		return this.alreadyBeenPrincipalDriverIndicator;
	}

	/**
	 * @param anAlreadyBeenPrincipalDriverIndicator the alreadyBeenPrincipalDriverIndicator to set
	 */
	public void setAlreadyBeenPrincipalDriverIndicator(final Boolean anAlreadyBeenPrincipalDriverIndicator) {
		this.alreadyBeenPrincipalDriverIndicator = anAlreadyBeenPrincipalDriverIndicator;
	}

	/**
	 * Checks if is principal driver.
	 * 
	 * @return true, if is principal driver
	 */
	public boolean isPrincipalDriver() {

		if (this.partyRoleInRiskType != null
				&& !StringUtils.equals(this.partyRoleInRiskType.getCode(),
						PartyRoleInRiskTypeCodeEnum.IS_DRIVER_OF.getCode())) {
			return false;
		}

		if (this.driverType != null
				&& StringUtils.equals(this.driverType.getCode(), DriverTypeCodeEnum.PRINCIPAL.getCode())) {
			return true;
		}

		return false;
	}

	/**
	 * Gets the driver use percentage.
	 * 
	 * @return the driver use percentage
	 */
	public Short getDriverUsePercentage() {
		return this.driverUsePercentage;
	}

	/**
	 * Sets the driver use percentage.
	 * 
	 * @param aDriverUsePercentage the new driver use percentage
	 */
	public void setDriverUsePercentage(Short aDriverUsePercentage) {
		this.driverUsePercentage = aDriverUsePercentage;
	}
}
