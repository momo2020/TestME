package com.ing.canada.plp.domain.helper;

public class DescriptionCodeEnumHelper {
	// TODO code DescriptionCodeEnumHelper
}
