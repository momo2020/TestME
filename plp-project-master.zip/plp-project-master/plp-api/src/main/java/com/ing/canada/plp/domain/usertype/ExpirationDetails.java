/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.usertype;

import java.util.Date;

/**
 * The Class ExpirationDetails.
 */
public class ExpirationDetails {

	/** The effective date. */
	private Date effectiveDate = null;

	/** The expiry date. */
	private Date expiryDate = null;

	/**
	 * Checks if is expired.
	 * @param dateToVerify date to verify
	 * @return true, if checks if is expired
	 */
	public boolean isExpired(Date dateToVerify) {
		if (this.expiryDate != null && this.expiryDate.before(dateToVerify)) {
			return true;
		}

		return false;
	}
	 
	/**
	 * Checks if is active.
	 * @param dateToVerify date to verify
	 * @return true, if is active
	 */
	public boolean isActive(Date dateToVerify) {
		return !isExpired(dateToVerify);
	}

	/**
	 * Gets the effective date.
	 * 
	 * @return the effective date
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * Sets the effective date.
	 * 
	 * @param aEffectiveDate the new effective date
	 */
	public void setEffectiveDate(Date aEffectiveDate) {
		this.effectiveDate = aEffectiveDate;
	}

	/**
	 * Gets the expiry date.
	 * 
	 * @return the expiry date
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * Sets the expiry date.
	 * 
	 * @param aExpiryDate the new expiry date
	 */
	public void setExpiryDate(Date aExpiryDate) {
		this.expiryDate = aExpiryDate;
	}

}
