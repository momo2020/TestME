/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.businesstransaction;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlTransient;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * TransactionalMessageElement entity.
 * 
 * @author Patrick Lafleur
 */
@Entity
@Table(name = "TRANSACTIONAL_MSG_ELEMENT", uniqueConstraints = {})
public class TransactionalMessageElement extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "TRANSACTIONAL_MSG_ELEMENT_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "TransactionalMessageElementSequence")
	@SequenceGenerator(name = "TransactionalMessageElementSequence", sequenceName = "TRANSACTIONAL_MSG_ELEMENT_SEQ", allocationSize = 5)
	private Long id;

	/** The transactional message. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "TRANSACTIONAL_MESSAGE_ID", nullable = false, updatable = true)
	private TransactionalMessage transactionalMessage;

	/** The element value. */
	@Column(name = "ELEMENT_VALUE_TXT", length = 50)
	private String elementValue;

	/** The element name. */
	@Column(name = "ELEMENT_NAME_TXT", length = 50)
	private String elementName;

	/** The element desc. */
	@Column(name = "ELEMENT_DESC", length = 50)
	private String elementDescription;

	/** The message element id. */
	@Column(name = "MESSAGE_ELEMENT_ID", length = 8)
	private String messageElementIdentification;

	/**
	 * Instantiates a new transactional message element.
	 */
	public TransactionalMessageElement() {
		// noarg constructor
	}

	/**
	 * Instantiates a new transactional message element.
	 * 
	 * @param aTransactionalMessage the a transactional message
	 */
	public TransactionalMessageElement(TransactionalMessage aTransactionalMessage) {
		setTransactionalMessage(aTransactionalMessage);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the transactional message.
	 * 
	 * @return the transactional message
	 */
	@XmlTransient
	public TransactionalMessage getTransactionalMessage() {
		return this.transactionalMessage;
	}

	/**
	 * Sets the transactional message.
	 * 
	 * @param aTransactionalMessage the new transactional message
	 */
	public void setTransactionalMessage(TransactionalMessage aTransactionalMessage) {
		AssociationsHelper.updateOneToManyFields(aTransactionalMessage, "transactionalMessageElements", this,
				"transactionalMessage");
	}

	/**
	 * Gets the element value.
	 * 
	 * @return the element value
	 */
	public String getElementValue() {
		return this.elementValue;
	}

	/**
	 * Sets the element value.
	 * 
	 * @param aElementValue the new element value
	 */
	public void setElementValue(String aElementValue) {
		this.elementValue = aElementValue;
	}

	/**
	 * Gets the element name.
	 * 
	 * @return the element name
	 */
	public String getElementName() {
		return this.elementName;
	}

	/**
	 * Sets the element name.
	 * 
	 * @param aElementName the new element name
	 */
	public void setElementName(String aElementName) {
		this.elementName = aElementName;
	}

	/**
	 * Gets the element desc.
	 * 
	 * @return the element desc
	 */
	public String getElementDescription() {
		return this.elementDescription;
	}

	/**
	 * Sets the element desc.
	 * 
	 * @param aElementDesc the new element desc
	 */
	public void setElementDescription(String aElementDesc) {
		this.elementDescription = aElementDesc;
	}

	/**
	 * Gets the message element id.
	 * 
	 * @return the message element id
	 */
	public String getMessageElementIdentification() {
		return this.messageElementIdentification;
	}

	/**
	 * Sets the message element id.
	 * 
	 * @param aMessageElementId the new message element id
	 */
	public void setMessageElementIdentification(String aMessageElementId) {
		this.messageElementIdentification = aMessageElementId;
	}

}
