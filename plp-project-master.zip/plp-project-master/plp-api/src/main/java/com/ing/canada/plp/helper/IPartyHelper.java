/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;

import com.ing.canada.plp.domain.driver.DriverComplementInfo;
import com.ing.canada.plp.domain.driver.DriverLicenseClass;
import com.ing.canada.plp.domain.enums.CommunicationChannelCodeEnum;
import com.ing.canada.plp.domain.enums.ConsentTypeCodeEnum;
import com.ing.canada.plp.domain.enums.DistributorCodeEnum;
import com.ing.canada.plp.domain.enums.DriverLicenseClassCodeEnum;
import com.ing.canada.plp.domain.enums.PartyGroupTypeCodeEnum;
import com.ing.canada.plp.domain.enums.PartyTypeCodeEnum;
import com.ing.canada.plp.domain.enums.PhoneTypeCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.partnership.Partnership;
import com.ing.canada.plp.domain.party.Address;
import com.ing.canada.plp.domain.party.Consent;
import com.ing.canada.plp.domain.party.GroupRepositoryEntry;
import com.ing.canada.plp.domain.party.Party;
import com.ing.canada.plp.domain.party.Phone;
import com.ing.canada.plp.domain.policyversion.PolicyHolder;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

/**
 * Helper class to access Party Content.
 *
 * @author fsimard
 */
public interface IPartyHelper {

	/**
	 * Gets the current home phone.
	 *
	 * @param aParty the a party
	 *
	 * @return the current home phone
	 */
	Phone getCurrentHomePhone(Party aParty);

	/**
	 * Gets the current business phone.
	 *
	 * @param aParty the a party
	 *
	 * @return the current business phone
	 */
	Phone getCurrentBusinessPhone(Party aParty);

	/**
	 * Initialize the type of phone wanted. If the type of phone wanted is not available, null will be returned. 2 types
	 * of phone available : PhoneTypeCodeEnum.HOME_PHONE, PhoneTypeCodeEnum.BUSINESS_PHONE HOME_PHONE should always be
	 * available but to make sure anything bad happen, is is smarter to test Phone == null before doing anything else.
	 *
	 * @param aParty the a party
	 * @param aPhoneTypeParam the a phone type param
	 *
	 * @return the phone
	 */
	Phone getCurrentPhone(Party aParty, PhoneTypeCodeEnum aPhoneTypeParam);

	/**
	 * Initialize the type of phone wanted. If the type of phone wanted is not available, null will be returned. 2 types
	 * of phone available : PhoneTypeCodeEnum.HOME_PHONE, PhoneTypeCodeEnum.BUSINESS_PHONE HOME_PHONE should always be
	 * available but to make sure anything bad happen, is is smarter to test Phone == null before doing anything else.
	 *
	 * @param aPhoneSet the Phone Set
	 * @param aPhoneTypeParam the a phone type param
	 *
	 * @return the phone
	 */
	Phone getCurrentPhone(Set<Phone> aPhoneSet, PhoneTypeCodeEnum aPhoneTypeParam);

	/**
	 * Sets the current home Phone.
	 *
	 * @param aParty the Party to set the Phone
	 * @param aPhone the new home Phone
	 */
	void setCurrentHomePhone(Party aParty, Phone aPhone);

	/**
	 * Sets the current Phone.
	 *
	 * @param aParty the Party to set the Phone
	 * @param aPhone the new Phone
	 * @param aPhoneTypeParam the Phone
	 */
	void setCurrentPhone(Party aParty, Phone aPhone, PhoneTypeCodeEnum aPhoneTypeParam);

	/**
	 * Gets the current residential address.
	 *
	 * @param aParty the a party
	 *
	 * @return the current residential address
	 */
	Address getCurrentResidentialAddress(Party aParty);

	/**
	 * Gets the current mailing address.
	 *
	 * @param aParty the a party
	 *
	 * @return the current mailing address
	 */
	Address getCurrentMailingAddress(Party aParty);

	/**
	 * Gets the previous residential address.
	 *
	 * @param aParty the a party
	 *
	 * @return the previous residential address
	 */
	Address getPreviousResidentialAddress(Party aParty);

	/**
	 * Get the Consent for specified type.
	 *
	 * @param aParty The party
	 * @param aConsentTypeCodeEnum The type.
	 *
	 * @return The Consent
	 */
	Consent getConsent(Party aParty, ConsentTypeCodeEnum aConsentTypeCodeEnum);

	/**
	 * Get the Consent for specified type.
	 *
	 * @param aPolicyVersion The policyVersion
	 * @param aConsentTypeCodeEnum The type.
	 *
	 * @return The Consent
	 */
	Consent getConsent(PolicyVersion aPolicyVersion, ConsentTypeCodeEnum aConsentTypeCodeEnum);

	/**
	 * Get the Credit consent for specified type.
	 *
	 * @param aPolicyVersion
	 *
	 * @return The Consent
	 */
	Consent getCreditConsent(PolicyVersion aPolicyVersion);

	/**
	 * From an insuranceRisk, find and return the principal driver Party.
	 *
	 * @param aInsuranceRisk {@link InsuranceRisk}
	 *
	 * @return The {@link Party}.
	 */
	Party getPrincipalDriver(InsuranceRisk aInsuranceRisk);

	/**
	 * From an insuranceRisk, find and return the owner Party.
	 *
	 * @param aInsuranceRisk {@link InsuranceRisk}
	 *
	 * @return The {@link Party}.
	 */
	Party getOwner(InsuranceRisk aInsuranceRisk);

	/**
	 * From an PolicyVersion, find and return the driver party with the sequence received in parameter.
	 *
	 * @param aPolicyVersion {@link PolicyVersion}
	 * @param sequence the sequence
	 *
	 * @return The {@link Party}.
	 */
	Party getDriverBySequence(PolicyVersion aPolicyVersion, Integer sequence);

	/**
	 * From an PolicyVersion, find and return the named insured driver party.
	 *
	 * @param aPolicyVersion {@link PolicyVersion}
	 *
	 * @return The {@link Party}.
	 */
	Party getNamedInsured(PolicyVersion aPolicyVersion);

	/**
	 * From an PolicyVersion, determine if the named insured as a profile created.
	 *
	 * @param aPolicyVersion {@link PolicyVersion}
	 *
	 * @return boolean.
	 */
	boolean isNamedInsuredProfileCreated(PolicyVersion aPolicyVersion);

	/**
	 * Retrieve a all the driver name from a the InsuranceRisk object. The List Party include first ad last name only!
	 *
	 * @param aInsuranceRisk the a insurance risk
	 *
	 * @return the party name list
	 */
	List<Party> getPartyNameList(InsuranceRisk aInsuranceRisk);

	/**
	 * Gets the Occupation/Domain GroupRepositoryEntry.
	 *
	 * @param aParty the a party
	 *
	 * @return the occupation domain group
	 */
	GroupRepositoryEntry getOccupationDomainGroup(Party aParty);

	/**
	 * Gets the Insured Group GroupRepositoryEntry.
	 *
	 * @param aParty the a party
	 *
	 * @return the insured group
	 */
	String getInsuredGroup(Party aParty);

	/**
	 * Gets the GrouprepositoryEntry corresponding to the partyGroupTypeCode
	 *
	 * @param aParty the a party
	 * @param aPartyGroupTypeCode the group type to search in the party's groups.
	 *
	 * @return the insured group
	 */
	GroupRepositoryEntry findGroupRepositoryEntry(Party aParty, PartyGroupTypeCodeEnum aPartyGroupTypeCode);

	/**
	 * Gets the current DriverLicenseClass.
	 *
	 * @param aDriverComplementInfo The DriverComplementInfo
	 *
	 * @return the DriverLicenseClass
	 */
	DriverLicenseClass getCurrentDriverLicenseClass(DriverComplementInfo aDriverComplementInfo);

	/**
	 * Get all the drivers with a valid driver license
	 *
	 * @param aPartyList the Party List to inspect
	 * @return all the drivers with a valid driver license
	 */
	List<Party> getValidDrivers(Collection<Party> aPartyList);

	/**
	 * Checks if the Party is a principal driver
	 *
	 * @param party the party to check
	 *
	 * @return true, if the Party is a principal driver
	 */
	boolean isPrincipalDriver(Party party);

	/**
	 * Determines if the party is a registered owner.
	 *
	 * @param party
	 * @return
	 */
	boolean isOwner(PolicyVersion policyVersion, Party party);

	/**
	 * Gets the driver license class entry for a given license class
	 *
	 * @param aDriverComplementInfo {@link DriverComplementInfo}
	 * @param licenseClassCode {@link DriverLicenseClassCodeEnum}
	 *
	 * @return the DriverLicenseClass
	 */
	DriverLicenseClass getDriverLicenseClassForGivenClass(DriverComplementInfo aDriverComplementInfo,
			DriverLicenseClassCodeEnum licenseClassCode);

	/**
	 * Checks if the Party is the policy Holder.
	 *
	 * @param party {@link Party}
	 *
	 * @return boolean
	 */
	boolean isPolicyHolder(Party party);

	/**
	 * Checks if there a unique driver for the whole policy
	 *
	 * @param pv
	 * @return
	 */
	boolean isUniquePrincipalDriver(PolicyVersion pv);

	/**
	 *
	 * return true at least if one driver is interested by UBI
	 *
	 * @param insuranceRisk
	 * @return
	 */
	boolean isUbiCustomerInterested(InsuranceRisk insuranceRisk);

	/**
	 * Verify if clients have included UBI at least on one of their vehicles
	 *
	 * @param ir
	 *
	 * @return
	 */
	boolean isUbiIncluded(Set<InsuranceRisk> ir);

	/**
	 * Gets the Advisor Party
	 *
	 * @param aPolicyVersion a aPolicyVersion
	 *
	 * @return the Advisor Party
	 */

	Party getAdvisor(PolicyVersion aPolicyVersion);

	/**
	 * Gets the Advisor address.
	 *
	 * @param aParty the a party
	 *
	 * @return the Advisor address
	 */
	Address getAdvisorAddress(Party aParty);
	
	/**
	 * Initialize a new party.
	 *
	 * @param policyVersion {@link PolicyVersion}
	 * @return {@link Party}
	 */
	Party initNewParty(final PolicyVersion policyVersion);
	
	/**
	 * Initialize a new party.
	 *
	 * @param policyVersion {@link PolicyVersion}
	 * @param policyVersion {@link Boolean  isDriver}
	 * @return {@link Party}
	 */
	Party initNewParty(final PolicyVersion policyVersion, final Boolean  isDriver);

	

	/**
	 * Safe initialization of a PriorCarrierPolicInfo for a party.<br>
	 * Creates it only when it doesn't already exist.
	 *
	 * @param aPArty - {@link Party}
	 */
	public void initPriorCarrierPolicyInfo(Party aParty);

	/**
	 * Obtain a specific party from a collection of party
	 *
	 * @param parties - a list of {@ink Party}
	 * @param sequence - the sequence to find
	 * @return the party found or null if not gound
	 */
	Party getPartyFromSequence(final List<Party> parties, final int sequence);

	/**
	 * Checks if the party is a driver. Returns true if the party as a driver license.
	 *
	 * @param aParty - {@link Party}
	 * @return true if is a driver, false otherwise
	 */
	boolean isDriver(final Party aParty);

	/**
	 * Check if the driver has a learner's permit (ex: Alberta is Class 7 and Ontario is G1)
	 *
	 * @param aDriver - The driver as {@link Party}
	 * @return true when has a learner permit, false otherwise
	 */
	boolean hasLearnersPermit(final Party aParty);

	/**
	 * Creates a new database consent object.
	 *
	 * @param aParty {@link Party}
	 * @param communicationChannel {@link CommunicationChannelCodeEnum}
	 * @param consentType {@link ConsentTypeCodeEnum}
	 * @param consentInd the {@link Boolean} indicator for the consent
	 * @param effectiveDate effective {@link Date} of the consent
	 */
	Party createConsent(Party aParty, CommunicationChannelCodeEnum communicationChannel,
			ConsentTypeCodeEnum consentType, Boolean consentInd, Date effectiveDate);

	/**
	 * Get principal policy holder
	 *
	 * @param policyVersion {@link PolicyVersion}
	 * @return {@link PolicyHolder}
	 */
	PolicyHolder getPrincipalPolicyHolder(PolicyVersion policyVersion);

	/**
	 * safely get the direct channel distributor from the party's policy version.
	 *
	 * @return {@link DistributorCodeEnum}
	 */
	DistributorCodeEnum getDistributorCode(final Party party);

	/**
	 * safely get the partnerships from the party's policy version.
	 *
	 * @return {@link DistributorCodeEnum}
	 */
	Set<Partnership> getPartnerships(final Party party);


}
