package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.party.MunicipalityDetailSpecification;

public interface IMunicipalityDetailSpecService extends ICRUDService<MunicipalityDetailSpecification> {
	/**
	 * Create a municipality detail and its parent municipality repository entry.
	 * 
	 * @param aGroupRepositoryEntry the a group repository entry
	 * 
	 * @return the equivalent persistent repository entry
	 */
	MunicipalityDetailSpecification createMunicipalityDetailSpecification(
			MunicipalityDetailSpecification aMunicipalityDetailSpecification);
}
