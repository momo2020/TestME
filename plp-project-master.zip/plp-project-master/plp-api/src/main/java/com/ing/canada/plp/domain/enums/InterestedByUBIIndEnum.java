package com.ing.canada.plp.domain.enums;

public enum InterestedByUBIIndEnum {
	/// code InterestedByUBIIndEnum
}
