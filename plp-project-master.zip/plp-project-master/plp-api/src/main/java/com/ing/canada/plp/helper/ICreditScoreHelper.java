package com.ing.canada.plp.helper;

import com.ing.canada.plp.domain.enums.ClientEligibilityLevelCodeEnum;
import com.ing.canada.plp.domain.party.CreditScore;
import com.ing.canada.plp.domain.policyversion.PolicyVersion;

public interface ICreditScoreHelper {

	/**
	 * Get the client eligibility level code.
	 * 
	 * @param aPolicyVersion
	 * @return the client eligibility level code.
	 */
	ClientEligibilityLevelCodeEnum getClientEligibilityLevelCode(PolicyVersion aPolicyVersion);

	/**
	 * Is the credit score good?
	 * 
	 * @param aPolicyVersion
	 * @return true if the creditscore is above threshold or not regular.
	 */
	boolean isGoodCreditScore(PolicyVersion aPolicyVersion);

	/**
	 * Is the credit score bad?
	 * 
	 * @param aPolicyVersion
	 * @return true if the creditscore is below threshold or regular.
	 */
	boolean isBadCreditScore(PolicyVersion aPolicyVersion);

	/**
	 * Is the credit score is no consent ?
	 * 
	 * @param aPolicyVersion
	 * @return true if the creditscore is regular.
	 */
	boolean isNoConsentCreditScore(PolicyVersion aPolicyVersion);

	/**
	 * Is the credit score regular? Regular could be different for Intact Rating and
	 * Belair Direct Rating.
	 * 
	 * @param aPolicyVersion
	 * @return true if the creditscore is regular.
	 */
	boolean isRegularCreditScore(PolicyVersion aPolicyVersion);

	/**
	 * Is the credit score advantage?
	 * 
	 * @param aPolicyVersion
	 * @return true if the creditscore is advantage.
	 */
	boolean isAdvantageCreditScore(PolicyVersion aPolicyVersion);

	/**
	 * Is the credit score distinction?
	 * 
	 * @param aPolicyVersion
	 * @return true if the creditscore is distinction.
	 */
	boolean isPrivilegeCreditScore(PolicyVersion aPolicyVersion);

	/**
	 * Is the credit score standard offer plus? Regular Plus/Standard Plus could be
	 * different for Intact Rating and Belair Direct Rating.
	 * 
	 * @param aPolicyVersion
	 * @return true if the creditscore is distinction.
	 */
	boolean isStandardOfferPlusCreditScore(PolicyVersion aPolicyVersion);

	/**
	 * @param aPolicyVersion
	 * @return
	 */
	CreditScore getCreditScore(PolicyVersion aPolicyVersion);

}
