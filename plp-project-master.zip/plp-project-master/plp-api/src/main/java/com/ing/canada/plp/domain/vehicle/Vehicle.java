/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.vehicle;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.enums.BasicCoverageCodeEnum;
import com.ing.canada.plp.domain.enums.ConditionVehicleWhenBoughtCodeEnum;
import com.ing.canada.plp.domain.enums.FuelUsedByVehicleCodeEnum;
import com.ing.canada.plp.domain.enums.LanguageCodeEnum;
import com.ing.canada.plp.domain.enums.NumberOfKmsUsedOutsideProvinceCodeEnum;
import com.ing.canada.plp.domain.enums.OtherProvinceOfUseCodeEnum;
import com.ing.canada.plp.domain.enums.ParkingTypeCodeEnum;
import com.ing.canada.plp.domain.enums.PurposeUseOutsideOfPvCodeEnum;
import com.ing.canada.plp.domain.enums.UseOfVehicleCategoryCodeEnum;
import com.ing.canada.plp.domain.enums.UseOfVehicleCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.AdditionalInterestRole;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.insurancerisk.Trailer;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * Vehicle entity.
 * 
 * @author Patrick Lafleur
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@Entity
@Table(name = "VEHICLE", uniqueConstraints = {})
public class Vehicle extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@GeneratedValue(generator = "insuranceRiskForeignGenerator")
	@org.hibernate.annotations.GenericGenerator(name = "insuranceRiskForeignGenerator", strategy = "foreign", parameters = @Parameter(name = "property", value = "insuranceRisk"))
	@Column(name = "INSURANCE_RISK_ID")
	private Long id = null;

	/** The insurance risk. */
	@OneToOne(cascade = {}, fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn(name = "INSURANCE_RISK_ID")
	private InsuranceRisk insuranceRisk;

	/** The vehicle detail spec repository entry. */
	@ManyToOne(cascade = { CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name = "VEH_DETAIL_SPEC_REP_ENTRY_ID")
	private VehicleDetailSpecificationRepositoryEntry vehicleDetailSpecificationRepositoryEntry;

	/** The list price new. */
	@Column(name = "LIST_PRICE_NEW_AMT", precision = 7, scale = 0)
	private Integer listPriceNew;

	/** The vehicle body type. */
	@Column(name = "VEHICLE_BODY_TYPE_CD", length = 3)
	private String vehicleBodyType;

	/** The type of machinery equipment code. */
	@Column(name = "TYPE_MACHINERY_EQUIP_CD", length = 4)
	private String typeOfMachineryEquipmentCode;

	/** The type of machinery equipment code additional. */
	@Column(name = "TYPE_MACHINERY_EQUIP_ADD_CD", length = 4)
	private String typeOfMachineryEquipmentCodeAdditional;

	/** The vehicle identification number. */
	@Column(name = "VEHICLE_IDENTIFICATION_NBR", length = 30)
	private String vehicleIdentificationNumber;

	/** The purchase date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "VEHICLE_PURCHASE_DT", length = 7)
	private Date vehiclePurchaseDate;

	/** The purchase price. */
	@Column(name = "VEHICLE_PURCHASE_PRICE_AMT", precision = 7, scale = 0)
	private Integer vehiclePurchasePrice;

	/** The use of vehicle category. */
	@Column(name = "USE_OF_VEHICLE_CATEGORY_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.UseOfVehicleCategoryCodeEnum") })
	private UseOfVehicleCategoryCodeEnum useOfVehicleCategory = null;

	/** The vehicle usage. */
	@Column(name = "USE_OF_VEHICLE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.UseOfVehicleCodeEnum") })
	private UseOfVehicleCodeEnum vehicleUsage;

	/** The vehicle usage description. */
	@Column(name = "VEHICLE_USAGE_DESC", length = 65)
	private String vehicleUsageDescription;

	/** The other province of usage. */
	@Column(name = "OTHER_PROVINCE_OF_USE_CD", length = 2)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.OtherProvinceOfUseCodeEnum") })
	private OtherProvinceOfUseCodeEnum otherProvinceOfUsage;

	/** The used outside province or country. */
	@Type(type = "yes_no")
	@Column(name = "USE_OUT_PROV_OR_COUNTRY_IND", length = 1)
	private Boolean usedOutsideProvinceOrCountryIndicator;

	/** The outside province usage percentage. */
	@Column(name = "USE_OUTSIDE_OF_PROVINCE_PCT", precision = 3, scale = 0)
	private Short percentageUseOutsideOfProvince;

	/** The outside province usage purpose. */
	@Column(name = "PURPOSE_USE_OUTSIDE_OF_PV_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.PurposeUseOutsideOfPvCodeEnum") })
	private PurposeUseOutsideOfPvCodeEnum purposeUseOutsideOfProvince;

	/** The condition of vehicle when bought. */
	@Column(name = "CONDITION_VEH_WHEN_BOUGHT_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ConditionVehicleWhenBoughtCodeEnum") })
	private ConditionVehicleWhenBoughtCodeEnum conditionOfVehicleWhenBought;

	/** The number of kilometers to drive to work. */
	@Column(name = "NBR_OF_KM_DRIVE_TO_WORK_QTY", precision = 6, scale = 0)
	private Integer numberOfKilometersToDriveToWork;

	/** The number of kilometers the vehicle is used outside the province. */
	@Column(name = "NBR_KM_USE_OUTSIDE_PV_CD", length = 6)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.NumberOfKmsUsedOutsideProvinceCodeEnum") })
	private NumberOfKmsUsedOutsideProvinceCodeEnum numberOfKmsUsedOutsideOfProvince = null;

	/** The number of kilometers the vehicle is used outside the province for business. */
	@Column(name = "NBR_KM_USE_OUTSIDE_PV_PL_BS_CD", length = 6)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.NumberOfKmsUsedOutsideProvinceCodeEnum") })
	private NumberOfKmsUsedOutsideProvinceCodeEnum numberOfKmsUsedOutsideOfProvinceBusiness = null;

	/** The annual kilometers. */
	@Column(name = "ANNUAL_KM_QTY", precision = 6, scale = 0)
	private Integer annualKilometers;

	/** The annual business kilometers. */
	@Column(name = "ANNUAL_BUSINESS_KM_QTY", precision = 6, scale = 0)
	private Integer annualBusinessKilometers;

	/** The odometer reading. */
	@Column(name = "ODOMETER_READING_QTY", precision = 6, scale = 0)
	private Integer odometerReading;

	/** The fuel used by vehicle. */
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.FuelUsedByVehicleCodeEnum") })
	@Column(name = "FUEL_USED_BY_VEHICLE_CD", length = 1)
	private FuelUsedByVehicleCodeEnum fuelUsedByVehicle;

	/** The additional equipment or modification installed. */
	@Type(type = "yes_no")
	@Column(name = "ADDL_EQPMNT_OR_MDFCTN_IND", length = 1)
	private Boolean indicatorOfAdditionalEquipementOrModification;

	/** The value of vehicle modification. */
	@Column(name = "VALUE_OF_VEH_MODIFICATION_AMT", precision = 6, scale = 0)
	private Integer valueOfVehicleModification;

	/** The value of custom paint job. */
	@Column(name = "VALUE_OF_CUSTOM_PAINT_JOB_AMT", precision = 6, scale = 0)
	private Integer valueOfCustomPaintJob;

	/** The high value vehicle modification indicator. */
	@Type(type = "yes_no")
	@Column(name = "HIGH_VALUE_VEHICLE_MOD_IND", length = 1)
	private Boolean highValueVehicleModificationIndicator;

	/** The performance vehicle modification indicator. */
	@Type(type = "yes_no")
	@Column(name = "PERFORMANCE_VEHICLE_MOD_IND", length = 1)
	private Boolean performanceVehicleModificationIndicator;

	/** The vehicle change restriction indicator. */
	@Type(type = "yes_no")
	@Column(name = "VEH_MODIFICATION_RESTRICT_IND", length = 1)
	private Boolean vehicleChangeRestrictionIndicator;

	/** The vehicle age. */
	@Column(name = "VEHICLE_AGE_QTY", precision = 3, scale = 0)
	private Short vehicleAge;

	/** The leasedVehicleIndicator. */
	@Type(type = "yes_no")
	@Column(name = "LEASED_VEHICLE_IND", length = 1)
	private Boolean leasedVehicleIndicator;

	/** The replacement cost proof ind. */
	@Type(type = "yes_no")
	@Column(name = "REPLACEMENT_COST_PROOF_IND", length = 1)
	private Boolean replacementCostProofIndicator;

	/** The unrepaired damage ind. */
	@Type(type = "yes_no")
	@Column(name = "UNREPAIRED_DAMAGE_IND", length = 1)
	private Boolean unrepairedDamageIndicator;

	/** The recreational motorcycle discount ind. */
	@Type(type = "yes_no")
	@Column(name = "RCRTNL_MOTORCYCLE_DISCOUNT_IND", length = 1)
	private Boolean recreationalMotorcycleDiscountIndicator;

	/** The carry explosive radioactive ind. */
	@Type(type = "yes_no")
	@Column(name = "CARRY_EXPL_RADIOACTIVE_IND", length = 1)
	private Boolean carryExplosiveRadioactiveIndicator;

	/** The vehicle rate group. */
	@Column(name = "VEHICLE_RATE_GROUP_CD", length = 2)
	private String vehicleRateGroup;

	/** The vehicle rate group liability bodily injury. */
	@Column(name = "VEH_RT_GRP_LBLTY_BDLY_INJRY_CD", length = 2)
	private String vehicleRateGroupLiabilityBodilyInjury;

	/** The vehicle rate group liability property damage. */
	@Column(name = "VEH_RT_GRP_LBLTY_PRPTY_DMD_CD", length = 2)
	private String vehicleRateGroupLiabilityPropertyDamage;

	/** The vehicle rate group accident benefit. */
	@Column(name = "VEH_RT_GRP_ACDNT_BNFT_CD", length = 2)
	private String vehicleRateGroupAccidentBenefit;

	/** The vehicle rate group all perils. */
	@Column(name = "VEH_RT_GRP_ALL_PERILS_CD", length = 2)
	private String vehicleRateGroupAllPerils;

	/** The vehicle rate group collision. */
	@Column(name = "VEH_RT_GRP_COLLISION_CD", length = 2)
	private String vehicleRateGroupCollision;

	/** The vehicle rate group comprehensive. */
	@Column(name = "VEH_RT_GRP_COMPREHENSIVE_CD", length = 2)
	private String vehicleRateGroupComprehensive;

	/** The vehicle rate group specified perils. */
	@Column(name = "VEH_RT_GRP_SPECIFIED_PERILS_CD", length = 2)
	private String vehicleRateGroupSpecifiedPerils;

	/** The vehicle rate group liability. */
	@Column(name = "VEH_RT_GRP_LBLTY_CD", length = 2)
	private String vehicleRateGroupLiability;

	/** The vehicle rate group medical expenses. */
	@Column(name = "VEH_RT_GRP_MEDICAL_EXPENSES_CD", length = 2)
	private String vehicleRateGroupMedicalExpenses;

	/** The vehicle rate group total disability. */
	@Column(name = "VEH_RT_GRP_TOTAL_DISABILITY_CD", length = 2)
	private String vehicleRateGroupTotalDisability;

	/** The parking type. */
	@Column(name = "PARKING_TYPE_CD", length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.ParkingTypeCodeEnum") })
	private ParkingTypeCodeEnum parkingType;

	/** The vehicle equipments. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "vehicle", orphanRemoval = true)
	private Set<VehicleEquipment> vehicleEquipments = new HashSet<VehicleEquipment>(0);

	/** The anti theft devices. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "vehicle", orphanRemoval = true)
	private Set<AntiTheftDevice> antiTheftDevices = new HashSet<AntiTheftDevice>(0);

	/** The trailers. */
	@OneToMany(cascade = {}, fetch = FetchType.LAZY, mappedBy = "vehicle")
	private Set<Trailer> trailers = new HashSet<Trailer>(0);

	/** The additional interest roles. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "vehicle", orphanRemoval = true)
	private Set<AdditionalInterestRole> additionalInterestRoles = new HashSet<AdditionalInterestRole>(0);

	/** The alarm system indicator. */
	@Type(type = "yes_no")
	@Column(name = "ALARM_SYSTEM_IND", length = 1)
	private Boolean alarmSystemIndicator;

	/** The cut off switch indicator. */
	@Type(type = "yes_no")
	@Column(name = "CUT_OFF_SWITCH_IND", length = 1)
	private Boolean cutOffSwitchIndicator;

	/** The intensive engraving indicator. */
	@Type(type = "yes_no")
	@Column(name = "INTENSIVE_ENGRAVING_IND", length = 1)
	private Boolean intensiveEngravingIndicator;

	/** The remote tracking system indicator. */
	@Type(type = "yes_no")
	@Column(name = "REMOTE_TRACKING_SYSTEM_IND", length = 1)
	private Boolean remoteTrackingSystemIndicator;

	/** The Original Scenario Insurance Risk *. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_INSURANCE_RISK_ID", insertable = false, updatable = false)
	private Vehicle originalScenarioVehicle;

	/** The add party navigation indicator. */
	@Type(type = "yes_no")
	@Column(name = "ADD_PARTY_NAVIGATION_IND", length = 1)
	private Boolean addPartyNavigationIndicator;

	/** The usage to review by client indicator. */
	@Type(type = "yes_no")
	@Column(name = "USAGE_TO_REVIEW_BY_CLIENT_IND", length = 1)
	private Boolean usageToReviewByClientIndicator;

	/** The lien holder indicator. */
	@Type(type = "yes_no")
	@Column(name = "LIENHOLDER_IND", length = 1)
	private Boolean lienHolderIndicator = null;

	/** The vehicle net weight. */
	@Column(name = "VEHICLE_NET_WEIGHT_QTY", precision = 7, scale = 0)
	private Integer vehicleNetWeight;

	/** The performance vehicle modification indicator. */
	@Type(type = "yes_no")
	@Column(name = "CARRY_PASSENGER_FOR_COMP_IND", length = 1)
	private Boolean carryPassengerForCompensationIndicator;

	/**
	 * DEXXX/RULL4 Autoquote Ontario fixes The purchase date vehicle modification indicator.
	 */
	@Type(type = "yes_no")
	@Column(name = "VEH_PURCHASE_DT_ENT_BY_USR_IND", length = 1)
	private Boolean purchaseDateByUserIndicator;

	/** The vehicle modifications. */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "vehicle", orphanRemoval = true)
	private Set<VehicleModification> vehicleModifications = new HashSet<VehicleModification>(0);

	/** Indicate if the vehicle is eligible to the UBI program **/
	@Column(name = "UBI_ELIGIBILITY_IND", length = 1)
	@Type(type = "yes_no")
	private Boolean UBIEligibilityIndicator;
	
	/** Vehicle’s radius of operation */
	@Column(name = "NORMAL_RADIUS_OF_OPERATION_QTY",  precision = 6)
	private Integer normalRadiusOfOperationQty;
	
	/** The Gross vehicle weight rating (GVWR). */
	@Column(name = "GROSS_VEHICLE_WEIGHT_QTY",  precision = 8)
	private Double grossVehicleWeightQty;
	
	/** The Vehicle business use. */
	@Column(name = "VEHICLE_BUSINESS_USE_CD", length = 5)
	private String vehicleBusinessUse;
	
	/** (4.2.2) Indicates if the vehicle rate groups for the vehicle were obtained based on the vehicle's value or not. */
	@Column(name = "VEH_RT_GRP_BY_VALUE_IND", length = 1)
	private String vehicleRateGroupByValueInd;
		
	/**
	 * Instantiates a new vehicle.
	 */
	public Vehicle() {
		// noarg constructor
	}

	/**
	 * Instantiates a new vehicle.
	 * 
	 * @param aInsuranceRisk the a insurance risk
	 */
	public Vehicle(InsuranceRisk aInsuranceRisk) {
		this.setInsuranceRisk(aInsuranceRisk);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param insuranceRiskId the insurance risk id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object insuranceRiskId) {
		this.id = (Long) insuranceRiskId;
	}

	/**
	 * Gets the vehicle detail spec repository entry.
	 * 
	 * @return the vehicle detail spec repository entry
	 */
	public VehicleDetailSpecificationRepositoryEntry getVehicleDetailSpecificationRepositoryEntry() {
		return this.vehicleDetailSpecificationRepositoryEntry;
	}

	/**
	 * Sets the vehicle detail spec repository entry.
	 * 
	 * @param aVehicleDetailSpecificationRepositoryEntry the new vehicle detail spec repository entry
	 */
	public void setVehicleDetailSpecificationRepositoryEntry(
			VehicleDetailSpecificationRepositoryEntry aVehicleDetailSpecificationRepositoryEntry) {
		this.vehicleDetailSpecificationRepositoryEntry = aVehicleDetailSpecificationRepositoryEntry;
	}

	/**
	 * Gets the insurance risk.
	 * 
	 * @return the insurance risk
	 */
	@XmlTransient
	// parent
	public InsuranceRisk getInsuranceRisk() {
		return this.insuranceRisk;
	}

	/**
	 * Sets the insurance risk.
	 * 
	 * @param aInsuranceRisk the new insurance risk
	 */
	public void setInsuranceRisk(InsuranceRisk aInsuranceRisk) {
		AssociationsHelper.updateOneToOneFields(aInsuranceRisk, InsuranceRisk.class, "vehicle", this, Vehicle.class,
				"insuranceRisk");
	}

	/**
	 * Gets the list price new.
	 * 
	 * @return the list price new
	 */
	public Integer getListPriceNew() {
		return this.listPriceNew;
	}

	/**
	 * Sets the list price new.
	 * 
	 * @param listPriceNewAmount the new list price new
	 */
	public void setListPriceNew(Integer listPriceNewAmount) {
		this.listPriceNew = listPriceNewAmount;
	}

	/**
	 * Gets the vehicle body type.
	 * 
	 * @return the vehicle body type
	 */
	public String getVehicleBodyType() {
		return this.vehicleBodyType;
	}

	/**
	 * Sets the vehicle body type.
	 * 
	 * @param vehicleBodyTypeCode the new vehicle body type
	 */
	public void setVehicleBodyType(String vehicleBodyTypeCode) {
		this.vehicleBodyType = vehicleBodyTypeCode;
	}

	/**
	 * Gets the type of machinery equipment code.
	 * 
	 * @return the type of machinery equipment code
	 */
	public String getTypeOfMachineryEquipmentCode() {
		return this.typeOfMachineryEquipmentCode;
	}

	/**
	 * Sets the type of machinery equipment code.
	 * 
	 * @param typeMachineryEquipCode the new type of machinery equipment code
	 */
	public void setTypeOfMachineryEquipmentCode(String typeMachineryEquipCode) {
		this.typeOfMachineryEquipmentCode = typeMachineryEquipCode;
	}

	/**
	 * Gets the type of machinery equipment code additional.
	 * 
	 * @return the type of machinery equipment code additional
	 */
	public String getTypeOfMachineryEquipmentCodeAdditional() {
		return this.typeOfMachineryEquipmentCodeAdditional;
	}

	/**
	 * Sets the type of machinery equipment code additional.
	 * 
	 * @param typeMachineryEquipAddCode the new type of machinery equipment code additional
	 */
	public void setTypeOfMachineryEquipmentCodeAdditional(String typeMachineryEquipAddCode) {
		this.typeOfMachineryEquipmentCodeAdditional = typeMachineryEquipAddCode;
	}

	/**
	 * Gets the vehicle identification number.
	 * 
	 * @return the vehicle identification number
	 */
	public String getVehicleIdentificationNumber() {
		return this.vehicleIdentificationNumber;
	}

	/**
	 * Sets the vehicle identification number.
	 * 
	 * @param aVehicleIdentificationNumber the new vehicle identification number
	 */
	public void setVehicleIdentificationNumber(String aVehicleIdentificationNumber) {
		this.vehicleIdentificationNumber = aVehicleIdentificationNumber;
	}

	/**
	 * Gets the purchase date.
	 * 
	 * @return the purchase date
	 */
	public Date getVehiclePurchaseDate() {
		return this.vehiclePurchaseDate;
	}

	/**
	 * Sets the purchase date.
	 * 
	 * @param aVehiclePurchaseDate the new purchase date
	 */
	public void setVehiclePurchaseDate(Date aVehiclePurchaseDate) {
		this.vehiclePurchaseDate = aVehiclePurchaseDate;
	}

	/**
	 * Gets the purchase price.
	 * 
	 * @return the purchase price
	 */
	public Integer getVehiclePurchasePrice() {
		return this.vehiclePurchasePrice;
	}

	/**
	 * Sets the purchase price.
	 * 
	 * @param vehiclePurchasePriceAmount the new purchase price
	 */
	public void setVehiclePurchasePrice(Integer vehiclePurchasePriceAmount) {
		this.vehiclePurchasePrice = vehiclePurchasePriceAmount;
	}

	/**
	 * Gets the vehicle usage.
	 * 
	 * @return the vehicle usage
	 */
	public UseOfVehicleCodeEnum getVehicleUsage() {
		return this.vehicleUsage;
	}

	/**
	 * Sets the vehicle usage.
	 * 
	 * @param useOfVehicleCode the new vehicle usage
	 */
	public void setVehicleUsage(UseOfVehicleCodeEnum useOfVehicleCode) {
		this.vehicleUsage = useOfVehicleCode;
	}

	/**
	 * Gets the vehicle usage description.
	 * 
	 * @return the vehicle usage description
	 */
	public String getVehicleUsageDescription() {
		return this.vehicleUsageDescription;
	}

	/**
	 * Sets the vehicle usage description.
	 * 
	 * @param vehicleUsageDesc the new vehicle usage description
	 */
	public void setVehicleUsageDescription(String vehicleUsageDesc) {
		this.vehicleUsageDescription = vehicleUsageDesc;
	}

	/**
	 * Gets the other province of usage.
	 * 
	 * @return the other province of usage
	 */
	public OtherProvinceOfUseCodeEnum getOtherProvinceOfUsage() {
		return this.otherProvinceOfUsage;
	}

	/**
	 * Sets the other province of usage.
	 * 
	 * @param otherProvinceOfUseCode the new other province of usage
	 */
	public void setOtherProvinceOfUsage(OtherProvinceOfUseCodeEnum otherProvinceOfUseCode) {
		this.otherProvinceOfUsage = otherProvinceOfUseCode;
	}

	/**
	 * Gets the used outside province or country.
	 * 
	 * @return the used outside province or country
	 */
	public Boolean getUsedOutsideProvinceOrCountryIndicator() {
		return this.usedOutsideProvinceOrCountryIndicator;
	}

	/**
	 * Sets the used outside province or country.
	 * 
	 * @param useOutProvOrCountryIndicator the new used outside province or country
	 */
	public void setUsedOutsideProvinceOrCountryIndicator(Boolean useOutProvOrCountryIndicator) {
		this.usedOutsideProvinceOrCountryIndicator = useOutProvOrCountryIndicator;
	}

	/**
	 * Gets the outside province usage percentage.
	 * 
	 * @return the outside province usage percentage
	 */
	public Short getPercentageUseOutsideOfProvince() {
		return this.percentageUseOutsideOfProvince;
	}

	/**
	 * Sets the outside province usage percentage.
	 * 
	 * @param useOutsideOfProvincePercentage the new outside province usage percentage
	 */
	public void setPercentageUseOutsideOfProvince(Short useOutsideOfProvincePercentage) {
		this.percentageUseOutsideOfProvince = useOutsideOfProvincePercentage;
	}

	/**
	 * Gets the outside province usage purpose.
	 * 
	 * @return the outside province usage purpose
	 */
	public PurposeUseOutsideOfPvCodeEnum getPurposeUseOutsideOfProvince() {
		return this.purposeUseOutsideOfProvince;
	}

	/**
	 * Sets the outside province usage purpose.
	 * 
	 * @param purposeUseOutsideOfPvCode the new outside province usage purpose
	 */
	public void setPurposeUseOutsideOfProvince(PurposeUseOutsideOfPvCodeEnum purposeUseOutsideOfPvCode) {
		this.purposeUseOutsideOfProvince = purposeUseOutsideOfPvCode;
	}

	/**
	 * Gets the condition of vehicle when bought.
	 * 
	 * @return the condition of vehicle when bought
	 */
	public ConditionVehicleWhenBoughtCodeEnum getConditionOfVehicleWhenBought() {
		return this.conditionOfVehicleWhenBought;
	}

	/**
	 * Sets the condition of vehicle when bought.
	 * 
	 * @param conditionVehWhenBoughtCode the new condition of vehicle when bought
	 */
	public void setConditionOfVehicleWhenBought(ConditionVehicleWhenBoughtCodeEnum conditionVehWhenBoughtCode) {
		this.conditionOfVehicleWhenBought = conditionVehWhenBoughtCode;
	}

	/**
	 * Gets the number of kilometers to drive to work.
	 * 
	 * @return the number of kilometers to drive to work
	 */
	public Integer getNumberOfKilometersToDriveToWork() {
		return this.numberOfKilometersToDriveToWork;
	}

	/**
	 * Sets the number of kilometers to drive to work.
	 * 
	 * @param nbrOfKmDriveToWork the new number of kilometers to drive to work
	 */
	public void setNumberOfKilometersToDriveToWork(Integer nbrOfKmDriveToWork) {
		this.numberOfKilometersToDriveToWork = nbrOfKmDriveToWork;
	}

	/**
	 * Gets the annual kilometers.
	 * 
	 * @return the annual kilometers
	 */
	public Integer getAnnualKilometers() {
		return this.annualKilometers;
	}

	/**
	 * Sets the annual kilometers.
	 * 
	 * @param annualKm the new annual kilometers
	 */
	public void setAnnualKilometers(Integer annualKm) {
		this.annualKilometers = annualKm;
	}

	/**
	 * Gets the annual business kilometers.
	 * 
	 * @return the annual business kilometers
	 */
	public Integer getAnnualBusinessKilometers() {
		return this.annualBusinessKilometers;
	}

	/**
	 * Sets the annual business kilometers.
	 * 
	 * @param annualBusinessKm the new annual business kilometers
	 */
	public void setAnnualBusinessKilometers(Integer annualBusinessKm) {
		this.annualBusinessKilometers = annualBusinessKm;
	}

	/**
	 * Gets the odometer reading.
	 * 
	 * @return the odometer reading
	 */
	public Integer getOdometerReading() {
		return this.odometerReading;
	}

	/**
	 * Sets the odometer reading.
	 * 
	 * @param aOdometerReading the new odometer reading
	 */
	public void setOdometerReading(Integer aOdometerReading) {
		this.odometerReading = aOdometerReading;
	}

	/**
	 * Gets the fuel used by vehicle.
	 * 
	 * @return the fuel used by vehicle
	 */
	public FuelUsedByVehicleCodeEnum getFuelUsedByVehicle() {
		return this.fuelUsedByVehicle;
	}

	/**
	 * Sets the fuel used by vehicle.
	 * 
	 * @param fuelUsedByVehicleCode the new fuel used by vehicle
	 */
	public void setFuelUsedByVehicle(FuelUsedByVehicleCodeEnum fuelUsedByVehicleCode) {
		this.fuelUsedByVehicle = fuelUsedByVehicleCode;
	}

	/**
	 * Gets the additional equipment or modification installed.
	 * 
	 * @return the additional equipment or modification installed
	 */
	public Boolean getIndicatorOfAdditionalEquipementOrModification() {
		return this.indicatorOfAdditionalEquipementOrModification;
	}

	/**
	 * Sets the additional equipment or modification installed.
	 * 
	 * @param addlEqpmntOrMdfctnIndicator the new additional equipment or modification installed
	 */
	public void setIndicatorOfAdditionalEquipementOrModification(Boolean addlEqpmntOrMdfctnIndicator) {
		this.indicatorOfAdditionalEquipementOrModification = addlEqpmntOrMdfctnIndicator;
	}

	/**
	 * Gets the value of vehicle modification.
	 * 
	 * @return the value of vehicle modification
	 */
	public Integer getValueOfVehicleModification() {
		return this.valueOfVehicleModification;
	}

	/**
	 * Sets the value of vehicle modification.
	 * 
	 * @param valueOfVehModificationAmount the new value of vehicle modification
	 */
	public void setValueOfVehicleModification(Integer valueOfVehModificationAmount) {
		this.valueOfVehicleModification = valueOfVehModificationAmount;
	}

	/**
	 * Gets the value of custom paint job.
	 * 
	 * @return the value of custom paint job
	 */
	public Integer getValueOfCustomPaintJob() {
		return this.valueOfCustomPaintJob;
	}

	/**
	 * Sets the value of custom paint job.
	 * 
	 * @param valueOfCustomPaintJobAmount the new value of custom paint job
	 */
	public void setValueOfCustomPaintJob(Integer valueOfCustomPaintJobAmount) {
		this.valueOfCustomPaintJob = valueOfCustomPaintJobAmount;
	}

	/**
	 * Gets the high value vehicle modification indicator.
	 * 
	 * @return the high value vehicle modification indicator
	 */
	public Boolean getHighValueVehicleModificationIndicator() {
		return this.highValueVehicleModificationIndicator;
	}

	/**
	 * Sets the high value vehicle modification indicator.
	 * 
	 * @param highValueVehicleModIndicator the new high value vehicle modification indicator
	 */
	public void setHighValueVehicleModificationIndicator(Boolean highValueVehicleModIndicator) {
		this.highValueVehicleModificationIndicator = highValueVehicleModIndicator;
	}

	/**
	 * Gets the performance vehicle modification indicator.
	 * 
	 * @return the performance vehicle modification indicator
	 */
	public Boolean getPerformanceVehicleModificationIndicator() {
		return this.performanceVehicleModificationIndicator;
	}

	/**
	 * Sets the performance vehicle modification indicator.
	 * 
	 * @param performanceVehicleModIndicator the new performance vehicle modification indicator
	 */
	public void setPerformanceVehicleModificationIndicator(Boolean performanceVehicleModIndicator) {
		this.performanceVehicleModificationIndicator = performanceVehicleModIndicator;
	}

	/**
	 * Gets the vehicle change restriction indicator.
	 * 
	 * @return the vehicle change restriction indicator
	 */
	public Boolean getVehicleChangeRestrictionIndicator() {
		return this.vehicleChangeRestrictionIndicator;
	}

	/**
	 * Sets the vehicle change restriction indicator.
	 * 
	 * @param vehModificationRestrictIndicator the new vehicle change restriction indicator
	 */
	public void setVehicleChangeRestrictionIndicator(Boolean vehModificationRestrictIndicator) {
		this.vehicleChangeRestrictionIndicator = vehModificationRestrictIndicator;
	}

	/**
	 * Gets the vehicle age.
	 * 
	 * @return the vehicle age
	 */
	public Short getVehicleAge() {
		return this.vehicleAge;
	}

	/**
	 * Sets the vehicle age.
	 * 
	 * @param aVehicleAge the new vehicle age
	 */
	public void setVehicleAge(Short aVehicleAge) {
		this.vehicleAge = aVehicleAge;
	}

	/**
	 * Gets the leasedVehicleIndicator.
	 * 
	 * @return the leasedVehicleIndicator
	 */
	public Boolean getLeasedVehicleIndicator() {
		return this.leasedVehicleIndicator;
	}

	/**
	 * Sets the leasedVehicleIndicator.
	 * 
	 * @param aLeasedVehicleIndicator the a leased vehicle indicator
	 */
	public void setLeasedVehicleIndicator(Boolean aLeasedVehicleIndicator) {
		this.leasedVehicleIndicator = aLeasedVehicleIndicator;
	}

	/**
	 * Gets the replacement cost proof ind.
	 * 
	 * @return the replacement cost proof ind
	 */
	public Boolean getReplacementCostProofIndicator() {
		return this.replacementCostProofIndicator;
	}

	/**
	 * Sets the replacement cost proof ind.
	 * 
	 * @param aReplacementCostProofIndicator the new replacement cost proof ind
	 */
	public void setReplacementCostProofIndicator(Boolean aReplacementCostProofIndicator) {
		this.replacementCostProofIndicator = aReplacementCostProofIndicator;
	}

	/**
	 * Gets the unrepaired damage ind.
	 * 
	 * @return the unrepaired damage ind
	 */
	public Boolean getUnrepairedDamageIndicator() {
		return this.unrepairedDamageIndicator;
	}

	/**
	 * Sets the unrepaired damage ind.
	 * 
	 * @param aUnrepairedDamageIndicator the new unrepaired damage ind
	 */
	public void setUnrepairedDamageIndicator(Boolean aUnrepairedDamageIndicator) {
		this.unrepairedDamageIndicator = aUnrepairedDamageIndicator;
	}

	/**
	 * Gets the recreational motorcycle discount ind.
	 * 
	 * @return the recreational motorcycle discount ind
	 */
	public Boolean getRecreationalMotorcycleDiscountIndicator() {
		return this.recreationalMotorcycleDiscountIndicator;
	}

	/**
	 * Sets the recreational motorcycle discount ind.
	 * 
	 * @param rcrtnlMotorcycleDiscountIndicator the new recreational motorcycle discount ind
	 */
	public void setRecreationalMotorcycleDiscountIndicator(Boolean rcrtnlMotorcycleDiscountIndicator) {
		this.recreationalMotorcycleDiscountIndicator = rcrtnlMotorcycleDiscountIndicator;
	}

	/**
	 * Gets the carry explosive radioactive ind.
	 * 
	 * @return the carry explosive radioactive ind
	 */
	public Boolean getCarryExplosiveRadioactiveIndicator() {
		return this.carryExplosiveRadioactiveIndicator;
	}

	/**
	 * Sets the carry explosive radioactive ind.
	 * 
	 * @param carryExplRadioactiveIndicator the new carry explosive radioactive ind
	 */
	public void setCarryExplosiveRadioactiveIndicator(Boolean carryExplRadioactiveIndicator) {
		this.carryExplosiveRadioactiveIndicator = carryExplRadioactiveIndicator;
	}

	/**
	 * Gets the vehicle rate group.
	 * 
	 * @return the vehicle rate group
	 */
	public String getVehicleRateGroup() {
		return this.vehicleRateGroup;
	}

	/**
	 * Sets the vehicle rate group.
	 * 
	 * @param vehicleRateGroupCode the new vehicle rate group
	 */
	public void setVehicleRateGroup(String vehicleRateGroupCode) {
		this.vehicleRateGroup = vehicleRateGroupCode;
	}

	/**
	 * Set the vehiculeRateGroup on the data member corresponding to a:
	 * 
	 * Province+DistributionChannel+coverageCode
	 * 
	 * Note that at this very moment the coverage code used are already unique by province and Distribution channel..
	 * and this implementation is using the coverage code only...
	 * 
	 * @param manuContext the manu context
	 * @param coveragecode the coveragecode
	 * @param vehicleRateGroupCode the vehicle rate group code
	 */
	public void setSpecificRateGroup(String coveragecode, String vehicleRateGroupCode) {

		if (BasicCoverageCodeEnum.ACCIDENT_BENEFITS_P1.getCode().equals(coveragecode)) {
			this.setVehicleRateGroupMedicalExpenses(vehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.OPTIONAL_INCOME_REPLACEMENT_P2.getCode().equals(coveragecode)) {
			this.setVehicleRateGroupTotalDisability(vehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.LIABILITY_A.getCode().equals(coveragecode)) {
			this.setVehicleRateGroupLiability(vehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.ALL_PERILS_B1.getCode().equals(coveragecode)
				|| BasicCoverageCodeEnum.ALL_PERILS_C1.getCode().equals(coveragecode)) {
			this.setVehicleRateGroupAllPerils(vehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.COLLISION_B2.getCode().equals(coveragecode)
				|| BasicCoverageCodeEnum.COLLISION_C2.getCode().equals(coveragecode)) {
			this.setVehicleRateGroupCollision(vehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.COMPREHENSIVE_B3.getCode().equals(coveragecode)
				|| BasicCoverageCodeEnum.COMPREHENSIVE_C3.getCode().equals(coveragecode)) {
			this.setVehicleRateGroupComprehensive(vehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.SPECIFIED_PERILS_B4.getCode().equals(coveragecode)
				|| BasicCoverageCodeEnum.SPECIFIED_PERILS_C4.getCode().equals(coveragecode)) {
			this.setVehicleRateGroupSpecifiedPerils(vehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.ACCIDENT_BENEFITS_B.getCode().equals(coveragecode)) {
			this.setVehicleRateGroupAccidentBenefit(vehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.LIABILITY_BODILY_INJURY_A1.getCode().equals(coveragecode)) {
			this.setVehicleRateGroupLiabilityBodilyInjury(vehicleRateGroupCode);
		} else if (BasicCoverageCodeEnum.DIRECT_COMP_PROPERTY_DAM_A2.getCode().equals(coveragecode)) {
			this.setVehicleRateGroupLiabilityPropertyDamage(vehicleRateGroupCode);
		}
	}

	/**
	 * Gets the vehicle rate group liability bodily injury.
	 * 
	 * @return the vehicle rate group liability bodily injury
	 */
	public String getVehicleRateGroupLiabilityBodilyInjury() {
		return this.vehicleRateGroupLiabilityBodilyInjury;
	}

	/**
	 * Sets the vehicle rate group liability bodily injury.
	 * 
	 * @param vehRtGrpLbltyBdlyInjryCode the new vehicle rate group liability bodily injury
	 */
	public void setVehicleRateGroupLiabilityBodilyInjury(String vehRtGrpLbltyBdlyInjryCode) {
		this.vehicleRateGroupLiabilityBodilyInjury = vehRtGrpLbltyBdlyInjryCode;
	}

	/**
	 * Gets the vehicle rate group liability property damage.
	 * 
	 * @return the vehicle rate group liability property damage
	 */
	public String getVehicleRateGroupLiabilityPropertyDamage() {
		return this.vehicleRateGroupLiabilityPropertyDamage;
	}

	/**
	 * Sets the vehicle rate group liability property damage.
	 * 
	 * @param vehRtGrpLbltyPrptyDmdCode the new vehicle rate group liability property damage
	 */
	public void setVehicleRateGroupLiabilityPropertyDamage(String vehRtGrpLbltyPrptyDmdCode) {
		this.vehicleRateGroupLiabilityPropertyDamage = vehRtGrpLbltyPrptyDmdCode;
	}

	/**
	 * Gets the vehicle rate group accident benefit.
	 * 
	 * @return the vehicle rate group accident benefit
	 */
	public String getVehicleRateGroupAccidentBenefit() {
		return this.vehicleRateGroupAccidentBenefit;
	}

	/**
	 * Sets the vehicle rate group accident benefit.
	 * 
	 * @param vehRtGrpAcdntBnftCode the new vehicle rate group accident benefit
	 */
	public void setVehicleRateGroupAccidentBenefit(String vehRtGrpAcdntBnftCode) {
		this.vehicleRateGroupAccidentBenefit = vehRtGrpAcdntBnftCode;
	}

	/**
	 * Gets the vehicle rate group all perils.
	 * 
	 * @return the vehicle rate group all perils
	 */
	public String getVehicleRateGroupAllPerils() {
		return this.vehicleRateGroupAllPerils;
	}

	/**
	 * Sets the vehicle rate group all perils.
	 * 
	 * @param vehRtGrpAllPerilsCode the new vehicle rate group all perils
	 */
	public void setVehicleRateGroupAllPerils(String vehRtGrpAllPerilsCode) {
		this.vehicleRateGroupAllPerils = vehRtGrpAllPerilsCode;
	}

	/**
	 * Gets the vehicle rate group collision.
	 * 
	 * @return the vehicle rate group collision
	 */
	public String getVehicleRateGroupCollision() {
		return this.vehicleRateGroupCollision;
	}

	/**
	 * Sets the vehicle rate group collision.
	 * 
	 * @param vehRtGrpCollisionCode the new vehicle rate group collision
	 */
	public void setVehicleRateGroupCollision(String vehRtGrpCollisionCode) {
		this.vehicleRateGroupCollision = vehRtGrpCollisionCode;
	}

	/**
	 * Gets the vehicle rate group comprehensive.
	 * 
	 * @return the vehicle rate group comprehensive
	 */
	public String getVehicleRateGroupComprehensive() {
		return this.vehicleRateGroupComprehensive;
	}

	/**
	 * Sets the vehicle rate group comprehensive.
	 * 
	 * @param vehRtGrpComprehensiveCode the new vehicle rate group comprehensive
	 */
	public void setVehicleRateGroupComprehensive(String vehRtGrpComprehensiveCode) {
		this.vehicleRateGroupComprehensive = vehRtGrpComprehensiveCode;
	}

	/**
	 * Gets the vehicle rate group specified perils.
	 * 
	 * @return the vehicle rate group specified perils
	 */
	public String getVehicleRateGroupSpecifiedPerils() {
		return this.vehicleRateGroupSpecifiedPerils;
	}

	/**
	 * Sets the vehicle rate group specified perils.
	 * 
	 * @param vehRtGrpSpecifiedPerilsCode the new vehicle rate group specified perils
	 */
	public void setVehicleRateGroupSpecifiedPerils(String vehRtGrpSpecifiedPerilsCode) {
		this.vehicleRateGroupSpecifiedPerils = vehRtGrpSpecifiedPerilsCode;
	}

	/**
	 * Gets the vehicle rate group liability.
	 * 
	 * @return the vehicle rate group liability
	 */
	public String getVehicleRateGroupLiability() {
		return this.vehicleRateGroupLiability;
	}

	/**
	 * Sets the vehicle rate group liability.
	 * 
	 * @param vehRtGrpLbltyCode the new vehicle rate group liability
	 */
	public void setVehicleRateGroupLiability(String vehRtGrpLbltyCode) {
		this.vehicleRateGroupLiability = vehRtGrpLbltyCode;
	}

	/**
	 * Gets the vehicle rate group medical expenses.
	 * 
	 * @return the vehicle rate group medical expenses
	 */
	public String getVehicleRateGroupMedicalExpenses() {
		return this.vehicleRateGroupMedicalExpenses;
	}

	/**
	 * Sets the vehicle rate group medical expenses.
	 * 
	 * @param vehRtGrpMedicalExpensesCode the new vehicle rate group medical expenses
	 */
	public void setVehicleRateGroupMedicalExpenses(String vehRtGrpMedicalExpensesCode) {
		this.vehicleRateGroupMedicalExpenses = vehRtGrpMedicalExpensesCode;
	}

	/**
	 * Gets the vehicle rate group total disability.
	 * 
	 * @return the vehicle rate group total disability
	 */
	public String getVehicleRateGroupTotalDisability() {
		return this.vehicleRateGroupTotalDisability;
	}

	/**
	 * Sets the vehicle rate group total disability.
	 * 
	 * @param vehRtGrpTotalDisabilityCode the new vehicle rate group total disability
	 */
	public void setVehicleRateGroupTotalDisability(String vehRtGrpTotalDisabilityCode) {
		this.vehicleRateGroupTotalDisability = vehRtGrpTotalDisabilityCode;
	}

	/**
	 * Gets the parking type.
	 * 
	 * @return the parking type
	 */
	public ParkingTypeCodeEnum getParkingType() {
		return this.parkingType;
	}

	/**
	 * Sets the parking type.
	 * 
	 * @param parkingTypeCode the new parking type
	 */
	public void setParkingType(ParkingTypeCodeEnum parkingTypeCode) {
		this.parkingType = parkingTypeCode;
	}

	/**
	 * Gets the vehicle equipments.
	 * 
	 * @return the vehicle equipments
	 */
	@XmlElementWrapper(name = "vehicleEquipments")
	@XmlElement(name = "vehicleEquipment")
	public Set<VehicleEquipment> getVehicleEquipments() {
		return this.vehicleEquipments;
	}

	/**
	 * Sets the vehicle equipments.
	 * 
	 * @param aVehicleEquipments the new vehicle equipments
	 */
	protected void setVehicleEquipments(Set<VehicleEquipment> aVehicleEquipments) {
		this.vehicleEquipments = aVehicleEquipments;
	}

	/**
	 * Adds the vehicle equipment.
	 * 
	 * @param equipment the equipment
	 */
	public void addVehicleEquipment(com.ing.canada.plp.domain.vehicle.VehicleEquipment equipment) {
		AssociationsHelper.updateOneToManyFields(this, "vehicleEquipments", equipment, "vehicle");
	}

	/**
	 * Removes the vehicle equipment.
	 * 
	 * @param equipment the equipment
	 */
	public void removeVehicleEquipment(com.ing.canada.plp.domain.vehicle.VehicleEquipment equipment) {
		AssociationsHelper.updateOneToManyFields(null, "vehicleEquipments", equipment, "vehicle");
	}

	/**
	 * Gets the vehicle modifications.
	 * 
	 * @return the vehicle modifications
	 */
	@XmlElementWrapper(name = "vehicleModifications")
	@XmlElement(name = "vehicleModification")
	public Set<VehicleModification> getVehicleModifications() {
		return this.vehicleModifications;
	}

	/**
	 * Sets the vehicle modifications.
	 * 
	 * @param aVehicleModifications the new vehicle modifications
	 */
	protected void setVehicleModifications(Set<VehicleModification> aVehicleModifications) {
		this.vehicleModifications = aVehicleModifications;
	}

	/**
	 * Adds the vehicle modification.
	 * 
	 * @param modification the modification
	 */
	public void addVehicleModification(com.ing.canada.plp.domain.vehicle.VehicleModification modification) {
		AssociationsHelper.updateOneToManyFields(this, "vehicleModifications", modification, "vehicle");
	}

	/**
	 * Removes the vehicle modification.
	 * 
	 * @param modification the modification
	 */
	public void removeVehicleModification(com.ing.canada.plp.domain.vehicle.VehicleModification modification) {
		AssociationsHelper.updateOneToManyFields(null, "vehicleModifications", modification, "vehicle");
	}

	/**
	 * Clears the VehicleModifications collection
	 */
	public void clearVehicleModifications() {
		Set<VehicleModification> temp = new HashSet<VehicleModification>(this.vehicleModifications);

		for (VehicleModification modification : temp) {
			this.removeVehicleModification(modification);
		}

	}

	/**
	 * Gets the anti theft devices.
	 * 
	 * @return the anti theft devices
	 */
	@XmlElementWrapper(name = "antiTheftDevices")
	@XmlElement(name = "antiTheftDevice")
	public Set<AntiTheftDevice> getAntiTheftDevices() {
		return this.antiTheftDevices;
	}

	/**
	 * Sets the anti theft devices.
	 * 
	 * @param aAntiTheftDevices the new anti theft devices
	 */
	protected void setAntiTheftDevices(Set<AntiTheftDevice> aAntiTheftDevices) {
		this.antiTheftDevices = aAntiTheftDevices;
	}

	/**
	 * Adds the anti theft device.
	 * 
	 * @param antiTheftDevice the anti theft device
	 */
	public void addAntiTheftDevice(com.ing.canada.plp.domain.vehicle.AntiTheftDevice antiTheftDevice) {
		AssociationsHelper.updateOneToManyFields(this, "antiTheftDevices", antiTheftDevice, "vehicle");
	}

	/**
	 * Removes the anti theft device.
	 * 
	 * @param antiTheftDevice the anti theft device
	 */
	public void removeAntiTheftDevice(com.ing.canada.plp.domain.vehicle.AntiTheftDevice antiTheftDevice) {
		AssociationsHelper.updateOneToManyFields(null, "antiTheftDevices", antiTheftDevice, "vehicle");
	}

	/**
	 * Gets the trailers.
	 * 
	 * @return the trailers
	 */
	@XmlElementWrapper(name = "trailers")
	@XmlElement(name = "trailer")
	public Set<Trailer> getTrailers() {
		return this.trailers;
	}

	/**
	 * Sets the trailers.
	 * 
	 * @param aTrailers the new trailers
	 */
	protected void setTrailers(Set<Trailer> aTrailers) {
		this.trailers = aTrailers;
	}

	/**
	 * Adds the trailer.
	 * 
	 * @param aTrailer the a trailer
	 */
	public void addTrailer(Trailer aTrailer) {
		AssociationsHelper.updateOneToManyFields(this, "trailers", aTrailer, "vehicle");
	}

	/**
	 * Removes the trailer.
	 * 
	 * @param aTrailer the a trailer
	 */
	public void removeTrailer(Trailer aTrailer) {
		AssociationsHelper.updateOneToManyFields(null, "trailers", aTrailer, "vehicle");
	}

	/**
	 * Gets the additional interest roles.
	 * 
	 * @return the additional interest roles
	 */
	@XmlElementWrapper(name = "additionalInterestRoles")
	@XmlElement(name = "additionalInterestRole")
	public Set<AdditionalInterestRole> getAdditionalInterestRoles() {
		return this.additionalInterestRoles;
	}

	/**
	 * Sets the additional interest roles.
	 * 
	 * @param aAdditionalInterestRoles the new additional interest roles
	 */
	protected void setAdditionalInterestRoles(Set<AdditionalInterestRole> aAdditionalInterestRoles) {
		this.additionalInterestRoles = aAdditionalInterestRoles;
	}

	/**
	 * Adds the additional interest role.
	 * 
	 * @param additionalInterestRole the additional interest role
	 */
	public void addAdditionalInterestRole(AdditionalInterestRole additionalInterestRole) {
		AssociationsHelper.updateOneToManyFields(this, "additionalInterestRoles", additionalInterestRole, "vehicle");
	}

	/**
	 * Removes the additional interest role.
	 * 
	 * @param additionalInterestRole the additional interest role
	 */
	public void removeAdditionalInterestRole(AdditionalInterestRole additionalInterestRole) {
		AssociationsHelper.updateOneToManyFields(null, "additionalInterestRoles", additionalInterestRole, "vehicle");
	}

	/**
	 * Gets the number of kms used outside of province.
	 * 
	 * @return the numberOfKmsUsedOutsideOfProvince
	 */
	public NumberOfKmsUsedOutsideProvinceCodeEnum getNumberOfKmsUsedOutsideOfProvince() {
		return this.numberOfKmsUsedOutsideOfProvince;
	}

	/**
	 * Sets the number of kms used outside of province.
	 * 
	 * @param aNumberOfKmsUsedOutsideOfProvince the numberOfKmsUsedOutsideOfProvince to set
	 */
	public void setNumberOfKmsUsedOutsideOfProvince(
			NumberOfKmsUsedOutsideProvinceCodeEnum aNumberOfKmsUsedOutsideOfProvince) {
		this.numberOfKmsUsedOutsideOfProvince = aNumberOfKmsUsedOutsideOfProvince;
	}

	/**
	 * Gets the number of kms used outside of province business.
	 * 
	 * @return the numberOfKmsUsedOutsideOfProvinceBusiness
	 */
	public NumberOfKmsUsedOutsideProvinceCodeEnum getNumberOfKmsUsedOutsideOfProvinceBusiness() {
		return this.numberOfKmsUsedOutsideOfProvinceBusiness;
	}

	/**
	 * Sets the number of kms used outside of province business.
	 * 
	 * @param aNumberOfKmsUsedOutsideOfProvinceBusiness the numberOfKmsUsedOutsideOfProvinceBusiness to set
	 */
	public void setNumberOfKmsUsedOutsideOfProvinceBusiness(
			NumberOfKmsUsedOutsideProvinceCodeEnum aNumberOfKmsUsedOutsideOfProvinceBusiness) {
		this.numberOfKmsUsedOutsideOfProvinceBusiness = aNumberOfKmsUsedOutsideOfProvinceBusiness;
	}

	/**
	 * Gets the use of vehicle category.
	 * 
	 * @return the use of vehicle category
	 */
	public UseOfVehicleCategoryCodeEnum getUseOfVehicleCategory() {
		return this.useOfVehicleCategory;
	}

	/**
	 * sets the use of vehicle category.
	 * 
	 * @param aUseOfVehicleCategory the a use of vehicle category
	 */
	public void setUseOfVehicleCategory(UseOfVehicleCategoryCodeEnum aUseOfVehicleCategory) {
		this.useOfVehicleCategory = aUseOfVehicleCategory;
	}

	/**
	 * Checks if is alarm system indicator.
	 * 
	 * @return the boolean
	 */
	public Boolean getAlarmSystemIndicator() {
		return this.alarmSystemIndicator;
	}

	/**
	 * Sets the alarm system indicator.
	 * 
	 * @param aAlarmSystemIndicator the new alarm system indicator
	 */
	public void setAlarmSystemIndicator(Boolean aAlarmSystemIndicator) {
		this.alarmSystemIndicator = aAlarmSystemIndicator;
	}

	/**
	 * Checks if is cut off switch indicator.
	 * 
	 * @return the boolean
	 */
	public Boolean getCutOffSwitchIndicator() {
		return this.cutOffSwitchIndicator;
	}

	/**
	 * Sets the cut off switch indicator.
	 * 
	 * @param aCutOffSwitchIndicator the new cut off switch indicator
	 */
	public void setCutOffSwitchIndicator(Boolean aCutOffSwitchIndicator) {
		this.cutOffSwitchIndicator = aCutOffSwitchIndicator;
	}

	/**
	 * Checks if is intensive engraving indicator.
	 * 
	 * @return the boolean
	 */
	public Boolean getIntensiveEngravingIndicator() {
		return this.intensiveEngravingIndicator;
	}

	/**
	 * Sets the intensive engraving indicator.
	 * 
	 * @param aIntensiveEngravingIndicator the new intensive engraving indicator
	 */
	public void setIntensiveEngravingIndicator(Boolean aIntensiveEngravingIndicator) {
		this.intensiveEngravingIndicator = aIntensiveEngravingIndicator;
	}

	/**
	 * Checks if is remote tracking system indicator.
	 * 
	 * @return the boolean
	 */
	public Boolean getRemoteTrackingSystemIndicator() {
		return this.remoteTrackingSystemIndicator;
	}

	/**
	 * Sets the remote tracking system indicator.
	 * 
	 * @param aRemoteTrackingSystemIndicator the new remote tracking system indicator
	 */
	public void setRemoteTrackingSystemIndicator(Boolean aRemoteTrackingSystemIndicator) {
		this.remoteTrackingSystemIndicator = aRemoteTrackingSystemIndicator;
	}

	/**
	 * Gets the original scenario vehicle.
	 * 
	 * @return the original scenario vehicle
	 */
	@XmlTransient
	// reference source
	public Vehicle getOriginalScenarioVehicle() {
		return this.originalScenarioVehicle;
	}

	/**
	 * Sets the original scenario vehicle.
	 * 
	 * @param aOriginalScenarioVehicle the a original scenario vehicle
	 */
	public void setOriginalScenarioVehicle(Vehicle aOriginalScenarioVehicle) {
		this.originalScenarioVehicle = aOriginalScenarioVehicle;
	}

	/**
	 * Gets the add party navigation indicator.
	 * 
	 * @return the add party navigation indicator
	 */
	public Boolean getAddPartyNavigationIndicator() {
		return this.addPartyNavigationIndicator;
	}

	/**
	 * Sets the add the party navigation indicator.
	 * 
	 * @param isAddPartyNavigationIndicator the new add party navigation indicator
	 */
	public void setAddPartyNavigationIndicator(Boolean isAddPartyNavigationIndicator) {
		this.addPartyNavigationIndicator = isAddPartyNavigationIndicator;
	}

	/**
	 * Gets the usage to review by client indicator.
	 * 
	 * @return the usage to review by client indicator
	 */
	public Boolean getUsageToReviewByClientIndicator() {
		return this.usageToReviewByClientIndicator;
	}

	/**
	 * Sets the usage to review by client indicator.
	 * 
	 * @param aUsageToReviewByClientIndicator the new usage to review by client indicator
	 */
	public void setUsageToReviewByClientIndicator(Boolean aUsageToReviewByClientIndicator) {
		this.usageToReviewByClientIndicator = aUsageToReviewByClientIndicator;
	}

	/**
	 * @return the lienHolderIndicator
	 */
	public Boolean getLienHolderIndicator() {
		return this.lienHolderIndicator;
	}

	/**
	 * @param aLienHolderIndicator the lienHolderIndicator to set
	 */
	public void setLienHolderIndicator(Boolean aLienHolderIndicator) {
		this.lienHolderIndicator = aLienHolderIndicator;
	}

	public Integer getVehicleNetWeight() {
		return this.vehicleNetWeight;
	}

	public void setVehicleNetWeight(Integer aVehicleNetWeight) {
		this.vehicleNetWeight = aVehicleNetWeight;
	}

	/**
	 * @return the carryPassengerForCompensationIndicator
	 */
	public Boolean getCarryPassengerForCompensationIndicator() {
		return this.carryPassengerForCompensationIndicator;
	}

	/**
	 * @param aCarryPassengerForCompensationIndicator the carryPassengerForCompensationIndicator to set
	 */
	public void setCarryPassengerForCompensationIndicator(Boolean aCarryPassengerForCompensationIndicator) {
		this.carryPassengerForCompensationIndicator = aCarryPassengerForCompensationIndicator;
	}

	/**
	 * @param purchaseDateByUserIndicator the purchaseDateUserIndicator to set
	 */
	public void setPurchaseDateByUserIndicator(Boolean purchaseDateByUserIndicator) {
		this.purchaseDateByUserIndicator = purchaseDateByUserIndicator;
	}

	/**
	 * @return the purchaseDateUserIndicator
	 */
	public Boolean getPurchaseDateByUserIndicator() {
		return this.purchaseDateByUserIndicator;
	}

	/**
	 * get the UBI_ELIGIBILITY_IND value
	 * 
	 * @return {@link #UBIEligibilityIndicator}
	 */
	public Boolean getUBIEligibilityIndicator() {
		return this.UBIEligibilityIndicator;
	}

	/**
	 * set the UBI_ELIGIBILITY_IND value
	 * 
	 * @param aUBIEligibilityIndicator
	 */
	public void setUBIEligibilityIndicator(Boolean aUBIEligibilityIndicator) {
		this.UBIEligibilityIndicator = aUBIEligibilityIndicator;
	}

	public void removeAllEquipments() {
		if (this.vehicleEquipments != null) {
			for (VehicleEquipment equipment : this.vehicleEquipments) {
				this.removeVehicleEquipment(equipment);
			}
		}
	}

	public void removeAllModifications() {
		if (this.vehicleModifications != null) {
			for (VehicleModification equipment : this.vehicleModifications) {
				this.removeVehicleModification(equipment);
			}
		}
	}

	public String getModel(LanguageCodeEnum language) {

		String model = null;

		if (this.getVehicleDetailSpecificationRepositoryEntry() != null) {
			model = this.getVehicleDetailSpecificationRepositoryEntry().getModel(language);
		}

		return model;
	}
	
	public String getMake(LanguageCodeEnum language) {

		String make = null;

		if (this.getVehicleDetailSpecificationRepositoryEntry() != null) {
			make = this.getVehicleDetailSpecificationRepositoryEntry().getMake(language);
		}

		return make;
	}
	
	public Integer getYear() {
		Integer year = null;

		if (this.getVehicleDetailSpecificationRepositoryEntry() != null) {
			year = this.getVehicleDetailSpecificationRepositoryEntry().getVehicleYear();
		}

		return year;
	}

	public String getCode() {
		String code = null;
		
		if (this.getVehicleDetailSpecificationRepositoryEntry() != null) {
			code = this.getVehicleDetailSpecificationRepositoryEntry().getVehicleRepositoryEntry().getVehicleCode();
		}
		
		return code;
	}

	/**
	 * @return the normalRadiusOfOperationQty
	 */
	public Integer getNormalRadiusOfOperationQty() {
		return this.normalRadiusOfOperationQty;
	}

	/**
	 * @param normalRadiusOfOperationQty the normalRadiusOfOperationQty to set
	 */
	public void setNormalRadiusOfOperationQty(Integer normalRadiusOfOperationQty) {
		this.normalRadiusOfOperationQty = normalRadiusOfOperationQty;
	}

	/**
	 * @return the vehicleBusinessUse
	 */
	public String getVehicleBusinessUse() {
		return this.vehicleBusinessUse;
	}

	/**
	 * @param vehicleBusinessUse the vehicleBusinessUse to set
	 */
	public void setVehicleBusinessUse(String vehicleBusinessUse) {
		this.vehicleBusinessUse = vehicleBusinessUse;
	}
	
	/**
	 * @return the grossVehicleWeightQty
	 */
	public Double getGrossVehicleWeightQty() {
		return this.grossVehicleWeightQty;
	}

	/**
	 * @param grossVehicleWeightQty the grossVehicleWeightQty to set
	 */
	public void setGrossVehicleWeightQty(Double grossVehicleWeightQty) {
		this.grossVehicleWeightQty = grossVehicleWeightQty;
	}

	public String getVehicleRateGroupByValueInd() {
		return this.vehicleRateGroupByValueInd;
	}

	public void setVehicleRateGroupByValueInd(String vehicleRateGroupByValueInd) {
		this.vehicleRateGroupByValueInd = vehicleRateGroupByValueInd;
	}
}
