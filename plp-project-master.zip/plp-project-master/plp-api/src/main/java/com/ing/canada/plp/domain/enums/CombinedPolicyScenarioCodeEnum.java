/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum CombinedPolicyScenarioCodeEnum.
 */
public enum CombinedPolicyScenarioCodeEnum {

	COMBO_POLICY("C"), MONOLINE_POLICY("M"), COMBO_POLICY_TO_BE_APPLIED_AT_RENEWAL("R"), PIP_POLICY("P");

	/**
	 * Instantiates a new combined policy scenario code enum.
	 * 
	 * @param aCode the a code
	 */
	private CombinedPolicyScenarioCodeEnum(String aCode) {
		this.code = aCode;
	}

	/** The code. */
	private String code = null;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the combined policy scenario code enum
	 */
	public static CombinedPolicyScenarioCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (CombinedPolicyScenarioCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
}
