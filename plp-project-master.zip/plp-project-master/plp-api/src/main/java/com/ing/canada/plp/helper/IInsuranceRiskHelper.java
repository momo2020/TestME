/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.helper;

import java.util.Date;
import java.util.List;

import com.ing.canada.plp.domain.enums.DriverTypeCodeEnum;
import com.ing.canada.plp.domain.enums.LanguageCodeEnum;
import com.ing.canada.plp.domain.enums.OwnerTypeCodeEnum;
import com.ing.canada.plp.domain.enums.ProvinceCodeEnum;
import com.ing.canada.plp.domain.insurancerisk.AdditionalInterestRole;
import com.ing.canada.plp.domain.insurancerisk.InsuranceRisk;
import com.ing.canada.plp.domain.party.PartyRoleInRisk;

/**
 * The Interface IInsuranceRiskHelper.
 * 
 * @author Sylvain Bouchard
 */
public interface IInsuranceRiskHelper {

	/**
	 * Get the driver from a vehicle given a type.
	 * 
	 * @param aVehicle The {@link com.ing.canada.plp.domain.vehicle.Vehicle}.
	 * @param aDriverType The {@link DriverTypeCodeEnum}.
	 * 
	 * @return The driver encapsulated in PartyRoleInRisk object
	 */
	PartyRoleInRisk getDriverOfType(InsuranceRisk aRisk, DriverTypeCodeEnum aDriverType);

	List<PartyRoleInRisk> getDriversNotOfType(InsuranceRisk aRisk, DriverTypeCodeEnum aDriverType);

	/**
	 * Gets the drivers from a vehicle given a type.
	 * 
	 * @param aVehicle The {@link com.ing.canada.plp.domain.vehicle.Vehicle}.
	 * @param aDriverType The {@link DriverTypeCodeEnum}.
	 * @return The list of drivers encapsulated in PartyRoleInRisk object
	 */
	List<PartyRoleInRisk> getDriversOfType(InsuranceRisk aRisk, DriverTypeCodeEnum aDriverType);

	/**
	 * @see com.ing.canada.plp.helper.IInsuranceRiskHelper#getAllDrivers(com.ing.canada.plp.domain.insurancerisk.InsuranceRisk)
	 */
	List<PartyRoleInRisk> getAllDrivers(InsuranceRisk aRisk);

	/**
	 * Checks if the principal driver have changed.
	 * 
	 * @param aInsuranceRisk {@link InsuranceRisk}
	 * 
	 * @return true, if the principal driver changed
	 */
	boolean isPrincipalDriverChanged(InsuranceRisk aInsuranceRisk);

	/**
	 * Checks if an endorsement is present on vehicle.
	 * 
	 * @param endorsementList List of {@link com.ing.canada.plp.domain.enums.EndorsementCodeEnum}
	 * @param aInsuranceRisk {@link InsuranceRisk}
	 * 
	 * @return true, if one endorsement is present on vehicle
	 */
	boolean isEndorsementPresentOnVehicle(InsuranceRisk aInsuranceRisk, final Object[] endorsementList);

	/**
	 * Checks if a coverage is present on vehicle.
	 * 
	 * @param coverageList List of {@link com.ing.canada.plp.domain.enums.CoverageTypeCodeEnum}
	 * @param aInsuranceRisk {@link InsuranceRisk}
	 * 
	 * @return true, if one coverage is present on vehicle
	 */
	boolean isCoveragePresentOnVehicle(InsuranceRisk aInsuranceRisk, final Object[] coverageList);

	/**
	 * Gets the partyRoleInRisk for a defined type of owner.
	 * 
	 * @param aRisk the a risk
	 * @param aOwnerTypeCodeEnum the a owner type code enum
	 * 
	 * @return the owner of type
	 */
	PartyRoleInRisk getOwnerOfType(InsuranceRisk aRisk, OwnerTypeCodeEnum aOwnerTypeCodeEnum);

	/**
	 * Gets the good driver indicator value for a specific risk.
	 * 
	 * @param aInsuranceRisk the a insurance risk
	 * @param dateToCompare the date to compare
	 * @param aProvince the province
	 * 
	 * @return the good driver ind
	 */
	boolean getGoodDriverInd(InsuranceRisk aInsuranceRisk, ProvinceCodeEnum aProvince, Date dateToCompare);

	/**
	 * Gets the vehicle make.
	 * 
	 * @param aVehicle the vehicle
	 * @param aLang the language
	 * 
	 * @return the vehicle make
	 */
	String getRiskMake(InsuranceRisk aRisk, LanguageCodeEnum aLanguage);

	/**
	 * Gets the vehicle model.
	 * 
	 * @param aVehicle the vehicle
	 * @param aLang the language
	 * 
	 * @return the vehicle model
	 */
	String getRiskModel(InsuranceRisk aRisk, LanguageCodeEnum aLanguage);

	/**
	 * Gets the vehicle year.
	 * 
	 * @param aVehicle the vehicle
	 * @param aLang the language
	 * 
	 * @return the vehicle year
	 */
	String getRiskYear(InsuranceRisk aRisk);

	/**
	 * Gets the vehicle code.
	 * 
	 * @param aVehicle the a vehicle
	 * 
	 * @return the vehicle code
	 */
	String getRiskCode(InsuranceRisk aRisk);

	/**
	 * Gets the vehicle label.
	 * 
	 * @param aVehicle the vehicle
	 * @param aLanguage the language
	 * 
	 * @return the vehicle label
	 */
	String getRiskLabel(InsuranceRisk aRisk, LanguageCodeEnum aLanguage);

	/**
	 * Gets the vehicle label in "Year Make Model" order (or just "Year Model" is non-PPV).
	 * 
	 * @param aRisk
	 * @param aLanguage
	 * @return
	 */
	String getRiskLabelYMM(InsuranceRisk aRisk, LanguageCodeEnum aLanguage);

	/**
	 * Gets the vehicle label.
	 * 
	 * @param aLanguage the language
	 * @param aYear the year
	 * @param aMake the make
	 * @param aModel the model
	 * 
	 * @return the vehicle label
	 */
	String getRiskLabel(LanguageCodeEnum aLanguage, String aYear, String aMake, String aModel);

	/**
	 * Gets the vehicle label.
	 * 
	 * @param aLanguage the language
	 * @param aYear the year
	 * @param aMake the make
	 * @param aModel the model
	 * 
	 * @return the vehicle label
	 */
	String getRiskLabelNonPPV(LanguageCodeEnum aLanguage, String aYear, String aModel);

	/**
	 * Returns true if the risk is a PPV (Private passenger vehicle)
	 * 
	 * @param aRisk
	 * @return
	 */
	boolean isPPV(InsuranceRisk aRisk);

	/**
	 * Removes all traces of lien holder or lessor info in the database.
	 * 
	 * @param insuranceRisk - {@link InsuranceRisk}
	 * @param additionalInterestRole - {@link AdditionalInterestRole}
	 */
	void removeLienHolderLessor(InsuranceRisk insuranceRisk, AdditionalInterestRole additionalInterestRole);

	/**
	 * Gets the previous info on the lienholder and lessor to remove them from the database.
	 * 
	 * @param insuranceRisk - {@link InsuranceRisk}
	 */
	public void removeLienHolderLessorInfo(InsuranceRisk insuranceRisk);

}
