package com.ing.canada.plp.report.insurancePolicy;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.enums.AgreementFollowUpStatusEnum;
import com.ing.canada.plp.domain.enums.BusinessTransactionActivityCodeEnum;
import com.ing.canada.plp.domain.enums.CombinedPolicyCodeEnum;
import com.ing.canada.plp.domain.enums.CombinedPolicyScenarioCodeEnum;
import com.ing.canada.plp.domain.enums.LanguageCodeEnum;
import com.ing.canada.plp.domain.enums.LineOfBusinessCodeEnum;
import com.ing.canada.plp.domain.enums.TransactionStatusCodeEnum;
import com.ing.canada.plp.domain.usertype.BaseEntity;

/**
 * This class is used to build a real time insurance policy info list for report to brokers.
 */

@Entity
@SqlResultSetMapping(name = "InsurancePolicyBrokerListResultSet", entities = {
		@EntityResult(entityClass = com.ing.canada.plp.report.insurancePolicy.InsurancePolicyBrokerInfo.class, fields = {
				@FieldResult(name = "id", column = "ipId"),
				@FieldResult(name = "auditTrail.createTimestamp", column = "ipTs"),
				@FieldResult(name = "agreementNumber", column = "ipAgreementNb"),
				@FieldResult(name = "agreementLegacyNumber", column = "ipAgreementLegacyNb"),
				@FieldResult(name = "followUpStatusCode", column = "ipFollowUpStatusCd"),
				@FieldResult(name = "expirityDate", column = "ipExpirityDt"),
				@FieldResult(name = "quoteSource", column = "ipExtSystOriginCd"),
				@FieldResult(name = "customerValueIndex1", column = "irocviwithcrt_1"),
				@FieldResult(name = "customerValueIndex2", column = "irocviwithcrt_2"),
				@FieldResult(name = "vehicleClass1", column = "vehicleclass_1"),
				@FieldResult(name = "vehicleClass2", column = "vehicleclass_2"),
				@FieldResult(name = "intactRank", column = "intact_rank"),
				@FieldResult(name = "autoPlus", column = "auto_plus"),
				@FieldResult(name = "inceptionDate", column = "pvInceptionDt"),
				@FieldResult(name = "typeOfResidence", column = "paTypeOfResidence"),
				@FieldResult(name = "combinedPolicyCode", column = "pvCombinedPolicy"),
				@FieldResult(name = "combinedPolicyScenarioCode", column = "pvCombinedPolicyScenario"),
				@FieldResult(name = "ratingDate", column = "pvRatingDt"),
				@FieldResult(name = "firstName", column = "paFname"),
				@FieldResult(name = "lastName", column = "paLname"),
				@FieldResult(name = "birthDate", column = "paBirthDate"),
				@FieldResult(name = "postalCode", column = "addrPostalCode"),
				@FieldResult(name = "bTrxLastUpdateDate", column = "btLastUpdateTs"),
				@FieldResult(name = "bTrxStatusCode", column = "btTransStatusCd"),
				@FieldResult(name = "bTrxActivityCode", column = "btaActivityCd"),
				@FieldResult(name = "subBrokerName1", column = "sbaSubBrokerName1"),
				@FieldResult(name = "subBrokerName2", column = "sbaSubBrokerName2"),
				@FieldResult(name = "subBrokerName3", column = "sbaSubBrokerName3"),
				@FieldResult(name = "subBrokerCity", column = "sbaSubBrokerCity"),
				@FieldResult(name = "lastFollowupNote", column = "lastFollowupNote"),
				@FieldResult(name = "lastActivityNote", column = "lastActivityNote"),
				@FieldResult(name = "languageCommunicationCode", column = "langCommCd"),
				@FieldResult(name = "consent", column = "consent"),
				@FieldResult(name = "roadblockMsg", column = "roadblockMsg") }),

		@EntityResult(entityClass = com.ing.canada.plp.report.insurancePolicy.InsurancePolicyNoteInfo.class, fields = {
				@FieldResult(name = "id", column = "ipnId"),
				@FieldResult(name = "auditTrail.createTimestamp", column = "ipnTs"),
				@FieldResult(name = "note", column = "ipnNote"),
				@FieldResult(name = "authorUID", column = "ipnAuthor"),
				@FieldResult(name = "userActivityType", column = "ipnUserAct") }) })
@NamedNativeQueries({
		@NamedNativeQuery(name = "getInsurancePolicyBrokerListForParamMasters", resultSetMapping = "InsurancePolicyBrokerListResultSet", resultClass = com.ing.canada.plp.report.insurancePolicy.InsurancePolicyBrokerInfo.class, query = " SELECT * "
				+"	FROM (SELECT ipid, "
				+"                               ipts, "
				+"                               ipagreementnb, "
				+"                               ipagreementlegacynb, "
				+"                               ipfollowupstatuscd, "
				+"                               ipexpiritydt, "
				+"                               ipextsystorigincd, "
				+"                               ipnts, "
				+"                               ipnid, "
				+"                               ipnnote, "
				+"                               ipnauthor, "
				+"                               ipnuseract, "
				+"                               pvinceptiondt, "
				+"                               pvratingdt, "
				+"                               INITCAP(pa.first_name_txt) AS pafname, "
				+"                               INITCAP(pa.last_name_txt) AS palname, "
				+"                               pa.birth_dt as paBirthDate, "
				+"                               addr.postal_cd as addrPostalCode,                 "
				+"                               pa.residence_occupancy_cd AS paTypeOfResidence, "
				+"                               pvCombinedPolicy, "
				+"                               pvCombinedPolicyScenario, "
				+"                               btlastupdatets, "
				+"                               bttransstatuscd, "
				+"                               btaactivitycd, "
				+"                               sbasubbroker,                 "
				+"                               sbasubbrokername1, "
				+"                               sbasubbrokername2, "
				+"                               sbasubbrokername3, "
				+"                               sbasubbrokercity, "
				+"                               lastfollowupnote, "
				+"                               lastactivitynote, "
				+"                               langCommCd, "
				+"                               CASE "
				+"                                 WHEN (SELECT COUNT(cst.party_id) "
				+"                                         FROM plpadmin.consent cst "
				+"                                        WHERE cst.party_id= pa.party_id "
				+"                                          AND cst.consent_type_cd = 'QF' "
				+"                                          AND cst.consent_ind = 'N' "
				+"                                      ) >= 1 "
				+"                                 THEN "
				+"                                   'N' "
				+"                                 ELSE "
				+"                                   'Y' "
				+"                               END AS consent, "
				+"                               (SELECT btsaci.attribute_value_txt "
				+"                                  FROM plpadmin.business_trx_sub_activity ibtsa "
				+"                                  INNER JOIN plpadmin.bus_trx_sub_actv_comp_inf btsaci ON ibtsa.business_trx_sub_activity_id = btsaci.business_trx_sub_activity_id "
				+"                                  WHERE ibtsa.business_trx_sub_activity_id = (SELECT MAX(ibtsa2.business_trx_sub_activity_id) "
				+"                                                                                FROM plpadmin.business_trx_sub_activity ibtsa2 "
				+"                                                                               WHERE ibtsa2.business_trx_activity_id = pv.btaBbusiness_trx_activity_id "
				+"                                                                             ) "
				+"                                    AND ibtsa.business_trx_activity_id = pv.btaBbusiness_trx_activity_id "
				+"                                    AND ibtsa.business_trx_sub_activity_cd = 'ROAD_BLOCK' "
				+"                               ) AS roadblockMsg,"
				+"                               irocviwithcrt_1,"
				+"                               irocviwithcrt_2,"
				+"                               vehicleclass_1,"
				+"                               vehicleclass_2,"
				+"                               (SELECT intact_rank"
				+"                                  FROM cifadmin.fsa_broker_locators fsa "
				+"                                 WHERE fsa.sub_broker = sbasubbroker "
				+"                                   AND fsa.fsa = SUBSTR(addr.postal_cd,1,3)"
				+"                                   AND ROWNUM=1"
				+"                               ) AS intact_rank,"
				+"                               CASE "
				+"                               WHEN (SELECT COUNT(1)"
				+"                                       FROM glbadmin.document doc,"
				+"                                            glbadmin.task_document_request  tdr,"
				+"                                            plpadmin.driver_complement_info dci"
				+"                                      WHERE doc.task_document_request_id = tdr.task_document_request_id"
				+"                                        AND doc.mime_type_cd  = 'XML'"
				+"                                        AND tdr.type_cd       = 'ATPL'"
				+"                                        AND tdr.req_status_cd = '4'"
				+"                                        AND tdr.uw_company_cd = 'A'"
				+"                                        AND tdr.req_driving_license_nbr = dci.license_nbr"
				+"                                        AND pa.party_id       = dci.party_id) >= 1 THEN"
				+"                                'Y'"
				+"                             ELSE"
				+"                                'N'"
				+"                             END AS auto_plus"
				+"                          FROM (SELECT ipid, "
				+"                                       ipts, "
				+"                                       ipagreementnb, "
				+"                                       ipagreementlegacynb, "
				+"                                       ipfollowupstatuscd, "
				+"                                       ipexpiritydt, "
				+"                                       ipextsystorigincd, "
				+"                                       ipnts, "
				+"                                       ipnid, "
				+"                                       ipnnote, "
				+"                                       ipnauthor, "
				+"                                       ipnuseract, "
				+"                                       pv.policy_inception_dt AS pvinceptiondt, "
				+"                                       pv.rating_dt AS pvratingdt, "
				+"                                       bt.last_update_ts AS btlastupdatets, "
				+"                                       bt.transaction_status_cd AS bttransstatuscd, "
				+"                                       bta.bsns_trx_activity_cd AS btaactivitycd, "
				+"                                       ip.sbasubbroker, "
				+"                                       sbasubbrokername1, "
				+"                                       sbasubbrokername2, "
				+"                                       sbasubbrokername3, "
				+"                                       sbasubbrokercity, "
				+"                                       lastfollowupnote, "
				+"                                       lastactivitynote, "
				+"                                       pv.language_of_communication_cd AS langCommCd, "
				+"                                       ip.last_pv AS lastPv, "
				+"                                       bta.business_trx_activity_id  AS btaBbusiness_trx_activity_id, "
				+"                                       pv.combined_policy_cd AS pvCombinedPolicy, "
				+"                                       pv.combined_policy_scenario_cd AS pvCombinedPolicyScenario,"
				+"                                       irocviwithcrt_1,"
				+"                                       irocviwithcrt_2,"
				+"                                       vehicleclass_1,"
				+"                                       vehicleclass_2,"
				+"                                       company_number"
				+"                                  FROM (WITH  mv_ip AS (SELECT ip.insurance_policy_id AS ipid, "
				+"                                                               ip.system_create_ts AS ipts, "
				+"                                                               ip.agreement_nbr AS ipagreementnb, "
				+"                                                               ip.agreement_legacy_nbr AS ipagreementlegacynb, "
				+"                                                               ip.agreement_follow_up_status_cd AS ipfollowupstatuscd, "
				+"                                                               ip.quotation_validity_expiry_dt AS ipexpiritydt, "
				+"                                                               ip.external_system_origin_cd AS ipextsystorigincd, "
				+"                                                               ip.quotation_validity_expiry_dt, "
				+"                                                               (SELECT MAX (ipv.policy_version_id) "
				+"                                                                  FROM plpadmin.policy_version ipv "
				+"                                                                 WHERE ipv.insurance_policy_id =  ip.insurance_policy_id "
				+"                                                               )   last_pv, "
				+"                                                               (SELECT MAX (sba.sub_broker_assignment_id) "
				+"                                                                  FROM plpadmin.sub_broker_assignment sba "
				+"                                                                 WHERE sba.insurance_policy_id = ip.insurance_policy_id "
				+"                                                               ) last_sba_id,"
				+"                                                               ip.agreement_follow_up_status_cd"
				+"                                                          FROM plpadmin.insurance_policy ip "
				+"                                                         WHERE (ip.agreement_legacy_nbr IS NULL OR IP.APPLICATION_MODE_CD = 'Q') "
				+"                                                           AND ip.agreement_type_cd = 'QUO' "
				+"                                                           AND ip.manufacturing_context_id = :manufacturerCompanyID "
				+"                                                           AND ip.last_update_ts > SYSDATE - :nbrOfDaysLeft"
				+"                                                           AND (NVL(ip.agreement_follow_up_status_cd,'CONT_BUT_FLW') IN ('CONT_BUT_FLW', 'NOT_CONT')) "
				+"                                                       ) , "
				+"                                              mv_insurance_policy_note AS (SELECT * "
				+"                                                                             FROM plpadmin.insurance_policy_note ipn "
				+"                                                                          ), "
				+"                                              insurance_notes AS (SELECT ipn.insurance_policy_id, "
				+"                                                                         MAX(ipn.insurance_policy_note_id) as insurance_policy_note_id "
				+"                                                                    FROM mv_insurance_policy_note ipn, "
				+"                                                                         mv_ip ip "
				+"                                                                   WHERE ipn.user_activity_type_cd IN ('VIEW_QUO', 'UPLOAD_QUO', 'CHG_FLW_ST') "
				+"                                                                     AND   ip.ipid = ipn.insurance_policy_id "
				+"                                                                   GROUP BY ipn.insurance_policy_id "
				+"                                                                   UNION ALL "
				+"                                                                  SELECT ipn.insurance_policy_id, "
				+"                                                                         MAX(ipn.insurance_policy_note_id) as insurance_policy_note_id "
				+"                                                                    FROM mv_insurance_policy_note ipn, "
				+"                                                                         mv_ip ip "
				+"                                                                   WHERE ipn.user_activity_type_cd in ('ADD_NOTE') "
				+"                                                                     AND   ip.ipid = ipn.insurance_policy_id "
				+"                                                                   GROUP BY ipn.insurance_policy_id "
				+"                                                                 ) , "
				+"                                              subb AS (SELECT sb.sub_broker_web_access_type, "
				+"                                                              sb.company_number, "
				+"                                                              MAX(sba.sub_broker_assignment_id) AS sub_broker_assignment_id, "
				+"                                                              sba.insurance_policy_id, "
				+"                                                              sb.sub_broker_number, "
				+"                                                              sb.sub_broker,     "
				+"                                                              sb.name_line1, "
				+"                                                              sb.name_line2, "
				+"                                                              sb.attending_broker_name_line1, "
				+"                                                              sb.city"
				+"                                                         FROM cifadmin.sub_brokers sb, "
				+"                                                              plpadmin.sub_broker_assignment sba, "
				+"                                                              mv_ip ip "
				+"                                                        WHERE sb.sub_broker = sba.cif_sub_broker_id "
				+"                                                          AND sb.company_number = :subBrokerCompanyNbr "
				+"                                                          AND sb.search_province = :provinceCd"
				+"                                                          AND (sb.sub_broker_web_access_type  IN ('QI', 'QB', 'QIB') or sb.quick_quote_web_access_type IN ('QI', 'QB', 'QIB'))"
				+"                                                          AND ip.ipid = sba.insurance_policy_id "
				+"                                                         GROUP BY sb.sub_broker_web_access_type, sb.company_number,sba.insurance_policy_id, sb.sub_broker_number, sb.sub_broker, sb.name_line1, sb.name_line2,sb.attending_broker_name_line1, sb.city "
				+"                                                      ) ,"
				+"                                              mv_vehicle_cvi1 AS (SELECT iro.cvi_pure_with_credit_qty ,"
				+"                                                                         ir.vehicle_class_cd,"
				+"                                                                         ir.policy_version_id,"
				+"                                                                         ir.insurance_risk_seq "
				+"                                                                    FROM plpadmin.insurance_risk ir, "
				+"                                                                         plpadmin.insurance_risk_offer iro "
				+"                                                                   WHERE iro.insurance_risk_id = ir.insurance_risk_id "
				+"                                                                     AND iro.insurance_risk_offer_id = ir.selected_ins_risk_offer_id "
				+"                                                                     AND iro.selected_for_pol_offer_rat_ind  = 'Y'"
				+"                                                                     AND ir.insurance_risk_seq = 1"
				+"                                                                 ),"
				+"                                              mv_vehicle_cvi2 AS (SELECT iro.cvi_pure_with_credit_qty ,"
				+"                                                                         ir.vehicle_class_cd,"
				+"                                                                         ir.policy_version_id,"
				+"                                                                         ir.insurance_risk_seq "
				+"                                                                    FROM plpadmin.insurance_risk ir, "
				+"                                                                         plpadmin.insurance_risk_offer iro "
				+"                                                                   WHERE iro.insurance_risk_id = ir.insurance_risk_id "
				+"                                                                     AND iro.insurance_risk_offer_id = ir.selected_ins_risk_offer_id "
				+"                                                                     AND iro.selected_for_pol_offer_rat_ind  = 'Y'"
				+"                                                                     AND ir.insurance_risk_seq = 2 "
				+"                                                                 )"
				+"                                        SELECT ipid, "
				+"                                               sb.sub_broker_assignment_id,"
				+"                                               sb.company_number,"
				+"                                               ipn.user_activity_type_cd, "
				+"                                               ipts, "
				+"                                               ipagreementnb, "
				+"                                               ipagreementlegacynb, "
				+"                                               ipfollowupstatuscd, "
				+"                                               ipexpiritydt, "
				+"                                               ipextsystorigincd, "
				+"                                               ipn.system_create_ts AS ipnts, "
				+"                                               ipn.insurance_policy_note_id AS ipnid, "
				+"                                               ipn.insurance_policy_note AS ipnnote, "
				+"                                               ipn.author_u_id AS ipnauthor, "
				+"                                               ipn.user_activity_type_cd AS ipnuseract, "
				+"                                               sb.sub_broker as sbasubbroker, "
				+"                                               sb.name_line1 AS sbasubbrokername1, "
				+"                                               sb.name_line2 AS sbasubbrokername2, "
				+"                                               sb.attending_broker_name_line1 AS sbasubbrokername3, "
				+"                                               sb.city AS sbasubbrokercity, "
				+"                                               NULL AS lastfollowupnote, "
				+"                                               NULL AS lastactivitynote, "
				+"                                               ip.quotation_validity_expiry_dt, "
				+"                                               ip.last_pv,"
				+"                                               vc1.cvi_pure_with_credit_qty irocviwithcrt_1,"
				+"                                               vc2.cvi_pure_with_credit_qty irocviwithcrt_2,"
				+"                                               vc1.vehicle_class_cd vehicleclass_1,"
				+"                                               vc2.vehicle_class_cd vehicleclass_2"
				+"                                          FROM mv_ip ip, "
				+"                                               mv_insurance_policy_note ipn, "
				+"                                               subb sb, "
				+"                                               insurance_notes iipn,"
				+"                                               mv_vehicle_cvi1  vc1,"
				+"                                               mv_vehicle_cvi2  vc2"
				+"                                         WHERE sb.insurance_policy_id = ip.ipid "
				+"                                           AND sb.sub_broker_assignment_id =  ip.last_sba_id "
				+"                                           AND ip.ipid = iipn.insurance_policy_id(+) "
				+"                                           AND ipn.insurance_policy_note_id (+)= iipn.insurance_policy_note_id "
				
				// filter for selected masters 
				
				+"                           				 AND sb.sub_broker_number IN (SELECT bi.subroker_nbr "
				+"                                                          FROM cifadmin.broker_infos bi "
				+"                                                         WHERE bi.master_owner_nbr IN (:masters) "
				+"                                                       ) "
				
				// end filter for selected masters
				
				+"                                           AND vc1.policy_version_id(+) = ip.last_pv"
				+"                                           AND vc2.policy_version_id(+) = ip.last_pv"
				+"                                       )ip, "
				+"                                       plpadmin.policy_version pv, "
				+"                                       plpadmin.business_transaction bt, "
				+"                                       plpadmin.business_trx_activity bta "
				+"                                 WHERE ip.ipid = pv.insurance_policy_id "
				+"                                  AND pv.policy_version_id = ip.last_pv "
				+"                                  AND pv.business_transaction_id = bt.business_transaction_id "
				+"                                  AND NOT (ip.quotation_validity_expiry_dt < SYSDATE AND bt.transaction_status_cd in ('S','I','X', 'J', 'Y')) "
				+"                                  AND bt.transaction_status_cd NOT IN ('A', 'D') "
				+"                                  AND bt.last_update_ts > SYSDATE - :nbrOfDaysLeft "
				+"                                  AND bta.business_trx_activity_id IN (SELECT MAX (ibta.business_trx_activity_id) "
				+"                                                                         FROM plpadmin.business_trx_activity ibta "
				+"                                                                        WHERE bt.business_transaction_id = ibta.business_transaction_id "
				+"                                                                      ) "
				+"                               ) pv, "
				+"                               plpadmin.policy_holder ph, "
				+"                               plpadmin.party pa, "
				+"                               plpadmin.address addr"
				+"                         WHERE pv.lastPv = ph.policy_version_id "
				+"                           AND ph.policy_holder_type_cd = 'P' "
				+"                           AND ph.party_id = pa.party_id "
				+"                           AND addr.party_id = pa.party_id "
				+"                           AND ( EXISTS(SELECT 1 "
				+"                                          FROM plpadmin.consent co "
				+"                                         WHERE pa.party_id = co.party_id "
				+"                                           AND co.consent_ind = 'Y' "
				+"                                           AND co.consent_type_cd = 'PR' "
				+"                                          ) "
				+"                                              OR NOT EXISTS(SELECT 1 "
				+"                                                              FROM plpadmin.consent co "
				+"                                                             WHERE pa.party_id = co.party_id "
				+"                                                               AND co.consent_type_cd = 'PR' "
				+"                                                           ) "
				+"                                           ) "
				+"                      ORDER BY btlastupdatets DESC       )   WHERE ROWNUM <= :maxRow"
				
				),
				
				
				
				
				
		@NamedNativeQuery(name = "getInsurancePolicyBrokerListForAllMasters", resultSetMapping = "InsurancePolicyBrokerListResultSet", resultClass = com.ing.canada.plp.report.insurancePolicy.InsurancePolicyBrokerInfo.class, query = " SELECT * "

	+"	FROM (SELECT ipid, "
	+"                               ipts, "
	+"                               ipagreementnb, "
	+"                               ipagreementlegacynb, "
	+"                               ipfollowupstatuscd, "
	+"                               ipexpiritydt, "
	+"                               ipextsystorigincd, "
	+"                               ipnts, "
	+"                               ipnid, "
	+"                               ipnnote, "
	+"                               ipnauthor, "
	+"                               ipnuseract, "
	+"                               pvinceptiondt, "
	+"                               pvratingdt, "
	+"                               INITCAP(pa.first_name_txt) AS pafname, "
	+"                               INITCAP(pa.last_name_txt) AS palname, "
	+"                               pa.birth_dt as paBirthDate, "
	+"                               addr.postal_cd as addrPostalCode,                 "
	+"                               pa.residence_occupancy_cd AS paTypeOfResidence, "
	+"                               pvCombinedPolicy, "
	+"                               pvCombinedPolicyScenario, "
	+"                               btlastupdatets, "
	+"                               bttransstatuscd, "
	+"                               btaactivitycd, "
	+"                               sbasubbroker,                 "
	+"                               sbasubbrokername1, "
	+"                               sbasubbrokername2, "
	+"                               sbasubbrokername3, "
	+"                               sbasubbrokercity, "
	+"                               lastfollowupnote, "
	+"                               lastactivitynote, "
	+"                               langCommCd, "
	+"                               CASE "
	+"                                 WHEN (SELECT COUNT(cst.party_id) "
	+"                                         FROM plpadmin.consent cst "
	+"                                        WHERE cst.party_id= pa.party_id "
	+"                                          AND cst.consent_type_cd = 'QF' "
	+"                                          AND cst.consent_ind = 'N' "
	+"                                      ) >= 1 "
	+"                                 THEN "
	+"                                   'N' "
	+"                                 ELSE "
	+"                                   'Y' "
	+"                               END AS consent, "
	+"                               (SELECT btsaci.attribute_value_txt "
	+"                                  FROM plpadmin.business_trx_sub_activity ibtsa "
	+"                                  INNER JOIN plpadmin.bus_trx_sub_actv_comp_inf btsaci ON ibtsa.business_trx_sub_activity_id = btsaci.business_trx_sub_activity_id "
	+"                                  WHERE ibtsa.business_trx_sub_activity_id = (SELECT MAX(ibtsa2.business_trx_sub_activity_id) "
	+"                                                                                FROM plpadmin.business_trx_sub_activity ibtsa2 "
	+"                                                                               WHERE ibtsa2.business_trx_activity_id = pv.btaBbusiness_trx_activity_id "
	+"                                                                             ) "
	+"                                    AND ibtsa.business_trx_activity_id = pv.btaBbusiness_trx_activity_id "
	+"                                    AND ibtsa.business_trx_sub_activity_cd = 'ROAD_BLOCK' "
	+"                               ) AS roadblockMsg,"
	+"                               irocviwithcrt_1,"
	+"                               irocviwithcrt_2,"
	+"                               vehicleclass_1,"
	+"                               vehicleclass_2,"
	+"                               (SELECT intact_rank"
	+"                                  FROM cifadmin.fsa_broker_locators fsa "
	+"                                 WHERE fsa.sub_broker = sbasubbroker "
	+"                                   AND fsa.fsa = SUBSTR(addr.postal_cd,1,3)"
	+"                                   AND ROWNUM=1"
	+"                               ) AS intact_rank,"
	+"                               CASE "
	+"                               WHEN (SELECT COUNT(1)"
	+"                                       FROM glbadmin.document doc,"
	+"                                            glbadmin.task_document_request  tdr,"
	+"                                            plpadmin.driver_complement_info dci"
	+"                                      WHERE doc.task_document_request_id = tdr.task_document_request_id"
	+"                                        AND doc.mime_type_cd  = 'XML'"
	+"                                        AND tdr.type_cd       = 'ATPL'"
	+"                                        AND tdr.req_status_cd = '4'"
	+"                                        AND tdr.uw_company_cd = 'A'"
	+"                                        AND tdr.req_driving_license_nbr = dci.license_nbr"
	+"                                        AND pa.party_id       = dci.party_id) >= 1 THEN"
	+"                                'Y'"
	+"                             ELSE"
	+"                                'N'"
	+"                             END AS auto_plus"
	+"                          FROM (SELECT ipid, "
	+"                                       ipts, "
	+"                                       ipagreementnb, "
	+"                                       ipagreementlegacynb, "
	+"                                       ipfollowupstatuscd, "
	+"                                       ipexpiritydt, "
	+"                                       ipextsystorigincd, "
	+"                                       ipnts, "
	+"                                       ipnid, "
	+"                                       ipnnote, "
	+"                                       ipnauthor, "
	+"                                       ipnuseract, "
	+"                                       pv.policy_inception_dt AS pvinceptiondt, "
	+"                                       pv.rating_dt AS pvratingdt, "
	+"                                       bt.last_update_ts AS btlastupdatets, "
	+"                                       bt.transaction_status_cd AS bttransstatuscd, "
	+"                                       bta.bsns_trx_activity_cd AS btaactivitycd, "
	+"                                       ip.sbasubbroker, "
	+"                                       sbasubbrokername1, "
	+"                                       sbasubbrokername2, "
	+"                                       sbasubbrokername3, "
	+"                                       sbasubbrokercity, "
	+"                                       lastfollowupnote, "
	+"                                       lastactivitynote, "
	+"                                       pv.language_of_communication_cd AS langCommCd, "
	+"                                       ip.last_pv AS lastPv, "
	+"                                       bta.business_trx_activity_id  AS btaBbusiness_trx_activity_id, "
	+"                                       pv.combined_policy_cd AS pvCombinedPolicy, "
	+"                                       pv.combined_policy_scenario_cd AS pvCombinedPolicyScenario,"
	+"                                       irocviwithcrt_1,"
	+"                                       irocviwithcrt_2,"
	+"                                       vehicleclass_1,"
	+"                                       vehicleclass_2,"
	+"                                       company_number"
	+"                                  FROM (WITH  mv_ip AS (SELECT ip.insurance_policy_id AS ipid, "
	+"                                                               ip.system_create_ts AS ipts, "
	+"                                                               ip.agreement_nbr AS ipagreementnb, "
	+"                                                               ip.agreement_legacy_nbr AS ipagreementlegacynb, "
	+"                                                               ip.agreement_follow_up_status_cd AS ipfollowupstatuscd, "
	+"                                                               ip.quotation_validity_expiry_dt AS ipexpiritydt, "
	+"                                                               ip.external_system_origin_cd AS ipextsystorigincd, "
	+"                                                               ip.quotation_validity_expiry_dt, "
	+"                                                               (SELECT MAX (ipv.policy_version_id) "
	+"                                                                  FROM plpadmin.policy_version ipv "
	+"                                                                 WHERE ipv.insurance_policy_id =  ip.insurance_policy_id "
	+"                                                               )   last_pv, "
	+"                                                               (SELECT MAX (sba.sub_broker_assignment_id) "
	+"                                                                  FROM plpadmin.sub_broker_assignment sba "
	+"                                                                 WHERE sba.insurance_policy_id = ip.insurance_policy_id "
	+"                                                               ) last_sba_id,"
	+"                                                               ip.agreement_follow_up_status_cd"
	+"                                                          FROM plpadmin.insurance_policy ip "
	+"                                                         WHERE (ip.agreement_legacy_nbr IS NULL OR IP.APPLICATION_MODE_CD = 'Q') "
	+"                                                           AND ip.agreement_type_cd = 'QUO' "
	+"                                                           AND ip.manufacturing_context_id = :manufacturerCompanyID "
	+"                                                           AND ip.last_update_ts > SYSDATE - :nbrOfDaysLeft"
	+"                                                           AND (NVL(ip.agreement_follow_up_status_cd,'CONT_BUT_FLW') IN ('CONT_BUT_FLW', 'NOT_CONT')) "
	+"                                                       ) , "
	+"                                              mv_insurance_policy_note AS (SELECT * "
	+"                                                                             FROM plpadmin.insurance_policy_note ipn "
	+"                                                                          ), "
	+"                                              insurance_notes AS (SELECT ipn.insurance_policy_id, "
	+"                                                                         MAX(ipn.insurance_policy_note_id) as insurance_policy_note_id "
	+"                                                                    FROM mv_insurance_policy_note ipn, "
	+"                                                                         mv_ip ip "
	+"                                                                   WHERE ipn.user_activity_type_cd IN ('VIEW_QUO', 'UPLOAD_QUO', 'CHG_FLW_ST') "
	+"                                                                     AND   ip.ipid = ipn.insurance_policy_id "
	+"                                                                   GROUP BY ipn.insurance_policy_id "
	+"                                                                   UNION ALL "
	+"                                                                  SELECT ipn.insurance_policy_id, "
	+"                                                                         MAX(ipn.insurance_policy_note_id) as insurance_policy_note_id "
	+"                                                                    FROM mv_insurance_policy_note ipn, "
	+"                                                                         mv_ip ip "
	+"                                                                   WHERE ipn.user_activity_type_cd in ('ADD_NOTE') "
	+"                                                                     AND   ip.ipid = ipn.insurance_policy_id "
	+"                                                                   GROUP BY ipn.insurance_policy_id "
	+"                                                                 ) , "
	+"                                              subb AS (SELECT sb.sub_broker_web_access_type, "
	+"                                                              sb.company_number, "
	+"                                                              MAX(sba.sub_broker_assignment_id) AS sub_broker_assignment_id, "
	+"                                                              sba.insurance_policy_id, "
	+"                                                              sb.sub_broker_number, "
	+"                                                              sb.sub_broker,     "
	+"                                                              sb.name_line1, "
	+"                                                              sb.name_line2, "
	+"                                                              sb.attending_broker_name_line1, "
	+"                                                              sb.city"
	+"                                                         FROM cifadmin.sub_brokers sb, "
	+"                                                              plpadmin.sub_broker_assignment sba, "
	+"                                                              mv_ip ip "
	+"                                                        WHERE sb.sub_broker = sba.cif_sub_broker_id "
	+"                                                          AND sb.company_number = :subBrokerCompanyNbr "
	+"                                                          AND sb.search_province = :provinceCd"
	+"                                                          AND (sb.sub_broker_web_access_type  IN ('QI', 'QB', 'QIB') or sb.quick_quote_web_access_type IN ('QI', 'QB', 'QIB'))"
	+"                                                          AND ip.ipid = sba.insurance_policy_id "
	+"                                                         GROUP BY sb.sub_broker_web_access_type, sb.company_number,sba.insurance_policy_id, sb.sub_broker_number, sb.sub_broker, sb.name_line1, sb.name_line2,sb.attending_broker_name_line1, sb.city "
	+"                                                      ) ,"
	+"                                              mv_vehicle_cvi1 AS (SELECT iro.cvi_pure_with_credit_qty ,"
	+"                                                                         ir.vehicle_class_cd,"
	+"                                                                         ir.policy_version_id,"
	+"                                                                         ir.insurance_risk_seq "
	+"                                                                    FROM plpadmin.insurance_risk ir, "
	+"                                                                         plpadmin.insurance_risk_offer iro "
	+"                                                                   WHERE iro.insurance_risk_id = ir.insurance_risk_id "
	+"                                                                     AND iro.insurance_risk_offer_id = ir.selected_ins_risk_offer_id "
	+"                                                                     AND iro.selected_for_pol_offer_rat_ind  = 'Y'"
	+"                                                                     AND ir.insurance_risk_seq = 1"
	+"                                                                 ),"
	+"                                              mv_vehicle_cvi2 AS (SELECT iro.cvi_pure_with_credit_qty ,"
	+"                                                                         ir.vehicle_class_cd,"
	+"                                                                         ir.policy_version_id,"
	+"                                                                         ir.insurance_risk_seq "
	+"                                                                    FROM plpadmin.insurance_risk ir, "
	+"                                                                         plpadmin.insurance_risk_offer iro "
	+"                                                                   WHERE iro.insurance_risk_id = ir.insurance_risk_id "
	+"                                                                     AND iro.insurance_risk_offer_id = ir.selected_ins_risk_offer_id "
	+"                                                                     AND iro.selected_for_pol_offer_rat_ind  = 'Y'"
	+"                                                                     AND ir.insurance_risk_seq = 2 "
	+"                                                                 )"
	+"                                        SELECT ipid, "
	+"                                               sb.sub_broker_assignment_id,"
	+"                                               sb.company_number,"
	+"                                               ipn.user_activity_type_cd, "
	+"                                               ipts, "
	+"                                               ipagreementnb, "
	+"                                               ipagreementlegacynb, "
	+"                                               ipfollowupstatuscd, "
	+"                                               ipexpiritydt, "
	+"                                               ipextsystorigincd, "
	+"                                               ipn.system_create_ts AS ipnts, "
	+"                                               ipn.insurance_policy_note_id AS ipnid, "
	+"                                               ipn.insurance_policy_note AS ipnnote, "
	+"                                               ipn.author_u_id AS ipnauthor, "
	+"                                               ipn.user_activity_type_cd AS ipnuseract, "
	+"                                               sb.sub_broker as sbasubbroker, "
	+"                                               sb.name_line1 AS sbasubbrokername1, "
	+"                                               sb.name_line2 AS sbasubbrokername2, "
	+"                                               sb.attending_broker_name_line1 AS sbasubbrokername3, "
	+"                                               sb.city AS sbasubbrokercity, "
	+"                                               NULL AS lastfollowupnote, "
	+"                                               NULL AS lastactivitynote, "
	+"                                               ip.quotation_validity_expiry_dt, "
	+"                                               ip.last_pv,"
	+"                                               vc1.cvi_pure_with_credit_qty irocviwithcrt_1,"
	+"                                               vc2.cvi_pure_with_credit_qty irocviwithcrt_2,"
	+"                                               vc1.vehicle_class_cd vehicleclass_1,"
	+"                                               vc2.vehicle_class_cd vehicleclass_2"
	+"                                          FROM mv_ip ip, "
	+"                                               mv_insurance_policy_note ipn, "
	+"                                               subb sb, "
	+"                                               insurance_notes iipn,"
	+"                                               mv_vehicle_cvi1  vc1,"
	+"                                               mv_vehicle_cvi2  vc2"
	+"                                         WHERE sb.insurance_policy_id = ip.ipid "
	+"                                           AND sb.sub_broker_assignment_id =  ip.last_sba_id "
	+"                                           AND ip.ipid = iipn.insurance_policy_id(+) "
	+"                                           AND ipn.insurance_policy_note_id (+)= iipn.insurance_policy_note_id"
	+"                                           AND vc1.policy_version_id(+) = ip.last_pv"
	+"                                           AND vc2.policy_version_id(+) = ip.last_pv"
	+"                                       )ip, "
	+"                                       plpadmin.policy_version pv, "
	+"                                       plpadmin.business_transaction bt, "
	+"                                       plpadmin.business_trx_activity bta "
	+"                                 WHERE ip.ipid = pv.insurance_policy_id "
	+"                                  AND pv.policy_version_id = ip.last_pv "
	+"                                  AND pv.business_transaction_id = bt.business_transaction_id "
	+"                                  AND NOT (ip.quotation_validity_expiry_dt < SYSDATE AND bt.transaction_status_cd in ('S','I','X', 'J', 'Y')) "
	+"                                  AND bt.transaction_status_cd NOT IN ('A', 'D') "
	+"                                  AND bt.last_update_ts > SYSDATE - :nbrOfDaysLeft "
	+"                                  AND bta.business_trx_activity_id IN (SELECT MAX (ibta.business_trx_activity_id) "
	+"                                                                         FROM plpadmin.business_trx_activity ibta "
	+"                                                                        WHERE bt.business_transaction_id = ibta.business_transaction_id "
	+"                                                                      ) "
	+"                               ) pv, "
	+"                               plpadmin.policy_holder ph, "
	+"                               plpadmin.party pa, "
	+"                               plpadmin.address addr"
	+"                         WHERE pv.lastPv = ph.policy_version_id "
	+"                           AND ph.policy_holder_type_cd = 'P' "
	+"                           AND ph.party_id = pa.party_id "
	+"                           AND addr.party_id = pa.party_id "
	+"                           AND ( EXISTS(SELECT 1 "
	+"                                          FROM plpadmin.consent co "
	+"                                         WHERE pa.party_id = co.party_id "
	+"                                           AND co.consent_ind = 'Y' "
	+"                                           AND co.consent_type_cd = 'PR' "
	+"                                          ) "
	+"                                              OR NOT EXISTS(SELECT 1 "
	+"                                                              FROM plpadmin.consent co "
	+"                                                             WHERE pa.party_id = co.party_id "
	+"                                                               AND co.consent_type_cd = 'PR' "
	+"                                                           ) "
	+"                                           ) "
	+"                      ORDER BY btlastupdatets DESC       )   WHERE ROWNUM <= :maxRow"
				
				) })


public class InsurancePolicyBrokerInfo extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	private Long id;

	/** The agreement number. */
	private String agreementNumber;

	/** The agreement legacy number. */
	private String agreementLegacyNumber;

	/** The follow up status code. */
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.AgreementFollowUpStatusEnum") })
	private AgreementFollowUpStatusEnum followUpStatusCode;

	/** The expirity date. */
	private Date expirityDate;

	/** The inception date. */
	private Date inceptionDate;

	/** The rating date. */
	private Date ratingDate;

	/** The first name. */
	private String firstName;

	/** The last name. */
	private String lastName;
	
	private Long partyId;
	
	private Long insurancePolicyId;		
	
	private Date birthDate = null;
	
	private String postalCode = null;

	/** The b trx last update date. */
	private Date bTrxLastUpdateDate;

	/** The b trx status code. */
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.TransactionStatusCodeEnum") })
	private TransactionStatusCodeEnum bTrxStatusCode;

	/** The b trx activity code. */
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.BusinessTransactionActivityCodeEnum") })
	private BusinessTransactionActivityCodeEnum bTrxActivityCode;

	/** The sub broker name1. */
	private String subBrokerName1;

	/** The sub broker name2. */
	private String subBrokerName2;

	/** The sub broker name3. the one set in POS Management */
	private String subBrokerName3;

	/** The sub broker city. */
	private String subBrokerCity;

	/** The last followup note. */
	private InsurancePolicyNoteInfo lastFollowupNote = new InsurancePolicyNoteInfo();

	/** The last activity note. */
	private InsurancePolicyNoteInfo lastActivityNote = new InsurancePolicyNoteInfo();

	private String quoteSource;

	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.LanguageCodeEnum") })
	private LanguageCodeEnum languageCommunicationCode;

	private String consent;

	private String roadblockMsg;

	private String typeOfResidence;

	/** The combined policy code. */
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.CombinedPolicyCodeEnum") })
	private CombinedPolicyCodeEnum combinedPolicyCode;

	/** The combined policy scenario code. */
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.CombinedPolicyScenarioCodeEnum") })
	private CombinedPolicyScenarioCodeEnum combinedPolicyScenarioCode;

	private String customerValueIndex1;

	private String customerValueIndex2;
	
	private String intactRank;
	
	private String autoPlus;
	
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.LineOfBusinessCodeEnum") })
	private LineOfBusinessCodeEnum lineOfBusiness;
	
	private String unstructuredName;
	

	public String getCustomerValueIndex1() {
		return this.customerValueIndex1;
	}

	public void setCustomerValueIndex1(String custumerValueIndex) {
		this.customerValueIndex1 = custumerValueIndex;
	}

	public String getCustomerValueIndex2() {
		return this.customerValueIndex2;
	}

	public void setCustomerValueIndex2(String customerValueIndex2) {
		this.customerValueIndex2 = customerValueIndex2;
	}
	
	private String vehicleClass1;
	private String vehicleClass2;
	

	public String getVehicleClass1() {
		return this.vehicleClass1;
	}

	public void setVehicleClass1(String vehicleClass1) {
		this.vehicleClass1 = vehicleClass1;
	}

	public String getVehicleClass2() {
		return this.vehicleClass2;
	}

	public void setVehicleClass2(String vehicleClass2) {
		this.vehicleClass2 = vehicleClass2;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long) aId;
	}

	/**
	 * Gets the agreement number.
	 * 
	 * @return the agreement number
	 */
	public String getAgreementNumber() {
		return this.agreementNumber;
	}

	/**
	 * Sets the agreement number.
	 * 
	 * @param aAgreementNumber the new agreement number
	 */
	public void setAgreementNumber(String aAgreementNumber) {
		this.agreementNumber = aAgreementNumber;
	}

	/**
	 * Gets the agreement legacy number.
	 * 
	 * @return the agreement legacy number
	 */
	public String getAgreementLegacyNumber() {
		return this.agreementLegacyNumber;
	}

	/**
	 * Sets the agreement legacy number.
	 * 
	 * @param agreementLegacyNumber the new agreement legacy number
	 */
	public void setAgreementLegacyNumber(String anAgreementLegacyNumber) {
		this.agreementLegacyNumber = anAgreementLegacyNumber;
	}

	/**
	 * Gets the b trx activity code.
	 * 
	 * @return the b trx activity code
	 */
	public BusinessTransactionActivityCodeEnum getBTrxActivityCode() {
		return this.bTrxActivityCode;
	}

	/**
	 * Sets the b trx activity code.
	 * 
	 * @param trxActivityCode the new b trx activity code
	 */
	public void setBTrxActivityCode(BusinessTransactionActivityCodeEnum trxActivityCode) {
		this.bTrxActivityCode = trxActivityCode;
	}

	/**
	 * Gets the b trx last update date.
	 * 
	 * @return the b trx last update date
	 */
	public Date getBTrxLastUpdateDate() {
		return this.bTrxLastUpdateDate;
	}

	/**
	 * Sets the b trx last update date.
	 * 
	 * @param trxLastUpdateDate the new b trx last update date
	 */
	public void setBTrxLastUpdateDate(Date trxLastUpdateDate) {
		this.bTrxLastUpdateDate = trxLastUpdateDate;
	}

	/**
	 * Gets the b trx status code.
	 * 
	 * @return the b trx status code
	 */
	public TransactionStatusCodeEnum getBTrxStatusCode() {
		return this.bTrxStatusCode;
	}

	/**
	 * Sets the b trx status code.
	 * 
	 * @param trxStatusCode the new b trx status code
	 */
	public void setBTrxStatusCode(TransactionStatusCodeEnum trxStatusCode) {
		this.bTrxStatusCode = trxStatusCode;
	}

	/**
	 * Gets the expirity date.
	 * 
	 * @return the expirity date
	 */
	public Date getExpirityDate() {
		return this.expirityDate;
	}

	/**
	 * Sets the expirity date.
	 * 
	 * @param aExpirityDate the new expirity date
	 */
	public void setExpirityDate(Date aExpirityDate) {
		this.expirityDate = aExpirityDate;
	}

	/**
	 * Gets the first name.
	 * 
	 * @return the first name
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 * Sets the first name.
	 * 
	 * @param aFirstName the new first name
	 */
	public void setFirstName(String aFirstName) {
		this.firstName = aFirstName;
	}

	/**
	 * Gets the follow up status code.
	 * 
	 * @return the follow up status code
	 */
	public AgreementFollowUpStatusEnum getFollowUpStatusCode() {
		return this.followUpStatusCode;
	}

	/**
	 * Sets the follow up status code.
	 * 
	 * @param aFollowUpStatusCode the new follow up status code
	 */
	public void setFollowUpStatusCode(AgreementFollowUpStatusEnum aFollowUpStatusCode) {
		this.followUpStatusCode = aFollowUpStatusCode;
	}

	/**
	 * Gets the inception date.
	 * 
	 * @return the inception date
	 */
	public Date getInceptionDate() {
		return this.inceptionDate;
	}

	/**
	 * Sets the inception date.
	 * 
	 * @param aInceptionDate the new inception date
	 */
	public void setInceptionDate(Date aInceptionDate) {
		this.inceptionDate = aInceptionDate;
	}

	/**
	 * Gets the last name.
	 * 
	 * @return the last name
	 */
	public String getLastName() {
		return this.lastName;
	}

	/**
	 * Sets the last name.
	 * 
	 * @param aLastName the new last name
	 */
	public void setLastName(String aLastName) {
		this.lastName = aLastName;
	}

	public Date getBirthDate() {
		return this.birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public String getPostalCode() {
		return this.postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * Gets the rating date.
	 * 
	 * @return the rating date
	 */
	public Date getRatingDate() {
		return this.ratingDate;
	}

	/**
	 * Sets the rating date.
	 * 
	 * @param aRatingDate the new rating date
	 */
	public void setRatingDate(Date aRatingDate) {
		this.ratingDate = aRatingDate;
	}

	/**
	 * Gets the last activity note.
	 * 
	 * @return the last activity note
	 */
	public InsurancePolicyNoteInfo getLastActivityNote() {
		return this.lastActivityNote;
	}

	/**
	 * Gets the last followup note.
	 * 
	 * @return the last followup note
	 */
	public InsurancePolicyNoteInfo getLastFollowupNote() {
		return this.lastFollowupNote;
	}

	/**
	 * Sets the last activity note.
	 * 
	 * @param aLastActivityNote the new last activity note
	 */
	public void setLastActivityNote(InsurancePolicyNoteInfo aLastActivityNote) {
		this.lastActivityNote = aLastActivityNote;
	}

	/**
	 * Sets the last followup note.
	 * 
	 * @param aLastFollowupNote the new last followup note
	 */
	public void setLastFollowupNote(InsurancePolicyNoteInfo aLastFollowupNote) {
		this.lastFollowupNote = aLastFollowupNote;
	}

	/**
	 * Gets the sub broker city.
	 * 
	 * @return the sub broker city
	 */
	public String getSubBrokerCity() {
		return this.subBrokerCity;
	}

	/**
	 * Sets the sub broker city.
	 * 
	 * @param aSubBrokerCity the new sub broker city
	 */
	public void setSubBrokerCity(String aSubBrokerCity) {
		this.subBrokerCity = aSubBrokerCity;
	}

	/**
	 * Gets the sub broker name1.
	 * 
	 * @return the sub broker name1
	 */
	public String getSubBrokerName1() {
		return this.subBrokerName1;
	}

	/**
	 * Sets the sub broker name1.
	 * 
	 * @param aSubBrokerName1 the new sub broker name1
	 */
	public void setSubBrokerName1(String aSubBrokerName1) {
		this.subBrokerName1 = aSubBrokerName1;
	}

	/**
	 * Gets the sub broker name2.
	 * 
	 * @return the sub broker name2
	 */
	public String getSubBrokerName2() {
		return this.subBrokerName2;
	}

	/**
	 * Sets the sub broker name2.
	 * 
	 * @param aSubBrokerName2 the new sub broker name2
	 */
	public void setSubBrokerName2(String aSubBrokerName2) {
		this.subBrokerName2 = aSubBrokerName2;
	}

	/**
	 * Gets the sub broker name 3
	 * 
	 * @return the sub broker name 3
	 */
	public String getSubBrokerName3() {
		return this.subBrokerName3;
	}

	/**
	 * Sets the sub broker name 3
	 * 
	 * @param subBrokerName3 the sub broker name 3 to set
	 */
	public void setSubBrokerName3(String subBrokerName3) {
		this.subBrokerName3 = subBrokerName3;
	}

	/**
	 * Gets the quote source
	 * 
	 * @return the quote source
	 */
	public String getQuoteSource() {
		return this.quoteSource;
	}

	/**
	 * Sets the quote source
	 * 
	 * @param aQuoteSource the quote source to set
	 */
	public void setQuoteSource(String aQuoteSource) {
		this.quoteSource = aQuoteSource;
	}

	/**
	 * Gets the language communication code
	 * 
	 * @return the language communication code
	 */
	public LanguageCodeEnum getLanguageCommunicationCode() {
		return this.languageCommunicationCode;
	}

	/**
	 * Sets the language communication code
	 * 
	 * @param aLanguageCommunicationCode the language communication code to set
	 */
	public void setLanguageCommunicationCode(LanguageCodeEnum aLanguageCommunicationCode) {
		this.languageCommunicationCode = aLanguageCommunicationCode;
	}

	public String getConsent() {
		return this.consent;
	}

	public void setConsent(String aConsent) {
		this.consent = aConsent;
	}

	public String getRoadblockMsg() {
		return this.roadblockMsg;
	}

	public void setRoadblockMsg(String aRoadblockMsg) {
		this.roadblockMsg = aRoadblockMsg;
	}

	public String getTypeOfResidence() {
		return this.typeOfResidence;
	}

	public void setTypeOfResidence(String typeOfResidence) {
		this.typeOfResidence = typeOfResidence;
	}

	public CombinedPolicyCodeEnum getCombinedPolicyCode() {
		return this.combinedPolicyCode;
	}

	public void setCombinedPolicyCode(CombinedPolicyCodeEnum combinedPolicyCode) {
		this.combinedPolicyCode = combinedPolicyCode;
	}

	public CombinedPolicyScenarioCodeEnum getCombinedPolicyScenarioCode() {
		return this.combinedPolicyScenarioCode;
	}

	public void setCombinedPolicyScenarioCode(CombinedPolicyScenarioCodeEnum combinedPolicyScenarioCode) {
		this.combinedPolicyScenarioCode = combinedPolicyScenarioCode;
	}

	public String getIntactRank() {
		return intactRank;
	}

	public void setIntactRank(String intactRank) {
		this.intactRank = intactRank;
	}

	public String getAutoPlus() {
		return autoPlus;
	}

	public void setAutoPlus(String autoPlus) {
		this.autoPlus = autoPlus;
	}

	public Long getPartyId() {
		return partyId;
	}

	public void setPartyId(Long partyId) {
		this.partyId = partyId;
	}

	public Long getInsurancePolicyId() {
		return insurancePolicyId;
	}

	public void setInsurancePolicyId(Long insurancePolicyId) {
		this.insurancePolicyId = insurancePolicyId;
	}

	public LineOfBusinessCodeEnum getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(LineOfBusinessCodeEnum lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getUnstructuredName() {
		return unstructuredName;
	}

	public void setUnstructuredName(String unstructuredName) {
		this.unstructuredName = unstructuredName;
	}


	
}