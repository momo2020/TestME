package com.ing.canada.plp.lock;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.event.internal.DefaultFlushEntityEventListener;
import org.hibernate.event.spi.FlushEntityEvent;

public class InsurancePolicyLockFlushEntityEventListener extends DefaultFlushEntityEventListener {

	private static final long serialVersionUID = -8806669440915054626L;

	private static final Log log = LogFactory.getLog(InsurancePolicyLockFlushEntityEventListener.class);

	@Override
	public void onFlushEntity(FlushEntityEvent event) throws HibernateException {

		if (InsurancePolicyLockManagerThreadLocal.getGroupLockManager() != null) {

			if (log.isTraceEnabled()) {
				log.trace("about to flush an entity of type: " + event.getEntity().getClass().getSimpleName());

			}

			// InsurancePolicyLockManagerThreadLocal.getGroupLockManager().lockEntitiesInReadMode(event.getSession());

			// Checks the timestamp in memory
			// InsurancePolicyLockManagerThreadLocal.getGroupLockManager().checkVersions(event.getSession());
			// InsurancePolicyLockManagerThreadLocal.getGroupLockManager().upgradeVersions(event.getSession());
			// InsurancePolicyLockManagerThreadLocal.getGroupLockManager().upgradeVersions(event.getSession());

			InsurancePolicyLockManagerThreadLocal.getGroupLockManager().checkVersions(event.getSession());
		}

		//super.onFlushEntity(event);

		if (InsurancePolicyLockManagerThreadLocal.getGroupLockManager() != null
				&& event.getEntity() instanceof InsurancePolicyLockable) {
			InsurancePolicyLockable lockable = (InsurancePolicyLockable) event.getEntity();
			if (InsurancePolicyLockManagerThreadLocal.getGroupLockManager().isLocked(lockable)) {
				InsurancePolicyLockManagerThreadLocal.getGroupLockManager().refresh(lockable);
			}
		}

	}

}
