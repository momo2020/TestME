/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

/**
 * The Enum DriverLicenseTypeCodeEnum.
 */
public enum DriverLicenseTypeCodeEnum {

	REGULAR_LICENSE("R"), //
	LEARNER_LICENSE("L"), //
	PROBATIONARY_LICENSE("P"), //
	VALID_LICENSE_ISSUED_IN_ANOTHER_PROVINCE_COUNTRY("A"), //
	VALID_LICENSE_ISSUED_IN_ANOTHER_PROVINCE("C"),
	VALID_LICENSE_ISSUED_IN_ANOTHER_COUNTRY("B"),
	LEARNER_LICENSE_ISSUED_IN_ANOTHER_PROVINCE("D"),
	NO_LICENSE("U");

	/** The code. */
	private String code = null;
	
	private static Map<String, DriverLicenseTypeCodeEnum> valuesMap = null;

	/**
	 * Instantiates a new driver license type code enum.
	 * 
	 * @param aCode the a code
	 * @param aClass the DriverLicenseClassCodeEnum
	 */
	private DriverLicenseTypeCodeEnum(String aCode) {
		this.code = aCode;
	}

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Value of code.
	 * 
	 * @param value the value
	 * 
	 * @return the driver license type code enum
	 */
	public static DriverLicenseTypeCodeEnum valueOfCode(String value) {

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		for (DriverLicenseTypeCodeEnum v : values()) {
			if (v.code.equals(value)) {
				return v;
			}

		}

		throw new IllegalArgumentException("no enum value found for code: " + value);

	}
	
	public static DriverLicenseTypeCodeEnum fromCode(String code) {
			
		if (DriverLicenseTypeCodeEnum.valuesMap == null) {
			DriverLicenseTypeCodeEnum.valuesMap = new HashMap<String, DriverLicenseTypeCodeEnum>();

			for (DriverLicenseTypeCodeEnum type : DriverLicenseTypeCodeEnum.values())
				DriverLicenseTypeCodeEnum.valuesMap.put(type.getCode(), type);
		}

		return DriverLicenseTypeCodeEnum.valuesMap.get(code);
	}

	/**
	 * Value of driverLicenseClassCodeEnum.
	 * 
	 * @param value the value
	 * 
	 * @return the driver license type code enum
	 */
	public static DriverLicenseTypeCodeEnum valueOfDriverLicenseClassCodeEnum(DriverLicenseClassCodeEnum aClassCodeEnum) {

		if (aClassCodeEnum == null) {
			return null;
		}
		DriverLicenseTypeCodeEnum aDriverLicenseTypeCode = null;

		switch (aClassCodeEnum) {
		case LEARNER_PERMIT:
			// ON
			aDriverLicenseTypeCode = DriverLicenseTypeCodeEnum.LEARNER_LICENSE;
			break;
		case PROBATIONARY_PERMIT:
			// ON
			aDriverLicenseTypeCode = DriverLicenseTypeCodeEnum.PROBATIONARY_LICENSE;
			break;
		case GRADUATED_PERMIT:
			// ON
			aDriverLicenseTypeCode = DriverLicenseTypeCodeEnum.REGULAR_LICENSE;
			break;
		case LEARNER:
			// AB
			aDriverLicenseTypeCode = DriverLicenseTypeCodeEnum.LEARNER_LICENSE;
			break;
		case AXLE_CARS:
			// AB
			aDriverLicenseTypeCode = DriverLicenseTypeCodeEnum.REGULAR_LICENSE;
			break;
		case AXLE_PLUS:
			// AB
			aDriverLicenseTypeCode = DriverLicenseTypeCodeEnum.REGULAR_LICENSE;
			break;
		case PROFESSIONAL_ANY_VEHICULE:
			// AB
			aDriverLicenseTypeCode = DriverLicenseTypeCodeEnum.REGULAR_LICENSE;
			break;
		case PROFESSIONAL_BUS:
			// AB
			aDriverLicenseTypeCode = DriverLicenseTypeCodeEnum.REGULAR_LICENSE;
			break;
		case PROFESSIONAL_TAXI:
			// AB
			aDriverLicenseTypeCode = DriverLicenseTypeCodeEnum.REGULAR_LICENSE;
			break;
		default:
			throw new IllegalArgumentException("no enum value found for enum: " + aClassCodeEnum.toString());
		}

		return aDriverLicenseTypeCode;
	}
}
