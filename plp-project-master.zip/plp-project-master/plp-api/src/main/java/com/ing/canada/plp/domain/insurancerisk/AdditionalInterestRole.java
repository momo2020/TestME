/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance 
 * Copyright (c) 2009, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.insurancerisk;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import com.ing.canada.plp.domain.AssociationsHelper;
import com.ing.canada.plp.domain.coverage.Coverage;
import com.ing.canada.plp.domain.enums.AdditionalInterestTypeCodeEnum;
import com.ing.canada.plp.domain.party.Party;
import com.ing.canada.plp.domain.usertype.BaseEntity;
import com.ing.canada.plp.domain.vehicle.Vehicle;

/**
 * AdditionalInterestRole entity.
 * 
 * @author Patrick Lafleur
 */
@Entity
@Table(name = "ADDITIONAL_INTEREST_ROLE", uniqueConstraints = {})
public class AdditionalInterestRole extends BaseEntity {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(name = "ADDITIONAL_INTEREST_ROLE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "AdditionalInterestRoleSequence")
	@SequenceGenerator(name = "AdditionalInterestRoleSequence", sequenceName = "ADDITIONAL_INTEREST_ROLE_SEQ", allocationSize = 5)
	private Long id;

	/** The party. */
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "PARTY_ID", updatable = true)
	private Party party;

	/** The coverage. */
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "COVERAGE_ID", updatable = true)
	private Coverage coverage;

	/** The trailer. */
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "TRAILER_ID", updatable = true)
	private Trailer trailer;

	/** The vehicle. */
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "VEHICLE_ID", updatable = true)
	private Vehicle vehicle;

	/** The additional interest type. */
	@Column(name = "ADDITIONAL_INTEREST_TYPE_CD", nullable = false, length = 1)
	@Type(type = "com.ing.canada.plp.dao.mapping.GenericEnumUserType", parameters = { @Parameter(name = "enumClass", value = "com.ing.canada.plp.domain.enums.AdditionalInterestTypeCodeEnum") })
	private AdditionalInterestTypeCodeEnum additionalInterestType;

	/** The expiry date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRY_DT", length = 7)
	private Date expiryDate;

	/** The original scenario additional interest role. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_SCE_ADDITIONAL_INT_ROLE_ID", insertable = false, updatable = false)
	private AdditionalInterestRole originalScenarioAdditionalInterestRole;

	/** The additional interest repository manufacturing context. */
	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "ADDL_INT_REP_MAN_CONTEXT_ID", updatable = true)
	private AdditionalInterestRepositoryManufacturingContext additionalInterestRepositoryManufacturingContext;

	/**
	 * Instantiates a new additional interest role.
	 */
	public AdditionalInterestRole() {
		// noarg constructor
	}

	/**
	 * Instantiates a new additional interest role.
	 * 
	 * @param additionalInterestTypeCode the additional interest type code
	 */
	public AdditionalInterestRole(AdditionalInterestTypeCodeEnum additionalInterestTypeCode) {
		setAdditionalInterestType(additionalInterestTypeCode);
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#getId()
	 */
	@Override
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param aId the a id
	 * 
	 * @see com.ing.canada.plp.domain.usertype.BaseEntity#setId(java.lang.Object)
	 */
	@Override
	public void setId(Object aId) {
		this.id = (Long)aId;
	}

	/**
	 * Gets the party.
	 * 
	 * @return the party
	 */
	@XmlTransient
	public Party getParty() {
		return this.party;
	}

	/**
	 * Sets the party.
	 * 
	 * @param aParty the new party
	 */
	public void setParty(Party aParty) {
		AssociationsHelper.updateOneToManyFields(aParty, "additionalInterestRoles", this, "party");
	}

	/**
	 * Gets the coverage.
	 * 
	 * @return the coverage
	 */
	@XmlTransient
	public Coverage getCoverage() {
		return this.coverage;
	}

	/**
	 * Sets the coverage.
	 * 
	 * @param aCoverage the new coverage
	 */
	public void setCoverage(Coverage aCoverage) {
		AssociationsHelper.updateOneToManyFields(aCoverage, "additionalInterestRoles", this, "coverage");
	}

	/**
	 * Gets the trailer.
	 * 
	 * @return the trailer
	 */
	@XmlTransient
	public Trailer getTrailer() {
		return this.trailer;
	}

	/**
	 * Sets the trailer.
	 * 
	 * @param aTrailer the new trailer
	 */
	public void setTrailer(Trailer aTrailer) {
		AssociationsHelper.updateOneToManyFields(aTrailer, "additionalInterestRoles", this, "trailer");
	}

	/**
	 * Gets the vehicle.
	 * 
	 * @return the vehicle
	 */
	@XmlTransient
	public Vehicle getVehicle() {
		return this.vehicle;
	}

	/**
	 * Sets the vehicle.
	 * 
	 * @param aVehicle the new vehicle
	 */
	public void setVehicle(Vehicle aVehicle) {
		AssociationsHelper.updateOneToManyFields(aVehicle, "additionalInterestRoles", this, "vehicle");
	}

	/**
	 * Gets the additional interest type.
	 * 
	 * @return the additional interest type
	 */
	public AdditionalInterestTypeCodeEnum getAdditionalInterestType() {
		return this.additionalInterestType;
	}

	/**
	 * Sets the additional interest type.
	 * 
	 * @param additionalInterestTypeCode the new additional interest type
	 */
	public void setAdditionalInterestType(AdditionalInterestTypeCodeEnum additionalInterestTypeCode) {
		this.additionalInterestType = additionalInterestTypeCode;
	}

	/**
	 * Gets the expiry date.
	 * 
	 * @return the expiry date
	 */
	public Date getExpiryDate() {
		return this.expiryDate;
	}

	/**
	 * Sets the expiry date.
	 * 
	 * @param aExpiryDate the new expiry date
	 */
	public void setExpiryDate(Date aExpiryDate) {
		this.expiryDate = aExpiryDate;
	}

	/**
	 * Gets the original scenario additional interest role.
	 * 
	 * @return the original scenario additional interest role
	 */
	public AdditionalInterestRole getOriginalScenarioAdditionalInterestRole() {
		return this.originalScenarioAdditionalInterestRole;
	}

	/**
	 * Sets the original scenario additional interest role.
	 * 
	 * @param anOoriginalScenarioAdditionalInterestRole the new original scenario additional interest role
	 */
	public void setOriginalScenarioAdditionalInterestRole(
			AdditionalInterestRole anOoriginalScenarioAdditionalInterestRole) {
		this.originalScenarioAdditionalInterestRole = anOoriginalScenarioAdditionalInterestRole;
	}

	/**
	 * Gets the additional interest repository manufacturing context.
	 * 
	 * @return the additional interest repository manufacturing context
	 */
	public AdditionalInterestRepositoryManufacturingContext getAdditionalInterestRepositoryManufacturingContext() {
		return this.additionalInterestRepositoryManufacturingContext;
	}

	/**
	 * Sets the additional interest repository manufacturing context.
	 * 
	 * @param aAdditionalInterestRepositoryManufacturingContext the new additional interest repository manufacturing
	 *            context
	 */
	public void setAdditionalInterestRepositoryManufacturingContext(
			AdditionalInterestRepositoryManufacturingContext aAdditionalInterestRepositoryManufacturingContext) {
		this.additionalInterestRepositoryManufacturingContext = aAdditionalInterestRepositoryManufacturingContext;
	}

}
