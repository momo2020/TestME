package com.ing.canada.plp.service;

import com.ing.canada.plp.domain.businesstransaction.BusinessTransactionSubActivity;

public interface IBusinessTransactionSubActivityService{
		
	/**
	 * Returns the last sub transaction activity associated with a business transaction.
	 * 
	 * @param businessTrxId
	 * @return BusinessTransactionSubActivity
	 */
	BusinessTransactionSubActivity findLastSubActivity(Long businessTrxId);	
	
}
