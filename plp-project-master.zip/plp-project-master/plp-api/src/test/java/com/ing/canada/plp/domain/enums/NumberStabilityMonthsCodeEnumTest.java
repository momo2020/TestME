package com.ing.canada.plp.domain.enums;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class NumberStabilityMonthsCodeEnumTest {

	@Test
	public void test() {
		
		assertTrue(5 == NumberStabilityMonthsCodeEnum.getNumberStabilityMonths(NumberStabilityMonthsCodeEnum.LESS_THAN_ONE));
		assertTrue(5 == NumberStabilityMonthsCodeEnum.getNumberStabilityMonths(NumberStabilityMonthsCodeEnum.LESS_THAN_SIX));
		assertTrue(9 == NumberStabilityMonthsCodeEnum.getNumberStabilityMonths(NumberStabilityMonthsCodeEnum.BETWEEN_SIX_AND_TWENTYFOUR));
		assertTrue(54 == NumberStabilityMonthsCodeEnum.getNumberStabilityMonths(NumberStabilityMonthsCodeEnum.TWENTYFOUR_OR_MORE));
		assertTrue(18 == NumberStabilityMonthsCodeEnum.getNumberStabilityMonths(NumberStabilityMonthsCodeEnum.BETWEEN_ONE_AND_TWO));
		assertTrue(30 == NumberStabilityMonthsCodeEnum.getNumberStabilityMonths(NumberStabilityMonthsCodeEnum.BETWEEN_TWO_AND_THREE));
		assertTrue(42 == NumberStabilityMonthsCodeEnum.getNumberStabilityMonths(NumberStabilityMonthsCodeEnum.BETWEEN_THREE_AND_FOUR));
		assertTrue(54 == NumberStabilityMonthsCodeEnum.getNumberStabilityMonths(NumberStabilityMonthsCodeEnum.BETWEEN_FOUR_AND_FIVE));
		assertTrue(66 == NumberStabilityMonthsCodeEnum.getNumberStabilityMonths(NumberStabilityMonthsCodeEnum.FIVE_OR_MORE));
		
		// test default
		assertTrue(0 == NumberStabilityMonthsCodeEnum.getNumberStabilityMonths(NumberStabilityMonthsCodeEnum.BETWEEN_NINE_AND_TEN));
	}

}
