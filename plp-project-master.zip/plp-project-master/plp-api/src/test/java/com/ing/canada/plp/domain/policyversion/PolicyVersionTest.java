/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2017, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.policyversion;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ing.canada.plp.domain.enums.DistributorCodeEnum;

/**
 * @author <a href="mailto:pascal.meunier@intact.net">Pascal Meunier</a>
 *
 */
public class PolicyVersionTest {

	PolicyVersion testedPolicyVersion;

	@Before
	public void setUp() throws Exception {
		this.testedPolicyVersion = new PolicyVersion();
	}

	@After
	public void tearDown() throws Exception {
		this.testedPolicyVersion = null;
	}

	@Test
	public void testGetDistributorCode_nullDCDRE() {
		this.testedPolicyVersion.setDirectChanDistRepEntry(null);
		assertEquals(null, this.testedPolicyVersion.getDistributorCode());
	}

	@Test
	public void testGetDistributorCode_empty() {
		DirectChanDistRepEntry actDCDRE = new DirectChanDistRepEntry();

		this.testedPolicyVersion.setDirectChanDistRepEntry(actDCDRE);
		assertEquals(null, this.testedPolicyVersion.getDistributorCode());
	}

	@Test
	public void testGetDistributorCode_valid() {
		DirectChanDistRepEntry actDCDRE = new DirectChanDistRepEntry();
		actDCDRE.setCode(DistributorCodeEnum.BEL);

		// Test Belair
		this.testedPolicyVersion.setDirectChanDistRepEntry(actDCDRE);
		assertEquals(DistributorCodeEnum.BEL, this.testedPolicyVersion.getDistributorCode());

		// Test BNA
		actDCDRE.setCode(DistributorCodeEnum.BNA);
		assertEquals(DistributorCodeEnum.BNA, this.testedPolicyVersion.getDistributorCode());
	}

}
