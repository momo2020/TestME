/**
 * Important notice: This software is the sole property of Intact Insurance and cannot be distributed and/or copied
 * without the written permission of Intact Insurance
 * Copyright (c) 2017, Intact Insurance, All rights reserved.<br>
 */
package com.ing.canada.plp.domain.enums;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Test class for the DistributorCodeEnum
 * 
 * @author <a href="mailto:pascal.meunier@intact.net">Pascal Meunier</a>
 *
 */
public class DistributorCodeEnumTest {

	/**
	 * Test method for {@link com.ing.canada.plp.domain.enums.DistributorCodeEnum#getCode()}.
	 */
	@Test
	public void testGetCode() {

		assertEquals("BEL", DistributorCodeEnum.BEL.getCode());

		assertEquals("BNA", DistributorCodeEnum.BNA.getCode());
	}

	/**
	 * Test method for {@link com.ing.canada.plp.domain.enums.DistributorCodeEnum#valueOfCode(java.lang.String)}.
	 */
	@Test
	public void testValueOfCode() {

		assertEquals(DistributorCodeEnum.BNA, DistributorCodeEnum.valueOfCode("bna"));

		assertEquals(DistributorCodeEnum.BEL, DistributorCodeEnum.valueOfCode("BeL"));

		assertEquals(null, DistributorCodeEnum.valueOfCode("PATATE"));

		assertEquals(null, DistributorCodeEnum.valueOfCode(null));

	}

}
