# plp-project
PLP persistence model library

[![Build Status](https://prod-jenkins-2020.iad.ca.inet/job/Intact/job/plp-project/job/master/badge/icon)][jenkins-build-status]

### Built With

- [Jenkinsfile jobs][jenkins-job]
  - [pipeline activity][jenkins-pipeline]


### Changelog

For the list of latest and upcoming changes see [CHANGELOG](CHANGELOG.md) file.


### Integrating to your project

Add to your project's pom file the 2 following dependencies
 
```
<dependencies>
...
    <dependency>
        <groupId>intact.commons.service.plp</groupId>
        <artifactId>plp-api</artifactId>
    </dependency>
    <dependency>
        <groupId>intact.commons.service.plp</groupId>
        <artifactId>plp-services</artifactId>
        <scope>runtime</scope>
    </dependency>
...
</dependencies>
```

YOU SHOULD JUST PUT PLP-SERVICES DEPENDENCY AS RUNTIME SCOPE IN THE XXXX-WEB OF YOUR PROJECT ONLY.
ALL THE APPLICATION SHOULD USE THE PLP SERVICES VIA THE PLP-API ONLY.  SPRING DI WILL THEN USE IMPLEMENTATIONS FOUND IN PLP-SERVICES.

The project plp-services also contains full Spring application context files that you can refer to directly in your project:
- dw-services-beans.xml  : `<import resource="classpath:dw-services-bean.xml" />`
- plp-services-beans.xml : `<import resource="classpath:plp-services-beans.xml" />`
- transaction-beans.xml  : `<import resource="classpath:transaction-beans.xml" />`


### Installing

`mvn clean install` 







[jenkins-job]: https://prod-jenkins-2020.iad.ca.inet/job/Intact/job/plp-project/
[jenkins-build-status]: https://prod-jenkins-2020.iad.ca.inet/job/Intact/job/plp-project/job/master/
[jenkins-pipeline]: https://prod-jenkins-2020.iad.ca.inet/blue/organizations/jenkins/GitHub%2FIntact%2Fplp-project/activity
